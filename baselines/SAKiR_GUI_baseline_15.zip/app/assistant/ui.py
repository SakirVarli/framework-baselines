"""Native PyQt assistant, connection settings, capability browser and review."""
import copy
from dataclasses import asdict
import html
import json
import re
from pathlib import Path
import threading
import time

from PyQt5 import QtCore, QtGui, QtWidgets

from . import changes
from .appearance import ComboBox, apply_theme, icon
from .activity import WorkingIndicator
from .conversation import Conversation
from .chat_rendering import message_html
from .policy import AssistantError, digest, redact
from .provider import ChatProvider
from .storage import Settings
from .usage import UsageIndicator
from .context_window import capacity_for
from .settings_help import SETTING_HELP, TAB_HELP, HEADER_HELP
from .turn_activity import TurnActivity
from .review import ReviewDialog


def show_error(parent, exc):
    QtWidgets.QMessageBox.warning(parent, "Assistant", str(exc))


class SettingsDialog(QtWidgets.QDialog):
    probe_finished = QtCore.pyqtSignal(object)

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Assistant Settings")
        apply_theme(self)
        self.resize(690, 650)
        self.widgets = {}
        self.profile = copy.deepcopy(controller.settings.capability_profile)
        self.model_limits = {}
        self.cancel = threading.Event()
        self.provider = None
        outer = QtWidgets.QVBoxLayout(self)
        notice = QtWidgets.QLabel("Configuration: app/data/assistant/assistant.json\n"
                                 "Assistant files stay inside this framework folder.\n"
                                 "Hover over a setting or its label for an explanation.")
        notice.setWordWrap(True)
        outer.addWidget(notice)
        tabs = QtWidgets.QTabWidget()
        tabs.setAccessibleName("Assistant settings sections")
        tabs.tabBar().setObjectName("assistantSettingsTabs")
        tabs.setUsesScrollButtons(False)
        tabs.setElideMode(QtCore.Qt.ElideNone)
        tabs.tabBar().setExpanding(False)
        outer.addWidget(tabs)
        connection, limits, privacy = [QtWidgets.QWidget() for _ in range(3)]
        tabs.addTab(connection, "Connection")
        tabs.addTab(limits, "Limits")
        tabs.addTab(privacy, "History")
        usage = QtWidgets.QWidget()
        tabs.addTab(usage, "Usage")
        usage_layout = QtWidgets.QVBoxLayout(usage)
        hint = QtWidgets.QLabel("Choose HTTP response headers to show in the assistant's Usage area. "
                               "Values update after each model response, including error responses. "
                               "Header keys are case-insensitive; values are displayed as sent by your provider.")
        hint.setWordWrap(True)
        usage_layout.addWidget(hint)
        self.usage_headers = QtWidgets.QTableWidget(0, 2)
        self.usage_headers.setAccessibleName("Usage response header mappings")
        self.usage_headers.setHorizontalHeaderLabels(["Header key", "Display name"])
        self.usage_headers.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.usage_headers.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.usage_headers.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.usage_headers.verticalHeader().hide()
        usage_layout.addWidget(self.usage_headers, 1)
        row = QtWidgets.QHBoxLayout()
        self.add_header_button = QtWidgets.QPushButton("Add header")
        self.add_header_button.clicked.connect(lambda: self.add_usage_header())
        self.remove_header_button = QtWidgets.QPushButton("Remove selected")
        self.remove_header_button.clicked.connect(self.remove_usage_headers)
        row.addWidget(self.add_header_button)
        row.addWidget(self.remove_header_button)
        row.addStretch(1)
        usage_layout.addLayout(row)
        example = QtWidgets.QLabel("Example: x-ratelimit-remaining-tokens → Tokens remaining\n"
                                  "Example: x-ratelimit-reset-tokens → Tokens reset in\n"
                                  "Missing headers show “Not provided”. No values are added together or converted to percentages.")
        example.setWordWrap(True)
        usage_layout.addWidget(example)
        for entry in controller.settings.usage_headers:
            self.add_usage_header(entry["header"], entry["display_name"])
        conn = QtWidgets.QFormLayout(connection)
        self.text(conn, "base_url", "Server base URL", "http://server:8000/v1")
        self.text(conn, "model", "Model ID", "Exact ID returned by your server")
        self.combo(conn, "auth_mode", "Authentication", [("No authentication", "none"), ("Session key", "session"),
                   ("Environment variable", "environment"), ("Windows Credential Manager", "windows")])
        self.key = QtWidgets.QLineEdit(controller.credentials.session)
        self.key.setEchoMode(QtWidgets.QLineEdit.Password)
        self.key.setPlaceholderText("Enter a key; never written to assistant.json")
        conn.addRow("API key", self.key)
        self.text(conn, "key_env", "Key environment variable")
        self.text(conn, "credential_ref", "Windows credential reference", "Auto-generated when a key is saved")
        self.text(conn, "ca_bundle", "Custom CA certificate", "Optional path to a trusted CA PEM file")
        self.check(conn, "streaming", "Stream responses")
        probe_row = QtWidgets.QWidget()
        buttons = QtWidgets.QHBoxLayout(probe_row)
        self.list_button = QtWidgets.QPushButton("List models")
        self.probe_button = QtWidgets.QPushButton("Test tools && streaming")
        buttons.addWidget(self.list_button)
        buttons.addWidget(self.probe_button)
        conn.addRow(probe_row)
        self.models = ComboBox()
        self.models.setPlaceholderText("Models returned by the server")
        self.models.activated.connect(self.select_model)
        conn.addRow("Discovered models", self.models)
        self.probe_status = QtWidgets.QPlainTextEdit()
        self.probe_status.setReadOnly(True)
        self.probe_status.setMaximumHeight(140)
        self.probe_status.setPlainText(json.dumps(self.profile, indent=2) if self.profile else "Connection not tested yet. Model IDs can also be entered manually.")
        conn.addRow("Compatibility", self.probe_status)
        form = QtWidgets.QFormLayout(limits)
        self.combo(form, "token_parameter", "Output limit parameter", [("max_tokens", "max_tokens"), ("max_completion_tokens", "max_completion_tokens")])
        for key, label, low, high in (("timeout", "Request timeout (seconds)", 5, 600), ("max_tokens", "Maximum output tokens", 256, 65536),
                                    ("context_chars", "Context budget (characters)", 8000, 2000000), ("max_rounds", "Maximum model rounds", 1, 40),
                                    ("max_tool_calls", "Maximum tool calls", 1, 100), ("task_timeout", "Task deadline (seconds)", 30, 3600),
                                    ("file_timeout", "File-reader timeout (seconds)", 1, 120), ("preview_rows", "Preview rows", 1, 200),
                                    ("result_chars", "Tool-result character limit", 1000, 64000)):
            spin = QtWidgets.QSpinBox()
            spin.setRange(low, high)
            spin.setValue(getattr(controller.settings, key))
            self.widgets[key] = spin
            form.addRow(label, spin)
        hint = QtWidgets.QLabel("Context is measured conservatively in characters. Server token limits still apply.\nDisable streaming if your server supports tools only in complete responses.")
        hint.setWordWrap(True)
        form.addRow(hint)
        context_page = QtWidgets.QWidget()
        tabs.addTab(context_page, "Context")
        form = QtWidgets.QFormLayout(context_page)
        for key, label, low, high in (("context_tokens", "Model context capacity (tokens)", 0, 10000000),
                                    ("context_margin", "Safety margin (tokens)", 0, 65536),
                                    ("compact_threshold", "Compact at input budget (%)", 50, 95)):
            spin = QtWidgets.QSpinBox()
            spin.setRange(low, high)
            spin.setValue(getattr(controller.settings, key))
            if key == "context_tokens":
                spin.setSpecialValueText("Automatic / unknown")
            self.widgets[key] = spin
            form.addRow(label, spin)
        self.combo(form, "tokenizer", "Preflight token counting", [("Estimate for any model", "estimate"),
                   ("cl100k_base (requires tiktoken)", "cl100k_base"), ("o200k_base (requires tiktoken)", "o200k_base")])
        self.check(form, "auto_compact", "Automatically compact older context")
        self.check(form, "stream_usage", "Request stream token usage (server support required)")
        hint = QtWidgets.QLabel("Set the capacity configured on your model server, or use model-list metadata when available. "
                               "Zero means unknown when the server does not advertise it. Maximum output tokens also reserve context space.\n\n"
                               "Preflight counts are estimates because servers use different chat templates. Provider-reported input usage "
                               "is shown after a response. Select a tokenizer only when it matches your model.\n\n"
                               "Compaction uses this server to summarize older conversation and completed tool activity. "
                               "It shares task time/model-round limits. The readable transcript stays intact; summaries can lose detail. "
                               "With unknown capacity, the character budget still controls compaction.")
        hint.setWordWrap(True)
        form.addRow(hint)
        form = QtWidgets.QFormLayout(privacy)
        self.check(form, "save_history", "Save visible conversation history locally")
        spin = QtWidgets.QSpinBox()
        spin.setRange(1, 100)
        spin.setValue(controller.settings.history_sessions)
        self.widgets["history_sessions"] = spin
        form.addRow("Retained sessions", spin)
        private = QtWidgets.QLabel(str(controller.store.private))
        private.setWordWrap(True)
        private.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        form.addRow("Assistant data folder", private)
        clear = QtWidgets.QPushButton("Delete conversation history")
        clear.clicked.connect(self.clear_history)
        form.addRow(clear)
        policy = QtWidgets.QLabel("Framework Python: read only\nCallbacks and externals: previewed project edits\nConfiguration JSON: validated edits\nGenerated stubs: maintained by the framework\nNo shell or arbitrary code execution tool\nApply & Reload executes reviewed project Python.\nAssistant data is excluded from baseline exports.\nOnly attached external files can be inspected outside the project.")
        policy.setWordWrap(True)
        form.addRow("Permissions", policy)
        self.buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.save)
        self.buttons.rejected.connect(self.reject)
        outer.addWidget(self.buttons)
        self.list_button.clicked.connect(lambda: self.test("models"))
        self.probe_button.clicked.connect(lambda: self.test("probe"))
        self.probe_finished.connect(self.test_finished)
        self.finished.connect(self.stop_probe)
        self.widgets["auth_mode"].currentIndexChanged.connect(self.update_auth)
        self.update_auth()
        for index, text in enumerate(TAB_HELP):
            tabs.setTabToolTip(index, self.help_text(text))
        for key, widget in self.widgets.items():
            self.explain(widget, SETTING_HELP[key])
        for key, widget in (("api_key", self.key), ("models", self.models), ("probe_status", self.probe_status),
                            ("data_folder", private)):
            self.explain(widget, SETTING_HELP[key])
        for widget, text in ((self.list_button, "Ask the configured server for available model IDs and any advertised context capacities. This makes a network request; you can enter a Model ID manually instead."),
                             (self.probe_button, SETTING_HELP["probe_status"]),
                             (clear, "Delete all saved conversation history and context summaries in this project, then start a new chat. Recovery journals and settings are retained."),
                             (self.add_header_button, "Add a response-header key and a display name to track in the Usage hover card. Up to 32 mappings are supported."),
                             (self.remove_header_button, "Remove the selected mappings. Changes take effect when you save Settings."),
                             (self.buttons.button(QtWidgets.QDialogButtonBox.Save), "Save these settings for this project. Session API keys stay in memory."),
                             (self.buttons.button(QtWidgets.QDialogButtonBox.Cancel), "Close without saving edited settings. Connection tests may already have sent requests."),
                             (self.usage_headers, "Add one response-header key and display name per row. Double-click a cell to edit it. Missing headers show Not provided in the Usage hover card."),
                             (policy, "These permissions describe what assistant tools can inspect or stage. File changes require review and Apply; reviewed project Python runs when loaded or reloaded.")):
            self.explain(widget, text)
        for column, text in enumerate(HEADER_HELP):
            self.usage_headers.horizontalHeaderItem(column).setToolTip(self.help_text(text))
        for value, text in (("none", "For servers that do not require an API key, usually local model servers."),
                            ("session", "Use the API key entered here for this app session. It stays in memory."),
                            ("environment", "Read the key from the named environment variable available to this app."),
                            ("windows", "Store or read the key using the specified Windows Credential Manager reference.")):
            combo = self.widgets["auth_mode"]
            combo.setItemData(combo.findData(value), self.help_text(text), QtCore.Qt.ToolTipRole)

    @staticmethod
    def help_text(text):
        return "<qt>" + html.escape(text) + "</qt>"

    def explain(self, widget, text):
        widget.setToolTip(self.help_text(text))
        widget.setAccessibleDescription(text)
        if isinstance(widget, QtWidgets.QSpinBox):
            widget.lineEdit().setToolTip(self.help_text(text))
        layout = widget.parentWidget().layout() if widget.parentWidget() else None
        if isinstance(layout, QtWidgets.QFormLayout):
            label = layout.labelForField(widget)
            if label is not None:
                label.setToolTip(self.help_text(text))
                label.setAccessibleDescription(text)

    def update_auth(self, *_):
        mode = self.widgets["auth_mode"].currentData()
        self.key.setEnabled(mode in {"session", "windows"})
        self.widgets["key_env"].setEnabled(mode == "environment")
        self.widgets["credential_ref"].setEnabled(mode == "windows")

    def select_model(self, index):
        model = self.models.itemText(index)
        self.widgets["model"].setText(model)
        if model in self.model_limits:
            base_url = self.widgets["base_url"].text().strip()
            profile = self.profile or {}
            if (profile.get("base_url"), profile.get("model")) != (base_url, model):
                profile = {"base_url": base_url, "model": model}
            self.profile = {**profile, "context_tokens": self.model_limits[model],
                            "streaming": self.widgets["streaming"].isChecked()}

    def add_usage_header(self, header="", display_name=""):
        row = self.usage_headers.rowCount()
        if row >= 32:
            return
        self.usage_headers.insertRow(row)
        for column, value in enumerate((header, display_name)):
            item = QtWidgets.QTableWidgetItem(value)
            item.setToolTip(self.help_text(HEADER_HELP[column]))
            self.usage_headers.setItem(row, column, item)
        self.usage_headers.setCurrentCell(row, 0)
        self.add_header_button.setEnabled(self.usage_headers.rowCount() < 32)

    def remove_usage_headers(self):
        for row in sorted({index.row() for index in self.usage_headers.selectedIndexes()}, reverse=True):
            self.usage_headers.removeRow(row)
        self.add_header_button.setEnabled(self.usage_headers.rowCount() < 32)

    def text(self, form, key, label, placeholder=""):
        widget = QtWidgets.QLineEdit(getattr(self.controller.settings, key))
        widget.setPlaceholderText(placeholder)
        self.widgets[key] = widget
        form.addRow(label, widget)

    def combo(self, form, key, label, items):
        widget = ComboBox()
        for title, value in items:
            widget.addItem(title, value)
        widget.setCurrentIndex(max(0, widget.findData(getattr(self.controller.settings, key))))
        self.widgets[key] = widget
        form.addRow(label, widget)

    def check(self, form, key, label):
        widget = QtWidgets.QCheckBox(label)
        widget.setChecked(getattr(self.controller.settings, key))
        self.widgets[key] = widget
        form.addRow(widget)

    def collect(self):
        data = asdict(self.controller.settings)
        for key, widget in self.widgets.items():
            data[key] = widget.currentData() if isinstance(widget, QtWidgets.QComboBox) else widget.isChecked() if isinstance(widget, QtWidgets.QCheckBox) else widget.value() if isinstance(widget, QtWidgets.QSpinBox) else widget.text().strip()
        data["capability_profile"] = self.profile
        data["usage_headers"] = []
        for row in range(self.usage_headers.rowCount()):
            values = [self.usage_headers.item(row, column).text().strip()
                      if self.usage_headers.item(row, column) else "" for column in range(2)]
            data["usage_headers"].append(dict(zip(("header", "display_name"), values)))
        return Settings(**data)

    def key_for(self, settings, save=False):
        if settings.auth_mode == "session":
            self.controller.credentials.session = self.key.text()
        elif settings.auth_mode == "windows" and self.key.text():
            if not save:
                return self.key.text()
            settings.credential_ref = settings.credential_ref or "SAKiR-Assistant-" + digest(settings.base_url.encode())[:24]
            self.controller.credentials._windows(settings.credential_ref, self.key.text())
        return self.controller.credentials.key(settings)

    def save(self):
        try:
            settings = self.collect()
            settings.validate(connection=bool(settings.base_url or settings.model))
            if settings.auth_mode in {"session", "windows"}:
                self.key_for(settings, save=True)
            profile = settings.capability_profile
            if profile and (profile.get("model"), profile.get("base_url"), profile.get("streaming")) != (settings.model, settings.base_url, settings.streaming):
                settings.capability_profile = ({"base_url": settings.base_url, "model": settings.model,
                                                "streaming": settings.streaming, "context_tokens": profile["context_tokens"]}
                                               if (profile.get("base_url"), profile.get("model")) == (settings.base_url, settings.model)
                                               and type(profile.get("context_tokens")) is int else None)
            self.controller.store.save_settings(settings)
            self.controller.settings = settings
            self.controller.settings_error = ""
            self.controller.activity.emit("settings", settings.model)
            self.accept()
        except Exception as exc:
            show_error(self, exc)

    def test(self, kind):
        try:
            settings = self.collect()
            if kind == "models" and not settings.model:
                settings.model = "discovery"
            settings.validate()
            key = self.key_for(settings)
        except Exception as exc:
            show_error(self, exc)
            return
        self.cancel = threading.Event()
        self.list_button.setEnabled(False)
        self.probe_button.setEnabled(False)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(False)
        self.probe_status.setPlainText("Checking the configured server…")
        def worker():
            try:
                self.provider = ChatProvider(settings, key)
                data = self.provider.models() if kind == "models" else self.provider.probe(self.cancel)
                result = {"kind": kind, "data": data, "model_limits": self.provider.model_limits}
                if kind == "probe" and self.profile and self.profile.get("context_tokens"):
                    if (self.profile.get("base_url"), self.profile.get("model")) == (settings.base_url, settings.model):
                        data["context_tokens"] = self.profile["context_tokens"]
            except Exception as exc:
                result = {"error": str(exc).replace(key, "<redacted>"), "code": getattr(exc, "code", "CONNECTION_ERROR"),
                          "profile": {"base_url": settings.base_url, "model": settings.model,
                                      "streaming": settings.streaming, "tool_round_trip": False}}
            finally:
                if self.provider:
                    try:
                        self.provider.dispose()
                    except Exception:
                        pass
                self.provider = None
            try:
                self.probe_finished.emit(result)
            except RuntimeError:
                pass
        threading.Thread(target=worker, daemon=True, name="assistant-connection-test").start()

    def test_finished(self, result):
        self.list_button.setEnabled(True)
        self.probe_button.setEnabled(True)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(True)
        self.probe_status.setPlainText(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("kind") == "models":
            self.model_limits = result.get("model_limits", {})
            self.models.clear()
            self.models.addItems(result["data"])
            index = self.models.findText(self.widgets["model"].text().strip())
            if index >= 0:
                self.select_model(index)
        elif result.get("kind") == "probe":
            self.profile = result["data"]
        elif result.get("code") == "TOOLS_UNSUPPORTED":
            self.profile = result["profile"]

    def stop_probe(self, *_):
        self.cancel.set()
        if self.provider:
            threading.Thread(target=self.provider.close, daemon=True).start()

    def clear_history(self):
        self.controller.store.clear_history()
        self.controller.new_session()
        self.probe_status.setPlainText("Conversation history deleted. Recovery journals retained.")


class Composer(QtWidgets.QPlainTextEdit):
    send_requested = QtCore.pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter) and not event.modifiers() & QtCore.Qt.ShiftModifier:
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


class AssistantWindow(QtWidgets.QMainWindow):
    def __init__(self, controller):
        # A QWidget parent creates a native owner on Windows, which excludes
        # the window from normal task switching. The controller owns lifetime.
        super().__init__(None, QtCore.Qt.Window)
        self.setWindowTitle("SAKiR Assistant")
        self.setObjectName("sakirAssistantWindow")
        self.setWindowIcon(controller.window.windowIcon())
        self.setAttribute(QtCore.Qt.WA_QuitOnClose, False)
        self.controller = controller
        self.resize(1180, 820)
        self.setMinimumSize(680, 500)
        apply_theme(self)
        self.visible_messages = copy.deepcopy(controller.history)
        self.streaming_text = ""
        self.turn_activities = {}
        self._active_turn = None
        self._message_id = None
        self._render_pending = False
        self._activity_titles = {}
        self._message_cache = []
        self.data_preview = None
        self._sidebar_preference = True
        self._sidebar_width = 248
        self._restoring_sidebar = False
        self._sessions = {}
        content = QtWidgets.QWidget()
        content.setObjectName("assistantSurface")
        self.setCentralWidget(content)
        shell = QtWidgets.QHBoxLayout(content)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)
        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        self.splitter.setObjectName("assistantSplit")
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(3)
        shell.addWidget(self.splitter)

        self.sidebar = QtWidgets.QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setMinimumWidth(220)
        self.sidebar.setMaximumWidth(480)
        side = QtWidgets.QVBoxLayout(self.sidebar)
        side.setContentsMargins(16, 24, 16, 16)
        side.setSpacing(10)
        side.addWidget(self.label("SAKiR  /  Assistant", "brand"))
        side.addSpacing(18)
        self.new_button = self.button("New chat", self.new, "newChat", "new")
        self.new_button.setToolTip("New chat (Ctrl+N)")
        side.addWidget(self.new_button)
        side.addWidget(self.button("Saved drafts", self.drafts, "navigation", "document"))
        side.addWidget(self.button("Capabilities", self.capabilities, "navigation", "folder"))
        side.addSpacing(18)
        side.addWidget(self.label("CONVERSATIONS", "eyebrow"))
        self.session_search = QtWidgets.QLineEdit()
        self.session_search.setObjectName("sessionSearch")
        self.session_search.setPlaceholderText("Search chats…")
        self.session_search.setAccessibleName("Search conversations")
        self.session_search.textChanged.connect(self.filter_sessions)
        side.addWidget(self.session_search)
        self.session_list = QtWidgets.QListWidget()
        self.session_list.setObjectName("sessions")
        self.session_list.setAccessibleName("Saved conversations")
        self.session_list.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.session_list.itemClicked.connect(self.load_session)
        side.addWidget(self.session_list, 1)
        self.session_notice = self.label("Your chats will appear here.", "muted")
        side.addWidget(self.session_notice)
        side.addWidget(self.button("Restore previous changes", self.restore, "navigation", "history"))
        side.addWidget(self.button("Settings", self.settings, "navigation", "settings"))
        project = self.label(controller.policy.root.name, "muted")
        project.setToolTip(str(controller.policy.root))
        side.addWidget(project)
        self.splitter.addWidget(self.sidebar)

        chat = QtWidgets.QWidget()
        chat.setObjectName("chatPage")
        chat.setMinimumWidth(400)
        outer = QtWidgets.QVBoxLayout(chat)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.splitter.addWidget(chat)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        divider = self.splitter.handle(1)
        divider.setCursor(QtCore.Qt.SizeHorCursor)
        divider.setAccessibleName("Resize conversation sidebar")
        divider.setToolTip("Drag left or right to resize the sidebar. Ctrl+B hides or shows it.")
        self.splitter.splitterMoved.connect(self.remember_sidebar_width)
        header = QtWidgets.QFrame()
        header.setObjectName("header")
        head = QtWidgets.QHBoxLayout(header)
        head.setContentsMargins(20, 14, 24, 14)
        toggle = self.button("", self.toggle_sidebar, "", "panel")
        toggle.setAccessibleName("Toggle conversation sidebar")
        toggle.setToolTip("Toggle sidebar (Ctrl+B)")
        head.addWidget(toggle)
        self.chat_title = self.label("New chat", "brand")
        self.chat_title.setMinimumWidth(0)
        self.chat_title.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        head.addWidget(self.chat_title, 1)
        self.model = self.label(controller.settings.model or "Set up a model", "model")
        self.model.setMaximumWidth(240)
        self.model.setToolTip(controller.settings.model or "Choose a model in Settings")
        head.addWidget(self.model)
        head.addWidget(self.button("", self.settings, "", "settings"))
        head.itemAt(head.count() - 1).widget().setToolTip("Connection settings")
        head.itemAt(head.count() - 1).widget().setAccessibleName("Connection settings")
        outer.addWidget(header)

        # Keep long responses and the composer within a comfortable reading width.
        reading_row = QtWidgets.QHBoxLayout()
        reading_row.setContentsMargins(24, 0, 24, 0)
        reading_row.addStretch(1)
        reading = QtWidgets.QWidget()
        reading.setMaximumWidth(880)
        reading.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        body = QtWidgets.QVBoxLayout(reading)
        body.setContentsMargins(0, 0, 0, 16)
        body.setSpacing(12)
        reading_row.addWidget(reading, 10)
        reading_row.addStretch(1)
        outer.addLayout(reading_row, 1)
        self.pages = QtWidgets.QStackedWidget()
        self.pages.addWidget(self.build_welcome())
        self.conversation = Conversation()
        self.conversation.setObjectName("conversation")
        self.conversation.setAccessibleName("Assistant conversation")
        self.conversation.setOpenExternalLinks(False)
        self.conversation.setOpenLinks(False)
        self.conversation.anchorClicked.connect(self.open_source)
        self.conversation.document().setDocumentMargin(16)
        # Inline chevrons use drawn icons so they render independently of fonts.
        for state, direction in (("collapsed", "right"), ("expanded", "down")):
            self.conversation.document().addResource(
                QtGui.QTextDocument.ImageResource, QtCore.QUrl(f"sakir-icon:activity-{state}"),
                icon(f"chevron-{direction}", "#697180").pixmap(24, 24).toImage())
        self.conversation.document().setDefaultStyleSheet(
            "body { color: #252a34; font-family: 'Segoe UI'; font-size: 11pt; }"
            "p { margin-top: 8px; margin-bottom: 12px; line-height: 150%; }"
            "pre { color: #33455e; white-space: pre-wrap; font-family: Consolas; margin: 0; }"
            "code { font-family: Consolas; color: #33455e; }"
            "a { color: #2563ad; text-decoration: none; }"
            "th, td { padding: 8px; } h1, h2, h3 { color: #202630; }"
        )
        self.pages.addWidget(self.conversation)
        body.addWidget(self.pages, 1)
        self.status = self.label(("Settings need repair: " + controller.settings_error) if controller.settings_error else "Ready", "status")
        self.status.setWordWrap(True)
        self.activity_footer = QtWidgets.QWidget()
        self.activity_footer.setObjectName("chatActivityFooter")
        status_row = QtWidgets.QHBoxLayout(self.activity_footer)
        status_row.setContentsMargins(0, 0, 0, 0)
        status_row.setSpacing(8)
        status_row.setAlignment(QtCore.Qt.AlignLeft)
        self.working_indicator = WorkingIndicator()
        status_row.addWidget(self.working_indicator)
        status_row.addWidget(self.status, 1)
        self.status.setVisible(bool(controller.settings_error))
        self.activity_footer.setVisible(bool(controller.settings_error))
        body.addWidget(self.activity_footer)
        self.review_bar = QtWidgets.QFrame()
        self.review_bar.setObjectName("reviewBar")
        review_row = QtWidgets.QHBoxLayout(self.review_bar)
        self.review_label = self.label("Ready for your review", "muted")
        self.review_label.setMinimumWidth(0)
        self.review_label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        review_row.addWidget(self.review_label, 1)
        self.review_button = self.button("Review changes", self.review, "primary")
        self.action_button = self.button("Review action", self.review_action)
        self.data_button = self.button("Data preview", self.preview_data)
        for button in (self.review_button, self.action_button, self.data_button):
            review_row.addWidget(button)
        body.addWidget(self.review_bar)

        composer = QtWidgets.QFrame()
        composer.setObjectName("composer")
        composer_layout = QtWidgets.QVBoxLayout(composer)
        composer_layout.setContentsMargins(14, 12, 14, 10)
        composer_layout.setSpacing(8)
        self.attachments = QtWidgets.QListWidget()
        self.attachments.setObjectName("attachments")
        self.attachments.setMaximumHeight(70)
        self.attachments.setAccessibleName("Attached files")
        self.attachments.setToolTip("Double-click to remove an attachment.")
        self.attachments.itemDoubleClicked.connect(self.remove_attachment)
        composer_layout.addWidget(self.attachments)
        self.sync_attachments(sorted(map(str, controller.policy.attachments)))
        self.input = Composer()
        self.input.setObjectName("request")
        self.input.setAccessibleName("Assistant request")
        self.input.setPlaceholderText("Ask anything about your project, or describe a change…")
        self.input.setMinimumHeight(58)
        self.input.setMaximumHeight(150)
        self.input.send_requested.connect(self.send)
        self.input.textChanged.connect(self.resize_composer)
        self.resize_composer()
        composer_layout.addWidget(self.input)
        footer = QtWidgets.QHBoxLayout()
        attach = self.button("", self.attach, "", "attach")
        attach.setToolTip("Attach files")
        attach.setAccessibleName("Attach files")
        footer.addWidget(attach)
        self.intent = ComboBox()
        self.intent.addItems(["Explain / Inspect", "Create Changes"])
        self.intent.setAccessibleName("Assistant mode")
        self.intent.setToolTip("Create Changes stages edits for your review before applying.")
        footer.addWidget(self.intent)
        footer.addStretch(1)
        self.stop_button = self.button("Stop", controller.stop, "stop")
        footer.addWidget(self.stop_button)
        self.send_button = self.button("Send", self.send, "primary", "send")
        self.send_button.setIcon(icon("send", "#ffffff"))
        footer.addWidget(self.send_button)
        composer_layout.addLayout(footer)
        body.addWidget(composer)
        self.usage_indicator = UsageIndicator(self)
        self.usage_panel = self.usage_indicator.popup
        usage_layout = QtWidgets.QVBoxLayout(self.usage_panel)
        usage_layout.setContentsMargins(12, 8, 12, 8)
        usage_layout.setSpacing(4)
        usage_layout.setAlignment(QtCore.Qt.AlignTop)
        usage_title = self.label("USAGE", "eyebrow")
        usage_title.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        usage_layout.addWidget(usage_title)
        self.usage_scroll = QtWidgets.QScrollArea()
        self.usage_scroll.setObjectName("usageScroll")
        self.usage_scroll.setWidgetResizable(True)
        self.usage_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.usage_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.usage_scroll.setMinimumHeight(48)
        self.usage_scroll.setMaximumHeight(200)
        usage_layout.addWidget(self.usage_scroll)
        self.usage_status = self.label("Awaiting response", "muted")
        usage_layout.addWidget(self.usage_status)
        self.usage_values = {}
        self.configure_usage()
        self.context_indicator = UsageIndicator(self, kind="context")
        context_layout = QtWidgets.QVBoxLayout(self.context_indicator.popup)
        context_layout.setContentsMargins(12, 10, 12, 10)
        context_layout.setSpacing(8)
        context_layout.setAlignment(QtCore.Qt.AlignTop)
        context_title = self.label("CONTEXT WINDOW", "eyebrow")
        context_title.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        context_layout.addWidget(context_title)
        context_form = QtWidgets.QFormLayout()
        context_form.setContentsMargins(0, 0, 0, 0)
        context_form.setVerticalSpacing(4)
        context_form.setHorizontalSpacing(16)
        self.context_values = {}
        for key, title in (("input_tokens", "Input tokens"), ("capacity", "Model capacity"),
                           ("input_budget", "Input budget"), ("remaining", "Remaining input space"),
                           ("output_reserve", "Output reserve"), ("safety_margin", "Safety margin"),
                           ("completion_tokens", "Last response output"), ("compactions", "Compactions"),
                           ("counting", "Counting"), ("characters", "Input characters"),
                           ("character_budget", "Character budget"), ("status", "Status")):
            label = self.label("", "muted")
            label.setWordWrap(True)
            label.setMinimumWidth(0)
            label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            context_form.addRow(title, label)
            self.context_values[key] = label
        context_layout.addLayout(context_form)
        self.reset_context()
        info = QtWidgets.QHBoxLayout()
        self.context_label = self.label(controller.selection or "Current project", "context")
        self.context_label.setMinimumWidth(0)
        self.context_label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.context_label.setMaximumWidth(440)
        info.addWidget(self.context_label, 1)
        info.addWidget(self.usage_indicator)
        info.addWidget(self.context_indicator)
        hint = self.label("Enter to send · Shift+Enter for a new line", "muted")
        info.addWidget(hint)
        body.addLayout(info)
        controller.activity.connect(self.on_event)
        controller.busy_changed.connect(self.busy)
        controller.proposal_changed.connect(self.update_review)
        controller.action_changed.connect(self.update_review)
        controller.attachments_changed.connect(self.sync_attachments)
        self.refresh_sessions()
        self.busy(controller.busy)
        for sequence, callback in (("Ctrl+N", self.new), ("Ctrl+B", self.toggle_sidebar),
                                   ("Ctrl+L", self.input.setFocus)):
            shortcut = QtWidgets.QShortcut(QtGui.QKeySequence(sequence), self)
            shortcut.activated.connect(callback)
        self.paint_timer = QtCore.QTimer(self)
        self.paint_timer.setInterval(80)
        self.paint_timer.timeout.connect(self.flush_render)
        self.paint_timer.start()
        self._rendered = None
        self.render()

    @staticmethod
    def label(text, name):
        label = QtWidgets.QLabel(text)
        label.setObjectName(name)
        label.setTextFormat(QtCore.Qt.PlainText)
        return label

    @staticmethod
    def button(text, callback, name="", symbol=None):
        button = QtWidgets.QPushButton(text)
        button.setObjectName(name)
        button.setCursor(QtCore.Qt.PointingHandCursor)
        if symbol:
            button.setIcon(icon(symbol))
            button.setIconSize(QtCore.QSize(18, 18))
        button.clicked.connect(callback)
        return button

    def build_welcome(self):
        welcome = QtWidgets.QWidget()
        welcome.setObjectName("welcome")
        self.welcome = welcome
        layout = QtWidgets.QVBoxLayout(welcome)
        layout.setContentsMargins(12, 20, 12, 20)
        layout.setSpacing(14)
        layout.addStretch(2)
        layout.addWidget(self.label("YOUR PROJECT, WITH A LITTLE HELP", "eyebrow"))
        self.hero = self.label("What shall we build?", "hero")
        self.hero.setWordWrap(True)
        layout.addWidget(self.hero)
        subtitle = self.label("Explore your framework, work with data,\nor turn an idea into a reviewed change.", "subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        layout.addSpacing(20)
        suggestions = QtWidgets.QGridLayout()
        suggestions.setSpacing(10)
        self.suggestion_grid = suggestions
        self.suggestion_buttons = []
        prompts = (
            ("Explore the project", "Explain the structure of this project and its main capabilities.", 0),
            ("Build a feature", "Help me plan a new feature for this project. Ask what I would like to build.", 1),
            ("Inspect my data", "Help me inspect a data file. Ask which file I would like to attach.", 0),
            ("Understand callbacks", "Explain how callbacks work in this project, with source references.", 0),
        )
        for i, (title, prompt, mode) in enumerate(prompts):
            button = self.button(title + "  ↗", lambda checked=False, p=prompt, m=mode: self.use_prompt(p, m), "suggestion")
            button.setToolTip(prompt)
            button.setMinimumHeight(54)
            self.suggestion_buttons.append(button)
            suggestions.addWidget(button, i // 2, i % 2)
        layout.addLayout(suggestions)
        layout.addStretch(3)
        # The start screen remains usable in a short or narrow native window.
        scroll = QtWidgets.QScrollArea()
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setWidget(welcome)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        welcome.installEventFilter(self)
        return scroll

    def eventFilter(self, watched, event):
        if watched is getattr(self, "welcome", None) and event.type() == QtCore.QEvent.Resize:
            narrow = event.size().width() < 480
            columns = 1 if narrow else 2
            for i, button in enumerate(self.suggestion_buttons):
                self.suggestion_grid.removeWidget(button)
                self.suggestion_grid.addWidget(button, i // columns, i % columns)
            self.hero.setStyleSheet("font-size: " + ("22pt;" if narrow else "28pt;"))
        return super().eventFilter(watched, event)

    def use_prompt(self, prompt, mode):
        self.intent.setCurrentIndex(mode)
        self.input.setPlainText(prompt)
        self.input.setFocus()

    def resize_composer(self):
        line_height = self.input.fontMetrics().lineSpacing()
        lines = max(self.input.blockCount(), int(self.input.document().size().height()))
        self.input.setFixedHeight(min(150, max(58, lines * line_height + 16)))

    def toggle_sidebar(self):
        self._sidebar_preference = self.sidebar.isHidden()
        self.update_sidebar(self._sidebar_preference)

    def remember_sidebar_width(self, position, index):
        if index == 1 and not self._restoring_sidebar and not self.sidebar.isHidden():
            self._sidebar_width = self.splitter.sizes()[0]

    def update_sidebar(self, visible):
        self._restoring_sidebar = True
        try:
            self.sidebar.setMaximumWidth(min(480, max(220, self.width() - 520 - self.splitter.handleWidth())))
            self.sidebar.setVisible(visible)
            if visible:
                width = min(self._sidebar_width, self.sidebar.maximumWidth())
                self.splitter.setSizes([width, max(1, self.splitter.width() - width - self.splitter.handleWidth())])
        finally:
            self._restoring_sidebar = False

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "splitter") and self.splitter.count() == 2:
            self.update_sidebar(self._sidebar_preference and self.width() >= 900)
        if hasattr(self, "_rendered"):
            self._rendered = None
            self.render()

    def refresh_sessions(self):
        self._sessions = dict(self.controller.store.sessions())
        # Include the active conversation even when local history is disabled.
        if self.visible_messages:
            self._sessions[self.controller.session_id] = copy.deepcopy(self.visible_messages)
        self.session_list.clear()
        keys = list(self._sessions)
        if self.controller.session_id in keys:
            keys.remove(self.controller.session_id)
        keys.insert(0, self.controller.session_id)
        for key in keys:
            messages = self._sessions.get(key, [])
            title = next((m["content"] for m in messages if m["role"] == "user"), "New chat")
            title = " ".join(title.split())
            item = QtWidgets.QListWidgetItem(self.session_list)
            item.setText(self.session_list.fontMetrics().elidedText(title, QtCore.Qt.ElideRight, 186))
            item.setToolTip(title)
            item.setData(QtCore.Qt.UserRole, key)
            item.setData(QtCore.Qt.UserRole + 1, title)
            if key == self.controller.session_id:
                self.session_list.setCurrentItem(item)
        self.session_notice.setVisible(not self._sessions)
        self.filter_sessions(self.session_search.text())

    def filter_sessions(self, text):
        for i in range(self.session_list.count()):
            item = self.session_list.item(i)
            item.setHidden(text.casefold() not in item.data(QtCore.Qt.UserRole + 1).casefold())

    def load_session(self, item):
        key = item.data(QtCore.Qt.UserRole)
        if key == self.controller.session_id:
            return
        try:
            self.controller.new_session(copy.deepcopy(self._sessions[key]), key)
        except Exception as exc:
            self.refresh_sessions()
            show_error(self, exc)

    def update_review(self, *_):
        proposal, action = self.controller.proposal, self.controller.action
        self.review_button.setVisible(proposal is not None)
        self.review_button.setEnabled(proposal is not None and not self.controller.busy)
        self.action_button.setVisible(action is not None)
        self.action_button.setEnabled(action is not None and not self.controller.busy)
        self.data_button.setVisible(self.data_preview is not None)
        self.review_bar.setVisible(proposal is not None or action is not None or self.data_preview is not None)
        self.review_label.setText("Ready for your review" if proposal or action else "File inspected")

    def showEvent(self, event):
        super().showEvent(event)
        self.paint_timer.start()
        self.render()

    def hideEvent(self, event):
        self.paint_timer.stop()
        super().hideEvent(event)

    def render(self):
        self._render_pending = False
        fingerprint = repr(self.visible_messages) + self.streaming_text + repr(
            [(key, activity.entries if activity.expanded else None, activity.expanded,
              activity.finished_at, sum(item["kind"] == "tool" and item["status"] == "failed" for item in activity.entries))
             for key, activity in self.turn_activities.items()])
        if fingerprint == self._rendered:
            self.refresh_activity_titles()
            return
        self._rendered = fingerprint
        self.pages.setCurrentIndex(1 if self.visible_messages or self.streaming_text else 0)
        title = next((m["content"] for m in self.visible_messages if m["role"] == "user"), "New chat")
        title = " ".join(title.split())
        self.chat_title.setText(self.chat_title.fontMetrics().elidedText(title, QtCore.Qt.ElideRight, max(120, self.width() - 650)))
        self.chat_title.setToolTip(title)
        bar = self.conversation.verticalScrollBar()
        previous = bar.value()
        follow = bar.maximum() - previous <= 36
        parts = []
        message_cache = []
        for index, message in enumerate(self.visible_messages + ([{"role": "pending", "content": self.streaming_text}] if self.streaming_text else [])):
            key = (message["role"], message["content"])
            if message["role"] == "pending":
                formatted = message_html(*key)
            else:
                cached = self._message_cache[index] if index < len(self._message_cache) else None
                formatted = cached[1] if cached is not None and cached[0] == key else message_html(*key)
                message_cache.append((key, formatted))
            parts.append(formatted)
            if index in self.turn_activities:
                parts.append(self.turn_activities[index].render(index))
        self.conversation.setHtml("<html><body>" + "".join(parts) + "</body></html>")
        self._message_cache = message_cache
        self._activity_titles = {f"sakir-activity:{key}": activity.title for key, activity in self.turn_activities.items()}
        bar.setValue(bar.maximum() if follow else min(previous, bar.maximum()))

    def refresh_activity_titles(self):
        titles = {f"sakir-activity:{key}": activity.title for key, activity in self.turn_activities.items()}
        if titles != self._activity_titles:
            self.conversation.update_activity_titles(titles)
            self._activity_titles = titles

    def flush_render(self):
        if self._render_pending:
            started = time.perf_counter()
            self.render()
            # Leave time for input/Stop even when a very long chat costs more.
            self.paint_timer.setInterval(max(80, min(1000, round((time.perf_counter() - started) * 4000))))
        else:
            self.refresh_activity_titles()

    def open_source(self, url):
        if url.scheme() == "sakir-activity":
            if not url.host() and not url.query() and not url.fragment() and re.fullmatch(r"[0-9]{1,9}", url.path()):
                activity = self.turn_activities.get(int(url.path()))
                if activity is not None:
                    activity.expanded = not activity.expanded
                    self.render()
            return
        if url.scheme() == "sakir-help":
            try:
                if url.host() or url.query() or url.fragment() or not re.fullmatch(r"[\w.-]{1,100}", url.path()):
                    raise AssistantError("SECTION_NOT_FOUND", "Invalid handbook section link.")
                handbook = self.controller.index.handbook
                handbook.refresh()
                handbook.read(url.path())
                window = self.controller.window._open_help()
                if window is not None:
                    window.navigate_to(url.path())
            except Exception as exc:
                show_error(self, exc)
            return
        if url.scheme() != "sakir-source":
            return
        try:
            start = int(url.fragment().lstrip("L") or "1")
            revision = QtCore.QUrlQuery(url).queryItemValue("revision")
            if revision:
                task = self.controller.task_index
                if not re.fullmatch(r"[0-9a-f]{64}", revision) or task is None or task.cache.get(url.path(), {}).get("content_revision") != revision:
                    raise AssistantError("STALE_REFERENCE", "This source revision is no longer available in this session. Ask Assistant to inspect the current source again.")
                data = task.read(url.path(), start, 120)
            else:
                data = self.controller.index.read(url.path(), start, 120)
            dialog = QtWidgets.QDialog(self)
            dialog.setWindowTitle(data["path"] + ":" + str(start) + (" — " + data["state"] + " snapshot" if revision else ""))
            dialog.resize(950, 650)
            layout = QtWidgets.QVBoxLayout(dialog)
            source = QtWidgets.QPlainTextEdit()
            source.setReadOnly(True)
            source.setFont(QtGui.QFont("Consolas", 10))
            source.setPlainText(data["text"])
            layout.addWidget(source)
            dialog.exec_()
        except Exception as exc:
            show_error(self, exc)

    def configure_usage(self):
        self.usage_indicator.hide_timer.stop()
        self.usage_panel.hide()
        self.usage_values = {}
        content = QtWidgets.QWidget()
        content.setObjectName("usageContent")
        form = QtWidgets.QFormLayout(content)
        form.setContentsMargins(0, 0, 8, 0)
        form.setVerticalSpacing(4)
        form.setHorizontalSpacing(20)
        form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        for entry in self.controller.settings.usage_headers:
            name = QtWidgets.QLabel(entry["display_name"])
            name.setTextFormat(QtCore.Qt.PlainText)
            name.setWordWrap(True)
            name.setFixedWidth(200)
            name.setToolTip(entry["header"])
            value = QtWidgets.QLabel("Awaiting response")
            value.setTextFormat(QtCore.Qt.PlainText)
            value.setWordWrap(True)
            value.setMinimumWidth(0)
            value.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            value.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            value.setAccessibleName(entry["display_name"])
            value.setToolTip(entry["header"])
            form.addRow(name, value)
            self.usage_values[entry["header"].lower()] = value
        old = self.usage_scroll.takeWidget()
        if old is not None:
            old.deleteLater()
        self.usage_scroll.setWidget(content)
        self.usage_scroll.setFixedHeight(min(200, max(48, content.sizeHint().height() + 2)))
        self.usage_status.setText("Awaiting response")
        self.usage_indicator.setVisible(bool(self.usage_values))

    def reset_context(self):
        self.context_indicator.popup.hide()
        settings = self.controller.settings
        capacity = capacity_for(settings)
        self.update_context({"base_url": settings.base_url, "model": settings.model,
                             "capacity": capacity, "input_tokens": None, "estimated": True,
                             "input_budget": max(0, capacity - settings.max_tokens - settings.context_margin) if capacity else None,
                             "output_reserve": settings.max_tokens, "safety_margin": settings.context_margin,
                             "compactions": self.controller.context_state.get("compactions", 0),
                             "tokenizer": settings.tokenizer, "characters": 0,
                             "character_budget": settings.context_chars - min(settings.context_chars // 4, max(2000, settings.max_tokens * 4)),
                             "status": "Awaiting request"})

    def update_context(self, report):
        settings = self.controller.settings
        if (report.get("base_url"), report.get("model")) != (settings.base_url, settings.model):
            return
        used, capacity, budget = report.get("input_tokens"), report.get("capacity"), report.get("input_budget")
        fraction = used / capacity if used is not None and capacity else None
        estimated = report.get("estimated", True)
        caption = "Context" if fraction is None else f"Context {'~' if estimated else ''}{fraction:.0%}"
        self.context_indicator.set_meter(caption, fraction)
        values = {**report, "capacity": capacity if capacity else "Unknown — set in Settings",
                  "input_tokens": used if used is not None else "Awaiting request",
                  "input_budget": budget if budget is not None else "Unknown",
                  "remaining": max(0, budget - used) if budget is not None and used is not None else "Unknown",
                  "counting": ("Estimated (" + report.get("tokenizer", "estimate") + ")") if estimated else "Provider-reported (last request)"}
        for key, label in self.context_values.items():
            value = values.get(key)
            label.setText(f"{value:,}" if type(value) is int else str(value) if value is not None else "—")

    def on_event(self, kind, value):
        if kind == "user":
            self.visible_messages.append({"role": "user", "content": value})
            self._active_turn = len(self.visible_messages) - 1
            self.turn_activities[self._active_turn] = TurnActivity()
            self._message_id = None
            self.streaming_text = ""
            self.refresh_sessions()
        elif kind == "message_started":
            self._message_id = value["id"]
            self.streaming_text = ""
        elif kind == "text_delta":
            self.streaming_text += value
            self._render_pending = True
            return
        elif kind == "reasoning_delta":
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.text("reasoning", value, self._message_id)
                self._render_pending |= activity.expanded
            return
        elif kind == "message_completed":
            text = value.get("text", "")
            if value["phase"] == "commentary":
                activity = self.turn_activities.get(self._active_turn)
                if activity is not None:
                    activity.text("commentary", text, value["id"])
                self.streaming_text = ""
            else:
                self.streaming_text = text
            self._message_id = None
        elif kind in {"tool_started", "tool_completed"}:
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.tool(value, completed=kind == "tool_completed")
        elif kind == "finished":
            response = value.get("text", "") if isinstance(value, dict) else ""
            if response or self.streaming_text:
                self.visible_messages.append({"role": "assistant", "content": response or self.streaming_text})
            self.streaming_text = ""
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.finish()
            self._message_id = None
        elif kind in {"status", "error"}:
            self.status.setText(value)
            self.working_indicator.setToolTip(str(value))
            if kind == "error":
                self.context_values["status"].setText("Stopped" if "CANCELLED" in str(value) else "Request failed")
                activity = self.turn_activities.get(self._active_turn)
                if activity is not None:
                    activity.text("interrupted", self.streaming_text, self._message_id)
                    activity.finish()
                self.streaming_text = ""
                self._message_id = None
                self.visible_messages.append({"role": "error", "content": value})
        elif kind == "tool_result" and value["tool"] == "inspect_file" and value["result"].get("ok"):
            self.data_preview = value["result"]["data"]
            self.update_review()
        elif kind == "session":
            self.turn_activities.clear()
            self._active_turn = self._message_id = None
            self.reset_context()
            self.visible_messages = copy.deepcopy(value)
            self.streaming_text = ""
            self.data_preview = None
            self.input.clear()
            self.update_review()
            self.refresh_sessions()
            self.conversation.verticalScrollBar().setValue(0)
        elif kind == "selection":
            self.context_label.setText(value or "Current project")
            self.context_label.setToolTip(value or "Current project")
        elif kind == "coverage":
            self.context_label.setToolTip((self.controller.selection or "Current project") +
                f"\nKnowledge: {value['files']} files, {value['symbols']} symbols, {value['help_topics']} handbook topics" +
                "\nUnsaved overlays: " + (", ".join(value["unsaved_paths"]) or "none") +
                f"\nDiagnostics: {len(value['diagnostics'])}. Open Capabilities for details and refresh.")
        elif kind == "settings":
            self.configure_usage()
            self.reset_context()
            self.model.setText(value or "Configure a local model")
            self.status.setText("Ready")
            self.status.hide()
            self.activity_footer.setVisible(self.controller.busy)
            self.model.setToolTip(value or "Choose a model in Settings")
            self.refresh_sessions()
        elif kind == "usage_headers":
            settings = self.controller.settings
            if (value["base_url"], value["model"]) == (settings.base_url, settings.model):
                for header, label in self.usage_values.items():
                    received = value["values"].get(header)
                    label.setText("Not provided" if received is None else received)
                    label.setToolTip(header + ("\n" + received if received is not None else "\nNot provided in the last response"))
                self.usage_status.setText("Last response · " + QtCore.QDateTime.currentDateTime().toString("HH:mm:ss"))
        elif kind == "context":
            self.update_context(value)
        elif kind == "context_compacted":
            self.status.setText("Context compacted · continuing…")
        if kind == "status" and not self.controller.busy:
            self.refresh_sessions()
        if kind in {"user", "message_started", "message_completed", "tool_started", "tool_completed", "finished", "error", "session"}:
            self.render()

    def busy(self, value):
        self.working_indicator.set_running(value)
        self.activity_footer.setVisible(value or bool(self.controller.settings_error))
        self.status.setVisible(not value and bool(self.controller.settings_error))
        if value:
            self.status.setText("Starting…")
            self.working_indicator.setToolTip("Starting…")
        self.send_button.setEnabled(not value)
        self.stop_button.setEnabled(value)
        self.stop_button.setVisible(value)
        self.send_button.setVisible(not value)
        self.new_button.setEnabled(not value)
        self.session_list.setEnabled(not value)
        self.intent.setEnabled(not value)
        self.update_review()

    def send(self):
        if self.controller.busy:
            return
        text = self.input.toPlainText().strip()
        if not text:
            return
        try:
            self.controller.submit(text, self.intent.currentIndex() == 1)
            self.input.clear()
        except Exception as exc:
            show_error(self, exc)

    def settings(self):
        if self.controller.busy:
            show_error(self, "Stop the active task before changing the connection.")
            return
        SettingsDialog(self.controller, self).exec_()
        self.model.setText(self.controller.settings.model or "Configure a local model")
        self.refresh_sessions()

    def new(self):
        try:
            self.controller.new_session()
            self.input.setFocus()
        except Exception as exc:
            show_error(self, exc)

    def history(self):
        try:
            sessions = self.controller.store.sessions()
            labels = [str(i+1) + ". " + (messages[0].get("content", "Empty")[:70] if messages else "Empty") for i, (_, messages) in enumerate(sessions)]
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Conversation History", "Session", labels, 0, False)
            if ok:
                key, messages = sessions[labels.index(choice)]
                self.controller.new_session(messages, key)
        except Exception as exc:
            show_error(self, exc)

    def drafts(self):
        try:
            drafts = self.controller.drafts()
            labels = [str(i+1) + ". " + p.summary[:90] for i, p in enumerate(drafts)]
            if not labels:
                show_error(self, "No saved proposal drafts yet.")
                return
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Saved Proposal Drafts", "Draft (revalidated against the current project)", labels, 0, False)
            if ok:
                self.controller.load_draft(drafts[labels.index(choice)])
                self.review()
        except Exception as exc:
            show_error(self, exc)

    def attach(self):
        files, _ = QtWidgets.QFileDialog.getOpenFileNames(self, "Attach Data or Source", str(self.controller.policy.root / "externals"))
        for filename in files:
            try:
                path = self.controller.policy.attach(filename)
                if not self.attachments.findItems(path, QtCore.Qt.MatchExactly):
                    self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))
            except Exception as exc:
                show_error(self, exc)

    def remove_attachment(self, item):
        self.controller.policy.attachments.discard(Path(item.text()).resolve())
        self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))

    def sync_attachments(self, paths):
        self.attachments.clear()
        self.attachments.addItems(paths)
        self.attachments.setVisible(bool(paths))

    def capabilities(self):
        from .knowledge_ui import KnowledgeDialog
        KnowledgeDialog(self.controller, self).exec_()

    def review(self):
        try:
            ReviewDialog(self.controller, self).exec_()
        except Exception as exc:
            show_error(self, exc)

    def restore(self):
        try:
            self.controller.restore()
            self.review()
        except Exception as exc:
            show_error(self, exc)

    def review_action(self):
        action = copy.deepcopy(self.controller.action)
        if not action:
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Review Session Action")
        dialog.resize(600, 420)
        layout = QtWidgets.QVBoxLayout(dialog)
        text = QtWidgets.QPlainTextEdit()
        text.setReadOnly(True)
        text.setPlainText(json.dumps({k: v for k, v in action.items() if k not in {"runtime_revision", "generation"}}, ensure_ascii=False, indent=2)
                          + "\n\nThis action affects the existing connection/device. File restore cannot undo a transmission.")
        layout.addWidget(text)
        run_button = QtWidgets.QPushButton("Run Action")
        def run_action():
            try:
                self.controller.run_action(digest(action))
                dialog.accept()
            except Exception as exc:
                show_error(dialog, exc)
        run_button.clicked.connect(run_action)
        layout.addWidget(run_button)
        dialog.exec_()

    def preview_data(self):
        if self.data_preview is None:
            show_error(self, "Ask the assistant to inspect a file first.")
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Inspected Data Preview")
        dialog.resize(850, 600)
        layout = QtWidgets.QVBoxLayout(dialog)
        if "rows" in self.data_preview and "columns" in self.data_preview:
            columns, rows = self.data_preview["columns"], self.data_preview["rows"]
            table = QtWidgets.QTableWidget(len(rows), len(columns))
            table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            table.setHorizontalHeaderLabels(columns)
            for i, row in enumerate(rows):
                for j, value in enumerate(row[:len(columns)]):
                    table.setItem(i, j, QtWidgets.QTableWidgetItem(str(value)))
            layout.addWidget(table)
        else:
            text = QtWidgets.QPlainTextEdit()
            text.setReadOnly(True)
            text.setPlainText(json.dumps(self.data_preview, ensure_ascii=False, indent=2))
            layout.addWidget(text)
        dialog.exec_()
