"""Plain-language help shared by settings fields and their form labels."""

SETTING_HELP = {
    "base_url": "Address of your model server's OpenAI-compatible API. Include its API prefix, for example http://127.0.0.1:11434/v1. Do not append /chat/completions.",
    "model": "Exact model ID your server accepts, for example qwen3:4b. Use List models to discover IDs, or enter one manually.",
    "auth_mode": "Choose how this server authenticates requests. Local servers often need no key. Session keys stay in memory; environment variables and Windows Credential Manager provide other key sources.",
    "api_key": "Key supplied by your model provider. Used with Session key or saved to Windows Credential Manager. The key is never written to assistant.json.",
    "key_env": "Name of the environment variable containing your API key, such as SAKIR_ASSISTANT_API_KEY. Enter the variable's name here, not the key. Available with Environment variable authentication.",
    "credential_ref": "Name used to look up your key in Windows Credential Manager. A reference is generated when you save a new key. Available with Windows Credential Manager authentication.",
    "ca_bundle": "Optional path to a trusted CA certificate file in PEM format, for example for an internal HTTPS server. Leave empty to use normal certificate verification.",
    "streaming": "Show the model's answer as it arrives. Turn this off if your server supports tool calls only in complete responses. This does not enable token-usage reporting by itself.",
    "token_parameter": "Name of the output-limit field sent to your server. Choose max_tokens or max_completion_tokens according to the model/server's API requirements. This changes the field name, not the limit amount.",
    "timeout": "How many seconds a model connection or read may wait before timing out. Increase this for a slow local model. The separate task deadline limits the whole task.",
    "max_tokens": "Maximum tokens generated in each model reply, including reasoning where the model counts it. Tokens are small pieces of text. This amount is also reserved from the model's context; lowering it leaves more room for input.",
    "context_chars": "Local size guard for messages, project evidence, tool definitions and tool results, measured in characters. Some space is reserved for later output. The server's token capacity also applies when known; characters and tokens are different units.",
    "max_rounds": "Maximum model requests in one task, including context-summary requests. A task may need several requests to inspect data, call tools and answer. Raising this allows longer tasks.",
    "max_tool_calls": "Maximum assistant tool invocations in one task, such as reading a file or preparing a change. One model request can ask for several tools.",
    "task_timeout": "Maximum task duration in seconds, including model requests, tool work and compaction. The deadline is checked between operations and after model requests; a pending request also has its own timeout.",
    "file_timeout": "Maximum time in seconds allowed for one file-inspection worker. Increase this for slower spreadsheets or large data files. This does not change the model timeout.",
    "preview_rows": "Default number of rows sampled during file inspection. Smaller previews use less context; larger previews show the model more data. An individual inspection can request a different row limit.",
    "result_chars": "Maximum characters returned to the model by one tool. Larger results are shortened to a preview. Lower values save context but may omit details the model needs.",
    "context_tokens": "Total context capacity actually configured on your model server, including input and reserved output. Automatic / unknown uses advertised model-list metadata if available. If no capacity is known, the meter shows no percentage and the character guard remains active.",
    "context_margin": "Extra tokens kept free for differences between estimated counts and your server's chat formatting. Input budget = context capacity minus maximum output tokens minus this margin.",
    "compact_threshold": "Start summarizing older context when this percentage of the available input budget is reached. 80% leaves room before the limit. A lower value compacts earlier and may cause more summary requests. With unknown token capacity, the character budget is used.",
    "tokenizer": "How input tokens are estimated before a request. Estimate for any model needs no extra package. Choose cl100k_base or o200k_base only if it matches your model and tiktoken is installed. Server formatting can still make the final count differ.",
    "auto_compact": "Use your configured model server to summarize older conversation and completed tool exchanges before context fills. Recent conversation and the current request stay intact. Summaries can lose detail and count toward task limits and provider usage. The readable transcript is retained.",
    "stream_usage": "Ask streaming responses to include token-usage statistics using stream_options.include_usage. Enable only if your server supports it. Disable if the server rejects the option. Interrupted streams may not include final usage.",
    "save_history": "Save user messages, final answers and context summaries in this project's assistant data folder. Activity, tool logs and reasoning previews stay in memory. Turn off to keep new history in memory only. Previously saved history remains until deleted.",
    "history_sessions": "Maximum number of saved chats retained in this project. When a new chat is saved beyond this limit, the oldest saved chats and their context summaries are removed.",
    "models": "Models returned by List models. Selecting one fills the Model ID field and uses any advertised context-capacity metadata. You can also enter a Model ID manually.",
    "probe_status": "Results of the latest connection check. The tool test asks the model to call a harmless echo tool, consume its result and answer. These checks send requests to your configured server and may consume provider usage.",
    "data_folder": "Project-local folder for assistant settings, saved chats, context summaries, drafts and recovery data. It is excluded from baseline exports and frozen builds.",
}

TAB_HELP = (
    "Connection: server address, model selection, authentication and connection tests.",
    "Limits and compatibility: output limits, model/tool budgets, timeouts and file-preview sizes.",
    "History and permissions: local conversation storage, retained chats and assistant editing permissions.",
    "Usage headers: map provider HTTP response headers to names in the Usage hover card.",
    "Context: model capacity, token counting, output safety margin and automatic summarization.",
)

HEADER_HELP = (
    "HTTP response-header name to read, for example x-ratelimit-remaining-tokens. Matching is case-insensitive. This does not add a header to outgoing requests.",
    "Friendly label shown beside the received value in the Usage hover card, for example Tokens remaining. Values are displayed as received; no units or percentages are inferred.",
)
