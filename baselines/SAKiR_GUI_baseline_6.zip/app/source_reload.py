"""Transactional callback/external imports and editor-independent source watching."""

from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

from PyQt5 import QtCore


class CallbackImportTransaction:
    """Stage callback-owned imports and publish them only after runtime success."""

    def __init__(self, project_root: Path, callbacks_path: Path, changed_paths=()):
        self.project_root = project_root.resolve()
        self.callbacks_path = callbacks_path.resolve()
        self.externals_root = (self.project_root / "externals").resolve()
        self.changed_paths = tuple(Path(path).resolve() for path in changed_paths)
        self.previous: dict[str, object] = {}
        self.candidate: dict[str, object] = {}
        self._staged = False

    def _is_managed(self, name: str, module) -> bool:
        if name == "callbacks" or name == "externals" or name.startswith("externals."):
            return True
        filename = getattr(module, "__file__", "")
        if not filename:
            return False
        try:
            path = Path(filename).resolve()
        except OSError:
            return False
        return path == self.callbacks_path or path == self.externals_root or self.externals_root in path.parents

    def _managed_modules(self) -> dict[str, object]:
        return {
            name: module
            for name, module in tuple(sys.modules.items())
            if module is not None and self._is_managed(name, module)
        }

    def _clear_managed(self) -> None:
        for name, module in tuple(sys.modules.items()):
            if module is not None and self._is_managed(name, module):
                sys.modules.pop(name, None)

    def stage(self):
        from app.utils import load_callbacks

        for path in self.changed_paths:
            if path.suffix.lower() == ".py" and path.exists():
                compile(path.read_text(encoding="utf-8"), str(path), "exec")

        importlib.invalidate_caches()
        self.previous = self._managed_modules()
        self._clear_managed()
        try:
            callbacks = load_callbacks()
            self.candidate = self._managed_modules()
        except Exception:
            self._clear_managed()
            sys.modules.update(self.previous)
            raise
        self._clear_managed()
        sys.modules.update(self.previous)
        self._staged = True
        return callbacks

    def commit(self) -> None:
        if not self._staged:
            return
        self._clear_managed()
        sys.modules.update(self.candidate)
        self._staged = False

    def rollback(self) -> None:
        if not self._staged:
            return
        self._clear_managed()
        sys.modules.update(self.previous)
        self._staged = False


class SourceReloadWatcher(QtCore.QObject):
    """Watch callbacks and recursive externals, including atomic rename saves."""

    changed = QtCore.pyqtSignal(object)

    def __init__(self, project_root: Path, parent=None, debounce_ms: int = 500):
        super().__init__(parent)
        self.project_root = project_root.resolve()
        self.callbacks_path = self.project_root / "callbacks" / "callbacks.py"
        self.externals_root = self.project_root / "externals"
        self._snapshot = self._scan()
        self._pending: set[Path] = set()
        self._watcher = QtCore.QFileSystemWatcher(self)
        self._watcher.fileChanged.connect(self._filesystem_changed)
        self._watcher.directoryChanged.connect(self._filesystem_changed)
        self._debounce = QtCore.QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(debounce_ms)
        self._debounce.timeout.connect(self._emit_pending)
        self._poll = QtCore.QTimer(self)
        self._poll.setInterval(750)
        self._poll.timeout.connect(self._rescan)
        self._poll.start()
        self._refresh_watches()

    def _source_paths(self):
        if self.callbacks_path.exists():
            yield self.callbacks_path
        if self.externals_root.exists():
            yield from (
                path for path in self.externals_root.rglob("*.py")
                if "__pycache__" not in path.parts
            )

    def _scan(self) -> dict[Path, tuple[int, int]]:
        result = {}
        for path in self._source_paths():
            try:
                stat = path.stat()
                result[path.resolve()] = (stat.st_mtime_ns, stat.st_size)
            except OSError:
                continue
        return result

    def _refresh_watches(self) -> None:
        desired = {str(path) for path in self._source_paths()}
        desired.add(str(self.callbacks_path.parent))
        if self.externals_root.exists():
            desired.update(str(path) for path in (self.externals_root, *self.externals_root.rglob("*")) if path.is_dir())
        existing = set(self._watcher.files()) | set(self._watcher.directories())
        remove = list(existing - desired)
        add = [path for path in desired - existing if Path(path).exists()]
        if remove:
            self._watcher.removePaths(remove)
        if add:
            self._watcher.addPaths(add)

    def _filesystem_changed(self, _path: str) -> None:
        self._rescan()

    def _rescan(self) -> None:
        current = self._scan()
        changed = {
            path for path in set(self._snapshot) | set(current)
            if self._snapshot.get(path) != current.get(path)
        }
        self._snapshot = current
        if changed:
            self._pending.update(changed)
            self._debounce.start()
        self._refresh_watches()

    def _emit_pending(self) -> None:
        if not self._pending:
            return
        paths = tuple(sorted(self._pending, key=lambda path: os.path.normcase(str(path))))
        self._pending.clear()
        self.changed.emit(paths)
