"""Qt-aware orchestration for Globals declarations and lifecycle phases."""

from __future__ import annotations

import asyncio
import inspect
import threading
import traceback
from contextlib import nullcontext
from typing import Any, Callable, Dict, Iterable, Mapping

from PyQt5 import QtCore

from app.global_store import AppGlobals, GlobalRegistry
from app.globals_api import (
    AppGlobalDefinitionError,
    AsyncLazy,
    GlobalSpec,
    GlobalsBase,
    ReloadPolicy,
    _looks_like_widgetish,
    _normalize_declaration,
)
from app.lifecycle import HookRecord, LifecycleManager, LifecycleRegistration


class _AsyncCallWorker(QtCore.QThread):
    """Run one callable/awaitable on a cancellable worker-owned event loop."""

    completed = QtCore.pyqtSignal(int, object)
    failed = QtCore.pyqtSignal(int, str)
    cancelled = QtCore.pyqtSignal(int)

    def __init__(
        self,
        generation: int,
        producer: Callable[[], Any],
        *,
        cancel_on_generation: bool = True,
    ):
        super().__init__()
        self.generation = int(generation)
        self._producer = producer
        self.cancel_on_generation = bool(cancel_on_generation)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._task: asyncio.Task | None = None
        self._guard = threading.RLock()

    async def _run_value(self) -> Any:
        value = self._producer()
        return await value if inspect.isawaitable(value) else value

    def run(self) -> None:
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            with self._guard:
                self._loop = loop
            task = loop.create_task(self._run_value())
            with self._guard:
                self._task = task
            result = loop.run_until_complete(task)
            self.completed.emit(self.generation, result)
        except asyncio.CancelledError:
            self.cancelled.emit(self.generation)
        except Exception:
            self.failed.emit(self.generation, traceback.format_exc())
        finally:
            with self._guard:
                loop = self._loop
                self._loop = None
                self._task = None
            if loop is not None:
                try:
                    pending = asyncio.all_tasks(loop)
                    for task in pending:
                        task.cancel()
                    if pending:
                        loop.run_until_complete(
                            asyncio.gather(*pending, return_exceptions=True)
                        )
                finally:
                    loop.close()

    def request_cancel(self) -> None:
        self.requestInterruption()
        with self._guard:
            loop = self._loop
            task = self._task
        if loop is not None and task is not None and not task.done():
            loop.call_soon_threadsafe(task.cancel)


class _AsyncGlobalsWorker(QtCore.QThread):
    """Resolve async declarations sequentially for one runtime generation."""

    completed = QtCore.pyqtSignal(int, dict)
    failed_with_results = QtCore.pyqtSignal(int, str, dict)
    cancelled = QtCore.pyqtSignal(int)

    def __init__(self, pending_async: Mapping[str, Any], generation: int = 0):
        super().__init__()
        self._pending_async = dict(pending_async)
        self.generation = int(generation)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._task: asyncio.Task | None = None
        self._guard = threading.RLock()
        self._partial_results: Dict[str, Any] = {}
        self._staging_registry: GlobalRegistry | None = None
        self._staging_values: Dict[str, Any] | None = None

    def set_staging_registry(
        self, registry: GlobalRegistry, values: Dict[str, Any]
    ) -> None:
        self._staging_registry = registry
        self._staging_values = values

    async def _runner(self) -> Dict[str, Any]:
        results: Dict[str, Any] = {}
        for name, declaration in self._pending_async.items():
            if self.isInterruptionRequested():
                raise asyncio.CancelledError
            spec = (
                _normalize_declaration(declaration)
                if isinstance(declaration, AsyncLazy) else declaration
            )
            factory = getattr(spec, "factory", None)
            if not callable(factory):
                raise TypeError(f"Async global {name!r} has no callable factory")
            try:
                produced = factory()
                if inspect.isawaitable(produced):
                    timeout = getattr(spec, "timeout", None)
                    produced = (
                        await asyncio.wait_for(produced, timeout)
                        if timeout is not None else await produced
                    )
                if _looks_like_widgetish(produced):
                    raise RuntimeError(
                        "returned a Qt object or Qt-backed wrapper; use lazy(...) "
                        "for main-thread resources"
                    )
                results[name] = produced
                self._partial_results[name] = produced
            except asyncio.CancelledError:
                raise
            except Exception as error:
                label = f" ({spec.label})" if getattr(spec, "label", "") else ""
                raise RuntimeError(
                    f"Async global {name!r}{label} failed during worker "
                    f"initialization: {error}"
                ) from error
        return results

    async def _dispose_partial_results(self) -> None:
        for name, value in reversed(list(self._partial_results.items())):
            declaration = self._pending_async.get(name)
            spec = (
                _normalize_declaration(declaration)
                if isinstance(declaration, AsyncLazy) else declaration
            )
            disposer = getattr(spec, "dispose", None)
            if not callable(disposer):
                continue
            try:
                result = disposer(value)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                pass

    def run(self) -> None:
        loop = None
        try:
            loop = asyncio.new_event_loop()
            with self._guard:
                self._loop = loop
            asyncio.set_event_loop(loop)
            task = loop.create_task(self._runner())
            with self._guard:
                self._task = task
            scope = (
                self._staging_registry._staging_scope(self._staging_values)
                if self._staging_registry is not None
                and self._staging_values is not None
                else nullcontext()
            )
            with scope:
                results = loop.run_until_complete(task)
            self.completed.emit(self.generation, results)
        except asyncio.CancelledError:
            if loop is not None:
                try:
                    loop.run_until_complete(self._dispose_partial_results())
                except Exception:
                    pass
            self.cancelled.emit(self.generation)
        except Exception:
            self.failed_with_results.emit(
                self.generation, traceback.format_exc(), dict(self._partial_results)
            )
        finally:
            with self._guard:
                loop = self._loop
                self._task = None
                self._loop = None
            if loop is not None:
                try:
                    pending = asyncio.all_tasks(loop)
                    for pending_task in pending:
                        pending_task.cancel()
                    if pending:
                        loop.run_until_complete(
                            asyncio.gather(*pending, return_exceptions=True)
                        )
                finally:
                    loop.close()

    def request_cancel(self) -> None:
        self.requestInterruption()
        with self._guard:
            loop = self._loop
            task = self._task
        if loop is not None and task is not None and not task.done():
            loop.call_soon_threadsafe(task.cancel)


class GlobalRuntimeCoordinator(QtCore.QObject):
    """Own initialization generations, workers, reload policy, and disposal."""

    ready = QtCore.pyqtSignal(int)
    initialization_failed = QtCore.pyqtSignal(int, str)
    initialization_warning = QtCore.pyqtSignal(int, str)
    state_changed = QtCore.pyqtSignal(str, int)
    reload_finished = QtCore.pyqtSignal(int, bool)

    def __init__(
        self,
        parent=None,
        *,
        registry: GlobalRegistry = AppGlobals,
        lifecycle=LifecycleManager,
    ):
        super().__init__(parent)
        self.registry = registry
        self.lifecycle = lifecycle
        self.generation = registry.generation
        self.current_callbacks = None
        self.current_globals_class = None
        self.current_globals_object = None
        self._workers: set[QtCore.QThread] = set()
        self._after_workers_cancelled: Callable[[], None] | None = None
        self._operation: Dict[str, Any] | None = None
        self._shutdown_callback: Callable[[], None] | None = None

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------
    def begin_initialization(
        self,
        callbacks,
        *,
        window,
        build_ui: Callable[[], None],
        inject_helpers: Callable[[Any], None],
    ) -> int:
        return self._begin_operation(
            callbacks,
            window=window,
            build_ui=build_ui,
            inject_helpers=inject_helpers,
            is_reload=False,
        )

    def begin_reload(
        self,
        callbacks,
        *,
        window,
        inject_helpers: Callable[[Any], None],
        rebuild_ui: Callable[[], None] | None = None,
    ) -> int:
        return self._begin_operation(
            callbacks,
            window=window,
            build_ui=rebuild_ui,
            inject_helpers=inject_helpers,
            is_reload=True,
        )

    def begin_shutdown(self, window, on_finished: Callable[[], None] | None = None) -> None:
        if self._operation is not None and not self._operation.get("committed", False):
            self._rollback_uncommitted(self._operation)
            self._operation = None
        self.generation += 1
        generation = self.generation
        self._shutdown_callback = on_finished

        def start() -> None:
            self._set_state("DISPOSING", generation)
            self._run_hooks(
                self.lifecycle.records("close"),
                (window,),
                generation,
                lambda: self._dispose_all_for_shutdown(generation),
                lambda details: self._shutdown_hook_failed(generation, details),
            )

        self._cancel_workers_then(start, cancel_all=True)

    def _cancel_active_generation(self) -> None:
        if self._operation is not None and not self._operation.get("committed", False):
            self._rollback_uncommitted(self._operation)
            self._operation = None
        self.generation += 1
        self._cancel_workers_then(lambda: None)

    # ------------------------------------------------------------------
    # Generation setup and validation
    # ------------------------------------------------------------------
    def _begin_operation(
        self,
        callbacks,
        *,
        window,
        build_ui,
        inject_helpers,
        is_reload: bool,
    ) -> int:
        active_operation = self._operation
        if active_operation is not None and not active_operation.get("committed", False):
            self._rollback_uncommitted(active_operation)
            self._operation = None
        previous_generation = self.registry.generation
        previous_state = self.registry.state
        self.generation = max(self.generation, previous_generation) + 1
        generation = self.generation
        self.registry._set_runtime_state(
            "RELOADING" if is_reload else "DECLARED", generation=generation
        )

        def start() -> None:
            self._start_operation(
                callbacks,
                window=window,
                build_ui=build_ui,
                inject_helpers=inject_helpers,
                is_reload=is_reload,
                generation=generation,
                previous_generation=previous_generation,
                previous_state=previous_state,
            )

        self._cancel_workers_then(start)
        return generation

    def _start_operation(
        self,
        callbacks,
        *,
        window,
        build_ui,
        inject_helpers,
        is_reload: bool,
        generation: int,
        previous_generation: int,
        previous_state: str,
    ) -> None:
        if generation != self.generation:
            return
        old_values = self.registry.snapshot()
        old_specs = self.registry._spec_snapshot()
        old_generation = previous_generation
        old_state = previous_state
        try:
            globals_class = getattr(callbacks, "Globals", None)
            if not (
                isinstance(globals_class, type)
                and issubclass(globals_class, GlobalsBase)
                and globals_class is not GlobalsBase
            ):
                raise AppGlobalDefinitionError(
                    "callbacks.py must define class Globals(GlobalsBase)."
                )
            globals_object = globals_class()
            init = getattr(globals_object, "init_globals", None)
            if not callable(init):
                raise AppGlobalDefinitionError("Globals.init_globals must be callable.")
            if inspect.iscoroutinefunction(init):
                raise AppGlobalDefinitionError(
                    "Globals.init_globals must be synchronous because it runs in the Qt "
                    "main thread. Move I/O into async_global(...)."
                )
            specs = globals_class.definitions()
            registration = getattr(callbacks, "__lifecycle_registration__", None)
            if not isinstance(registration, LifecycleRegistration):
                registration = self.lifecycle.registration_scope(
                    "callbacks"
                )
        except Exception:
            self._fail_without_operation(generation, traceback.format_exc(), is_reload)
            return

        candidate_values = dict(old_values)
        for removed_name in set(old_specs) - set(specs):
            candidate_values.pop(removed_name, None)

        operation = {
            "generation": generation,
            "is_reload": is_reload,
            "callbacks": callbacks,
            "globals_class": globals_class,
            "globals_object": globals_object,
            "init": init,
            "specs": specs,
            "registration": registration,
            "window": window,
            "build_ui": build_ui,
            "inject_helpers": inject_helpers,
            "old_values": old_values,
            "old_specs": old_specs,
            "old_generation": old_generation,
            "old_state": old_state,
            "staged": candidate_values,
            "candidate_visible": not is_reload,
            "warnings": [],
            "committed": False,
        }
        self._operation = operation
        self._set_state("INITIALIZING_EARLY", generation)

        for name, spec in specs.items():
            if self._preserve_existing(operation, name, spec):
                continue
            if spec.kind == "plain":
                operation["staged"][name] = spec.value
            else:
                operation["staged"].pop(name, None)

        if is_reload:
            records = self.lifecycle.records("unload")
            on_hooks_done = lambda: self._publish_early_after_unload(operation)
        else:
            # Initial startup hooks intentionally see plain declarations.
            records = registration.for_stage("startup")
            on_hooks_done = lambda: self._capture_startup_plain_values(operation)
        self._set_state("RELOADING" if is_reload else "STARTUP", generation)
        self._run_hooks(
            records,
            (window,),
            generation,
            on_hooks_done,
            lambda details: self._fail_operation(operation, details, precommit=True),
        )

    def _capture_startup_plain_values(self, operation: Dict[str, Any]) -> None:
        """Retain declared-value mutations performed by startup hooks."""
        if not self._is_current(operation):
            return
        self._after_early_hooks(operation)

    @staticmethod
    def _preserve_existing(operation: Mapping[str, Any], name: str, spec: GlobalSpec) -> bool:
        old_spec = operation["old_specs"].get(name)
        return (
            operation["is_reload"]
            and spec.reload is ReloadPolicy.PRESERVE
            and old_spec is not None
            and old_spec.kind == spec.kind
            and name in operation["old_values"]
        )

    # ------------------------------------------------------------------
    # UI, lazy, and async resource phases
    # ------------------------------------------------------------------
    def _publish_early_after_unload(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        operation["candidate_visible"] = True
        old_specs = operation["old_specs"]
        old_values = operation["old_values"]
        for name, old_spec in old_specs.items():
            if old_spec.kind != "lazy" or name not in old_values:
                continue
            new_spec = operation["specs"].get(name)
            preserved = new_spec is not None and self._preserve_existing(
                operation, name, new_spec
            )
            if not preserved and isinstance(old_values[name], QtCore.QObject):
                try:
                    if old_values[name].parent() is not None:
                        old_values[name].setParent(None)
                except RuntimeError:
                    pass
        self._after_early_hooks(operation)

    def _after_early_hooks(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        try:
            build_ui = operation["build_ui"]
            with self.registry._staging_scope(operation["staged"]):
                if callable(build_ui):
                    self._set_state("UI_BUILD", operation["generation"])
                    build_ui()
                operation["inject_helpers"](operation["callbacks"])
                self._set_state("INITIALIZING_RESOURCES", operation["generation"])
                for name, spec in operation["specs"].items():
                    if spec.kind != "lazy" or self._preserve_existing(operation, name, spec):
                        continue
                    try:
                        value = spec.factory()
                        if inspect.isawaitable(value):
                            try:
                                value.close()
                            except Exception:
                                pass
                            raise TypeError(
                                "lazy() returned an awaitable; use async_global(...)"
                            )
                    except Exception as error:
                        label = f" ({spec.label})" if spec.label else ""
                        raise RuntimeError(
                            f"Lazy global {name!r}{label} failed: {error}"
                        ) from error
                    operation["staged"][name] = value
        except Exception:
            self._fail_operation(operation, traceback.format_exc(), precommit=True)
            return

        pending_async = {
            name: spec
            for name, spec in operation["specs"].items()
            if spec.kind == "async" and not self._preserve_existing(operation, name, spec)
        }
        if not pending_async:
            self._commit_operation(operation)
            return

        worker = _AsyncGlobalsWorker(pending_async, operation["generation"])
        worker.set_staging_registry(self.registry, operation["staged"])
        worker.completed.connect(
            lambda generation, results: self._async_globals_ready(
                operation, generation, results
            )
        )
        worker.failed_with_results.connect(
            lambda generation, details, partial: self._async_globals_failed(
                operation, generation, details, partial
            )
        )
        worker.cancelled.connect(lambda generation: None)
        self._track_worker(worker)
        worker.start()

    def _async_globals_ready(
        self, operation: Dict[str, Any], generation: int, results: Dict[str, Any]
    ) -> None:
        if generation != self.generation or not self._is_current(operation):
            self._dispose_stale_async_results(operation, results)
            return
        operation["staged"].update(results)
        self._commit_operation(operation)

    def _async_globals_failed(
        self,
        operation: Dict[str, Any],
        generation: int,
        details: str,
        partial: Dict[str, Any],
    ) -> None:
        if generation != self.generation or not self._is_current(operation):
            return
        operation["staged"].update(partial)
        self._fail_operation(operation, details, precommit=True)

    def _dispose_stale_async_results(
        self, operation: Mapping[str, Any], results: Mapping[str, Any]
    ) -> None:
        """Best-effort cleanup for a cancelled factory that suppressed cancellation."""
        for name, value in results.items():
            spec = operation["specs"].get(name)
            disposer = getattr(spec, "dispose", None)
            if not callable(disposer):
                continue
            try:
                if inspect.iscoroutinefunction(disposer):
                    worker = _AsyncCallWorker(
                        self.generation,
                        lambda disposer=disposer, value=value: disposer(value),
                    )
                    worker.completed.connect(lambda generation, result: None)
                    worker.failed.connect(
                        lambda generation, details, name=name: self.initialization_warning.emit(
                            generation,
                            f"Stale disposer for {name!r} failed:\n{details}",
                        )
                    )
                    self._track_worker(worker)
                    worker.start()
                    continue
                result = disposer(value)
                if inspect.isawaitable(result):
                    worker = _AsyncCallWorker(
                        self.generation, lambda result=result: result
                    )
                    worker.completed.connect(lambda generation, value: None)
                    worker.failed.connect(
                        lambda generation, details, name=name: self.initialization_warning.emit(
                            generation,
                            f"Stale disposer for {name!r} failed:\n{details}",
                        )
                    )
                    self._track_worker(worker)
                    worker.start()
            except Exception:
                self.initialization_warning.emit(
                    self.generation,
                    f"Stale disposer for {name!r} failed:\n{traceback.format_exc()}",
                )

    # ------------------------------------------------------------------
    # Commit, disposal, init hook, and ready
    # ------------------------------------------------------------------
    def _commit_operation(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        specs = operation["specs"]
        old_specs = operation["old_specs"]
        old_values = operation["old_values"]
        removals = set(old_specs) - set(specs)
        replaced = {
            name for name in specs
            if (
                name in old_specs
                and name in old_values
                and operation["staged"].get(name, object()) is not old_values[name]
            )
        }
        self.registry._commit_generation(
            specs=specs,
            values=operation["staged"],
            generation=operation["generation"],
        )
        operation["registration"].commit()
        operation["committed"] = True
        operation["disposals"] = [
            (name, old_values[name], old_specs[name])
            for name in sorted(removals | replaced)
            if name in old_values
        ]
        self.current_callbacks = operation["callbacks"]
        self.current_globals_class = operation["globals_class"]
        self.current_globals_object = operation["globals_object"]
        self._dispose_entries(
            operation["disposals"],
            operation["generation"],
            lambda: self._run_init_hook(operation),
            operation["warnings"],
        )

    def _run_init_hook(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        self._set_state("INIT_UI", operation["generation"])
        try:
            result = operation["init"]()
            if inspect.isawaitable(result):
                try:
                    result.close()
                except Exception:
                    pass
                raise AppGlobalDefinitionError(
                    "Globals.init_globals returned an awaitable. It must be synchronous; "
                    "use async_global(...) for asynchronous initialization."
                )
        except Exception:
            self._fail_operation(operation, traceback.format_exc(), precommit=False)
            return

        records = (
            operation["registration"].for_stage("reload")
            if operation["is_reload"] else []
        )
        self._run_hooks(
            records,
            (operation["window"],),
            operation["generation"],
            lambda: self._mark_ready(operation),
            lambda details: self._fail_operation(operation, details, precommit=False),
        )

    def _mark_ready(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        generation = operation["generation"]
        self._set_state("READY", generation)
        if operation["warnings"]:
            self.initialization_warning.emit(
                generation, "\n\n".join(operation["warnings"])
            )
        self._operation = None
        self.ready.emit(generation)
        if operation["is_reload"]:
            self.reload_finished.emit(generation, True)

    # ------------------------------------------------------------------
    # Lifecycle hook runner
    # ------------------------------------------------------------------
    def _run_hooks(
        self,
        records: list[HookRecord],
        args: tuple[Any, ...],
        generation: int,
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        records = list(records)

        def advance(index: int) -> None:
            if generation != self.generation:
                return
            if index >= len(records):
                on_done()
                return
            record = records[index]
            try:
                operation = self._operation
                use_candidate = (
                    operation is not None
                    and operation.get("generation") == generation
                    and not operation.get("committed", False)
                    and operation.get("candidate_visible", False)
                )
                scope = (
                    self.registry._staging_scope(operation["staged"])
                    if use_candidate else nullcontext()
                )
                if inspect.iscoroutinefunction(record.callback):
                    self._start_async_call(
                        generation,
                        lambda record=record: self.lifecycle.invoke(record, *args),
                        lambda _result: advance(index + 1),
                        on_error,
                    )
                    return
                with scope:
                    result = self.lifecycle.invoke(record, *args)
                if inspect.isawaitable(result):
                    self._start_async_call(
                        generation,
                        lambda result=result: result,
                        lambda _result: advance(index + 1),
                        on_error,
                    )
                    return
            except Exception:
                on_error(traceback.format_exc())
                return
            advance(index + 1)

        advance(0)

    def _start_async_call(
        self,
        generation: int,
        producer: Callable[[], Any],
        on_result: Callable[[Any], None],
        on_error: Callable[[str], None],
    ) -> None:
        operation = self._operation
        if (
            operation is not None
            and operation.get("generation") == generation
            and not operation.get("committed", False)
            and operation.get("candidate_visible", False)
        ):
            staged = operation["staged"]
            original_producer = producer

            async def producer():
                with self.registry._staging_scope(staged):
                    value = original_producer()
                    return await value if inspect.isawaitable(value) else value

        worker = _AsyncCallWorker(generation, producer)
        worker.completed.connect(
            lambda worker_generation, result: (
                on_result(result) if worker_generation == self.generation else None
            )
        )
        worker.failed.connect(
            lambda worker_generation, details: (
                on_error(details) if worker_generation == self.generation else None
            )
        )
        worker.cancelled.connect(lambda worker_generation: None)
        self._track_worker(worker)
        worker.start()

    # ------------------------------------------------------------------
    # Resource disposal
    # ------------------------------------------------------------------
    def _dispose_entries(
        self,
        entries: Iterable[tuple[str, Any, GlobalSpec]],
        generation: int,
        on_done: Callable[[], None],
        warnings: list[str],
    ) -> None:
        entries = list(entries)

        def advance(index: int) -> None:
            if generation != self.generation:
                return
            if index >= len(entries):
                on_done()
                return
            name, value, spec = entries[index]
            disposer = spec.dispose
            if disposer is None:
                if isinstance(value, QtCore.QObject):
                    try:
                        value.deleteLater()
                    except RuntimeError:
                        pass
                advance(index + 1)
                return
            try:
                if isinstance(value, QtCore.QObject):
                    result = disposer(value)
                    if inspect.isawaitable(result):
                        try:
                            result.close()
                        except Exception:
                            pass
                        raise RuntimeError(
                            "Qt-owned resources require a synchronous main-thread disposer."
                        )
                    advance(index + 1)
                    return
                if inspect.iscoroutinefunction(disposer):
                    self._start_async_call(
                        generation,
                        lambda disposer=disposer, value=value: disposer(value),
                        lambda _result: advance(index + 1),
                        lambda details, name=name: (
                            warnings.append(f"Disposer for {name!r} failed:\n{details}"),
                            advance(index + 1),
                        )[-1],
                    )
                    return
                result = disposer(value)
                if inspect.isawaitable(result):
                    self._start_async_call(
                        generation,
                        lambda result=result: result,
                        lambda _result: advance(index + 1),
                        lambda details, name=name: (
                            warnings.append(f"Disposer for {name!r} failed:\n{details}"),
                            advance(index + 1),
                        )[-1],
                    )
                    return
            except Exception:
                warnings.append(
                    f"Disposer for {name!r} failed:\n{traceback.format_exc()}"
                )
            advance(index + 1)

        advance(0)

    def _dispose_all_for_shutdown(self, generation: int) -> None:
        specs = self.registry._spec_snapshot()
        values = self.registry._owned_snapshot()
        entries = [
            (name, values[name], spec)
            for name, spec in specs.items()
            if name in values
        ]
        warnings: list[str] = []
        self._dispose_entries(
            entries,
            generation,
            lambda: self._finish_shutdown(generation, warnings),
            warnings,
        )

    def _finish_shutdown(self, generation: int, warnings: list[str]) -> None:
        if generation != self.generation:
            return
        if warnings:
            self.initialization_warning.emit(generation, "\n\n".join(warnings))
        self.registry.clear()
        self._set_state("CLOSED", generation)
        callback = self._shutdown_callback
        self._shutdown_callback = None
        if callback is not None:
            callback()

    def _shutdown_hook_failed(self, generation: int, details: str) -> None:
        if generation != self.generation:
            return
        self.initialization_warning.emit(
            generation, f"Close lifecycle hook failed:\n{details}"
        )
        self._dispose_all_for_shutdown(generation)

    # ------------------------------------------------------------------
    # Failure, state, and worker ownership
    # ------------------------------------------------------------------
    def _fail_without_operation(
        self, generation: int, details: str, is_reload: bool
    ) -> None:
        if generation != self.generation:
            return
        self._operation = None
        state = "READY" if is_reload and self.current_callbacks is not None else "FAILED"
        self.registry._set_runtime_state(
            state, generation=generation, error=details
        )
        self.state_changed.emit(state, generation)
        self.initialization_failed.emit(generation, details)
        if is_reload:
            self.reload_finished.emit(generation, False)

    def _fail_operation(
        self, operation: Dict[str, Any], details: str, *, precommit: bool
    ) -> None:
        if not self._is_current(operation):
            return
        generation = operation["generation"]
        if precommit:
            self._rollback_uncommitted(operation)
            if not operation["is_reload"]:
                self.registry._set_runtime_state(
                    "FAILED", generation=generation, error=details
                )
            else:
                self.registry._set_runtime_state(
                    operation["old_state"],
                    generation=operation["old_generation"],
                    error=details,
                )
        else:
            self.registry._set_runtime_state(
                "FAILED", generation=generation, error=details
            )
        self._operation = None
        self.state_changed.emit(
            self.registry.state, self.registry.generation
        )
        self.initialization_failed.emit(generation, details)
        if operation["is_reload"]:
            self.reload_finished.emit(generation, False)

    def _set_state(self, state: str, generation: int) -> None:
        if generation != self.generation:
            return
        self.registry._set_runtime_state(state, generation=generation)
        self.state_changed.emit(state, generation)

    def _is_current(self, operation: Mapping[str, Any]) -> bool:
        return (
            self._operation is operation
            and operation["generation"] == self.generation
        )

    def _rollback_uncommitted(self, operation: Mapping[str, Any]) -> None:
        """Restore a staged generation and release resources it already created."""
        self.registry._restore_generation(
            values=operation["old_values"],
            specs=operation["old_specs"],
            generation=operation["old_generation"],
            state=operation["old_state"],
        )
        old_values = operation["old_values"]
        specs = operation["specs"]
        for name, value in operation["staged"].items():
            if old_values.get(name, object()) is value:
                continue
            spec = specs.get(name)
            disposer = getattr(spec, "dispose", None)
            try:
                if disposer is not None and inspect.iscoroutinefunction(disposer):
                    worker = _AsyncCallWorker(
                        operation["generation"],
                        lambda disposer=disposer, value=value: disposer(value),
                        cancel_on_generation=False,
                    )
                    worker.failed.connect(
                        lambda _generation, details, name=name: self.initialization_warning.emit(
                            self.generation,
                            f"Staged disposer for {name!r} failed:\n{details}",
                        )
                    )
                    self._track_worker(worker)
                    worker.start()
                elif disposer is not None:
                    result = disposer(value)
                    if inspect.isawaitable(result):
                        worker = _AsyncCallWorker(
                            operation["generation"],
                            lambda result=result: result,
                            cancel_on_generation=False,
                        )
                        worker.failed.connect(
                            lambda _generation, details, name=name: self.initialization_warning.emit(
                                self.generation,
                                f"Staged disposer for {name!r} failed:\n{details}",
                            )
                        )
                        self._track_worker(worker)
                        worker.start()
                elif disposer is None and isinstance(value, QtCore.QObject):
                    value.deleteLater()
            except Exception:
                self.initialization_warning.emit(
                    operation["generation"],
                    f"Staged disposer for {name!r} failed:\n{traceback.format_exc()}",
                )

    def _track_worker(self, worker: QtCore.QThread) -> None:
        self._workers.add(worker)

        def cleanup() -> None:
            self._workers.discard(worker)
            worker.deleteLater()
            if not self._workers and self._after_workers_cancelled is not None:
                callback = self._after_workers_cancelled
                self._after_workers_cancelled = None
                QtCore.QTimer.singleShot(0, callback)

        worker.finished.connect(cleanup)

    def _cancel_workers_then(
        self,
        callback: Callable[[], None],
        *,
        cancel_all: bool = False,
    ) -> None:
        active = [worker for worker in self._workers if worker.isRunning()]
        if not active:
            QtCore.QTimer.singleShot(0, callback)
            return
        self._after_workers_cancelled = callback
        for worker in active:
            if not cancel_all and not getattr(worker, "cancel_on_generation", True):
                continue
            cancel = getattr(worker, "request_cancel", None)
            if callable(cancel):
                cancel()
            else:
                worker.requestInterruption()


__all__ = ["GlobalRuntimeCoordinator"]
