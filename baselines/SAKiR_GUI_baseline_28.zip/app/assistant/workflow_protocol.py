"""Host-owned tool contracts and terminal outcome helpers; no inference."""
from .policy import AssistantError


def evidence_payload(name, data, arguments=None, policy=None):
    """Validate evidence before it can earn read authority or progress credit."""
    if name not in {'read_source', 'inspect_candidate', 'read_tool_result'}:
        return
    arguments = arguments or {}
    invalid = lambda: AssistantError('TOOL_RESULT_INVALID', f'{name} returned an invalid evidence payload.')
    if not isinstance(data, dict) or not isinstance(data.get('text'), str):
        raise invalid()
    if name == 'read_source':
        expected = arguments.get('path')
        if expected and policy:
            target = policy.path(expected)
            expected = target.relative_to(policy.root).as_posix() if target.is_relative_to(policy.root) else str(target)
        if (not all(isinstance(data.get(k), str) and data[k] for k in ('path', 'sha256', 'content_revision'))
                or type(data.get('start_line', 1)) is not int or data.get('start_line', 1) < 1
                or expected is not None and expected != data['path']):
            raise invalid()
        return
    identity = 'path' if name == 'inspect_candidate' else 'handle'
    if (not isinstance(data.get(identity), str) or not data[identity]
            or arguments.get(identity, data[identity]) != data[identity]):
        raise invalid()
    if name == 'inspect_candidate' and (not isinstance(data.get('fingerprint'), str)
                                       or not data['fingerprint'] or data.get('state') != 'candidate'):
        raise invalid()
    offset, total, following = (data.get(k) for k in ('offset', 'total_characters', 'next_offset'))
    if (type(offset) is not int or type(total) is not int or not 0 <= offset <= total
            or arguments.get('offset', offset) != offset
            or (following is not None and (type(following) is not int or not offset < following < total))):
        raise invalid()
    end = following if following is not None else total
    # Candidate text is redacted and can change length. Source offsets always
    # refer to original content; result-handle text has already been redacted.
    if (end == offset and total != 0) or (name == 'read_tool_result' and len(data['text']) != end - offset):
        raise invalid()


def capture_workflow(record, kind, value):
    """Small host trace for all live evaluators, without source/tool arguments."""
    if kind == 'workflow_outcome':
        record['outcome'] = value
    elif kind == 'workflow_stage':
        record.setdefault('host_stages', {})[value['stage_id']] = value
    elif kind in {'tool_started', 'tool_completed', 'tool_result'}:
        tool = record.setdefault('host_tools', {}).setdefault(value['id'], {})
        tool[kind] = True
        if kind == 'tool_result':
            tool['code'] = value['result'].get('code')


def evidence_identities(value):
    """Progress follows scoped evidence locations, not arbitrary result prose."""
    found = set()
    if isinstance(value, dict):
        path = value.get('path')
        revision = value.get('content_revision') or value.get('source_revision') or value.get('sha256')
        if isinstance(path, str) and isinstance(revision, str):
            found.add((path, revision, str(value.get('section_id', '')),
                       str(value.get('start_line', value.get('line', ''))),
                       str(value.get('end_line', ''))))
        for child in value.values():
            if isinstance(child, (dict, list)):
                found.update(evidence_identities(child))
    elif isinstance(value, list):
        for child in value:
            found.update(evidence_identities(child))
    return found


def host_checks(turns):
    """Score host integrity independently of answer quality and exceptions."""
    return {
        'terminal_outcome_recorded': all(isinstance(t.get('outcome'), dict) for t in turns),
        'stages_terminated': all(s.get('status') in {'succeeded', 'blocked', 'failed', 'interrupted'}
                                 for t in turns for s in t.get('host_stages', {}).values()),
        'tool_events_complete': all(all(tool.get(k) for k in ('tool_started', 'tool_completed', 'tool_result'))
                                    for t in turns for tool in t.get('host_tools', {}).values()),
        'tool_contracts_valid': all(tool.get('code') != 'TOOL_RESULT_INVALID'
                                    for t in turns for tool in t.get('host_tools', {}).values()),
        'review_clearance_consistent': all(not t.get('artifact_reviewed')
                                           or not (t.get('outcome') or {}).get('candidate_fingerprint') or
                                           (t.get('outcome') or {}).get('artifact_status') == 'reviewed'
                                           for t in turns),
    }
