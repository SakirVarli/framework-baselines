"""Session-only tool details and read-only previews of retained results."""
import copy
import json

from PyQt5 import QtCore, QtGui, QtWidgets

from .turn_activity import display_path


def formatted(value):
    return json.dumps(value, ensure_ascii=False, indent=2, default=str)


class ToolCard(QtWidgets.QFrame):
    preview_requested = QtCore.pyqtSignal(object)

    def __init__(self, entry, parent=None):
        super().__init__(parent)
        self.setObjectName("toolCard")
        self.entry = entry
        self._details_key = None
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        self.toggle = QtWidgets.QToolButton()
        self.toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle.setCheckable(True)
        self.toggle.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.toggle.toggled.connect(self.expand)
        layout.addWidget(self.toggle)
        self.status = QtWidgets.QLabel()
        self.status.setTextFormat(QtCore.Qt.PlainText)
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.preview_button = QtWidgets.QPushButton("Preview result")
        self.preview_button.clicked.connect(lambda: self.preview_requested.emit(self.entry))
        layout.addWidget(self.preview_button)
        self.details = QtWidgets.QWidget()
        detail_layout = QtWidgets.QVBoxLayout(self.details)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        self.arguments = self.editor("Tool arguments", detail_layout)
        self.result = self.editor("Returned result", detail_layout)
        layout.addWidget(self.details)
        self.details.hide()
        self.update_entry(entry)

    @staticmethod
    def editor(title, layout):
        layout.addWidget(QtWidgets.QLabel(title))
        editor = QtWidgets.QPlainTextEdit()
        editor.setAccessibleName(title)
        editor.setReadOnly(True)
        editor.setFont(QtGui.QFont("Consolas", 9))
        editor.setMinimumHeight(90)
        editor.setMaximumHeight(180)
        layout.addWidget(editor)
        return editor

    def expand(self, expanded):
        self.toggle.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.details.setVisible(expanded)
        if expanded:
            self.refresh_details()

    def refresh_details(self):
        key = (self.entry.get("arguments"), self.entry.get("result"), self.entry.get("error"))
        if key == self._details_key:
            return
        self._details_key = copy.deepcopy(key)
        self.arguments.setPlainText(formatted(key[0]) if key[0] is not None else "Arguments unavailable.")
        self.result.setPlainText(formatted(key[1]) if key[1] is not None else key[2] or "Awaiting result…")

    def update_entry(self, entry):
        self.entry = entry
        name = entry["name"].replace("_", " ").capitalize()
        self.toggle.setText(name)
        self.toggle.setToolTip(name + " · Expand call details")
        self.toggle.setArrowType(QtCore.Qt.DownArrow if self.toggle.isChecked() else QtCore.Qt.RightArrow)
        status = entry["status"].capitalize()
        if entry.get("duration_ms") is not None:
            status += f" · {entry['duration_ms'] / 1000:.1f}s"
        result = entry.get("result")
        data = result.get("data", {}) if isinstance(result, dict) else {}
        if isinstance(result, dict) and result.get("truncated"):
            status += " · Tool result truncated"
        if isinstance(result, dict) and result.get("display_truncated"):
            status += " · Display shortened"
        if isinstance(data, dict) and "sample" in data:
            status += " · Sample"
        if isinstance(entry.get("preview"), dict) and entry["preview"].get("truncated"):
            status += " · Diff shortened"
        if isinstance(data, dict) and data.get("truncated"):
            status += " · Partial source"
        if isinstance(entry.get("arguments"), dict) and entry["arguments"].get("display_truncated"):
            status += " · Arguments shortened"
        if entry.get("error"):
            status += "\n" + entry["error"]
        self.status.setText(status)
        self.status.setTextFormat(QtCore.Qt.PlainText)
        self.status.setStyleSheet("color: #ad3d32;" if entry["status"] in {"failed", "interrupted"} else "")
        self.preview_button.setVisible(result is not None)
        self.preview_button.setText("Diff preview" if entry.get("preview") else "Data preview" if entry["name"] == "inspect_file" else
                                    "Source preview" if entry["name"] == "read_source" else "Preview result")
        if self.toggle.isChecked():
            self.refresh_details()


class RequestGroup(QtWidgets.QFrame):
    """One request owns its cards, so late results cannot enter another group."""
    def __init__(self, request, parent=None):
        super().__init__(parent)
        self.setObjectName('timelineGroup')
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Maximum)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 12)
        layout.setSpacing(10)
        layout.setAlignment(QtCore.Qt.AlignTop)
        header = QtWidgets.QFrame()
        header.setObjectName('timelineRequest')
        header.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        heading = QtWidgets.QVBoxLayout(header)
        heading.setContentsMargins(10, 10, 10, 10)
        heading.setSpacing(6)
        self.toggle = QtWidgets.QToolButton()
        self.toggle.setObjectName('requestToggle')
        self.toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle.setCheckable(True)
        self.toggle.setChecked(True)
        self.toggle.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.request = ' '.join(request.split())
        self.toggle.setToolTip(request)
        self.toggle.setAccessibleName('Request: ' + request)
        heading.addWidget(self.toggle)
        self.badge = QtWidgets.QLabel()
        self.badge.setObjectName('timelineBadge')
        self.badge.setSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
        heading.addWidget(self.badge)
        layout.addWidget(header)
        self.content = QtWidgets.QFrame()
        self.content.setObjectName('timelineBranch')
        self.content.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Maximum)
        self.cards = QtWidgets.QVBoxLayout(self.content)
        self.cards.setContentsMargins(12, 4, 0, 4)
        self.cards.setSpacing(8)
        self.cards.setAlignment(QtCore.Qt.AlignTop)
        layout.addWidget(self.content)
        self.toggle.toggled.connect(self.expand)
        self.expand(True)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.toggle.setText(self.toggle.fontMetrics().elidedText(
            self.request, QtCore.Qt.ElideRight, max(50, self.width() - 56)))

    def expand(self, expanded):
        self.toggle.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.content.setVisible(expanded)
        self.layout().activate()
        self.updateGeometry()
        parent = self.parentWidget()
        if parent is not None and parent.layout() is not None:
            parent.layout().activate()

    def set_status(self, status):
        if self.badge.text() == status:
            return
        self.badge.setText(status)
        colors = {'Working': ('#e7eef9', '#45638c'), 'Needs review': ('#fff1d9', '#8b641f'),
                  'Completed': ('#e6f3eb', '#35644b'), 'Stopped': ('#fbe9e6', '#9a4c42')}
        bg, fg = colors[status]
        self.badge.setStyleSheet(f'background:{bg}; color:{fg}; border-radius:5px; padding:3px 7px; font-size:8pt;')


class TimelineCard(QtWidgets.QFrame):
    preview_requested = QtCore.pyqtSignal(object)
    review_requested = QtCore.pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('timelineCard')
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(7)
        self.title = QtWidgets.QLabel()
        self.title.setObjectName('timelineCardTitle')
        self.description = QtWidgets.QLabel()
        self.description.setWordWrap(True)
        self.status = QtWidgets.QLabel()
        self.status.setObjectName('muted')
        for label in (self.title, self.description, self.status):
            label.setTextFormat(QtCore.Qt.PlainText)
            layout.addWidget(label)
        self.preview_button = QtWidgets.QPushButton()
        self.preview_button.clicked.connect(lambda: self.preview_requested.emit(self.record))
        layout.addWidget(self.preview_button)
        self.review_button = QtWidgets.QPushButton()
        self.review_button.setObjectName('primary')
        self.review_button.clicked.connect(lambda: self.review_requested.emit(self.record))
        layout.addWidget(self.review_button)

    def update_record(self, record):
        self.record = record
        self.title.setText(record['title'])
        self.description.setText(record['description'])
        self.status.setText(record['status'])
        self.preview_button.setText(record['preview_label'])
        self.review_button.setText(record.get('review_label', 'Review'))
        self.review_button.setVisible(bool(record.get('reviewable')))
        self.review_button.setEnabled(not record.get('busy'))


class ToolActivityPanel(QtWidgets.QFrame):
    preview_requested = QtCore.pyqtSignal(object)
    timeline_preview_requested = QtCore.pyqtSignal(object)
    review_requested = QtCore.pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("toolsSidebar")
        self.setMinimumWidth(260)
        self.setMaximumWidth(520)
        self.cards = {}
        self.groups = {}
        self.event_cards = {}
        self.follow_timer = QtCore.QTimer(self)
        self.follow_timer.setSingleShot(True)
        self.follow_timer.timeout.connect(self.follow_bottom)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 20, 14, 16)
        heading = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("Actions timeline")
        title.setObjectName("brand")
        heading.addWidget(title, 1)
        layout.addLayout(heading)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.content = QtWidgets.QWidget()
        self.content.setObjectName("toolActivityContent")
        self.calls = QtWidgets.QVBoxLayout(self.content)
        self.calls.setContentsMargins(0, 0, 0, 0)
        self.empty = QtWidgets.QLabel("Requests, tool activity and actions will appear here.\nDetails are kept for this open chat session.")
        self.empty.setObjectName("muted")
        self.empty.setWordWrap(True)
        self.calls.addWidget(self.empty)
        self.calls.addStretch(1)
        self.scroll.setWidget(self.content)
        layout.addWidget(self.scroll, 1)

    def sync(self, activities, messages):
        bar = self.scroll.verticalScrollBar()
        follow = bar.maximum() - bar.value() <= 24
        for turn, activity in activities.items():
            if turn not in self.groups:
                request = getattr(activity, 'request_label', messages[turn]['content'] if turn < len(messages) else 'Resumed task')
                group = RequestGroup(request)
                self.calls.insertWidget(self.calls.count() - 1, group)
                self.groups[turn] = group
            group = self.groups[turn]
            position, needs_review = 0, False
            for index, entry in enumerate(activity.entries):
                if entry['kind'] == 'tool':
                    key = (turn, entry['message_id'], entry['id'])
                    if key not in self.cards:
                        card = ToolCard(entry)
                        card.preview_requested.connect(self.preview_requested)
                        self.cards[key] = card
                    else:
                        self.cards[key].update_entry(entry)
                    if position >= group.cards.count() or group.cards.itemAt(position).widget() is not self.cards[key]:
                        group.cards.insertWidget(position, self.cards[key])
                    position += 1
                record = self.record(activity, entry)
                if record:
                    record.update(turn=turn, index=index, busy=activity.busy)
                    needs_review |= record.get('reviewable', False)
                    key = (turn, index)
                    if key not in self.event_cards:
                        card = TimelineCard()
                        card.preview_requested.connect(self.timeline_preview_requested)
                        card.review_requested.connect(self.review_requested)
                        self.event_cards[key] = card
                    self.event_cards[key].update_record(record)
                    if position >= group.cards.count() or group.cards.itemAt(position).widget() is not self.event_cards[key]:
                        group.cards.insertWidget(position, self.event_cards[key])
                    position += 1
            stopped = any(e.get('status') in {'failed', 'interrupted'} or e['kind'] == 'interrupted' for e in activity.entries)
            group.set_status('Working' if activity.finished_at is None else 'Needs review' if needs_review
                             else 'Stopped' if stopped else 'Completed')
        self.empty.setVisible(not self.groups)
        if follow:
            self.follow_timer.start(0)

    def follow_bottom(self):
        bar = self.scroll.verticalScrollBar()
        bar.setValue(bar.maximum())

    def clear(self):
        self.follow_timer.stop()
        for widget in self.groups.values():
            self.calls.removeWidget(widget)
            widget.deleteLater()
        self.cards.clear()
        self.event_cards.clear()
        self.groups.clear()
        self.empty.show()

    def show_turn(self, turn):
        if turn in self.groups:
            self.groups[turn].toggle.setChecked(True)
            self.scroll.ensureWidgetVisible(self.groups[turn])

    def move_turn(self, old, new):
        """Preserve widgets and expansion choices when archiving a loaded draft."""
        if old in self.groups:
            self.groups[new] = self.groups.pop(old)
        for key in list(self.cards):
            if key[0] == old:
                self.cards[(new, *key[1:])] = self.cards.pop(key)
        for key in list(self.event_cards):
            if key[0] == old:
                card = self.event_cards.pop(key)
                card.record['turn'] = new
                self.event_cards[(new, key[1])] = card

    @staticmethod
    def record(activity, entry):
        preview = entry.get('preview')
        if isinstance(preview, dict):
            current = bool(preview.get('fingerprint') and preview['fingerprint'] == activity.proposal_fingerprint)
            applied = preview.get('applied') or (preview.get('proposal_id') and preview['proposal_id'] == activity.applied_proposal_id)
            status = ('Applied' if applied else 'Ready for review' if current else
                      'Superseded' if activity.proposal_fingerprint else 'Draft · Preparing' if activity.finished_at is None else 'Unavailable')
            return {'type': 'changes', 'title': 'Changes ready', 'description': preview.get('summary', 'Proposed changes'),
                    'status': status, 'preview_label': 'Preview changes', 'review_label': 'Review && apply',
                    'reviewable': current and not applied, 'fingerprint': preview.get('fingerprint')}
        if entry['kind'] == 'action':
            return {'type': 'action', 'title': 'Action ready', 'description': entry['summary'],
                    'status': entry['status'], 'preview_label': 'Action details', 'review_label': 'Review action',
                    'reviewable': entry['status'] == 'Ready for review', 'fingerprint': entry['fingerprint']}
        if entry['kind'] == 'data':
            return {'type': 'data', 'title': 'Data inspected', 'description': display_path(entry.get('path', 'Inspected data')),
                    'status': 'Read-only preview', 'preview_label': 'Data preview', 'reviewable': False}
        return None


class ToolPreviewDialog(QtWidgets.QDialog):
    def __init__(self, entry, parent=None):
        super().__init__(parent)
        self.setWindowTitle(entry["name"].replace("_", " ").capitalize() + " · Result preview")
        self.resize(850, 600)
        layout = QtWidgets.QVBoxLayout(self)
        result = entry["result"]
        data = result.get("data", result) if isinstance(result, dict) else result
        notes = ["Retained result from this call. Read-only."]
        if entry.get("preview"):
            data = entry["preview"]
            notes = ["Retained proposal diff from this call. Read-only; use Review changes to apply the current proposal."]
        if isinstance(result, dict) and result.get("truncated"):
            notes.append("Tool result was truncated before being sent to the model.")
        if isinstance(result, dict) and result.get("display_truncated"):
            notes.append("Display shortened; the model received more content than this display retains.")
        if isinstance(data, dict):
            for key in ("path", "filename", "sheet", "state", "note"):
                if data.get(key):
                    notes.append(f"{key.capitalize()}: {data[key]}")
            if "sample" in data:
                notes.append("Sample only; this may not represent the complete file.")
            if data.get("truncated"):
                notes.append("Preview shortened; additional content is not shown.")
        note = QtWidgets.QLabel("\n".join(notes))
        note.setTextFormat(QtCore.Qt.PlainText)
        note.setWordWrap(True)
        layout.addWidget(note)
        if isinstance(data, dict) and isinstance(data.get("rows"), list) and isinstance(data.get("columns"), list):
            columns, rows = data["columns"], data["rows"]
            self.preview = QtWidgets.QTableWidget(len(rows), len(columns))
            self.preview.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.preview.setHorizontalHeaderLabels([str(value) for value in columns])
            for i, row in enumerate(rows):
                for j, value in enumerate(row[:len(columns)]):
                    self.preview.setItem(i, j, QtWidgets.QTableWidgetItem(str(value)))
        else:
            self.preview = QtWidgets.QPlainTextEdit()
            self.preview.setReadOnly(True)
            self.preview.setFont(QtGui.QFont("Consolas", 10))
            self.preview.setPlainText(data["text"] if isinstance(data, dict) and isinstance(data.get("text"), str) else formatted(data))
        layout.addWidget(self.preview, 1)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
