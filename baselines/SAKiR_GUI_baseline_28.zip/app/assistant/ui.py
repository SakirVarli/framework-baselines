"""Native PyQt assistant, connection settings, capability browser and review."""
import copy
from dataclasses import asdict
import html
import json
import re
from pathlib import Path
import threading
import time

from PyQt5 import QtCore, QtGui, QtWidgets
from app import message_dialog

from . import changes
from .appearance import ComboBox, apply_theme, icon
from .activity import WorkingIndicator
from .conversation import Conversation
from .chat_rendering import message_html
from .policy import AssistantError, digest, redact
from .provider import ChatProvider
from .storage import Settings
from .usage import UsageIndicator
from .context_window import capacity_for
from .settings_help import SETTING_HELP, SETTING_TITLES, TAB_HELP, HEADER_HELP
from .settings_policy import (AUTOMATIC_FIELDS, budget_summary, character_budget, manual_settings,
                              resolve_settings)
from .settings_guide import SettingsGuideDialog
from .turn_activity import TurnActivity, tool_label
from .review import ReviewDialog
from .tool_activity import ToolActivityPanel, ToolPreviewDialog
from .tool_details import snapshot
from .clarification_ui import ClarificationPanel


def show_error(parent, exc):
    message_dialog.warning(parent, "Assistant", str(exc))


class SettingsDialog(QtWidgets.QDialog):
    probe_finished = QtCore.pyqtSignal(object)

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.manual_settings = manual_settings(controller.settings)
        self.setWindowTitle("Assistant Settings")
        apply_theme(self)
        self.resize(690, 650)
        self.widgets = {}
        self.profile = copy.deepcopy(controller.settings.capability_profile)
        self.model_limits = {}
        self.discovery_base_url = controller.settings.base_url
        self.cancel = threading.Event()
        self.provider = None
        outer = QtWidgets.QVBoxLayout(self)
        notice = QtWidgets.QLabel("Configuration: app/data/assistant/assistant.json\n"
                                 "Assistant files stay inside this framework folder.\n"
                                 "Hover over a setting or its label for an explanation.")
        notice.setWordWrap(True)
        outer.addWidget(notice)
        mode_row = QtWidgets.QHBoxLayout()
        mode_row.addWidget(QtWidgets.QLabel("Settings mode"))
        self.mode = ComboBox()
        self.mode.addItem("Simplified settings", "simplified")
        self.mode.addItem("Advanced settings", "advanced")
        self.mode.setCurrentIndex(self.mode.findData(controller.settings.settings_mode))
        self.mode.setAccessibleName("Settings mode")
        self.widgets["settings_mode"] = self.mode
        mode_row.addWidget(self.mode, 1)
        self.guide_button = QtWidgets.QPushButton("Settings Guide")
        self.guide_button.clicked.connect(self.open_guide)
        mode_row.addWidget(self.guide_button)
        outer.addLayout(mode_row)
        tabs = QtWidgets.QTabWidget()
        self.tabs = tabs
        tabs.setAccessibleName("Assistant settings sections")
        tabs.tabBar().setObjectName("assistantSettingsTabs")
        tabs.setUsesScrollButtons(False)
        tabs.setElideMode(QtCore.Qt.ElideNone)
        tabs.tabBar().setExpanding(False)
        outer.addWidget(tabs)
        connection, limits, privacy = [QtWidgets.QWidget() for _ in range(3)]
        tabs.addTab(connection, "Connection")
        tabs.addTab(limits, "Limits")
        tabs.addTab(privacy, "History")
        usage = QtWidgets.QWidget()
        tabs.addTab(usage, "Usage")
        usage_layout = QtWidgets.QVBoxLayout(usage)
        hint = QtWidgets.QLabel("Choose HTTP response headers to show in the assistant's Usage area. "
                               "Values update after each model response, including error responses. "
                               "Header keys are case-insensitive; values are displayed as sent by your provider.")
        hint.setWordWrap(True)
        usage_layout.addWidget(hint)
        self.usage_headers = QtWidgets.QTableWidget(0, 2)
        self.usage_headers.setAccessibleName("Usage response header mappings")
        self.usage_headers.setHorizontalHeaderLabels(["Header key", "Display name"])
        self.usage_headers.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.usage_headers.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.usage_headers.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.usage_headers.verticalHeader().hide()
        usage_layout.addWidget(self.usage_headers, 1)
        row = QtWidgets.QHBoxLayout()
        self.add_header_button = QtWidgets.QPushButton("Add header")
        self.add_header_button.clicked.connect(lambda: self.add_usage_header())
        self.remove_header_button = QtWidgets.QPushButton("Remove selected")
        self.remove_header_button.clicked.connect(self.remove_usage_headers)
        row.addWidget(self.add_header_button)
        row.addWidget(self.remove_header_button)
        row.addStretch(1)
        usage_layout.addLayout(row)
        example = QtWidgets.QLabel("Example: x-ratelimit-remaining-tokens → Tokens remaining\n"
                                  "Example: x-ratelimit-reset-tokens → Tokens reset in\n"
                                  "Missing headers show “Not provided”. No values are added together or converted to percentages.")
        example.setWordWrap(True)
        usage_layout.addWidget(example)
        for entry in controller.settings.usage_headers:
            self.add_usage_header(entry["header"], entry["display_name"])
        conn = QtWidgets.QFormLayout(connection)
        self.text(conn, "base_url", "Server base URL", "http://server:8000/v1")
        self.text(conn, "model", "Model ID", "Exact ID returned by your server")
        self.combo(conn, "auth_mode", "Authentication", [("No authentication", "none"), ("Session key", "session"),
                   ("Environment variable", "environment"), ("Windows Credential Manager", "windows")])
        self.key = QtWidgets.QLineEdit(controller.credentials.session)
        self.key.setEchoMode(QtWidgets.QLineEdit.Password)
        self.key.setPlaceholderText("Enter a key; never written to assistant.json")
        conn.addRow("API key", self.key)
        self.text(conn, "key_env", "Key environment variable")
        self.text(conn, "credential_ref", "Windows credential reference", "Auto-generated when a key is saved")
        self.text(conn, "ca_bundle", "Custom CA certificate", "Optional path to a trusted CA PEM file")
        self.check(conn, "streaming", "Stream responses")
        self.check(conn, "stream_usage", "Request stream token usage (server support required)")
        self.combo(conn, "token_parameter", "Output limit parameter", [("max_tokens", "max_tokens"), ("max_completion_tokens", "max_completion_tokens")])
        self.reasoning_adapter = ComboBox()
        self.reasoning_adapter.addItem('Discover / server default', 'auto')
        self.reasoning_adapter.addItem('Native reasoning_effort (declare support)', 'native')
        self.reasoning_adapter.addItem('llama.cpp template controls (declare support)', 'llama_cpp')
        self.reasoning_adapter.setAccessibleName('Reasoning support for this model')
        self.reasoning_adapter.setToolTip('Optional per-model declaration for servers that do not advertise support. Verify supported parameters and levels in the server/model documentation.')
        self.reasoning_levels = QtWidgets.QLineEdit()
        self.reasoning_levels.setAccessibleName('Supported reasoning levels')
        self.reasoning_levels.setPlaceholderText('For example: low,medium,high; binary llama.cpp: none,enabled')
        self.reasoning_adapter.currentIndexChanged.connect(lambda _: self.reasoning_levels.setEnabled(self.reasoning_adapter.currentData() != 'auto'))
        conn.addRow('Reasoning support', self.reasoning_adapter)
        conn.addRow('Supported levels', self.reasoning_levels)
        self.sync_reasoning_support()
        probe_row = QtWidgets.QWidget()
        buttons = QtWidgets.QHBoxLayout(probe_row)
        self.list_button = QtWidgets.QPushButton("List models")
        self.probe_button = QtWidgets.QPushButton("Test tools && streaming")
        buttons.addWidget(self.list_button)
        buttons.addWidget(self.probe_button)
        conn.addRow(probe_row)
        self.models = ComboBox()
        self.models.setPlaceholderText("Models returned by the server")
        self.models.activated.connect(self.select_model)
        conn.addRow("Discovered models", self.models)
        self.probe_status = QtWidgets.QPlainTextEdit()
        self.probe_status.setReadOnly(True)
        self.probe_status.setMaximumHeight(140)
        self.probe_status.setPlainText(json.dumps(self.profile, indent=2) if self.profile else "Connection not tested yet. Model IDs can also be entered manually.")
        conn.addRow("Compatibility", self.probe_status)
        from .model_routing import ROLES
        agents = QtWidgets.QWidget()
        agent_form = QtWidgets.QFormLayout(agents)
        self.check(agent_form, "multi_model", "Use multiple models")
        self.agent_toggle = self.widgets["multi_model"]
        self.agent_hint = QtWidgets.QLabel()
        self.agent_hint.setWordWrap(True)
        agent_form.addRow(self.agent_hint)
        self.agent_selectors = {}
        for role in ROLES:
            selector = ComboBox()
            selector.setAccessibleName(role.title() + " model")
            self.agent_selectors[role] = selector
            agent_form.addRow(role.title(), selector)
        self.agent_catalog = list(getattr(controller, 'discovered_models', None) or ())
        self.agent_catalog_endpoint = controller.settings.base_url
        self.agent_endpoint = None
        self.agent_toggle.toggled.connect(self.update_agent_controls)
        self.widgets["base_url"].textChanged.connect(self.refresh_agent_controls)
        self.refresh_agent_controls()
        self.limits_stack = QtWidgets.QStackedLayout(limits)
        manual_page = QtWidgets.QWidget()
        self.limits_stack.addWidget(manual_page)
        form = QtWidgets.QFormLayout(manual_page)
        for key, label, low, high in (("timeout", "Request timeout (seconds)", 5, 600), ("max_tokens", "Maximum output tokens", 256, 65536),
                                    ("context_chars", "Context budget (characters)", 8000, 2000000), ("max_rounds", "Maximum model rounds", 1, 40),
                                    ("max_tool_calls", "Maximum tool calls", 1, 100), ("task_timeout", "Task deadline (seconds)", 30, 3600),
                                    ("file_timeout", "File-reader timeout (seconds)", 1, 120), ("preview_rows", "Preview rows", 1, 200),
                                    ("result_chars", "Tool-result character limit", 1000, 64000)):
            spin = QtWidgets.QSpinBox()
            spin.setRange(low, high)
            spin.setValue(getattr(self.manual_settings, key))
            self.widgets[key] = spin
            form.addRow(label, spin)
        hint = QtWidgets.QLabel("Context is measured conservatively in characters. Server token limits still apply.\nDisable streaming if your server supports tools only in complete responses.")
        hint.setWordWrap(True)
        form.addRow(hint)
        context_page = QtWidgets.QWidget()
        tabs.addTab(context_page, "Context")
        tabs.addTab(agents, "Agent Models")
        form = QtWidgets.QFormLayout(context_page)
        for key, label, low, high in (("context_tokens", "Model context capacity (tokens)", 0, 10000000),
                                    ("context_margin", "Safety margin (tokens)", 0, 65536),
                                    ("compact_threshold", "Compact at input budget (%)", 50, 95)):
            spin = QtWidgets.QSpinBox()
            spin.setRange(low, high)
            spin.setValue(getattr(self.manual_settings, key))
            if key == "context_tokens":
                spin.setSpecialValueText("Automatic / unknown")
            self.widgets[key] = spin
            form.addRow(label, spin)
        self.combo(form, "tokenizer", "Preflight token counting", [("Estimate for any model", "estimate"),
                   ("cl100k_base (requires tiktoken)", "cl100k_base"), ("o200k_base (requires tiktoken)", "o200k_base")])
        self.check(form, "auto_compact", "Automatically compact older context")
        hint = QtWidgets.QLabel("Set the capacity configured on your model server, or use model-list metadata when available. "
                               "Zero means unknown when the server does not advertise it. Maximum output tokens also reserve context space.\n\n"
                               "Preflight counts are estimates because servers use different chat templates. Provider-reported input usage "
                               "is shown after a response. Select a tokenizer only when it matches your model.\n\n"
                               "Compaction uses this server to summarize older conversation and completed tool activity. "
                               "It shares task time/model-round limits. The readable transcript stays intact; summaries can lose detail. "
                               "With unknown capacity, the character budget still controls compaction.")
        hint.setWordWrap(True)
        form.addRow(hint)
        simple_page = QtWidgets.QWidget()
        self.limits_stack.addWidget(simple_page)
        simple = QtWidgets.QFormLayout(simple_page)
        self.combo(simple, "task_preset", "Task size", [("Quick", "quick"), ("Standard", "standard"), ("Extended", "extended")])
        self.combo(simple, "output_preset", "Output allowance", [("Standard", "standard"), ("Large completion allowance", "reasoning")])
        self.combo(simple, "file_detail", "File detail", [("Small", "small"), ("Standard", "standard"), ("Detailed", "detailed")])
        self.simple_capacity = QtWidgets.QSpinBox()
        self.simple_capacity.setRange(0, 10000000)
        self.simple_capacity.setSpecialValueText("Automatic / unknown")
        self.simple_capacity.setValue(self.widgets["context_tokens"].value())
        self.simple_capacity.setAccessibleName("Model context capacity (tokens)")
        simple.addRow("Model context capacity (tokens)", self.simple_capacity)
        self.explain(self.simple_capacity, SETTING_HELP["context_tokens"])
        self.simple_capacity.valueChanged.connect(self.widgets["context_tokens"].setValue)
        self.widgets["context_tokens"].valueChanged.connect(self.simple_capacity.setValue)
        self.calculated = QtWidgets.QPlainTextEdit()
        self.calculated.setReadOnly(True)
        self.calculated.setAccessibleName("Calculated settings")
        self.calculated.setMinimumHeight(225)
        simple.addRow("Calculated settings", self.calculated)
        simple_hint = QtWidgets.QLabel("Capacity and output allowance determine input space. Task and file presets choose the other limits. "
                                      "No capacity is inferred from the model name. Connection compatibility stays under Connection.")
        simple_hint.setWordWrap(True)
        simple.addRow(simple_hint)
        form = QtWidgets.QFormLayout(privacy)
        self.check(form, "save_history", "Save visible conversation history locally")
        spin = QtWidgets.QSpinBox()
        spin.setRange(1, 100)
        spin.setValue(controller.settings.history_sessions)
        self.widgets["history_sessions"] = spin
        form.addRow("Retained sessions", spin)
        private = QtWidgets.QLabel(str(controller.store.private))
        private.setWordWrap(True)
        private.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        form.addRow("Assistant data folder", private)
        clear = QtWidgets.QPushButton("Delete conversation history")
        clear.clicked.connect(self.clear_history)
        form.addRow(clear)
        policy = QtWidgets.QLabel("Framework Python: read only\nCallbacks and externals: previewed project edits\nConfiguration JSON: validated edits\nGenerated stubs: maintained by the framework\nNo shell or arbitrary code execution tool\nApply & Reload executes reviewed project Python.\nAssistant data is excluded from baseline exports.\nOnly attached external files can be inspected outside the project.")
        policy.setWordWrap(True)
        form.addRow("Permissions", policy)
        self.buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.save)
        self.buttons.rejected.connect(self.reject)
        outer.addWidget(self.buttons)
        self.list_button.clicked.connect(lambda: self.test("models"))
        self.probe_button.clicked.connect(lambda: self.test("probe"))
        self.probe_finished.connect(self.test_finished)
        self.finished.connect(self.stop_probe)
        self.widgets["auth_mode"].currentIndexChanged.connect(self.update_auth)
        self.update_auth()
        # Keep long forms usable at the original window size in either mode.
        for index in range(tabs.count()):
            page, title = tabs.widget(index), tabs.tabText(index)
            tabs.removeTab(index)
            scroll = QtWidgets.QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
            scroll.setWidget(page)
            tabs.insertTab(index, scroll, title)
        tabs.setCurrentIndex(0)
        self.mode.currentIndexChanged.connect(self.update_mode)
        for key, widget in self.widgets.items():
            if key == "settings_mode":
                continue
            signal = (widget.currentIndexChanged if isinstance(widget, QtWidgets.QComboBox) else
                      widget.toggled if isinstance(widget, QtWidgets.QCheckBox) else
                      widget.valueChanged if isinstance(widget, QtWidgets.QSpinBox) else widget.textChanged)
            signal.connect(self.update_calculated)
        self.widgets["base_url"].textChanged.connect(self.connection_changed)
        self.widgets["model"].textChanged.connect(self.connection_changed)
        for index, text in enumerate(TAB_HELP):
            tabs.setTabToolTip(index, self.help_text(text))
        self.update_mode()
        for key, widget in self.widgets.items():
            self.explain(widget, SETTING_HELP[key])
        for key, widget in (("api_key", self.key), ("models", self.models), ("probe_status", self.probe_status),
                            ("data_folder", private)):
            self.explain(widget, SETTING_HELP[key])
        for widget, text in ((self.list_button, "Ask the configured server for available model IDs and any advertised context capacities. This makes a network request; you can enter a Model ID manually instead."),
                             (self.probe_button, SETTING_HELP["probe_status"]),
                             (clear, "Delete all saved conversation history and context summaries in this project, then start a new chat. Recovery journals and settings are retained."),
                             (self.add_header_button, "Add a response-header key and a display name to track in the Usage hover card. Up to 32 mappings are supported."),
                             (self.remove_header_button, "Remove the selected mappings. Changes take effect when you save Settings."),
                             (self.buttons.button(QtWidgets.QDialogButtonBox.Save), "Save these settings for this project. Session API keys stay in memory."),
                             (self.buttons.button(QtWidgets.QDialogButtonBox.Cancel), "Close without saving edited settings. Connection tests may already have sent requests."),
                             (self.usage_headers, "Add one response-header key and display name per row. Double-click a cell to edit it. Missing headers show Not provided in the Usage hover card."),
                             (self.guide_button, "Open a searchable guide to every setting, automatic calculation, dependency and troubleshooting step."),
                             (self.calculated, "Live effective values used by Simplified settings. Calculations are local; use List models to request server capacity metadata."),
                             (policy, "These permissions describe what assistant tools can inspect or stage. File changes require review and Apply; reviewed project Python runs when loaded or reloaded.")):
            self.explain(widget, text)
        for column, text in enumerate(HEADER_HELP):
            self.usage_headers.horizontalHeaderItem(column).setToolTip(self.help_text(text))
        for value, text in (("none", "For servers that do not require an API key, usually local model servers."),
                            ("session", "Use the API key entered here for this app session. It stays in memory."),
                            ("environment", "Read the key from the named environment variable available to this app."),
                            ("windows", "Store or read the key using the specified Windows Credential Manager reference.")):
            combo = self.widgets["auth_mode"]
            combo.setItemData(combo.findData(value), self.help_text(text), QtCore.Qt.ToolTipRole)

    def save_agent_choices(self):
        if self.agent_endpoint:
            preferences = {
                role: selector.currentData() for role, selector in self.agent_selectors.items()
                if selector.currentData()}
            if preferences:
                self.manual_settings.agent_models[self.agent_endpoint] = preferences
            else:
                self.manual_settings.agent_models.pop(self.agent_endpoint, None)

    def refresh_agent_controls(self, *_):
        self.save_agent_choices()
        self.agent_endpoint = self.widgets["base_url"].text().strip()
        catalog = self.agent_catalog if self.agent_endpoint == self.agent_catalog_endpoint else ()
        preferences = self.manual_settings.agent_models.get(self.agent_endpoint, {})
        for role, selector in self.agent_selectors.items():
            selector.clear()
            selector.addItem("Automatic", None)
            for model in sorted(set(catalog)):
                selector.addItem(model, model)
            model = preferences.get(role)
            if model and selector.findData(model) < 0:
                selector.addItem(model + " (unavailable or unlisted)", model)
            selector.setCurrentIndex(selector.findData(model))
        self.update_agent_controls()

    def update_agent_controls(self, *_):
        available = (self.agent_endpoint == self.agent_catalog_endpoint and len(set(self.agent_catalog)) >= 2)
        self.agent_toggle.setEnabled(available)
        for selector in self.agent_selectors.values():
            selector.setEnabled(available and self.agent_toggle.isChecked())
        self.agent_hint.setText(
            "Automatic uses verified capabilities when available. Unavailable preferences fall back to Automatic."
            if available else "Use List models in Connection to discover at least two models on this server.")

    def update_mode(self, *_):
        simplified = self.mode.currentData() == "simplified"
        self.limits_stack.setCurrentIndex(1 if simplified else 0)
        self.tabs.setTabText(1, "Simplified" if simplified else "Limits")
        self.tabs.setTabToolTip(1, self.help_text("Simplified: select task size, output allowance and file detail; review calculated limits."
                                                if simplified else TAB_HELP[1]))
        if simplified and self.tabs.currentIndex() == 4:
            self.tabs.setCurrentIndex(1)
        self.tabs.setTabVisible(4, not simplified)
        self.update_calculated()

    def update_calculated(self, *_):
        try:
            effective, summary = budget_summary(self.collect())
            lines = [f"{key}: {value:,}" if type(value) is int else f"{key}: {value or 'Unknown'}"
                     for key, value in summary.items()]
            lines.append("")
            for key in AUTOMATIC_FIELDS:
                value = getattr(effective, key)
                label = SETTING_TITLES[key]
                lines.append(f"{label}: {value:,}" if type(value) is int else f"{label}: {value}")
            if effective.context_chars == 2000000:
                lines.append("Character guard capped at 2,000,000 to bound memory; it may compact before the token guard.")
            self.calculated.setPlainText("\n".join(lines))
        except (AssistantError, ValueError) as exc:
            self.calculated.setPlainText("Please correct settings: " + str(exc))

    def connection_changed(self, *_):
        # A manual capacity is specific to a connection too; clear it on a
        # server/model change rather than applying the old model's limit.
        self.profile = None
        base_url = self.widgets["base_url"].text().strip()
        model = self.widgets["model"].text().strip()
        if base_url != self.discovery_base_url:
            self.model_limits = {}
            self.models.clear()
        elif model in self.model_limits:
            self.profile = {"base_url": base_url, "model": model,
                            "context_tokens": self.model_limits[model],
                            "streaming": self.widgets["streaming"].isChecked()}
        known = self.manual_settings.model_profiles.get(digest([base_url, model]), {})
        if known:
            self.profile = {**known, **(self.profile or {})}
        self.widgets["context_tokens"].setValue(0)
        self.sync_reasoning_support()
        self.update_calculated()

    def sync_reasoning_support(self):
        profile = self.profile or {}
        declared = str(profile.get('reasoning_source','')).startswith('user configuration')
        self.reasoning_adapter.setCurrentIndex(max(0,self.reasoning_adapter.findData(profile.get('reasoning_adapter') if declared else 'auto')))
        levels = profile.get('reasoning_efforts',[])
        self.reasoning_levels.setText(','.join(v for v in levels if isinstance(v,str)) if isinstance(levels,list) else '')
        self.reasoning_levels.setEnabled(declared)

    def open_guide(self):
        if not hasattr(self, "guide"):
            self.guide = SettingsGuideDialog(self)
        self.guide.show()
        self.guide.raise_()
        self.guide.activateWindow()

    @staticmethod
    def help_text(text):
        return "<qt>" + html.escape(text) + "</qt>"

    def explain(self, widget, text):
        widget.setToolTip(self.help_text(text))
        widget.setAccessibleDescription(text)
        if isinstance(widget, QtWidgets.QSpinBox):
            widget.lineEdit().setToolTip(self.help_text(text))
        layout = widget.parentWidget().layout() if widget.parentWidget() else None
        if isinstance(layout, QtWidgets.QFormLayout):
            label = layout.labelForField(widget)
            if label is not None:
                label.setToolTip(self.help_text(text))
                label.setAccessibleDescription(text)

    def update_auth(self, *_):
        mode = self.widgets["auth_mode"].currentData()
        self.key.setEnabled(mode in {"session", "windows"})
        self.widgets["key_env"].setEnabled(mode == "environment")
        self.widgets["credential_ref"].setEnabled(mode == "windows")

    def select_model(self, index):
        model = self.models.itemText(index)
        capacity = self.model_limits.get(model)
        self.widgets["model"].setText(model)
        if capacity:
            base_url = self.widgets["base_url"].text().strip()
            profile = self.profile or {}
            if (profile.get("base_url"), profile.get("model")) != (base_url, model):
                profile = {"base_url": base_url, "model": model}
            self.profile = {**profile, "context_tokens": capacity}
        self.update_calculated()

    def add_usage_header(self, header="", display_name=""):
        row = self.usage_headers.rowCount()
        if row >= 32:
            return
        self.usage_headers.insertRow(row)
        for column, value in enumerate((header, display_name)):
            item = QtWidgets.QTableWidgetItem(value)
            item.setToolTip(self.help_text(HEADER_HELP[column]))
            self.usage_headers.setItem(row, column, item)
        self.usage_headers.setCurrentCell(row, 0)
        self.add_header_button.setEnabled(self.usage_headers.rowCount() < 32)

    def remove_usage_headers(self):
        for row in sorted({index.row() for index in self.usage_headers.selectedIndexes()}, reverse=True):
            self.usage_headers.removeRow(row)
        self.add_header_button.setEnabled(self.usage_headers.rowCount() < 32)

    def text(self, form, key, label, placeholder=""):
        widget = QtWidgets.QLineEdit(getattr(self.manual_settings, key))
        widget.setPlaceholderText(placeholder)
        self.widgets[key] = widget
        form.addRow(label, widget)

    def combo(self, form, key, label, items):
        widget = ComboBox()
        for title, value in items:
            widget.addItem(title, value)
        widget.setCurrentIndex(max(0, widget.findData(getattr(self.manual_settings, key))))
        self.widgets[key] = widget
        form.addRow(label, widget)

    def check(self, form, key, label):
        widget = QtWidgets.QCheckBox(label)
        widget.setChecked(getattr(self.manual_settings, key))
        self.widgets[key] = widget
        form.addRow(widget)

    def collect(self):
        self.save_agent_choices()
        data = asdict(self.manual_settings)
        for key, widget in self.widgets.items():
            data[key] = widget.currentData() if isinstance(widget, QtWidgets.QComboBox) else widget.isChecked() if isinstance(widget, QtWidgets.QCheckBox) else widget.value() if isinstance(widget, QtWidgets.QSpinBox) else widget.text().strip()
        data["capability_profile"] = self.profile
        data["usage_headers"] = []
        for row in range(self.usage_headers.rowCount()):
            values = [self.usage_headers.item(row, column).text().strip()
                      if self.usage_headers.item(row, column) else "" for column in range(2)]
            data["usage_headers"].append(dict(zip(("header", "display_name"), values)))
        data["advanced_limits"] = ({key: data[key] for key in AUTOMATIC_FIELDS}
                                   if data["settings_mode"] == "simplified" else {})
        adapter = self.reasoning_adapter.currentData()
        if adapter != 'auto':
            from .reasoning import LEVELS
            levels = [v.strip() for v in self.reasoning_levels.text().split(',') if v.strip()]
            if not levels or any(v not in LEVELS or adapter == 'native' and v == 'enabled' for v in levels):
                raise AssistantError('SETTINGS_INVALID','Declare the actual supported reasoning levels for this model; use comma-separated known levels.')
            data['capability_profile'] = {**(data.get('capability_profile') or {}), 'base_url':data['base_url'], 'model':data['model'],
                'reasoning_adapter':adapter, 'reasoning_efforts':list(dict.fromkeys(levels)), 'reasoning_source':'user configuration (unverified)'}
        elif str((data.get('capability_profile') or {}).get('reasoning_source','')).startswith('user configuration'):
            data['capability_profile'] = {**data['capability_profile'], 'reasoning_efforts':[], 'reasoning_adapter':'server', 'reasoning_source':'not advertised by server'}
        return resolve_settings(Settings(**data))

    def key_for(self, settings, save=False):
        if settings.auth_mode == "session":
            self.controller.credentials.session = self.key.text()
        elif settings.auth_mode == "windows" and self.key.text():
            if not save:
                return self.key.text()
            settings.credential_ref = settings.credential_ref or "SAKiR-Assistant-" + digest(settings.base_url.encode())[:24]
            self.controller.credentials._windows(settings.credential_ref, self.key.text())
        return self.controller.credentials.key(settings)

    def save(self):
        try:
            settings = self.collect()
            settings.validate(connection=bool(settings.base_url or settings.model))
            if settings.auth_mode in {"session", "windows"}:
                self.key_for(settings, save=True)
            profile = settings.capability_profile
            if profile and (profile.get('model'), profile.get('base_url')) != (settings.model, settings.base_url):
                settings.capability_profile = None
            elif profile and profile.get('streaming') != settings.streaming:
                settings.capability_profile = {k:v for k,v in profile.items() if k != 'tool_round_trip'} | {'streaming':settings.streaming}
            known = settings.model_profiles.get(digest([settings.base_url, settings.model]), {})
            if known:
                settings.capability_profile = {**{k:v for k,v in known.items() if k not in {'tool_round_trip','streaming'}}, **(settings.capability_profile or {})}
            if settings.capability_profile:
                settings.model_profiles[digest([settings.base_url, settings.model])] = copy.deepcopy(settings.capability_profile)
            elif settings.model:
                settings.model_profiles[digest([settings.base_url, settings.model])] = {'base_url':settings.base_url,'model':settings.model}
            if settings.model:
                settings.model_profiles[digest([settings.base_url, settings.model])]['chat_limits'] = {
                    k:getattr(settings,k) for k in ('context_tokens','max_tokens','context_margin')}
                settings.model_profiles[digest([settings.base_url, settings.model])]['chat_streaming'] = settings.streaming
                settings.model_profiles[digest([settings.base_url, settings.model])]['chat_token_parameter'] = settings.token_parameter
            from .reasoning import supported_efforts
            if settings.reasoning_effort not in supported_efforts(settings):
                settings.reasoning_effort = 'auto'
            self.controller.store.save_settings(settings)
            self.controller.settings = settings
            self.controller.settings_error = ""
            self.controller.activity.emit("settings", settings.model)
            self.accept()
        except Exception as exc:
            show_error(self, exc)

    def test(self, kind):
        try:
            settings = self.collect()
            if kind == "models" and not settings.model:
                settings.model = "discovery"
            settings.validate()
            key = self.key_for(settings)
        except Exception as exc:
            show_error(self, exc)
            return
        self.cancel = threading.Event()
        self.list_button.setEnabled(False)
        self.probe_button.setEnabled(False)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(False)
        self.probe_status.setPlainText("Checking the configured server…")
        def worker():
            try:
                self.provider = ChatProvider(settings, key)
                if kind == "models":
                    data = self.provider.models()
                else:
                    try:
                        self.provider.models()
                    except Exception:
                        pass
                    data = self.provider.probe(self.cancel)
                    data["probe_time"] = time.time()
                    data["probe_revision"] = self.provider.model_profiles.get(settings.model, {}).get("model_revision")
                result = {"kind": kind, "data": data, "model_limits": self.provider.model_limits,
                          "model_profiles": self.provider.model_profiles,
                          "base_url": settings.base_url, "model": settings.model}
                if kind == "probe" and self.profile and self.profile.get("context_tokens"):
                    if (self.profile.get("base_url"), self.profile.get("model")) == (settings.base_url, settings.model):
                        data["context_tokens"] = self.profile["context_tokens"]
            except Exception as exc:
                result = {"error": str(exc).replace(key, "<redacted>"), "code": getattr(exc, "code", "CONNECTION_ERROR"),
                          "base_url": settings.base_url, "model": settings.model,
                          "profile": {"base_url": settings.base_url, "model": settings.model,
                                      "streaming": settings.streaming, "tool_round_trip": False,
                                      "probe_time": time.time(), "probe_revision":
                                          getattr(self.provider, 'model_profiles', {}).get(settings.model, {}).get('model_revision')}}
            finally:
                if self.provider:
                    try:
                        self.provider.dispose()
                    except Exception:
                        pass
                self.provider = None
            try:
                self.probe_finished.emit(result)
            except RuntimeError:
                pass
        threading.Thread(target=worker, daemon=True, name="assistant-connection-test").start()

    def test_finished(self, result):
        self.list_button.setEnabled(True)
        self.probe_button.setEnabled(True)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(True)
        if (result.get("base_url", self.widgets["base_url"].text().strip()) != self.widgets["base_url"].text().strip()
                or (result.get("kind") != "models" and result.get("model", self.widgets["model"].text().strip()) != self.widgets["model"].text().strip())):
            self.probe_status.setPlainText("Connection changed during the check; old results were discarded. Run the check again.")
            return
        self.probe_status.setPlainText(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("kind") == "models":
            for model, profile in result.get('model_profiles', {}).items():
                from .reasoning import merge_profile
                key = digest([profile['base_url'],model])
                self.manual_settings.model_profiles[key] = merge_profile(self.manual_settings.model_profiles.get(key,{}), profile)
            self.model_limits = result.get("model_limits", {})
            self.discovery_base_url = self.widgets["base_url"].text().strip()
            self.models.clear()
            self.models.addItems(result["data"])
            self.agent_catalog = result["data"]
            self.agent_catalog_endpoint = self.discovery_base_url
            self.refresh_agent_controls()
            index = self.models.findText(self.widgets["model"].text().strip())
            if index >= 0:
                self.select_model(index)
        elif result.get("kind") == "probe":
            previous = self.profile or {}
            self.profile = {**previous, **result["data"]} if (previous.get('base_url'), previous.get('model')) == (result['data'].get('base_url'), result['data'].get('model')) else result['data']
        elif result.get("code") == "TOOLS_UNSUPPORTED":
            self.profile = result["profile"]
        if result.get("kind") == "probe" or result.get("code") == "TOOLS_UNSUPPORTED":
            key = digest([self.profile['base_url'], self.profile['model']])
            self.manual_settings.model_profiles[key] = {**self.manual_settings.model_profiles.get(key, {}), **self.profile}
        self.sync_reasoning_support()
        self.update_calculated()

    def stop_probe(self, *_):
        self.cancel.set()
        if self.provider:
            threading.Thread(target=self.provider.close, daemon=True).start()

    def clear_history(self):
        self.controller.store.clear_history()
        self.controller.workflow_store.clear()
        self.controller.new_session()
        self.probe_status.setPlainText("Conversation history deleted. Recovery journals retained.")


class Composer(QtWidgets.QPlainTextEdit):
    send_requested = QtCore.pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter) and not event.modifiers() & QtCore.Qt.ShiftModifier:
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


class AssistantWindow(QtWidgets.QMainWindow):
    def __init__(self, controller):
        # A QWidget parent creates a native owner on Windows, which excludes
        # the window from normal task switching. The controller owns lifetime.
        super().__init__(None, QtCore.Qt.Window)
        self.setWindowTitle("SAKiR Assistant")
        self.setObjectName("sakirAssistantWindow")
        self.setWindowIcon(controller.window.windowIcon())
        self.setAttribute(QtCore.Qt.WA_QuitOnClose, False)
        self.controller = controller
        self.resize(1180, 820)
        self.setMinimumSize(680, 500)
        apply_theme(self)
        self.visible_messages = copy.deepcopy(controller.history)
        self.streaming_text = ""
        self._completed_answer = ""
        self._answer_reveal = None
        self.turn_activities = {}
        self._active_turn = None
        self._message_id = None
        self._message_phase = None
        self._render_pending = False
        self._detail_stream_pending = False
        self._activity_titles = {}
        self._message_cache = []
        self.data_preview = None
        self._sidebar_preference = True
        self._sidebar_width = 248
        self._restoring_sidebar = False
        self._tools_preference = False
        self._tools_width = 320
        self._tools_explicit = False
        self._sessions = {}
        content = QtWidgets.QWidget()
        content.setObjectName("assistantSurface")
        self.setCentralWidget(content)
        shell = QtWidgets.QHBoxLayout(content)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)
        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        self.splitter.setObjectName("assistantSplit")
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(3)
        shell.addWidget(self.splitter)

        self.sidebar = QtWidgets.QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setMinimumWidth(220)
        self.sidebar.setMaximumWidth(480)
        side = QtWidgets.QVBoxLayout(self.sidebar)
        side.setContentsMargins(16, 24, 16, 16)
        side.setSpacing(10)
        side.addWidget(self.label("SAKiR  /  Assistant", "brand"))
        side.addSpacing(18)
        self.new_button = self.button("New chat", self.new, "newChat", "new")
        self.new_button.setToolTip("New chat (Ctrl+N)")
        side.addWidget(self.new_button)
        side.addWidget(self.button("Saved drafts", self.drafts, "navigation", "document"))
        side.addWidget(self.button("Capabilities", self.capabilities, "navigation", "folder"))
        side.addSpacing(18)
        side.addWidget(self.label("CONVERSATIONS", "eyebrow"))
        self.session_search = QtWidgets.QLineEdit()
        self.session_search.setObjectName("sessionSearch")
        self.session_search.setPlaceholderText("Search chats…")
        self.session_search.setAccessibleName("Search conversations")
        self.session_search.textChanged.connect(self.filter_sessions)
        side.addWidget(self.session_search)
        self.session_list = QtWidgets.QListWidget()
        self.session_list.setObjectName("sessions")
        self.session_list.setAccessibleName("Saved conversations")
        self.session_list.setToolTip("Right-click a chat to rename or delete it.")
        self.session_list.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.session_list.itemClicked.connect(self.load_session)
        self.session_list.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.session_list.customContextMenuRequested.connect(self.session_menu)
        side.addWidget(self.session_list, 1)
        self.session_notice = self.label("Your chats will appear here.", "muted")
        side.addWidget(self.session_notice)
        self.restore_button = self.button("Restore previous changes", self.restore, "navigation", "history")
        self.restore_button.setIconSize(QtCore.QSize(16, 16))
        self.restore_button.setStyleSheet("QPushButton { padding: 9px 5px; }")
        self.restore_button.setToolTip("Restore previous changes")
        side.addWidget(self.restore_button)
        side.addWidget(self.button("Settings", self.settings, "navigation", "settings"))
        project = self.label(controller.policy.root.name, "muted")
        project.setToolTip(str(controller.policy.root))
        side.addWidget(project)
        self.splitter.addWidget(self.sidebar)

        chat = QtWidgets.QWidget()
        chat.setObjectName("chatPage")
        chat.setMinimumWidth(400)
        outer = QtWidgets.QVBoxLayout(chat)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.splitter.addWidget(chat)
        self.tools_sidebar = ToolActivityPanel()
        self.tools_sidebar.preview_requested.connect(self.preview_tool)
        self.tools_sidebar.timeline_preview_requested.connect(self.preview_timeline)
        self.tools_sidebar.review_requested.connect(self.review_timeline)
        self.splitter.addWidget(self.tools_sidebar)
        self.tools_sidebar.hide()
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.handle(2).setCursor(QtCore.Qt.SizeHorCursor)
        self.splitter.handle(2).setAccessibleName("Resize tools sidebar")
        self.splitter.handle(2).setToolTip("Drag to resize the actions timeline. Ctrl+Shift+B hides or shows it.")
        divider = self.splitter.handle(1)
        divider.setCursor(QtCore.Qt.SizeHorCursor)
        divider.setAccessibleName("Resize conversation sidebar")
        divider.setToolTip("Drag left or right to resize the sidebar. Ctrl+B hides or shows it.")
        self.splitter.splitterMoved.connect(self.remember_sidebar_width)
        header = QtWidgets.QFrame()
        header.setObjectName("header")
        head = QtWidgets.QHBoxLayout(header)
        head.setContentsMargins(20, 14, 24, 14)
        toggle = self.button("", self.toggle_sidebar, "", "panel")
        toggle.setAccessibleName("Toggle conversation sidebar")
        toggle.setToolTip("Toggle sidebar (Ctrl+B)")
        head.addWidget(toggle)
        self.chat_title = self.label("New chat", "brand")
        self.chat_title.setMinimumWidth(0)
        self.chat_title.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        head.addWidget(self.chat_title, 1)
        self.model = self.label(controller.settings.model or "Set up a model", "model")
        self.model.setMaximumWidth(240)
        self.model.setMinimumWidth(0)
        self.model.setToolTip(controller.settings.model or "Choose a model in Settings")
        self.current_effort = self.label("", "model")
        self.current_effort.setAccessibleName("Current reasoning effort")
        self.tools_toggle = self.button("", self.toggle_tools_sidebar, "", "panel-right")
        self.tools_toggle.setCheckable(True)
        self.tools_toggle.setAccessibleName("Toggle actions timeline")
        self.tools_toggle.setToolTip("Actions timeline (Ctrl+Shift+B)")
        head.addWidget(self.tools_toggle)
        head.addWidget(self.button("", self.settings, "", "settings"))
        head.itemAt(head.count() - 1).widget().setToolTip("Connection settings")
        head.itemAt(head.count() - 1).widget().setAccessibleName("Connection settings")
        outer.addWidget(header)
        self.model_selector = ComboBox()
        self.model_selector.setEditable(False)
        self.model_selector.setMinimumWidth(100)
        self.model_selector.setMaximumWidth(200)
        self.model_selector.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        self.model_selector.setMinimumContentsLength(8)
        self.model_selector.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.model_selector.setAccessibleName('Chat model')
        self.model_selector.setToolTip('Choose a served model. Selection refreshes capabilities; your conversation and draft are kept.')
        self.model_selector.activated.connect(lambda _: self.change_model())
        self.effort_selector = ComboBox()
        self.effort_selector.setAccessibleName('Reasoning effort')
        self.effort_selector.setMinimumWidth(84)
        self.effort_selector.setMaximumWidth(120)
        self.effort_selector.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        self.effort_selector.setMinimumContentsLength(6)
        self.effort_selector.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.effort_selector.activated.connect(self.change_effort)
        self.refresh_models_button = self.button('', self.refresh_models, symbol='refresh')
        self.refresh_models_button.setFixedSize(38,38)
        self.refresh_models_button.setAccessibleName('Refresh models')
        self.refresh_models_button.setToolTip('Read server models, capacity and effort support. Keeps drafts/history and does not restart the server.')
        self.model_popup = QtWidgets.QFrame(self, QtCore.Qt.Popup)
        self.model_popup.setObjectName("modelEffortPopup")
        self.model_popup.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.model_popup.setStyleSheet("QFrame#modelEffortPopup { background: #ffffff; border: 1px solid #dce1e8; border-radius: 12px; }"
            "QSlider::groove:horizontal { height: 4px; background: #dce1e8; border-radius: 2px; }"
            "QSlider::sub-page:horizontal { background: #697f9e; border-radius: 2px; }"
            "QSlider::handle:horizontal { background: #ffffff; border: 1px solid #697f9e; width: 14px; margin: -6px 0; border-radius: 7px; }")
        popup_layout = QtWidgets.QVBoxLayout(self.model_popup)
        popup_layout.addWidget(self.label("Model and effort", "brand"))
        model_row = QtWidgets.QHBoxLayout()
        model_row.addWidget(self.refresh_models_button)
        self.model_selector.setMaximumWidth(360)
        model_row.addWidget(self.model_selector, 1)
        popup_layout.addLayout(model_row)
        self.effort_label = self.label("Effort", "muted")
        popup_layout.addWidget(self.effort_label)
        self.effort_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.effort_slider.setAccessibleName("Reasoning effort")
        self.effort_slider.setTickPosition(QtWidgets.QSlider.TicksBelow)
        self.effort_slider.setTickInterval(1)
        self.effort_slider.setTracking(False)
        self.effort_slider.valueChanged.connect(self.slide_effort)
        popup_layout.addWidget(self.effort_slider)
        self.effort_selector.setParent(self.model_popup)
        self.effort_selector.hide()
        self.model_effort_button = self.button("Model / Effort", self.show_model_popup)
        self.model_effort_button.setToolTip("Select model and effort")
        self.model_effort_button.setAccessibleName("Select model and effort")
        self.sync_model_controls()

        # Keep long responses and the composer within a comfortable reading width.
        reading_row = QtWidgets.QHBoxLayout()
        reading_row.setContentsMargins(24, 0, 24, 0)
        reading_row.addStretch(1)
        reading = QtWidgets.QWidget()
        reading.setMaximumWidth(880)
        reading.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        body = QtWidgets.QVBoxLayout(reading)
        body.setContentsMargins(0, 0, 0, 16)
        body.setSpacing(12)
        reading_row.addWidget(reading, 10)
        reading_row.addStretch(1)
        outer.addLayout(reading_row, 1)
        self.pages = QtWidgets.QStackedWidget()
        self.pages.addWidget(self.build_welcome())
        self.conversation = Conversation()
        self.conversation.jump_button.setIcon(icon("chevron-down"))
        self.conversation.setObjectName("conversation")
        self.conversation.setAccessibleName("Assistant conversation")
        self.conversation.setOpenExternalLinks(False)
        self.conversation.setOpenLinks(False)
        self.conversation.anchorClicked.connect(self.open_source)
        self.conversation.document().setDocumentMargin(16)
        # Inline chevrons use drawn icons so they render independently of fonts.
        for state, direction in (("collapsed", "right"), ("expanded", "down")):
            self.conversation.document().addResource(
                QtGui.QTextDocument.ImageResource, QtCore.QUrl(f"sakir-icon:activity-{state}"),
                icon(f"chevron-{direction}", "#697180").pixmap(24, 24).toImage())
        self.conversation.document().addResource(
            QtGui.QTextDocument.ImageResource, QtCore.QUrl("sakir-icon:progress"),
            icon("document", "#697180").pixmap(24, 24).toImage())
        self.conversation.document().addResource(
            QtGui.QTextDocument.ImageResource, QtCore.QUrl("sakir-icon:copy"),
            icon("copy", "#697180").pixmap(40, 40).toImage())
        self.conversation.document().setDefaultStyleSheet(
            "body { color: #252a34; font-family: 'Segoe UI'; font-size: 11pt; }"
            "p { margin-top: 8px; margin-bottom: 12px; line-height: 150%; }"
            "pre { color: #33455e; white-space: pre-wrap; font-family: Consolas; margin: 0; }"
            "code { font-family: Consolas; color: #33455e; }"
            "a { color: #2563ad; text-decoration: none; }"
            "th, td { padding: 8px; } h1, h2, h3 { color: #202630; }"
        )
        self.pages.addWidget(self.conversation)
        body.addWidget(self.pages, 1)
        self.question_panel=ClarificationPanel(controller,lambda:self.intent.currentIndex()==1,
            lambda:self.intent.setCurrentIndex(1),lambda exc:show_error(self,exc))
        body.addWidget(self.question_panel)
        self.status = self.label(("Settings need repair: " + controller.settings_error) if controller.settings_error else "Ready", "status")
        self.status.setWordWrap(True)
        self.activity_footer = QtWidgets.QWidget()
        self.activity_footer.setObjectName("chatActivityFooter")
        status_row = QtWidgets.QHBoxLayout(self.activity_footer)
        status_row.setContentsMargins(0, 0, 0, 0)
        status_row.setSpacing(8)
        status_row.setAlignment(QtCore.Qt.AlignLeft)
        self.working_indicator = WorkingIndicator()
        self.conversation.set_live_indicator(self.working_indicator)
        placeholder = QtGui.QImage(1, 28, QtGui.QImage.Format_ARGB32)
        placeholder.fill(QtCore.Qt.transparent)
        self.conversation.document().addResource(QtGui.QTextDocument.ImageResource,
            QtCore.QUrl("sakir-icon:live-status"), placeholder)
        status_row.addWidget(self.status, 1)
        self.status.setVisible(bool(controller.settings_error))
        self.activity_footer.setVisible(bool(controller.settings_error))
        body.addWidget(self.activity_footer)
        composer = QtWidgets.QFrame()
        composer.setObjectName("composer")
        composer_layout = QtWidgets.QVBoxLayout(composer)
        composer_layout.setContentsMargins(14, 12, 14, 10)
        composer_layout.setSpacing(8)
        self.attachments = QtWidgets.QListWidget()
        self.attachments.setObjectName("attachments")
        self.attachments.setMaximumHeight(70)
        self.attachments.setAccessibleName("Attached files")
        self.attachments.setToolTip("Double-click to remove an attachment.")
        self.attachments.itemDoubleClicked.connect(self.remove_attachment)
        composer_layout.addWidget(self.attachments)
        self.sync_attachments(sorted(map(str, controller.policy.attachments)))
        self.input = Composer()
        self.input.setObjectName("request")
        self.input.setAccessibleName("Assistant request")
        self.input.setPlaceholderText("Ask anything about your project, or describe a change…")
        self.input.setMinimumHeight(58)
        self.input.setMaximumHeight(150)
        self.input.send_requested.connect(self.send)
        self.input.textChanged.connect(self.resize_composer)
        self.resize_composer()
        composer_layout.addWidget(self.input)
        footer = QtWidgets.QHBoxLayout()
        footer.setSpacing(6)
        attach = self.button("", self.attach, "", "attach")
        attach.setToolTip("Attach files")
        attach.setAccessibleName("Attach files")
        footer.addWidget(attach)
        self.composer_options = QtWidgets.QWidget()
        self.composer_options.setSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed)
        self.model_effort_button.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        option_row = QtWidgets.QHBoxLayout(self.composer_options)
        option_row.setContentsMargins(0,0,0,0)
        option_row.setSpacing(6)
        self.intent = ComboBox()
        self.intent.addItems(["Explain / Inspect", "Create Changes"])
        self.intent.setAccessibleName("Assistant mode")
        self.intent.setToolTip("Create Changes stages edits for your review before applying.")
        self.intent.activated.connect(lambda _: self.refresh_models())
        self.intent.setMinimumWidth(100)
        self.intent.setMaximumWidth(182)
        self.intent.setSizePolicy(QtWidgets.QSizePolicy.Fixed,QtWidgets.QSizePolicy.Fixed)
        option_row.addWidget(self.intent)
        option_row.addWidget(self.model_effort_button)
        footer.addWidget(self.composer_options)
        footer.addStretch(1)
        self.stop_button = self.button("Stop", controller.stop, "stop")
        footer.addWidget(self.stop_button)
        self.send_button = self.button("Send", self.send, "primary", "send")
        self.send_button.setIcon(icon("send", "#ffffff"))
        self.send_button.setFixedWidth(80)
        self.stop_button.setFixedWidth(80)
        footer.addWidget(self.send_button)
        composer_layout.addLayout(footer)
        self.composer_layout, self.composer_footer = composer_layout, footer
        self._composer_stacked = None
        body.addWidget(composer)
        self.usage_indicator = UsageIndicator(self)
        self.usage_panel = self.usage_indicator.popup
        usage_layout = QtWidgets.QVBoxLayout(self.usage_panel)
        usage_layout.setContentsMargins(12, 8, 12, 8)
        usage_layout.setSpacing(4)
        usage_layout.setAlignment(QtCore.Qt.AlignTop)
        usage_title = self.label("USAGE", "eyebrow")
        usage_title.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        usage_layout.addWidget(usage_title)
        self.usage_scroll = QtWidgets.QScrollArea()
        self.usage_scroll.setObjectName("usageScroll")
        self.usage_scroll.setWidgetResizable(True)
        self.usage_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.usage_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.usage_scroll.setMinimumHeight(48)
        self.usage_scroll.setMaximumHeight(200)
        usage_layout.addWidget(self.usage_scroll)
        self.usage_status = self.label("Awaiting response", "muted")
        usage_layout.addWidget(self.usage_status)
        self.usage_values = {}
        self.configure_usage()
        self.context_indicator = UsageIndicator(self, kind="context")
        context_layout = QtWidgets.QVBoxLayout(self.context_indicator.popup)
        context_layout.setContentsMargins(12, 10, 12, 10)
        context_layout.setSpacing(8)
        context_layout.setAlignment(QtCore.Qt.AlignTop)
        context_title = self.label("CONTEXT WINDOW", "eyebrow")
        context_title.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        context_layout.addWidget(context_title)
        context_form = QtWidgets.QFormLayout()
        context_form.setContentsMargins(0, 0, 0, 0)
        context_form.setVerticalSpacing(4)
        context_form.setHorizontalSpacing(16)
        self.context_values = {}
        for key, title in (("input_tokens", "Input tokens"), ("capacity", "Model capacity"),
                           ("input_budget", "Input budget"), ("remaining", "Remaining input space"),
                           ("output_reserve", "Output reserve"), ("safety_margin", "Safety margin"),
                           ("compaction_policy", "Auto-compaction"),
                           ("completion_tokens", "Last response output"), ("compactions", "Compactions"),
                           ("counting", "Counting"), ("characters", "Input characters"),
                           ("character_budget", "Character budget"), ("character_remaining", "Remaining characters"), ("status", "Status")):
            label = self.label("", "muted")
            label.setWordWrap(True)
            label.setMinimumWidth(0)
            label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            context_form.addRow(title, label)
            self.context_values[key] = label
        context_layout.addLayout(context_form)
        self.reset_context()
        info = QtWidgets.QHBoxLayout()
        self.context_label = self.label(controller.selection or "Current project", "context")
        self.context_label.setMinimumWidth(0)
        self.context_label.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        self.context_label.setMaximumWidth(440)
        metadata = QtWidgets.QWidget()
        metadata.setMinimumWidth(0)
        metadata.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        metadata_row = QtWidgets.QHBoxLayout(metadata)
        metadata_row.setContentsMargins(0, 0, 0, 0)
        metadata_row.setSpacing(6)
        metadata_row.addWidget(self.context_label)
        metadata_row.addWidget(self.label("·", "muted"))
        metadata_row.addWidget(self.model)
        metadata_row.addWidget(self.label("·", "muted"))
        metadata_row.addWidget(self.current_effort)
        metadata_row.addStretch(1)
        info.addWidget(metadata, 1)
        info.addWidget(self.usage_indicator)
        info.addWidget(self.context_indicator)
        hint = self.label("Enter to send · Shift+Enter for a new line", "muted")
        self.composer_hint = hint
        info.addWidget(hint)
        body.addLayout(info)
        controller.activity.connect(self.on_event)
        controller.busy_changed.connect(self.busy)
        controller.proposal_changed.connect(self.update_review)
        controller.action_changed.connect(self.update_review)
        controller.attachments_changed.connect(self.sync_attachments)
        self.refresh_sessions()
        self.busy(controller.busy)
        for sequence, callback in (("Ctrl+N", self.new), ("Ctrl+B", self.toggle_sidebar),
                                   ("Ctrl+Shift+B", self.toggle_tools_sidebar),
                                   ("Ctrl+L", self.input.setFocus)):
            shortcut = QtWidgets.QShortcut(QtGui.QKeySequence(sequence), self)
            shortcut.activated.connect(callback)
        self.paint_timer = QtCore.QTimer(self)
        self.paint_timer.setInterval(80)
        self.paint_timer.timeout.connect(self.flush_render)
        self.paint_timer.start()
        self._rendered = None
        self.render()
        self.on_event('task_state',controller.task_ledger.projection())

    @staticmethod
    def label(text, name):
        label = QtWidgets.QLabel(text)
        label.setObjectName(name)
        label.setTextFormat(QtCore.Qt.PlainText)
        return label

    @staticmethod
    def button(text, callback, name="", symbol=None):
        button = QtWidgets.QPushButton(text)
        button.setObjectName(name)
        button.setCursor(QtCore.Qt.PointingHandCursor)
        if symbol:
            button.setIcon(icon(symbol))
            button.setIconSize(QtCore.QSize(18, 18))
        button.clicked.connect(callback)
        return button

    def build_welcome(self):
        welcome = QtWidgets.QWidget()
        welcome.setObjectName("welcome")
        self.welcome = welcome
        layout = QtWidgets.QVBoxLayout(welcome)
        layout.setContentsMargins(12, 20, 12, 20)
        layout.setSpacing(14)
        layout.addStretch(2)
        layout.addWidget(self.label("YOUR PROJECT, WITH A LITTLE HELP", "eyebrow"))
        self.hero = self.label("What shall we build?", "hero")
        self.hero.setWordWrap(True)
        layout.addWidget(self.hero)
        subtitle = self.label("Explore your framework, work with data,\nor turn an idea into a reviewed change.", "subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        layout.addSpacing(20)
        suggestions = QtWidgets.QGridLayout()
        suggestions.setSpacing(10)
        self.suggestion_grid = suggestions
        self.suggestion_buttons = []
        prompts = (
            ("Explore the project", "Explain the structure of this project and its main capabilities.", 0),
            ("Build a feature", "Help me plan a new feature for this project. Ask what I would like to build.", 1),
            ("Inspect my data", "Help me inspect a data file. Ask which file I would like to attach.", 0),
            ("Understand callbacks", "Explain how callbacks work in this project, with source references.", 0),
        )
        for i, (title, prompt, mode) in enumerate(prompts):
            button = self.button(title + "  ↗", lambda checked=False, p=prompt, m=mode: self.use_prompt(p, m), "suggestion")
            button.setToolTip(prompt)
            button.setMinimumHeight(54)
            self.suggestion_buttons.append(button)
            suggestions.addWidget(button, i // 2, i % 2)
        layout.addLayout(suggestions)
        layout.addStretch(3)
        # The start screen remains usable in a short or narrow native window.
        scroll = QtWidgets.QScrollArea()
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setWidget(welcome)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        welcome.installEventFilter(self)
        return scroll

    def eventFilter(self, watched, event):
        if watched is getattr(self, "welcome", None) and event.type() == QtCore.QEvent.Resize:
            narrow = event.size().width() < 480
            columns = 1 if narrow else 2
            for i, button in enumerate(self.suggestion_buttons):
                self.suggestion_grid.removeWidget(button)
                self.suggestion_grid.addWidget(button, i // columns, i % columns)
            self.hero.setStyleSheet("font-size: " + ("22pt;" if narrow else "28pt;"))
        return super().eventFilter(watched, event)

    def use_prompt(self, prompt, mode):
        self.intent.setCurrentIndex(mode)
        self.input.setPlainText(prompt)
        self.input.setFocus()

    def resize_composer(self):
        line_height = self.input.fontMetrics().lineSpacing()
        lines = max(self.input.blockCount(), int(self.input.document().size().height()))
        minimum=40 if hasattr(self,'question_panel') and not self.question_panel.isHidden() else 58
        self.input.setFixedHeight(min(150, max(minimum, lines * line_height + 16)))

    def toggle_sidebar(self):
        self._sidebar_preference = self.sidebar.isHidden()
        self.update_sidebar(self._sidebar_preference)

    def remember_sidebar_width(self, position, index):
        if not self._restoring_sidebar:
            if index == 1 and not self.sidebar.isHidden():
                self._sidebar_width = self.splitter.sizes()[0]
            if index == 2 and not self.tools_sidebar.isHidden():
                self._tools_width = self.splitter.sizes()[2]

    def toggle_tools_sidebar(self):
        self._tools_preference = self.tools_sidebar.isHidden()
        self._tools_explicit = self._tools_preference
        self.update_sidebar(self._sidebar_preference and self.width() >= 900)

    def show_tools(self, turn=None):
        self._tools_preference = True
        self._tools_explicit = True
        self.update_sidebar(self._sidebar_preference and self.width() >= 900)
        if turn is not None:
            self.tools_sidebar.show_turn(turn)

    def update_sidebar(self, visible):
        self._restoring_sidebar = True
        try:
            handles = self.splitter.handleWidth()
            tools_visible = self._tools_preference and (self.width() >= 1080 or self._tools_explicit)
            tool_width = min(self._tools_width, max(260, self.width() - 520 - handles), 520) if tools_visible else 0
            visible = visible and (not tools_visible or self.width() >= 1080)
            self.sidebar.setMaximumWidth(min(480, max(220, self.width() - 520 - tool_width - handles * 2)))
            self.sidebar.setVisible(visible)
            self.tools_sidebar.setVisible(tools_visible)
            if hasattr(self, "tools_toggle"):
                self.tools_toggle.setChecked(tools_visible)
            width = min(self._sidebar_width, self.sidebar.maximumWidth()) if visible else 0
            center_width = max(1, self.splitter.width() - width - tool_width - handles * 2)
            self.splitter.setSizes([width, center_width, tool_width])
            if hasattr(self, "model"):
                self.composer_hint.setVisible(center_width >= 600)
                self.reflow_composer(center_width)
                QtCore.QTimer.singleShot(0, self.elide_chat_title)
        finally:
            self._restoring_sidebar = False

    def reflow_composer(self, center_width):
        if not hasattr(self,'composer_options'):
            return
        # The compact controls always share the same row.
        self._composer_stacked = False

    def show_model_popup(self):
        self.model_popup.adjustSize()
        self.model_popup.resize(max(340, self.model_popup.width()), self.model_popup.height())
        point = self.model_effort_button.mapToGlobal(QtCore.QPoint(0, 0))
        screen = QtWidgets.QApplication.screenAt(point) or QtWidgets.QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        self.model_popup.move(max(bounds.left(), min(point.x(), bounds.right() - self.model_popup.width())),
                              max(bounds.top(), point.y() - self.model_popup.height() - 8))
        self.model_popup.show()

    def slide_effort(self, value):
        self.effort_selector.setCurrentIndex(value)
        self.effort_label.setText("Effort · " + self.effort_selector.currentText())
        self.change_effort()

    def session_menu(self, point):
        item = self.session_list.itemAt(point)
        if item is None or self.controller.busy:
            return
        menu = QtWidgets.QMenu(self)
        rename = menu.addAction("Rename chat")
        delete = menu.addAction("Delete chat")
        action = menu.exec_(self.session_list.mapToGlobal(point))
        key = item.data(QtCore.Qt.UserRole)
        try:
            if action == rename:
                title, accepted = QtWidgets.QInputDialog.getText(self, "Rename chat", "Chat name",
                    text=item.data(QtCore.Qt.UserRole + 1))
                if accepted and title.strip():
                    self.controller.store.rename_session(key, title)
            elif action == delete:
                self.controller.store.delete_session(key)
                if key == self.controller.session_id:
                    self.controller.new_session()
            else:
                return
            self.refresh_sessions()
            self._rendered = None
            self.render()
        except Exception as exc:
            show_error(self, exc)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "splitter") and self.splitter.count() == 3:
            self._tools_explicit = False
            self.update_sidebar(self._sidebar_preference and self.width() >= 900)
        if hasattr(self, "_rendered"):
            self._rendered = None
            self.render()

    def refresh_sessions(self):
        self._sessions = dict(self.controller.store.sessions())
        self._session_titles = self.controller.store.session_titles()
        # Include the active conversation even when local history is disabled.
        if self.visible_messages:
            self._sessions[self.controller.session_id] = copy.deepcopy(self.visible_messages)
        self.session_list.clear()
        keys = list(self._sessions)
        if self.controller.session_id in keys:
            keys.remove(self.controller.session_id)
        keys.insert(0, self.controller.session_id)
        for key in keys:
            messages = self._sessions.get(key, [])
            title = next((m["content"] for m in messages if m["role"] == "user"), "New chat")
            title = self._session_titles.get(key) or " ".join(title.split())
            item = QtWidgets.QListWidgetItem(self.session_list)
            item.setText(self.session_list.fontMetrics().elidedText(title, QtCore.Qt.ElideRight, 186))
            item.setToolTip(title)
            item.setData(QtCore.Qt.UserRole, key)
            item.setData(QtCore.Qt.UserRole + 1, title)
            if key == self.controller.session_id:
                self.session_list.setCurrentItem(item)
        self.session_notice.setVisible(not self._sessions)
        self.filter_sessions(self.session_search.text())

    def filter_sessions(self, text):
        for i in range(self.session_list.count()):
            item = self.session_list.item(i)
            item.setHidden(text.casefold() not in item.data(QtCore.Qt.UserRole + 1).casefold())

    def load_session(self, item):
        key = item.data(QtCore.Qt.UserRole)
        if key == self.controller.session_id:
            return
        try:
            self.controller.new_session(copy.deepcopy(self._sessions[key]), key)
        except Exception as exc:
            self.refresh_sessions()
            show_error(self, exc)

    def update_review(self, *_):
        proposal, action = self.controller.proposal, self.controller.action
        self.tools_toggle.setToolTip("Actions timeline · Review pending (Ctrl+Shift+B)" if proposal or action
                                    else "Actions timeline (Ctrl+Shift+B)")
        self.tools_toggle.setText('')
        if proposal:
            # Match retained per-call previews by immutable fingerprint. Drafts
            # loaded from storage also get a card without opening the sidebar.
            found = any(entry.get('preview', {}).get('fingerprint') == proposal.fingerprint
                        for activity in self.turn_activities.values() for entry in activity.entries)
            if not found:
                activity = self.timeline_activity()
                try:
                    text = redact(changes.diff(self.controller.policy, proposal, self.controller.snapshot()))
                    activity.entries.append({'kind': 'changes', 'preview': {
                        'fingerprint': proposal.fingerprint, 'proposal_id': proposal.id,
                        'summary': redact(proposal.summary), 'paths': [edit.path for edit in proposal.edits],
                        'text': text[:48000], 'truncated': len(text) > 48000}})
                except (OSError, AssistantError):
                    pass
        action_fingerprint = digest(action) if action else None
        if action and not any(e.get('fingerprint') == action_fingerprint
                              for a in self.turn_activities.values() for e in a.entries if e['kind'] == 'action'):
            self.timeline_activity().entries.append({
                'kind': 'action', 'fingerprint': action_fingerprint, 'action': snapshot(action),
                'task_id': self.controller._action_task_id, 'status': 'Ready for review',
                'summary': str(redact(f"{action.get('operation', 'Action').capitalize()} · {action.get('tool', 'Session')}"))})
        for activity in self.turn_activities.values():
            activity.proposal_fingerprint = proposal.fingerprint if proposal else None
            activity.applied_proposal_id = self.controller.last_transaction
            activity.busy = self.controller.busy
            for entry in activity.entries:
                if entry['kind'] == 'action':
                    task = self.controller.task_ledger.find(entry.get('task_id')) if entry.get('task_id') else None
                    completion = (task or {}).get('completion', {})
                    owns_task = task and task.get('artifact_id') == entry['fingerprint']
                    if entry['fingerprint'] == action_fingerprint:
                        entry['status'] = 'Ready for review'
                    elif entry['status'].startswith('Executed'):
                        pass  # Keep successful historical actions after the task is revised.
                    elif owns_task and completion.get('dispatched'):
                        entry['status'] = 'Executed · Dispatched'
                    elif owns_task and task.get('last_failure'):
                        entry['status'] = 'Failed · Check task details'
                    elif action:
                        entry['status'] = 'Superseded'
                    else:
                        entry['status'] = 'Dispatching' if task and task['status'] == 'ready_for_review' else 'Unavailable'
                preview = entry.get('preview')
                if preview and preview.get('proposal_id') == self.controller.last_transaction:
                    preview['applied'] = True
        self.tools_sidebar.sync(self.turn_activities, self.visible_messages)
        self._render_pending = True

    def timeline_activity(self):
        if self._active_turn not in self.turn_activities:
            self._active_turn = len(self.visible_messages)
            activity = TurnActivity()
            activity.request_label = 'Loaded draft or action'
            if not self.controller.busy:
                activity.finish()
            self.turn_activities[self._active_turn] = activity
        return self.turn_activities[self._active_turn]

    def showEvent(self, event):
        super().showEvent(event)
        self.paint_timer.start()
        self.render()

    def hideEvent(self, event):
        self.paint_timer.stop()
        super().hideEvent(event)

    def render(self, preserve_scroll=False):
        self._render_pending = False
        preserve_scroll |= self._detail_stream_pending
        self._detail_stream_pending = False
        visible_stream = self.streaming_text if self._message_phase in {None, "final_answer"} else ""
        messages = self.visible_messages
        if self._answer_reveal is not None:
            _, end = self._answer_reveal
            messages = messages[:-1] + [{"role": "pending", "content": messages[-1]["content"][:end]}]
        fingerprint = repr(messages) + visible_stream + repr(
            [(key, [item for item in activity.entries if item["kind"] != "tool" and (activity.expanded or item["kind"] in {'changes', 'interrupted'})], activity.expanded,
              activity.finished_at, activity.open_previews, activity.proposal_fingerprint, activity.applied_proposal_id, activity.busy,
              [(item["id"], item["message_id"], item["status"], item.get('preview')) for item in activity.entries if item["kind"] == "tool"])
             for key, activity in self.turn_activities.items()])
        if fingerprint == self._rendered:
            self.refresh_activity_titles()
            return
        self._rendered = fingerprint
        self.pages.setCurrentIndex(1 if self.visible_messages or visible_stream or self.turn_activities else 0)
        title = next((m["content"] for m in self.visible_messages if m["role"] == "user"), "New chat")
        title = self._session_titles.get(self.controller.session_id) or " ".join(title.split())
        self.chat_title.setToolTip(title)
        self.elide_chat_title()
        parts = []
        message_cache = []
        prompt_metrics = QtGui.QFontMetrics(QtGui.QFont("Segoe UI", 11))
        chat_width = max(1, self.conversation.viewport().width() - 2 * self.conversation.document().documentMargin())
        for index, message in enumerate(messages + ([{"role": "pending", "content": visible_stream}] if visible_stream else [])):
            key = (message["role"], message["content"])
            if message["role"] == "pending":
                formatted = message_html(*key)
            else:
                cached = self._message_cache[index] if index < len(self._message_cache) else None
                formatted = cached[1] if cached is not None and cached[0] == key else message_html(*key)
                message_cache.append((key, formatted))
            if message["role"] == "user":
                longest_line = max((prompt_metrics.horizontalAdvance(line)
                                    for line in message["content"][:8000].splitlines()), default=0)
                width = min(78, max(50, round(100 * (longest_line + 28) / chat_width)))
                formatted = formatted.replace("USER_BUBBLE_WIDTH%", f"{width}%", 1)
                formatted = formatted.replace("<!--USER_COPY-->",
                    f'<a href="sakir-copy:{index}" title="Copy prompt">'
                    '<img src="sakir-icon:copy" width="20" height="20" alt="Copy prompt"></a>')
            parts.append(formatted)
            if index in self.turn_activities:
                parts.append(self.turn_activities[index].render(index, include_tools=False))
        if self._active_turn == len(self.visible_messages) and not visible_stream:
            parts.append(self.turn_activities[self._active_turn].render(self._active_turn, include_tools=False))
        self.conversation.set_live_turn(self._active_turn)
        self.conversation.replace_html("<html><body>" + "".join(parts) + "</body></html>",
                                       preserve_scroll=preserve_scroll)
        self._message_cache = message_cache
        self._activity_titles = {f"sakir-activity:{key}": activity.title for key, activity in self.turn_activities.items()}

    def elide_chat_title(self):
        self.chat_title.setText(self.chat_title.fontMetrics().elidedText(
            self.chat_title.toolTip(), QtCore.Qt.ElideRight, max(1, self.chat_title.width())))

    def refresh_activity_titles(self):
        titles = {f"sakir-activity:{key}": activity.title for key, activity in self.turn_activities.items()}
        if titles != self._activity_titles:
            self.conversation.update_activity_titles(titles)
            self._activity_titles = titles

    def flush_render(self):
        if self._answer_reveal is not None:
            deadline, end = self._answer_reveal
            text = self.visible_messages[-1]["content"]
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._answer_reveal = None
            else:
                step = max(24, round((len(text) - end) * min(1, 0.08 / remaining)))
                end = self.reveal_boundary(text, end + step)
                self._answer_reveal = (deadline, end) if end < len(text) else None
            self._render_pending = True
        if self._render_pending:
            started = time.perf_counter()
            self.render()
            # Leave time for input/Stop even when a very long chat costs more.
            self.paint_timer.setInterval(max(80, min(1000, round((time.perf_counter() - started) * 4000))))
        else:
            self.refresh_activity_titles()

    @staticmethod
    def reveal_boundary(text, offset):
        # Prefer a word break, with a bounded lookahead for code and URLs.
        boundary = re.search(r"\s", text[offset:offset + 32])
        return offset + boundary.start() if boundary else min(offset, len(text))

    def open_source(self, url):
        if url.scheme() in {'sakir-diff', 'sakir-review'}:
            if url.host() or url.query() or url.fragment() or not re.fullmatch(r'[0-9]{1,9}/[0-9]{1,9}', url.path()):
                return
            turn, index = map(int, url.path().split('/'))
            activity = self.turn_activities.get(turn)
            if activity is None or index >= len(activity.entries):
                return
            preview = activity.entries[index].get('preview')
            if not preview:
                return
            if url.scheme() == 'sakir-diff':
                activity.open_previews.symmetric_difference_update({index})
                self.render(preserve_scroll=True)
            elif (not self.controller.busy and self.controller.proposal
                  and preview.get('fingerprint') == self.controller.proposal.fingerprint):
                self.review()
            return
        if url.scheme() == "sakir-copy":
            if not url.host() and not url.query() and not url.fragment() and re.fullmatch(r"[0-9]{1,9}", url.path()):
                index = int(url.path())
                if index < len(self.visible_messages) and self.visible_messages[index]["role"] == "user":
                    QtWidgets.QApplication.clipboard().setText(self.visible_messages[index]["content"])
            return
        if url.scheme() == "sakir-tools":
            if not url.host() and not url.query() and not url.fragment() and re.fullmatch(r"[0-9]{1,9}", url.path()):
                self.show_tools(int(url.path()))
            return
        if url.scheme() == "sakir-activity":
            if not url.host() and not url.query() and not url.fragment() and re.fullmatch(r"[0-9]{1,9}", url.path()):
                activity = self.turn_activities.get(int(url.path()))
                if activity is not None:
                    activity.expanded = not activity.expanded
                    self.render(preserve_scroll=True)
            return
        if url.scheme() == "sakir-help":
            try:
                if url.host() or url.query() or url.fragment() or not re.fullmatch(r"[\w.-]{1,100}", url.path()):
                    raise AssistantError("SECTION_NOT_FOUND", "Invalid handbook section link.")
                handbook = self.controller.index.handbook
                handbook.refresh()
                handbook.read(url.path())
                window = self.controller.window._open_help()
                if window is not None:
                    window.navigate_to(url.path())
            except Exception as exc:
                show_error(self, exc)
            return
        if url.scheme() != "sakir-source":
            return
        try:
            start = int(url.fragment().lstrip("L") or "1")
            revision = QtCore.QUrlQuery(url).queryItemValue("revision")
            if revision:
                task = self.controller.task_index
                if not re.fullmatch(r"[0-9a-f]{64}", revision) or task is None or task.cache.get(url.path(), {}).get("content_revision") != revision:
                    raise AssistantError("STALE_REFERENCE", "This source revision is no longer available in this session. Ask Assistant to inspect the current source again.")
                data = task.read(url.path(), start, 120)
            else:
                data = self.controller.index.read(url.path(), start, 120)
            dialog = QtWidgets.QDialog(self)
            dialog.setWindowTitle(data["path"] + ":" + str(start) + (" — " + data["state"] + " snapshot" if revision else ""))
            dialog.resize(950, 650)
            layout = QtWidgets.QVBoxLayout(dialog)
            source = QtWidgets.QPlainTextEdit()
            source.setReadOnly(True)
            source.setFont(QtGui.QFont("Consolas", 10))
            source.setPlainText(data["text"])
            layout.addWidget(source)
            dialog.exec_()
        except Exception as exc:
            show_error(self, exc)

    def configure_usage(self):
        self.usage_indicator.hide_timer.stop()
        self.usage_panel.hide()
        self.usage_values = {}
        content = QtWidgets.QWidget()
        content.setObjectName("usageContent")
        form = QtWidgets.QFormLayout(content)
        form.setContentsMargins(0, 0, 8, 0)
        form.setVerticalSpacing(4)
        form.setHorizontalSpacing(20)
        form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        for entry in self.controller.settings.usage_headers:
            name = QtWidgets.QLabel(entry["display_name"])
            name.setTextFormat(QtCore.Qt.PlainText)
            name.setWordWrap(True)
            name.setFixedWidth(200)
            name.setToolTip(entry["header"])
            value = QtWidgets.QLabel("Awaiting response")
            value.setTextFormat(QtCore.Qt.PlainText)
            value.setWordWrap(True)
            value.setMinimumWidth(0)
            value.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            value.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            value.setAccessibleName(entry["display_name"])
            value.setToolTip(entry["header"])
            form.addRow(name, value)
            self.usage_values[entry["header"].lower()] = value
        old = self.usage_scroll.takeWidget()
        if old is not None:
            old.deleteLater()
        self.usage_scroll.setWidget(content)
        self.usage_scroll.setFixedHeight(min(200, max(48, content.sizeHint().height() + 2)))
        self.usage_status.setText("Awaiting response")
        self.usage_indicator.setVisible(bool(self.usage_values))

    def reset_context(self):
        self.context_indicator.popup.hide()
        settings = resolve_settings(self.controller.settings)
        capacity = capacity_for(settings)
        self.update_context({"base_url": settings.base_url, "model": settings.model,
                             "capacity": capacity, "input_tokens": None, "estimated": True,
                             "input_budget": max(0, capacity - settings.max_tokens - settings.context_margin) if capacity else None,
                             "output_reserve": settings.max_tokens, "safety_margin": settings.context_margin,
                             "compactions": self.controller.context_state.get("compactions", 0),
                             "tokenizer": settings.tokenizer, "characters": 0,
                             "character_budget": character_budget(settings),
                             "status": "Awaiting request"})

    def update_context(self, report):
        settings = self.controller.settings
        if report.get("base_url") != settings.base_url or (not settings.multi_model and report.get("model") != settings.model):
            return
        used, capacity, budget = report.get("input_tokens"), report.get("capacity"), report.get("input_budget")
        fraction = used / capacity if used is not None and capacity else None
        estimated = report.get("estimated", True)
        caption = "Context" if fraction is None else f"Context {'~' if estimated else ''}{fraction:.0%}"
        characters, char_budget = report.get("characters"), report.get("character_budget")
        if not capacity and used is not None and characters is not None and char_budget:
            fraction = characters / char_budget
            caption = f"Context chars {fraction:.0%}"
        self.context_indicator.set_meter(caption, fraction)
        self.context_indicator.setToolTip('Context memory usage, not task completion. Open details for the compaction threshold and output reserve.')
        values = {**report, "capacity": capacity if capacity else "Unknown — set in Settings",
                  "input_tokens": used if used is not None else "Awaiting request",
                  "input_budget": budget if budget is not None else "Unknown",
                  "remaining": max(0, budget - used) if budget is not None and used is not None else "Unknown",
                  "character_remaining": max(0, char_budget - characters) if char_budget and characters is not None else "Unknown",
                  "counting": ("Estimated (" + report.get("tokenizer", "estimate") + ")") if estimated else "Provider-reported (last request)"}
        threshold = settings.compact_threshold
        if not settings.auto_compact:
            values['compaction_policy'] = 'Off; input limits still apply'
        elif budget and capacity:
            trigger = (budget*threshold+99)//100
            values['compaction_policy'] = (f'{threshold}% of input budget: {trigger:,} estimated input tokens '
                f'(≈{trigger/capacity:.0%} of full context). Character guard also applies. '
                'The meter uses full context; compaction is checked before the next request, not predicted from response length.')
        else:
            values['compaction_policy'] = f'{threshold}% of character budget; token capacity unknown'
        values['compaction_policy'] += ' The percentage shows context memory usage, not task completion.'
        for key, label in self.context_values.items():
            value = values.get(key)
            label.setText(f"{value:,}" if type(value) is int else str(value) if value is not None else "—")

    def on_event(self, kind, value):
        if kind in {"user", "turn_resumed", "session", "error"}:
            self._answer_reveal = None
            self._completed_answer = ""
        if kind == 'workflow_diagnostic':
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.text('commentary', 'Technical detail: ' + value['text'])
        elif kind=='task_state':
            self.question_panel.set_projection(value)
            self.pages.setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                QtWidgets.QSizePolicy.Ignored if not self.question_panel.isHidden() else QtWidgets.QSizePolicy.Expanding)
            self.resize_composer()
        elif kind == 'turn_resumed':
            self._active_turn = len(self.visible_messages)
            self.turn_activities[self._active_turn] = TurnActivity()
            self.turn_activities[self._active_turn].request_label = 'Resumed ' + value['summary']
            self.turn_activities[self._active_turn].text('commentary', 'Resumed ' + value['summary'])
            self._message_id = None
            self._message_phase = None
            self.streaming_text = ''
            self.working_indicator.set_running(True)
        elif kind == "user":
            # A loaded draft can occupy the next transcript position without a
            # user message. Keep that request group when a real request arrives.
            next_turn = len(self.visible_messages)
            if next_turn in self.turn_activities:
                saved_activity = self.turn_activities.pop(next_turn)
                archived_turn = 100000000 + len(self.turn_activities)
                self.turn_activities[archived_turn] = saved_activity
                self.tools_sidebar.move_turn(next_turn, archived_turn)
            self.visible_messages.append({"role": "user", "content": value})
            self._active_turn = len(self.visible_messages) - 1
            self.turn_activities[self._active_turn] = TurnActivity()
            self._message_id = None
            self._message_phase = None
            self.streaming_text = ""
            self.refresh_sessions()
        elif kind == "message_started":
            self._completed_answer = ""
            self._message_id = value["id"]
            self._message_phase = value.get("phase", "unclassified")
            self.streaming_text = ""
            self.working_indicator.set_status("Waiting for model…")
        elif kind == "text_delta":
            self.streaming_text += value
            if self._message_phase not in {None, "final_answer"}:
                self.working_indicator.append_model_text("progress", value)
                activity = self.turn_activities.get(self._active_turn)
                if activity is not None:
                    activity.text("pending", value, self._message_id)
                    self._render_pending = True
                    self._detail_stream_pending = True
            else:
                self._render_pending = True
            return
        elif kind == "reasoning_delta":
            self.working_indicator.append_model_text("reasoning", value)
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.text("reasoning", value, self._message_id)
                self._render_pending |= activity.expanded
                self._detail_stream_pending |= activity.expanded
            return
        elif kind == "message_completed":
            text = value.get("text", "")
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.complete_message(value["id"], value["phase"], text)
            if value["phase"] == "commentary":
                self.streaming_text = ""
                self.working_indicator.set_status("Preparing tool actions…")
            else:
                self._completed_answer = text
                if self._message_phase != "final_answer":
                    self.streaming_text = ""
                self.working_indicator.set_status("Finishing response…")
            self._message_phase = value["phase"]
            self._message_id = None
        elif kind in {"tool_started", "tool_completed"}:
            state = value.get("status", "completed") if kind == "tool_completed" else "running"
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.tool(value, completed=kind == "tool_completed")
                entry = next(item for item in reversed(activity.entries) if item['kind'] == 'tool'
                             and (item['id'], item['message_id']) == (value['id'], value['message_id']))
                label = tool_label(entry, self.controller.policy.root)
            else:
                label = tool_label(value, self.controller.policy.root)
            self.working_indicator.set_status(label + (f' · {state}' if state in {'failed', 'interrupted'} else ''))
        elif kind == "finished":
            self.working_indicator.set_running(False)
            response = value.get("text", "") if isinstance(value, dict) else ""
            response = response or self._completed_answer or self.streaming_text
            if response:
                prefix = self.streaming_text if self._message_phase in {None, "final_answer"} else ""
                shown = len(prefix) if response.startswith(prefix) else 0
                self.visible_messages.append({"role": "assistant", "content": response})
                self._answer_reveal = None
                if self.controller.settings.streaming and len(response) - shown > 72:
                    end = self.reveal_boundary(response, shown + 32)
                    self._answer_reveal = (time.monotonic() + 0.9, end)
                    self.paint_timer.setInterval(80)
            self._completed_answer = ""
            self.streaming_text = ""
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.complete_message(self._message_id, "final_answer")
                activity.finish()
            self._message_id = None
            self._message_phase = None
        elif kind in {"status", "error"}:
            self.status.setText(value)
            self.working_indicator.set_status(value)
            if kind == "error":
                self.working_indicator.set_running(False)
                self.context_values["status"].setText("Stopped" if "CANCELLED" in str(value) else "Request failed")
                activity = self.turn_activities.get(self._active_turn)
                if activity is not None:
                    activity.complete_message(self._message_id, "interrupted", self.streaming_text)
                    activity.finish()
                self.streaming_text = ""
                self._message_id = None
                self._message_phase = None
                self.visible_messages.append({"role": "error", "content": value})
        elif kind == "tool_result":
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                activity.tool_result(value)
            if value["tool"] == "inspect_file" and value["result"].get("ok"):
                self.data_preview = value["result"]["data"]
                data = self.data_preview if isinstance(self.data_preview, dict) else {}
                self.timeline_activity().entries.append({'kind': 'data', 'path': data.get('path', 'Inspected data'),
                                                        'result': snapshot(value['result'])})
                self.update_review()
        elif kind == "session":
            self.working_indicator.set_running(False)
            self.turn_activities.clear()
            self.tools_sidebar.clear()
            self._active_turn = self._message_id = None
            self._message_phase = None
            self.reset_context()
            self.visible_messages = copy.deepcopy(value)
            self.streaming_text = ""
            self.data_preview = None
            self.input.clear()
            self.update_review()
            self.refresh_sessions()
            self.conversation.jump_to_latest()
        elif kind == "selection":
            self.context_label.setText(value or "Current project")
            self.context_label.setToolTip(value or "Current project")
        elif kind == "coverage":
            self.context_label.setToolTip((self.controller.selection or "Current project") +
                f"\nKnowledge: {value['files']} files, {value['symbols']} symbols, {value['help_topics']} handbook topics" +
                "\nUnsaved overlays: " + (", ".join(value["unsaved_paths"]) or "none") +
                f"\nDiagnostics: {len(value['diagnostics'])}. Open Capabilities for details and refresh.")
        elif kind == "settings":
            self.configure_usage()
            self.reset_context()
            self.model.setText(value or "Configure a local model")
            self.status.setText("Ready")
            self.status.hide()
            self.activity_footer.setVisible(bool(self.controller.settings_error))
            self.model.setToolTip(value or "Choose a model in Settings")
            self.refresh_sessions()
            self.sync_model_controls()
        elif kind == 'model_discovery':
            self.sync_model_controls()
            if value.get('loading') and not self.controller.busy:
                self.status.setText('Refreshing model capabilities…')
                self.status.show()
                self.activity_footer.show()
            if value.get('error'):
                self.refresh_models_button.setToolTip(str(value['error']))
                self.status.setText(str(value['error']))
                self.status.show()
                self.activity_footer.show()
            elif not value.get('loading'):
                self.refresh_models_button.setToolTip('Read server models, capacity and effort support. Keeps drafts/history and does not restart the server.')
                if not self.controller.busy:
                    self.status.hide()
                    self.activity_footer.hide()
                self.sync_model_controls(preserve_edit=True)
                if not value.get('from_task'):
                    self.reset_context()
        elif kind == 'workflow_outcome':
            self.status.setText(value['summary'])
            self.status.setToolTip(' · '.join(str(value.get(k) or '') for k in
                                            ('validation_status', 'review_status', 'current_blocker', 'next_action')))
        elif kind == 'reasoning_effort':
            resolved = value.get('effective') or 'server default'
            self.effort_selector.setToolTip(f"This task: {value['requested']} → {resolved}. Model: {value['model']}\nSupport: {value.get('source','not advertised')}")
        elif kind == 'workflow_stage' and value['status'] == 'running' and 'model' in value:
            activity = self.turn_activities.get(self._active_turn)
            if activity is not None:
                model = value['model'] or 'No compatible model'
                fallback = value.get('fallback')
                reason = (fallback or value['reason']).replace('_', ' ')
                activity.text('commentary', f"{value['role'].title()} · {model} ({reason})")
                self.tools_sidebar.sync(self.turn_activities, self.visible_messages)
        elif kind == "usage_headers":
            settings = self.controller.settings
            if value["base_url"] == settings.base_url and (settings.multi_model or value["model"] == settings.model):
                for header, label in self.usage_values.items():
                    received = value["values"].get(header)
                    label.setText("Not provided" if received is None else received)
                    label.setToolTip(header + ("\n" + received if received is not None else "\nNot provided in the last response"))
                model = value["model"] + " · " if settings.multi_model else ""
                self.usage_status.setText("Last response · " + model + QtCore.QDateTime.currentDateTime().toString("HH:mm:ss"))
        elif kind == "context":
            self.update_context(value)
        elif kind == "context_compacted":
            self.status.setText("Context compacted · continuing…")
            self.working_indicator.set_status("Context compacted · continuing…")
        if kind == "status" and not self.controller.busy:
            self.refresh_sessions()
        if kind in {"user", "turn_resumed", "workflow_diagnostic", "message_started", "message_completed", "tool_started", "tool_completed", "finished", "error", "session"}:
            self.tools_sidebar.sync(self.turn_activities, self.visible_messages)
            self.render()
        elif kind == "tool_result":
            self.tools_sidebar.sync(self.turn_activities, self.visible_messages)
            self._render_pending = True

    def busy(self, value):
        self.question_panel.set_busy(value)
        self.working_indicator.set_running(value)
        self.conversation.position_live_indicator()
        self.activity_footer.setVisible(bool(self.controller.settings_error))
        self.status.setVisible(not value and bool(self.controller.settings_error))
        if value:
            self.status.setText("Starting…")
            self.working_indicator.set_status("Starting…")
        self.send_button.setEnabled(not value)
        self.stop_button.setEnabled(value)
        self.stop_button.setVisible(value)
        self.send_button.setVisible(not value)
        self.new_button.setEnabled(not value)
        self.session_list.setEnabled(not value)
        self.intent.setEnabled(not value)
        self.sync_model_controls()
        self.update_review()

    def sync_model_controls(self, preserve_edit=False):
        from .reasoning import supported_efforts, profile_for
        settings = self.controller.settings
        pending = settings.model
        self.model_selector.blockSignals(True)
        self.model_selector.clear()
        models = sorted({p['model'] for p in settings.model_profiles.values() if isinstance(p, dict)
                         and p.get('base_url') == settings.base_url and isinstance(p.get('model'), str)})
        if self.controller.discovered_models is not None:
            models = list(self.controller.discovered_models)
        known_models = bool(models)
        if settings.model and settings.model not in models:
            models.insert(0, settings.model)
        self.model_selector.addItems(models)
        self.model_selector.setCurrentIndex(self.model_selector.findText(pending))
        self.model_selector.blockSignals(False)
        self.effort_selector.blockSignals(True)
        self.effort_selector.clear()
        levels = supported_efforts(settings)
        self.effort_selector.addItem('Auto' if levels else 'Server default', 'auto')
        for level in levels:
            self.effort_selector.addItem('Off' if level == 'none' else 'Thinking on' if level == 'enabled' else level.title(), level)
        self.effort_selector.setCurrentIndex(max(0, self.effort_selector.findData(settings.reasoning_effort)))
        self.effort_selector.blockSignals(False)
        self.effort_slider.blockSignals(True)
        self.effort_slider.setRange(0, max(0, self.effort_selector.count() - 1))
        self.effort_slider.setValue(self.effort_selector.currentIndex())
        self.effort_slider.blockSignals(False)
        self.effort_label.setText("Effort · " + self.effort_selector.currentText())
        self.current_effort.setText(self.effort_selector.currentText())
        available = not (self.controller.busy or self.controller.discovering_models or self.controller.model_refresh_error)
        self.model_selector.setEnabled(known_models and available)
        self.effort_selector.setEnabled(bool(levels) and available)
        self.effort_slider.setEnabled(bool(levels) and available)
        self.refresh_models_button.setEnabled(not self.controller.discovering_models)
        self.model_selector.setToolTip('Choose a served model. Selection refreshes capabilities; your conversation and draft are kept.')
        if self.controller.model_refresh_error:
            self.model_selector.setToolTip('Capability refresh failed. Use Refresh to retry; selections are locked until it succeeds. '+self.controller.model_refresh_error)
        source = str(profile_for(settings).get('reasoning_source', ''))
        explanation = 'Thinking on/off. Auto keeps the server default. Support: ' if set(levels) <= {'none','enabled'} else 'Model reasoning effort. Auto chooses by task. Support: '
        self.effort_selector.setToolTip((explanation + source) if levels
                                      else 'No reasoning levels advertised. Refresh models; the server default is retained.')
        self.effort_slider.setToolTip(self.effort_selector.toolTip())
        self.current_effort.setToolTip(self.effort_selector.toolTip())

    def change_model(self):
        model = self.model_selector.currentText().strip()
        if model == self.controller.settings.model:
            return
        try:
            self.controller.change_chat_model(model=model)
            self.controller.discover_models()
        except Exception as exc:
            self.sync_model_controls()
            show_error(self, exc)

    def change_effort(self, _=None):
        try:
            self.controller.change_chat_model(effort=self.effort_selector.currentData())
            self.controller.discover_models()
        except Exception as exc:
            self.sync_model_controls()
            show_error(self, exc)

    def refresh_models(self):
        try:
            self.controller.discover_models()
        except Exception as exc:
            show_error(self, exc)

    def send(self):
        if self.controller.busy:
            return
        text = self.input.toPlainText().strip()
        if not text:
            return
        try:
            self.controller.submit(text, self.intent.currentIndex() == 1)
            self.input.clear()
        except Exception as exc:
            show_error(self, exc)

    def settings(self):
        if self.controller.busy:
            show_error(self, "Stop the active task before changing the connection.")
            return
        SettingsDialog(self.controller, self).exec_()
        self.controller.discovered_models = None
        self.refresh_models()
        self.model.setText(self.controller.settings.model or "Configure a local model")
        self.refresh_sessions()

    def new(self):
        try:
            self.controller.new_session()
            self.input.setFocus()
        except Exception as exc:
            show_error(self, exc)

    def history(self):
        try:
            sessions = self.controller.store.sessions()
            labels = [str(i+1) + ". " + (messages[0].get("content", "Empty")[:70] if messages else "Empty") for i, (_, messages) in enumerate(sessions)]
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Conversation History", "Session", labels, 0, False)
            if ok:
                key, messages = sessions[labels.index(choice)]
                self.controller.new_session(messages, key)
        except Exception as exc:
            show_error(self, exc)

    def drafts(self):
        try:
            drafts = self.controller.drafts()
            labels = [str(i+1) + ". " + p.summary[:90] for i, p in enumerate(drafts)]
            if not labels:
                show_error(self, "No saved proposal drafts yet.")
                return
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Saved Proposal Drafts", "Draft (revalidated against the current project)", labels, 0, False)
            if ok:
                self.controller.load_draft(drafts[labels.index(choice)])
                self.review()
        except Exception as exc:
            show_error(self, exc)

    def attach(self):
        files, _ = QtWidgets.QFileDialog.getOpenFileNames(self, "Attach Data or Source", str(self.controller.policy.root / "externals"))
        for filename in files:
            try:
                path = self.controller.policy.attach(filename)
                if not self.attachments.findItems(path, QtCore.Qt.MatchExactly):
                    self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))
            except Exception as exc:
                show_error(self, exc)

    def remove_attachment(self, item):
        self.controller.policy.attachments.discard(Path(item.text()).resolve())
        self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))

    def sync_attachments(self, paths):
        self.attachments.clear()
        self.attachments.addItems(paths)
        self.attachments.setVisible(bool(paths))

    def capabilities(self):
        from .knowledge_ui import KnowledgeDialog
        KnowledgeDialog(self.controller, self).exec_()

    def review(self):
        try:
            ReviewDialog(self.controller, self).exec_()
        except Exception as exc:
            show_error(self, exc)

    def restore(self):
        try:
            self.controller.restore()
            self.review()
        except Exception as exc:
            show_error(self, exc)

    def review_action(self):
        action = copy.deepcopy(self.controller.action)
        if not action:
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Review Session Action")
        dialog.resize(600, 420)
        layout = QtWidgets.QVBoxLayout(dialog)
        text = QtWidgets.QPlainTextEdit()
        text.setReadOnly(True)
        text.setPlainText(json.dumps({k: v for k, v in action.items() if k not in {"runtime_revision", "generation"}}, ensure_ascii=False, indent=2)
                          + "\n\nThis action affects the existing connection/device. File restore cannot undo a transmission.")
        layout.addWidget(text)
        run_button = QtWidgets.QPushButton("Run Action")
        def run_action():
            try:
                self.controller.run_action(digest(action))
                dialog.accept()
            except Exception as exc:
                show_error(dialog, exc)
        run_button.clicked.connect(run_action)
        layout.addWidget(run_button)
        dialog.exec_()

    def preview_tool(self, entry):
        ToolPreviewDialog(entry, self).exec_()

    def timeline_entry(self, record):
        activity = self.turn_activities.get(record['turn'])
        index = record['index']
        if activity is None or not 0 <= index < len(activity.entries):
            return None
        entry = activity.entries[index]
        if record['type'] == 'changes' and entry.get('preview', {}).get('fingerprint') != record.get('fingerprint'):
            return None
        if record['type'] == 'action' and entry.get('fingerprint') != record.get('fingerprint'):
            return None
        return entry

    def preview_timeline(self, record):
        entry = self.timeline_entry(record)
        if entry is None:
            return
        if record['type'] == 'changes' and entry.get('preview'):
            self.preview_tool({'name': 'propose_changes', 'result': {'ok': True}, 'preview': entry['preview']})
        elif record['type'] == 'action' and entry['kind'] == 'action':
            self.preview_tool({'name': 'session_action', 'result': {'data': entry['action']}})
        elif record['type'] == 'data' and entry['kind'] == 'data':
            self.preview_tool({'name': 'inspect_file', 'result': entry['result']})

    def review_timeline(self, record):
        if self.controller.busy or self.timeline_entry(record) is None:
            return
        if (record['type'] == 'changes' and self.controller.proposal
                and record['fingerprint'] == self.controller.proposal.fingerprint):
            self.review()
        elif (record['type'] == 'action' and self.controller.action
              and record['fingerprint'] == digest(self.controller.action)):
            self.review_action()

    def preview_data(self):
        if self.data_preview is None:
            show_error(self, "Ask the assistant to inspect a file first.")
            return
        for activity in reversed(list(self.turn_activities.values())):
            for entry in reversed(activity.entries):
                if (entry["kind"] == "tool" and entry["name"] == "inspect_file"
                        and entry.get("result") and entry["result"].get("ok", True)):
                    self.preview_tool(entry)
                    return
        self.preview_tool({"name": "inspect_file", "result": {"ok": True, "data": self.data_preview}})
