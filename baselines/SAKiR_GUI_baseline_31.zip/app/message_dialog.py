"""Copyable, bounded details for messages with variable-length content."""

import re

from PyQt5 import QtCore, QtWidgets


class MessageDialog(QtWidgets.QDialog):
    DETAILS_MAX_HEIGHT = 240

    def __init__(self, parent, title, text, icon, buttons=QtWidgets.QMessageBox.Ok,
                 default=QtWidgets.QMessageBox.NoButton, *, copy_label="Copy", summary=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self._escape_result = QtWidgets.QMessageBox.NoButton
        self._default_button = None
        layout = QtWidgets.QVBoxLayout(self)
        heading = QtWidgets.QHBoxLayout()
        layout.addLayout(heading)
        icon_label = QtWidgets.QLabel()
        icon_label.setPixmap(QtWidgets.QMessageBox.standardIcon(icon))
        heading.addWidget(icon_label)
        summary_label = QtWidgets.QLabel()
        summary_label.setTextFormat(QtCore.Qt.PlainText)
        summary_label.setWordWrap(True)
        if summary is None:
            if len(text) <= 180 and text.count("\n") <= 2:
                summary = text
            else:
                first_line = text.lstrip().partition("\n")[0] or title
                summary = first_line if len(first_line) <= 180 else first_line[:177] + "…"
        # Allow the summary to wrap paths and identifiers as well as prose.
        summary_label.setText(re.sub(r"\S{24}(?=\S)", lambda match: match[0] + "\u200b", summary))
        heading.addWidget(summary_label, 1)

        self.details = QtWidgets.QTextEdit()
        self.details.setReadOnly(True)
        self.details.setPlainText(text)
        self.details.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.details.hide()
        layout.addWidget(self.details)

        controls = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButtons(int(buttons)))
        layout.addWidget(controls)
        toggle = controls.addButton("Show Details", QtWidgets.QDialogButtonBox.ActionRole)
        toggle.setCheckable(True)
        toggle.setAutoDefault(False)
        toggle.toggled.connect(self._toggle_details)
        self._toggle = toggle
        copy = controls.addButton(copy_label, QtWidgets.QDialogButtonBox.ActionRole)
        copy.setAutoDefault(False)
        copy.clicked.connect(lambda: QtWidgets.QApplication.clipboard().setText(text))
        controls.clicked.connect(self._choose)
        self.controls = controls
        for fallback in (QtWidgets.QDialogButtonBox.Cancel, QtWidgets.QDialogButtonBox.No,
                         QtWidgets.QDialogButtonBox.Ok, QtWidgets.QDialogButtonBox.Close):
            if controls.button(fallback):
                self._escape_result = int(fallback)
                break
        default_button = controls.button(QtWidgets.QDialogButtonBox.StandardButton(int(default)))
        if default_button is None and buttons == QtWidgets.QMessageBox.Ok:
            default_button = controls.button(QtWidgets.QDialogButtonBox.Ok)
        if default_button:
            self.set_default_button(default_button)
        self.resize(500, self.sizeHint().height())

    def _toggle_details(self, expanded):
        self._toggle.setText("Hide Details" if expanded else "Show Details")
        if expanded:
            width = self.contentsRect().width()
            margins = self.layout().contentsMargins()
            self.details.document().setTextWidth(
                width - margins.left() - margins.right() - 2 * self.details.frameWidth()
                - self.style().pixelMetric(QtWidgets.QStyle.PM_ScrollBarExtent))
            height = self.details.document().size().height() + 2 * self.details.frameWidth()
            self.details.setFixedHeight(min(self.DETAILS_MAX_HEIGHT, max(40, int(height + 2))))
        self.details.setVisible(expanded)
        self.layout().activate()
        self.resize(self.width(), self.sizeHint().height())

    def _choose(self, button):
        result = self.controls.standardButton(button)
        if result != QtWidgets.QDialogButtonBox.NoButton:
            self.done(int(result))

    def reject(self):
        self.done(self._escape_result)

    def set_default_button(self, button):
        button.setDefault(True)
        button.setFocus()
        self._default_button = button

    def showEvent(self, event):
        super().showEvent(event)
        if self._default_button:
            self._default_button.setFocus()


def _message(icon):
    def show(parent, title, text, buttons=QtWidgets.QMessageBox.Ok,
             default=QtWidgets.QMessageBox.NoButton, *, summary=None):
        return MessageDialog(parent, title, text, icon, buttons, default, summary=summary).exec_()
    return show


information = _message(QtWidgets.QMessageBox.Information)
warning = _message(QtWidgets.QMessageBox.Warning)
critical = _message(QtWidgets.QMessageBox.Critical)
question = _message(QtWidgets.QMessageBox.Question)
