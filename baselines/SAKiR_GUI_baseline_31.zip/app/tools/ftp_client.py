# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import ftplib
import posixpath
import threading
import json
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict, Any
from enum import Enum
from PyQt5 import QtCore, QtGui, QtWidgets
from app import message_dialog
import shutil
from pathlib import Path

from app.utils import load_json, save_json, FTP_CLIENT_SETTINGS, PROJECT_ROOT
from app.tool_api import ToolCallFuture


# ==========================================================
# Models
# ==========================================================

@dataclass
class TransferItem:
    op: str                 # 'upload' or 'download'
    local_path: str
    remote_path: str
    size: int = 0
    id: int = 0
    cancelled: bool = False
    is_dir: bool = False    # folder transfer?

class OverwriteDecision(Enum):
    ASK = 0
    REPLACE = 1
    SKIP = 2
    CANCEL_ALL = 3


def _norm_local(p: str) -> str:
    return os.path.normpath(p).replace("\\", "/")


def _norm_remote(p: str) -> str:
    return p.replace("\\", "/")


def _remote_norm_abs(p: str) -> str:
    """
    Remote path normalization:
    - ensure starts with "/"
    - collapse "//"
    - remove trailing "/" except root
    """
    if not p:
        return "/"
    p = _norm_remote(p).strip()
    if not p.startswith("/"):
        p = "/" + p
    p = posixpath.normpath(p)
    if not p.startswith("/"):
        p = "/" + p
    return p


# ==========================================================
# FTP backend (worker thread)
# ==========================================================

class FTPBackend(QtCore.QObject):
    """
    Worker-thread FTP backend.

    Supports:
    - connect/disconnect
    - listdir requests (REQ_ID based)
    - upload/download files + folders
    - sequential transfer queue
    """

    # UI signals
    log = QtCore.pyqtSignal(str)
    connected = QtCore.pyqtSignal(bool, str)  # ok, cwd
    cwd_changed = QtCore.pyqtSignal(str)

    # ===== CHANGED =====
    # listdir now returns req_id + requested path + items
    listed_req = QtCore.pyqtSignal(int, str, str, list, bool, str)  # req_id, req_path, pwd, items, ok, err

    job_progress = QtCore.pyqtSignal(int, int, int)      # job_id, bytes, total
    job_done = QtCore.pyqtSignal(int, bool, str)         # job_id, ok, msg
    api_requested = QtCore.pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.ftp: Optional[ftplib.FTP] = None
        self.timeout = 10
        self._lock = threading.RLock()

        # transfer queue
        self._queue: List[TransferItem] = []
        self._queue_lock = threading.RLock()
        self._busy = False

        # listdir request queue
        self._req_lock = threading.RLock()
        self._req_seq = 0
        self.api_requested.connect(self._run_api_request, QtCore.Qt.QueuedConnection)

    def submit(self, func) -> ToolCallFuture:
        """Run ``func(self)`` in the FTP backend's owning thread."""
        future = ToolCallFuture()
        self.api_requested.emit((func, future))
        return future

    @QtCore.pyqtSlot(object)
    def _run_api_request(self, request):
        func, future = request
        try:
            future.set_result(func(self))
        except BaseException as error:
            future.set_exception(error)

    def _next_req_id(self) -> int:
        with self._req_lock:
            self._req_seq += 1
            return self._req_seq

    # ---------------- Connection ---------------- #

    @QtCore.pyqtSlot(str, int, str, str)
    def connect_to(self, host: str, port: int, user: str, password: str):
        try:
            with self._lock:
                if self.ftp:
                    try:
                        self.ftp.quit()
                    except Exception:
                        pass

                self.ftp = ftplib.FTP()
                self.ftp.connect(host, port, timeout=self.timeout)
                self.ftp.login(user=user, passwd=password)
                self.ftp.set_pasv(True)

                cwd = self.ftp.pwd()
                self.log.emit(f"✅ Connected to {host}:{port} as {user}; CWD={cwd}")
                self.connected.emit(True, cwd)
                self.cwd_changed.emit(cwd)
                return cwd

        except Exception as e:
            self.log.emit(f"❌ Connect failed: {e}")
            self.connected.emit(False, "")
            return False

    @QtCore.pyqtSlot()
    def disconnect(self):
        with self._lock:
            if self.ftp:
                try:
                    self.ftp.quit()
                except Exception:
                    pass
                self.ftp = None
                self.log.emit("🔌 Disconnected")

    # ---------------- Helpers ---------------- #

    def _ensure_connected(self):
        if self.ftp is None:
            raise RuntimeError("Not connected")

    # ---------------- listdir (REQ based) ---------------- #

    @QtCore.pyqtSlot(int, str)
    def listdir_req(self, req_id: int, path: str):
        """
        List directory content for given path.
        Emits listed_req(req_id, req_path, pwd, items, ok, err).
        """
        items: List[Tuple[str, bool, int]] = []
        req_path = _remote_norm_abs(path)
        err = ""
        ok = True

        try:
            with self._lock:
                self._ensure_connected()
                ftp = self.ftp

                # IMPORTANT: ftp session is stateful (cwd). Make listdir stateless
                cur = ftp.pwd()
                try:
                    ftp.cwd(req_path)
                    pwd = ftp.pwd()

                    # Prefer MLSD
                    try:
                        for name, facts in ftp.mlsd():
                            if name in (".", ".."):
                                continue
                            t = facts.get("type", "")
                            is_dir = (t == "dir")
                            size = int(facts.get("size", 0) or 0) if not is_dir else 0
                            items.append((name, is_dir, size))
                    except Exception:
                        # fallback: NLST + SIZE trick
                        names = ftp.nlst()
                        for n in names:
                            base = os.path.basename(n.rstrip("/"))
                            if base in ("", ".", ".."):
                                continue
                            try:
                                s = ftp.size(n) or 0
                                is_dir = False
                            except Exception:
                                is_dir = True
                                s = 0
                            items.append((base, is_dir, s))

                finally:
                    try:
                        ftp.cwd(cur)
                    except Exception:
                        pass

        except Exception as e:
            ok = False
            err = str(e)
            pwd = ""
            self.log.emit(f"❌ LIST failed ({req_path}): {e}")

        self.listed_req.emit(req_id, req_path, pwd, items, ok, err)

    @QtCore.pyqtSlot()
    def go_home(self):
        try:
            with self._lock:
                self._ensure_connected()
                try:
                    self.ftp.cwd("/")
                except Exception:
                    pass
                new = self.ftp.pwd()
                self.cwd_changed.emit(new)
                self.log.emit(f"🏠 Remote home → {new}")
        except Exception as e:
            self.log.emit(f"❌ Remote home failed: {e}")

    # ---------------- Directory ops ---------------- #

    @QtCore.pyqtSlot(str)
    def mkdir(self, abs_remote_dir: str):
        try:
            with self._lock:
                self._ensure_connected()
                self.ftp.mkd(_remote_norm_abs(abs_remote_dir))
                self.log.emit(f"📁 MKDIR {abs_remote_dir}")
        except Exception as e:
            self.log.emit(f"❌ MKDIR failed: {e}")

    @QtCore.pyqtSlot(str)
    def delete(self, abs_remote_file: str):
        try:
            with self._lock:
                self._ensure_connected()
                self.ftp.delete(_remote_norm_abs(abs_remote_file))
                self.log.emit(f"🗑️ DELETE {abs_remote_file}")
        except Exception as e:
            self.log.emit(f"❌ DELETE failed: {e}")

    @QtCore.pyqtSlot(str)
    def rmdir(self, abs_remote_dir: str):
        try:
            with self._lock:
                self._ensure_connected()
                self.ftp.rmd(_remote_norm_abs(abs_remote_dir))
                self.log.emit(f"🗑️ RMDIR {abs_remote_dir}")
        except Exception as e:
            self.log.emit(f"❌ RMDIR failed: {e}")

    @QtCore.pyqtSlot(str, str)
    def rename(self, abs_src: str, abs_dst: str):
        try:
            with self._lock:
                self._ensure_connected()
                self.ftp.rename(_remote_norm_abs(abs_src), _remote_norm_abs(abs_dst))
                self.log.emit(f"✏️ RENAME {abs_src} → {abs_dst}")
        except Exception as e:
            self.log.emit(f"❌ RENAME failed: {e}")

    # ==========================================================
    # Transfer Queue
    # ==========================================================

    @QtCore.pyqtSlot(object)
    def enqueue(self, item: TransferItem):
        with self._queue_lock:
            self._queue.append(item)
        self._pump_queue()

    @QtCore.pyqtSlot(int)
    def cancel_job(self, job_id: int):
        with self._queue_lock:
            for it in self._queue:
                if it.id == job_id:
                    it.cancelled = True
                    self.log.emit(f"⛔ Cancel requested: job {job_id}")
                    return

    def _pump_queue(self):
        with self._queue_lock:
            if self._busy:
                return
            if not self._queue:
                return
            self._busy = True

        QtCore.QTimer.singleShot(0, self._run_next)

    @QtCore.pyqtSlot()
    def _run_next(self):
        with self._queue_lock:
            if not self._queue:
                self._busy = False
                return
            item = self._queue.pop(0)

        try:
            if item.cancelled:
                self.job_done.emit(item.id, False, "Cancelled")
                self._run_next()
                return

            if item.op == "upload":
                if item.is_dir:
                    self._upload_dir(item)
                else:
                    self._upload_file(item)

            elif item.op == "download":
                if item.is_dir:
                    self._download_dir(item)
                else:
                    self._download_file(item)
            else:
                raise ValueError("Unknown op")

            self.job_done.emit(item.id, True, "OK")

        except Exception as e:
            self.job_done.emit(item.id, False, str(e))

        self._run_next()

    # ---------------- Transfer impl ---------------- #

    def _upload_file(self, item: TransferItem):
        with self._lock:
            self._ensure_connected()

            local_path = item.local_path
            remote_path = _remote_norm_abs(item.remote_path)

            self._ensure_remote_dir(posixpath.dirname(remote_path) or "/")

            file_size = os.path.getsize(local_path)
            sent = 0

            self.log.emit(f"⬆️ Upload file: {local_path} → {remote_path}")

            with open(local_path, "rb") as f:
                def _cb(chunk: bytes):
                    nonlocal sent
                    if item.cancelled:
                        raise RuntimeError("Cancelled")
                    sent += len(chunk)
                    self.job_progress.emit(item.id, sent, file_size or 1)

                # IMPORTANT: ftplib reads from file itself
                self.ftp.storbinary(
                    f"STOR {remote_path}",
                    f,
                    blocksize=1024 * 64,
                    callback=_cb
                )

    def _ensure_remote_dir(self, remote_dir: str):
        remote_dir = _remote_norm_abs(remote_dir)
        if remote_dir in ("", ".", "/"):
            return

        cur = self.ftp.pwd()
        try:
            parts = [p for p in remote_dir.strip("/").split("/") if p]
            self.ftp.cwd("/")
            for p in parts:
                try:
                    self.ftp.cwd(p)
                except Exception:
                    self.ftp.mkd(p)
                    self.ftp.cwd(p)
        finally:
            try:
                self.ftp.cwd(cur)
            except Exception:
                pass

    def _upload_dir(self, item: TransferItem):
        with self._lock:
            self._ensure_connected()

            src_dir = item.local_path
            remote_base = _remote_norm_abs(item.remote_path)
            self.log.emit(f"⬆️ Upload folder: {src_dir} → {remote_base}")

            self._ensure_remote_dir(remote_base)

            total_bytes = 0
            file_list = []
            for root, _, files in os.walk(src_dir):
                for fn in files:
                    fp = os.path.join(root, fn)
                    file_list.append(fp)
                    try:
                        total_bytes += os.path.getsize(fp)
                    except Exception:
                        pass

            done = 0
            for fp in file_list:
                if item.cancelled:
                    raise RuntimeError("Cancelled")

                rel = os.path.relpath(fp, src_dir).replace("\\", "/")
                remote_path = posixpath.join(remote_base, rel)
                remote_dir = posixpath.dirname(remote_path)

                self._ensure_remote_dir(remote_dir)

                with open(fp, "rb") as f:
                    def _cb(chunk: bytes):
                        nonlocal done
                        if item.cancelled:
                            raise RuntimeError("Cancelled")
                        done += len(chunk)
                        self.job_progress.emit(item.id, done, total_bytes or 1)

                    self.ftp.storbinary(
                        f"STOR {remote_path}",
                        f,
                        blocksize=1024 * 64,
                        callback=_cb
                    )

    def _download_file(self, item: TransferItem):
        with self._lock:
            self._ensure_connected()

            remote_path = _remote_norm_abs(item.remote_path)
            local_path = _norm_local(item.local_path)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            total = 0
            expected = item.size or 0

            self.log.emit(f"⬇️ Download file: {remote_path} → {local_path}")

            with open(local_path, "wb") as f:
                def _cb(chunk: bytes):
                    nonlocal total
                    if item.cancelled:
                        raise RuntimeError("Cancelled")
                    f.write(chunk)
                    total += len(chunk)
                    self.job_progress.emit(item.id, total, expected or 1)

                self.ftp.retrbinary(f"RETR {remote_path}", _cb)

    def _remote_is_dir(self, name: str) -> bool:
        cur = self.ftp.pwd()
        try:
            self.ftp.cwd(name)
            return True
        except Exception:
            return False
        finally:
            try:
                self.ftp.cwd(cur)
            except Exception:
                pass

    def _remote_list_simple(self) -> List[str]:
        try:
            return [n for n in self.ftp.nlst() if n not in (".", "..")]
        except Exception:
            return []

    def _download_dir(self, item: TransferItem):
        with self._lock:
            self._ensure_connected()

            remote_dir = _remote_norm_abs(item.remote_path)
            local_dir = _norm_local(item.local_path)
            os.makedirs(local_dir, exist_ok=True)

            self.log.emit(f"⬇️ Download folder: {remote_dir} → {local_dir}")

            cur = self.ftp.pwd()
            try:
                self.ftp.cwd(remote_dir)
                base_remote = self.ftp.pwd()

                all_files: List[Tuple[str, int]] = []

                def walk(rem: str):
                    if item.cancelled:
                        raise RuntimeError("Cancelled")
                    self.ftp.cwd(rem)
                    here = self.ftp.pwd()

                    try:
                        entries = list(self.ftp.mlsd())
                        for nm, facts in entries:
                            if nm in (".", ".."):
                                continue
                            t = facts.get("type", "")
                            if t == "dir":
                                walk(posixpath.join(here, nm))
                                self.ftp.cwd(here)
                            else:
                                sz = int(facts.get("size", 0) or 0)
                                all_files.append((posixpath.join(here, nm), sz))
                    except Exception:
                        names = self._remote_list_simple()
                        for nm in names:
                            base = os.path.basename(nm.rstrip("/"))
                            if base in ("", ".", ".."):
                                continue
                            if self._remote_is_dir(base):
                                walk(posixpath.join(here, base))
                                self.ftp.cwd(here)
                            else:
                                try:
                                    sz = self.ftp.size(base) or 0
                                except Exception:
                                    sz = 0
                                all_files.append((posixpath.join(here, base), sz))

                walk(".")

                total_bytes = sum(sz for _, sz in all_files) or 1
                done = 0

                for rfile, sz in all_files:
                    if item.cancelled:
                        raise RuntimeError("Cancelled")

                    rel = posixpath.relpath(rfile, base_remote)
                    lfile = os.path.join(local_dir, rel).replace("\\", "/")
                    os.makedirs(os.path.dirname(lfile), exist_ok=True)

                    with open(lfile, "wb") as f:
                        def _cb(chunk: bytes):
                            nonlocal done
                            if item.cancelled:
                                raise RuntimeError("Cancelled")
                            f.write(chunk)
                            done += len(chunk)
                            self.job_progress.emit(item.id, done, total_bytes)

                        self.ftp.retrbinary(f"RETR {rfile}", _cb)

            finally:
                try:
                    self.ftp.cwd(cur)
                except Exception:
                    pass


# ==========================================================
# Remote Explorer Model (FTP-backed)
# ==========================================================

@dataclass
class RemoteNode:
    name: str
    is_dir: bool
    size: int = 0
    parent: Optional["RemoteNode"] = None
    children: List["RemoteNode"] = field(default_factory=list)
    loaded: bool = False
    loading: bool = False
    abs_override: Optional[str] = None  # if set, node.path() returns this

    def path(self) -> str:
        if self.abs_override:
            return self.abs_override
        if self.parent is None:
            return "/"
        pp = self.parent.path()
        if pp == "/":
            return "/" + self.name
        return posixpath.join(pp, self.name)



class RemoteFSModel(QtCore.QAbstractItemModel):
    MIME_TYPE = "application/x-ftp-remote-items"

    def __init__(self, backend: FTPBackend, parent=None):
        super().__init__(parent)
        self.backend = backend

        self.root = RemoteNode("/", True, parent=None)
        self.visible_root = self.root
        self.root.loaded = False

        self._pending: Dict[int, RemoteNode] = {}

        self.backend.listed_req.connect(self._on_listed_req)

        self._icon_folder = QtGui.QIcon.fromTheme("folder")
        self._icon_file = QtGui.QIcon.fromTheme("text-x-generic")

    def reset_all(self):
        self.beginResetModel()
        self.root.children.clear()
        self.root.loaded = False
        self.root.loading = False
        self._pending.clear()
        self.endResetModel()

    # ---------- model basics ----------

    def columnCount(self, parent=QtCore.QModelIndex()) -> int:
        return 3

    def rowCount(self, parent=QtCore.QModelIndex()) -> int:
        node = self._node(parent) or self.visible_root
        return len(node.children)

    def index(self, row: int, col: int, parent=QtCore.QModelIndex()) -> QtCore.QModelIndex:
        pnode = self._node(parent) or self.visible_root
        if 0 <= row < len(pnode.children):
            child = pnode.children[row]
            return self.createIndex(row, col, child)
        return QtCore.QModelIndex()

    def parent(self, index: QtCore.QModelIndex) -> QtCore.QModelIndex:
        node = self._node(index)
        if not node:
            return QtCore.QModelIndex()

        p = node.parent
        if p is None:
            return QtCore.QModelIndex()

        # top-level relative to visible_root
        if p is self.visible_root:
            return QtCore.QModelIndex()

        # create parent index relative to its own parent
        pp = p.parent
        if pp is None:
            return QtCore.QModelIndex()

        try:
            row = pp.children.index(p)
        except ValueError:
            row = 0
        return self.createIndex(row, 0, p)

    def data(self, index: QtCore.QModelIndex, role: int):
        if not index.isValid():
            return None
        node: RemoteNode = index.internalPointer()

        if role == QtCore.Qt.DisplayRole:
            if index.column() == 0:
                return node.name
            if index.column() == 1:
                return "" if node.is_dir else str(node.size)
            if index.column() == 2:
                return "dir" if node.is_dir else "file"

        if role == QtCore.Qt.DecorationRole and index.column() == 0:
            return self._icon_folder if node.is_dir else self._icon_file

        if role == QtCore.Qt.ToolTipRole:
            return f"{node.path()}\n{'Directory' if node.is_dir else 'File'}"

        if role == QtCore.Qt.UserRole:
            return {
                "name": node.name,
                "is_dir": node.is_dir,
                "size": node.size,
                "remote_path": node.path(),
            }

        return None

    def headerData(self, section, orient, role):
        if orient == QtCore.Qt.Horizontal and role == QtCore.Qt.DisplayRole:
            return ["Name", "Size", "Type"][section]
        return None

    def flags(self, index: QtCore.QModelIndex):
        if not index.isValid():
            return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsDropEnabled
        node: RemoteNode = index.internalPointer()
        fl = QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsDragEnabled
        if node.is_dir:
            fl |= QtCore.Qt.ItemIsDropEnabled
        return fl

    def hasChildren(self, parent=QtCore.QModelIndex()) -> bool:
        node = self._node(parent) or self.visible_root
        return bool(node.is_dir)

    def canFetchMore(self, parent: QtCore.QModelIndex) -> bool:
        node = self._node(parent) or self.visible_root
        return node.is_dir and not node.loaded and not node.loading

    def fetchMore(self, parent: QtCore.QModelIndex):
        node = self._node(parent) or self.visible_root
        if not node.is_dir or node.loaded or node.loading:
            return

        node.loading = True

        # request listdir of node path
        req_id = int(QtCore.QDateTime.currentMSecsSinceEpoch() & 0x7FFFFFFF)
        self._pending[req_id] = node

        QtCore.QMetaObject.invokeMethod(
            self.backend,
            "listdir_req",
            QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(int, req_id),
            QtCore.Q_ARG(str, node.path()),
        )
    
    def refresh_path(self, abs_path: str):
        """
        Force re-list a directory even if it was already loaded.
        """
        abs_path = _remote_norm_abs(abs_path)

        # If we can find cached node, mark it dirty
        node = self._find_node_by_path(abs_path)
        if node is not None:
            node.loaded = False
            node.loading = False
            node.children.clear()

            # If currently visible, reset to show spinner/empty
            if node is self.visible_root:
                self.beginResetModel()
                self.endResetModel()

            # Trigger fetch
            self.fetchMore(QtCore.QModelIndex())
            return

        # If not cached -> create synthetic and fetch
        self.set_visible_root_path(abs_path)
        self.fetchMore(QtCore.QModelIndex())

    @QtCore.pyqtSlot(int, str, str, list, bool, str)
    def _on_listed_req(self, req_id: int, req_path: str, pwd: str,
                       items: List[Tuple[str, bool, int]], ok: bool, err: str):
        node = self._pending.pop(req_id, None)
        if node is None:
            return

        self.beginResetModel()

        node.children.clear()
        node.loaded = True
        node.loading = False

        if ok:
            for name, is_dir, size in sorted(items, key=lambda x: (not x[1], x[0].lower())):
                if name in (".", ".."):
                    continue
                node.children.append(RemoteNode(name=name, is_dir=is_dir, size=size, parent=node))

        self.endResetModel()

    def _node(self, index: QtCore.QModelIndex) -> Optional[RemoteNode]:
        if index.isValid():
            return index.internalPointer()
        return None

    # ---------- drag support ----------

    def mimeTypes(self) -> List[str]:
        return [self.MIME_TYPE]

    def supportedDragActions(self):
        return QtCore.Qt.CopyAction

    def supportedDropActions(self):
        return QtCore.Qt.CopyAction

    def mimeData(self, indexes: List[QtCore.QModelIndex]) -> QtCore.QMimeData:
        nodes = []
        seen = set()
        for ix in indexes:
            if not ix.isValid() or ix.column() != 0:
                continue
            node: RemoteNode = ix.internalPointer()
            if node and node.parent is not None:
                p = node.path()
                if p not in seen:
                    seen.add(p)
                    nodes.append(node)

        payload = []
        for n in nodes:
            payload.append({
                "name": n.name,
                "is_dir": n.is_dir,
                "size": n.size,
                "remote_path": n.path(),
            })

        md = QtCore.QMimeData()
        md.setData(self.MIME_TYPE, json.dumps(payload).encode("utf-8"))
        return md

    def set_visible_root_path(self, abs_path: str):
        abs_path = _remote_norm_abs(abs_path)
        # find node in cache; if not cached, we just reset model and treat as root placeholder
        node = self._find_node_by_path(abs_path)
        if node is None:
            # create a synthetic node so view can load its children
            node = RemoteNode(
                name=posixpath.basename(abs_path.rstrip("/")) or "/",
                is_dir=True,
                parent=None,
                abs_override=abs_path,
            )
            node.loaded = False
            node.loading = False
            self.visible_root = node
            self.beginResetModel()
            self.endResetModel()
            return

        self.visible_root = node
        self.beginResetModel()
        self.endResetModel()
    
    def _find_node_by_path(self, abs_path: str) -> Optional[RemoteNode]:
        abs_path = _remote_norm_abs(abs_path)

        # visible root might itself already match (esp. synthetic)
        if self.visible_root and self.visible_root.path() == abs_path:
            return self.visible_root

        # Root path
        if abs_path == "/":
            return self.root

        parts = [p for p in abs_path.strip("/").split("/") if p]

        # Walk from real root cache
        cur = self.root
        for part in parts:
            # must be loaded to find child; if not loaded, stop
            if not cur.loaded:
                return None
            nxt = None
            for ch in cur.children:
                if ch.name == part and ch.is_dir:
                    nxt = ch
                    break
            if nxt is None:
                return None
            cur = nxt
        return cur

# ==========================================================
# Local TreeView with remote-drop handler
# ==========================================================

class LocalTreeView(QtWidgets.QTreeView):
    remote_dropped = QtCore.pyqtSignal(list, str)  # items, local_dest_dir
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, e: QtGui.QDragEnterEvent):
        if e.mimeData().hasFormat(RemoteFSModel.MIME_TYPE):
            e.acceptProposedAction()
            return
        super().dragEnterEvent(e)

    def dragMoveEvent(self, e: QtGui.QDragMoveEvent):
        if e.mimeData().hasFormat(RemoteFSModel.MIME_TYPE):
            e.acceptProposedAction()
            return
        super().dragMoveEvent(e)

    def dropEvent(self, e: QtGui.QDropEvent):
        if e.mimeData().hasFormat(RemoteFSModel.MIME_TYPE):
            raw = bytes(e.mimeData().data(RemoteFSModel.MIME_TYPE))
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = []

            if payload:
                # ✅ determine destination folder from drop position
                dest_dir = ""
                idx = self.indexAt(e.pos())
                if idx.isValid():
                    model = self.model()
                    if model is not None:
                        if model.isDir(idx):
                            dest_dir = model.filePath(idx)
                        else:
                            dest_dir = os.path.dirname(model.filePath(idx))
                if not dest_dir:
                    # fallback to current root shown in tree
                    root = self.rootIndex()
                    model = self.model()
                    if model is not None and root.isValid():
                        dest_dir = model.filePath(root)

                self.remote_dropped.emit(payload, dest_dir)
                e.acceptProposedAction()
                return

        super().dropEvent(e)


# ==========================================================
# Remote TreeView with local-drop handler (upload into folder)
# ==========================================================

class RemoteTreeView(QtWidgets.QTreeView):
    local_dropped = QtCore.pyqtSignal(list, str)  # paths, remote_dest_dir

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

        self.get_current_remote_dir = None  # callable returning str

    def dragEnterEvent(self, e: QtGui.QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            return
        super().dragEnterEvent(e)

    def dragMoveEvent(self, e: QtGui.QDragMoveEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            return
        super().dragMoveEvent(e)

    def dropEvent(self, e: QtGui.QDropEvent):
        if e.mimeData().hasUrls():
            urls = e.mimeData().urls()
            paths = [u.toLocalFile() for u in urls if u.toLocalFile()]

            # default destination = current opened remote folder
            remote_dest = "/"
            if callable(self.get_current_remote_dir):
                try:
                    remote_dest = self.get_current_remote_dir() or "/"
                except Exception:
                    remote_dest = "/"

            # if dropped on an item -> override destination
            idx = self.indexAt(e.pos())
            if idx.isValid():
                data = idx.data(QtCore.Qt.UserRole) or {}
                if data.get("is_dir"):
                    remote_dest = data.get("remote_path") or remote_dest
                else:
                    rp = data.get("remote_path") or remote_dest
                    remote_dest = posixpath.dirname(rp) or remote_dest

            if paths:
                self.local_dropped.emit(paths, _remote_norm_abs(remote_dest))
                e.acceptProposedAction()
                return

        super().dropEvent(e)


# ==========================================================
# FTP Client Widget
# ==========================================================

class FTPClientWidget(QtWidgets.QWidget):
    """
    Full FileZilla-like FTP client widget.

    Upgrades:
    - Remote: filesystem explorer model (QTreeView + RemoteFSModel)
    - Remote: address bar + back/forward + home/up
    - Local: address bar + back/forward + home/up
    - Drag remote -> local downloads directly into current local folder (Option 1)
    - Drag local -> remote uploads into dropped folder
    """

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("FTP Client Manager")
        self.resize(1300, 800)

        self._job_seq = 0
        self._jobs: Dict[int, Tuple[TransferItem, QtWidgets.QProgressBar]] = {}
        self._overwrite_policy = OverwriteDecision.ASK

        # local nav state
        self._local_history: List[str] = []
        self._local_hist_i: int = -1
        self._local_nav_block = False

        # remote nav state (address-bar style)
        self._remote_history: List[str] = []
        self._remote_hist_i: int = -1
        self._remote_nav_block = False
        self._remote_cwd: str = "/"

        # ---------------- Connection bar ----------------
        self.host_edit = QtWidgets.QLineEdit()
        self.port_edit = QtWidgets.QLineEdit("21")
        self.user_edit = QtWidgets.QLineEdit()

        self.pass_edit = QtWidgets.QLineEdit()
        self.pass_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.pass_edit.setMinimumWidth(220)

        eye_btn = QtWidgets.QToolButton()
        eye_btn.setText("👁️")
        eye_btn.setToolTip("Show/Hide Password")
        eye_btn.setCursor(QtCore.Qt.PointingHandCursor)
        eye_btn.setFixedSize(22, 22)

        def toggle_echo():
            self.pass_edit.setEchoMode(
                QtWidgets.QLineEdit.Normal
                if self.pass_edit.echoMode() == QtWidgets.QLineEdit.Password
                else QtWidgets.QLineEdit.Password
            )
        eye_btn.clicked.connect(toggle_echo)

        pass_container = QtWidgets.QWidget()
        pass_layout = QtWidgets.QHBoxLayout(pass_container)
        pass_layout.setContentsMargins(0, 0, 0, 0)
        pass_layout.setSpacing(0)
        pass_layout.addWidget(self.pass_edit)
        pass_layout.addWidget(eye_btn)

        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.disconnect_btn = QtWidgets.QPushButton("Disconnect")

        top = QtWidgets.QHBoxLayout()
        for label, w in [
            ("Host", self.host_edit),
            ("Port", self.port_edit),
            ("User", self.user_edit),
            ("Pass", pass_container),
        ]:
            top.addWidget(QtWidgets.QLabel(label))
            top.addWidget(w)
        top.addWidget(self.connect_btn)
        top.addWidget(self.disconnect_btn)

        # ==========================================================
        # Local Navigation Bar (back/forward/home/up + address bar)
        # ==========================================================

        self.local_back_btn = QtWidgets.QToolButton()
        self.local_back_btn.setText("◀")
        self.local_back_btn.setToolTip("Back")

        self.local_fwd_btn = QtWidgets.QToolButton()
        self.local_fwd_btn.setText("▶")
        self.local_fwd_btn.setToolTip("Forward")

        self.local_up_btn = QtWidgets.QToolButton()
        self.local_up_btn.setText("⬆️")
        self.local_up_btn.setToolTip("Up")

        self.local_home_btn = QtWidgets.QToolButton()
        self.local_home_btn.setText("🏠")
        self.local_home_btn.setToolTip("Local Home")

        self.local_pick_btn = QtWidgets.QToolButton()
        self.local_pick_btn.setText("📁")
        self.local_pick_btn.setToolTip("Choose Local Home")

        self.local_path_edit = QtWidgets.QLineEdit(QtCore.QDir.homePath())
        self.local_path_edit.setPlaceholderText("Local path...")
        self.local_path_edit.setClearButtonEnabled(True)

        local_path_bar = QtWidgets.QHBoxLayout()
        local_path_bar.addWidget(QtWidgets.QLabel("Local:"))
        local_path_bar.addWidget(self.local_back_btn)
        local_path_bar.addWidget(self.local_fwd_btn)
        local_path_bar.addWidget(self.local_up_btn)
        local_path_bar.addWidget(self.local_home_btn)
        local_path_bar.addWidget(self.local_path_edit, 1)
        local_path_bar.addWidget(self.local_pick_btn)

        # ==========================================================
        # Remote Navigation Bar (back/forward/home/up + address bar)
        # ==========================================================

        self.remote_back_btn = QtWidgets.QToolButton()
        self.remote_back_btn.setText("◀")
        self.remote_back_btn.setToolTip("Back")

        self.remote_fwd_btn = QtWidgets.QToolButton()
        self.remote_fwd_btn.setText("▶")
        self.remote_fwd_btn.setToolTip("Forward")

        self.remote_up_btn = QtWidgets.QToolButton()
        self.remote_up_btn.setText("⬆️")
        self.remote_up_btn.setToolTip("Up")

        self.remote_home_btn = QtWidgets.QToolButton()
        self.remote_home_btn.setText("🏠")
        self.remote_home_btn.setToolTip("Remote Home")

        self.remote_path_edit = QtWidgets.QLineEdit("/")
        self.remote_path_edit.setPlaceholderText("Remote path...")
        self.remote_path_edit.setClearButtonEnabled(True)

        remote_path_bar = QtWidgets.QHBoxLayout()
        remote_path_bar.addWidget(QtWidgets.QLabel("Remote:"))
        remote_path_bar.addWidget(self.remote_back_btn)
        remote_path_bar.addWidget(self.remote_fwd_btn)
        remote_path_bar.addWidget(self.remote_up_btn)
        remote_path_bar.addWidget(self.remote_home_btn)
        remote_path_bar.addWidget(self.remote_path_edit, 1)

        # ---------------- Local pane ----------------
        self.local_model = QtWidgets.QFileSystemModel(self)
        self.local_model.setRootPath("")

        self.local_view = LocalTreeView()
        self.local_view.setModel(self.local_model)
        self.local_view.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.local_view.setDragEnabled(True)
        self.local_view.setAcceptDrops(True)
        self.local_view.setDragDropMode(QtWidgets.QAbstractItemView.DragDrop)

        # ---------------- Remote pane ----------------
        self.remote_view = RemoteTreeView()
        self.remote_view.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.remote_view.setDragEnabled(True)
        self.remote_view.setAcceptDrops(True)
        self.remote_view.setDragDropMode(QtWidgets.QAbstractItemView.DragDrop)
        self.remote_view.setDefaultDropAction(QtCore.Qt.CopyAction)

        self.remote_view.get_current_remote_dir = lambda: self._remote_cwd

        # ---------------- Splitter ----------------
        split = QtWidgets.QSplitter()

        left = QtWidgets.QWidget()
        lv = QtWidgets.QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.addLayout(local_path_bar)
        lv.addWidget(self.local_view, 1)

        right = QtWidgets.QWidget()
        rv = QtWidgets.QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.addLayout(remote_path_bar)
        rv.addWidget(self.remote_view, 1)

        split.addWidget(left)
        split.addWidget(right)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 1)

        # ---------------- Transfer queue ----------------
        self.queue_table = QtWidgets.QTableWidget(0, 6)
        self.queue_table.setHorizontalHeaderLabels(["ID", "Op", "Local", "Remote", "Progress", "Cancel"])
        self.queue_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.queue_table.horizontalHeader().setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.queue_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.queue_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)

        # ---------------- Log ----------------
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)

        # Layout
        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(split, 4)
        layout.addWidget(QtWidgets.QLabel("Transfer Queue"))
        layout.addWidget(self.queue_table, 2)
        layout.addWidget(QtWidgets.QLabel("Log"))
        layout.addWidget(self.log, 2)

        # ---------------- Backend thread ----------------
        self._thread = QtCore.QThread(self)
        self.backend = FTPBackend()
        self.backend.moveToThread(self._thread)
        self._thread.start()

        # remote model
        self.remote_model = RemoteFSModel(self.backend)
        self.remote_view.setModel(self.remote_model)
        self.remote_view.setColumnWidth(0, 420)

        # ---------------- Signals ----------------
        self.connect_btn.clicked.connect(self._connect)
        self.disconnect_btn.clicked.connect(lambda: QtCore.QMetaObject.invokeMethod(self.backend, "disconnect"))

        self.backend.log.connect(self.log.appendPlainText)
        self.backend.connected.connect(self._on_connected)
        self.backend.cwd_changed.connect(self._on_remote_pwd_signal)
        self.backend.job_progress.connect(self._on_job_progress)
        self.backend.job_done.connect(self._on_job_done)

        # -------- Local interactions --------
        self.local_view.doubleClicked.connect(self._local_double)
        self.local_view.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.local_view.customContextMenuRequested.connect(self._local_menu)

        # local nav buttons
        self.local_pick_btn.clicked.connect(self._pick_local_home)
        self.local_home_btn.clicked.connect(lambda: self._local_go(QtCore.QDir.homePath()))
        self.local_up_btn.clicked.connect(self._local_up)
        self.local_back_btn.clicked.connect(self._local_back)
        self.local_fwd_btn.clicked.connect(self._local_forward)
        self.local_path_edit.returnPressed.connect(self._local_path_entered)

        # remote drop -> local download
        self.local_view.remote_dropped.connect(self._download_items_to_local_dir)

        # -------- Remote interactions --------
        self.remote_view.doubleClicked.connect(self._remote_double_tree)
        self.remote_view.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.remote_view.customContextMenuRequested.connect(self._remote_menu)

        # remote nav buttons
        self.remote_home_btn.clicked.connect(self._remote_home)
        self.remote_up_btn.clicked.connect(self._remote_up)
        self.remote_back_btn.clicked.connect(self._remote_back)
        self.remote_fwd_btn.clicked.connect(self._remote_forward)
        self.remote_path_edit.returnPressed.connect(self._remote_path_entered)

        # local drop -> remote upload into folder
        self.remote_view.local_dropped.connect(self._upload_paths_into_remote_dir)

        # init local root
        self._local_go(QtCore.QDir.homePath(), push_history=True)

        self._load_settings()
        self._update_nav_buttons()

        self._remote_refresh_timer = QtCore.QTimer(self)
        self._remote_refresh_timer.setSingleShot(True)
        self._remote_refresh_timer.timeout.connect(lambda: self.remote_model.refresh_path(self._remote_cwd or "/"))

    # ==========================================================
    # Navigation helpers
    # ==========================================================

    # -------- Local navigation --------

    def _local_go(self, path: str, *, push_history: bool = True):
        path = os.path.abspath(path)
        if not os.path.isdir(path):
            return

        self._local_nav_block = True
        try:
            self.local_view.setRootIndex(self.local_model.index(path))
            self.local_path_edit.setText(_norm_local(path))
        finally:
            self._local_nav_block = False

        if push_history:
            self._push_local_history(path)

        self._update_nav_buttons()

    def _push_local_history(self, path: str):
        path = os.path.abspath(path)
        # truncate forward history
        if self._local_hist_i < len(self._local_history) - 1:
            self._local_history = self._local_history[:self._local_hist_i + 1]
        self._local_history.append(path)
        self._local_hist_i = len(self._local_history) - 1

    def _local_back(self):
        if self._local_hist_i > 0:
            self._local_hist_i -= 1
            self._local_go(self._local_history[self._local_hist_i], push_history=False)

    def _local_forward(self):
        if self._local_hist_i < len(self._local_history) - 1:
            self._local_hist_i += 1
            self._local_go(self._local_history[self._local_hist_i], push_history=False)

    def _local_up(self):
        cur = self.local_path_edit.text().strip()
        if not cur:
            return
        parent = os.path.dirname(cur)
        if parent and os.path.isdir(parent):
            self._local_go(parent)

    def _local_path_entered(self):
        if self._local_nav_block:
            return
        p = self.local_path_edit.text().strip()
        if p and os.path.isdir(p):
            self._local_go(p)

    def _pick_local_home(self):
        start = self.local_path_edit.text() or QtCore.QDir.homePath()
        p = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Local Home Folder", start)
        if p:
            self._local_go(p)

    def _local_double(self, index: QtCore.QModelIndex):
        if not index.isValid():
            return
        if self.local_model.isDir(index):
            p = self.local_model.filePath(index)
            self._local_go(p)

    # -------- Remote navigation --------

    def _remote_set_cwd(self, path: str, *, push_history: bool = True):
        path = _remote_norm_abs(path)
        self._remote_cwd = path

        self._remote_nav_block = True
        try:
            self.remote_path_edit.setText(path)
        finally:
            self._remote_nav_block = False

        if push_history:
            self._push_remote_history(path)

        # ✅ ENTER folder visually (important!)
        self.remote_model.set_visible_root_path(path)

        self._update_nav_buttons()

    def _push_remote_history(self, path: str):
        if self._remote_hist_i < len(self._remote_history) - 1:
            self._remote_history = self._remote_history[:self._remote_hist_i + 1]
        self._remote_history.append(path)
        self._remote_hist_i = len(self._remote_history) - 1

    def _remote_back(self):
        if self._remote_hist_i > 0:
            self._remote_hist_i -= 1
            self._remote_set_cwd(self._remote_history[self._remote_hist_i], push_history=False)

    def _remote_forward(self):
        if self._remote_hist_i < len(self._remote_history) - 1:
            self._remote_hist_i += 1
            self._remote_set_cwd(self._remote_history[self._remote_hist_i], push_history=False)

    def _remote_home(self):
        QtCore.QMetaObject.invokeMethod(self.backend, "go_home", QtCore.Qt.QueuedConnection)
        # the go_home emits cwd_changed => _remote_set_cwd
        # so inside _on_remote_pwd_signal call set_visible_root_path too

    def _on_remote_pwd_signal(self, cwd: str):
        if cwd:
            self._remote_set_cwd(cwd)
            self.remote_model.set_visible_root_path(cwd)

    def _remote_up(self):
        cur = self._remote_cwd or "/"
        parent = posixpath.dirname(cur.rstrip("/")) or "/"
        self._remote_set_cwd(parent)
        self.remote_model.set_visible_root_path(parent)

    def _remote_path_entered(self):
        if self._remote_nav_block:
            return
        p = self.remote_path_edit.text().strip() or "/"
        p = _remote_norm_abs(p)
        self._remote_set_cwd(p)
        self.remote_model.set_visible_root_path(p)

    def _remote_refresh_root(self):
        """
        Ensure root loads and attempt to expand to cwd.
        """
        # trigger root fetch
        if self.remote_model.canFetchMore(QtCore.QModelIndex()):
            self.remote_model.fetchMore(QtCore.QModelIndex())

        # expanding to cwd reliably requires node path indexing
        # We'll simply refresh model; user can expand normally.
        # (If you want auto-expand to cwd path segments, we can add it.)

    def _remote_double_tree(self, index: QtCore.QModelIndex):
        if not index.isValid():
            return
        data = index.data(QtCore.Qt.UserRole) or {}
        if not data:
            return

        if data.get("is_dir"):
            rp = data.get("remote_path") or "/"
            self._remote_set_cwd(rp)  # updates address bar + history
            self.remote_model.set_visible_root_path(rp)  # ENTER folder (important)
        else:
            self._download_items_to_current_local([data])
    # ==========================================================
    # Connection
    # ==========================================================

    def _connect(self):
        host = self.host_edit.text().strip()
        port = int(self.port_edit.text() or 21)
        user = self.user_edit.text().strip()
        pw = self.pass_edit.text()

        self._save_settings()

        QtCore.QMetaObject.invokeMethod(
            self.backend,
            "connect_to",
            QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(str, host),
            QtCore.Q_ARG(int, port),
            QtCore.Q_ARG(str, user),
            QtCore.Q_ARG(str, pw),
        )

    def _on_connected(self, ok: bool, cwd: str):
        if ok:
            self.remote_model.reset_all()
            self._remote_set_cwd(cwd or "/")
        else:
            self.log.appendPlainText("Connection failed.")

    # ==========================================================
    # Context menus
    # ==========================================================

    def _remote_menu(self, pos: QtCore.QPoint):
        idx = self.remote_view.indexAt(pos)
        menu = QtWidgets.QMenu(self)

        menu.addAction("Refresh", self._remote_refresh_root)
        menu.addSeparator()
        menu.addAction("New Folder", self._mkdir_dialog)
        menu.addSeparator()

        if idx.isValid():
            data = idx.data(QtCore.Qt.UserRole) or {}
            name = data.get("name", "")
            is_dir = bool(data.get("is_dir"))
            rp = data.get("remote_path", "")

            if name and name != "/":
                menu.addAction("Rename", lambda: self._rename_dialog(rp))
                if is_dir:
                    menu.addAction("Delete Folder", lambda: self._rmdir(rp))
                    menu.addAction("Download Folder", lambda: self._download_items_to_current_local([data]))
                else:
                    menu.addAction("Delete File", lambda: self._delete(rp))
                    menu.addAction("Download", lambda: self._download_items_to_current_local([data]))

        menu.exec_(self.remote_view.viewport().mapToGlobal(pos))

    def _local_menu(self, pos: QtCore.QPoint):
        indexes = self.local_view.selectedIndexes()
        if not indexes:
            return

        # collect unique selected paths (only col 0)
        selected_paths = []
        seen = set()
        for idx in indexes:
            if idx.column() != 0:
                continue
            p = self.local_model.filePath(idx)
            if p:
                p = os.path.abspath(p)
                if p not in seen:
                    seen.add(p)
                    selected_paths.append(p)

        if not selected_paths:
            return

        menu = QtWidgets.QMenu(self)

        # ---------------- actions ----------------
        menu.addAction(
            "Open in Explorer",
            lambda: self._open_in_explorer(selected_paths[0])
        )

        menu.addSeparator()

        menu.addAction(
            "Upload Selected (to remote cwd)",
            lambda: self._enqueue_upload_from_paths(selected_paths, remote_base=self._remote_cwd)
        )

        menu.addAction(
            "Set as Home",
            lambda: self._local_go(
                selected_paths[0] if os.path.isdir(selected_paths[0])
                else os.path.dirname(selected_paths[0])
            )
        )

        menu.addSeparator()

        menu.addAction(
            "Delete",
            lambda: self._delete_local_paths(selected_paths)
        )

        menu.exec_(self.local_view.viewport().mapToGlobal(pos))

    def _mkdir_dialog(self):
        name, ok = QtWidgets.QInputDialog.getText(self, "New Folder", "Folder name:")
        if not (ok and name):
            return
        abs_dir = posixpath.join(self._remote_cwd or "/", name)
        QtCore.QMetaObject.invokeMethod(self.backend, "mkdir", QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, abs_dir))
        self._remote_refresh_after_action()

    def _rename_dialog(self, abs_src: str):
        base = posixpath.basename(abs_src.rstrip("/")) or abs_src
        dst, ok = QtWidgets.QInputDialog.getText(self, "Rename", f"Rename '{base}' to:")
        if not (ok and dst):
            return
        abs_dst = posixpath.join(posixpath.dirname(abs_src.rstrip("/")) or "/", dst)
        QtCore.QMetaObject.invokeMethod(
            self.backend, "rename", QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(str, abs_src),
            QtCore.Q_ARG(str, abs_dst),
        )
        self._remote_refresh_after_action()

    def _delete(self, abs_file: str):
        QtCore.QMetaObject.invokeMethod(self.backend, "delete", QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, abs_file))
        self._remote_refresh_after_action()

    def _rmdir(self, abs_dir: str):
        QtCore.QMetaObject.invokeMethod(self.backend, "rmdir", QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, abs_dir))
        self._remote_refresh_after_action()

    # ==========================================================
    # Transfers
    # ==========================================================

    def _next_job_id(self) -> int:
        self._job_seq += 1
        return self._job_seq

    def _add_queue_row(self, item: TransferItem) -> QtWidgets.QProgressBar:
        row = self.queue_table.rowCount()
        self.queue_table.insertRow(row)

        self.queue_table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(item.id)))
        self.queue_table.setItem(row, 1, QtWidgets.QTableWidgetItem(item.op))
        self.queue_table.setItem(row, 2, QtWidgets.QTableWidgetItem(item.local_path))
        self.queue_table.setItem(row, 3, QtWidgets.QTableWidgetItem(item.remote_path))

        bar = QtWidgets.QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(0)
        self.queue_table.setCellWidget(row, 4, bar)

        cancel_btn = QtWidgets.QToolButton()
        cancel_btn.setText("⛔")
        cancel_btn.setToolTip("Cancel this job")
        cancel_btn.clicked.connect(lambda: self._cancel_job(item.id))
        self.queue_table.setCellWidget(row, 5, cancel_btn)

        return bar

    def _cancel_job(self, job_id: int):
        it = self._jobs.get(job_id, (None, None))[0]
        if it:
            it.cancelled = True
        QtCore.QMetaObject.invokeMethod(
            self.backend, "cancel_job", QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(int, job_id)
        )

    def _on_job_progress(self, job_id: int, done: int, total: int):
        item_bar = self._jobs.get(job_id)
        if not item_bar:
            return
        _, bar = item_bar
        val = int(done / total * 100) if total else 0
        bar.setValue(max(0, min(100, val)))

    def _on_job_done(self, job_id: int, ok: bool, msg: str):
        item_bar = self._jobs.get(job_id)
        if not item_bar:
            return

        item, bar = item_bar
        if ok:
            bar.setValue(100)
        else:
            if item.cancelled:
                bar.setFormat("Cancelled")
            else:
                bar.setFormat("Failed")

        # ✅ refresh local if download
        if ok and item.op == "download":
            self._refresh_local_path(item.local_path)
            self._refresh_local_path(os.path.dirname(item.local_path))

        # ✅ refresh remote if upload / remote changes
        if ok and item.op == "upload":
            self._remote_refresh_after_action()

        self.log.appendPlainText(
            f"[{job_id}] {item.op}: {os.path.basename(item.local_path)} ⇄ {item.remote_path} => "
            f"{'OK' if ok else 'FAIL'} ({msg})"
        )

    # ---------------- Upload ---------------- #

    def _upload_paths_into_remote_dir(self, paths: List[str], remote_dest_dir: str):
        """
        Drag local -> remote folder will call this.
        """
        self._enqueue_upload_from_paths(paths, remote_base=remote_dest_dir)

    def _enqueue_upload_from_paths(self, paths: List[str], *, remote_base: Optional[str] = None):
        remote_base = _remote_norm_abs(remote_base or self._remote_cwd or "/")

        for p in paths:
            if not p:
                continue
            p = os.path.abspath(p)
            job_id = self._next_job_id()

            if os.path.isdir(p):
                remote_path = posixpath.join(remote_base, os.path.basename(p))
                item = TransferItem(
                    op="upload",
                    local_path=p,
                    remote_path=remote_path,
                    size=0,
                    id=job_id,
                    is_dir=True,
                )
            else:
                remote_path = posixpath.join(remote_base, os.path.basename(p))
                item = TransferItem(
                    op="upload",
                    local_path=p,
                    remote_path=remote_path,
                    size=os.path.getsize(p),
                    id=job_id,
                    is_dir=False,
                )

            bar = self._add_queue_row(item)
            self._jobs[job_id] = (item, bar)

            QtCore.QMetaObject.invokeMethod(
                self.backend,
                "enqueue",
                QtCore.Qt.QueuedConnection,
                QtCore.Q_ARG(object, item),
            )

    # ---------------- Download (Option 1: no dialogs) ---------------- #

    def _download_items_to_current_local(self, remote_items: List[dict]):
        """
        Remote -> Local drop or remote file double click.
        Downloads into current local path (local_path_edit). NO dialogs.
        """
        dest = self.local_path_edit.text().strip() or QtCore.QDir.homePath()
        dest = os.path.abspath(dest)
        os.makedirs(dest, exist_ok=True)

        for data in remote_items:
            name = data.get("name")
            if not name or name in ("..", "/", "."):
                continue

            remote_path = data.get("remote_path")
            if not remote_path:
                # fallback: resolve relative to cwd
                remote_path = posixpath.join(self._remote_cwd or "/", name)

            remote_path = _remote_norm_abs(remote_path)

            is_dir = bool(data.get("is_dir"))
            size = int(data.get("size", 0) or 0)
            job_id = self._next_job_id()

            

            if is_dir:
                local_path = os.path.join(dest, os.path.basename(name))
                # ✅ conflict handling
                if not self._resolve_local_conflict_before_download(local_path, is_dir):
                    continue
                item = TransferItem(
                    op="download",
                    local_path=local_path,
                    remote_path=remote_path,
                    size=0,
                    id=job_id,
                    is_dir=True,
                )
            else:
                local_path = os.path.join(dest, os.path.basename(name))
                # ✅ conflict handling
                if not self._resolve_local_conflict_before_download(local_path, is_dir):
                    continue
                item = TransferItem(
                    op="download",
                    local_path=local_path,
                    remote_path=remote_path,
                    size=size,
                    id=job_id,
                    is_dir=False,
                )

            bar = self._add_queue_row(item)
            self._jobs[job_id] = (item, bar)

            QtCore.QMetaObject.invokeMethod(
                self.backend,
                "enqueue",
                QtCore.Qt.QueuedConnection,
                QtCore.Q_ARG(object, item),
            )
    
    def _download_items_to_local_dir(self, remote_items: List[dict], local_dest_dir: str):
        """
        Remote -> Local drop downloads into drop target folder.
        """
        dest = local_dest_dir.strip() or self.local_path_edit.text().strip() or QtCore.QDir.homePath()
        dest = os.path.abspath(dest)
        os.makedirs(dest, exist_ok=True)

        for data in remote_items:
            name = data.get("name")
            if not name or name in ("..", "/", "."):
                continue

            remote_path = data.get("remote_path") or posixpath.join(self._remote_cwd or "/", name)
            remote_path = _remote_norm_abs(remote_path)

            is_dir = bool(data.get("is_dir"))
            size = int(data.get("size", 0) or 0)
            job_id = self._next_job_id()

            local_path = os.path.join(dest, os.path.basename(name))
            # ✅ conflict handling
            if not self._resolve_local_conflict_before_download(local_path, is_dir):
                continue

            item = TransferItem(
                op="download",
                local_path=local_path,
                remote_path=remote_path,
                size=size if not is_dir else 0,
                id=job_id,
                is_dir=is_dir,
            )

            bar = self._add_queue_row(item)
            self._jobs[job_id] = (item, bar)

            QtCore.QMetaObject.invokeMethod(
                self.backend,
                "enqueue",
                QtCore.Qt.QueuedConnection,
                QtCore.Q_ARG(object, item),
            )

    def _refresh_local_path(self, path: str):
        """
        Force QFileSystemModel to refresh metadata for a file/folder.
        """
        try:
            ix = self.local_model.index(path)
            if ix.isValid():
                # triggers model to stat the entry again
                self.local_model.refresh(ix)
        except Exception:
            pass
    
    def _remote_refresh_after_action(self, delay_ms: int = 250):
        self._remote_refresh_timer.start(delay_ms)

    
    def _ask_overwrite(self, path: str) -> OverwriteDecision:
        """
        Ask user what to do if local destination already exists.
        """
        msg = QtWidgets.QMessageBox(self)
        msg.setIcon(QtWidgets.QMessageBox.Warning)
        msg.setWindowTitle("File already exists")
        msg.setText("Destination already contains this file/folder:")
        msg.setInformativeText(_norm_local(path))

        replace_btn = msg.addButton("Replace", QtWidgets.QMessageBox.AcceptRole)
        skip_btn = msg.addButton("Skip", QtWidgets.QMessageBox.DestructiveRole)
        cancel_btn = msg.addButton("Cancel All", QtWidgets.QMessageBox.RejectRole)

        # Optional: checkbox to apply to all
        cb = QtWidgets.QCheckBox("Apply this choice to all conflicts")
        msg.setCheckBox(cb)

        msg.exec_()

        clicked = msg.clickedButton()

        if clicked == replace_btn:
            decision = OverwriteDecision.REPLACE
        elif clicked == skip_btn:
            decision = OverwriteDecision.SKIP
        else:
            decision = OverwriteDecision.CANCEL_ALL

        if cb.isChecked():
            self._overwrite_policy = decision

        return decision

    def _resolve_local_conflict_before_download(self, local_path: str, is_dir: bool) -> bool:
        """
        Returns True if download can proceed, False if skipped/cancelled.
        """
        local_path = os.path.abspath(local_path)

        exists = os.path.exists(local_path)
        if not exists:
            return True

        # decide using stored overwrite policy
        decision = self._overwrite_policy
        if decision == OverwriteDecision.ASK:
            decision = self._ask_overwrite(local_path)

        if decision == OverwriteDecision.SKIP:
            self.log.appendPlainText(f"⏭️ Skipped existing: {local_path}")
            return False

        if decision == OverwriteDecision.CANCEL_ALL:
            self.log.appendPlainText("⛔ Download cancelled by user.")
            # cancel queued download jobs too (optional)
            self._cancel_all_pending_downloads()
            return False

        # decision == REPLACE
        try:
            if is_dir:
                # replace folder
                import shutil
                shutil.rmtree(local_path)
            else:
                os.remove(local_path)
        except Exception as e:
            message_dialog.critical(
                self,
                "Cannot replace",
                f"Failed to remove existing target:\n{local_path}\n\n{e}"
            )
            return False

        return True

    def _cancel_all_pending_downloads(self):
        """
        Cancel all queued download jobs not started yet.
        """
        for job_id, (it, _) in list(self._jobs.items()):
            if it and it.op == "download":
                it.cancelled = True
                QtCore.QMetaObject.invokeMethod(
                    self.backend, "cancel_job", QtCore.Qt.QueuedConnection,
                    QtCore.Q_ARG(int, job_id)
                )
    
    def _open_in_explorer(self, path: str):
        """
        Open file/folder in OS file browser.
        - If file: selects it
        - If folder: opens it
        """
        try:
            path = os.path.abspath(path)

            if os.path.isdir(path):
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))
                return

            # file -> open parent and select it
            if os.name == "nt":
                # explorer supports selecting file
                os.system(f'explorer /select,"{path}"')
            else:
                # fallback
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(os.path.dirname(path)))
        except Exception as e:
            message_dialog.warning(self, "Open failed", str(e))
    
    def _delete_local_paths(self, paths: List[str]):
        """
        Delete local files/folders safely with confirmation.
        """
        if not paths:
            return

        # Confirm
        txt = "\n".join(_norm_local(p) for p in paths[:10])
        if len(paths) > 10:
            txt += f"\n... (+{len(paths)-10} more)"

        reply = message_dialog.question(
            self,
            "Delete",
            "Are you sure you want to delete these items?\n\n" + txt,
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No
        )
        if reply != QtWidgets.QMessageBox.Yes:
            return

        # Delete
        failed = []
        for p in paths:
            try:
                if os.path.isdir(p):
                    shutil.rmtree(p)
                else:
                    os.remove(p)
            except Exception as e:
                failed.append((p, str(e)))

        # Refresh local view
        # (refresh parent folders)
        for p in paths:
            self._refresh_local_path(os.path.dirname(p))
        self._refresh_local_path(self.local_path_edit.text().strip())

        if failed:
            msg = "\n".join(f"{_norm_local(p)} -> {err}" for p, err in failed[:8])
            if len(failed) > 8:
                msg += f"\n... (+{len(failed)-8} more)"
            message_dialog.warning(self, "Some items could not be deleted", msg)
        else:
            self.log.appendPlainText(f"🗑️ Deleted {len(paths)} item(s).")

    # ==========================================================
    # Settings
    # ==========================================================

    def _load_settings(self):
        try:
            data = load_json(FTP_CLIENT_SETTINGS)
        except Exception:
            data = {}

        self.host_edit.setText(data.get("host", ""))
        self.port_edit.setText(str(data.get("port", 21)))
        self.user_edit.setText(data.get("user", ""))
        self.pass_edit.setText(data.get("password", ""))

        local_home = data.get("local_home", "")
        if local_home:
            resolved_home = (
                local_home
                if os.path.isabs(local_home)
                else os.path.join(PROJECT_ROOT, local_home)
            )
            if os.path.isdir(resolved_home):
                self._local_go(resolved_home)

    def _save_settings(self):
        try:
            local_home = self.local_path_edit.text().strip()
            try:
                local_home = Path(local_home).resolve().relative_to(
                    Path(PROJECT_ROOT).resolve()
                ).as_posix()
            except (OSError, ValueError):
                pass
            data = {
                "host": self.host_edit.text().strip(),
                "port": int(self.port_edit.text() or 21),
                "user": self.user_edit.text().strip(),
                "password": self.pass_edit.text(),
                "local_home": str(local_home).replace("\\", "/"),
            }
            save_json(FTP_CLIENT_SETTINGS, data)
        except Exception as e:
            self.log.appendPlainText(f"⚠️ Failed to save settings: {e}")

    # ==========================================================
    # Buttons enable/disable
    # ==========================================================

    def _update_nav_buttons(self):
        # local
        self.local_back_btn.setEnabled(self._local_hist_i > 0)
        self.local_fwd_btn.setEnabled(self._local_hist_i < len(self._local_history) - 1)

        # remote
        self.remote_back_btn.setEnabled(self._remote_hist_i > 0)
        self.remote_fwd_btn.setEnabled(self._remote_hist_i < len(self._remote_history) - 1)

    # ==========================================================
    # Cleanup
    # ==========================================================

    def closeEvent(self, e: QtGui.QCloseEvent) -> None:
        try:
            self._save_settings()
            self._thread.quit()
            self._thread.wait(1500)
        except Exception:
            pass
        return super().closeEvent(e)
