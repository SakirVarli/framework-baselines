"""Lazy Windows Npcap binding. All packet buffers are copied before returning."""
from __future__ import annotations

import ctypes as C
import os
import threading
from pathlib import Path

from .ethernet import capture_filter


class _Timeval(C.Structure):
    _fields_ = [("seconds", C.c_int32), ("microseconds", C.c_int32)]


class _Header(C.Structure):
    _fields_ = [("ts", _Timeval), ("caplen", C.c_uint32), ("length", C.c_uint32)]


class _Device(C.Structure):
    pass


_Device._fields_ = [("next", C.POINTER(_Device)), ("name", C.c_char_p),
                    ("description", C.c_char_p), ("addresses", C.c_void_p), ("flags", C.c_uint32)]


class _Program(C.Structure):
    _fields_ = [("length", C.c_uint), ("instructions", C.c_void_p)]


class _Stats(C.Structure):
    _fields_ = [("received", C.c_uint), ("dropped", C.c_uint),
               ("interface_dropped", C.c_uint), ("captured", C.c_uint)]


class NpcapBackend:
    def __init__(self):
        if os.name != "nt":
            raise RuntimeError("Raw Ethernet currently requires Windows and Npcap")
        directory = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "Npcap"
        try:
            with os.add_dll_directory(str(directory)):
                self.dll = C.CDLL(str(directory / "wpcap.dll"))
        except OSError as error:
            raise RuntimeError("Npcap could not be loaded. Install Npcap matching the application architecture, then restart the session.") from error
        self.handle = None
        self.lock = threading.Lock()
        self._bind()

    def _bind(self):
        signatures = {
            "pcap_findalldevs": ([C.POINTER(C.POINTER(_Device)), C.c_char_p], C.c_int),
            "pcap_freealldevs": ([C.POINTER(_Device)], None),
            "pcap_create": ([C.c_char_p, C.c_char_p], C.c_void_p),
            "pcap_activate": ([C.c_void_p], C.c_int),
            "pcap_geterr": ([C.c_void_p], C.c_char_p),
            "pcap_close": ([C.c_void_p], None),
            "pcap_datalink": ([C.c_void_p], C.c_int),
            "pcap_setnonblock": ([C.c_void_p, C.c_int, C.c_char_p], C.c_int),
            "pcap_setdirection": ([C.c_void_p, C.c_int], C.c_int),
            "pcap_next_ex": ([C.c_void_p, C.POINTER(C.POINTER(_Header)), C.POINTER(C.POINTER(C.c_ubyte))], C.c_int),
            "pcap_compile": ([C.c_void_p, C.POINTER(_Program), C.c_char_p, C.c_int, C.c_uint32], C.c_int),
            "pcap_setfilter": ([C.c_void_p, C.POINTER(_Program)], C.c_int),
            "pcap_freecode": ([C.POINTER(_Program)], None),
            "pcap_sendpacket": ([C.c_void_p, C.c_void_p, C.c_int], C.c_int),
            "pcap_stats": ([C.c_void_p, C.POINTER(_Stats)], C.c_int),
        }
        for name in ("snaplen", "promisc", "timeout", "buffer_size"):
            signatures[f"pcap_set_{name}"] = ([C.c_void_p, C.c_int], C.c_int)
        for name, (args, result) in signatures.items():
            function = getattr(self.dll, name)
            function.argtypes, function.restype = args, result

    def _error(self):
        return (self.dll.pcap_geterr(self.handle) or b"Unknown Npcap error").decode("utf-8", "replace")

    def enumerate_adapters(self):
        devices = C.POINTER(_Device)()
        error = C.create_string_buffer(256)
        if self.dll.pcap_findalldevs(C.byref(devices), error) != 0:
            raise RuntimeError(error.value.decode("utf-8", "replace"))
        result = []
        try:
            current = devices
            while current:
                device = current.contents
                result.append({"id": device.name.decode("utf-8", "replace"),
                               "name": (device.description or device.name).decode("utf-8", "replace")})
                current = device.next
        finally:
            self.dll.pcap_freealldevs(devices)
        return result

    def open_capture(self, settings):
        error = C.create_string_buffer(256)
        self.handle = self.dll.pcap_create(settings["adapter_id"].encode("utf-8"), error)
        if not self.handle:
            raise RuntimeError(error.value.decode("utf-8", "replace"))
        try:
            for name, value in (("snaplen", settings["snapshot_length"]), ("promisc", int(settings["promiscuous"])),
                                ("timeout", settings["capture_timeout_ms"]), ("buffer_size", settings["driver_buffer_bytes"])):
                if getattr(self.dll, f"pcap_set_{name}")(self.handle, value) != 0:
                    raise RuntimeError(self._error())
            activated = self.dll.pcap_activate(self.handle)
            if activated < 0:
                raise RuntimeError(f"Could not open Ethernet adapter: {self._error()}. Check Npcap access permissions and adapter availability.")
            self.activation_warning = self._error() if activated > 0 else ""
            if self.dll.pcap_datalink(self.handle) != 1:  # DLT_EN10MB
                raise RuntimeError("Selected adapter does not expose Ethernet frames. Choose an Ethernet capture adapter.")
            if settings["capture_direction"] == "in":
                if self.dll.pcap_setdirection(self.handle, 1) != 0:
                    raise RuntimeError(f"Incoming-only capture is unsupported on this adapter: {self._error()}. Select incoming and outgoing capture.")
            expression = capture_filter(settings)
            if expression:
                program = _Program()
                if self.dll.pcap_compile(self.handle, C.byref(program), expression.encode("utf-8"), 1, 0xffffffff) != 0:
                    raise ValueError(f"Invalid capture filter: {self._error()}")
                try:
                    if self.dll.pcap_setfilter(self.handle, C.byref(program)) != 0:
                        raise RuntimeError(self._error())
                finally:
                    self.dll.pcap_freecode(C.byref(program))
            if self.dll.pcap_setnonblock(self.handle, 1, error) != 0:
                raise RuntimeError(error.value.decode("utf-8", "replace"))
        except BaseException:
            self.close()
            raise

    def read_packets(self):
        packets = []
        with self.lock:
            for _ in range(64):
                header, data = C.POINTER(_Header)(), C.POINTER(C.c_ubyte)()
                result = self.dll.pcap_next_ex(self.handle, C.byref(header), C.byref(data))
                if result == 0:
                    break
                if result < 0:
                    raise RuntimeError(f"Ethernet capture failed: {self._error()}")
                value = header.contents
                packets.append((C.string_at(data, value.caplen),
                                value.ts.seconds * 1_000_000_000 + value.ts.microseconds * 1000,
                                {"captured_length": value.caplen, "original_length": value.length,
                                 "timestamp_precision": "microseconds"}))
        return packets

    def send_packet(self, frame):
        with self.lock:
            buffer = C.create_string_buffer(frame)
            if self.dll.pcap_sendpacket(self.handle, buffer, len(frame)) != 0:
                raise RuntimeError(f"Ethernet transmission failed: {self._error()}")

    def get_statistics(self):
        with self.lock:
            stats = _Stats()
            if not self.handle or self.dll.pcap_stats(self.handle, C.byref(stats)) != 0:
                return {"driver_received": None, "driver_dropped": None, "interface_dropped": None}
            # A zero ps_ifdrop can mean unsupported; never promise zero loss.
            return {"driver_received": stats.received, "driver_dropped": stats.dropped,
                    "interface_dropped": stats.interface_dropped or None}

    def close(self):
        with self.lock:
            if self.handle:
                self.dll.pcap_close(self.handle)
                self.handle = None


def enumerate_adapters():
    return NpcapBackend().enumerate_adapters()
