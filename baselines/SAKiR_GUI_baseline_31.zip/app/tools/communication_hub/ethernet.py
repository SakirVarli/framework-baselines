"""Ethernet packet metadata; never buffers across packet boundaries."""
from __future__ import annotations

import re


ETHERNET_DEFAULTS = {
    "adapter_id": "", "adapter_name": "", "promiscuous": False,
    "ether_type": "", "source_mac": "", "destination_mac": "",
    "capture_filter": "", "snapshot_length": 65535,
    "driver_buffer_bytes": 4 * 1024 * 1024, "capture_timeout_ms": 20,
    "capture_direction": "inout", "maximum_frame_size": 1518,
}


def normalize_mac(value: str) -> str:
    value = str(value).strip().replace("-", ":").lower()
    if not re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", value):
        raise ValueError("MAC address must contain six hexadecimal octets, for example 02:00:00:00:00:01")
    return value


def ether_type_value(value) -> int:
    text = str(value).strip()
    result = int(text, 16) if text.lower().startswith("0x") else int(text, 10)
    if not 1536 <= result <= 65535:
        raise ValueError("EtherType must be between 1536 and 65535 (for example 0x88B5)")
    return result


def capture_filter(settings: dict) -> str:
    """Use explicit byte offsets so EtherType filters also match tagged packets."""
    terms = []
    for key, direction in (("source_mac", "src"), ("destination_mac", "dst")):
        if str(settings.get(key, "")).strip():
            terms.append(f"ether {direction} {normalize_mac(settings[key])}")
    if str(settings.get("ether_type", "")).strip():
        value = ether_type_value(settings["ether_type"])
        tag12 = "(ether[12:2] = 0x8100 or ether[12:2] = 0x88a8)"
        tag16 = "(ether[16:2] = 0x8100 or ether[16:2] = 0x88a8)"
        terms.append(f"(ether[12:2] = {value} or ({tag12} and ether[16:2] = {value}) or "
                     f"({tag12} and {tag16} and ether[20:2] = {value}))")
    advanced = str(settings.get("capture_filter", "")).strip()
    if advanced:
        terms.append(f"({advanced})")
    return " and ".join(terms)


def decode_ethernet(frame: bytes) -> tuple[bytes, dict, str]:
    fields = {"vlan_tags": []}
    if len(frame) < 14:
        return bytes(frame), fields, "Ethernet header requires at least 14 captured bytes"
    fields.update(destination_mac=frame[:6].hex(":"), source_mac=frame[6:12].hex(":"))
    offset = 12
    value = int.from_bytes(frame[offset:offset + 2], "big")
    while value in {0x8100, 0x88A8}:
        if len(frame) < offset + 6:
            return bytes(frame), fields, "Truncated Ethernet VLAN header"
        tci = int.from_bytes(frame[offset + 2:offset + 4], "big")
        fields["vlan_tags"].append({"tpid": value, "vlan_id": tci & 0xfff,
                                    "priority": tci >> 13, "dei": bool(tci & 0x1000)})
        offset += 4
        value = int.from_bytes(frame[offset:offset + 2], "big")
    fields["header_length"] = offset + 2
    fields["type_or_length"] = value
    fields["ether_type"] = value if value >= 1536 else None
    fields["payload_length"] = value if value <= 1500 else None
    error = "Reserved Ethernet type/length value" if 1500 < value < 1536 else ""
    return bytes(frame[:offset + 2]), fields, error
