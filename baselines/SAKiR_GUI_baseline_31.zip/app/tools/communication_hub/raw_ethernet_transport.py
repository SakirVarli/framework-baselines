"""Packet transport using bounded, nonblocking Npcap reads off the event loop."""
from __future__ import annotations

import asyncio
import time

from .ethernet import decode_ethernet
from .npcap_backend import NpcapBackend
from .transports import BaseTransport


class RawEthernetTransport(BaseTransport):
    backend_factory = NpcapBackend

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.backend = None
        self.on_packet = None
        self._task = None
        self._send_lock = asyncio.Lock()
        self._stop_event = asyncio.Event()
        self.metrics = {"packets_captured": 0, "packets_submitted": 0,
                        "driver_received": None, "driver_dropped": None, "interface_dropped": None}

    async def start(self):
        if self.running:
            return
        if self._task is not None:
            # A failed capture may still be releasing its previous handle.
            await self._task
            self._task = None
        if not self.config.get("adapter_id", "").strip():
            raise ValueError("Select an Ethernet adapter before starting capture")
        self._status("starting", "Opening Ethernet adapter")
        try:
            self.backend = self.backend_factory()
            await asyncio.to_thread(self.backend.open_capture, self.config)
        except Exception as error:
            if self.backend:
                await asyncio.to_thread(self.backend.close)
            self.backend = None
            self._status("error", str(error))
            raise
        self.running = True
        self._stop_event.clear()
        self.metrics["activation_warning"] = getattr(self.backend, "activation_warning", "")
        detail = self.config.get("adapter_name") or self.config["adapter_id"]
        if self.metrics["activation_warning"]:
            detail += f" · {self.metrics['activation_warning']}"
        self._status("connected", detail)
        self._task = asyncio.create_task(self._run(), name="ethernet-capture")

    async def _run(self):
        next_stats = 0.0
        try:
            while self.running:
                packets = await asyncio.to_thread(self.backend.read_packets)
                # A native read is bounded to 64 packets; only one batch is held.
                for data, timestamp_ns, metadata in packets:
                    metadata = {**metadata, "adapter_id": self.config["adapter_id"],
                                "direction": "incoming" if self.config["capture_direction"] == "in" else "unknown",
                                "origin": "capture"}
                    self.metrics["packets_captured"] += 1
                    if self.on_packet is not None:
                        await self.on_packet(data, timestamp_ns, metadata)
                    else:
                        _, fields, _ = decode_ethernet(data)
                        await self.on_chunk(data, timestamp_ns, "", fields.get("source_mac", ""))
                if time.monotonic() >= next_stats:
                    self.metrics.update(await asyncio.to_thread(self.backend.get_statistics))
                    next_stats = time.monotonic() + 1.0
                if not packets:
                    try:
                        await asyncio.wait_for(self._stop_event.wait(), timeout=0.005)
                    except TimeoutError:
                        pass
        except Exception as error:
            self.running = False
            self._status("error", f"{type(error).__name__}: {error}")
        finally:
            async with self._send_lock:
                try:
                    self.metrics.update(await asyncio.to_thread(self.backend.get_statistics))
                except Exception as error:
                    self.metrics["statistics_error"] = str(error)
                finally:
                    await asyncio.to_thread(self.backend.close)

    async def stop(self):
        self.running = False
        self._stop_event.set()
        if self._task:
            await self._task
        self._task = None
        self._status("stopped", "")

    async def send(self, data: bytes, target: str = ""):
        if target and target != "all":
            raise ValueError("Ethernet destination is encoded in the frame; leave the client target empty")
        _, fields, error = decode_ethernet(data)
        if error:
            raise ValueError(error)
        if not 60 <= len(data) <= self.config["maximum_frame_size"]:
            raise ValueError(f"Supply 60 to {self.config['maximum_frame_size']} frame bytes, excluding FCS. Add explicit padding to short frames.")
        async with self._send_lock:
            if not self.running:
                raise ConnectionError("Ethernet capture is not active")
            # Shield native work and await its completion even during cancellation:
            # never close a handle while a background send still uses it.
            send = asyncio.create_task(asyncio.to_thread(self.backend.send_packet, bytes(data)))
            try:
                await asyncio.shield(send)
            except asyncio.CancelledError:
                await send
                raise
        self.metrics["packets_submitted"] += 1
        return [("", fields["destination_mac"], time.time_ns())]
