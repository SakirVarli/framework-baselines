from __future__ import annotations

import copy
import html
import json
import os
import re
import shutil
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Callable, Iterable, Optional

from PyQt5 import QtCore, QtGui, QtWidgets
from app import message_dialog

from app.branding import FULL_NAME, SHORT_NAME, expand_branding


HELP_SCHEMA_VERSION = 1
MAX_HELP_DEPTH = 8
MAX_HELP_TOPICS = 500
MAX_HTML_LENGTH = 2_000_000
_BLOCKED_TAGS = {"script", "iframe", "object", "embed"}
_BODY_RE = re.compile(r"<body[^>]*>(.*)</body>", re.IGNORECASE | re.DOTALL)
_SLUG_RE = re.compile(r"[^a-z0-9]+")


class HelpDocumentError(ValueError):
    pass


class _HelpHtmlValidator(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.errors: list[str] = []

    def handle_starttag(self, tag, attrs):
        tag = tag.casefold()
        if tag in _BLOCKED_TAGS:
            self.errors.append(f"The <{tag}> element is not supported.")
        for name, value in attrs:
            name = name.casefold()
            value = str(value or "").strip()
            if name.startswith("on"):
                self.errors.append(f"Event attribute {name!r} is not supported.")
            if name in {"href", "src"} and value:
                lowered = value.casefold()
                if not (
                    lowered.startswith("#")
                    or lowered.startswith("http://")
                    or lowered.startswith("https://")
                ):
                    self.errors.append(f"Unsupported link or resource: {value!r}.")


def _validate_html(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise HelpDocumentError(f"{label} must be an HTML string.")
    if len(value) > MAX_HTML_LENGTH:
        raise HelpDocumentError(f"{label} is too large.")
    parser = _HelpHtmlValidator()
    try:
        parser.feed(value)
        parser.close()
    except Exception as exc:
        raise HelpDocumentError(f"{label} contains invalid HTML: {exc}") from exc
    if parser.errors:
        raise HelpDocumentError(f"{label}: {parser.errors[0]}")
    return value


@dataclass
class HelpTopic:
    topic_id: str
    title: str
    body_html: str = ""
    children: list["HelpTopic"] = field(default_factory=list)

    @classmethod
    def from_dict(cls, value: object, *, depth: int = 0) -> "HelpTopic":
        if not isinstance(value, dict):
            raise HelpDocumentError("Each help topic must be an object.")
        if depth >= MAX_HELP_DEPTH:
            raise HelpDocumentError(
                f"Help topics may be nested at most {MAX_HELP_DEPTH} levels deep."
            )
        topic_id = value.get("id")
        title = value.get("title")
        body_html = value.get("body_html", "")
        children = value.get("children", [])
        if not isinstance(topic_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]*", topic_id):
            raise HelpDocumentError(f"Invalid help topic id: {topic_id!r}.")
        if not isinstance(title, str) or not title.strip():
            raise HelpDocumentError(f"Topic {topic_id!r} must have a title.")
        if not isinstance(children, list):
            raise HelpDocumentError(f"Topic {topic_id!r} children must be a list.")
        return cls(
            topic_id=topic_id,
            title=title.strip(),
            body_html=_validate_html(body_html, f"Topic {topic_id!r}"),
            children=[cls.from_dict(child, depth=depth + 1) for child in children],
        )

    def to_dict(self) -> dict:
        return {
            "id": self.topic_id,
            "title": self.title,
            "body_html": self.body_html,
            "children": [child.to_dict() for child in self.children],
        }


@dataclass
class HelpDocument:
    title: str
    topics: list[HelpTopic]
    schema_version: int = HELP_SCHEMA_VERSION

    @classmethod
    def from_dict(cls, value: object) -> "HelpDocument":
        if not isinstance(value, dict):
            raise HelpDocumentError("The help document root must be an object.")
        if value.get("schema_version") != HELP_SCHEMA_VERSION:
            raise HelpDocumentError(
                f"Unsupported help schema version: {value.get('schema_version')!r}."
            )
        title = value.get("title")
        topics = value.get("topics")
        if not isinstance(title, str) or not title.strip():
            raise HelpDocumentError("The help document must have a title.")
        if not isinstance(topics, list) or not topics:
            raise HelpDocumentError("The help document must contain at least one topic.")
        document = cls(
            title=title.strip(),
            topics=[HelpTopic.from_dict(topic) for topic in topics],
        )
        document.validate()
        return document

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "title": self.title,
            "topics": [topic.to_dict() for topic in self.topics],
        }

    def walk(self) -> Iterable[tuple[HelpTopic, int]]:
        def visit(items: list[HelpTopic], depth: int):
            for topic in items:
                yield topic, depth
                yield from visit(topic.children, depth + 1)

        return visit(self.topics, 0)

    def validate(self) -> None:
        seen: set[str] = set()
        count = 0
        for topic, _depth in self.walk():
            count += 1
            if topic.topic_id in seen:
                raise HelpDocumentError(f"Duplicate help topic id: {topic.topic_id!r}.")
            seen.add(topic.topic_id)
            if not topic.title.strip():
                raise HelpDocumentError(f"Topic {topic.topic_id!r} must have a title.")
            _validate_html(topic.body_html, f"Topic {topic.topic_id!r}")
        if count > MAX_HELP_TOPICS:
            raise HelpDocumentError(f"A help document may contain at most {MAX_HELP_TOPICS} topics.")

    def find(self, topic_id: str) -> Optional[HelpTopic]:
        return next((topic for topic, _depth in self.walk() if topic.topic_id == topic_id), None)


def load_help_document(path: str | Path) -> HelpDocument:
    path = Path(path)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HelpDocumentError(f"Could not read {path.name}: {exc}") from exc
    return HelpDocument.from_dict(value)


def save_help_document(document: HelpDocument, path: str | Path) -> None:
    document.validate()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    backup = path.with_name(path.name + ".bak")
    temporary = path.with_name(path.name + ".tmp")
    if path.is_file():
        try:
            load_help_document(path)
        except HelpDocumentError:
            pass
        else:
            shutil.copy2(path, backup)
    try:
        temporary.write_text(
            json.dumps(document.to_dict(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def recovery_help_document(error: str = "") -> HelpDocument:
    detail = html.escape(error or "The bundled help source is unavailable.")
    return HelpDocument(
        title="Help is unavailable",
        topics=[HelpTopic(
            "help-recovery",
            "Help source could not be loaded",
            f"<div class='warning'><p><b>The help handbook could not be opened.</b></p>"
            f"<p>{detail}</p><p>Restore <code>app/data/help.json</code> from a valid "
            "baseline package or its <code>.bak</code> file.</p></div>",
        )],
    )


def _html_body_fragment(value: str) -> str:
    match = _BODY_RE.search(value or "")
    fragment = match.group(1) if match else (value or "")
    return fragment.replace("<!--StartFragment-->", "").replace("<!--EndFragment-->", "").strip()


def _expand_branding_html(value: str) -> str:
    """Expand branding tokens without allowing branding text to become HTML."""
    return str(value).replace("{short_name}", html.escape(SHORT_NAME)).replace(
        "{full_name}", html.escape(FULL_NAME)
    )


def _topic_list_html(topics: list[HelpTopic]) -> str:
    parts = ["<ol>"]
    for topic in topics:
        parts.append(
            f'<li><a href="#{html.escape(topic.topic_id, quote=True)}">'
            f"{html.escape(expand_branding(topic.title))}</a>"
        )
        if topic.children:
            parts.append(_topic_list_html(topic.children))
        parts.append("</li>")
    parts.append("</ol>")
    return "".join(parts)


def render_help_html(document: HelpDocument) -> str:
    sections: list[str] = []
    for topic, depth in document.walk():
        heading = min(2 + depth, 6)
        sections.append(
            f'<section><a name="{html.escape(topic.topic_id, quote=True)}"></a>'
            f"<h{heading}>{html.escape(expand_branding(topic.title))}</h{heading}>"
            f"{_expand_branding_html(topic.body_html)}</section>"
        )
    topic_count = sum(1 for _topic, _depth in document.walk())
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><style>
body {{ font-family: 'Segoe UI', sans-serif; font-size: 10.5pt; color: #1f2a35;
       line-height: 1.52; margin: 36px 52px 72px 52px; background: #ffffff; }}
h1 {{ color: #123f68; font-size: 27pt; margin: 0 0 8px 0; }}
h2 {{ color: #123f68; font-size: 18pt; margin-top: 34px; padding-bottom: 6px;
      border-bottom: 2px solid #d9e4ee; }}
h3 {{ color: #2b648f; font-size: 14pt; margin-top: 24px; }}
h4, h5, h6 {{ color: #365b7d; margin-top: 18px; }}
a {{ color: #1261a0; text-decoration: none; }}
code, pre {{ font-family: Consolas, 'Courier New', monospace; background: #f3f6f8; }}
code {{ color: #7a2948; padding: 1px 3px; }}
pre {{ color: #18232d; padding: 14px; border: 1px solid #d4dee7; border-left: 4px solid #7896af;
       white-space: pre-wrap; margin: 12px 0 18px 0; }}
table {{ border-collapse: collapse; margin: 12px 0 20px 0; width: 100%; }}
th {{ color: #173f60; background: #eaf1f7; font-weight: 600; text-align: left; }}
th, td {{ border: 1px solid #bccbd7; padding: 7px 10px; vertical-align: top; }}
.api td:first-child {{ width: 38%; }}
.note, .tip, .warning {{ margin: 14px 0; padding: 11px 15px; border-left: 4px solid #3f7fb5; background: #edf5fb; }}
.tip {{ border-left-color: #33865b; background: #edf8f1; }}
.warning {{ border-left-color: #c27a20; background: #fff5e7; }}
.muted {{ color: #66717d; }}
.lead {{ color: #354c5f; font-size: 12pt; line-height: 1.55; }}
.cover {{ padding: 30px 34px; margin: 0 0 28px 0; background: #edf4fa; border: 1px solid #c7d8e7; }}
.kicker {{ color: #3d6f96; font-size: 9pt; font-weight: 600; letter-spacing: 1px; }}
.edition {{ color: #536d80; margin-top: 16px; }}
.steps li {{ margin-bottom: 8px; }}
section {{ margin-bottom: 22px; }}
</style></head><body>
<a name="contents"></a><div class="cover"><div class="kicker">REFERENCE HANDBOOK</div>
<h1>{html.escape(expand_branding(document.title))}</h1>
<p class="lead">Design, callbacks, built-in tools, communication, delivery, and recovery.</p>
<p class="edition">Schema {document.schema_version} &nbsp;•&nbsp; {topic_count} maintained topics &nbsp;•&nbsp; Baseline authoring and development operation</p></div>
<p class="muted">Select a topic in the contents tree or choose a link below. This contents page is generated from the same topic hierarchy.</p>
<h2>Contents</h2>{_topic_list_html(document.topics)}
{''.join(sections)}
</body></html>"""


class HelpWindow(QtWidgets.QMainWindow):
    def __init__(
        self,
        help_path: str | Path,
        *,
        phase: str = "development",
        admin_check: Optional[Callable[[], bool]] = None,
        parent=None,
    ):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_QuitOnClose, False)
        self.help_path = Path(help_path)
        self.can_edit = phase == "baseline"
        self.admin_check = admin_check or (lambda: True)
        self.load_error = ""
        try:
            self.document_model = load_help_document(self.help_path)
        except HelpDocumentError as exc:
            self.load_error = str(exc)
            self.document_model = recovery_help_document(self.load_error)
        self._saved_model = copy.deepcopy(self.document_model)
        self._dirty = False
        self._editing = False
        self._loading_editor = False
        self._editor_topic_id: Optional[str] = None
        self._history: list[str] = []
        self._history_index = -1
        self._zoom_steps = 0
        self._tree_items: dict[str, QtWidgets.QTreeWidgetItem] = {}
        self._build_ui()
        self._rebuild_tree()
        self._refresh_reader()
        self.navigate_to("contents", record=True)
        if self.load_error:
            self.statusBar().showMessage(f"Recovery help shown: {self.load_error}")

    @property
    def dirty(self) -> bool:
        return self._dirty

    def _build_ui(self):
        self.setWindowTitle(expand_branding(self.document_model.title))
        self.resize(1120, 760)

        self.splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal, self)
        self.contents_tree = QtWidgets.QTreeWidget()
        self.contents_tree.setHeaderHidden(True)
        self.contents_tree.setMinimumWidth(190)
        self.contents_tree.itemSelectionChanged.connect(self._tree_selection_changed)
        self.splitter.addWidget(self.contents_tree)

        right = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.pages = QtWidgets.QStackedWidget()
        self.browser = QtWidgets.QTextBrowser()
        self.browser.setOpenLinks(False)
        self.browser.setOpenExternalLinks(False)
        self.browser.anchorClicked.connect(self._anchor_clicked)
        self.pages.addWidget(self.browser)
        self.editor_panel = self._make_editor_panel()
        self.pages.addWidget(self.editor_panel)
        right_layout.addWidget(self.pages, 1)
        self.find_bar = self._make_find_bar()
        right_layout.addWidget(self.find_bar)
        self.find_bar.hide()
        self.splitter.addWidget(right)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 3)
        self.splitter.setSizes([270, 850])
        self.setCentralWidget(self.splitter)
        self._make_menus()

    def _make_editor_panel(self):
        panel = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        toolbar = QtWidgets.QToolBar("Rich text")
        self.style_combo = QtWidgets.QComboBox()
        self.style_combo.addItems(["Paragraph", "Heading 2", "Heading 3", "Heading 4"])
        self.style_combo.activated.connect(self._apply_paragraph_style)
        toolbar.addWidget(self.style_combo)
        self.size_combo = QtWidgets.QComboBox()
        self.size_combo.setEditable(True)
        self.size_combo.addItems(["8", "9", "10", "11", "12", "14", "16", "18", "24", "30"])
        self.size_combo.setCurrentText("11")
        self.size_combo.activated.connect(self._apply_font_size)
        self.size_combo.lineEdit().returnPressed.connect(self._apply_font_size)
        toolbar.addWidget(self.size_combo)
        toolbar.addSeparator()

        self.bold_action = self._format_action(toolbar, "Bold", QtGui.QKeySequence.Bold, self._toggle_bold)
        self.italic_action = self._format_action(toolbar, "Italic", QtGui.QKeySequence.Italic, self._toggle_italic)
        self.underline_action = self._format_action(toolbar, "Underline", QtGui.QKeySequence.Underline, self._toggle_underline)
        toolbar.addSeparator()
        for label, alignment in (
            ("Left", QtCore.Qt.AlignLeft), ("Center", QtCore.Qt.AlignHCenter),
            ("Right", QtCore.Qt.AlignRight), ("Justify", QtCore.Qt.AlignJustify),
        ):
            toolbar.addAction(label, lambda _checked=False, value=alignment: self.editor.setAlignment(value))
        toolbar.addSeparator()
        toolbar.addAction("Bullets", lambda: self._create_list(QtGui.QTextListFormat.ListDisc))
        toolbar.addAction("Numbering", lambda: self._create_list(QtGui.QTextListFormat.ListDecimal))
        toolbar.addAction("Text color", self._choose_text_color)
        toolbar.addAction("Highlight", self._choose_highlight_color)
        toolbar.addAction("Link", self._insert_link)
        toolbar.addAction("Table", self._insert_table)
        toolbar.addAction("Clear format", self._clear_formatting)
        layout.addWidget(toolbar)
        self.editor = QtWidgets.QTextEdit()
        self.editor.setAcceptRichText(True)
        self.editor.textChanged.connect(self._editor_changed)
        self.editor.currentCharFormatChanged.connect(self._sync_format_actions)
        layout.addWidget(self.editor, 1)
        return panel

    def _format_action(self, toolbar, label, shortcut, slot):
        action = toolbar.addAction(label)
        action.setCheckable(True)
        action.setShortcut(shortcut)
        action.triggered.connect(slot)
        return action

    def _make_find_bar(self):
        bar = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(bar)
        layout.setContentsMargins(5, 3, 5, 3)
        layout.addWidget(QtWidgets.QLabel("Find:"))
        self.find_edit = QtWidgets.QLineEdit()
        self.find_edit.setPlaceholderText("Text in handbook")
        self.find_edit.returnPressed.connect(self.find_next)
        layout.addWidget(self.find_edit, 1)
        layout.addWidget(QtWidgets.QPushButton("Previous", clicked=self.find_previous))
        layout.addWidget(QtWidgets.QPushButton("Next", clicked=self.find_next))
        self.find_status = QtWidgets.QLabel()
        layout.addWidget(self.find_status)
        layout.addWidget(QtWidgets.QPushButton("Close", clicked=bar.hide))
        return bar

    def _make_menus(self):
        file_menu = self.menuBar().addMenu("&File")
        if self.can_edit:
            self.save_action = file_menu.addAction("&Save")
            self.save_action.setShortcut(QtGui.QKeySequence.Save)
            self.save_action.triggered.connect(self.save)
            self.revert_action = file_menu.addAction("&Revert")
            self.revert_action.triggered.connect(self.revert)
            file_menu.addSeparator()
        file_menu.addAction("&Close", self.close, QtGui.QKeySequence.Close)

        if self.can_edit:
            edit_menu = self.menuBar().addMenu("&Edit")
            self.edit_mode_action = edit_menu.addAction("Edit Handbook")
            self.edit_mode_action.setCheckable(True)
            self.edit_mode_action.triggered.connect(self.set_edit_mode)
            edit_menu.addSeparator()
            edit_menu.addAction("Undo", lambda: self.editor.undo(), QtGui.QKeySequence.Undo)
            edit_menu.addAction("Redo", lambda: self.editor.redo(), QtGui.QKeySequence.Redo)
            edit_menu.addSeparator()
            edit_menu.addAction("Add Sibling Topic", self.add_sibling_topic)
            edit_menu.addAction("Add Child Topic", self.add_child_topic)
            edit_menu.addAction("Rename Topic", self.rename_topic)
            edit_menu.addAction("Delete Topic", self.delete_topic)
            edit_menu.addSeparator()
            edit_menu.addAction("Move Topic Up", lambda: self.move_topic(-1))
            edit_menu.addAction("Move Topic Down", lambda: self.move_topic(1))
            edit_menu.addAction("Indent Topic", self.indent_topic)
            edit_menu.addAction("Outdent Topic", self.outdent_topic)
            edit_menu.addSeparator()
            edit_menu.addAction("Preview", lambda: self.set_edit_mode(False))

        find_menu = self.menuBar().addMenu("&Find")
        find_menu.addAction("Find...", self.show_find, QtGui.QKeySequence.Find)
        find_menu.addAction("Find Next", self.find_next, QtGui.QKeySequence("F3"))
        find_menu.addAction("Find Previous", self.find_previous, QtGui.QKeySequence("Shift+F3"))

        go_menu = self.menuBar().addMenu("&Go To")
        go_menu.addAction("Contents", lambda: self.navigate_to("contents"), QtGui.QKeySequence("Ctrl+Home"))
        go_menu.addAction("Back", self.go_back, QtGui.QKeySequence.Back)
        go_menu.addAction("Forward", self.go_forward, QtGui.QKeySequence.Forward)
        go_menu.addSeparator()
        go_menu.addAction("Previous Topic", lambda: self.go_relative(-1), QtGui.QKeySequence("Alt+Up"))
        go_menu.addAction("Next Topic", lambda: self.go_relative(1), QtGui.QKeySequence("Alt+Down"))
        go_menu.addAction("Top", self.go_top)

        view_menu = self.menuBar().addMenu("&View")
        self.contents_action = view_menu.addAction("Show Contents")
        self.contents_action.setCheckable(True)
        self.contents_action.setChecked(True)
        self.contents_action.toggled.connect(self.contents_tree.setVisible)
        view_menu.addAction("Expand All", self.contents_tree.expandAll)
        view_menu.addAction("Collapse All", self.contents_tree.collapseAll)
        view_menu.addSeparator()
        view_menu.addAction("Zoom In", self.zoom_in, QtGui.QKeySequence.ZoomIn)
        view_menu.addAction("Zoom Out", self.zoom_out, QtGui.QKeySequence.ZoomOut)
        view_menu.addAction("Reset Zoom", self.reset_zoom, QtGui.QKeySequence("Ctrl+0"))

    def _rebuild_tree(self, selected_id: Optional[str] = None):
        selected_id = selected_id or self._selected_topic_id()
        self.contents_tree.blockSignals(True)
        self.contents_tree.clear()
        self._tree_items.clear()
        contents = QtWidgets.QTreeWidgetItem(["Contents"])
        contents.setData(0, QtCore.Qt.UserRole, "contents")
        self.contents_tree.addTopLevelItem(contents)

        def add_topics(parent_item, topics):
            for topic in topics:
                item = QtWidgets.QTreeWidgetItem([expand_branding(topic.title)])
                item.setData(0, QtCore.Qt.UserRole, topic.topic_id)
                parent_item.addChild(item)
                self._tree_items[topic.topic_id] = item
                add_topics(item, topic.children)

        add_topics(contents, self.document_model.topics)
        self._tree_items["contents"] = contents
        self.contents_tree.expandAll()
        target = self._tree_items.get(selected_id or "contents", contents)
        self.contents_tree.setCurrentItem(target)
        self.contents_tree.blockSignals(False)

    def _refresh_reader(self):
        scroll = self.browser.verticalScrollBar().value()
        self.browser.setHtml(render_help_html(self.document_model))
        self.browser.verticalScrollBar().setValue(scroll)
        self.setWindowTitle(
            expand_branding(self.document_model.title) + (" *" if self._dirty else "")
        )

    def _tree_selection_changed(self):
        topic_id = self._selected_topic_id()
        if not topic_id:
            return
        if self._editing:
            self._commit_editor_topic()
            self._load_editor_topic(topic_id)
        else:
            self.navigate_to(topic_id)

    def _selected_topic_id(self) -> Optional[str]:
        item = self.contents_tree.currentItem()
        return str(item.data(0, QtCore.Qt.UserRole)) if item is not None else None

    def _anchor_clicked(self, url: QtCore.QUrl):
        if url.scheme().casefold() in {"http", "https"}:
            QtGui.QDesktopServices.openUrl(url)
            return
        topic_id = url.fragment() or url.toString().lstrip("#")
        if topic_id:
            self.navigate_to(topic_id)

    def navigate_to(self, topic_id: str, *, record: bool = True):
        if topic_id != "contents" and self.document_model.find(topic_id) is None:
            return False
        if self._editing:
            self.set_edit_mode(False)
        self.browser.scrollToAnchor(topic_id)
        item = self._tree_items.get(topic_id)
        if item is not None:
            self.contents_tree.blockSignals(True)
            self.contents_tree.setCurrentItem(item)
            self.contents_tree.scrollToItem(item)
            self.contents_tree.blockSignals(False)
        if record and (self._history_index < 0 or self._history[self._history_index] != topic_id):
            del self._history[self._history_index + 1:]
            self._history.append(topic_id)
            self._history_index = len(self._history) - 1
        return True

    def go_back(self):
        if self._history_index > 0:
            self._history_index -= 1
            self.navigate_to(self._history[self._history_index], record=False)

    def go_forward(self):
        if self._history_index + 1 < len(self._history):
            self._history_index += 1
            self.navigate_to(self._history[self._history_index], record=False)

    def go_relative(self, offset: int):
        topics = [topic.topic_id for topic, _depth in self.document_model.walk()]
        current = self._selected_topic_id()
        if current not in topics:
            target = topics[0] if offset >= 0 else topics[-1]
        else:
            target = topics[max(0, min(len(topics) - 1, topics.index(current) + offset))]
        self.navigate_to(target)

    def go_top(self):
        self.browser.verticalScrollBar().setValue(0)

    def show_find(self):
        if self._editing:
            self.set_edit_mode(False)
        self.find_bar.show()
        self.find_edit.setFocus()
        self.find_edit.selectAll()

    def _find(self, backward: bool):
        text = self.find_edit.text()
        if not text:
            self.find_status.setText("Enter text")
            return False
        flags = QtGui.QTextDocument.FindBackward if backward else QtGui.QTextDocument.FindFlags()
        if not self.browser.find(text, flags):
            cursor = self.browser.textCursor()
            cursor.movePosition(QtGui.QTextCursor.End if backward else QtGui.QTextCursor.Start)
            self.browser.setTextCursor(cursor)
            if not self.browser.find(text, flags):
                self.find_status.setText("No matches")
                return False
        self.find_status.setText("Match")
        self.browser.ensureCursorVisible()
        return True

    def find_next(self):
        return self._find(False)

    def find_previous(self):
        return self._find(True)

    def zoom_in(self):
        self.browser.zoomIn(1)
        self._zoom_steps += 1

    def zoom_out(self):
        self.browser.zoomOut(1)
        self._zoom_steps -= 1

    def reset_zoom(self):
        if self._zoom_steps > 0:
            self.browser.zoomOut(self._zoom_steps)
        elif self._zoom_steps < 0:
            self.browser.zoomIn(-self._zoom_steps)
        self._zoom_steps = 0

    def _mark_dirty(self):
        self._dirty = True
        self.setWindowTitle(expand_branding(self.document_model.title) + " *")

    def set_edit_mode(self, enabled: bool):
        enabled = bool(enabled)
        if enabled and (not self.can_edit or not self.admin_check()):
            if hasattr(self, "edit_mode_action"):
                self.edit_mode_action.blockSignals(True)
                self.edit_mode_action.setChecked(False)
                self.edit_mode_action.blockSignals(False)
            return
        if enabled == self._editing:
            return
        if not enabled:
            self._commit_editor_topic()
            self._refresh_reader()
            topic_id = self._editor_topic_id or "contents"
            self.pages.setCurrentWidget(self.browser)
            self._editing = False
            self.navigate_to(topic_id)
        else:
            self._editing = True
            topic_id = self._selected_topic_id()
            if topic_id == "contents":
                topic_id = next((topic.topic_id for topic, _depth in self.document_model.walk()), None)
            self.pages.setCurrentWidget(self.editor_panel)
            if topic_id:
                self._load_editor_topic(topic_id)
        if hasattr(self, "edit_mode_action"):
            self.edit_mode_action.blockSignals(True)
            self.edit_mode_action.setChecked(enabled)
            self.edit_mode_action.blockSignals(False)

    def _load_editor_topic(self, topic_id: str):
        topic = self.document_model.find(topic_id)
        if topic is None:
            return
        self._loading_editor = True
        self._editor_topic_id = topic_id
        self.editor.setHtml(topic.body_html)
        self.editor.document().setModified(False)
        self._loading_editor = False

    def _commit_editor_topic(self):
        if not self._editor_topic_id:
            return
        topic = self.document_model.find(self._editor_topic_id)
        if topic is None:
            return
        value = _html_body_fragment(self.editor.toHtml())
        if value != topic.body_html:
            topic.body_html = value
            self._mark_dirty()

    def _editor_changed(self):
        if not self._loading_editor:
            self._mark_dirty()

    def _merge_char_format(self, fmt: QtGui.QTextCharFormat):
        cursor = self.editor.textCursor()
        if not cursor.hasSelection():
            cursor.select(QtGui.QTextCursor.WordUnderCursor)
        cursor.mergeCharFormat(fmt)
        self.editor.mergeCurrentCharFormat(fmt)

    def _toggle_bold(self, checked):
        fmt = QtGui.QTextCharFormat()
        fmt.setFontWeight(QtGui.QFont.Bold if checked else QtGui.QFont.Normal)
        self._merge_char_format(fmt)

    def _toggle_italic(self, checked):
        fmt = QtGui.QTextCharFormat(); fmt.setFontItalic(checked); self._merge_char_format(fmt)

    def _toggle_underline(self, checked):
        fmt = QtGui.QTextCharFormat(); fmt.setFontUnderline(checked); self._merge_char_format(fmt)

    def _sync_format_actions(self, fmt):
        self.bold_action.setChecked(fmt.fontWeight() >= QtGui.QFont.Bold)
        self.italic_action.setChecked(fmt.fontItalic())
        self.underline_action.setChecked(fmt.fontUnderline())

    def _apply_font_size(self, *_args):
        try:
            size = float(self.size_combo.currentText())
        except ValueError:
            return
        if 6 <= size <= 72:
            fmt = QtGui.QTextCharFormat(); fmt.setFontPointSize(size); self._merge_char_format(fmt)

    def _apply_paragraph_style(self, index):
        sizes = {0: 10.5, 1: 18.0, 2: 14.0, 3: 12.0}
        fmt = QtGui.QTextCharFormat()
        fmt.setFontPointSize(sizes.get(index, 10.5))
        fmt.setFontWeight(QtGui.QFont.Normal if index == 0 else QtGui.QFont.Bold)
        cursor = self.editor.textCursor()
        cursor.select(QtGui.QTextCursor.BlockUnderCursor)
        cursor.mergeCharFormat(fmt)

    def _create_list(self, style):
        cursor = self.editor.textCursor()
        list_format = QtGui.QTextListFormat(); list_format.setStyle(style); list_format.setIndent(1)
        cursor.createList(list_format)

    def _choose_text_color(self):
        color = QtWidgets.QColorDialog.getColor(parent=self)
        if color.isValid():
            fmt = QtGui.QTextCharFormat(); fmt.setForeground(color); self._merge_char_format(fmt)

    def _choose_highlight_color(self):
        color = QtWidgets.QColorDialog.getColor(parent=self)
        if color.isValid():
            fmt = QtGui.QTextCharFormat(); fmt.setBackground(color); self._merge_char_format(fmt)

    def _insert_link(self):
        cursor = self.editor.textCursor()
        label = cursor.selectedText()
        if not label:
            label, ok = QtWidgets.QInputDialog.getText(self, "Insert Link", "Link text:")
            if not ok or not label:
                return
        target, ok = QtWidgets.QInputDialog.getText(
            self, "Insert Link", "Target (#topic-id, http://, or https://):"
        )
        if not ok or not target:
            return
        if not (target.startswith("#") or target.startswith("http://") or target.startswith("https://")):
            QtWidgets.QMessageBox.warning(self, "Unsupported Link", "Use an internal #topic-id or an HTTP/HTTPS URL.")
            return
        fmt = QtGui.QTextCharFormat(); fmt.setAnchor(True); fmt.setAnchorHref(target)
        fmt.setForeground(QtGui.QColor("#1261a0")); fmt.setFontUnderline(True)
        if not cursor.hasSelection():
            cursor.insertText(label, fmt)
        else:
            cursor.mergeCharFormat(fmt)

    def _insert_table(self):
        rows, ok = QtWidgets.QInputDialog.getInt(self, "Insert Table", "Rows:", 2, 1, 20)
        if not ok:
            return
        columns, ok = QtWidgets.QInputDialog.getInt(self, "Insert Table", "Columns:", 2, 1, 10)
        if ok:
            self.editor.textCursor().insertTable(rows, columns)

    def _clear_formatting(self):
        cursor = self.editor.textCursor()
        if not cursor.hasSelection():
            cursor.select(QtGui.QTextCursor.WordUnderCursor)
        cursor.setCharFormat(QtGui.QTextCharFormat())

    def _topic_location(self, topic_id: str):
        def search(items, parent_topic=None):
            for index, topic in enumerate(items):
                if topic.topic_id == topic_id:
                    return items, index, parent_topic
                result = search(topic.children, topic)
                if result:
                    return result
            return None
        return search(self.document_model.topics)

    def _unique_id(self, title: str) -> str:
        base = _SLUG_RE.sub("-", title.casefold()).strip("-") or "topic"
        used = {topic.topic_id for topic, _depth in self.document_model.walk()}
        candidate = base
        number = 2
        while candidate in used:
            candidate = f"{base}-{number}"; number += 1
        return candidate

    def _new_topic(self, title: str) -> HelpTopic:
        return HelpTopic(self._unique_id(title), title.strip(), "<p>Describe this topic here.</p>")

    def _ask_topic_title(self, caption: str) -> Optional[str]:
        title, ok = QtWidgets.QInputDialog.getText(self, caption, "Topic title:")
        return title.strip() if ok and title.strip() else None

    def _prepare_structure_edit(self) -> bool:
        if not self.can_edit:
            return False
        if not self._editing:
            self.set_edit_mode(True)
        self._commit_editor_topic()
        return self._editing

    def add_sibling_topic(self):
        if not self._prepare_structure_edit(): return
        title = self._ask_topic_title("Add Sibling Topic")
        if not title: return
        selected = self._selected_topic_id()
        location = self._topic_location(selected) if selected and selected != "contents" else None
        target_list, index = (location[0], location[1] + 1) if location else (self.document_model.topics, len(self.document_model.topics))
        topic = self._new_topic(title); target_list.insert(index, topic)
        self._mark_dirty(); self._rebuild_tree(topic.topic_id); self._load_editor_topic(topic.topic_id)

    def add_child_topic(self):
        if not self._prepare_structure_edit(): return
        title = self._ask_topic_title("Add Child Topic")
        if not title: return
        parent = self.document_model.find(self._selected_topic_id() or "")
        target = parent.children if parent else self.document_model.topics
        topic = self._new_topic(title); target.append(topic)
        self._mark_dirty(); self._rebuild_tree(topic.topic_id); self._load_editor_topic(topic.topic_id)

    def rename_topic(self):
        if not self._prepare_structure_edit(): return
        topic = self.document_model.find(self._selected_topic_id() or "")
        if topic is None: return
        title, ok = QtWidgets.QInputDialog.getText(self, "Rename Topic", "Topic title:", text=topic.title)
        if ok and title.strip() and title.strip() != topic.title:
            topic.title = title.strip(); self._mark_dirty(); self._rebuild_tree(topic.topic_id)

    def delete_topic(self):
        if not self._prepare_structure_edit(): return
        topic_id = self._selected_topic_id() or ""
        location = self._topic_location(topic_id)
        if not location: return
        topic = location[0][location[1]]
        meaningful = bool(re.sub(r"<[^>]+>", "", topic.body_html).strip() or topic.children)
        if meaningful and QtWidgets.QMessageBox.question(
            self, "Delete Topic", f"Delete '{topic.title}' and all of its child topics?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        ) != QtWidgets.QMessageBox.Yes:
            return
        del location[0][location[1]]
        self._editor_topic_id = None
        self._mark_dirty(); self._rebuild_tree("contents")
        first = next((item.topic_id for item, _depth in self.document_model.walk()), None)
        if first: self._load_editor_topic(first)

    def move_topic(self, offset: int):
        if not self._prepare_structure_edit(): return
        topic_id = self._selected_topic_id() or ""; location = self._topic_location(topic_id)
        if not location: return
        items, index, _parent = location; target = index + offset
        if 0 <= target < len(items):
            items[index], items[target] = items[target], items[index]
            self._mark_dirty(); self._rebuild_tree(topic_id)

    def indent_topic(self):
        if not self._prepare_structure_edit(): return
        topic_id = self._selected_topic_id() or ""; location = self._topic_location(topic_id)
        if not location or location[1] == 0: return
        items, index, _parent = location; topic = items.pop(index); items[index - 1].children.append(topic)
        self._mark_dirty(); self._rebuild_tree(topic_id)

    def outdent_topic(self):
        if not self._prepare_structure_edit(): return
        topic_id = self._selected_topic_id() or ""; location = self._topic_location(topic_id)
        if not location or location[2] is None: return
        items, index, parent_topic = location; topic = items.pop(index)
        parent_location = self._topic_location(parent_topic.topic_id)
        parent_items, parent_index, _grandparent = parent_location
        parent_items.insert(parent_index + 1, topic)
        self._mark_dirty(); self._rebuild_tree(topic_id)

    def save(self):
        if not self.can_edit or not self.admin_check():
            return False
        self._commit_editor_topic()
        try:
            save_help_document(self.document_model, self.help_path)
        except Exception as exc:
            message_dialog.critical(self, "Help Save Failed", str(exc))
            return False
        self._saved_model = copy.deepcopy(self.document_model)
        self._dirty = False
        self._refresh_reader()
        self.statusBar().showMessage("Help handbook saved safely.", 5000)
        return True

    def revert(self):
        if self._dirty and QtWidgets.QMessageBox.question(
            self, "Revert Help", "Discard all unsaved help changes?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        ) != QtWidgets.QMessageBox.Yes:
            return False
        try:
            self.document_model = load_help_document(self.help_path)
        except HelpDocumentError as exc:
            message_dialog.warning(self, "Help Revert Failed", str(exc))
            return False
        self._saved_model = copy.deepcopy(self.document_model)
        self._dirty = False; self._editor_topic_id = None
        self._rebuild_tree("contents"); self._refresh_reader()
        if self._editing:
            first = next((topic.topic_id for topic, _depth in self.document_model.walk()), None)
            if first: self._load_editor_topic(first)
        return True

    def closeEvent(self, event):
        self._commit_editor_topic()
        if not self.confirm_pending_changes():
            event.ignore()
            return
        event.accept()

    def confirm_pending_changes(self) -> bool:
        if not self._dirty:
            return True
        box = QtWidgets.QMessageBox(self)
        box.setIcon(QtWidgets.QMessageBox.Warning)
        box.setWindowTitle("Unsaved help changes")
        box.setText("Save changes to the help handbook before closing?")
        save_button = box.addButton("Save", QtWidgets.QMessageBox.AcceptRole)
        discard_button = box.addButton("Discard", QtWidgets.QMessageBox.DestructiveRole)
        box.addButton("Cancel", QtWidgets.QMessageBox.RejectRole)
        box.exec_()
        if box.clickedButton() is save_button:
            return self.save()
        if box.clickedButton() is discard_button:
            self._dirty = False
            return True
        return False
