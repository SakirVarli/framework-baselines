from PyQt5 import QtWidgets, QtGui, QtCore
from app import message_dialog
from app.branding import expand_branding
from app.utils import (
    load_json, PROJECT_ROOT, CONFIG_PATH, CALLBACKS_PATH, ensure_history,
    load_callbacks, sanitize_func_name, is_frozen,
)
from app.output_widgets import OutputArea, OutputRegistry
from app.info_widgets import InfoWidget, InfoRegistry
from app.print_redirector import PrintRedirector
from app.global_runtime import GlobalRuntimeCoordinator
from app.input_spawner import spawn_input
from app.tool_api import Tools
from app.stub_generator import regenerate_stubs
from app.config_designer.canvas_layout import CanvasLayout
from app.config_designer.config_structure import is_window_layout_config
from app.tab_widgets import configure_tab_widget
from app.source_reload import (
    CallbackImportTransaction, SourceReloadWatcher, automatic_source_reload_enabled,
    ReloadScheduler, source_manifest,
)
import threading
import traceback
import copy
from pathlib import Path
from app.reload_effects import (
    resource_widget, retained_identities, qt_alive, StaleGenerationError,
    check_execution, execution_token,
    borrowed,
)
from app.global_store import AppGlobals


class _LayoutReloadTransaction:
    """Retain the working UI and registries until the candidate is published."""
    def __init__(self, window, config):
        self.window = window
        self.old = {name: getattr(window, name) for name in (
            "config", "title", "tabs", "tab_widgets", "_root_surface", "_unlocked_tabs")}
        self.title = window.windowTitle()
        self.outputs = window.output_registry._by_name
        self.infos = window.info_registry._by_instance
        self.mounts = [(name, area, area._widget_layout.itemAt(index).widget())
                       for name, area in self.outputs.items()
                       for index in range(area._widget_layout.count())]
        self.floating = []
        for is_info, widgets in ((False, self.outputs), (True, self.infos)):
            for name, widget in widgets.items():
                dialog = getattr(widget, "_float", None)
                if qt_alive(dialog):
                    self.floating.append((is_info, name, widget, dialog.geometry(), dialog.isVisible()))
        self.central = window.takeCentralWidget()
        if self.central is not None:
            self.central.setParent(window)
            self.central.hide()
        self.config = config

    def build(self):
        window = self.window
        indices = {name: widget.currentIndex() for name, widget in self.old["tab_widgets"].items()}
        window.config = self.config
        window.title = expand_branding((self.config.get("window") or {}).get("title") or "App")
        window.setWindowTitle(window.title)
        window.tabs = None
        window.tab_widgets = {}
        window.output_registry._by_name = {}
        window.info_registry._by_instance = {}
        try:
            window._build_all()
            for name, index in indices.items():
                widget = window.tab_widgets.get(name)
                if widget is not None and 0 <= index < widget.count():
                    widget.setCurrentIndex(index)
        except Exception:
            self.rollback()
            raise
        return self

    def rollback(self):
        window = self.window
        candidate = window.takeCentralWidget()
        if candidate is not None and candidate is not self.central:
            candidate.hide()
            candidate.deleteLater()
        for name, value in self.old.items():
            setattr(window, name, value)
        window.output_registry._by_name = self.outputs
        window.info_registry._by_instance = self.infos
        window.setWindowTitle(self.title)
        if qt_alive(self.central):
            window.setCentralWidget(self.central)
            self.central.show()

    def commit(self):
        window = self.window
        retained = retained_identities(AppGlobals.values())
        for name, old_area, widget in self.mounts:
            area = window.output_registry._by_name.get(name)
            if (qt_alive(widget) and id(widget) in retained and area is not None
                    and (widget.parent() is None or old_area._widget_holder.isAncestorOf(widget))):
                area._safe_display(widget, "append")
        retiring_roots = [self.central] + [entry[2] for entry in self.floating]
        for value in AppGlobals.values():
            widget = resource_widget(value)
            if qt_alive(widget) and any(qt_alive(root) and root.isAncestorOf(widget)
                                        for root in retiring_roots):
                widget.hide()
                widget.setParent(None)
        for root in retiring_roots:
            if not qt_alive(root):
                continue
            for widget in root.findChildren(QtWidgets.QWidget):
                if borrowed(widget):
                    widget.hide()
                    widget.setParent(None)
        for is_info, name, old_widget, geometry, visible in self.floating:
            dialog = getattr(old_widget, "_float", None)
            if qt_alive(dialog):
                # finished must not dock the retired widget into a deleted layout.
                dialog.blockSignals(True)
                dialog.hide()
                dialog.deleteLater()
            old_widget.hide()
            old_widget.deleteLater()
            registry = window.info_registry._by_instance if is_info else window.output_registry._by_name
            replacement = registry.get(name)
            if replacement is not None and replacement.dockable:
                replacement._undock()
                replacement._float.setGeometry(geometry)
                replacement._float.setVisible(visible)
        if qt_alive(self.central):
            self.central.deleteLater()

class ConfigDrivenWindow(QtWidgets.QMainWindow):
    ready = QtCore.pyqtSignal()
    initialization_failed = QtCore.pyqtSignal(int, str)
    initialization_warning = QtCore.pyqtSignal(int, str)
    source_reload_started = QtCore.pyqtSignal()
    source_reload_finished = QtCore.pyqtSignal(bool)
    def __init__(self, *, degraded_startup=False):
        super().__init__()
        # Temporary notices should not leave an empty strip below the content.
        status_bar = self.statusBar()
        status_bar.messageChanged.connect(
            lambda message: status_bar.setVisible(bool(message))
        )
        status_bar.hide()
        self.resize(800, 600)
        self.config_path = CONFIG_PATH
        self.config = load_json(self.config_path)
        # Reconcile the generated developer API before callbacks import it.
        if not degraded_startup:
            regenerate_stubs(self.config)
        self.callbacks = load_callbacks(degraded_startup=degraded_startup)
        self._applied_source_manifest = source_manifest(PROJECT_ROOT, CALLBACKS_PATH)
        self._cb_lock = threading.RLock()
        self.icon = None

        self.tabs = None
        self.tab_widgets = {}
        self._root_surface = None
        self._unlocked_tabs = set()

        self.output_registry = OutputRegistry(self)
        self.info_registry = InfoRegistry(self)
        self.print_redirector = PrintRedirector(self.info_registry)
        self.global_runtime = GlobalRuntimeCoordinator(self)
        self.global_runtime.ready.connect(self._on_global_runtime_ready)
        self.global_runtime.initialization_failed.connect(
            self._on_global_runtime_failed)
        self.global_runtime.initialization_warning.connect(
            self._on_global_runtime_warning)
        self._reload_queue = ReloadScheduler(
            self.global_runtime, self._execute_reload_request, self)
        self.global_runtime.reload_finished.connect(self._on_source_reload_finished)
        self._source_reload_transactions = {}
        self._quiet_reload_generations = set()
        self._source_reload_in_progress = False
        self._source_reloads_stopped = False
        self._source_change_prompt = None
        self._source_reload_notice = None
        self._source_reload_approved = False
        self._manual_source_reload_generations = set()
        self._pending_source_paths = set()
        self._source_watcher = None
        if not is_frozen():
            self._source_watcher = SourceReloadWatcher(Path(PROJECT_ROOT), self)
            self._source_watcher.changed.connect(self._on_source_files_changed)

        # Bind the stable callback-facing tool registry before lifecycle hooks
        # and Globals.init_globals() run. Subclasses such as MainApp provide
        # these opener methods.
        opener_names = {
            "ftp_server": "_open_ftp_server",
            "ftp_client": "_open_ftp_client",
            "serial": "_open_serial",
            "telnet": "_open_telnet",
            "communication": "_open_communication_hub",
        }
        if all(hasattr(self, method) for method in opener_names.values()):
            Tools.bind(
                {
                    key: (lambda method=method: getattr(self, method)())
                    for key, method in opener_names.items()
                },
                acquirers={
                    "communication": lambda: self._acquire_communication_hub()
                } if hasattr(self, "_acquire_communication_hub") else None,
            )

        # Apply window settings
        wcfg = self.config.get('window') or {}
        self.title = expand_branding(wcfg.get('title') or 'App')
        icon_path = wcfg.get('icon')
        self.icon = fr"{PROJECT_ROOT}\{icon_path}" if icon_path else ""
        self.version = wcfg.get('version', '1.0.0')
        self.app_version_release_notes = wcfg.get('app_version_release_notes', '')
        self.build = wcfg.get('build', 1)
        self.phase = wcfg.get('phase', 'baseline')
        self.baseline_number = wcfg.get('baseline_number', wcfg.get('baseline', 1))
        self.admin_pasword = wcfg.get('admin_password')
        if self.icon:
            self.setWindowIcon(QtGui.QIcon(self.icon))
        self.setWindowTitle(self.title)

        self._globals_obj = None
        QtCore.QTimer.singleShot(0, self._begin_global_initialization)
    
    def _begin_global_initialization(self):
        self.global_runtime.begin_initialization(
            self.callbacks,
            window=self,
            build_ui=self._build_all,
            inject_helpers=self._inject_callback_helpers,
        )

    def _inject_callback_helpers(self, callback_module):
        callback_module.__dict__.update({
            'info_start': self.info_registry.start,
            'info_stop': self.info_registry.stop,
            'info_reset': self.info_registry.reset,
            'info_clear': self.info_registry.clear,
            'info_show': self.info_registry.show,
            'info_hide': self.info_registry.hide,
            'info_set_state': self.info_registry.set_state,
            'info_set_progress': self.info_registry.set_progress,
            'info_set_text': self.info_registry.set_text,
            'info_tqdm': self.info_registry.tqdm,
            'display': self.output_registry.display,
            'route_prints': self.info_registry.route_prints,
            'Tools': Tools,
        })

    def _on_global_runtime_ready(self, generation):
        self.callbacks = self.global_runtime.current_callbacks
        self._globals_obj = self.global_runtime.current_globals_object
        if self.tabs is not None and self.tabs.count() > 0:
            self._last_tab_index = getattr(self, "_last_tab_index", 0)
        self.ready.emit()
        if self._pending_source_paths and not self._source_reload_in_progress:
            QtCore.QTimer.singleShot(0, lambda: self._on_source_files_changed(()))

    def _on_global_runtime_failed(self, generation, details):
        if self.global_runtime.current_callbacks is not None:
            self.callbacks = self.global_runtime.current_callbacks
            self._globals_obj = self.global_runtime.current_globals_object
        if generation in self._quiet_reload_generations:
            self.statusBar().showMessage(
                "Source reload failed; previous callbacks retained. See diagnostics.", 12000
            )
            print(f"Automatic source reload generation {generation} failed:\n{details}")
        else:
            self._show_error_traceback(
                f"Globals generation {generation} failed:\n\n{details}")
        self.initialization_failed.emit(generation, details)

    def _on_global_runtime_warning(self, generation, details):
        self.initialization_warning.emit(generation, details)
        print(f"Globals generation {generation} warning:\n{details}")


    def _begin_transactional_reload(self, *, changed_paths=(), quiet=False, rebuild_ui=None):
        generation = self._reload_queue.submit(
            changed_paths=changed_paths, quiet=quiet, rebuild_ui=rebuild_ui)
        if quiet:
            self._quiet_reload_generations.add(generation)
        self._source_reload_in_progress = True
        self.setEnabled(False)
        return generation

    def _execute_reload_request(self, request):
        """The only importer/lifecycle entry point for all reload triggers."""
        current = source_manifest(PROJECT_ROOT, CALLBACKS_PATH)
        applied = self._applied_source_manifest
        changed = set(request.paths) | self._pending_source_paths | {
            path for path in current.keys() | applied.keys()
            if current.get(path) != applied.get(path)}
        self._pending_source_paths.clear()
        self._source_reload_approved = False
        for name in ("_source_change_prompt", "_source_reload_notice"):
            box = getattr(self, name, None)
            if box is not None:
                setattr(self, name, None)
                box.blockSignals(True)
                box.close()
        external_root = (Path(PROJECT_ROOT) / "externals").resolve()
        external_paths = [path for path in changed if external_root in Path(path).resolve().parents]
        hub = getattr(self.window(), "_communication_hub", None)
        if external_paths and hub is not None and hasattr(hub, "mark_external_code_stale"):
            hub.mark_external_code_stale(external_paths)
        transaction = CallbackImportTransaction(
            Path(PROJECT_ROOT), Path(CALLBACKS_PATH), changed
        )
        try:
            with self._cb_lock:
                callbacks = transaction.stage()
            callbacks.__import_transaction__ = transaction
            self._source_reload_transactions[request.generation] = transaction
            self.global_runtime.begin_reload(
                callbacks,
                window=self,
                inject_helpers=self._inject_callback_helpers,
                rebuild_ui=request.rebuild_ui,
                requested_generation=request.generation,
            )
        except Exception:
            transaction.rollback()
            self.global_runtime.initialization_failed.emit(request.generation, traceback.format_exc())
            self.global_runtime.reload_finished.emit(request.generation, False)

    def _reload_runtime(self, *, changed_paths=(), quiet=False):
        return self._begin_transactional_reload(
            changed_paths=changed_paths, quiet=quiet
        )

    def _on_source_files_changed(self, paths):
        if self._source_reloads_stopped:
            return
        approved = getattr(self, "_assistant_reload_hashes", {})
        if approved:
            from app.assistant.policy import file_hash
            remaining = []
            for path in paths:
                path = Path(path)
                if path in approved and file_hash(path) == approved[path]:
                    approved.pop(path, None)
                else:
                    remaining.append(path)
            paths = remaining
        applied = getattr(self, "_applied_source_manifest", None)
        if applied is not None:
            import hashlib
            remaining = []
            # A watcher notification may arrive after staging but before commit.
            # Revalidate the whole pending batch, not only newly delivered paths.
            for path in set(paths) | self._pending_source_paths:
                path = Path(path).resolve()
                try:
                    digest = hashlib.sha256(path.read_bytes()).hexdigest()
                except FileNotFoundError:
                    digest = None
                if path not in applied or applied[path] != digest:
                    remaining.append(path)
            self._pending_source_paths.clear()
            paths = remaining
        self._pending_source_paths.update(Path(path) for path in paths)
        external_root = Path(PROJECT_ROOT) / "externals"
        external_paths = [
            path for path in self._pending_source_paths
            if external_root in path.parents
        ]
        if external_paths:
            hub = getattr(self.window(), "_communication_hub", None)
            if hub is not None and hasattr(hub, "mark_external_code_stale"):
                hub.mark_external_code_stale(external_paths)
        if self._source_reload_in_progress or self.global_runtime.current_callbacks is None:
            return
        if not self._pending_source_paths:
            return
        if self._source_change_prompt is not None or self._source_reload_notice is not None:
            return
        if not self._source_reload_approved and not automatic_source_reload_enabled(PROJECT_ROOT):
            self._offer_source_reload()
            return
        self._source_reload_in_progress = True
        self.source_reload_started.emit()
        # Give the main window a turn to show feedback and disable interaction
        # before synchronous callback imports begin.
        QtCore.QTimer.singleShot(0, self._run_pending_source_reload)

    def _offer_source_reload(self):
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle("Project source changed")
        box.setIcon(QtWidgets.QMessageBox.Question)
        box.setText("Project source files changed. Reload the runtime now?")
        box.setInformativeText(
            "Yes applies the current source changes, including saves made while this prompt is open. "
            "No keeps the current runtime; the saved files remain on disk.")
        box.setDetailedText("\n".join(sorted(str(path) for path in self._pending_source_paths)))
        box.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        copy = QtWidgets.QPushButton("Copy", box)
        copy.setAutoDefault(False)
        layout = box.layout()
        layout.addWidget(copy, layout.rowCount(), 0, 1, layout.columnCount(), QtCore.Qt.AlignLeft)
        copy.clicked.connect(lambda: QtWidgets.QApplication.clipboard().setText(
            "\n\n".join((box.text(), box.informativeText(), box.detailedText()))
        ))
        box.setDefaultButton(QtWidgets.QMessageBox.No)
        box.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self._source_change_prompt = box
        box.finished.connect(self._source_reload_decision)
        box.open()

    def _source_reload_decision(self, answer):
        self._source_change_prompt = None
        if self._source_reloads_stopped:
            return
        if answer == QtWidgets.QMessageBox.Yes:
            self._source_reload_approved = True
            self._on_source_files_changed(())
        else:
            self._pending_source_paths.clear()
            self._source_reload_approved = False
            self._show_source_reload_notice(False,
                "Source changes were not applied to the runtime. "
                "Saved files remain on disk. Use File → Soft Restart to apply them later.")

    def _show_source_reload_notice(self, applied, text):
        if self._source_reloads_stopped:
            return
        self.statusBar().showMessage(text, 15000)
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle("Source changes applied" if applied else "Source changes not applied")
        box.setIcon(QtWidgets.QMessageBox.Information if applied else QtWidgets.QMessageBox.Warning)
        box.setText(text)
        box.setStandardButtons(QtWidgets.QMessageBox.Ok)
        box.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self._source_reload_notice = box
        box.finished.connect(self._source_reload_notice_closed)
        box.open()

    def _source_reload_notice_closed(self, _answer):
        self._source_reload_notice = None
        if self._pending_source_paths and not self._source_reloads_stopped:
            QtCore.QTimer.singleShot(0, lambda: self._on_source_files_changed(()))

    def _run_pending_source_reload(self):
        if self._source_reloads_stopped:
            self._source_reload_in_progress = False
            return
        changed = tuple(self._pending_source_paths)
        self._pending_source_paths.clear()
        user_requested = self._source_reload_approved
        self._source_reload_approved = False
        try:
            generation = self._reload_runtime(changed_paths=changed, quiet=True)
            if user_requested:
                self._manual_source_reload_generations.add(generation)
            self.statusBar().showMessage("Reloading callbacks and external modules…")
        except Exception:
            self._source_reload_in_progress = False
            self.statusBar().showMessage(
                "Source reload failed; previous callbacks retained. See diagnostics.", 12000
            )
            print("Source reload staging failed:\n" + traceback.format_exc())
            self.source_reload_finished.emit(False)
            if user_requested:
                self._show_source_reload_notice(False,
                    "Source changes were not applied because loading failed. Previous callbacks were retained.")

    def _stop_source_reloads(self):
        self._source_reloads_stopped = True
        queue = getattr(self, "_reload_queue", None)
        if queue is not None:
            queue.stop()
        if hasattr(self, "_pending_source_paths"):
            self._pending_source_paths.clear()
        watcher = getattr(self, "_source_watcher", None)
        if watcher is not None:
            watcher.stop()
        for name in ("_source_change_prompt", "_source_reload_notice"):
            box = getattr(self, name, None)
            if box is not None:
                setattr(self, name, None)
                box.close()

    def _on_source_reload_finished(self, generation, succeeded):
        quiet = generation in self._quiet_reload_generations
        transaction = self._source_reload_transactions.pop(generation, None)
        if transaction is not None:
            if succeeded:
                self._applied_source_manifest = transaction.manifest
                self.statusBar().showMessage("Callbacks and external modules reloaded.", 5000)
        self._quiet_reload_generations.discard(generation)
        queue = getattr(self, "_reload_queue", None)
        self._source_reload_in_progress = bool(self._source_reload_transactions) or bool(queue and queue.busy)
        if quiet:
            self.source_reload_finished.emit(bool(succeeded))
        if generation in self._manual_source_reload_generations:
            self._manual_source_reload_generations.discard(generation)
            self._show_source_reload_notice(bool(succeeded),
                "Project source changes were applied to the runtime." if succeeded
                else "Source changes were not applied because reload failed. Previous callbacks were retained; review diagnostics for hook or external side effects.")
        if not getattr(self, "_shutdown_feedback_started", False):
            self.setEnabled(not self._source_reload_in_progress)
        if self._pending_source_paths and not self._source_reload_in_progress:
            QtCore.QTimer.singleShot(
                0, lambda: self._on_source_files_changed(())
            )

    def _reload_config(self):
        cfg = load_json(self.config_path)
        self._reload_layout(cfg)
    
    def _reload_layout(self, cfg: dict):
        """Rebuild layout through the generation-aware Globals coordinator."""
        cfg = copy.deepcopy(cfg)
        def rebuild_ui():
            return _LayoutReloadTransaction(self, cfg).build()

        return self._begin_transactional_reload(rebuild_ui=rebuild_ui)

    # ------------- Build UI from config -------------
    def _build_all(self):
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            ensure_history()
            if is_window_layout_config(self.config):
                self._build_window_layout()
            else:
                definition = {
                    "type": "tab_widget", "instance": "main_tabs",
                    "tabPosition": "top", "tabTextOrientation": "native",
                    "tabs": self.config.get("tabs", []) or [],
                }
                tabs = self._create_tab_widget(definition)
                self.setCentralWidget(tabs)
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()

        if self.tabs is not None:
            self.tabs.currentChanged.connect(self.print_redirector.set_active_tab)

    def _build_window_layout(self):
        surface = QtWidgets.QWidget()
        self._root_surface = surface
        definition = self.config.get("layout") or {
            "mode": "canvas", "designSize": [1200, 800],
            "resizeMode": "anchors",
        }
        if definition.get("mode", "canvas") == "canvas":
            layout = CanvasLayout(
                design_size=definition.get("designSize", [1200, 800]),
                resize_mode=definition.get("resizeMode", "anchors"))
            surface.setLayout(layout)
        else:
            rows, columns = self.config.get("grid", [6, 4])
            layout = QtWidgets.QGridLayout(surface)
            for row in range(rows):
                layout.setRowStretch(row, 1)
            for column in range(columns):
                layout.setColumnStretch(column, 1)
        for definition in self.config.get("widgets", []) or []:
            self._place_widget(layout, definition)
        self.setCentralWidget(surface)

    def _create_tab_widget(self, definition, parent=None):
        tabs = configure_tab_widget(QtWidgets.QTabWidget(parent), definition)
        instance = str(definition.get("instance") or f"tabs_{len(self.tab_widgets) + 1}")
        tabs.setObjectName(instance)
        tabs._tab_definitions = list(definition.get("tabs", []) or [])
        tabs._unlocked_tabs = set()
        tabs._last_tab_index = 0
        tabs.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        tabs.customContextMenuRequested.connect(
            lambda pos, widget=tabs: self._on_tab_context_menu_for(widget, pos))
        for tab_definition in tabs._tab_definitions:
            self._add_tab(tab_definition, tabs)
        tabs.currentChanged.connect(
            lambda index, widget=tabs: self._on_tab_widget_switched(widget, index))
        self.tab_widgets[instance] = tabs
        if self.tabs is None:
            self.tabs = tabs
            self._unlocked_tabs = tabs._unlocked_tabs
        return tabs

    def _add_tab(self, tdef: dict, tab_widget=None):
        if tab_widget is None:
            tab_widget = self.tabs
        tab = QtWidgets.QWidget()
        name = tdef.get('name')
        layout_definition = tdef.get("layout") or {}
        if layout_definition.get("mode") == "canvas":
            grid = CanvasLayout(
                design_size=layout_definition.get("designSize", [1200, 800]),
                resize_mode=layout_definition.get("resizeMode", "anchors"),
            )
            tab.setLayout(grid)
        else:
            grid_r, grid_c = tdef.get('grid') or [6, 4]
            grid = QtWidgets.QGridLayout(tab)
            grid.setContentsMargins(6,6,6,6)
            grid.setSpacing(6)
            for i in range(grid_r):
                grid.setRowStretch(i, 1)
            for j in range(grid_c):
                grid.setColumnStretch(j, 1)

        # place widgets
        for wdef in tdef.get('widgets', []) or []:
            self._place_widget(grid, wdef)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(tab)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        tab_widget.addTab(scroll, name)

    def _place_widget(self, grid: QtWidgets.QGridLayout, wdef: dict, parent_group: QtWidgets.QGroupBox=None):
        wtype = wdef.get('type')
        pos = wdef.get('pos')  # [r,c] or [r,c,rs,cs]
        if not isinstance(grid, CanvasLayout) and (not pos or not (2 <= len(pos) <= 4)):
            raise ValueError(f"Bad pos for widget {wdef}")
        pos = pos or [0, 0, 1, 1]
        r, c = pos[0], pos[1]
        rs = pos[2] if len(pos) > 2 else 1
        cs = pos[3] if len(pos) > 3 else 1

        # background/foreground
        bg = wdef.get('bg'); fg = wdef.get('fg'); icon = wdef.get('icon'); width = wdef.get('width'); height = wdef.get('height')

        if wtype == 'group':
            box = QtWidgets.QGroupBox(wdef.get('name'))
            self._apply_widget_styling(
                box, bg, fg,
                None if isinstance(grid, CanvasLayout) else width,
                None if isinstance(grid, CanvasLayout) else height)
            child_layout = wdef.get("layout") or {}
            if child_layout.get("mode") == "canvas":
                child_design_size = child_layout.get("designSize")
                group_bounds = wdef.get("bounds")
                if (not (isinstance(child_design_size, list) and
                         len(child_design_size) == 2) and
                        isinstance(group_bounds, list) and len(group_bounds) == 4 and
                        group_bounds[2] > 0 and group_bounds[3] > 0):
                    child_design_size = group_bounds[2:4]
                child_design_size = child_design_size or [800, 600]
                v = CanvasLayout(
                    design_size=child_design_size,
                    resize_mode=child_layout.get("resizeMode", "anchors"),
                )
                box.setLayout(v)
            else:
                v = QtWidgets.QGridLayout(box)
            for child in wdef.get('widgets', []) or []:
                self._place_widget(v, child, parent_group=box)
            self._add_to_runtime_layout(grid, box, wdef, r, c, rs, cs)

        elif wtype == 'tab_widget':
            tab_widget = self._create_tab_widget(wdef, parent=grid.parentWidget())
            self._apply_widget_styling(
                tab_widget, bg, fg,
                None if isinstance(grid, CanvasLayout) else width,
                None if isinstance(grid, CanvasLayout) else height)
            self._add_to_runtime_layout(grid, tab_widget, wdef, r, c, rs, cs)

        elif wtype == 'button':
            btn = QtWidgets.QPushButton(wdef.get('name'))
            if icon:
                btn.setIcon(QtGui.QIcon(icon))
            
            tooltip = wdef.get('tooltip')
            if tooltip:
                btn.setToolTip(tooltip)

            # --- Optional keyboard shortcut ---
            shortcut = wdef.get('shortcut')
            if shortcut:
                btn.setShortcut(QtGui.QKeySequence(shortcut))

            self._apply_widget_styling(
                btn, bg, fg,
                None if isinstance(grid, CanvasLayout) else width,
                None if isinstance(grid, CanvasLayout) else height)
            password = wdef.get('password')
            confirm = wdef.get('confirm', False)

            # Wire callback: name → btn_NAME_callback in callbacks
            raw_name = wdef.get('name')
            func_name = wdef.get("callback") or sanitize_func_name(raw_name)
            cb = getattr(self.callbacks, func_name, None)
            if cb is None:
                def _missing():
                    QtWidgets.QMessageBox.warning(self, 'Callback Missing', f'{func_name}() not found in callbacks.py')
                cb = _missing

            def _run():
                # password gate
                if password:
                    text, ok = QtWidgets.QInputDialog.getText(
                        self, 'Password', f'Password for "{raw_name}":', QtWidgets.QLineEdit.Password
                    )
                    if not ok or text != password:
                        return
                # --- Confirmation gate ---
                if confirm:
                    res = QtWidgets.QMessageBox.question(
                        self,
                        "Confirm Action",
                        f"Are you sure you want to run '{raw_name}'?",
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                        QtWidgets.QMessageBox.No
                    )
                    if res != QtWidgets.QMessageBox.Yes:
                        return
                try:
                    # 🔁 Fetch callback dynamically each time — so it updates when reloaded
                    with self._cb_lock:  # 🔒 Prevent reload during lookup
                        cb = getattr(self.callbacks, func_name, None)
                    if cb is None:
                        QtWidgets.QMessageBox.warning(self, 'Callback Missing', f'{func_name}() not found in callbacks.py')
                        return

                    cb_globals = getattr(cb, '__globals__', {})
                    def safe_spawn_input(*args, **kwargs):
                        check_execution()
                        if len(args) > 0:
                            raise TypeError("'spawn_input' only accepts kewrod aruments.")
                        QtCore.QMetaObject.invokeMethod(
                            self,
                            "_do_spawn_input",
                            QtCore.Qt.QueuedConnection,
                            QtCore.Q_ARG(object, {"parent_button": btn,
                                "_runtime_token": execution_token(), **kwargs})
                        )

                    cb_globals.update({
                        'info_start': self.info_registry.start,
                        'info_stop': self.info_registry.stop,
                        'info_reset': self.info_registry.reset,
                        'info_clear': self.info_registry.clear,
                        'info_show': self.info_registry.show,
                        'info_hide': self.info_registry.hide,
                        'info_set_state': self.info_registry.set_state,
                        'info_set_progress': self.info_registry.set_progress,
                        'info_set_text': self.info_registry.set_text,
                        'info_tqdm': self.info_registry.tqdm,
                        'display': self.output_registry.display,
                        'route_prints': self.info_registry.route_prints,
                        'spawn_input': safe_spawn_input,
                        'Tools': Tools,
                    })

                    def run_in_thread():
                        try:
                            cb()
                        except StaleGenerationError:
                            return
                        except Exception as e:
                            # Capture traceback for clarity
                            tb = traceback.format_exc()
                            # Safely show popup from the GUI thread
                            QtCore.QMetaObject.invokeMethod(
                                self,
                                "_show_error_traceback",
                                QtCore.Qt.QueuedConnection,
                                QtCore.Q_ARG(str, f"Callback '{cb.__name__}' crashed:\n\n{tb}")
                            )

                    if cb.__name__ == "_missing":
                        cb()
                    else:
                        self.global_runtime.start_callback(run_in_thread)

                except Exception as e:
                    tb = traceback.format_exc()
                    # Safely show popup from the GUI thread
                    QtCore.QMetaObject.invokeMethod(
                        self,
                        "_show_error_traceback",
                        QtCore.Qt.QueuedConnection,
                        QtCore.Q_ARG(str, f"'Callback Error':\n\n{tb}")
                    )

            btn.clicked.connect(_run)
            btn.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            btn.customContextMenuRequested.connect(
                lambda pos, b=btn, fname=func_name: self._on_button_context_menu(pos, b, fname)
            )

            self._add_to_runtime_layout(grid, btn, wdef, r, c, rs, cs)

        elif wtype == 'output':
            out = OutputArea(instance=wdef.get('instance'),
                             kind=wdef.get('output_kind') or 'any',
                             editable=bool(wdef.get('editable', False)),
                             dockable=bool(wdef.get('dockable', True)),
                             df_row_height=wdef.get('df_row_height'),
                             df_column_width=wdef.get('df_column_width'),
                             df_auto_wrap=bool(wdef.get('df_auto_wrap', False)),
                             allow_save=bool(wdef.get('save_to_file', True)))
            self._apply_widget_styling(
                out, bg, fg,
                None if isinstance(grid, CanvasLayout) else width,
                None if isinstance(grid, CanvasLayout) else height)
            self.output_registry.register(out)
            self._add_to_runtime_layout(grid, out.container(), wdef, r, c, rs, cs)
        
        elif wtype == 'info':
            info = InfoWidget(instance=wdef.get('instance'),
                             orientation=wdef.get('orientation') or 'horizontal',
                             height=None if isinstance(grid, CanvasLayout) else wdef.get('height'),
                             width=None if isinstance(grid, CanvasLayout) else wdef.get('width'),
                             bg_color=bg,
                             fg_color=fg,
                             font=wdef.get('font'),
                             visible=bool(wdef.get('visible', True)),
                             # InfoWidget applies visibility in its constructor.
                             # Give it its runtime parent first so it can never
                             # appear as a temporary top-level Python window.
                             parent=grid.parentWidget())
            
            self.info_registry.register(info)
            self._add_to_runtime_layout(grid, info.container(), wdef, r, c, rs, cs)

        else:
            raise ValueError(f"Unknown widget type: {wtype}")

        runtime_widget = (
            box if wtype == "group" else tab_widget if wtype == "tab_widget"
            else btn if wtype == "button"
            else out.container() if wtype == "output" else info.container()
        )
        tooltip = wdef.get("tooltip")
        if tooltip:
            runtime_widget.setToolTip(str(tooltip))

    @staticmethod
    def _add_to_runtime_layout(layout, widget, definition, row, column, row_span, column_span):
        if isinstance(layout, CanvasLayout):
            layout.addWidgetDefinition(widget, definition)
        else:
            layout.addWidget(widget, row, column, row_span, column_span)

    def _apply_widget_styling(self, widget, bg=None, fg=None, width=None, height=None):
        """
        Apply widget-aware colors without breaking native styles.

        QPushButton:
            - Always uses a Windows-like minimal stylesheet
            - Auto-detects text color (white or black) for contrast
        Other widgets:
            - Uses QPalette for background/foreground (keeps native look)
        """

        pal = widget.palette()

        # ------------------ BUTTONS ------------------
        if isinstance(widget, QtWidgets.QPushButton):
            base_color = QtGui.QColor(bg) if bg else QtGui.QColor("#FFFFFF")

            # Auto text color
            if not fg:
                brightness = (0.299 * base_color.red() + 0.587 * base_color.green() + 0.114 * base_color.blue())
                fg = "#000000" if brightness > 160 else "#FFFFFF"

            lighter = base_color.lighter(150).name()   # top shade
            darker = base_color.darker(110).name()     # bottom shade
            border = base_color.darker(140).name()

            widget.setStyleSheet(f"""
                QPushButton {{
                    background-color: qlineargradient(
                        x1:0, y1:0, x2:0, y2:1,
                        stop:0 {lighter}, stop:1 {darker}
                    );
                    color: {fg};
                    border: 1px solid {border};
                    border-radius: 4px;
                    padding: 4px 8px;
                }}
                QPushButton:hover {{
                    background-color: qlineargradient(
                        x1:0, y1:0, x2:0, y2:1,
                        stop:0 {base_color.lighter(130).name()},
                        stop:1 {base_color.lighter(110).name()}
                    );
                }}
                QPushButton:pressed {{
                    background-color: qlineargradient(
                        x1:0, y1:0, x2:0, y2:1,
                        stop:0 {base_color.darker(115).name()},
                        stop:1 {base_color.darker(130).name()}
                    );
                }}
                QPushButton:disabled {{
                    background-color: #CCCCCC;
                    color: #777777;
                    border: 1px solid #AAAAAA;
                }}
            """)

        # --- NON-BUTTON WIDGETS --------------------------------------------------
        else:
            if bg or fg:
                if bg:
                    c = QtGui.QColor(bg)
                    if isinstance(widget, (QtWidgets.QLineEdit, QtWidgets.QPlainTextEdit, QtWidgets.QTextEdit)):
                        pal.setColor(QtGui.QPalette.Base, c)
                    elif isinstance(widget, QtWidgets.QGroupBox):
                        pal.setColor(QtGui.QPalette.Window, c)
                    else:
                        pal.setColor(QtGui.QPalette.Window, c)
                        pal.setColor(QtGui.QPalette.Base, c)
                    widget.setAutoFillBackground(True)

                if fg:
                    c = QtGui.QColor(fg)
                    pal.setColor(QtGui.QPalette.WindowText, c)
                    pal.setColor(QtGui.QPalette.Text, c)
                    pal.setColor(QtGui.QPalette.ButtonText, c)

                widget.setPalette(pal)
                widget.setStyleSheet("")  # revert to native engine
                widget.update()

        # Apply size if requested
        if width and height:
            widget.setFixedSize(int(width), int(height))
        elif width:
            widget.setFixedWidth(int(width))
        elif height:
            widget.setFixedHeight(int(height))

    def _on_tab_widget_switched(self, tab_widget, index):
        """Apply page passwords independently for each configured tab widget."""
        definitions = getattr(tab_widget, "_tab_definitions", [])
        if index < 0 or index >= len(definitions):
            return
        definition = definitions[index]
        name = definition.get("name", f"Tab {index + 1}")
        password = definition.get("password", "")
        if not password or index in tab_widget._unlocked_tabs:
            tab_widget._previous_index = getattr(tab_widget, "_last_tab_index", 0)
            tab_widget._last_tab_index = index
            return
        text, ok = QtWidgets.QInputDialog.getText(
            self, "Password Required", f"Enter password for tab '{name}':",
            QtWidgets.QLineEdit.Password)
        if ok and text == password:
            tab_widget._unlocked_tabs.add(index)
            tab_widget._previous_index = getattr(tab_widget, "_last_tab_index", 0)
            tab_widget._last_tab_index = index
            return
        QtWidgets.QMessageBox.warning(
            self, "Access Denied",
            "Tab access cancelled." if not ok else f"Incorrect password for '{name}'.")
        fallback = self._find_fallback_tab_for(tab_widget, index)
        previous = fallback if fallback >= 0 else getattr(tab_widget, "_last_tab_index", 0)
        if 0 <= previous < tab_widget.count():
            tab_widget.blockSignals(True)
            tab_widget.setCurrentIndex(previous)
            tab_widget.blockSignals(False)

    def _find_fallback_tab_for(self, tab_widget, exclude_index):
        definitions = getattr(tab_widget, "_tab_definitions", [])
        for index, definition in enumerate(definitions):
            if index != exclude_index and not definition.get("password"):
                return index
        return -1

    def _on_tab_context_menu_for(self, tab_widget, pos):
        bar = tab_widget.tabBar()
        index = bar.tabAt(pos)
        definitions = getattr(tab_widget, "_tab_definitions", [])
        if index < 0 or index >= len(definitions):
            return
        definition = definitions[index]
        password = definition.get("password", "")
        menu = QtWidgets.QMenu(self)
        if password and index in tab_widget._unlocked_tabs:
            name = definition.get("name", f"Tab {index + 1}")
            lock_action = menu.addAction(f"Lock '{name}'")
            if menu.exec_(bar.mapToGlobal(pos)) == lock_action:
                tab_widget._unlocked_tabs.remove(index)
                fallback = self._find_fallback_tab_for(tab_widget, index)
                if fallback >= 0:
                    tab_widget.setCurrentIndex(fallback)
        else:
            menu.addAction("(No unlocked protected page)").setEnabled(False)
            menu.exec_(bar.mapToGlobal(pos))

    def _on_tab_switched(self, index: int):
        """Prompt for password when switching to a protected tab and handle fallback if denied."""
        if index < 0:
            return

        try:
            tab_cfg = self.config["tabs"][index]
        except (KeyError, IndexError):
            return

        name = tab_cfg.get("name", f"Tab {index + 1}")
        password = tab_cfg.get("password", "")

        # No password required
        if not password:
            self._previous_index = getattr(self, "_last_tab_index", 0)
            self._last_tab_index = index
            return

        # Already unlocked
        if index in getattr(self, "_unlocked_tabs", set()):
            self._previous_index = getattr(self, "_last_tab_index", 0)
            self._last_tab_index = index
            return

        # Prompt for password
        text, ok = QtWidgets.QInputDialog.getText(
            self,
            "Password Required",
            f"Enter password for tab '{name}':",
            QtWidgets.QLineEdit.Password
        )

        if not ok or text != password:
            if not ok:
                QtWidgets.QMessageBox.warning(
                    self, "Access Denied", "Tab access cancelled."
                )
            else:
                QtWidgets.QMessageBox.warning(
                    self, "Access Denied", f"Incorrect password for '{name}'."
                )

            # --- Find nearest safe tab ---
            fallback = self._find_fallback_tab(exclude_index=index)
            if fallback >= 0:
                self.tabs.blockSignals(True)
                self.tabs.setCurrentIndex(fallback)
                self._last_tab_index = fallback
                self.tabs.blockSignals(False)
            else:
                # Stay on previous if no safe tab found
                prev = getattr(self, "_last_tab_index", 0)
                if 0 <= prev < self.tabs.count():
                    self.tabs.blockSignals(True)
                    self.tabs.setCurrentIndex(prev)
                    self._last_tab_index = prev
                    self.tabs.blockSignals(False)
            return

        # Password correct → unlock
        self._unlocked_tabs.add(index)
        self._previous_index = getattr(self, "_last_tab_index", 0)
        self._last_tab_index = index

    def _on_tab_context_menu(self, pos: QtCore.QPoint):
        """Show right-click context menu for locking/unlocking tabs."""
        bar = self.tabs.tabBar()
        index = bar.tabAt(pos)
        if index < 0:
            return

        tab_cfg = self.config["tabs"][index]
        name = tab_cfg.get("name", f"Tab {index+1}")
        password = tab_cfg.get("password", "")

        menu = QtWidgets.QMenu(self)

        # Decide which options to show
        if password:
            if index in self._unlocked_tabs:
                lock_action = menu.addAction(f"Lock '{name}'")
                action = menu.exec_(bar.mapToGlobal(pos))
                if action == lock_action:
                    self._lock_tab(index, name)
        else:
            menu.addAction("(No password set)").setEnabled(False)
            menu.exec_(bar.mapToGlobal(pos))

    def _find_fallback_tab(self, exclude_index=None):
        """Return the nearest tab index that has no password protection."""
        total = self.tabs.count()
        if total == 0:
            return -1

        # Prefer previous unlocked index
        if hasattr(self, "_last_tab_index") and self._last_tab_index != exclude_index:
            idx = self._last_tab_index
            if 0 <= idx < total:
                cfg = self.config["tabs"][idx]
                if not cfg.get("password"):
                    return idx

        # Scan left and right for any tab without password
        for offset in range(1, total):
            left = exclude_index - offset
            right = exclude_index + offset
            for i in (left, right):
                if 0 <= i < total:
                    cfg = self.config["tabs"][i]
                    if not cfg.get("password"):
                        return i

        # Fallback: first unlocked tab
        for i in range(total):
            if i not in self._unlocked_tabs:
                cfg = self.config["tabs"][i]
                if not cfg.get("password"):
                    return i
        return -1

    def _lock_tab(self, index: int, name: str):
        """Re-lock a previously unlocked tab and switch to nearest safe tab."""
        if index in self._unlocked_tabs:
            self._unlocked_tabs.remove(index)
            QtWidgets.QMessageBox.information(
                self, "Tab Locked", f"'{name}' has been locked again."
            )

            # --- Find nearest safe tab ---
            fallback = self._find_fallback_tab(exclude_index=index)
            if fallback >= 0:
                self.tabs.blockSignals(True)
                self.tabs.setCurrentIndex(fallback)
                self.tabs.blockSignals(False)
                self._last_tab_index = fallback
            else:
                prev = getattr(self, "_previous_index", 0)
                if 0 <= prev < self.tabs.count():
                    self.tabs.blockSignals(True)
                    self.tabs.setCurrentIndex(prev)
                    self.tabs.blockSignals(False)
                    self._last_tab_index = prev

        else:
            QtWidgets.QMessageBox.information(
                self, "Already Locked", f"'{name}' is already locked."
            )

    def _on_button_context_menu(self, pos, btn, func_name):
        """Show context menu for buttons (open callback, copy name, etc.)."""
        menu = QtWidgets.QMenu(btn)
        menu.setToolTipsVisible(True)
        top = self.window()
        open_vscode = menu.addAction("Open Callback in VS Code")
        vscode_ready = bool(
            hasattr(top, "_vscode_is_available") and top._vscode_is_available()
        )
        open_vscode.setEnabled(vscode_ready)
        if vscode_ready:
            vscode_explanation = "Open this callback definition in VS Code."
        elif hasattr(top, "_vscode_disabled_reason"):
            vscode_explanation = top._vscode_disabled_reason()
        else:
            vscode_explanation = "Install a supported VS Code version to use this feature."
        open_vscode.setToolTip(vscode_explanation)
        open_vscode.setStatusTip(vscode_explanation)
        copy_name = menu.addAction("Copy Callback Name")
        ask_assistant = None
        if not is_frozen() and getattr(top, "phase", "") in {"baseline", "development"} and hasattr(top, "_open_assistant"):
            ask_assistant = menu.addAction("Ask Assistant about this Callback")
        action = menu.exec_(btn.mapToGlobal(pos))

        if action == open_vscode:
            top._open_callback_in_vscode(func_name)

        elif action == copy_name:
            QtWidgets.QApplication.clipboard().setText(func_name)
            QtWidgets.QToolTip.showText(QtGui.QCursor.pos(), f"Copied: {func_name}")
        elif ask_assistant is not None and action == ask_assistant:
            top._open_assistant(f"callback {func_name}")

    @QtCore.pyqtSlot(object)
    def _do_spawn_input(self, kwargs):
        """Executed in the main GUI thread; spawns input widgets safely."""
        kwargs = dict(kwargs)
        try:
            check_execution(kwargs.pop("_runtime_token", None))
        except StaleGenerationError:
            return
        parent_button = kwargs.get("parent_button")
        if parent_button is None or not isinstance(parent_button, QtWidgets.QPushButton):
            QtWidgets.QMessageBox.warning(self, "Spawn Error", "Invalid or missing parent_button reference.")
            return
        spawn_input(**kwargs)
    
    @QtCore.pyqtSlot(str)
    def _show_error_traceback(self, msg: str):
        message_dialog.MessageDialog(
            self, "Critical Error", msg, QtWidgets.QMessageBox.Critical,
            copy_label="Copy Traceback", summary="An error occurred. Show Details to view the traceback.",
        ).show()

    @QtCore.pyqtSlot(str)
    def _show_done_confirm(self, msg: str):
        message_dialog.MessageDialog(
            self, "Mission Succesful", msg, QtWidgets.QMessageBox.Information,
        ).show()
