"""Versioned user responses and turn provenance, separate from stage summaries."""
from dataclasses import asdict, dataclass, field
import uuid
import ast
import re
import textwrap
import warnings

from .policy import AssistantError


@dataclass(frozen=True)
class TurnEnvelope:
    origin: str = 'user_message'
    task_id: str | None = None
    user_message_id: str | None = None
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    version: int = 1

    def __post_init__(self):
        if self.origin not in {'user_message', 'resume_button', 'clarification_answer', 'retry'}:
            raise AssistantError('TURN_PROTOCOL', 'Unknown turn origin.')
        if self.origin in {'resume_button', 'retry'} and not self.task_id:
            raise AssistantError('TURN_PROTOCOL', 'Resume requires an explicit task binding.')

    def export(self):
        return asdict(self)


@dataclass(frozen=True)
class ResponseDraft:
    answer: str
    kind: str = 'explanation'
    evidence: tuple = ()
    limitations: tuple = ()
    version: int = 1

    def __post_init__(self):
        if (self.kind not in {'conversation', 'explanation', 'inspection'} or not isinstance(self.answer, str)
                or not self.answer.strip() or len(self.answer) > 48000):
            raise AssistantError('RESPONSE_REQUIRED', 'Provide the actual user-facing answer, not an internal completion summary.')
        for values in (self.evidence, self.limitations):
            if len(values) > 20 or any(not isinstance(v, str) or len(v) > 2000 for v in values):
                raise AssistantError('RESPONSE_PROTOCOL', 'Response evidence and limitations must be bounded text lists.')

    def export(self):
        return asdict(self)

    def text(self):
        text = self.answer.strip()
        if self.limitations:
            text += '\n\nLimitations: ' + '; '.join(self.limitations)
        return text


def terminal_outcome(run, status, task, proposal, response, action=None):
    """One host outcome shared by persistence, activity and evaluation."""
    reviewed = status == 'awaiting_review' and proposal is not None
    review = next((s for s in reversed(run['stages']) if s['role'] == 'review'), {})
    validation = run.get('validation', {})
    blocker = run.get('error') or review.get('failure', {}).get('code')
    incomplete = status in {'failed', 'incomplete', 'cancelled'}
    if incomplete and not blocker:
        blocker = 'CANCELLED' if status == 'cancelled' else 'WORKFLOW_INCOMPLETE'
    review_resume = bool(proposal and run.get('pending_stage') == 'review'
                         and validation.get('ok') and run.get('validated_candidate') == proposal.fingerprint)
    next_action = {'awaiting_review': 'review_proposal', 'awaiting_action': 'run_action',
                   'awaiting_clarification': 'answer_question', 'awaiting_mode_change': 'change_mode'}.get(status)
    if incomplete:
        next_action = 'resume_review' if review_resume else 'resume'
    summaries = {'completed': 'Completed', 'awaiting_review': 'Reviewed draft ready for Apply',
                 'awaiting_action': 'Action prepared; review before Run Action',
                 'awaiting_clarification': 'Waiting for your answer',
                 'awaiting_mode_change': 'Waiting for Create Changes mode', 'cancelled': 'Stopped'}
    summary = summaries.get(status, 'Workflow incomplete')
    if incomplete and proposal:
        summary = 'Draft retained; review incomplete. Resume review.' if review_resume else 'Draft retained; workflow incomplete. Resume to continue.'
        if review_resume and blocker in {'CONTEXT_LIMIT', 'REVIEW_CONTEXT_LIMIT'}:
            summary = 'Draft retained; review needs more context. Resume review with a larger context budget.'
        elif review_resume and blocker in {'TASK_LIMIT', 'REVIEW_BUDGET'}:
            summary = 'Draft retained; review needs more task allowance. Resume review.'
        elif review_resume and review.get('evidence_delivery', {}).get('unread_offsets'):
            path = next(iter(review['evidence_delivery']['unread_offsets']))
            summary = f'Draft retained; review evidence incomplete for {path}. Resume review.'
    return {'version': 2, 'answer_status': ('retained' if status in {'failed', 'cancelled'} else 'delivered') if response else 'missing' if task and 'explain' in task['work'] else 'not_requested',
            'artifact_status': 'reviewed' if reviewed else 'incomplete' if proposal else 'none',
            'task_disposition': status, 'current_blocker': blocker if incomplete else None,
            'next_action': next_action, 'summary': summary,
            'validation_status': 'passed' if validation.get('ok') or status == 'awaiting_action' else 'failed' if validation else 'not_run',
            'review_status': 'passed' if reviewed else review['status'] if review.get('status') in {'failed', 'interrupted'} else 'incomplete' if review else 'pending' if review_resume else 'not_run',
            'candidate_fingerprint': proposal.fingerprint if proposal else None,
            'draft_id': proposal.id if proposal else None, 'applied': bool((task or {}).get('completion', {}).get('applied')),
            'action_status': 'dispatched' if (task or {}).get('completion', {}).get('dispatched') else 'prepared' if action else 'none',
            'resume_eligible': incomplete and task is not None}


def validate_examples(answer):
    """Check the installed callback contract in Python examples; never execute.

    Class methods are intentionally excluded. This is a narrow framework check,
    not a claim to verify arbitrary explanation semantics or Python behavior.
    """
    for code in re.findall(r'```(?:python|py)\s*\n(.*?)```', answer, flags=re.I | re.S):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',SyntaxWarning)
                tree = ast.parse(textwrap.dedent(code))
        except SyntaxError:
            continue  # Incomplete illustrative snippets are not executable tests.
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                arguments = [*node.args.posonlyargs, *node.args.args]
                if any(a.arg == 'self' for a in arguments):
                    raise AssistantError('RESPONSE_CONTRACT', 'Framework callback examples must be top-level zero-argument functions, not methods taking self. Use display(instance, data, mode=...) and inspect the installed API before giving examples.')
