"""Static revision-aware knowledge retrieval. Indexed project code is never imported."""
import ast
import copy
import json
import os
from pathlib import Path
import threading
from difflib import get_close_matches

from .handbook import HandbookIndex
from .policy import AssistantError, SECRET, digest, redact
from .retrieval import LexicalIndex, tokens


GROUPS = {
    "Layout and widgets": "app/config_designer/", "Callback APIs and inputs": "app/stubs.py",
    "Outputs and tables": "app/output_widgets.py", "Globals": "app/globals_api.py",
    "Lifecycle": "app/lifecycle.py", "Connection tools": "app/tool_api.py",
    "Communication and Protocol Insights": "app/tools/communication_hub/",
    "Binary messages": "app/binary_messages/", "Message Designer": "app/tools/message_designer/",
    "Reload": "app/source_reload.py", "Build": "app/builder.py", "VS Code": "app/vscode_integration.py",
    "Upgrade": "app/upgrade_manager.py",
}
PRUNE = {"__pycache__", "node_modules", "venv", "env", "designer", "baselines", "build", "dist"}


def nested_definitions(body):
    """Nearest nested definitions suffice: their ranges already include deeper children."""
    pending = list(body)
    result = []
    while pending:
        node = pending.pop()
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            result.append(node)
        else:
            pending.extend(child for child in ast.iter_child_nodes(node)
                           if isinstance(child, (ast.stmt, ast.ExceptHandler, ast.match_case)))
    return result


def source_record(relative, raw, state="saved", saved_hash=None):
    """Extract metadata with lexical ownership, including nested definitions and overloads."""
    stamp = digest(raw)
    text = raw.decode("utf-8-sig")
    result = {"path": relative, "sha256": saved_hash if state == "unsaved" else stamp,
              "content_revision": stamp, "state": state, "symbols": [], "chunks": [],
              "imports": [], "calls": [], "declarations": [], "diagnostics": []}
    suffix = Path(relative).suffix.lower()
    if suffix == ".json":
        try:
            text = json.dumps(redact(json.loads(text)), indent=2, ensure_ascii=False)
        except ValueError as exc:
            result["diagnostics"].append({"path": relative, "kind": "json", "message": str(exc)})
    text = redact(text)
    result["text"] = text
    lines = text.splitlines()
    common = {k: result[k] for k in ("path", "sha256", "content_revision", "state")}
    common["source_kind"] = ("test" if relative.startswith("tests/") else "example" if relative.startswith("examples/")
                             else "configuration" if suffix == ".json" else "source")
    common["line_basis"] = "formatted_redacted_json" if suffix == ".json" else "source"

    def chunks(start, end, identity, metadata):
        for first in range(start, end+1, 60):
            last = min(end, first+79)
            result["chunks"].append({**common, **metadata, "id": f"{identity}:{first}",
                                     "definition_id": identity, "line": first, "end_line": last,
                                     "citation": f"sakir-source:{relative}?revision={stamp}#L{first}",
                                     "text": "\n".join(lines[first-1:last])})

    covered = set()
    if suffix == ".py":
        try:
            tree = ast.parse(raw.decode("utf-8-sig"))
            module = relative.removesuffix(".py").replace("/", ".")
            application = relative.startswith(("callbacks/", "externals/"))

            class Visitor(ast.NodeVisitor):
                scope = ()
                owner = None
                globals_classes = set()

                def generic_visit(self, node):
                    if application:
                        super().generic_visit(node)
                    else:
                        # Framework bodies are text-searchable. Only application code
                        # needs expression-level call extraction for the project map.
                        for child in ast.iter_child_nodes(node):
                            if isinstance(child, (ast.stmt, ast.ExceptHandler, ast.match_case)):
                                self.visit(child)

                def definition(self, node):
                    scope, owner = self.scope, self.owner
                    qualified = ".".join((module, *scope, node.name))
                    identity = f"{relative}:{qualified}:{node.lineno}"
                    is_class = isinstance(node, ast.ClassDef)
                    arguments = ast.unparse(node.args) if not is_class else ", ".join(ast.unparse(b) for b in node.bases)
                    returns = ast.unparse(node.returns) if getattr(node, "returns", None) else ""
                    signature = f"{node.name}({arguments})" + (f" -> {returns}" if returns else "")
                    entry = redact({**common, "id": identity, "name": node.name, "module": module,
                                    "citation": f"sakir-source:{relative}?revision={stamp}#L{node.lineno}",
                                    "qualified_name": qualified, "owner": owner,
                                    "kind": "class" if is_class else "async_function" if isinstance(node, ast.AsyncFunctionDef) else "function",
                                    "line": node.lineno, "end_line": node.end_lineno,
                                    "definition_start_line": min([node.lineno] + [d.lineno for d in node.decorator_list]),
                                    "signature": arguments, "full_signature": signature, "returns": returns,
                                    "decorators": [ast.unparse(d) for d in node.decorator_list],
                                    "bases": [ast.unparse(b) for b in node.bases] if is_class else [],
                                    "summary": (ast.get_docstring(node) or "")[:1500]})
                    result["symbols"].append(entry)
                    if is_class and (node.name == "Globals" or any(b.endswith("GlobalsBase") for b in entry["bases"])):
                        self.globals_classes.add(qualified)
                    nested = nested_definitions(node.body)
                    excluded = {i for n in nested for i in range(min([n.lineno] + [d.lineno for d in n.decorator_list]), n.end_lineno+1)}
                    start = min([node.lineno] + [d.lineno for d in node.decorator_list])
                    first = None
                    for line in range(start, node.end_lineno+2):
                        if line <= node.end_lineno and line not in excluded:
                            if first is None:
                                first = line
                        elif first is not None:
                            chunks(first, line-1, identity, entry)
                            first = None
                    covered.update(range(start, node.end_lineno+1))
                    self.scope, self.owner = (*scope, node.name), qualified
                    for child in node.body:
                        self.visit(child)
                    self.scope, self.owner = scope, owner

                visit_ClassDef = definition
                visit_FunctionDef = definition
                visit_AsyncFunctionDef = definition

                def visit_Import(self, node):
                    for item in node.names:
                        result["imports"].append({"module": item.name, "alias": item.asname or item.name.split(".")[0],
                                                  "scope": self.owner, "line": node.lineno})

                def visit_ImportFrom(self, node):
                    for item in node.names:
                        base = ("." * node.level) + (node.module or "")
                        result["imports"].append({"module": base, "name": item.name, "alias": item.asname or item.name,
                                                  "scope": self.owner, "line": node.lineno})

                def visit_Call(self, node):
                    if not application:
                        return
                    if self.owner:
                        name = ast.unparse(node.func)
                        literals = [a.value if isinstance(a, ast.Constant) and isinstance(a.value, (str, int)) else None for a in node.args[:3]]
                        keywords = {k.arg: k.value.value if isinstance(k.value, ast.Constant) and isinstance(k.value.value, (str, int)) else None
                                    for k in node.keywords if k.arg}
                        result["calls"].append(redact({"caller": self.owner, "target": name[:200],
                                                       "arguments": literals, "keywords": keywords, "line": node.lineno}))
                    self.generic_visit(node)

                def declaration(self, node):
                    if self.owner in self.globals_classes:
                        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                        for target in targets:
                            if isinstance(target, ast.Name):
                                value = ast.unparse(node.value)[:300] if node.value else ""
                                result["declarations"].append(redact({"owner": self.owner, "name": target.id,
                                    "line": node.lineno, "annotation": ast.unparse(node.annotation) if isinstance(node, ast.AnnAssign) else "",
                                    "value": "<redacted>" if SECRET.search(target.id) else value}))
                    self.generic_visit(node)

                visit_Assign = declaration
                visit_AnnAssign = declaration

            Visitor().visit(tree)
        except (SyntaxError, ValueError, RecursionError) as exc:
            result["diagnostics"].append({"path": relative, "kind": "python", "message": str(exc)[:500]})
    first = None
    for line in range(1, len(lines)+2):
        if line <= len(lines) and line not in covered:
            if first is None:
                first = line
        elif first is not None:
            for start in range(first, line, 60):
                chunks(start, min(line-1, start+79), f"{relative}:module:{start}",
                       {"name": Path(relative).name, "signature": "", "kind": "text"})
            first = None
    return result


class SourceIndex:
    def __init__(self, policy):
        self.policy = policy
        self.cache = {}
        self.handbook = HandbookIndex(policy)
        self.lock = threading.RLock()
        self.frozen = False
        self.generation = None
        self.diagnostics = []
        self.disk_hashes = {}
        self.lexical = LexicalIndex([])
        self.knowledge = LexicalIndex([])

    def files(self):
        paths = []
        self.discovery_diagnostics = []
        readme = self.policy.root / "README.md"
        if readme.is_file():
            try:
                target = self.policy.path("README.md")
                if target.stat().st_size <= 2_000_000:
                    paths.append(target)
                else:
                    self.discovery_diagnostics.append({"path": "README.md", "kind": "size", "message": "File exceeds 2 MB indexing limit."})
            except (AssistantError, OSError):
                pass
        for directory in ("app", "callbacks", "externals", "examples", "tests"):
            base = self.policy.root / directory
            if not base.exists():
                continue
            try:
                self.policy.path(f"{directory}/__index_probe__.py")
            except AssistantError:
                continue
            for parent, directories, names in os.walk(base, followlinks=False):
                allowed = []
                for directory_name in directories:
                    if directory_name.startswith(".") or directory_name in PRUNE:
                        continue
                    try:
                        child = (Path(parent) / directory_name).relative_to(self.policy.root)
                        probe = "config.json" if child.as_posix() == "app/data" else "__index_probe__.py"
                        self.policy.path(child / probe)
                        allowed.append(directory_name)
                    except (AssistantError, OSError):
                        continue
                directories[:] = allowed
                for name in names:
                    path = Path(parent) / name
                    # Test code is useful evidence; evaluation answers and fixture payloads are not.
                    if directory == "tests" and (path.suffix != ".py" or not name.startswith("test_")):
                        continue
                    if path.suffix.lower() in {".py", ".md", ".json"}:
                        try:
                            self.policy.path(path.relative_to(self.policy.root))
                            if path.is_file():
                                if path.stat().st_size <= 2_000_000:
                                    paths.append(path)
                                else:
                                    self.discovery_diagnostics.append({"path": path.relative_to(self.policy.root).as_posix(),
                                                                       "kind": "size", "message": "File exceeds 2 MB indexing limit."})
                        except (AssistantError, OSError):
                            continue
        return sorted(paths)

    def refresh(self):
        if self.frozen:
            return
        with self.lock:
            current, diagnostics, disk_hashes = {}, [], {}
            for path in self.files():
                relative = path.relative_to(self.policy.root).as_posix()
                try:
                    raw = path.read_bytes()
                    stamp = digest(raw)
                    disk_hashes[relative] = stamp
                    previous = self.cache.get(relative)
                    current[relative] = previous if previous and previous["content_revision"] == stamp else source_record(relative, raw)
                except (OSError, UnicodeError, RecursionError) as exc:
                    diagnostics.append({"path": relative, "kind": "source", "message": str(exc)[:500]})
            self.cache = current
            self.disk_hashes = disk_hashes
            self.handbook.refresh()
            self.diagnostics = diagnostics + self.discovery_diagnostics + [d for record in current.values() for d in record["diagnostics"]] + self.handbook.diagnostics
            self._rebuild()

    def _rebuild(self):
        generation = digest([(p, r["content_revision"]) for p, r in sorted(self.cache.items())] + [("help", self.handbook.sha256)])
        if generation != self.generation:
            self.generation = generation
            records = [c for record in self.cache.values() for c in record["chunks"]]
            self.lexical = LexicalIndex(records)
            self.knowledge = LexicalIndex(records + self.handbook.records, base=self.lexical)

    def for_snapshot(self, snapshot):
        """Pin one task to immutable records; overlays never change the saved edit hash."""
        self.refresh()
        with self.lock:
            task = copy.copy(self)
            task.cache = self.cache.copy()
            task.disk_hashes = self.disk_hashes.copy()
            task.handbook = copy.copy(self.handbook)
            task.diagnostics = list(self.diagnostics)
            task.frozen = True
            for relative, stamp in snapshot.get("hashes", {}).items():
                if relative in task.disk_hashes and stamp != task.disk_hashes[relative]:
                    raise AssistantError("SOURCE_CHANGED", "Saved source changed while capturing task context: " + relative)
            for relative, value in (("callbacks/callbacks.py", snapshot.get("callbacks")),
                                    ("app/data/config.json", snapshot.get("config"))):
                before = task.cache.get(relative)
                if value is None:
                    continue
                text = json.dumps(redact(value), indent=2, ensure_ascii=False) if isinstance(value, dict) else value
                if before and before["text"].replace("\r\n", "\n") == redact(text).replace("\r\n", "\n"):
                    continue
                saved = before["sha256"] if before else None
                task.cache[relative] = source_record(relative, text.encode("utf-8"), "unsaved", saved)
            task._rebuild()
            task.diagnostics = [d for d in task.diagnostics if d.get("path") not in task.cache or task.cache[d["path"]]["state"] != "unsaved"]
            task.diagnostics += [d for r in task.cache.values() if r["state"] == "unsaved" for d in r["diagnostics"]]
            return task

    def read(self, path, start=1, count=160):
        target = self.policy.path(path)
        relative = target.relative_to(self.policy.root).as_posix() if target.is_relative_to(self.policy.root) else str(target)
        if self.frozen and relative in self.cache:
            record = self.cache[relative]
        else:
            if target.stat().st_size > 2_000_000:
                raise AssistantError("FILE_TOO_LARGE", "Use a bounded data reader for this file.")
            if target.suffix.lower() in {'.bin', '.dat', '.xlsx', '.xls', '.mat'}:
                raise AssistantError('DATA_READER_REQUIRED', 'Use inspect_file(path=..., options=...) for this data file. BIN/DAT decoding requires options.binary_schema; read_source reads project source text.')
            text_data = target.suffix.lower() in {'.txt','.csv','.tsv','.xml'}
            if self.frozen and target not in self.policy.attachments and not text_data:
                raise AssistantError("SOURCE_CHANGED", "Source was not in the task snapshot. Retry with current project context.")
            record = source_record(relative, target.read_bytes())
            if self.frozen:
                # Explicit small-text reads are pinned on first access; data is
                # not indiscriminately added to the framework search index.
                self.cache[relative] = record
                self.disk_hashes[relative] = record['sha256']
                self._rebuild()
        lines = record["text"].splitlines()
        start, count = max(1, int(start)), min(250, max(1, int(count)))
        return {"path": relative, "sha256": record["sha256"], "content_revision": record["content_revision"],
                "state": record["state"], "line_basis": "formatted_redacted_json" if target.suffix.lower() == ".json" else "source",
                "citation": f"sakir-source:{relative}?revision={record['content_revision']}#L{start}",
                "start_line": start, "total_lines": len(lines),
                "text": "\n".join(f"{i+1}: {line}" for i, line in enumerate(lines) if start <= i+1 < start+count),
                "truncated": len(lines) >= start+count, "next_line": start+count if len(lines) >= start+count else None}

    def symbols(self):
        self.refresh()
        return [s for r in self.cache.values() for s in r["symbols"]]

    def search(self, query, limit=20):
        self.refresh()
        return self.lexical.search(query, limit)

    def search_knowledge(self, query, scope="all", limit=20):
        self.refresh()
        if scope == "source":
            return self.lexical.search(query, limit)
        if scope == "help":
            return self.handbook.search(query, limit)
        if scope != "all":
            raise AssistantError("INVALID_ARGUMENTS", "Unknown knowledge scope.")
        return self.knowledge.search(query, limit)

    def focused_knowledge(self, query, limit=6):
        """Reserve help and source candidates; expand only relevant help links."""
        self.refresh()
        terms = set(tokens(query))
        if len(terms) < 2:
            return []
        vocabulary = {term for item in self.handbook.sections.values() for term in tokens(item['title'])}
        corrections = {match[0] for term in sorted(terms) if len(term)>=5 and term not in vocabulary
                       if (match := get_close_matches(term,sorted(vocabulary),n=1,cutoff=.88))}
        if corrections:
            query += '\nRelated title terms: '+' '.join(sorted(corrections))
            terms.update(corrections)
        help_hits = self.handbook.search(query, min(3, limit))
        source_hits = self.lexical.search(query, max(2, limit))
        # A title match is a stronger procedure lead than body-only overlap.
        relevant = [h for h in help_hits if terms & set(tokens(h.get('title', '')))]
        result = []
        for hit in relevant[:2]:
            page = self.handbook.read(hit['section_id'], count=3000)
            result.append(page)
        if result and len(result) < limit:
            for link in result[0].get('links', [])[:6]:
                if link in self.handbook.sections and all(e.get('section_id') != link for e in result):
                    linked = self.handbook.sections[link]
                    if terms & set(tokens(linked.get('title', ''))):
                        result.append(self.handbook.read(link, count=2500))
                        break
        seen = {(e.get('path'), e.get('section_id'), e.get('line')) for e in result}
        for hit in [*source_hits, *help_hits]:
            key = (hit.get('path'), hit.get('section_id'), hit.get('line'))
            if key not in seen:
                result.append(hit)
                seen.add(key)
            if len(result) >= limit:
                break
        return result[:limit]

    def get_symbol(self, qualified_name, limit=20):
        entries = self.symbols()
        exact = [s for s in entries if qualified_name in (s["qualified_name"], s["id"])]
        return (exact or [s for s in entries if s["name"] == qualified_name or s["qualified_name"].endswith("." + qualified_name)])[:min(40, limit)]

    def search_help(self, query, limit=10):
        self.refresh()
        return self.handbook.search(query, limit)

    def read_help(self, section_id, offset=0, count=6000):
        self.refresh()
        return self.handbook.read(section_id, offset, count)

    def coverage(self):
        self.refresh()
        return {"generation": self.generation, "files": len(self.cache),
                "symbols": sum(len(r["symbols"]) for r in self.cache.values()),
                "chunks": len(self.lexical.records), "help_topics": len(self.handbook.sections),
                "unsaved_paths": [p for p, r in self.cache.items() if r["state"] == "unsaved"],
                "diagnostics": self.diagnostics[:50], "diagnostics_truncated": len(self.diagnostics) > 50,
                "optional_material": {name: (self.policy.root / name).exists() for name in ("README.md", "examples", "tests")}}

    def assert_current(self):
        if not self.frozen:
            return
        changed = []
        discovered = {p.relative_to(self.policy.root).as_posix() for p in self.files()}
        changed.extend(sorted(discovered - set(self.disk_hashes)))
        for path, stamp in self.disk_hashes.items():
            try:
                target = self.policy.path(path)
                current = digest(target.read_bytes()) if target.is_file() else None
            except (OSError, AssistantError):
                current = None
            if current != stamp:
                changed.append(path)
        try:
            current_help = digest(self.handbook.raw())
        except (OSError, AssistantError):
            current_help = None
        if current_help != self.handbook.sha256:
            changed.append("app/data/help.json")
        if changed:
            raise AssistantError("SOURCE_CHANGED", "Project evidence changed during this task; retry. Changed: " + ", ".join(changed[:8]))

    def catalog(self):
        from app.config_designer.schema import FEATURES
        from .capabilities import contracts
        return {"widgets": redact(FEATURES), "groups": GROUPS,
                "contracts": contracts(),
                "symbols": [s for s in self.symbols() if not s["name"].startswith("_")]}
