"""Sanitized development dialogues; fixture assertions are independent of stage prose."""


WORKFLOW_CASE_IDS = (
    'hello_how_are_you', 'callback_contract', 'workflow_novice_inspect',
    'workflow_expert_inspect', 'mode_callback', 'callback_edit', 'callback_amend',
    'workflow_novice_repair_without_code', 'workflow_novice_repair_with_code',
    'workflow_expert_repair_without_code', 'workflow_expert_repair_with_code',
)


def cases():
    result = []
    def add(identifier, turns, **expect):
        result.append({'id': identifier, 'turns': turns, **expect})
    for identifier, turns in [
        ('hello_how_are_you', ['hello', 'how are u']),
        ('thanks', ['Thank you for your help.']),
        ('turkish_greeting', ['Merhaba, nasılsın?']),
        ('capability_question', ['What can you help me do in this project?']),
        ('casual_followup', ['Hi there.', 'I am doing well, thanks.']),
        ('no_changes', ['Please just say hello. Do not inspect or change my project.']),
        ('short_reply', ['Respond with a brief friendly greeting.']),
        ('fresh_topic', ['Hello!', 'Could we talk about the app later?'])]:
        add(identifier, turns, conversation=True)
    for identifier, request, words in [
        ('tcp_client', 'Explain step by step how to create a TCP client connection in the Communication Hub. Do not create or connect anything.', ['tcp','client','host','port']),
        ('tcp_server', 'Explain how to listen for TCP connections as a server in this app, and how it differs from a client. Do not start anything.', ['tcp','server','port']),
        ('append_replace', 'Explain how display append and replace modes differ, with a small callback example. Do not stage changes.', ['append','replace','display']),
        ('callback_contract', 'Explain how to define and bind a button callback in this framework. Include its argument contract. Do not create changes.', ['callback']),
        ('portable_paths', 'Which portable project root constant should I use in callback file paths? Show an example, without making edits.', ['PROJECT_ROOT']),
        ('globals_contract', 'Explain the required base class and initialization method for project globals. Do not propose edits.', ['GlobalsBase','init_globals']),
        ('worker_explanation', 'Why should a slow spreadsheet loader run off the Qt GUI thread, and how should its result reach the output? Explain only.', ['thread']),
        ('tcp_followup', 'Explain TCP client setup in Communication Hub, then explain what to check if connection fails. Do not connect.', ['tcp','port'])]:
        add(identifier, [request], words=words, inspect=True)
    for identifier, request in [
        ('mode_button', 'Create a button called ReviewOnly in Controls at bounds [20,80,120,36].'),
        ('mode_callback', 'Create a callback called review_only that returns 7.'),
        ('mode_tab', 'Create a new tab with a button and output that shows hello.'),
        ('mode_mixed', 'Explain callbacks and add a button called ExplainAndAdd in Controls.')]:
        add(identifier, [request], mode_required=True)
    add('callback_edit', ['Create a callback named read_reliability that returns the Python literal 7. Preserve existing code and stage for review.'],
        edit=True, function='read_reliability', literal=7)
    add('callback_amend', ['Create a callback named read_reliability that returns the Python literal 7. Preserve existing code and stage for review.',
                           'Amend that same draft: read_reliability must now return the Python literal 9. Preserve everything else.'],
        edit=True, function='read_reliability', literal=9, same_task=True)
    add('draft_topic_switch', ['Create a callback named read_reliability that returns the Python literal 7. Preserve existing code and stage for review.',
                               'Thanks! How are you? Please leave the draft as it is.'],
        edit=True, function='read_reliability', literal=7, background=True)
    add('mixed_explain_edit', ['Explain what a callback is and create one named read_reliability returning the Python literal 7. Preserve existing code and stage for review.'],
        edit=True, function='read_reliability', literal=7, answer_required=True)
    add('serial_message_followups', [
        'Explain how to create a serial session in Communication Hub. Do not create or connect anything.',
        'In that same Hub serial session, how do I send PING followed by a newline? Show callback code, but do not send anything.',
        'How do I create the message itself? Distinguish raw bytes from a binary message schema, without inventing my device format.'
    ], inspect=True, words=['message', 'bytes', 'schema'], serial_sequence=True)
    add('message_designer_recovery', [
        'Hello.',
        'How do I design a message library?',
        'For device communication over Communication Hub. I want to learn the installed tool.',
        'Explain how to use Message Designer, rather than asking for my device requirements.',
        'How do I create a message library with Message Designer? Give the documented UI steps. Do not create or run anything.',
        'Continue with how I save and generate it, and what files I should edit afterward. Do not change anything.'
    ], inspect=True, designer_sequence=True)
    for identifier, request in [
        ('designer_ui', 'Explain the documented Message Designer UI procedure for a new library. Do not ask for a device schema or create files.'),
        ('designer_existing', 'How do I reopen an existing Message Designer library? Can it reverse-engineer an arbitrary Python package? Explain only.'),
        ('designer_future', 'Explain how a future generated library would be imported after saving. No library exists yet; distinguish illustrative names from current project imports. Do not create files.'),
        ('designer_bytes', 'Explain how a generated binary message send differs from sending raw bytes through Communication Hub. Do not invent my schema or send anything.'),
        ('designer_no_schema', 'I do not know my device schema yet. Can you still teach me how to create a library in Message Designer? Explain the UI procedure only.'),
        ('evidence_facades', 'Compare standalone Serial and Communication Hub session lifecycle APIs using installed documentation. Explain only; do not connect.'),
        ('designer_topic_switch', 'Explain Message Designer Save As, not serial connection settings. Do not make changes.'),
        ('evidence_unknown_format', 'What is the exact binary payload my undocumented device requires? I have supplied no device documentation. Explain what is unknown without inventing bytes.'),
        ('evidence_runtime_limit', 'Does a successful generated BinaryMessage.send prove the remote device received the message? Use installed help. Do not execute anything.'),
        ('evidence_internal_rpc', 'Is propose_message_library an importable callback Python API or an assistant proposal capability? Explain without importing or invoking it.')
    ]:
        add(identifier,[request],inspect=True)
    add('workflow_novice_inspect', [
        "I'm new to this app. What happens when I click Seed, and what number does its code return? Just look, please."
    ], inspect=True, words=['seed_callback', '42'])
    add('workflow_expert_inspect', [
        'Trace the Seed button binding from the project config to its Python definition. '
        'Report the parent, bounds, callback name, and return value. Inspection only.'
    ], inspect=True, words=['Controls', 'seed_callback', '42'], bounds=[20, 20, 100, 36])

    for persona, inspect, repair in [
        ('novice',
         "I'm new here. Since the last change, clicking Seed gives me a missing argument error. "
         "Could you look at what went wrong first? Please don't change anything yet.",
         "Please fix it now. I want clicking Seed to work without any input and return the number 42 again. "
         "Keep the rest of the app as it is."),
        ('expert',
         'Inspect the Seed binding and diagnose the missing positional argument regression in its '
         'callback. Identify the required parameter and compare it with the runtime invocation contract. Read only.',
         'Stage a repair of seed_callback in callbacks/callbacks.py. Restore the zero-argument '
         'signature and return the integer literal 42. Preserve the layout and all unrelated source.'),
    ]:
        for with_code in (False, True):
            suffix = 'with_code' if with_code else 'without_code'
            request = repair
            if with_code:
                request += '\nUse this corrected code:\n```python\ndef seed_callback():\n    return 42\n```'
            add(f'workflow_{persona}_repair_{suffix}', [inspect, request],
                edit=True, turn_modes=(False, True), repair=True, function='seed_callback', literal=42,
                exact_callback=persona == 'expert' or with_code)
    return result
