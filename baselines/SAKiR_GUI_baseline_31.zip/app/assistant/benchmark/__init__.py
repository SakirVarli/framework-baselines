"""Opt-in, isolated live assistant benchmarks and sanitized reports."""
