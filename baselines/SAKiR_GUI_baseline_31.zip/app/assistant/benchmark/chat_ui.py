"""Preview and explicitly attach a selected sidebar chat to a local report."""
import json

from PyQt5 import QtWidgets

from ..appearance import ComboBox
from .chat_attachments import chat_snapshot, available_reports, attach_chat


def add_chat_to_benchmark(parent, controller, session_id, title, messages, activities):
    payload, sanitizer = chat_snapshot(controller, session_id, title, messages, activities)
    dialog = QtWidgets.QDialog(parent)
    dialog.setWindowTitle('Add chat to benchmark report')
    dialog.resize(800, 650)
    layout = QtWidgets.QVBoxLayout(dialog)
    notice = QtWidgets.QLabel('Attach a sanitized snapshot of this chat and its retained diagnostics. '
        'This can include project/source snippets already present in tool results. Review the preview before adding. '
        'Older chats may lack reasoning, tools or original settings; missing evidence cannot be reconstructed. '
        'The attachment stays local and does not affect benchmark scores.')
    notice.setWordWrap(True)
    layout.addWidget(notice)
    reports = ComboBox()
    reports.setAccessibleName('Destination benchmark report')
    reports.addItem('Create a new chat diagnostic report', None)
    for folder, summary in available_reports(controller.store.private):
        reports.addItem(folder.name+' — '+summary['status'], str(folder))
    layout.addWidget(reports)
    note = QtWidgets.QLineEdit()
    note.setAccessibleName('Chat diagnostic note')
    note.setPlaceholderText('Optional: what should we investigate in this chat?')
    note.setMaxLength(4000)
    layout.addWidget(note)
    preview = QtWidgets.QPlainTextEdit()
    preview.setAccessibleName('Sanitized chat attachment preview')
    preview.setReadOnly(True)
    preview.setPlainText(json.dumps(payload, ensure_ascii=False, indent=2))
    layout.addWidget(preview, 1)
    status = QtWidgets.QLabel()
    status.setWordWrap(True)
    layout.addWidget(status)
    buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Cancel)
    add = buttons.addButton('Add chat', QtWidgets.QDialogButtonBox.AcceptRole)
    add.setObjectName('attachBenchmarkChat')
    layout.addWidget(buttons)
    result = []
    def save():
        try:
            payload['user_note'] = sanitizer.clean(note.text())
            result.append(attach_chat(controller.store.private, payload, sanitizer, reports.currentData()))
            dialog.accept()
        except Exception as exc:
            status.setText(sanitizer.clean(str(exc)))
    add.clicked.connect(save)
    buttons.rejected.connect(dialog.reject)
    dialog.exec_()
    return result[0] if result else None
