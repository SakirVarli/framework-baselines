"""Existing clarification/topic-switch/mode dialogue scenarios and oracles."""
import ast
import json
from app.assistant.policy import file_hash
from app.assistant.task_context import layout_rows
from app.assistant.task_state import TaskLedger
from app.assistant.workflow_protocol import completion_checks

def run_dialogue(case, turn, state, entry, snapshot, root):
    # turn updates state.ledger; use a small live proxy for the original oracle.
    class LedgerProxy:
        def __getattr__(self, name):
            return getattr(state.ledger, name)
    ledger = LedgerProxy()
    if case=='format':
        first=turn("Create an Export button inside Controls at exact bounds [20,80,120,36], bound to export_data. This is a prototype: its callback must return the literal 'CSV selected' or 'Excel selected' according to my choice, not write any file. Before staging any edits, ask me to choose CSV or Excel; I have not chosen. Preserve existing widgets and callbacks.",True)
        task=ledger.find()
        pending=ledger.pending(task,True)
        entry['checks']['required_card_before_edits']=bool(pending) and first.proposal is None
        entry['checks']['predefined_choices']=bool(pending and len(pending[0]['options'])>=2)
        if not pending:
            raise ValueError('No required format question was recorded.')
        q=pending[0]
        ledger.answer(task['id'],q['id'],task['revision'],value='Excel',message_id='explicit-fixture-user-answer')
        # JSON round trip simulates restoring structured state before resuming.
        state.ledger=TaskLedger(json.loads(json.dumps(ledger.export())))
        second=turn('Excel',True,task['id'])
        entry['checks']['answer_retained']=ledger.find()['questions'][0]['answer']['text']=='Excel'
        entry['checks']['valid_proposal']=bool(second.proposal and second.validate()['ok'])
        files={e.path:e.content for e in second.proposal.edits} if second.proposal else {}
        rows=layout_rows({'config':json.loads(files.get('app/data/config.json',json.dumps(snapshot['config'])))})
        buttons=[r for r in rows if r['type']=='button' and r['properties'].get('name')=='Export']
        entry['checks']['button_and_binding']=len(buttons)==1 and buttons[0]['properties'].get('callback')=='export_data' and buttons[0]['properties'].get('bounds')==[20,80,120,36]
        functions=[n for n in ast.parse(files.get('callbacks/callbacks.py','')).body if isinstance(n,ast.FunctionDef) and n.name=='export_data']
        returned=[]
        for fn in functions:
            for node in ast.walk(fn):
                if isinstance(node,ast.Return):
                    try:
                        returned.append(ast.literal_eval(node.value))
                    except (ValueError,TypeError):
                        pass
        entry['checks']['chosen_format_behavior']='Excel selected' in returned
    elif case=='optional':
        first=turn("Explain what callbacks are in two sentences. Offer an optional question card with choices 'Show example' and 'More detail', plus free text; do not require a response and do not edit anything.",False)
        original=ledger.find()['id']
        questions=ledger.pending(ledger.find())
        entry['checks']['answer_and_optional_card']=bool(entry['turns'][0]['answer'] and questions and all(not q['required'] for q in questions))
        entry['checks']['no_edits']=first.proposal is None
        second=turn('New unrelated question: what does PROJECT_ROOT refer to in this framework?',False)
        entry['checks']['new_topic_identity']=ledger.find()['id']!=original
        entry['checks']['original_question_still_pending']=all(q['status']=='pending' for q in ledger.find(original)['questions'])
        entry['checks']['new_topic_not_bound_as_answer']=entry['checks']['new_topic_identity'] and entry['checks']['original_question_still_pending']
        entry['checks']['second_explanation']=bool(entry['turns'][1]['answer']) and second.proposal is None
    else:
        first=turn('A button labelled Continue would help inside Controls, at exact bounds [20,80,120,36]. Please prepare it.',False)
        task=ledger.find()
        entry['checks']['host_mode_required']=bool(task and task['status']=='awaiting_mode_change' and first.proposal is None)
        if task is None:
            raise ValueError('No task record for the blocked request.')
        second=turn('Continue the selected task after my explicit switch to Create Changes.',True,task['id'])
        entry['checks']['valid_proposal']=bool(second.proposal and second.validate()['ok'])
        files={e.path:e.content for e in second.proposal.edits} if second.proposal else {}
        rows=layout_rows({'config':json.loads(files.get('app/data/config.json',json.dumps(snapshot['config'])))})
        entry['checks']['requested_button']=any(r['type']=='button' and r['properties'].get('name')=='Continue' and r['properties'].get('bounds')==[20,80,120,36] for r in rows)
    if case in {'format','mode'}:
        entry['completion_checks']=completion_checks(entry['turns'][-1], second.proposal.fingerprint if second.proposal else None)
        entry['checks']['reviewed_completion']=all(entry['completion_checks'].values())
    else:
        entry['checks']['explanations_delivered']=all(t.get('outcome',{}).get('answer_status')=='delivered'
            and t.get('outcome',{}).get('task_disposition')=='completed' for t in entry['turns'])
    entry['checks']['no_files_applied']=all(file_hash(root/p)==h for p,h in snapshot['hashes'].items())
    entry['passed']=bool(entry['checks']) and all(entry['checks'].values())
