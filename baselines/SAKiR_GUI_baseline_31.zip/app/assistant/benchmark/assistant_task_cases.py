"""Evaluation-only requests and independent oracles; excluded from source retrieval."""


def task_cases():
    cases = []
    def add(domain, name, request, expected, edit=False, smoke=False, setup=''):
        cases.append(dict(id=name, domain=domain, request=request, expected=expected, edit=edit, smoke=smoke, setup=setup))
    for name, request, bounds, anchors in [
        ('exact', 'Add a Run button inside Controls at x=120,y=80,width=100,height=36.', [120,80,100,36], ['left','top']),
        ('bottom_right', 'Add a Run button inside Controls, 16 pixels from the right and bottom edges, size 100 by 36. Keep those edge distances on resize.', [284,248,100,36], ['right','bottom']),
        ('top_right', 'Add a Run button in Controls 24 pixels from its top and right edges, size 100 by 36.', [276,24,100,36], ['right','top']),
        ('bottom_left', 'Add a Run button in Controls 12 pixels from its bottom and left edges, size 100 by 36.', [12,252,100,36], ['left','bottom']),
        ('center', 'Add a Run button centered in the Controls design canvas, size 100 by 36.', [150,132,100,36], ['left','top']),
        ('turkish', 'Controls grubuna Run adında buton ekle: x=120 y=80 genişlik=100 yükseklik=36.', [120,80,100,36], ['left','top']),
    ]:
        add('layout',name,request+' Stage for review.', {'node':{'name':'Run','bounds':bounds,'anchors':anchors},'parent':'Controls'}, True, name in {'exact','bottom_right'})
    for name, literal in [('reading',7),('enabled',True),('label','ready'),('empty',None),('values',[1,2]),('mapping',{'value':3})]:
        add('callbacks','callback_'+name,f'Create a callback named read_{name} that returns the Python literal {literal!r}. Preserve existing callbacks and stage it.',
            {'function':{'path':'callbacks/callbacks.py','name':'read_'+name,'returns':literal}},True,name in {'reading','values'})
    for name, request, words in [
        ('columns','Inspect externals/readings.csv and list its column names.',['time','voltage']),
        ('values','Inspect externals/readings.csv and give the two voltage values.',['3.5','4.5']),
        ('json','Inspect externals/readings.json and report its unit.',['volts']),
        ('xml','Inspect externals/readings.xml and report its unit attribute.',['volts']),
        ('text','Inspect externals/notes.txt and report the sample frequency.',['25']),
        ('binary','Inspect externals/sample.bin as little-endian binary with one uint16 field named value and report its value.',['513']),
    ]:
        expected = {'calls':['inspect_file'],'answer_all':words}
        if name != 'binary':
            expected = {'any_calls':['inspect_file','read_source'],'answer_all':words}
        add('data','data_'+name,request+' Do not propose edits.',expected,False,name in {'columns','values'})
    for kind in ('text','df','array','html','markdown','image'):
        add('output','output_'+kind,f'Add an output widget inside Controls with instance result_{kind}, output_kind={kind}, bounds [20,20,300,180]. Stage the change.',
            {'node':{'instance':'result_'+kind,'output_kind':kind,'bounds':[20,20,300,180]},'parent':'Controls'},True,kind=='df')
    for name, request, words in [
        ('portable','Explain which portable project-root constant callbacks should use.',['PROJECT_ROOT']),
        ('base','Explain the required base class and initialization method for project globals.',['GlobalsBase','init_globals']),
        ('thread','Explain why a blocking Excel loader should use a worker instead of running on the Qt GUI thread.',['thread']),
        ('ownership','Explain ownership of borrowed Tools services across reload.',['borrow']),
        ('hooks','Explain LifecycleManager hooks; inspect installed source and cite it.',['LifecycleManager']),
        ('reload','Explain the distinction between saved code and a runtime generation during reload.',['runtime']),
    ]:
        add('lifecycle','lifecycle_'+name,request+' Do not propose changes.',{'answer_all':words},False,name in {'portable','base'})
    for name, tool, operation, payload in [('serial_connect','serial','connect',''),('serial_disconnect','serial','disconnect',''),
            ('serial_send','serial','send','PING'),('telnet_connect','telnet','connect',''),
            ('telnet_send','telnet','send','STATUS'),('hub_disconnect','communication','disconnect','')]:
        add('sessions','session_'+name,f'Prepare a {tool} {operation} action on existing session Device'+(f' with exact payload {payload}' if payload else '')+'. Do not execute it.',
            {'action':{'tool':tool,'session':'Device','operation':operation,'payload':payload}},True,name=='serial_send')
    for package in ('sensor_messages','command_messages','status_messages'):
        add('messages',package,f'Create an empty valid message library with package name {package} under externals/{package}. Use installed manifest defaults. Stage only.',
            {'manifest':{'path':f'externals/{package}/message_library.json','package_name':package}},True,package=='sensor_messages')
    for name, request, words in [('endian','Explain why byte order matters for uint16 wire fields.',['byte']),
            ('preserve','Explain how generating a message library preserves custom behaviors.',['behavior']),
            ('validation','Explain why validating a message manifest does not prove device interoperability.',['device'])]:
        add('messages','message_'+name,request+' Do not propose changes.',{'answer_all':words})
    for name, request, words in [
        ('error','Inspect recent errors and report the exact missing output instance.',['missing_output']),
        ('binding','Inspect the Seed button callback binding and explain what function it calls.',['seed_callback']),
        ('value','Inspect seed_callback and report its current return value.',['42']),
        ('output','Inspect the Status output and report its configured output kind.',['text']),
        ('static','Explain whether static call relationships prove runtime dispatch.',['runtime']),
        ('state','Explain whether an unsaved callback overlay takes precedence over saved source.',['unsaved']),
    ]:
        add('diagnosis','diagnosis_'+name,request+' Do not propose changes.',{'answer_all':words},False,name=='error')
    for domain, name, request, expected, edit, setup in [
        ('layout','duplicate_target','Add a button inside Controls; first resolve the parent and ask if ambiguous.',{'clarification':True},True,'duplicate'),
        ('layout','grid_parent','Add a Run button in Controls at exact bounds [10,10,100,36]. Do not convert its grid layout; explain if unsupported.',{'no_proposal':True},True,'grid'),
        ('layout','read_only','Add a Run button at [10,10,100,36] inside Controls.',{'no_proposal':True},False,''),
        ('layout','preserve_seed','Add a Run button at [10,10,100,36] in Controls and preserve Seed.',{'node':{'name':'Run','bounds':[10,10,100,36]},'parent':'Controls','preserve_seed':True},True,''),
        ('layout','rename','Rename Seed to Start without changing its callback.',{'node':{'name':'Start','callback':'seed_callback'}},True,''),
        ('layout','remove','Remove the Seed button and preserve the Status output.',{'absent_name':'Seed','node':{'instance':'status'}},True,''),
        ('callbacks','replace','Change only seed_callback to return 99. Read the affected source first.',{'function':{'path':'callbacks/callbacks.py','name':'seed_callback','returns':99}},True,''),
        ('callbacks','helper','Create externals/calculation.py with a function calculate returning 17.',{'function':{'path':'externals/calculation.py','name':'calculate','returns':17}},True,''),
        ('callbacks','permission','Change app/main.py to print hello.',{'no_proposal':True},True,''),
        ('callbacks','compound','Create callback run_new returning 7, add Run in Controls at [20,100,100,36], and bind it to run_new.',{'function':{'path':'callbacks/callbacks.py','name':'run_new','returns':7},'node':{'name':'Run','callback':'run_new','bounds':[20,100,100,36]},'parent':'Controls'},True,''),
        ('callbacks','unsaved','Inspect seed_callback and report its current return value.',{'answer_all':['77']},False,'unsaved'),
        ('data','missing_file','Build a loader for my spreadsheet; no file is attached. Ask which file to use.',{'clarification':True},True,''),
        ('output','append','Explain how to append data to an existing output without replacing it.',{'answer_all':['append']},False,''),
        ('sessions','missing_session','Prepare a serial send to unknown session Missing with payload PING.',{'no_action':True},True,''),
        ('diagnosis','unavailable','Inspect an actual runtime value that is not in the snapshot; explain the limitation.',{'no_proposal':True},False,''),
        ('layout','relative','Add Run inside Controls below Seed with a 16 pixel gap, same left coordinate, size 100 by 36.',{'node':{'name':'Run','bounds':[20,72,100,36]},'parent':'Controls'},True,''),
    ]:
        add(domain,'cross_'+name,request,expected,edit,False,setup)
    assert len(cases) == 64 and sum(c['smoke'] for c in cases) == 12
    return cases


def session_cases():
    request='can u create button and output box in a nee tab when i clicked the button i wanf to see a greeting from u i left the button output and tab names to u'
    permission='i give the chanve permisson u can implement greeting messags is left to u u can select as u wish'
    return [dict(id=name,domain='layout',request=text,history=history,setup='greeting_tab',edit=True,smoke=True,
                 expected={'greeting_ui':True,'preserve_seed':True}) for name,text,history in [
        ('session_new_greeting_tab',request,[]),
        ('session_retry_greeting_tab','can u retry',[{'role':'user','content':request}]),
        ('session_permission_greeting_tab',permission,[{'role':'user','content':request},{'role':'user','content':'can u retry'},
            {'role':'assistant','content':'Which domains should I explore? Please choose a greeting.'}])]]
