"""Sanitize before persistence; portable, reviewable benchmark artifacts."""
import base64
from collections import Counter
from dataclasses import asdict, fields
from datetime import datetime, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import platform
import re
import math
import statistics
import time
import threading
from urllib.parse import quote
import zipfile

from ..policy import AssistantError
from ..storage import atomic_json, Settings
from ..changes import Edit, Proposal

SCHEMA_VERSION = 1
PRIVATE_FIELDS = {'key_env', 'credential_ref', 'ca_bundle', 'model_profiles', 'agent_models',
                  'capability_profile', 'usage_headers', 'base_url'}
SETTING_FIELDS = tuple(f.name for f in fields(Settings) if f.name not in PRIVATE_FIELDS)
SECRET_FIELD = re.compile(r'(?i)^(?:.*[_-])?(?:api[_-]?key|password|passwd|secret|token|access[_-]?token|refresh[_-]?token|authorization|cookie|set-cookie|credential[_-]?ref|key_env|ca_bundle)$')


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def safe_settings(settings):
    return {name: getattr(settings, name) for name in SETTING_FIELDS}


class Sanitizer:
    def __init__(self, secrets=(), paths=(), endpoint=''):
        self.secrets = set()
        for value in secrets:
            if value and value != 'no-key-required':
                self.secrets.update((value, quote(value, safe=''), base64.b64encode(value.encode()).decode()))
        self.replacements = {str(p): f'<path-{i}>' for i, p in enumerate(paths) if p}
        if endpoint:
            self.replacements[endpoint.rstrip('/')] = '<endpoint-1>'
            from urllib.parse import urlsplit
            host = urlsplit(endpoint).netloc
            if host:
                self.replacements[host] = '<server-1>'
        self.counts = Counter()

    def clean(self, value):
        if isinstance(value, Proposal):
            return self.clean({**asdict(value), 'fingerprint': value.fingerprint})
        if isinstance(value, Edit):
            return self.clean(asdict(value))
        if isinstance(value, Path):
            return self.clean(str(value))
        if isinstance(value, dict):
            result = {}
            for key, child in value.items():
                if SECRET_FIELD.fullmatch(str(key)):
                    result[self.clean(str(key))] = '<redacted>'
                    self.counts['secret_fields'] += 1
                else:
                    result[self.clean(str(key))] = self.clean(child)
            return result
        if isinstance(value, (list, tuple)):
            return [self.clean(child) for child in value]
        if not isinstance(value, str):
            return value
        for secret in sorted(self.secrets, key=len, reverse=True):
            if secret in value:
                self.counts['known_credentials'] += value.count(secret)
                value = value.replace(secret, '<redacted>')
        value = re.sub(r'(?i)\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+', 'Bearer <redacted>', value)
        # Embedded JSON, code assignments, bearer headers and URLs occur in tool text.
        value, n = re.subn(r'''(?i)((?:api[_-]?key|password|passwd|secret|token|access[_-]?token|refresh[_-]?token|authorization|cookie)["']?\s*[:=]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s,;}]+)''',
                           r'\1"<redacted>"', value)
        self.counts['credential_patterns'] += n
        value = re.sub(r'\bsk-[A-Za-z0-9_-]{12,}', '<redacted>', value)
        value = re.sub(r'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----.*?-----END (?:[A-Z ]+ )?PRIVATE KEY-----',
                       '<redacted-private-key>', value, flags=re.S)
        value = re.sub(r'(https?://)[^/\s:@]+:[^/\s@]+@', r'\1<redacted>@', value)
        value = re.sub(r'(?i)([?&](?:key|api_key|token|password|secret)=)[^&#\s]+', r'\1<redacted>', value)
        for path, replacement in sorted(self.replacements.items(), key=lambda row: len(row[0]), reverse=True):
            value = value.replace(path, replacement).replace(path.replace('\\', '/'), replacement)
        value = re.sub(r'(?i)[A-Z]:[\\/]Users[\\/][^\\/\s"<>]+', '<user-home>', value)
        value = re.sub(r'/(?:home|Users)/[^/\s"<>]+', '<user-home>', value)
        return value

    def verify(self, content):
        if any(secret.encode() in content for secret in self.secrets):
            raise AssistantError('BENCHMARK_SECRET', 'Export blocked: a known credential remains.')


def environment():
    from importlib.metadata import version, PackageNotFoundError
    packages = {}
    for package in ('openai', 'PyQt5', 'openpyxl', 'tiktoken', 'psutil'):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {'os': platform.system(), 'os_release': platform.release(), 'architecture': platform.machine(),
            'python': platform.python_version(), 'logical_cpus': os.cpu_count(), 'dependencies': packages,
            'scope': 'application host; remote inference hardware unknown',
            'gpu': {'available': False, 'reason': 'No GPU collector configured'}}


def resources():
    result = {'process_cpu_seconds': time.process_time(), 'rss_bytes': None, 'available_ram_bytes': None}
    try:
        import psutil
        result.update(rss_bytes=psutil.Process().memory_info().rss,
                      available_ram_bytes=psutil.virtual_memory().available, collector='psutil')
    except (ImportError, OSError):
        result['collector'] = 'stdlib; RSS and RAM unavailable'
        if os.name == 'nt':
            import ctypes
            from ctypes import wintypes
            class MemoryStatus(ctypes.Structure):
                _fields_ = [('length', wintypes.DWORD), ('load', wintypes.DWORD),
                            *[(name, ctypes.c_ulonglong) for name in ('total', 'available', 'total_page', 'available_page', 'total_virtual', 'available_virtual', 'extended')]]
            class ProcessMemory(ctypes.Structure):
                _fields_ = [('cb', wintypes.DWORD), ('faults', wintypes.DWORD),
                            *[(name, ctypes.c_size_t) for name in ('peak_rss', 'rss', 'peak_paged', 'paged', 'peak_nonpaged', 'nonpaged', 'pagefile', 'peak_pagefile')]]
            try:
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                psapi = ctypes.WinDLL('psapi', use_last_error=True)
                kernel.GetCurrentProcess.restype = wintypes.HANDLE
                psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessMemory), wintypes.DWORD]
                memory, process = MemoryStatus(), ProcessMemory()
                memory.length = ctypes.sizeof(memory)
                process.cb = ctypes.sizeof(process)
                if kernel.GlobalMemoryStatusEx(ctypes.byref(memory)):
                    result.update(available_ram_bytes=memory.available, total_ram_bytes=memory.total)
                if psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(process), process.cb):
                    result.update(rss_bytes=process.rss, peak_rss_bytes=process.peak_rss)
                result['collector'] = 'Windows memory APIs'
            except (OSError, AttributeError):
                pass
    return result


class Recorder:
    def __init__(self, folder, sanitizer, max_bytes):
        self.folder, self.sanitizer = Path(folder), sanitizer
        self.folder.mkdir(parents=True, exist_ok=False)
        self.max_bytes, self.bytes, self.sequence = max_bytes, 0, 0
        self.started = time.monotonic()
        self.scope = {}
        self.last_resource = 0
        self.lock = threading.RLock()
        self.metrics = Counter()

    def event(self, kind, payload):
        with self.lock:
            try:
                self._event(kind, payload)
            except AssistantError:
                raise
            except Exception as exc:
                message = self.sanitizer.clean(f'Could not record event {kind}: {type(exc).__name__}: {exc}')
                raise AssistantError('BENCHMARK_RECORDING_FAILED', message) from exc

    def _event(self, kind, payload):
        self.sequence += 1
        row = {'sequence': self.sequence, 'utc': utc_now(), 'elapsed_seconds': time.monotonic()-self.started,
               **self.scope, 'kind': kind, 'payload': payload}
        content = (json.dumps(self.sanitizer.clean(row), ensure_ascii=False) + '\n').encode('utf-8')
        if self.bytes + len(content) > self.max_bytes:
            raise AssistantError('BENCHMARK_TRACE_LIMIT', 'Trace size limit reached; evidence is incomplete.')
        self.sanitizer.verify(content)
        with (self.folder / 'events.jsonl').open('ab') as stream:
            stream.write(content)
        self.bytes += len(content)
        if kind == 'provider_usage':
            self.metrics['responses_with_usage'] += 1
            for field in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
                if type(payload.get(field)) is int:
                    self.metrics[field] += payload[field]
        elif kind == 'tool_result':
            self.metrics['tool_returns'] += 1
            self.metrics['tool_failures'] += int(not payload.get('result', {}).get('ok'))
        elif kind == 'provider_reasoning_delta':
            self.metrics['exposed_reasoning_characters'] += len(payload)

    def write(self, name, value):
        cleaned = self.sanitizer.clean(value)
        self.sanitizer.verify(json.dumps(cleaned, ensure_ascii=False).encode())
        atomic_json(self.folder / name, cleaned)

    def sample(self):
        with self.lock:
            if time.monotonic()-self.last_resource >= 1:
                self.last_resource = time.monotonic()
                self.event('host_resources', resources())


def summarize(manifest, cases, status, error=None):
    groups = {}
    for case in cases:
        key = case['mode']
        group = groups.setdefault(key, {'executed': 0, 'passed': 0, 'seconds': 0, 'actual_models': [], 'multi_model_exercised': False})
        group['executed'] += 1
        group['passed'] += int(case.get('passed', False))
        group['seconds'] += case.get('seconds', 0)
        group['actual_models'] = sorted(set(group['actual_models']) | set(case.get('actual_models', [])))
        group['multi_model_exercised'] = len(group['actual_models']) >= 2
    candidates = {}
    for case in cases:
        if case.get('candidate'):
            candidate_key = case['mode']+':'+case['candidate']
            group = candidates.setdefault(candidate_key, {'calibration_passed': 0, 'calibration_total': 0,
                'validation_passed': 0, 'validation_total': 0, 'seconds': 0, 'settings': case.get('candidate_settings', {}), 'mode': case['mode']})
            prefix = case['partition']
            group[prefix+'_passed'] += int(case.get('passed', False))
            group[prefix+'_total'] += 1
            group['seconds'] += case.get('seconds', 0)
    recommendations = {'status': 'insufficient_evidence', 'message': 'Inspect failed checks and traces. No saved settings were changed.'}
    if status == 'completed' and candidates:
        recommendations = {'status': 'candidate_for_review', 'selected_using': 'calibration only; validation shown separately',
                           'by_mode': {}, 'message': 'Small synthetic sample; inspect tradeoffs before changing settings.'}
        for mode in {group['mode'] for group in candidates.values()}:
            ranked = sorted((name for name in candidates if candidates[name]['mode'] == mode),
                key=lambda name: (-candidates[name]['calibration_passed']/max(1, candidates[name]['calibration_total']), candidates[name]['seconds']))
            best = ranked[0]
            evidence = candidates[best]
            recommendations['by_mode'][mode] = {'candidate': best, 'settings': evidence['settings'],
                'validation_passed': evidence['validation_passed'], 'validation_total': evidence['validation_total'],
                'validated': evidence['validation_total'] > 0 and evidence['validation_total'] == evidence['validation_passed']}
    domain_groups = {}
    for case in cases:
        group = domain_groups.setdefault(case['mode']+'/'+case.get('domain', 'unknown'), [])
        group.append(case)
    domains = {}
    for name, rows in domain_groups.items():
        durations = sorted(row.get('seconds', 0) for row in rows)
        domains[name] = {'executed': len(rows), 'passed': sum(bool(row.get('passed')) for row in rows),
                         'p50_seconds': statistics.median(durations),
                         'p95_seconds': durations[math.ceil(len(durations)*.95)-1]}
    return {'schema_version': SCHEMA_VERSION, 'run_id': manifest['run_id'], 'status': status,
            'updated_utc': utc_now(), 'scheduled': len(manifest['matrix']), 'executed': len(cases),
            'passed': sum(bool(c.get('passed')) for c in cases),
            'not_executed': len(manifest['matrix'])-len(cases), 'by_mode': groups, 'error': error,
            'by_mode_domain': domains,
            'interpretation': 'Development measurements. Failures do not alone establish hardware insufficiency.',
            'limits_candidates': candidates, 'recommendations': recommendations}


def recover_event_tail(folder):
    """Repair only an interrupted final JSONL write; never hide interior corruption."""
    path = Path(folder)/'events.jsonl'
    if not path.is_file() or path.is_symlink():
        return
    offset, last_sequence = 0, 0
    with path.open('rb') as stream:
        for line in stream:
            try:
                value = json.loads(line)
                last_sequence = value.get('sequence', last_sequence)
            except (ValueError, UnicodeError):
                if stream.read(1):
                    raise ValueError('Report contains interior event corruption.')
                dropped = path.stat().st_size-offset
                break
            offset += len(line)
        else:
            return
    marker = {'sequence': last_sequence+1, 'utc': utc_now(), 'kind': 'recording_interrupted',
              'payload': {'dropped_incomplete_tail_bytes': dropped, 'trace_complete': False}}
    with path.open('r+b') as stream:
        stream.truncate(offset)
        stream.seek(offset)
        stream.write((json.dumps(marker)+'\n').encode())


def render_report(folder):
    folder = Path(folder)
    summary = json.loads((folder / 'summary.json').read_text(encoding='utf-8'))
    rows = json.loads((folder / 'cases.json').read_text(encoding='utf-8'))
    body = '<h1>Assistant benchmark</h1><pre>' + html.escape(json.dumps(summary, indent=2)) + '</pre>'
    body += '<table><tr><th>Case</th><th>Mode</th><th>Result</th><th>Seconds</th></tr>'
    for row in rows:
        values = (row['id'], row['mode'], row.get('status', 'passed' if row.get('passed') else 'failed'), round(row.get('seconds', 0), 2))
        body += '<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in values)+'</tr>'
    body += '</table><h2>Case evidence</h2><pre>'+html.escape(json.dumps(rows, ensure_ascii=False, indent=2))+'</pre>'
    chats = folder/'chats.json'
    if chats.is_file():
        body += '<h2>User-selected chats (diagnostics; excluded from scores)</h2><pre>'
        body += html.escape(json.dumps(json.loads(chats.read_text(encoding='utf-8')), ensure_ascii=False, indent=2))+'</pre>'
    content = '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>Assistant benchmark</title><style>body{font:15px system-ui;margin:32px}pre{white-space:pre-wrap;overflow-wrap:anywhere}td,th{padding:8px;border:1px solid #ccc}table{border-collapse:collapse}</style>'+body
    (folder / 'report.html').write_text(content, encoding='utf-8')


EXPORT_FILES = ('manifest.json', 'summary.json', 'cases.json', 'events.jsonl', 'chats.json', 'report.html')


def export_bundle(folder, destination, sanitizer=None):
    """Only export known artifacts. Never recursively zip a user-selected directory."""
    folder, destination = Path(folder), Path(destination)
    if any(destination.resolve() == (folder / name).resolve() for name in EXPORT_FILES):
        raise AssistantError('BENCHMARK_EXPORT', 'Choose a ZIP path outside the report artifacts.')
    sanitizer = sanitizer or Sanitizer()
    content = {}
    for name in EXPORT_FILES:
        path = folder / name
        if path.is_file() and not path.is_symlink():
            raw = path.read_bytes()
            if name.endswith('.json'):
                raw = json.dumps(sanitizer.clean(json.loads(raw)), ensure_ascii=False, indent=2).encode()
            elif name.endswith('.jsonl'):
                raw = ('\n'.join(json.dumps(sanitizer.clean(json.loads(line)), ensure_ascii=False)
                                  for line in raw.decode('utf-8').splitlines() if line.strip())+'\n').encode()
            else:
                raw = sanitizer.clean(raw.decode('utf-8')).encode()
            sanitizer.verify(raw)
            content[name] = raw
    if not {'manifest.json', 'summary.json', 'cases.json'} <= content.keys():
        raise AssistantError('BENCHMARK_EXPORT', 'This report is missing its manifest, summary or cases.')
    inventory = {name: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name, raw in content.items()}
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in content.items():
            archive.writestr(name, raw)
        archive.writestr('inventory.json', json.dumps(inventory, indent=2))
