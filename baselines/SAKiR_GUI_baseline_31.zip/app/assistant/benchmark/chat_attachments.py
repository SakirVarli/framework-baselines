"""Explicitly selected real-chat snapshots, separate from scored benchmark cases."""
import copy
import json
from pathlib import Path
import time
import uuid

from ..policy import AssistantError, digest, file_hash
from ..storage import atomic_json
from .configuration import SUITE_VERSION, suite_fingerprint
from .reporting import (SCHEMA_VERSION, Sanitizer, environment, render_report,
                        safe_settings, summarize, utc_now)

MAX_ATTACHMENT_BYTES = 16*1024*1024
MAX_CHATS_BYTES = 32*1024*1024


def chat_snapshot(controller, session_id, title, messages, activities=()):
    """Read only selected-session evidence; never change the active chat or call a model."""
    if not messages:
        raise AssistantError('BENCHMARK_CHAT_EMPTY', 'This chat has no messages to attach.')
    controller.store._session_key(session_id)
    secrets = [getattr(controller.credentials, 'session', '')]
    try:
        secrets.append(controller.credentials.key(controller.settings))
    except (AssistantError, OSError):
        pass  # Exporting a saved chat does not require a working inference credential.
    sanitizer = Sanitizer(secrets, paths=(str(controller.policy.root), str(Path.home())),
                          endpoint=controller.settings.base_url)
    unavailable = ['Original provider request/response streams were not recorded for ordinary chats.',
                   'Complete reasoning and tool history cannot be reconstructed after the fact.',
                   'Activity previews can be shortened; historical model settings may be unavailable.']
    workflows = []
    try:
        workflows = [copy.deepcopy(row) for row in controller.workflow_store.records()
                     if row.get('session_id') == session_id]
    except (OSError, ValueError) as exc:
        unavailable.append('Retained workflow checkpoints unavailable: '+str(exc))
    source_ref = digest(['chat-source', session_id])
    application = Path(__file__).resolve().parents[3]
    implementation = digest([(p.relative_to(application).as_posix(), file_hash(p))
        for p in sorted((application/'app/assistant').rglob('*.py')) if '__pycache__' not in p.parts])
    for workflow in workflows:
        workflow['session_id'] = source_ref
    failures = []
    path = controller.store.private/'failures'/f'{session_id}.json'
    if path.is_file() and not path.is_symlink():
        if path.stat().st_size <= MAX_ATTACHMENT_BYTES:
            try:
                failures = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                unavailable.append('Saved failure records could not be read.')
        else:
            unavailable.append('Saved failure records exceed the attachment limit.')
    payload = sanitizer.clean({'schema_version': 1, 'attachment_id': digest([session_id, messages]),
        'kind': 'user_selected_chat', 'captured_utc': utc_now(), 'source_session_ref': source_ref,
        'title': title, 'messages': copy.deepcopy(messages), 'retained_activity': copy.deepcopy(list(activities)),
        'retained_workflows': workflows, 'saved_failures': failures,
        'current_settings': safe_settings(controller.settings),
        'environment_at_attachment': environment(), 'implementation_at_attachment': implementation,
        'settings_provenance': 'Settings at attachment time; not asserted to be the settings used for historical turns.',
        'capture_completeness': {'full_benchmark_trace': False, 'limitations': unavailable},
        'user_note': '', 'scoring': 'Diagnostic attachment only; excluded from benchmark cases, pass rates and recommendations.'})
    raw = json.dumps(payload, ensure_ascii=False).encode()
    sanitizer.verify(raw)
    if len(raw) > MAX_ATTACHMENT_BYTES:
        raise AssistantError('BENCHMARK_CHAT_LIMIT', 'Chat diagnostics exceed 16 MiB. Nothing was attached.')
    return payload, sanitizer


def available_reports(private):
    folder = Path(private)/'benchmarks'
    result = []
    if folder.is_dir():
        for path in sorted(folder.iterdir(), reverse=True):
            if not path.is_dir() or path.is_symlink():
                continue
            try:
                summary = json.loads((path/'summary.json').read_text(encoding='utf-8'))
                if summary['status'] == 'running' or not (path/'manifest.json').is_file():
                    continue
                result.append((path, summary))
            except (OSError, ValueError, KeyError):
                continue
    return result


def attach_chat(private, payload, sanitizer, report=None):
    """Write a sanitized snapshot; never rewrite benchmark cases, scores or events."""
    base = Path(private)/'benchmarks'
    base.mkdir(parents=True, exist_ok=True)
    existing = []
    if report is not None:
        folder = Path(report)
        if folder.is_symlink() or folder.resolve().parent != base.resolve():
            raise AssistantError('BENCHMARK_CHAT_REPORT', 'Choose a report in this project’s benchmark history.')
        if not folder.is_dir():
            raise AssistantError('BENCHMARK_CHAT_REPORT', 'The selected report no longer exists.')
        for name in ('manifest.json', 'summary.json', 'cases.json', 'chats.json', 'report.html'):
            if (folder/name).is_symlink():
                raise AssistantError('BENCHMARK_CHAT_REPORT', 'Linked report artifacts are not supported.')
        summary = json.loads((folder/'summary.json').read_text(encoding='utf-8'))
        if summary['status'] == 'running':
            raise AssistantError('BENCHMARK_CHAT_RUNNING', 'Wait for the benchmark to finish before attaching a chat.')
        if (folder/'chats.json').is_file():
            if (folder/'chats.json').stat().st_size > MAX_CHATS_BYTES:
                raise AssistantError('BENCHMARK_CHAT_LIMIT', 'This report exceeds the chat attachment limit.')
            existing = json.loads((folder/'chats.json').read_text(encoding='utf-8'))
            if not isinstance(existing, list):
                raise AssistantError('BENCHMARK_CHAT_REPORT', 'Invalid chat attachment records.')
    else:
        folder = base/(time.strftime('%Y%m%d-%H%M%S')+'-chat-'+uuid.uuid4().hex[:8])
    cleaned = sanitizer.clean(payload)
    rows = sanitizer.clean([row for row in existing if row.get('attachment_id') != cleaned['attachment_id']] + [cleaned])
    raw = json.dumps(rows, ensure_ascii=False).encode()
    sanitizer.verify(raw)
    if len(raw) > MAX_CHATS_BYTES:
        raise AssistantError('BENCHMARK_CHAT_LIMIT', 'Chat attachments would exceed 32 MiB. Nothing was attached.')
    if report is None:
        folder.mkdir(exist_ok=False)
        manifest = {'schema_version': SCHEMA_VERSION, 'suite_version': SUITE_VERSION,
            'suite_fingerprint': suite_fingerprint(), 'run_id': uuid.uuid4().hex, 'created_utc': utc_now(),
            'kind': 'chat_diagnostic', 'matrix': [], 'options': {}, 'environment': environment(),
            'implementation_fingerprint': cleaned['implementation_at_attachment'],
            'scope': 'User-selected chat diagnostics; no benchmark cases or inference were executed.'}
        summary = summarize(manifest, [], 'diagnostic')
        atomic_json(folder/'manifest.json', sanitizer.clean(manifest))
        atomic_json(folder/'summary.json', sanitizer.clean(summary))
        atomic_json(folder/'cases.json', [])
    atomic_json(folder/'chats.json', rows)
    render_report(folder)
    return folder
