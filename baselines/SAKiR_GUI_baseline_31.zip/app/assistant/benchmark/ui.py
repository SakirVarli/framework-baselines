"""Settings benchmark panel with a killable subprocess and local report history."""
from dataclasses import asdict
import json
from pathlib import Path
import sys
import time
import uuid

from PyQt5 import QtCore, QtWidgets

from ..appearance import ComboBox
from ..policy import AssistantError
from ..storage import atomic_json
from .configuration import BenchmarkOptions
from .status_ui import BenchmarkStatus
from .reporting import Sanitizer, export_bundle, render_report, summarize, recover_event_tail, EXPORT_FILES


class BenchmarkPanel(QtWidgets.QWidget):
    def __init__(self, settings_dialog):
        super().__init__(settings_dialog)
        self.dialog = settings_dialog
        self.folder = settings_dialog.controller.store.private / 'benchmarks'
        self.process = None
        self.output = None
        self.buffer = b''
        self.sanitizer = Sanitizer()
        self.started = None
        self.options_snapshot = None
        outer = QtWidgets.QVBoxLayout(self)
        notice = QtWidgets.QLabel('Live tests use synthetic projects and the connection/limits in Settings. '
            'Model requests may incur charges. Detailed benchmark traces are filtered and kept locally; export to share.')
        notice.setToolTip('Changes are staged only. Benchmark chats, provider-exposed reasoning, tools, results and settings '
            'are recorded with confidential values filtered. Unrelated chats and project files are excluded. '
            'Review the exported report before committing it to Git.')
        notice.setWordWrap(True)
        outer.addWidget(notice)
        form = QtWidgets.QFormLayout()
        outer.addLayout(form)
        self.level = ComboBox()
        for label, value in [('Quick', 'quick'), ('Standard', 'standard'), ('Full live suite', 'full'), ('Limits study (model rounds)', 'limits')]:
            self.level.addItem(label, value)
        self.model_mode = ComboBox()
        for label, value in [('Single model', 'single'), ('Multi-model (Agent Models)', 'multi'), ('Compare both', 'compare')]:
            self.model_mode.addItem(label, value)
        self.repetitions = self.spin(1, 10, 1)
        self.minutes = self.spin(1, 720, 10)
        self.requests = self.spin(1, 100000, 300)
        self.trace = self.spin(1, 1024, 64)
        for label, widget, help_text in [
            ('Benchmark level', self.level, 'Quick: 5 representative cases. Standard: 16 cases. Full: all registered live cases. Limits study compares current/fewer/more model rounds with separate calibration and validation cases.'),
            ('Model mode', self.model_mode, 'Multi-model uses Agent Models assignments on the same endpoint. At least two models must pass tool probes. Each case records the models actually used.'),
            ('Repetitions', self.repetitions, 'Repeat the frozen case matrix. Compare mode reverses mode order on alternating repetitions.'),
            ('Whole-run deadline (minutes)', self.minutes, 'Includes preflight, probes, fixture setup and all cases. A capped run is partial, not a full-suite pass.'),
            ('Maximum model requests', self.requests, 'Hard whole-run model request count, including probes, summaries and reviews. Token usage is reported when available.'),
            ('Trace limit (MiB)', self.trace, 'Stop if detailed trace exceeds this limit. Retain a partial report with an explicit diagnostic-limit outcome.')]:
            form.addRow(label, widget)
            widget.setToolTip(help_text)
            widget.setAccessibleName(label)
            widget.setAccessibleDescription(help_text)
        self.preview = QtWidgets.QLabel()
        self.preview.setWordWrap(True)
        outer.addWidget(self.preview)
        buttons = QtWidgets.QHBoxLayout()
        self.run_button = QtWidgets.QPushButton('Run Benchmark')
        self.stop_button = QtWidgets.QPushButton('Stop')
        self.stop_button.setEnabled(False)
        buttons.addWidget(self.run_button)
        buttons.addWidget(self.stop_button)
        buttons.addStretch()
        outer.insertLayout(0, buttons)
        outer.insertWidget(1, self.preview)
        self.status = BenchmarkStatus(self)
        self.progress = self.status.progress
        outer.insertWidget(2, self.status)
        self.history = ComboBox()
        self.history.setAccessibleName('Benchmark results')
        outer.addWidget(self.history)
        reports = QtWidgets.QHBoxLayout()
        self.preview_button = QtWidgets.QPushButton('Preview report')
        self.export_button = QtWidgets.QPushButton('Export report ZIP for Git')
        reports.addWidget(self.preview_button)
        reports.addWidget(self.export_button)
        outer.addLayout(reports)
        actions = QtWidgets.QHBoxLayout()
        self.recommend_button = QtWidgets.QPushButton('Review recommended round limit')
        self.delete_button = QtWidgets.QPushButton('Delete selected report')
        actions.addWidget(self.recommend_button)
        actions.addWidget(self.delete_button)
        outer.addLayout(actions)
        outer.addStretch()
        self.controls = (self.level, self.model_mode, self.repetitions, self.minutes, self.requests, self.trace)
        self.level.currentIndexChanged.connect(self.level_changed)
        self.model_mode.currentIndexChanged.connect(self.update_preview)
        for widget in (self.repetitions, self.minutes, self.requests, self.trace):
            widget.valueChanged.connect(self.update_preview)
        self.run_button.clicked.connect(self.start)
        self.stop_button.clicked.connect(self.stop)
        self.preview_button.clicked.connect(self.show_report)
        self.export_button.clicked.connect(self.export)
        self.recommend_button.clicked.connect(self.review_recommendation)
        self.delete_button.clicked.connect(self.delete_report)
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.tick)
        self.load_options()
        self.refresh_history()
        self.update_preview()

    @staticmethod
    def spin(low, high, value):
        widget = QtWidgets.QSpinBox()
        widget.setRange(low, high)
        widget.setValue(value)
        return widget

    def options(self):
        return BenchmarkOptions(self.level.currentData(), self.model_mode.currentData(), self.repetitions.value(),
                                self.minutes.value()*60, self.requests.value(), self.trace.value())

    def load_options(self):
        try:
            options = BenchmarkOptions(**json.loads((self.folder.parent/'benchmark-settings.json').read_text(encoding='utf-8')))
            options.validate()
            self.level.setCurrentIndex(self.level.findData(options.level))
            self.model_mode.setCurrentIndex(self.model_mode.findData(options.mode))
            self.repetitions.setValue(options.repetitions)
            self.minutes.setValue(max(1, options.run_seconds//60))
            self.requests.setValue(options.max_requests)
            self.trace.setValue(options.trace_mib)
        except (OSError, ValueError, TypeError):
            pass

    def update_preview(self, *_):
        options = self.options()
        self.preview.setText(f'{len(options.matrix())} scheduled case runs. Whole-run cap: {self.minutes.value()} minutes / '
            f'{options.max_requests:,} model requests / {options.trace_mib} MiB trace. '
            'Per-response, context, round, tool and task limits come from the current Settings snapshot. '
            'Server cache is uncontrolled. Remote server hardware is unknown unless advertised.')

    def level_changed(self, *_):
        self.minutes.setValue({'quick': 10, 'standard': 45, 'full': 180, 'limits': 90}[self.level.currentData()])
        self.requests.setValue({'quick': 300, 'standard': 1000, 'full': 10000, 'limits': 3000}[self.level.currentData()])
        self.repetitions.setValue(3 if self.level.currentData() == 'full' else 2 if self.level.currentData() == 'limits' else 1)
        self.update_preview()

    def start(self):
        if self.process is not None:
            return
        try:
            if getattr(self.dialog.controller, 'busy', False):
                raise AssistantError('BENCHMARK_BUSY', 'Wait for the current assistant turn to finish before benchmarking.')
            settings = self.dialog.collect()
            settings.validate()
            key = self.dialog.key_for(settings)
            options = self.options()
            options.validate()
            self.folder.mkdir(parents=True, exist_ok=True)
            atomic_json(self.folder.parent/'benchmark-settings.json', asdict(options))
            self.output = self.folder / (time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
            self.sanitizer = Sanitizer((key, self.dialog.key.text()), paths=(str(Path.home()),), endpoint=settings.base_url)
            self.buffer = b''
            self.options_snapshot = options
            self.process = QtCore.QProcess(self)
            self.process.setProgram(sys.executable)
            self.process.setArguments(['-B', '-m', 'app.assistant.benchmark.worker'])
            self.process.setWorkingDirectory(str(Path(__file__).resolve().parents[3]))
            self.process.setProcessChannelMode(QtCore.QProcess.SeparateChannels)
            self.process.readyReadStandardOutput.connect(self.read_progress)
            self.process.readyReadStandardError.connect(self.discard_stderr)
            self.process.finished.connect(self.finished)
            self.process.errorOccurred.connect(self.process_error)
            payload = {'settings': asdict(settings), 'key': key, 'options': asdict(options),
                       'output': str(self.output), 'secrets': [self.dialog.key.text()]}
            self.process.started.connect(lambda: self.send_payload(payload))
            self.started = time.monotonic()
            self.status.begin(len(options.matrix()), options.max_requests)
            self.set_running(True)
            self.timer.start()
            self.process.start()
        except Exception as exc:
            self.status.finish('failed', self.sanitizer.clean(str(exc)))

    def send_payload(self, payload):
        if self.process:
            self.process.write((json.dumps(payload, ensure_ascii=True)+'\n').encode())

    def set_running(self, running):
        for widget in self.controls:
            widget.setEnabled(not running)
        self.run_button.setEnabled(not running)
        self.stop_button.setEnabled(running)
        self.export_button.setEnabled(not running)
        self.preview_button.setEnabled(not running)
        self.recommend_button.setEnabled(not running)
        self.delete_button.setEnabled(not running)
        self.dialog.buttons.setEnabled(not running)

    def read_progress(self):
        if self.process is None:
            return
        self.buffer += bytes(self.process.readAllStandardOutput())
        while b'\n' in self.buffer:
            line, self.buffer = self.buffer.split(b'\n', 1)
            try:
                value = self.sanitizer.clean(json.loads(line))
            except (ValueError, UnicodeError):
                continue
            if isinstance(value, dict):
                self.status.apply_event(value)

    def discard_stderr(self):
        if self.process:
            self.process.readAllStandardError()  # Never display or persist unfiltered SDK stderr.

    def tick(self):
        self.status.update_clock()
        if self.process and time.monotonic()-self.started > self.options_snapshot.run_seconds+10:
            self.status.request_stop('Whole-run deadline reached. Stopping worker and retaining partial results.')
            self.process.kill()

    def stop(self):
        if self.process:
            self.process.write(b'stop\n')
            self.stop_button.setEnabled(False)
            self.status.request_stop('Stopping… Completed cases will be retained.')
            process = self.process
            QtCore.QTimer.singleShot(5000, lambda: process.kill() if self.process is process else None)

    def process_error(self, error):
        if error == QtCore.QProcess.FailedToStart:
            self.status.finish('failed', 'Benchmark worker could not start.')
            self.finished(-1)

    def finished(self, *_):
        self.timer.stop()
        self.read_progress()
        if self.output and (self.output/'manifest.json').is_file():
            try:
                manifest = json.loads((self.output/'manifest.json').read_text(encoding='utf-8'))
                summary = json.loads((self.output/'summary.json').read_text(encoding='utf-8'))
                cases = json.loads((self.output/'cases.json').read_text(encoding='utf-8'))
                if summary['status'] == 'running':
                    summary = summarize(manifest, cases, 'interrupted', {'code': 'WORKER_INTERRUPTED', 'message': 'Worker stopped before finalization. Active case evidence may be incomplete.'})
                    atomic_json(self.output/'summary.json', self.sanitizer.clean(summary))
                    recover_event_tail(self.output)
                render_report(self.output)
                self.progress.setMaximum(max(1, summary['scheduled']))
                self.progress.setValue(summary['executed'])
                self.status.counts = {
                    'passed': sum(bool(case.get('passed')) for case in cases),
                    'failed': sum(not case.get('passed') and case.get('status') != 'unsupported' for case in cases),
                    'unsupported': sum(case.get('status') == 'unsupported' for case in cases)}
                self.status.update_results()
                self.status.request_count = summary.get('model_requests', self.status.request_count)
                self.status.finish(summary['status'], self.sanitizer.clean(summary.get('error')))
            except (OSError, ValueError, KeyError):
                self.status.add_message('Partial report could not be finalized; inspect the retained artifacts.')
        if not self.status.terminal:
            self.status.finish('interrupted', 'Worker stopped before finalization. Completed cases have been retained when available.')
        process, self.process = self.process, None
        if process:
            process.deleteLater()
        self.set_running(False)
        self.refresh_history()

    def refresh_history(self):
        self.history.clear()
        if self.folder.is_dir():
            for path in sorted(self.folder.iterdir(), reverse=True):
                if not path.is_dir() or path.is_symlink():
                    continue
                try:
                    summary = json.loads((path/'summary.json').read_text(encoding='utf-8'))
                    if summary.get('status') == 'running' and self.process is None:
                        summary.update(status='interrupted', trace_complete=False,
                                       error={'code': 'WORKER_INTERRUPTED', 'message': 'Previous worker did not finalize this report.'})
                        atomic_json(path/'summary.json', summary)
                        recover_event_tail(path)
                        render_report(path)
                    label = f'{path.name}: {summary["status"]} — {summary["passed"]}/{summary["scheduled"]} passed'
                    if (path/'chats.json').is_file():
                        count = len(json.loads((path/'chats.json').read_text(encoding='utf-8')))
                        label = (f'{path.name}: chat diagnostic' if summary['status'] == 'diagnostic' else label)
                        label += f' · {count} attached chat(s)'
                    self.history.addItem(label, str(path))
                except (OSError, ValueError, KeyError):
                    continue

    def show_report(self):
        selected = self.history.currentData()
        if not selected:
            return
        try:
            folder = Path(selected)
            dialog = QtWidgets.QDialog(self)
            dialog.setWindowTitle('Benchmark report — review before sharing')
            dialog.resize(900, 700)
            layout = QtWidgets.QVBoxLayout(dialog)
            text = QtWidgets.QPlainTextEdit()
            text.setReadOnly(True)
            text.setPlainText('\n\n'.join(name+'\n'+(folder/name).read_text(encoding='utf-8')
                                          for name in ('summary.json', 'manifest.json', 'cases.json', 'chats.json')
                                          if (folder/name).is_file()))
            layout.addWidget(text)
            dialog.exec_()
        except Exception as exc:
            self.status.add_message(self.sanitizer.clean(str(exc)))

    def export(self):
        selected = self.history.currentData()
        if not selected:
            return
        destination, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Export sanitized benchmark report',
            str(Path.home()/('assistant-benchmark-'+Path(selected).name+'.zip')), 'ZIP reports (*.zip)')
        if destination:
            try:
                export_bundle(selected, destination, self.sanitizer)
                self.status.add_message('Sanitized report exported. Commit the ZIP to Git and share its repository path for analysis.')
            except Exception as exc:
                self.status.add_message(self.sanitizer.clean(str(exc)))

    def review_recommendation(self):
        selected = self.history.currentData()
        if not selected:
            return
        try:
            summary = json.loads((Path(selected)/'summary.json').read_text(encoding='utf-8'))
            choices = summary.get('recommendations', {}).get('by_mode', {})
            validated = {mode: row for mode, row in choices.items() if row.get('validated') and type(row.get('settings', {}).get('max_rounds')) is int}
            if not validated:
                self.status.add_message('No validated round-limit recommendation in this report. Review the failed checks and traces.')
                return
            dialog = QtWidgets.QDialog(self)
            dialog.setWindowTitle('Review benchmark recommendation')
            layout = QtWidgets.QVBoxLayout(dialog)
            selector = ComboBox()
            for mode, row in validated.items():
                value = row['settings']['max_rounds']
                if 1 <= value <= 40:
                    selector.addItem(f'{mode}: maximum rounds {self.dialog.collect().max_rounds} → {value}', value)
            layout.addWidget(selector)
            label = QtWidgets.QLabel('This changes the round limit in the Settings form and switches to Advanced mode. '
                                    'Review all settings, then Save to apply. Other model/context limits were not tuned. '
                                    'This is a small synthetic validation sample; it does not establish universal performance.')
            label.setWordWrap(True)
            layout.addWidget(label)
            buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Apply | QtWidgets.QDialogButtonBox.Cancel)
            layout.addWidget(buttons)
            def apply():
                if selector.currentData():
                    self.apply_round_limit(selector.currentData())
                dialog.accept()
            buttons.button(QtWidgets.QDialogButtonBox.Apply).clicked.connect(apply)
            buttons.rejected.connect(dialog.reject)
            dialog.exec_()
        except Exception as exc:
            self.status.add_message(self.sanitizer.clean(str(exc)))

    def apply_round_limit(self, value):
        from ..settings_policy import AUTOMATIC_FIELDS
        effective = self.dialog.collect()
        # Carry current effective preset values into Advanced so the diff is only rounds.
        for key in AUTOMATIC_FIELDS:
            widget = self.dialog.widgets[key]
            current = getattr(effective, key)
            if isinstance(widget, QtWidgets.QComboBox):
                widget.setCurrentIndex(widget.findData(current))
            elif isinstance(widget, QtWidgets.QCheckBox):
                widget.setChecked(current)
            else:
                widget.setValue(current)
        self.dialog.mode.setCurrentIndex(self.dialog.mode.findData('advanced'))
        self.dialog.widgets['max_rounds'].setValue(value)

    def delete_report(self):
        selected = self.history.currentData()
        if not selected or self.process:
            return
        try:
            target = Path(selected).resolve()
            if target.parent != self.folder.resolve() or Path(selected).is_symlink():
                raise AssistantError('BENCHMARK_DELETE', 'Report is outside the benchmark history folder.')
            # Reports contain only these fixed artifacts; never recursively remove arbitrary paths.
            for name in EXPORT_FILES:
                (target/name).unlink(missing_ok=True)
            target.rmdir()
            self.refresh_history()
        except Exception as exc:
            self.status.add_message(self.sanitizer.clean(str(exc)))
