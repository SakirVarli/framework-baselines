"""Private subprocess entry point; credentials arrive only through stdin."""
import json
from pathlib import Path
import sys
import threading

from ..storage import Settings
from .configuration import BenchmarkOptions
from .reporting import Sanitizer
from .runner import run_benchmark


def main():
    payload = json.loads(sys.stdin.readline())
    cancel = threading.Event()
    def commands():
        for line in sys.stdin:
            if line.strip() == 'stop':
                cancel.set()
        cancel.set()  # Parent closed: do not orphan an inference run.
    threading.Thread(target=commands, daemon=True).start()
    sanitizer = Sanitizer((payload.get('key', ''), *payload.get('secrets', [])),
                          paths=(str(Path.home()),), endpoint=payload['settings'].get('base_url', ''))
    output_lock = threading.Lock()
    def progress(value):
        with output_lock:
            print(json.dumps(sanitizer.clean(value), ensure_ascii=True), flush=True)
    try:
        run_benchmark(Settings(**payload['settings']), payload['key'], BenchmarkOptions(**payload['options']),
                      Path(payload['output']), cancel, progress, secrets=payload.get('secrets', ()))
        return 0
    except Exception as exc:
        progress({'kind': 'fatal', 'message': str(exc)})
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
