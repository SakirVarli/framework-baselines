"""Structured, live benchmark status with an optional bounded event log."""
import json
import time

from PyQt5 import QtCore, QtWidgets


class BenchmarkStatus(QtWidgets.QGroupBox):
    def __init__(self, parent=None):
        super().__init__('Benchmark status', parent)
        self.setAccessibleName('Benchmark status')
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()
        form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        form.setRowWrapPolicy(QtWidgets.QFormLayout.WrapLongRows)
        layout.addLayout(form)
        self.fields = {}
        for key, title in [('state', 'Run'), ('results', 'Results'), ('activity', 'Activity'),
                           ('metrics', 'Usage'), ('health', 'Worker')]:
            label = QtWidgets.QLabel('—')
            label.setTextFormat(QtCore.Qt.PlainText)
            label.setWordWrap(True)
            label.setMinimumWidth(0)
            label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            label.setAccessibleName('Benchmark '+title.lower())
            label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            form.addRow(title, label)
            self.fields[key] = label
        self.progress = QtWidgets.QProgressBar()
        self.progress.setAccessibleName('Completed benchmark cases')
        self.progress.setFormat('%v / %m cases completed')
        layout.addWidget(self.progress)
        self.message = QtWidgets.QLabel()
        self.message.setTextFormat(QtCore.Qt.PlainText)
        self.message.setWordWrap(True)
        self.message.setMinimumWidth(0)
        self.message.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.message.setAccessibleName('Benchmark message')
        layout.addWidget(self.message)
        self.details = QtWidgets.QToolButton()
        self.details.setText('Technical event log')
        self.details.setCheckable(True)
        self.details.setArrowType(QtCore.Qt.RightArrow)
        self.details.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        layout.addWidget(self.details)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setFixedHeight(110)
        self.log.document().setMaximumBlockCount(200)
        self.log.setAccessibleName('Benchmark technical event log')
        layout.addWidget(self.log)
        self.details.toggled.connect(self.toggle_details)
        self.reset()
        self.hide()

    def toggle_details(self, expanded):
        self.details.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.log.setVisible(expanded)

    def reset(self, scheduled=0, request_limit=0):
        self.started = None
        self.ended = None
        self.last_heartbeat = None
        self.terminal = False
        self.stopping = False
        self.case_label = '—'
        self.counts = {'passed': 0, 'failed': 0, 'unsupported': 0}
        self.request_count = 0
        self.request_limit = request_limit
        self.memory = 'Unavailable'
        self.log.clear()
        self.message.clear()
        self.message.hide()
        self.details.setChecked(False)
        self.toggle_details(False)
        self.fields['state'].setText('Ready')
        self.fields['activity'].setText('—')
        self.progress.setRange(0, max(1, scheduled))
        self.progress.setValue(0)
        self.update_results()
        self.update_clock()

    def begin(self, scheduled, request_limit):
        self.reset(scheduled, request_limit)
        self.started = time.monotonic()
        self.fields['state'].setText('Starting')
        self.fields['activity'].setText('Starting isolated benchmark worker…')
        self.show()

    def add_message(self, message):
        self.message.setText(str(message))
        self.message.setVisible(bool(message))
        self.log.appendPlainText(str(message))
        self.show()

    def update_results(self):
        self.fields['results'].setText(' · '.join(f'{value} {key}' for key, value in self.counts.items()))

    def update_clock(self):
        now = self.ended if self.ended is not None else time.monotonic()
        elapsed = max(0, int(now-self.started)) if self.started is not None else 0
        minutes, seconds = divmod(elapsed, 60)
        self.fields['metrics'].setText(
            f'{minutes:02d}:{seconds:02d} elapsed · {self.request_count:,} / {self.request_limit:,} model requests')
        heartbeat = ('Waiting for heartbeat' if self.last_heartbeat is None else
                     f'Last heartbeat: {max(0, int(now-self.last_heartbeat))} seconds ago')
        self.fields['health'].setText(f'{heartbeat} · Memory: {self.memory}')

    def request_stop(self, message):
        self.stopping = True
        self.fields['state'].setText('Stopping')
        self.add_message(message)

    def finish(self, status, error=None):
        if self.ended is None:
            self.ended = time.monotonic()
        self.update_clock()
        self.terminal = True
        self.fields['state'].setText(str(status).replace('_', ' ').capitalize())
        self.fields['activity'].setText('No active case')
        if error:
            if isinstance(error, dict):
                error = ': '.join(str(error[key]) for key in ('code', 'message') if error.get(key))
            self.add_message(error)

    def apply_event(self, value):
        """Accept already-sanitized worker events; heartbeat only refreshes metrics."""
        kind = value.get('kind')
        self.log.appendPlainText(json.dumps(value, ensure_ascii=False))
        if self.terminal:
            return
        self.show()
        if 'requests' in value:
            self.request_count = value['requests']
        if 'scheduled' in value:
            self.progress.setMaximum(max(1, value['scheduled']))
        if 'executed' in value:
            self.progress.setValue(value['executed'])
        if kind == 'heartbeat':
            self.last_heartbeat = time.monotonic()
            rss = (value.get('resources') or {}).get('rss_bytes')
            self.memory = f'{rss / (1024*1024):.1f} MiB' if isinstance(rss, (int, float)) else 'Unavailable'
        elif kind == 'preflight':
            if not self.stopping:
                self.fields['state'].setText('Preflight')
            self.fields['activity'].setText('Discovering models and checking tool support…')
        elif kind == 'case_started':
            if not self.stopping:
                self.fields['state'].setText('Running')
            self.case_label = (f"{value['case']} · {value.get('mode', '—')} · "
                               f"repetition {value.get('repetition', 0)+1}")
            if value.get('candidate'):
                self.case_label += f" · {value['candidate']} ({value.get('partition', '—')})"
            self.fields['activity'].setText(self.case_label)
        elif kind == 'stage':
            stage = ' · '.join(str(value[key]) for key in ('role', 'status', 'model') if value.get(key))
            self.fields['activity'].setText(
                f"{self.case_label}\nTurn {value.get('turn', '—')} · {stage}")
        elif kind == 'case_completed':
            result = 'unsupported' if value.get('status') == 'unsupported' else 'passed' if value.get('passed') else 'failed'
            self.counts[result] += 1
            self.update_results()
            self.fields['activity'].setText(f"{value.get('id', 'Case')}: {result}")
            self.add_message(f"{value.get('id', 'Case')}: {result}.")
        elif kind == 'outcome':
            outcome = value.get('outcome')
            if isinstance(outcome, dict):
                outcome = outcome.get('status') or outcome.get('code')
            if outcome:
                self.add_message(f"Turn outcome: {outcome}")
        elif kind == 'fatal':
            self.finish('failed', value.get('message'))
        elif kind == 'finished':
            self.finish(value.get('status', 'interrupted'), value.get('error'))
        self.update_clock()
