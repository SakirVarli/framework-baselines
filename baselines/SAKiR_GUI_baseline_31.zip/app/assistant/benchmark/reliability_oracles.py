"""Independent benchmark fixtures and assertions; never model context."""
import ast
import copy
import json
import re
import struct
from app.assistant.policy import digest, file_hash
from app.assistant.task_context import layout_rows
from app.assistant.workflow_protocol import completion_checks
from app.starter_project import starter_project_files
CALLBACK_PATH = 'callbacks/callbacks.py'
BROKEN_SEED = 'def seed_callback(required_value):\n    return required_value'
WORKING_SEED = 'def seed_callback():\n    return 42'


def seed_failed_change(root, snapshot):
    source = snapshot['callbacks']
    if source.count(WORKING_SEED) != 1:
        raise ValueError('Expected exactly one original Seed callback in the fixture.')
    broken = source.replace(WORKING_SEED, BROKEN_SEED)
    (root / CALLBACK_PATH).write_text(broken, encoding='utf-8')
    snapshot['callbacks'] = broken
    snapshot['hashes'][CALLBACK_PATH] = file_hash(root / CALLBACK_PATH)
    snapshot['revision'] = digest([snapshot['config'], broken])
    snapshot['recent_errors'] = [{
        'generation': snapshot['runtime_generation'],
        'details': "TypeError: seed_callback() missing 1 required positional argument: 'required_value'",
    }]


def repaired_callback_matches(definitions, exact=True):
    if len(definitions) != 1:
        return False
    definition = copy.copy(definitions[0])
    if ast.get_docstring(definition) is not None:
        definition.body = definition.body[1:]
    if exact:
        return ast.dump(definition) == ast.dump(ast.parse(WORKING_SEED).body[0])

    args = definition.args
    positional = [*args.posonlyargs, *args.args]
    if definition.decorator_list or len(positional) != len(args.defaults) or None in args.kw_defaults:
        return False
    try:
        defaults = {arg.arg: ast.literal_eval(value) for arg, value in
                    zip([*positional, *args.kwonlyargs], [*args.defaults, *args.kw_defaults])}
        if args.vararg:
            defaults[args.vararg.arg] = ()
        if args.kwarg:
            defaults[args.kwarg.arg] = {}
        body = definition.body
        while body:
            statement, *remaining = body
            if isinstance(statement, ast.Return):
                value = statement.value
                returned = defaults[value.id] if isinstance(value, ast.Name) else ast.literal_eval(value)
                return type(returned) is int and returned == 42
            if (isinstance(statement, ast.If) and isinstance(statement.test, ast.Compare)
                    and isinstance(statement.test.left, ast.Name)
                    and len(statement.test.ops) == 1
                    and isinstance(statement.test.ops[0], (ast.Is, ast.IsNot))
                    and isinstance(statement.test.comparators[0], ast.Constant)
                    and statement.test.comparators[0].value is None):
                is_none = defaults[statement.test.left.id] is None
                branch = statement.body if is_none == isinstance(statement.test.ops[0], ast.Is) else statement.orelse
                body = [*branch, *remaining]
                continue
            return False
    except (ValueError, TypeError, KeyError):
        return False
    return False


def check_case(case, turns, tools, initial_hashes, root, initial_task):
    last = turns[-1]
    text = last.get('answer', '')
    checks = {'no_error': all(not t.get('error') for t in turns),
              'no_files_applied': all(file_hash(root / p) == value for p, value in initial_hashes.items()),
              'no_action_staged': tools.action is None and all(not t.get('action_staged') for t in turns)}
    if case.get('repair'):
        first = turns[0]
        diagnosis = (first.get('response') or {}).get('answer', '').casefold()
        checks['read_only_diagnosis'] = (
            not first.get('candidate') and bool(first.get('evidence'))
            and 'seed_callback' in diagnosis and 'required_value' in diagnosis
            and bool(re.search(r'no (arguments|parameters)|zero[ -]arg|without arguments|seed_callback\(\)', diagnosis))
        )
        checks['both_turns_attempted'] = len(turns) == len(case['turns'])
    if case.get('mode_required'):
        task = tools.ledger.find()
        checks['mode_gate'] = bool(task and task['status'] == 'awaiting_mode_change' and tools.proposal is None)
        return checks
    if not case.get('edit'):
        checks['actual_answer_field'] = all(t.get('response') and t['response'].get('answer', '').strip() for t in turns)
        checks['no_proposal'] = tools.proposal is None
        for word in case.get('words', []):
            checks['answer_' + word] = word.casefold() in text.casefold()
        if case.get('bounds'):
            pattern = r'\b' + r'\s*,\s*'.join(map(str, case['bounds'])) + r'\b'
            checks['reported_bounds'] = bool(re.search(pattern, text))
        if case.get('conversation'):
            checks['one_request_per_turn'] = all(t.get('model_calls') == 1 for t in turns)
            checks['no_source_tools'] = all(not t['tools'] or all(n in {'finish_response', 'finish_stage'} for n in t['tools']) for t in turns)
        if case.get('inspect'):
            checks['source_evidence_available'] = any(t.get('evidence') for t in turns)
        if case.get('designer_sequence'):
            procedure = turns[4].get('answer','').lower() if len(turns)>4 else ''
            checks['designer_procedure'] = all(word in procedure for word in ['message designer','new','save']) and ('definitions' in procedure or 'routing' in procedure)
            checks['preserves_behavior_extension'] = 'behaviors.py' in text.lower()
            checks['no_internal_marker_leak'] = all('assistant_rpc_not_runtime_function' not in t.get('answer','') for t in turns)
        if case['id'].startswith('tcp_'):
            actions = [r'\bopen\b', r'\b(new|create|add)\b', r'\b(select|choose)\b',
                       r'\b(set|enter|configure|specify)\b', r'\b(start|connect|listen)\b']
            checks['actionable_steps'] = sum(bool(re.search(pattern, text, re.I)) for pattern in actions) >= 4
            checks['actual_ui_entry'] = 'communication hub' in text.lower() and 'session' in text.lower()
        if case['id'] in {'append_replace', 'callback_contract'}:
            examples = re.findall(r'```(?:python|py)\s*\n(.*?)```', text, re.I | re.S)
            checked = []
            for code in examples:
                try:
                    tree = ast.parse(code)
                except SyntaxError:
                    continue
                for node in tree.body:
                    if isinstance(node, ast.FunctionDef):
                        checked.append(not (node.args.args or node.args.posonlyargs or node.args.kwonlyargs or node.args.vararg or node.args.kwarg))
            if case['id'] == 'append_replace':
                checks['callback_example'] = bool(checked) and all(checked)
            else:
                checks['zero_argument_contract'] = bool(re.search(r'zero[ -]argument|no arguments|without arguments|no parameters|zero parameters|\(\)', text, re.I))
        if case.get('serial_sequence'):
            imports_ok = True
            actual_newline = False
            hub_family = True
            real_send = False
            for index, turn in enumerate(turns):
                for code in re.findall(r'```(?:python|py)\s*\n(.*?)```', turn.get('answer', ''), re.I | re.S):
                    try:
                        tree = ast.parse(code)
                    except SyntaxError:
                        imports_ok = False
                        continue
                    for node in ast.walk(tree):
                        if isinstance(node, ast.ImportFrom) and node.module in {'app.messages', 'app.data.config'}:
                            imports_ok = False
                        if index == 1 and isinstance(node, ast.Attribute) and node.attr == 'serial':
                            hub_family = False
                        if index == 1 and isinstance(node, ast.Constant) and node.value in (b'PING\n', 'PING\n'):
                            actual_newline = True
                        if index == 1 and isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='send':
                            real_send=True
            checks['no_invented_imports'] = imports_ok
            checks['actual_newline_example'] = len(turns) == 3 and actual_newline
            checks['hub_family_preserved'] = hub_family
            checks['actual_send_example'] = real_send
        return checks
    candidate = tools.proposal
    checks['reviewed_proposal'] = bool(candidate and tools.validate()['ok'] and last.get('artifact_reviewed'))
    if not case.get('background'):
        checks['reviewed_completion'] = all(completion_checks(last, getattr(candidate, 'fingerprint', None)).values())
    if candidate:
        files = {e.path: e.content for e in candidate.edits}
        checks['only_requested_file'] = set(files) == {CALLBACK_PATH}
        try:
            current = ast.parse(files.get(CALLBACK_PATH, ''))
        except SyntaxError:
            checks['candidate_python_parses'] = False
            return checks
        definitions = [n for n in current.body
                       if isinstance(n, ast.FunctionDef) and n.name == case['function']]
        if not case.get('repair'):
            values = []
            for definition in definitions:
                for node in ast.walk(definition):
                    if isinstance(node, ast.Return):
                        try:
                            values.append(ast.literal_eval(node.value))
                        except (ValueError, TypeError):
                            pass
            checks['exact_function_and_return'] = len(definitions) == 1 and case['literal'] in values
        baseline = ast.parse((root / CALLBACK_PATH).read_text(encoding='utf-8'))
        if case.get('repair'):
            checks['repaired_callback_contract'] = repaired_callback_matches(definitions, exact=case['exact_callback'])
            checks['all_unrelated_statements_preserved'] = [
                ast.dump(node) for node in current.body
                if not isinstance(node, ast.FunctionDef) or node.name != case['function']
            ] == [
                ast.dump(node) for node in baseline.body
                if not isinstance(node, ast.FunctionDef) or node.name != case['function']
            ]
        by_name = {n.name: ast.dump(n) for n in current.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
        checks['baseline_definitions_preserved'] = all(by_name.get(n.name) == ast.dump(n) for n in baseline.body
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.name != case['function'])
    if case.get('same_task'):
        checks['same_task'] = tools.ledger.find()['id'] == initial_task
    if case.get('background'):
        checks['background_preserved'] = tools.ledger.find(initial_task)['status'] == 'ready_for_review'
        checks['topic_answer'] = bool(last.get('response'))
    if case.get('answer_required'):
        response_text = (last.get('response') or {}).get('answer', '')
        checks['mixed_answer'] = bool(re.search(r'function|handler', response_text, re.I) and re.search(r'event|click|button', response_text, re.I))
    return checks
