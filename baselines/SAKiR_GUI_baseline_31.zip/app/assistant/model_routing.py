"""Resolve a turn's role assignments from a single server catalog."""
from collections import Counter
from dataclasses import replace
import time

from .policy import digest
from .reasoning import merge_profile, profile_for, supported_efforts
from .settings_policy import capacity_for, resolve_settings


ROLES = ('inspect', 'author', 'review', 'action')


def stage_settings(settings, profile):
    model = profile['model']
    saved = settings.model_profiles.get(digest([settings.base_url, model]), {})
    if model == settings.model:
        saved = {**saved, **profile_for(settings)}
    merged = merge_profile(saved, profile)
    limits = saved.get('chat_limits', {}) if model != settings.model else {}
    overrides = {name: limits[name] for name in
                 ('context_tokens', 'context_margin', 'max_tokens', 'context_chars') if name in limits}
    if model != settings.model:
        overrides.setdefault('context_tokens', 0)
    if model != settings.model:
        overrides['streaming'] = saved.get('chat_streaming', settings.streaming)
        overrides['token_parameter'] = saved.get('chat_token_parameter', settings.token_parameter)
    result = replace(settings, model=model, capability_profile=merged, **overrides)
    advertised = merged.get('context_tokens', 0)
    if advertised and result.context_tokens:
        result.context_tokens = min(result.context_tokens, advertised)
    capacity = capacity_for(result)
    if capacity and result.max_tokens + result.context_margin >= capacity:
        result.context_margin = min(result.context_margin, capacity // 8)
        result.max_tokens = min(result.max_tokens, max(256, capacity // 8))
    if result.reasoning_effort not in ('auto', *supported_efforts(result)):
        result.reasoning_effort = 'auto'
    return resolve_settings(result)


def resolve_assignments(settings, profiles):
    if not settings.multi_model or not isinstance(profiles, dict) or len(profiles) < 2:
        return {}
    now = time.time()
    tools = {}
    for model in sorted(profiles):
        fresh = profiles[model]
        saved = settings.model_profiles.get(digest([settings.base_url, model]), {})
        if model == settings.model:
            saved = {**saved, **profile_for(settings)}
        streaming = settings.streaming if model == settings.model else saved.get('chat_streaming', settings.streaming)
        tools[model] = fresh.get('tool_round_trip') if fresh.get('streaming', streaming) == streaming else None
        checked = saved.get('probe_time')
        if (tools[model] is None and saved.get('streaming') == streaming
                and (saved.get('base_url'), saved.get('model')) == (settings.base_url, model)
                and isinstance(checked, (int, float)) and 0 <= now - checked <= 86400
                and saved.get('probe_revision') == fresh.get('model_revision')):
            tools[model] = saved.get('tool_round_trip')

    preferences = settings.agent_models.get(settings.base_url, {})
    assignments, fallbacks = {}, {}
    load = Counter()
    for role in ROLES:
        model = preferences.get(role)
        if model in tools and tools[model] is not False:
            assignments[role] = {'model': model, 'reason': 'preferred'}
            load[model] += 1
        elif model:
            fallbacks[role] = 'preferred_incompatible' if model in tools else 'preferred_unavailable'

    eligible = [model for model in tools if tools[model] is not False]
    verified = [model for model in eligible if tools[model] is True]
    candidates = verified or eligible
    capacities = {name: profiles[name].get('context_tokens', 0) for name in candidates}
    if capacities and all(type(capacity) is int and capacity >= 1024 for capacity in capacities.values()):
        wanted = settings.max_tokens + settings.context_margin + 1024
        candidates = [name for name in candidates if capacities[name] >= wanted] or candidates
    reason = 'capability_fit' if len(candidates) < len(tools) else 'distribution'
    for role in ROLES:
        if role in assignments:
            continue
        model = min(candidates, key=lambda name: (load[name], name)) if candidates else None
        assignment = {'model': model, 'reason': reason if model else 'no_eligible_model'}
        if role in fallbacks:
            assignment['fallback'] = fallbacks[role]
        assignments[role] = assignment
        if model:
            load[model] += 1
    return assignments
