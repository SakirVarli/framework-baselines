"""Deterministic checks against the complete candidate, also used during review."""
import ast


def validate_outcomes(checks, config, callbacks, policy=None, files=None):
    if not checks:
        return []
    from app.config_designer.document import DesignerDocument
    try:
        document = DesignerDocument.from_config(config)
    except (ValueError, TypeError) as exc:
        return [{'severity':'error', 'code':'OUTCOME_MISMATCH', 'message':str(exc)}]
    issues = []
    for check in checks:
        try:
            if check['kind'] == 'layout':
                node = document.root
                for part in check['target'].split('/')[1:]:
                    node = node.children[int(part)]
                for key, value in check['properties'].items():
                    if node.properties.get(key) != value:
                        raise ValueError(f"{check['target']} must preserve requested {key}={value!r}")
            elif check['kind'] == 'callback':
                definitions = [n for n in ast.parse(callbacks).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == check['name']]
                if len(definitions) != 1 or ast.dump(definitions[0]) != check['ast']:
                    raise ValueError('Requested callback definition differs: ' + check['name'])
            elif check['kind'] == 'function':
                source = (files or {}).get(check['path'],'')
                definitions = [n for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name == check['name']]
                if len(definitions) != 1 or ast.dump(definitions[0]) != check['ast']:
                    raise ValueError('Requested helper definition differs: ' + check['path'] + ':' + check['name'])
            elif check['kind'] == 'data_input':
                from .policy import data_revision
                if policy is None or data_revision(policy.path(check['path'])) != check['revision']:
                    raise ValueError('Inspected data changed; inspect it again: ' + check['path'])
            elif check['kind'] == 'composite_page':
                tabs = [n for n in document.root.walk() if n.node_type == 'tab' and n.properties.get('name') == check['tab_name']]
                if len(tabs) != 1:
                    raise ValueError('Requested page is missing or ambiguous: '+check['tab_name'])
                children = list(tabs[0].walk())
                buttons = [n for n in children if n.node_type == 'button' and n.properties.get('name') == check['button_label']
                           and n.properties.get('callback') == check['callback_name']]
                outputs = [n for n in children if n.node_type == 'output' and n.properties.get('instance') == check['output_instance']
                           and n.properties.get('output_kind') == check['output_kind']]
                if len(buttons) != 1 or len(outputs) != 1:
                    raise ValueError('The requested page needs its button, output and callback binding together.')
                definitions = [n for n in ast.parse(callbacks).body if isinstance(n, ast.FunctionDef) and n.name == check['callback_name']]
                if len(definitions) != 1:
                    raise ValueError('The requested page callback is missing or ambiguous.')
                from .authoring import validate_button_callback
                from .policy import AssistantError
                try:
                    validate_button_callback(ast.unparse(definitions[0]), check['callback_name'], check['output_instance'])
                except AssistantError as exc:
                    raise ValueError(str(exc)) from exc
            else:
                raise ValueError('Unsupported outcome check.')
        except (ValueError, KeyError, IndexError, TypeError, SyntaxError, OSError) as exc:
            issues.append({'severity': 'error', 'code': 'OUTCOME_MISMATCH', 'message': str(exc)})
    return issues
