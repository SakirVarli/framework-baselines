"""Application-local Assistant settings, history, proposals, and recovery state."""
from dataclasses import asdict, dataclass, field, fields
import json
import os
import re
from pathlib import Path
import tempfile
from urllib.parse import urlsplit

from .policy import AssistantError


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".assistant-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@dataclass
class Settings:
    base_url: str = ""
    model: str = ""
    auth_mode: str = "none"
    key_env: str = "SAKIR_ASSISTANT_API_KEY"
    credential_ref: str = ""
    timeout: int = 60
    streaming: bool = True
    max_tokens: int = 4096
    token_parameter: str = "max_tokens"
    context_chars: int = 96000
    max_rounds: int = 20
    max_tool_calls: int = 40
    task_timeout: int = 600
    file_timeout: int = 30
    preview_rows: int = 50
    result_chars: int = 60000
    save_history: bool = True
    history_sessions: int = 20
    ca_bundle: str = ""
    capability_profile: dict = None
    usage_headers: list = field(default_factory=list)
    context_tokens: int = 0
    context_margin: int = 512
    auto_compact: bool = True
    compact_threshold: int = 80
    tokenizer: str = "estimate"
    stream_usage: bool = False
    settings_mode: str = "advanced"
    task_preset: str = "standard"
    output_preset: str = "standard"
    file_detail: str = "standard"
    advanced_limits: dict = field(default_factory=dict)
    reasoning_effort: str = "auto"
    model_profiles: dict = field(default_factory=dict)
    multi_model: bool = False
    agent_models: dict = field(default_factory=dict)

    def validate(self, connection=True):
        from .reasoning import LEVELS
        if type(self.multi_model) is not bool or not isinstance(self.agent_models, dict):
            raise AssistantError("SETTINGS_INVALID", "Invalid multi-model settings.")
        from .model_routing import ROLES
        if any(not isinstance(endpoint, str) or not isinstance(roles, dict)
               or any(role not in ROLES or not isinstance(model, str) or not model.strip()
                      for role, model in roles.items())
               for endpoint, roles in self.agent_models.items()):
            raise AssistantError("SETTINGS_INVALID", "Invalid agent model preferences.")
        if self.reasoning_effort not in ('auto', *LEVELS):
            raise AssistantError("SETTINGS_INVALID", "Invalid reasoning effort.")
        if not isinstance(self.model_profiles, dict) or any(not isinstance(v, dict) for v in self.model_profiles.values()):
            raise AssistantError("SETTINGS_INVALID", "Model profiles must be an object.")
        if not isinstance(self.settings_mode, str) or self.settings_mode not in {"simplified", "advanced"}:
            raise AssistantError("SETTINGS_INVALID", "Choose Simplified or Advanced settings.")
        if (any(not isinstance(getattr(self, key), str) for key in ("task_preset", "output_preset", "file_detail"))
                or self.task_preset not in {"quick", "standard", "extended"}
                or self.output_preset not in {"standard", "reasoning"}
                or self.file_detail not in {"small", "standard", "detailed"}):
            raise AssistantError("SETTINGS_INVALID", "Invalid simplified settings preset.")
        if not isinstance(self.advanced_limits, dict):
            raise AssistantError("SETTINGS_INVALID", "Saved Advanced limits must be an object.")
        if self.advanced_limits:
            from .settings_policy import AUTOMATIC_FIELDS
            if set(self.advanced_limits) - set(AUTOMATIC_FIELDS):
                raise AssistantError("SETTINGS_INVALID", "Unknown saved Advanced limit.")
            restored = asdict(self)
            restored.update(self.advanced_limits)
            restored.update(advanced_limits={}, context_tokens=0)
            Settings(**restored).validate(connection=False)
        for key in ("base_url", "model", "auth_mode", "key_env", "credential_ref", "ca_bundle"):
            if not isinstance(getattr(self, key), str):
                raise AssistantError("SETTINGS_INVALID", f"{key} must be text.")
        if any(type(getattr(self, key)) is not bool for key in ("streaming", "save_history", "auto_compact", "stream_usage")):
            raise AssistantError("SETTINGS_INVALID", "Streaming/history preferences must be booleans.")
        if self.capability_profile is not None and not isinstance(self.capability_profile, dict):
            raise AssistantError("SETTINGS_INVALID", "Compatibility profile must be an object or null.")
        if not isinstance(self.usage_headers, list) or len(self.usage_headers) > 32:
            raise AssistantError("SETTINGS_INVALID", "Configure at most 32 usage headers.")
        seen = set()
        for entry in self.usage_headers:
            if not isinstance(entry, dict) or set(entry) != {"header", "display_name"}:
                raise AssistantError("SETTINGS_INVALID", "Each usage header needs a header key and display name.")
            header, name = entry["header"], entry["display_name"]
            if not isinstance(header, str) or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]{1,256}", header):
                raise AssistantError("SETTINGS_INVALID", "Usage header keys must be valid HTTP header names.")
            if not isinstance(name, str) or not name.strip() or len(name) > 80 or any(ord(c) < 32 or ord(c) == 127 for c in name):
                raise AssistantError("SETTINGS_INVALID", "Usage display names must contain 1–80 characters without control characters.")
            if header.lower() in seen:
                raise AssistantError("SETTINGS_INVALID", "Usage header keys must be unique (case-insensitive).")
            seen.add(header.lower())
        url = urlsplit(self.base_url)
        if connection and (url.scheme not in {"http", "https"} or not url.hostname or not self.model.strip()):
            raise AssistantError("SETTINGS_INVALID", "Enter a server base URL and model ID.")
        if url.username or url.password or url.query or url.fragment:
            raise AssistantError("SETTINGS_INVALID", "Do not embed credentials, queries or fragments in the server URL.")
        if self.auth_mode not in {"none", "session", "environment", "windows"}:
            raise AssistantError("SETTINGS_INVALID", "Unknown authentication mode.")
        if self.token_parameter not in {"max_tokens", "max_completion_tokens"}:
            raise AssistantError("SETTINGS_INVALID", "Unsupported token limit parameter.")
        if not isinstance(self.tokenizer, str) or self.tokenizer not in {"estimate", "cl100k_base", "o200k_base"}:
            raise AssistantError("SETTINGS_INVALID", "Unsupported context tokenizer.")
        for key, low, high in (("timeout", 5, 600), ("max_tokens", 256, 65536), ("context_chars", 8000, 2000000),
                               ("context_tokens", 0, 10000000), ("context_margin", 0, 65536), ("compact_threshold", 50, 95),
                               ("max_rounds", 1, 40), ("max_tool_calls", 1, 100), ("task_timeout", 30, 3600),
                               ("file_timeout", 1, 120), ("preview_rows", 1, 200), ("result_chars", 1000, 64000),
                               ("history_sessions", 1, 100)):
            if type(getattr(self, key)) is not int or not low <= getattr(self, key) <= high:
                raise AssistantError("SETTINGS_INVALID", f"Invalid {key}.")
        if self.context_tokens and self.context_tokens <= self.max_tokens + self.context_margin:
            raise AssistantError("SETTINGS_INVALID", "Context capacity must exceed the output limit plus safety margin.")


class Store:
    def __init__(self, root):
        root = Path(root).resolve()
        self.private = root / "app" / "data" / "assistant"
        self.settings_path = self.private / "assistant.json"

    def load_settings(self):
        try:
            data = json.loads(self.settings_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            from .settings_policy import resolve_settings
            return resolve_settings(Settings(settings_mode="simplified"))
        except (ValueError, OSError) as exc:
            raise AssistantError("SETTINGS_INVALID", f"Cannot read assistant.json: {exc}") from exc
        if not isinstance(data, dict):
            raise AssistantError("SETTINGS_INVALID", "assistant.json must contain an object.")
        settings = Settings(**{f.name: data[f.name] for f in fields(Settings) if f.name in data})
        from .settings_policy import resolve_settings
        return resolve_settings(settings)

    def save_settings(self, settings):
        from .settings_policy import resolve_settings
        atomic_json(self.settings_path, asdict(resolve_settings(settings)))

    def save_session(self, session_id, messages, settings, context_state=None):
        if settings.save_history:
            if context_state is not None:
                # Prefix hashes let the reader reject a checkpoint from a different transcript.
                atomic_json(self.private / "context_state" / f"{session_id}.json", context_state)
            atomic_json(self.private / "history" / f"{session_id}.json", messages)
            paths = sorted((self.private / "history").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for path in paths[settings.history_sessions:]:
                path.unlink()
                (self.private / "context_state" / path.name).unlink(missing_ok=True)
                (self.private / 'failures' / path.name).unlink(missing_ok=True)
                (self.private / 'tasks' / path.name).unlink(missing_ok=True)
            from .workflow_store import WorkflowStore
            import sqlite3
            try:
                WorkflowStore(self.private).retain({p.stem for p in paths[:settings.history_sessions]})
            except sqlite3.Error as exc:
                raise OSError('Conversation saved, but workflow retention could not be updated.') from exc

    def save_tasks(self, session_id, ledger, messages, settings):
        if settings.save_history:
            from .policy import digest
            atomic_json(self.private/'tasks'/f'{session_id}.json',
                {'version':1,'message_count':len(messages),'transcript_hash':digest(messages),'ledger':ledger.export()})

    def load_tasks(self, session_id, messages):
        from .task_state import TaskLedger
        from .policy import digest
        path=self.private/'tasks'/f'{session_id}.json'
        if not path.exists():
            return self._workflow_tasks(session_id, messages) or TaskLedger()
        if path.stat().st_size>10000000:
            raise AssistantError('TASK_PROTOCOL','Saved task state exceeds its limit. The file was retained.')
        try:
            value=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError) as exc:
            raise AssistantError('TASK_PROTOCOL','Cannot read saved task state; it was retained.') from exc
        if not isinstance(value,dict):
            raise AssistantError('TASK_PROTOCOL','Invalid saved task state; it was retained.')
        count=value.get('message_count',len(messages))
        if value.get('version')!=1 or type(count) is not int or not 0<=count<=len(messages) or value.get('transcript_hash')!=digest(messages[:count]):
            recovered = self._workflow_tasks(session_id, messages)
            if recovered is not None:
                return recovered
            raise AssistantError('TASK_STATE_STALE','Task state does not match this transcript. Saved files were retained.')
        return TaskLedger(value.get('ledger'))

    def _workflow_tasks(self, session_id, messages):
        """Recover only a transcript-bound accepted workflow checkpoint."""
        from .workflow_store import WorkflowStore
        from .task_state import TaskLedger
        from .policy import digest
        matching = []
        for run in WorkflowStore(self.private).records():
            count = run.get('message_count')
            if (run.get('session_id') == session_id and type(count) is int and 0 <= count <= len(messages)
                    and run.get('transcript_hash') == digest(messages[:count]) and run.get('ledger')):
                matching.append(run)
        latest = max(matching, key=lambda r: r['updated'], default=None)
        if latest is None:
            return None
        ledger = TaskLedger(latest['ledger'])
        task = ledger.find()
        if task and latest['status'] in {'created', 'running'}:
            task['status'] = 'incomplete'
            task['last_failure'] = {'kind': 'interrupted', 'message': 'Workflow interrupted. Resume with fresh inspection; the last accepted draft was retained.'}
        return ledger

    def recover_response(self, session_id, messages):
        """Hydrate a committed response if the process stopped before history save.

        The transcript must match exactly; old summary-only records are never
        promoted to user answers, and an already saved reply is not duplicated.
        """
        from .workflow_store import WorkflowStore
        from .policy import digest
        matching = [r for r in WorkflowStore(self.private).records()
                    if r.get('session_id') == session_id and r.get('message_count') == len(messages)
                    and r.get('transcript_hash') == digest(messages) and r.get('response')
                    and r.get('status') in {'completed', 'awaiting_review', 'incomplete'}
                    and isinstance(r.get('presented_text'), str) and r['presented_text'].strip()]
        latest = max(matching, key=lambda r: r['updated'], default=None)
        return [*messages, {'role': 'assistant', 'content': latest['presented_text']}] if latest else messages

    def save_failure(self, session_id, error, message_index, settings):
        """Bounded user-visible errors; no tool arguments, source, or reasoning."""
        if not settings.save_history:
            return
        from datetime import datetime, timezone
        from .policy import redact
        path = self.private / 'failures' / f'{session_id}.json'
        try:
            records = json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(records,list):
                records = []
        except (OSError,ValueError):
            records = []
        records = records[-19:] + [{'time':datetime.now(timezone.utc).isoformat(),
            'message_index':message_index, 'error':str(redact(error))[:2000]}]
        atomic_json(path,records)

    def load_context(self, session_id):
        try:
            value = json.loads((self.private / "context_state" / f"{session_id}.json").read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            return {}

    def sessions(self):
        paths = sorted((self.private / "history").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        result = []
        for path in paths:
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(value, list) and all(isinstance(m, dict) and m.get("role") in {"user", "assistant"} and isinstance(m.get("content"), str) for m in value):
                    result.append((path.stem, value))
            except (ValueError, OSError):
                continue
        return result

    @staticmethod
    def _session_key(session_id):
        if not isinstance(session_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", session_id):
            raise AssistantError("HISTORY_INVALID", "Invalid conversation identifier.")
        return session_id

    def session_titles(self):
        try:
            value = json.loads((self.private / "chat_titles.json").read_text(encoding="utf-8"))
            return {k: v for k, v in value.items() if isinstance(v, str)} if isinstance(value, dict) else {}
        except (OSError, ValueError):
            return {}

    def rename_session(self, session_id, title):
        key = self._session_key(session_id)
        titles = self.session_titles()
        titles[key] = " ".join(title.split())[:200]
        atomic_json(self.private / "chat_titles.json", titles)

    def delete_session(self, session_id):
        key = self._session_key(session_id)
        from .workflow_store import WorkflowStore
        WorkflowStore(self.private).delete_session(key)
        for directory in ("history", "context_state", "failures", "tasks"):
            (self.private / directory / f"{key}.json").unlink(missing_ok=True)
        titles = self.session_titles()
        titles.pop(key, None)
        atomic_json(self.private / "chat_titles.json", titles)

    def clear_history(self):
        from .workflow_store import WorkflowStore
        WorkflowStore(self.private).clear()
        (self.private / "chat_titles.json").unlink(missing_ok=True)
        for path in (self.private / "history").glob("*.json"):
            path.unlink()
        for path in (self.private / "context_state").glob("*.json"):
            path.unlink()
        for path in (self.private / 'failures').glob('*.json'):
            path.unlink()
        for path in (self.private / 'tasks').glob('*.json'):
            path.unlink()


class Credentials:
    """Credential Manager or session-only secrets. Never serialized into JSON."""
    def __init__(self):
        self.session = ""

    def key(self, settings):
        if settings.auth_mode == "none":
            return "local-no-auth"
        if settings.auth_mode == "session":
            value = self.session
        elif settings.auth_mode == "environment":
            value = os.environ.get(settings.key_env, "")
        else:
            value = self._windows(settings.credential_ref)
        if not value:
            raise AssistantError("AUTH_REQUIRED", "Enter a session key or configure a credential in Settings.")
        return value

    @staticmethod
    def _windows(target, secret=None):
        if os.name != "nt":
            raise AssistantError("AUTH_REQUIRED", "Windows Credential Manager is unavailable.")
        import ctypes
        from ctypes import wintypes as w
        class Credential(ctypes.Structure):
            _fields_ = [("Flags", w.DWORD), ("Type", w.DWORD), ("TargetName", w.LPWSTR),
                        ("Comment", w.LPWSTR), ("LastWritten", w.FILETIME), ("CredentialBlobSize", w.DWORD),
                        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)), ("Persist", w.DWORD),
                        ("AttributeCount", w.DWORD), ("Attributes", ctypes.c_void_p),
                        ("TargetAlias", w.LPWSTR), ("UserName", w.LPWSTR)]
        api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
        api.CredReadW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.POINTER(ctypes.POINTER(Credential))]
        api.CredWriteW.argtypes = [ctypes.POINTER(Credential), w.DWORD]
        api.CredFree.argtypes = [ctypes.c_void_p]
        if secret is not None:
            blob = (ctypes.c_ubyte * len(secret.encode("utf-16-le"))).from_buffer_copy(secret.encode("utf-16-le"))
            entry = Credential(Type=1, TargetName=target, CredentialBlobSize=len(blob), CredentialBlob=blob,
                               Persist=2, UserName="SAKiR Assistant")
            if not api.CredWriteW(ctypes.byref(entry), 0):
                raise ctypes.WinError(ctypes.get_last_error())
            return secret
        pointer = ctypes.POINTER(Credential)()
        if not api.CredReadW(target, 1, 0, ctypes.byref(pointer)):
            return ""
        try:
            return ctypes.string_at(pointer.contents.CredentialBlob, pointer.contents.CredentialBlobSize).decode("utf-16-le")
        finally:
            api.CredFree(pointer)
