"""Scoped desktop styling and resolution-independent assistant icons."""
from pathlib import Path

from PyQt5 import QtCore, QtGui, QtWidgets


STYLE = """
QWidget { color: #252a34; font-family: 'Segoe UI'; font-size: 10pt; }
QMainWindow, QDialog { background: #ffffff; }
QWidget#assistantSurface, QWidget#chatPage, QWidget#welcome { background: #ffffff; }
QFrame#sidebar { background: #f6f7f9; border-right: 1px solid #e4e7ec; }
QFrame#toolsSidebar { background: #f6f7f9; border-left: 1px solid #e4e7ec; }
QFrame#toolCard { background: #ffffff; border: 1px solid #e1e5eb; border-radius: 10px; }
QWidget#toolActivityContent { background: #f6f7f9; }
QFrame#toolsSidebar QScrollArea { background: transparent; }
QFrame#timelineGroup { background: #f6f7f9; border: none; }
QFrame#timelineRequest { background: #eaf0f8; border: 1px solid #d6e0ee; border-radius: 10px; }
QToolButton#requestToggle { background: transparent; border: none; padding: 0; text-align: left; font-weight: 600; }
QToolButton#requestToggle:hover { color: #365d91; }
QFrame#timelineBranch { background: #f6f7f9; border: none; border-left: 2px solid #dce4ef; margin-left: 9px; }
QFrame#timelineCard { background: #f8fafc; border: 1px solid #dce3ed; border-radius: 10px; }
QLabel#timelineCardTitle { font-weight: 600; }
QFrame#toolCard QToolButton { text-align: left; background: transparent; border: none; padding: 4px 0; }
QSplitter#assistantSplit::handle { background: #e4e7ec; }
QSplitter#assistantSplit::handle:hover { background: #b9c5d5; }
QFrame#header { border-bottom: 1px solid #e4e7ec; }
QFrame#composer { background: #ffffff; border: 1px solid #d8dce3; border-radius: 18px; }
QFrame#usagePanel { background: #f6f8fb; border: 1px solid #e1e5eb; border-radius: 10px; }
QScrollArea#usageScroll, QWidget#usageContent { background: transparent; }
QLabel#usageIndicator { color: #697180; font-size: 9pt; padding: 3px 8px; border-radius: 5px; }
QLabel#usageIndicator:hover { background: #e7ecf3; color: #252a34; }
QLabel { background: transparent; border: none; }
QLabel#brand { font-size: 13pt; font-weight: 600; }
QLabel#eyebrow { color: #697180; font-size: 9pt; }
QLabel#hero { font-size: 28pt; font-weight: 600; }
QLabel#subtitle { color: #697180; font-size: 11pt; }
QLabel#muted, QLabel#context { color: #697180; font-size: 9pt; }
QLabel#model { color: #596272; font-size: 9pt; }
QLabel#status { color: #697180; font-size: 9pt; }
QPushButton, QToolButton { background: #f1f3f6; border: 1px solid #d7dce4;
    border-radius: 8px; padding: 8px 12px; }
QPushButton:hover, QToolButton:hover { background: #e6ebf2; border-color: #b9c5d5; }
QPushButton:pressed, QToolButton:pressed { background: #dce3ed; border-color: #aab8cb; }
QPushButton:focus, QToolButton:focus { border: 1px solid #6485b5; }
QPushButton:disabled, QToolButton:disabled { background: #f7f8fa; border-color: #e7eaf0; color: #9097a3; }
QPushButton#navigation { text-align: left; padding: 9px 10px; }
QPushButton#newChat { background: #edf1f6; border: 1px solid #d7dce4; text-align: left; }
QPushButton#newChat:hover { background: #e3e9f2; }
QPushButton#newChat:pressed { background: #dce3ed; }
QPushButton#primary { background: #252a34; border-color: #252a34; color: #ffffff; font-weight: 600; }
QPushButton#primary:hover { background: #404754; border-color: #404754; }
QPushButton#primary:pressed { background: #171c25; border-color: #171c25; }
QPushButton#primary:disabled { background: #e6e9ee; border-color: #e6e9ee; color: #8c94a1; }
QPushButton#stop { background: #fff0ee; border-color: #efccc7; color: #ad3d32; }
QPushButton#suggestion { background: #f6f8fb; border: 1px solid #dce2ea;
    text-align: left; padding: 16px; border-radius: 12px; }
QPushButton#suggestion:hover { background: #edf2f8; border-color: #b5c1d2; }
QPushButton#suggestion:pressed { background: #e1e8f1; border-color: #aab8cb; }
QLineEdit, QPlainTextEdit, QTextBrowser, QListWidget, QTreeWidget, QTableWidget {
    background: #ffffff; border: 1px solid #dce1e8; border-radius: 8px;
    padding: 8px; selection-background-color: #dbeafe; selection-color: #172c48; }
QLineEdit:focus, QPlainTextEdit:focus { border-color: #7c9cc9; }
QLineEdit#sessionSearch { background: #ffffff; padding: 9px; }
QListWidget#sessions { background: transparent; border: none; padding: 0; outline: 0; }
QListWidget#sessions::item { padding: 11px 10px; border-radius: 7px; margin-bottom: 3px; }
QListWidget#sessions::item:hover { background: #edf0f5; }
QListWidget#sessions::item:selected { background: #e3e9f2; color: #202c40; }
QTextBrowser#conversation { background: transparent; border: none; padding: 8px 0; }
QPlainTextEdit#request { background: transparent; border: none; padding: 4px; font-size: 11pt; }
QListWidget#attachments { background: transparent; border: none; padding: 0; font-size: 9pt; }
QListWidget#attachments::item { background: #e9edf3; padding: 5px 9px; margin: 2px; border-radius: 6px; }
QComboBox, QSpinBox { background: #ffffff; border: 1px solid #dce1e8;
    border-radius: 8px; min-height: 22px; padding: 6px 36px 6px 10px; }
QComboBox:hover, QSpinBox:hover { border-color: #b5c1d2; }
QComboBox:focus, QSpinBox:focus { border-color: #7c9cc9; }
QComboBox:disabled, QSpinBox:disabled { background: #f6f7f9; color: #9097a3; }
QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: center right;
    border: none; width: 30px; }
QComboBox::down-arrow { image: url("@CHEVRON_DOWN@"); width: 12px; height: 8px; }
QListView#assistantChoices { background: #ffffff; color: #252a34;
    border: none; padding: 3px;
    outline: 0; selection-background-color: #e3e9f2; selection-color: #202c40; }
QListView#assistantChoices::item { padding: 0px 7px;
    margin: 0; border: none; border-radius: 5px; }
QListView#assistantChoices::item:hover { background: #edf0f5; color: #252a34; }
QListView#assistantChoices::item:selected { background: #e3e9f2; color: #202c40; }
QSpinBox QLineEdit { background: transparent; border: none; border-radius: 0; padding: 0; }
QSpinBox::up-button { subcontrol-origin: border; subcontrol-position: top right;
    width: 28px; height: 18px; background: #f6f7f9; border: none;
    border-left: 1px solid #e4e7ec; border-top-right-radius: 7px; }
QSpinBox::down-button { subcontrol-origin: border; subcontrol-position: bottom right;
    width: 28px; height: 18px; background: #f6f7f9; border: none;
    border-left: 1px solid #e4e7ec; border-bottom-right-radius: 7px; }
QSpinBox::up-button:hover, QSpinBox::down-button:hover { background: #e7ecf3; }
QSpinBox::up-button:pressed, QSpinBox::down-button:pressed { background: #dbe3ee; }
QSpinBox::up-button:disabled, QSpinBox::down-button:disabled { background: #ffffff; }
QSpinBox::up-arrow { image: url("@CHEVRON_UP@"); width: 10px; height: 6px; }
QSpinBox::down-arrow { image: url("@CHEVRON_DOWN@"); width: 10px; height: 6px; }
QTabWidget::pane { border: 1px solid #dce1e8; border-radius: 8px; padding: 8px; }
QTabWidget::tab-bar { left: 4px; }
QTabBar::tab { background: #f6f8fb; border: 1px solid #e1e5eb; border-radius: 8px;
    padding: 9px 14px; margin-right: 5px; margin-bottom: 6px; }
QTabBar::tab:hover { background: #edf2f8; border-color: #b5c1d2; }
QTabBar::tab:selected { background: #e7ecf3; border-color: #c8d3e2; }
QTabBar#assistantSettingsTabs::tab { padding: 9px 12px; margin-right: 4px; }
QHeaderView::section { background: #eef1f6; color: #46536a; border: none; padding: 8px; }
QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
QScrollBar::handle:vertical { background: #b7bec9; border-radius: 3px; min-height: 24px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QToolTip { background: #ffffff; color: #252a34; border: 1px solid #c9d0da; padding: 5px; }
"""

_ASSETS = Path(__file__).with_name("assets")
STYLE = STYLE.replace("@CHEVRON_DOWN@", (_ASSETS / "chevron-down.svg").as_posix()).replace(
    "@CHEVRON_UP@", (_ASSETS / "chevron-up.svg").as_posix())


class ChoiceDelegate(QtWidgets.QStyledItemDelegate):
    def sizeHint(self, option, index):
        size = super().sizeHint(option, index)
        size.setHeight(max(28, option.fontMetrics.height() + 8))
        return size


class ComboBox(QtWidgets.QComboBox):
    """Use a styled list popup instead of the Windows menu delegate."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._control_style = QtWidgets.QStyleFactory.create("Fusion")
        self._control_style.setParent(self)
        self.setStyle(self._control_style)
        view = QtWidgets.QListView(self)
        view.setStyle(self._control_style)
        view.setObjectName("assistantChoices")
        # The popup is a separate window; give it an explicit stylesheet too.
        view.setStyleSheet(STYLE)
        view.setUniformItemSizes(True)
        view.setMouseTracking(True)
        view.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        view.setTextElideMode(QtCore.Qt.ElideRight)
        self.setView(view)
        # QComboBox's native delegate can override selected foreground colors.
        self.setItemDelegate(ChoiceDelegate(view))
        self.setMaxVisibleItems(8)

    def showPopup(self):
        super().showPopup()
        view = self.view()
        popup = view.window()
        if not popup.isVisible():
            return
        # The list and its native popup container are different surfaces. Style
        # and clip the outer frame too, so square Windows corners cannot show.
        popup.setObjectName("assistantChoicesPopup")
        popup.setStyleSheet("QFrame#assistantChoicesPopup { background: #ffffff; "
                           "border: 1px solid #dce1e8; border-radius: 8px; }")
        rows = min(self.count(), self.maxVisibleItems())
        height = sum(view.sizeHintForRow(i) for i in range(rows)) + 8
        below = self.mapToGlobal(QtCore.QPoint(0, self.height() + 4))
        above = self.mapToGlobal(QtCore.QPoint(0, -4))
        screen = QtWidgets.QApplication.screenAt(below) or QtWidgets.QApplication.primaryScreen()
        available = screen.availableGeometry()
        room_below = available.bottom() - below.y() + 1
        room_above = above.y() - available.top()
        open_below = room_below >= height or room_below >= room_above
        height = min(height, max(1, room_below if open_below else room_above))
        width = min(self.width(), available.width())
        x = max(available.left(), min(below.x(), available.right() - width + 1))
        y = below.y() if open_below else above.y() - height
        popup.setGeometry(x, y, width, height)
        path = QtGui.QPainterPath()
        path.addRoundedRect(QtCore.QRectF(popup.rect()), 8, 8)
        popup.setMask(QtGui.QRegion(path.toFillPolygon().toPolygon()))
        view.scrollTo(view.currentIndex(), QtWidgets.QAbstractItemView.EnsureVisible)


def apply_theme(widget):
    # A local palette also covers native text surfaces and inherited dialogs.
    palette = widget.palette()
    for role, color in ((QtGui.QPalette.Window, "#ffffff"),
                        (QtGui.QPalette.Base, "#ffffff"),
                        (QtGui.QPalette.AlternateBase, "#f3f5f8"),
                        (QtGui.QPalette.Text, "#252a34"),
                        (QtGui.QPalette.WindowText, "#252a34"),
                        (QtGui.QPalette.Button, "#f6f7f9"),
                        (QtGui.QPalette.ButtonText, "#252a34"),
                        (QtGui.QPalette.Highlight, "#dbeafe"),
                        (QtGui.QPalette.HighlightedText, "#172c48"),
                        (QtGui.QPalette.PlaceholderText, "#7a8391")):
        palette.setColor(role, QtGui.QColor(color))
    widget.setPalette(palette)
    widget.setStyleSheet(STYLE)


def icon(name, color="#656f7e"):
    """Draw small outline icons without fonts, downloads, or new dependencies."""
    pixmap = QtGui.QPixmap(40, 40)
    pixmap.fill(QtCore.Qt.transparent)
    painter = QtGui.QPainter(pixmap)
    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    painter.scale(2, 2)
    painter.setPen(QtGui.QPen(QtGui.QColor(color), 1.5, QtCore.Qt.SolidLine,
                             QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
    if name == "new":
        painter.drawRoundedRect(QtCore.QRectF(3, 3, 14, 14), 3, 3)
        painter.drawLine(10, 6, 10, 14)
        painter.drawLine(6, 10, 14, 10)
    elif name in {"panel", "panel-right"}:
        painter.drawRoundedRect(QtCore.QRectF(2, 3, 16, 14), 2, 2)
        x = 13 if name == "panel-right" else 7
        painter.drawLine(x, 3, x, 17)
    elif name == "copy":
        painter.drawRoundedRect(QtCore.QRectF(3, 3, 11, 11), 2.5, 2.5)
        painter.setBrush(QtGui.QColor("#f2f4f7"))
        painter.drawRoundedRect(QtCore.QRectF(7, 7, 11, 11), 2.5, 2.5)
    elif name == "send":
        painter.drawLine(10, 16, 10, 4)
        painter.drawLine(5, 9, 10, 4)
        painter.drawLine(10, 4, 15, 9)
    elif name == 'refresh':
        painter.drawArc(QtCore.QRectF(3,3,14,14),40*16,280*16)
        painter.drawLine(16,3,16,7)
        painter.drawLine(16,7,12,7)
    elif name == "attach":
        path = QtGui.QPainterPath(QtCore.QPointF(14, 7))
        path.cubicTo(19, 0, 6, -1, 6, 6)
        path.lineTo(6, 14)
        path.cubicTo(6, 20, 15, 20, 15, 14)
        path.lineTo(15, 6)
        path.cubicTo(15, 2, 10, 2, 10, 6)
        path.lineTo(10, 14)
        painter.drawPath(path)
    elif name == "settings":
        for y, x in ((5, 7), (10, 13), (15, 8)):
            painter.drawLine(3, y, x - 2, y)
            painter.drawLine(x + 2, y, 17, y)
            painter.drawEllipse(QtCore.QPointF(x, y), 2, 2)
    elif name == "folder":
        path = QtGui.QPainterPath(QtCore.QPointF(2, 6))
        for x, y in ((2, 4), (8, 4), (10, 6), (18, 6), (18, 16), (2, 16), (2, 6)):
            path.lineTo(x, y)
        painter.drawPath(path)
    elif name in {"chevron-right", "chevron-down"}:
        points = ((7, 4), (13, 10), (7, 16)) if name == "chevron-right" else ((4, 7), (10, 13), (16, 7))
        path = QtGui.QPainterPath(QtCore.QPointF(*points[0]))
        for point in points[1:]:
            path.lineTo(*point)
        painter.drawPath(path)
    elif name == "history":
        path = QtGui.QPainterPath(QtCore.QPointF(3, 10))
        path.cubicTo(3, 16, 10, 20, 15, 15)
        path.cubicTo(20, 10, 16, 3, 10, 3)
        path.cubicTo(7, 3, 5, 4, 3, 7)
        painter.drawPath(path)
        painter.drawLine(3, 3, 3, 7)
        painter.drawLine(3, 7, 7, 7)
        painter.drawLine(10, 6, 10, 10)
        painter.drawLine(10, 10, 13, 12)
    else:
        painter.drawRoundedRect(QtCore.QRectF(3, 3, 14, 14), 2, 2)
        for y in (7, 10, 13):
            painter.drawLine(7, y, 13, y)
    painter.end()
    return QtGui.QIcon(pixmap)
