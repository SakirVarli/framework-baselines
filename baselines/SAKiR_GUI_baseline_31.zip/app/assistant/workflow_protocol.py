"""Host-owned tool contracts and terminal outcome helpers; no inference."""
from .policy import AssistantError, digest


def capture_diagnostics(record, kind, value):
    """Bounded metadata only: no tool arguments, source text or model reasoning."""
    diagnostics = record.setdefault('diagnostics', {'version': 1})
    if kind == 'workflow_stage':
        transitions = diagnostics.setdefault('stage_transitions', [])
        row = {k: value[k] for k in ('stage_id', 'role', 'status') if k in value}
        if not transitions or transitions[-1] != row:
            transitions.append(row)
            del transitions[:-256]
    elif kind in {'context_compacted', 'context_compaction_started'}:
        rows = diagnostics.setdefault('compactions', [])
        rows.append({**value.get('diagnostics', {}),
                     'status': 'completed' if kind == 'context_compacted' else 'started',
                     **{k: value[k] for k in ('stage_id', 'role', 'before', 'after', 'kind') if k in value}})
        del rows[:-64]
    elif kind == 'review_coverage':
        diagnostics['review_coverage'] = value
    elif kind == 'stage_metrics':
        diagnostics.setdefault('stages', {})[value['stage_id']] = value
    elif kind == 'context_deduplicated':
        diagnostics['duplicate_exchanges_removed'] = diagnostics.get('duplicate_exchanges_removed', 0) + value['exchanges_removed']
    elif kind == 'context_projected':
        rows = diagnostics.setdefault('evidence_projections', [])
        rows.append({k:value[k] for k in ('exchanges','before','after')})
        del rows[:-64]
    elif kind == 'tool_started' and value.get('name') in {
            'read_source', 'read_tool_result', 'inspect_candidate', 'get_task_state',
            'get_task_context', 'get_symbol', 'get_relationships', 'get_layout_schema'}:
        keys = diagnostics.setdefault('read_queries', [])
        key = digest([value['name'], value.get('arguments')])
        diagnostics['duplicate_read_queries'] = diagnostics.get('duplicate_read_queries', 0) + int(key in keys)
        keys.append(key)
        del keys[:-128]
    elif kind == 'tool_result':
        name = value.get('tool', value.get('name'))
        result = value.get('result', {})
        data = result.get('data')
        if not result.get('ok') or result.get('truncated') or not isinstance(data, dict):
            return
        if name == 'read_source' and isinstance(data.get('text'), str):
            scope = digest([data.get('path'), data.get('content_revision'), data.get('sha256')])
            first = data.get('start_line', 1)
            last = first + len(data['text'].splitlines())
            unit = 'lines'
        elif name in {'inspect_candidate', 'read_tool_result', 'read_next_candidate'} and isinstance(data.get('text'), str):
            scope = digest([data.get('fingerprint'), data.get('path'), data.get('handle')])
            first = data.get('offset', 0)
            last = data.get('next_offset') if data.get('next_offset') is not None else data.get('total_characters', first)
            unit = 'characters'
        else:
            return
        if type(first) is not int or type(last) is not int or last < first:
            return
        reads = diagnostics.setdefault('evidence_reads', [])
        intervals = sorted((r['start'], r['end']) for r in reads if r['scope'] == scope and r['unit'] == unit)
        cursor, overlap = first, 0
        for start, end in intervals:
            start, end = max(start, cursor), min(end, last)
            if end > start:
                overlap += end - start
                cursor = end
        diagnostics['read_calls'] = diagnostics.get('read_calls', 0) + 1
        diagnostics['repeated_units'] = diagnostics.get('repeated_units', 0) + overlap
        by_unit = diagnostics.setdefault('repeated_units_by_kind', {})
        by_unit[unit] = by_unit.get(unit, 0) + overlap
        diagnostics['duplicate_read_calls'] = diagnostics.get('duplicate_read_calls', 0) + int(last > first and overlap == last-first)
        reads.append({'tool': name, 'scope': scope, 'unit': unit, 'start': first, 'end': last,
                      'repeated_units': overlap})
        del reads[:-128]


def evidence_payload(name, data, arguments=None, policy=None):
    """Validate evidence before it can earn read authority or progress credit."""
    if name == 'read_next_candidate':
        if isinstance(data, dict) and data.get('complete') is True and isinstance(data.get('fingerprint'), str) and data['fingerprint']:
            return
        name = 'inspect_candidate'
    if name not in {'read_source', 'inspect_candidate', 'read_tool_result'}:
        return
    arguments = arguments or {}
    invalid = lambda: AssistantError('TOOL_RESULT_INVALID', f'{name} returned an invalid evidence payload.')
    if not isinstance(data, dict) or not isinstance(data.get('text'), str):
        raise invalid()
    if name == 'read_source':
        expected = arguments.get('path')
        if expected and policy:
            target = policy.path(expected)
            expected = target.relative_to(policy.root).as_posix() if target.is_relative_to(policy.root) else str(target)
        if (not all(isinstance(data.get(k), str) and data[k] for k in ('path', 'sha256', 'content_revision'))
                or type(data.get('start_line', 1)) is not int or data.get('start_line', 1) < 1
                or expected is not None and expected != data['path']):
            raise invalid()
        return
    identity = 'path' if name == 'inspect_candidate' else 'handle'
    if (not isinstance(data.get(identity), str) or not data[identity]
            or arguments.get(identity, data[identity]) != data[identity]):
        raise invalid()
    if name == 'inspect_candidate' and (not isinstance(data.get('fingerprint'), str)
                                       or not data['fingerprint'] or data.get('state') != 'candidate'):
        raise invalid()
    offset, total, following = (data.get(k) for k in ('offset', 'total_characters', 'next_offset'))
    if (type(offset) is not int or type(total) is not int or not 0 <= offset <= total
            or arguments.get('offset', offset) != offset
            or (following is not None and (type(following) is not int or not offset < following < total))):
        raise invalid()
    end = following if following is not None else total
    # Candidate text is redacted and can change length. Source offsets always
    # refer to original content; result-handle text has already been redacted.
    if (end == offset and total != 0) or (name == 'read_tool_result' and len(data['text']) != end - offset):
        raise invalid()


def capture_workflow(record, kind, value):
    """Small host trace for all live evaluators, without source/tool arguments."""
    if kind in {'workflow_stage', 'context_compacted', 'context_compaction_started',
                'review_coverage', 'stage_metrics', 'context_deduplicated', 'context_projected', 'tool_started', 'tool_result'}:
        capture_diagnostics(record, kind, value)
    if kind == 'workflow_outcome':
        record['outcome'] = value
    elif kind == 'workflow_stage':
        record.setdefault('host_stages', {})[value['stage_id']] = value
    elif kind in {'tool_started', 'tool_completed', 'tool_result'}:
        tool = record.setdefault('host_tools', {}).setdefault(value['id'], {})
        tool[kind] = True
        if kind == 'tool_result':
            tool['code'] = value['result'].get('code')


def evidence_identities(value):
    """Progress follows scoped evidence locations, not arbitrary result prose."""
    found = set()
    if isinstance(value, dict):
        path = value.get('path')
        revision = value.get('content_revision') or value.get('source_revision') or value.get('sha256')
        if isinstance(path, str) and isinstance(revision, str):
            found.add((path, revision, str(value.get('section_id', '')),
                       str(value.get('start_line', value.get('line', ''))),
                       str(value.get('end_line', ''))))
        for child in value.values():
            if isinstance(child, (dict, list)):
                found.update(evidence_identities(child))
    elif isinstance(value, list):
        for child in value:
            found.update(evidence_identities(child))
    return found


def host_checks(turns):
    """Score host integrity independently of answer quality and exceptions."""
    return {
        'terminal_outcome_recorded': all(isinstance(t.get('outcome'), dict) for t in turns),
        'stages_terminated': all(s.get('status') in {'succeeded', 'blocked', 'failed', 'interrupted'}
                                 for t in turns for s in t.get('host_stages', {}).values()),
        'tool_events_complete': all(all(tool.get(k) for k in ('tool_started', 'tool_completed', 'tool_result'))
                                    for t in turns for tool in t.get('host_tools', {}).values()),
        'tool_contracts_valid': all(tool.get('code') != 'TOOL_RESULT_INVALID'
                                    for t in turns for tool in t.get('host_tools', {}).values()),
        'review_clearance_consistent': all(not t.get('artifact_reviewed')
                                           or not (t.get('outcome') or {}).get('candidate_fingerprint') or
                                           (t.get('outcome') or {}).get('artifact_status') == 'reviewed'
                                           for t in turns),
    }


def completion_checks(record, candidate_fingerprint=None):
    """Edit success requires a host-reviewed result bound to the actual candidate."""
    outcome = record.get('outcome') or {}
    return {
        'candidate_present': bool(candidate_fingerprint),
        'candidate_current': bool(candidate_fingerprint) and outcome.get('candidate_fingerprint') == candidate_fingerprint,
        'validation_passed': outcome.get('validation_status') == 'passed',
        'review_passed': outcome.get('review_status') == 'passed',
        'reviewed_artifact': outcome.get('artifact_status') == 'reviewed',
        'ready_for_user_review': outcome.get('task_disposition') == 'awaiting_review' and outcome.get('current_blocker') is None,
        'not_applied': outcome.get('applied') is False,
    }


def answer_completion_checks(record):
    outcome = record.get('outcome') or {}
    return {'answer_delivered': outcome.get('answer_status') == 'delivered',
            'turn_completed': outcome.get('task_disposition') == 'completed',
            'no_blocker': outcome.get('current_blocker') is None}
