"""Display-only, bounded activity for one user request. Never model history."""
import html
import time
import ntpath

from .tool_details import snapshot
from .chat_rendering import content_html, activity_html


def display_path(path, root=None):
    """Project-relative display paths, including Windows paths on any host."""
    path = str(path).replace('\\', '/')
    if path.startswith('/') or ntpath.isabs(path):
        base = str(root or '').replace('\\', '/').rstrip('/')
        if base and path.casefold().startswith(base.casefold() + '/'):
            return path[len(base) + 1:]
        return ntpath.basename(path)
    return path


def tool_label(value, root=None):
    names = {'read_source': 'Inspecting', 'inspect_file': 'Inspecting',
             'inspect_candidate': 'Reviewing', 'search_source': 'Searching source',
             'get_symbol': 'Inspecting symbol', 'propose_changes': 'Preparing changes',
             'propose_callback': 'Preparing callback', 'propose_message_library': 'Preparing changes'}
    name = value['name']
    label = names.get(name, name.replace('_', ' ').capitalize())
    args = value.get('arguments') or {}
    if isinstance(args, dict):
        path = args.get('path') or args.get('filename')
        if isinstance(path, str):
            label += ' ' + display_path(path, root)
    return label


class TurnActivity:
    def __init__(self):
        self.entries = []
        self.expanded = False
        self.started_at = time.monotonic()
        self.finished_at = None
        self.open_previews = set()
        self.proposal_fingerprint = None
        self.applied_proposal_id = None
        self.busy = False

    @property
    def elapsed_seconds(self):
        end = self.finished_at if self.finished_at is not None else time.monotonic()
        return max(0, int(end - self.started_at))

    @property
    def title(self):
        hours, remainder = divmod(self.elapsed_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        duration = ((f"{hours}h " if hours else "")
                    + (f"{minutes}m " if hours or minutes else "") + f"{seconds}s")
        return ("Working for " if self.finished_at is None else "Worked for ") + duration

    def text(self, kind, text, message_id=None):
        if not text:
            return
        if kind in {"reasoning", "pending"}:
            entry = next((item for item in self.entries if item["kind"] == kind and item.get("message_id") == message_id), None)
            if entry is not None:
                self._append(entry, text)
                return
        entry = {"kind": kind, "text": "", "message_id": message_id}
        self._append(entry, text)
        self.entries.append(entry)

    def complete_message(self, message_id, phase, text=""):
        """Replace the optional live preview instead of duplicating final text."""
        self.entries = [entry for entry in self.entries
                        if not (entry["kind"] == "pending" and entry.get("message_id") == message_id)]
        if phase in {"commentary", "interrupted"}:
            self.text(phase, text, message_id)

    @staticmethod
    def _append(entry, text):
        remaining = max(0, 8000 - len(entry["text"]))
        entry["text"] += text[:remaining]
        if len(text) > remaining:
            entry["shortened"] = True

    def tool(self, value, completed=False):
        entry = next((item for item in self.entries if item["kind"] == "tool"
                      and (item["id"], item["message_id"]) == (value["id"], value["message_id"])), None)
        if entry is None:
            entry = {"kind": "tool", "id": value["id"], "message_id": value["message_id"], "name": value["name"]}
            self.entries.append(entry)
        entry["status"] = value.get("status", "completed") if completed else "running"
        if "arguments" in value:
            entry["arguments"] = snapshot(value["arguments"], 16000)
        if completed:
            entry["duration_ms"] = value.get("duration_ms")
            entry["error"] = value.get("error", "")[:500]

    def tool_result(self, value):
        entry = next((item for item in reversed(self.entries) if item["kind"] == "tool"
                      and item["name"] == value["tool"]
                      and ("id" not in value or (item["id"], item["message_id"]) ==
                           (value["id"], value["message_id"]))), None)
        if entry is not None:
            entry["result"] = snapshot(value["result"])
            if value.get("preview"):
                entry["preview"] = snapshot(value["preview"])

    def finish(self):
        if self.finished_at is None:
            self.finished_at = time.monotonic()
        for entry in self.entries:
            if entry["kind"] == "tool" and entry["status"] == "running":
                entry["status"] = "interrupted"

    def render(self, turn, include_tools=True):
        state = "expanded" if self.expanded else "collapsed"
        arrow = f'<img src="sakir-icon:activity-{state}" width="12" height="12">'
        title = self.title
        failed = sum(item["kind"] == "tool" and item["status"] == "failed" for item in self.entries)
        suffix = f" · {failed} failed" if failed else ""
        parts = [f'<p style="margin:4px 0; font-size:9pt;"><a href="sakir-activity:{turn}" '
                 f'style="color:#697180; text-decoration:none;">{title}</a>{suffix}&nbsp; '
                 f'<a href="sakir-activity:{turn}" style="color:#697180; text-decoration:none;">{arrow}</a></p>']
        tool_count = sum(item["kind"] == "tool" for item in self.entries)
        if tool_count and not include_tools:
            noun = "tool call" if tool_count == 1 else "tool calls"
            parts.append(f'<p><a href="sakir-tools:{turn}">{tool_count} {noun} · View tools</a></p>')
        if self.expanded:
            entries = [entry for entry in self.entries
                       if (include_tools or entry["kind"] != "tool")
                       and (self.expanded or entry["kind"] != "reasoning")]
            if not entries:
                parts.append('<p style="color:#697180; font-size:9pt;">No additional details provided.</p>')
            for entry in entries:
                if entry['kind'] in {'changes', 'action', 'data'}:
                    continue
                if entry["kind"] == "tool":
                    name = entry["name"].replace("_", " ").capitalize()
                    label = name + " · " + entry["status"]
                    if type(entry.get("duration_ms")) is int:
                        label += f" · {entry['duration_ms'] / 1000:.1f}s"
                    text = entry.get("error", "")
                    color = "#ad3d32" if entry["status"] in {"failed", "interrupted"} else "#697180"
                else:
                    label = "Provider reasoning" if entry["kind"] == "reasoning" else ""
                    text, color = entry["text"], "#697180"
                    if entry.get("shortened"):
                        text += "\n[Preview shortened]"
                if entry["kind"] in {"commentary", "pending", "interrupted"}:
                    parts.append(activity_html(text))
                else:
                    parts.append(f'<p style="margin:6px 0; color:{color}; font-size:9pt;"><b>{html.escape(label)}</b></p>'
                                 + (content_html(text) if text else ""))
        elif any(e['kind'] == 'interrupted' for e in self.entries):
            parts.append('<p style="color:#ad3d32;">Task interrupted · Expand details</p>')
        if self.finished_at is None:
            # Reserve document space for the existing native shimmer widget.
            parts.append(f'<p style="margin:0;"><a href="sakir-status:{turn}">'
                         '<img src="sakir-icon:live-status" width="1" height="28"></a></p>')
        # Proposal cards remain discoverable even with activity details collapsed.
        for index, entry in enumerate(self.entries):
            if isinstance(entry.get('preview'), dict):
                parts.append(self.render_preview(turn, index, entry['preview']))
        return '<table width="100%" cellspacing="0" cellpadding="10"><tr><td>' + "".join(parts) + "</td></tr></table>"

    def render_preview(self, turn, index, preview):
        escape = html.escape
        fingerprint = preview.get('fingerprint')
        current = fingerprint and fingerprint == self.proposal_fingerprint
        applied = preview.get('applied') or (preview.get('proposal_id') and preview['proposal_id'] == self.applied_proposal_id)
        if applied:
            state = 'Applied'
        elif current:
            state = 'Draft · Reviewing' if self.busy else 'Ready for review'
        elif self.proposal_fingerprint:
            state = 'Superseded'
        elif self.finished_at is None:
            state = 'Draft · Preparing'
        else:
            state = 'Draft · Unavailable'
        paths = preview.get('paths', [])
        summary = escape(str(preview.get('summary') or 'Proposed changes'))
        text = str(preview.get('text', ''))
        lines = text.splitlines()
        added = sum(line.startswith('+') and not line.startswith('+++') for line in lines)
        removed = sum(line.startswith('-') and not line.startswith('---') for line in lines)
        details = f'{len(paths)} {"file" if len(paths) == 1 else "files"} · +{added} −{removed}' if paths else f'+{added} −{removed}'
        if preview.get('truncated'):
            details += ' · Partial line totals'
        paragraph = '<p style="margin:6px 0;">'
        status_bg, status_fg = ('#e9f5ee', '#286143') if applied or (current and not self.busy) else ('#edf2f9', '#59677b')
        body = ('<table width="100%" cellspacing="0" cellpadding="0"><tr><td valign="middle" style="padding:0;">'
                '<p style="margin:0; font-size:11pt;"><b>Proposed changes</b></p></td>'
                '<td align="right" valign="middle" style="padding:0;">'
                f'<table bgcolor="{status_bg}" cellspacing="0" cellpadding="5"><tr><td style="padding:5px;">'
                f'<span style="font-size:8pt; color:{status_fg};">{escape(state)}</span>'
                '</td></tr></table></td></tr></table>'
                f'<p style="margin:8px 0 4px; color:#536074;">{summary}</p>'
                f'<p style="margin:4px 0 10px; color:#748094; font-size:9pt;">{details}</p>')
        if paths:
            body += ('<table width="100%" bgcolor="#edf2f9" cellspacing="0" cellpadding="7"><tr><td style="padding:7px;">'
                     '<span style="font-family:Consolas; font-size:9pt; color:#475569;">'
                     + '<br>'.join(escape(display_path(path)) for path in paths) + '</span></td></tr></table>')
        opened = index in self.open_previews
        if opened:
            body += '<table width="100%" cellspacing="0" cellpadding="2">'
            for line in lines[:240]:
                if line.startswith(('--- ', '+++ ')):
                    continue  # File names already appear in the card's file strip.
                background, foreground = ('#e8f5ec', '#24613d') if line.startswith('+') else (
                    ('#fcebea', '#993b35') if line.startswith('-') else ('#f8fafc', '#69788c'))
                code = escape(line).replace(' ', '&nbsp;').replace('\t', '&nbsp;' * 4) or '&nbsp;'
                body += (f'<tr><td bgcolor="{background}" style="padding:2px 8px;"><p style="margin:0; font-family:Consolas; '
                         f'font-size:9pt; color:{foreground};">{code}</p></td></tr>')
            body += '</table>'
            if len(lines) > 240 or preview.get('truncated') or preview.get('display_truncated'):
                body += paragraph + '<span style="font-size:9pt; color:#748094;">Preview shortened · Open Review &amp; apply for the full current proposal.</span></p>'
        body += '<p style="margin:0; font-size:4pt;">&nbsp;</p>'
        body += ('<table width="100%" cellspacing="0" cellpadding="0"><tr><td style="padding:0;">'
                 '<table bgcolor="#edf2f9" cellspacing="0" cellpadding="7"><tr><td style="padding:7px;">'
                 f'<a href="sakir-diff:{turn}/{index}" style="color:#425873; text-decoration:none; font-size:9pt;">'
                 f'{"Hide preview" if opened else "Preview changes"}</a></td></tr></table></td><td align="right" style="padding:0;">')
        if current and not self.busy and not applied:
            body += ('<table bgcolor="#252a34" cellspacing="0" cellpadding="7"><tr><td style="padding:7px;">'
                     f'<a href="sakir-review:{turn}/{index}" style="color:#ffffff; text-decoration:none; font-size:9pt;">'
                     'Review &amp; apply</a></td></tr></table>')
        else:
            body += f'<span style="font-size:9pt; color:#748094;">{"Changes saved" if applied else "Draft · Not applied"}</span>'
        body += '</td></tr></table>'
        return '<table width="100%" bgcolor="#f8fafc" cellspacing="0" cellpadding="14"><tr><td>' + body + '</td></tr></table>'
