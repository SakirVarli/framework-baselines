"""Selectable rich text with rounded message and code surfaces."""
from PyQt5 import QtCore, QtGui, QtWidgets


class Conversation(QtWidgets.QTextBrowser):
    # QTextDocument supports table padding but not CSS border-radius. Retain
    # its text layout and selection, and paint the marked table surfaces here.
    SURFACES = {"#f2f4f7": 12, "#f3f5f8": 10, "#f8fafc": 12,
                "#e9f5ee": 6, "#edf2f9": 6, "#252a34": 6}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._surfaces = []
        self.live_indicator = None
        self.live_turn = None
        self._live_anchor_cursor = None
        self.follow_latest = True
        self._updating_scroll = False
        self.jump_button = QtWidgets.QToolButton(self.viewport())
        self.jump_button.setToolTip("Jump to latest")
        self.jump_button.setAccessibleName("Jump to latest")
        self.jump_button.setFixedSize(36, 36)
        self.jump_button.clicked.connect(self.jump_to_latest)
        self.jump_button.hide()
        self.verticalScrollBar().valueChanged.connect(self._scroll_changed)
        self.verticalScrollBar().sliderReleased.connect(
            lambda: self._scroll_changed(self.verticalScrollBar().value()))
        self.verticalScrollBar().rangeChanged.connect(self._position_jump_button)
        self.verticalScrollBar().valueChanged.connect(self.position_live_indicator)
        self.horizontalScrollBar().valueChanged.connect(self.position_live_indicator)

    def set_live_indicator(self, indicator):
        self.live_indicator = indicator
        indicator.setParent(self.viewport())
        indicator.hide()

    def set_live_turn(self, turn):
        if self.live_turn != turn:
            self._live_anchor_cursor = None
        self.live_turn = turn
        self.position_live_indicator()

    def position_live_indicator(self, *_):
        indicator = self.live_indicator
        if indicator is None:
            return
        if self._live_anchor_cursor is not None:
            rect = self.cursorRect(self._live_anchor_cursor)
            indicator.setGeometry(rect.left(), rect.top(),
                max(0, self.viewport().width() - rect.left() - 16), 28)
            indicator.setVisible(indicator._running and rect.bottom() >= 0
                                 and rect.top() < self.viewport().height())
            indicator.raise_()
            return
        target = f"sakir-status:{self.live_turn}"
        block = self.document().begin()
        while self.live_turn is not None and block.isValid():
            iterator = block.begin()
            while not iterator.atEnd():
                fragment = iterator.fragment()
                if fragment.isValid() and fragment.charFormat().anchorHref() == target:
                    cursor = QtGui.QTextCursor(self.document())
                    cursor.setPosition(fragment.position())
                    self._live_anchor_cursor = cursor
                    self.position_live_indicator()
                    return
                iterator += 1
            block = block.next()
        indicator.hide()

    def resizeEvent(self, event):
        updating = self._updating_scroll
        self._updating_scroll = True
        super().resizeEvent(event)
        if self.follow_latest and not updating:
            self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())
        self._updating_scroll = updating
        self.position_live_indicator()
        self._position_jump_button()

    def _scroll_changed(self, value):
        if not self._updating_scroll:
            bar = self.verticalScrollBar()
            self.follow_latest = value == bar.maximum() and not bar.isSliderDown()
            self._position_jump_button()

    def jump_to_latest(self):
        self.follow_latest = True
        bar = self.verticalScrollBar()
        bar.setValue(bar.maximum())
        self._position_jump_button()

    def _position_jump_button(self, *_):
        if self._updating_scroll:
            return
        bar = self.verticalScrollBar()
        self.jump_button.move((self.viewport().width() - self.jump_button.width()) // 2,
                              self.viewport().height() - self.jump_button.height() - 12)
        self.jump_button.setVisible(bar.value() < bar.maximum())
        self.jump_button.raise_()

    def setHtml(self, text):
        self._surfaces = []
        self._live_anchor_cursor = None
        super().setHtml(text)
        self._live_anchor_cursor = None
        # Batch format changes; each setFormat otherwise relayouts the history.
        cursor = QtGui.QTextCursor(self.document())
        cursor.beginEditBlock()
        try:
            self._collect_surfaces(self.document().rootFrame())
        finally:
            cursor.endEditBlock()
        self.viewport().update()
        self.position_live_indicator()

    def replace_html(self, text, preserve_scroll=False):
        """Replace a streamed document without flashing the scrollbar at zero."""
        bar = self.verticalScrollBar()
        previous = bar.value()
        follow = self.follow_latest and not preserve_scroll and not bar.isSliderDown()
        top = self.cursorForPosition(QtCore.QPoint(self.viewport().width() // 2, 1))
        top_offset = top.position()
        top_position = top.positionInBlock()
        top_block = top.block().text()
        top_y = self.cursorRect(top).top()
        selection = self.textCursor()
        selected_text = selection.selectedText()
        position, anchor = selection.position(), selection.anchor()
        self.setUpdatesEnabled(False)
        self._updating_scroll = True
        try:
            self.setHtml(text)
            # Finish Qt's lazy layout before restoring the viewport. This also
            # accounts for wrapping when the scrollbar first becomes visible.
            self.document().documentLayout().documentSize()
            if selected_text:
                cursor = QtGui.QTextCursor(self.document())
                last = self.document().characterCount() - 1
                cursor.setPosition(min(anchor, last))
                cursor.setPosition(min(position, last), QtGui.QTextCursor.KeepAnchor)
                if cursor.selectedText() == selected_text:
                    self.setTextCursor(cursor)
            if not follow and not bar.isSliderDown() and top_block.strip():
                block = self.document().findBlock(top_offset)
                if block.text() != top_block:
                    match = self.document().find(top_block)
                    block = match.block() if not match.isNull() else QtGui.QTextBlock()
                if block.isValid():
                    cursor = QtGui.QTextCursor(block)
                    cursor.setPosition(block.position() + top_position)
                    previous = bar.value() + self.cursorRect(cursor).top() - top_y
            bar.setValue(bar.maximum() if follow else previous)
            self.position_live_indicator()
        finally:
            self._updating_scroll = False
            self.setUpdatesEnabled(True)
            self._position_jump_button()

    def update_activity_titles(self, titles):
        """Update only elapsed-time link text, preserving selection and history."""
        replacements = []
        block = self.document().begin()
        while block.isValid():
            iterator = block.begin()
            while not iterator.atEnd():
                fragment = iterator.fragment()
                if fragment.isValid():
                    fmt = fragment.charFormat()
                    title = titles.get(fmt.anchorHref())
                    if title is not None and fragment.text().startswith(("Working for ", "Worked for ")):
                        if fragment.text() != title:
                            replacements.append((fragment.position(), fragment.length(), fmt, title))
                iterator += 1
            block = block.next()
        cursor = QtGui.QTextCursor(self.document())
        cursor.beginEditBlock()
        try:
            for position, length, fmt, title in reversed(replacements):
                cursor.setPosition(position)
                cursor.setPosition(position + length, QtGui.QTextCursor.KeepAnchor)
                cursor.insertText(title, fmt)
        finally:
            cursor.endEditBlock()
        self.position_live_indicator()

    def _collect_surfaces(self, frame):
        for child in frame.childFrames():
            fmt = child.frameFormat()
            brush = fmt.background()
            color = brush.color().name()
            if brush.style() != QtCore.Qt.NoBrush and color in self.SURFACES:
                self._surfaces.append((child, QtGui.QColor(color), self.SURFACES[color]))
                fmt.setBackground(QtGui.QBrush(QtCore.Qt.NoBrush))
                if isinstance(child, QtGui.QTextTable):
                    child.setFormat(fmt.toTableFormat())
                else:
                    child.setFrameFormat(fmt)
            self._collect_surfaces(child)

    def surface_rect(self, frame):
        rect = self.document().documentLayout().frameBoundingRect(frame)
        if isinstance(frame, QtGui.QTextTable):
            # Qt reports the table origin at the first cell's content origin.
            cell = frame.cellAt(0, 0).format().toTableCellFormat()
            rect.translate(-cell.leftPadding(), -cell.topPadding())
        return rect

    def paintEvent(self, event):
        painter = QtGui.QPainter(self.viewport())
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtCore.Qt.NoPen)
        offset = QtCore.QPointF(-self.horizontalScrollBar().value(), -self.verticalScrollBar().value())
        for frame, color, radius in self._surfaces:
            rect = self.surface_rect(frame).translated(offset)
            if rect.intersects(QtCore.QRectF(event.rect())):
                painter.setPen(QtGui.QPen(QtGui.QColor('#dce3ed'), 1)
                               if color.name() == '#f8fafc' else QtCore.Qt.NoPen)
                painter.setBrush(color)
                painter.drawRoundedRect(rect, radius, radius)
        painter.end()
        super().paintEvent(event)
