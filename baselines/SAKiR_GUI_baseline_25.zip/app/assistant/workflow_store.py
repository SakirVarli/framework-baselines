"""Private transactional stage checkpoints and candidate-bound review clearance.

No open connections are shared between Qt and worker threads. With history off,
the same interface keeps all workflow records in memory.
"""
import copy
import json
import sqlite3
import threading
from pathlib import Path

from .policy import AssistantError, redact
from .storage import atomic_json, Store


class WorkflowStore:
    def __init__(self, private):
        self.private = Path(private)
        self.path = self.private / 'workflows' / 'state.sqlite3'
        self.lock = threading.RLock()
        self.memory = {}

    def _connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=5)
        try:
            connection.execute('CREATE TABLE IF NOT EXISTS runs (id TEXT PRIMARY KEY, session TEXT, payload TEXT NOT NULL)')
        except Exception:
            connection.close()
            raise
        return connection

    def save(self, run, durable=True):
        payload = json.dumps(redact(run), ensure_ascii=False)
        if len(payload.encode('utf-8')) > 2_000_000:
            raise AssistantError('WORKFLOW_STORAGE', 'Workflow checkpoint exceeds its size limit.')
        with self.lock:
            if durable:
                try:
                    connection = self._connect()
                    try:
                        with connection:
                            connection.execute('INSERT OR REPLACE INTO runs VALUES (?, ?, ?)',
                                               (run['id'], run['session_id'], payload))
                            connection.execute('DELETE FROM runs WHERE session = ? AND id NOT IN '
                                               '(SELECT id FROM runs WHERE session = ? ORDER BY rowid DESC LIMIT 30)',
                                               (run['session_id'], run['session_id']))
                    finally:
                        connection.close()
                except sqlite3.Error as exc:
                    raise AssistantError('WORKFLOW_STORAGE', 'Could not save workflow checkpoint.') from exc
                self.memory.pop(run['id'], None)
            else:
                self.memory[run['id']] = json.loads(payload)
                siblings = sorted((r for r in self.memory.values() if r['session_id']==run['session_id']), key=lambda r:r['updated'], reverse=True)
                for old in siblings[30:]:
                    self.memory.pop(old['id'], None)

    def records(self):
        with self.lock:
            records = {}
            if self.path.exists():
                try:
                    connection = self._connect()
                    try:
                        for identifier, payload in connection.execute('SELECT id, payload FROM runs'):
                            value = json.loads(payload)
                            if value.get('version') != 1:
                                raise ValueError('version')
                            records[identifier] = value
                    finally:
                        connection.close()
                except (sqlite3.Error, ValueError, TypeError) as exc:
                    raise AssistantError('WORKFLOW_STORAGE', 'Workflow records could not be read; review is required again.') from exc
            records.update(copy.deepcopy(self.memory))
            return list(records.values())

    def clearance(self, proposal, task=None):
        matches = [r for r in self.records() if r.get('candidate') == proposal.fingerprint]
        latest = max(matches, key=lambda r: r['updated'], default=None)
        if (not latest or latest['status'] != 'awaiting_review'
                or latest.get('snapshot_revision') != proposal.context_revision
                or (task and (latest.get('task_id') != task['id'] or latest.get('task_revision') != task['revision']))):
            return 'This draft needs a completed sequential review for its current requirements and contents. Resume the draft to complete review.'
        return None

    def save_candidate(self, proposal):
        """Write payload before its transactional checkpoint references it.

        Uses the existing draft format, so interrupted runs reopen through the
        normal draft browser. Incomplete streams and live Qt objects are absent.
        """
        atomic_json(self.path.parent.parent / 'proposals' / f'{proposal.id}.json',
                    {'id': proposal.id, 'summary': proposal.summary,
                     'context_revision': proposal.context_revision, 'fingerprint': proposal.fingerprint,
                     'outcome_checks': proposal.outcome_checks, 'workflow_required': proposal.workflow_required,
                     'edits': [e.__dict__ for e in proposal.edits]})

    def save_task(self, session_id, messages, ledger, settings):
        store = Store(self.private.parents[2])
        store.save_session(session_id, redact(messages), settings)
        store.save_tasks(session_id, ledger, redact(messages), settings)

    def clear(self):
        with self.lock:
            if self.path.exists():
                connection = self._connect()
                try:
                    with connection:
                        connection.execute('DELETE FROM runs')
                finally:
                    connection.close()
            self.memory.clear()

    def delete_session(self, session_id):
        with self.lock:
            if self.path.exists():
                connection = self._connect()
                try:
                    with connection:
                        connection.execute('DELETE FROM runs WHERE session = ?', (session_id,))
                finally:
                    connection.close()
            self.memory = {k: v for k, v in self.memory.items() if v['session_id'] != session_id}

    def retain(self, session_ids):
        """Remove records for expired history sessions, preserving active callers."""
        with self.lock:
            if self.path.exists():
                connection = self._connect()
                try:
                    with connection:
                        for (session,) in connection.execute('SELECT DISTINCT session FROM runs').fetchall():
                            if session not in session_ids:
                                connection.execute('DELETE FROM runs WHERE session = ?', (session,))
                finally:
                    connection.close()
            self.memory = {k: v for k, v in self.memory.items() if v['session_id'] in session_ids}
