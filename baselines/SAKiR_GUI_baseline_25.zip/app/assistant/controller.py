"""One project controller and Assistant window shared by all entry points."""
import copy
import json
from pathlib import Path
import threading
import uuid

from PyQt5 import QtCore

from .agent_roles import ACTION_TOOLS
from .availability import available
from . import changes
from .context import SourceIndex
from .context_window import clean_state
from .policy import AssistantError, ProjectPolicy, digest, file_hash, redact
from .provider import ChatProvider
from .workflow import run as run_workflow
from .storage import Store, Settings, Credentials, atomic_json
from .tools import ToolSet
from .task_state import TaskLedger
from .settings_policy import resolve_settings
from .workflow_store import WorkflowStore
from .workflow_types import TurnEnvelope


class Controller(QtCore.QObject):
    # Do not name this signal "event": Qt calls QObject.event() to deliver
    # queued worker completions, and a signal in its place aborts the process.
    activity = QtCore.pyqtSignal(str, object)
    busy_changed = QtCore.pyqtSignal(bool)
    proposal_changed = QtCore.pyqtSignal(object)
    action_changed = QtCore.pyqtSignal(object)
    attachments_changed = QtCore.pyqtSignal(object)
    _worker_done = QtCore.pyqtSignal(object)
    _snapshot_requested = QtCore.pyqtSignal(object)
    _models_received = QtCore.pyqtSignal(object)

    def __init__(self, window, root, store=None):
        if not available(window.phase):
            raise AssistantError("UNAVAILABLE", "Assistant is available only in non-frozen baseline/development modes.")
        super().__init__(window)
        self.window = window
        self.policy = ProjectPolicy(root)
        self.store = store or Store(root)
        self.workflow_store = WorkflowStore(self.store.private)
        self.credentials = Credentials()
        self.settings_error = ""
        try:
            self.settings = self.store.load_settings()
        except AssistantError as exc:
            self.settings = Settings()
            self.settings_error = str(exc)
        self.index = SourceIndex(self.policy)
        self.transactions = changes.Transactions(self.policy, self.store)
        self.history = []
        self.task_ledger = TaskLedger()
        self.task_drafts = {}
        self._active_attempt = None
        self._resume_task_id = None
        self.context_state = clean_state({}, [])
        self.evidence_summary = []
        self.task_index = None
        self.session_id = uuid.uuid4().hex
        self.proposal = None
        self.action = None
        self._action_task_id = None
        self.last_transaction = None
        self._undo_fingerprint = None
        self.busy = False
        self.closing = False
        self.cancel = threading.Event()
        self.provider = None
        self.assistant_window = None
        self.selection = ""
        self.recent_errors = []
        self._reload_generation = None
        self._worker_done.connect(self._done)
        self._snapshot_requested.connect(self._capture_snapshot_revision)
        self._models_received.connect(self._finish_models)
        self.discovering_models = False
        self.model_refresh_error = ''
        self.discovered_models = None
        self._pending_model_result = None
        self.window.global_runtime.reload_finished.connect(self._reloaded)
        for name in ("initialization_failed", "initialization_warning"):
            signal = getattr(window, name, None)
            if signal is not None:
                signal.connect(self.capture_error)

    def capture_error(self, generation, details):
        self.recent_errors.append({"generation": generation, "details": redact(str(details))[-6000:]})
        self.recent_errors = self.recent_errors[-10:]

    def change_chat_model(self, model=None, effort=None):
        """Persist next-turn controls without resetting the conversation or draft."""
        if self.busy or self.closing:
            raise AssistantError('PROJECT_BUSY', 'Wait for the current task before changing model or effort.')
        settings = copy.deepcopy(self.settings)
        if model is not None and model != settings.model:
            if not isinstance(model, str) or not model.strip():
                raise AssistantError('SETTINGS_INVALID', 'Enter a model ID.')
            previous_key = digest([settings.base_url, settings.model])
            if settings.model:
                from .reasoning import profile_for
                previous_profile = settings.model_profiles.setdefault(previous_key, copy.deepcopy(profile_for(settings) or {'base_url':settings.base_url,'model':settings.model}))
                previous_profile['preferred_effort'] = settings.reasoning_effort
                previous_profile['chat_limits'] = {k:getattr(settings,k) for k in ('context_tokens','max_tokens','context_margin')}
                previous_profile['chat_streaming'] = settings.streaming
                previous_profile['chat_token_parameter'] = settings.token_parameter
            settings.model = model.strip()
            settings.capability_profile = settings.model_profiles.get(digest([settings.base_url, settings.model]))
            preference = settings.capability_profile or {}
            if type(preference.get('chat_streaming')) is bool:
                settings.streaming = preference['chat_streaming']
            if preference.get('chat_token_parameter') in {'max_tokens','max_completion_tokens'}:
                settings.token_parameter = preference['chat_token_parameter']
            # A manually entered capacity belongs to the previous model.
            settings.context_tokens = 0
            settings.advanced_limits.pop('context_tokens', None)
            for key,value in (settings.capability_profile or {}).get('chat_limits',{}).items():
                if key in {'context_tokens','max_tokens','context_margin'} and type(value) is int:
                    setattr(settings,key,value)
            from .settings_policy import capacity_for
            capacity = capacity_for(settings)
            if capacity and settings.max_tokens + settings.context_margin >= capacity:
                settings.context_margin = min(settings.context_margin,capacity//8)
                settings.max_tokens = max(256,min(settings.max_tokens,capacity//8))
            from .reasoning import supported_efforts
            preferred = (settings.capability_profile or {}).get('preferred_effort', 'auto')
            settings.reasoning_effort = preferred if preferred in supported_efforts(settings) else 'auto'
        if effort is not None:
            settings.reasoning_effort = effort
            from .reasoning import resolve_effort
            resolve_effort(settings)
            current_key = digest([settings.base_url, settings.model])
            if current_key in settings.model_profiles:
                settings.model_profiles[current_key]['preferred_effort'] = effort
        settings = resolve_settings(settings)
        settings.validate(connection=bool(settings.base_url))
        self.store.save_settings(settings)
        self.settings = settings
        self.settings_error = ''
        self.activity.emit('settings', settings.model)

    def discover_models(self):
        if self.discovering_models or self.closing:
            return
        settings = copy.deepcopy(self.settings)
        if not settings.base_url:
            self.model_refresh_error = 'Set a server URL in Connection settings first.'
            self.activity.emit('model_discovery', {'error':self.model_refresh_error})
            return
        # Model discovery does not require a selected ID yet.
        settings.model = settings.model or 'discovery'
        settings.reasoning_effort = 'auto'  # Discover support before sending any effort option.
        settings.timeout = min(15, settings.timeout)
        try:
            key = self.credentials.key(settings)
        except AssistantError as exc:
            self.model_refresh_error = self.error_text(exc)
            self.activity.emit('model_discovery',{'error':self.model_refresh_error})
            return
        self.discovering_models = True
        self.model_refresh_error = ''
        self.activity.emit('model_discovery', {'loading': True})
        def worker():
            provider = None
            try:
                provider = ChatProvider(settings, key)
                result = {'models': provider.models(), 'profiles': provider.model_profiles, 'base_url': settings.base_url}
            except Exception as exc:
                error = self.error_text(exc)
                result = {'error': error.replace(key,'<redacted>') if key else error, 'base_url': settings.base_url}
            finally:
                if provider:
                    try:
                        provider.dispose()
                    except Exception:
                        pass
            try:
                self._models_received.emit(result)
            except RuntimeError:
                pass
        threading.Thread(target=worker, name='assistant-model-discovery', daemon=True).start()

    @QtCore.pyqtSlot(object)
    def _finish_models(self, result):
        self.discovering_models = False
        if self.closing:
            return
        if self.busy:
            # Read-only discovery may run during a task. Apply facts afterwards;
            # never change that task's immutable settings or clear its artifacts.
            self._pending_model_result = result
            self.activity.emit('model_discovery', {'deferred':True})
            return
        if result.get('base_url') != self.settings.base_url:
            self.activity.emit('model_discovery', {'discarded':True})
            return
        if not result.get('error'):
            try:
                settings = self.refreshed_settings(self.settings,result)
                self.store.save_settings(settings)
                self.settings = settings
                self.discovered_models = result.get('models',list(result['profiles']))
            except Exception as exc:
                result = {**result, 'error': self.error_text(exc)}
        self.model_refresh_error = result.get('error','')
        self.activity.emit('model_discovery', result)

    @staticmethod
    def refreshed_settings(original, result):
        from .reasoning import merge_profile, supported_efforts
        settings = copy.deepcopy(original)
        for model, profile in result['profiles'].items():
            key = digest([settings.base_url, model])
            settings.model_profiles[key] = merge_profile(settings.model_profiles.get(key,{}),profile)
        key = digest([settings.base_url,settings.model])
        current = result['profiles'].get(settings.model)
        if current is not None:
            previous = settings.capability_profile or {}
            if (previous.get('base_url'),previous.get('model')) != (settings.base_url,settings.model):
                previous = {}
            settings.capability_profile = merge_profile(previous,settings.model_profiles[key])
        else:
            settings.capability_profile = None
        if settings.reasoning_effort != 'auto' and settings.reasoning_effort not in supported_efforts(settings):
            settings.reasoning_effort = 'auto'
        capacity = (current or {}).get('context_tokens',0)
        if type(capacity) is int and capacity >= 1024:
            # An advertised server limit is an upper bound even when a previous
            # manual setting was larger. Preserve a smaller manual budget.
            if settings.context_tokens:
                settings.context_tokens = min(settings.context_tokens,capacity)
            if settings.max_tokens + settings.context_margin >= capacity:
                settings.context_margin = min(settings.context_margin,capacity//8)
                settings.max_tokens = max(256,min(settings.max_tokens,capacity//8))
                for name in ('context_tokens','max_tokens','context_margin'):
                    if name in settings.advanced_limits:
                        settings.advanced_limits[name] = getattr(settings,name)
        return resolve_settings(settings)

    @QtCore.pyqtSlot(object)
    def _capture_snapshot_revision(self, query):
        try:
            query["revision"] = self.snapshot()["revision"]
        except Exception as exc:
            query["error"] = str(exc)
        finally:
            query["ready"].set()

    def _freshness_check(self, revision):
        # Request Qt-owned designer state on the GUI thread; never inspect it from a worker.
        query = {"ready": threading.Event()}
        if QtCore.QThread.currentThread() == self.thread():
            self._capture_snapshot_revision(query)
        else:
            self._snapshot_requested.emit(query)
            for _ in range(100):
                if query["ready"].wait(.1):
                    break
                if self.cancel.is_set() or self.closing:
                    raise AssistantError("CANCELLED", "Stopped.")
        if not query["ready"].is_set():
            raise AssistantError("PROJECT_BUSY", "Could not confirm current designer state. Retry when the application is ready.")
        if query.get("error") or query.get("revision") != revision:
            raise AssistantError("SOURCE_CHANGED", "Designer or runtime state changed during this task; retry with current context.")

    def snapshot(self):
        designer = getattr(self.window, "_config_designer", None)
        config_path = self.policy.root / "app/data/config.json"
        callbacks_path = self.policy.root / "callbacks/callbacks.py"
        config = copy.deepcopy(designer.document.to_config()) if designer else json.loads(config_path.read_text(encoding="utf-8"))
        callbacks = designer._callback_source() if designer else callbacks_path.read_text(encoding="utf-8")
        from app.config_designer.document import DesignerDocument
        document = designer.document if designer else DesignerDocument.from_config(config)
        def nodes(node, selector="root"):
            return [{"selector": selector, "node_id": node.node_id, "type": node.node_type, "properties": copy.deepcopy(node.properties)}] + [
                row for i, child in enumerate(node.children) for row in nodes(child, f"{selector}/{i}")]
        from app.tool_api import Tools
        runtime = {}
        for name in ("serial", "telnet", "communication"):
            api = getattr(Tools, name)
            runtime[name] = {"open": api.available, "sessions": []}
            if api.available:
                for session in api.sessions:
                    runtime[name]["sessions"].append({"name": session.name, "running": session.running if name == "communication" else session.connected,
                                                      "settings": redact(session.config() if name == "communication" else session.settings)})
        for name in ("ftp_client", "ftp_server"):
            api = getattr(Tools, name)
            runtime[name] = {"open": api.available}
        message_designer = getattr(self.window, "_message_designer", None)
        manifest = copy.deepcopy(message_designer.document.data) if message_designer else None
        message_path = None
        if message_designer and message_designer.loaded:
            try:
                message_path = (message_designer.loaded.package_dir / "message_library.json").relative_to(self.policy.root).as_posix()
            except ValueError:
                pass
        hashes = {"app/data/config.json": file_hash(config_path), "callbacks/callbacks.py": file_hash(callbacks_path)}
        generation = self.window.global_runtime.generation
        result = {"config": config, "callbacks": callbacks, "hashes": hashes, "runtime_generation": generation,
                  "layout_tree": nodes(document.root), "runtime": runtime, "selection": self.selection,
                  "selected_nodes": designer.document.selected_ids if designer else [], "message_manifest": manifest,
                  "message_library_path": message_path,
                  "message_properties_pending": bool(message_designer and message_designer._properties_pending),
                  "attachments": sorted(map(str, self.policy.attachments)), "recent_errors": copy.deepcopy(self.recent_errors)}
        # Selection and transient runtime status are useful context, but do not
        # invalidate a reviewed code edit. Actual source/document generations do.
        result["revision"] = digest([config, callbacks, hashes, generation, manifest])
        return result

    def submit(self, request, can_edit=True, *, turn_origin='user_message'):
        if self.busy or self.closing:
            raise AssistantError("PROJECT_BUSY", "Wait for the current task or stop it.")
        if not self.window._admin_ok():
            return
        from .settings_policy import resolve_settings
        settings = resolve_settings(self.settings)
        settings.validate()
        key = self.credentials.key(settings)
        snapshot = self.snapshot()
        profile = settings.capability_profile or {}
        scoped = (profile.get('base_url'),profile.get('model'),profile.get('streaming')) == (settings.base_url,settings.model,settings.streaming)
        tools_supported = profile.get("tool_round_trip", True) if scoped else True
        if can_edit and not tools_supported and not settings.multi_model:
            raise AssistantError("TOOLS_UNSUPPORTED", "This connection failed tool compatibility. Use Explain / Inspect for source-context chat, or configure a tool-capable model.")
        history = copy.deepcopy(self.history)
        context_state = copy.deepcopy(self.context_state)
        previous_evidence = copy.deepcopy(self.evidence_summary)
        ledger=TaskLedger(self.task_ledger.export())
        drafts=dict(self.task_drafts)
        resume_task_id=self._resume_task_id
        self._resume_task_id=None
        bound_task = ledger.find(resume_task_id) if resume_task_id else None
        envelope = TurnEnvelope(origin=turn_origin, task_id=resume_task_id,
                                user_message_id=bound_task['source_message_id'] if bound_task and turn_origin=='resume_button' else None)
        attempt_id=self._active_attempt=uuid.uuid4().hex
        self.cancel = threading.Event()
        self.busy = True
        self.busy_changed.emit(True)
        if turn_origin in {'user_message', 'clarification_answer'}:
            self.history.append({"role": "user", "content": request})
            self.activity.emit("user", request)
        else:
            self.activity.emit('turn_resumed', {'task_id': resume_task_id, 'summary': bound_task['summary'] if bound_task else 'Task'})
        def worker():
            tools = None
            try:
                tools = ToolSet(self.policy, self.index, snapshot, settings, self.cancel, can_edit,
                                freshness_check=lambda: self._freshness_check(snapshot["revision"]),ledger=ledger,
                                drafts=drafts,resume_task_id=resume_task_id)
                tools.turn_envelope = envelope
                self.provider = ChatProvider(settings, key)
                # Every turn reads current metadata: a local server can restart
                # behind the same URL/model alias between requests.
                if callable(getattr(self.provider,'models',None)):
                    emit_settings = copy.deepcopy(settings)
                    emit_settings.reasoning_effort = 'auto'
                    self.provider.settings = emit_settings
                    try:
                        self.provider.models()
                    except Exception as exc:
                        error = self.error_text(exc)
                        error = error.replace(key,'<redacted>') if key else error
                        self._models_received.emit({'base_url':settings.base_url,'error':error})
                        raise AssistantError('MODEL_REFRESH_FAILED','Could not read current server capabilities. Use Refresh before retrying. '+error) from exc
                    discovered = {'models':list(self.provider.model_profiles),
                                  'profiles':self.provider.model_profiles,'base_url':settings.base_url,'from_task':True}
                    routing = settings.multi_model and len(discovered['models']) >= 2
                    if settings.model not in discovered['models'] and not routing:
                        self._models_received.emit(discovered)
                        raise AssistantError('MODEL_UNAVAILABLE','The selected model is not served by this endpoint. Select an available model next to the mode dropdown.')
                    settings_for_task = self.refreshed_settings(settings,discovered)
                    tools.settings = settings_for_task
                    self.provider.settings = settings_for_task
                    self._models_received.emit(discovered)
                if not (settings.multi_model and len(getattr(self.provider, 'model_profiles', {})) >= 2):
                    if can_edit and not tools_supported:
                        raise AssistantError('TOOLS_UNSUPPORTED', 'This connection failed tool compatibility.')
                    if not tools_supported:
                        tools.definitions.clear()
                text = run_workflow(self.provider, tools, history, request, self.activity.emit,
                                    self.cancel, self.workflow_store, self.session_id,
                                    context_state=context_state, previous=previous_evidence)
                result = {"text": text, "proposal": tools.proposal, "action": tools.action, "evidence": tools.evidence,
                          "task_index": tools.index}
            except Exception as exc:
                result = {"error": "CANCELLED: Stopped." if self.cancel.is_set() else self.error_text(exc),
                          "proposal": getattr(tools, "proposal", None), "action": getattr(tools, "action", None)}
            finally:
                result['attempt_id']=attempt_id
                result['task_ledger']=ledger.export()
                result['selected_task_id']=(ledger.selected or {}).get('id')
                if hasattr(tools, "workflow_context_state"):
                    result["context_state"] = tools.workflow_context_state
                if self.provider:
                    try:
                        self.provider.dispose()
                    except Exception:
                        pass
                self.provider = None
            try:
                self._worker_done.emit(result)
            except RuntimeError:
                pass  # the application/window can close while a request ends
        threading.Thread(target=worker, name="sakir-assistant", daemon=True).start()

    def error_text(self, exc):
        text = str(exc)
        try:
            key = self.credentials.key(self.settings)
            if key and key != "local-no-auth":
                text = text.replace(key, "<redacted>")
        except AssistantError:
            pass
        return f"{getattr(exc, 'code', 'ASSISTANT_ERROR')}: {redact(text)}"

    @staticmethod
    def workflow_error_message(error, has_draft):
        code = error.split(':', 1)[0]
        if code == 'CANCELLED':
            text = 'Stopped.'
        elif code in {'SOURCE_CHANGED', 'FILE_CHANGED', 'STALE_DRAFT', 'STALE_REVIEW'}:
            text = 'The project changed during this attempt. Resume with fresh inspection.'
        elif code == 'TASK_LIMIT':
            text = 'The workflow reached its task limits before completion. Resume or choose a larger task allowance.'
        elif code == 'API_EXAMPLE_INVALID':
            text = 'The generated API example could not be verified against this project after correction. Retry with a narrower example; details are in activity.'
        elif code in {'API_EVIDENCE_REQUIRED','API_EVIDENCE_MISMATCH'}:
            text = 'The answer needs matching project documentation or source evidence. Retry with a narrower question; details are in activity.'
        elif code in {'API_RESPONSE_UNSUPPORTED','API_REVIEW_REQUIRED'}:
            text = 'The API explanation did not pass factual review. Details are in activity.'
        elif code in {'CONTEXT_COMPACTION_FAILED','CONTEXT_LIMIT'}:
            text = 'The conversation could not fit safely in the model context. History was preserved; retry with a shorter request or larger context allowance.'
        elif code == 'INVALID_TOOL_CALL':
            text = 'The model or recovery flow returned an invalid tool exchange. Details are in activity.'
        elif 'timeout' in code.lower() or 'timed out' in error.lower():
            text = 'The model request timed out before completion. Retry or adjust the task allowance.'
        elif code in {'STAGE_PROTOCOL', 'RESPONSE_REQUIRED', 'RESPONSE_CONTRACT', 'API_EXAMPLE_INVALID', 'API_EVIDENCE_MISMATCH', 'API_RESPONSE_UNSUPPORTED', 'API_REVIEW_REQUIRED', 'NO_PROGRESS'}:
            text = 'The model could not complete a usable response. Retry the request or resume the task.'
        else:
            text = 'This attempt could not complete. Technical details are available in activity.'
        return text + (' Your draft was retained; nothing was applied.' if has_draft else ' Nothing was applied or executed.')

    @QtCore.pyqtSlot(object)
    def _done(self, result):
        if self.closing:
            return
        if result.get('attempt_id') and result['attempt_id']!=self._active_attempt:
            return
        if result.get('task_ledger'):
            self.task_ledger=TaskLedger(result['task_ledger'])
        if result.get('runtime_action') and result.get('action_task_id'):
            task=self.task_ledger.find(result['action_task_id'])
            if task:
                task['status']='incomplete' if result.get('error') else 'completed'
                task['completion']={**task.get('completion',{}),'dispatched':not bool(result.get('error')),
                                    'runtime_executed':not bool(result.get('error')),'device_completion_verified':False}
                if result.get('error'):
                    task['last_failure']={'kind':'dispatch_failed_or_unknown','message':result['error'][:1000]}
                else:
                    self.task_ledger.recovered(task)
        self.busy = False
        self.busy_changed.emit(False)
        if self._pending_model_result is not None:
            pending, self._pending_model_result = self._pending_model_result, None
            self._finish_models(pending)
        if "context_state" in result:
            self.context_state = clean_state(result["context_state"], self.history)
        if result.get("evidence"):
            self.evidence_summary = result["evidence"]
        if result.get("task_index"):
            self.task_index = result["task_index"]
        if not result.get("runtime_action"):
            selected=result.get('selected_task_id')
            if result.get('proposal'):
                self.proposal=result['proposal']
                if selected:
                    self.task_drafts[selected]=self.proposal
            elif selected:
                self.proposal=self.task_drafts.get(selected)
            self.proposal_changed.emit(self.proposal)
            if result.get('action') and selected:
                self.action = result['action']
                self._action_task_id = selected
            elif selected:
                self.action = None
                self._action_task_id = None
            self.action_changed.emit(self.action)
            self._recover_pending_actions()
            if self.proposal and self.settings.save_history:
                try:
                    atomic_json(self.store.private / "proposals" / f"{self.proposal.id}.json",
                                {"id": self.proposal.id, "summary": self.proposal.summary,
                                 "context_revision": self.proposal.context_revision, "fingerprint": self.proposal.fingerprint,
                                 "outcome_checks": self.proposal.outcome_checks,
                                 "workflow_required": self.proposal.workflow_required,
                                 "edits": [e.__dict__ for e in self.proposal.edits]})
                except OSError as exc:
                    self.activity.emit("error", "Proposal stays in memory; could not save draft: " + str(exc))
        if result.get("error"):
            current=self.task_ledger.find(result.get('selected_task_id')) if result.get('selected_task_id') else None
            if current and current['status'] not in {'awaiting_mode_change','awaiting_clarification'}:
                current['status']='incomplete'
                current['last_failure']={'kind':'attempt_failed','message':result['error'][:1000]}
            if not result.get('runtime_action'):
                self.activity.emit('workflow_diagnostic', {'text': result['error'][:1000]})
                self.activity.emit('error', self.workflow_error_message(result['error'], bool(self.proposal)))
            else:
                self.activity.emit("error", result["error"])
        elif result.get("text"):
            self.history.append({"role": "assistant", "content": result["text"]})
        # Persist only user-visible messages, not tool data/source or secrets.
        self.history = redact(self.history)
        try:
            if result.get('error'):
                self.store.save_failure(self.session_id,result['error'],len(self.history)-1,self.settings)
            self.store.save_session(self.session_id, self.history, self.settings, self.context_state)
            self.store.save_tasks(self.session_id,self.task_ledger,self.history,self.settings)
        except OSError as exc:
            self.activity.emit("error", "Conversation could not be saved: " + str(exc))
        if not result.get('error'):
            self.activity.emit("status", "Review the proposal" if self.proposal else "Ready")
        self.activity.emit('task_state',self.task_ledger.projection())

    def answer_question(self, task_id, question_id, revision, *, value='', option_id='', delegate=False, can_edit=False):
        if self.busy or self.closing:
            raise AssistantError('PROJECT_BUSY','Wait for the current attempt before answering.')
        candidate=TaskLedger(self.task_ledger.export())
        message_id=digest([len(self.history),'clarification',question_id,value,option_id,delegate])
        q=candidate.answer(task_id,question_id,revision,value,option_id,delegate,
                           snapshot_revision=self.snapshot()['revision'],message_id=message_id)
        candidate.data['active_task_id']=task_id
        # Persist acceptance before replacing the in-memory question. A failed
        # save leaves the original card answerable, with its typed text intact.
        self.store.save_tasks(self.session_id,candidate,self.history,self.settings)
        self.task_ledger=candidate
        self._resume_task_id=task_id
        # The explicit answer is persisted before inference; connection failure
        # cannot lose it or require the user to answer again.
        answer=q['answer']['text']
        message=f'Answer to {q["question"]}: {answer}'
        task=candidate.find(task_id)
        if candidate.pending(task,True):
            self._resume_task_id=None
            self.history.append({'role':'user','content':message})
            self.activity.emit('user',message)
            self.history=redact(self.history)
            self.store.save_session(self.session_id,self.history,self.settings,self.context_state)
            self.store.save_tasks(self.session_id,self.task_ledger,self.history,self.settings)
            self.activity.emit('task_state',self.task_ledger.projection())
            return
        self.store.save_tasks(self.session_id,self.task_ledger,self.history,self.settings)
        self.activity.emit('task_state',self.task_ledger.projection())
        try:
            self.submit(message,can_edit,turn_origin='clarification_answer')
        except Exception as exc:
            self._resume_task_id=None
            task['status']='incomplete'
            task['last_failure']={'kind':'resume_failed','message':str(exc)[:1000]}
            try:
                self.store.save_tasks(self.session_id,self.task_ledger,self.history,self.settings)
            except OSError:
                pass
            self.activity.emit('task_state',self.task_ledger.projection())
            raise

    def resume_task(self, task_id, can_edit=False):
        task=self.task_ledger.find(task_id)
        if task is None:
            raise AssistantError('TASK_NOT_FOUND','This task is no longer available.')
        if not can_edit and task['status']=='awaiting_mode_change':
            raise AssistantError('MODE_REQUIRED','Select Create Changes to resume this operation.')
        self._resume_task_id=task_id
        try:
            self.submit(task['source_text'],can_edit,turn_origin='resume_button')
        except Exception:
            self._resume_task_id=None
            raise

    def stop(self):
        self.cancel.set()
        provider = self.provider
        if provider:
            threading.Thread(target=provider.close, daemon=True).start()
        self.activity.emit("status", "Stopping…")

    def shutdown(self):
        self.closing = True
        self.stop()
        view = self.assistant_window
        self.assistant_window = None
        if view is not None:
            try:
                view.paint_timer.stop()
                view.close()
                view.deleteLater()
            except RuntimeError:
                pass

    def new_session(self, history=None, session_id=None):
        if self.busy:
            raise AssistantError("PROJECT_BUSY", "Stop the active task before changing sessions.")
        candidate_history=history or []
        if session_id:
            candidate_history = self.store.recover_response(session_id, candidate_history)
        ledger=self.store.load_tasks(session_id,candidate_history) if session_id else TaskLedger()
        available={p.id:p for p in self.drafts()}
        self.history = candidate_history
        self.task_ledger=ledger
        self.task_drafts={t['id']:available[t['artifact_id']] for t in ledger.data['tasks'] if t['artifact_id'] in available}
        self._resume_task_id=None
        self._active_attempt=None
        self.evidence_summary = []
        self.task_index = None
        self.session_id = session_id or uuid.uuid4().hex
        self.context_state = clean_state(self.store.load_context(self.session_id), self.history) if session_id else clean_state({}, self.history)
        self.proposal = None
        self.proposal_changed.emit(None)
        self.action = None
        self._action_task_id = None
        self.action_changed.emit(None)
        self._recover_pending_actions()
        self.activity.emit("session", copy.deepcopy(self.history))
        self.activity.emit('task_state',self.task_ledger.projection())

    def _recover_pending_actions(self):
        pending_digest = digest(self.action) if self.action else None
        for task in self.task_ledger.data['tasks']:
            artifact = task['artifact_id']
            if (task['status'] == 'ready_for_review' and artifact
                    and (task['id'] != self._action_task_id or artifact != pending_digest)
                    and any(r['operation'] in ACTION_TOOLS and r['artifact_id'] == artifact for r in task['receipts'])):
                task['status'] = 'incomplete'
                task['artifact_id'] = None
                task['completion'] = {**task.get('completion', {}), 'host_validation': False, 'artifact_id': None}

    def review(self, *, structured=False):
        if not self.proposal:
            raise AssistantError("NO_PROPOSAL", "No proposal is ready.")
        snapshot = self.snapshot()
        report = changes.validate(self.policy, self.proposal, snapshot)
        task = next((t for t in self.task_ledger.data['tasks'] if t['artifact_id'] == self.proposal.id), None)
        # Restore stages a host-generated inverse of the committed transaction.
        try:
            issue = None if self.proposal.fingerprint == self._undo_fingerprint else self.workflow_store.clearance(self.proposal, task)
        except AssistantError as exc:
            issue = str(exc)
        if issue:
            report['ok'] = False
            report['issues'].append({'severity': 'error', 'code': 'WORKFLOW_REVIEW_REQUIRED', 'message': issue})
        for edit in self.proposal.edits:
            name = Path(edit.path).stem
            if edit.path.startswith("app/data/") and name != "config" and snapshot["runtime"].get(name if name != "communication_hub" else "communication", {}).get("open"):
                report["ok"] = False
                report["issues"].append({"severity": "error", "message": f"Close {name} before applying its saved settings to avoid overwriting its active state."})
            message_path = snapshot.get("message_library_path")
            if message_path and Path(edit.path).parent == Path(message_path).parent and snapshot["message_properties_pending"]:
                report["ok"] = False
                report["issues"].append({"severity": "error", "message": "Apply or discard pending Message Designer property edits before saving its library."})
        return report, (changes.review_files(self.policy, self.proposal, snapshot) if structured
                        else changes.diff(self.policy, self.proposal, snapshot))

    def drafts(self):
        result = []
        for path in sorted((self.store.private / "proposals").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                edits = tuple(changes.Edit(**edit) for edit in value["edits"])
                proposal = changes.Proposal(value["id"], value["summary"], edits, value["context_revision"], tuple(value.get('outcome_checks', [])), bool(value.get('workflow_required', False)))
                if proposal.fingerprint == value["fingerprint"]:
                    result.append(proposal)
            except (OSError, ValueError, KeyError, TypeError):
                continue
        return result[:30]

    def load_draft(self, proposal):
        if self.busy:
            raise AssistantError("PROJECT_BUSY", "Stop the active task before loading a draft.")
        for edit in proposal.edits:
            self.policy.path(edit.path, write=True)
        self.proposal = proposal
        task = next((t for t in self.task_ledger.data['tasks'] if t['artifact_id'] == proposal.id), None)
        if task:
            self.task_drafts[task['id']] = proposal
        self.proposal_changed.emit(proposal)

    def apply(self, fingerprint, reload=True):
        if self.busy or self.closing or getattr(self.window, "_source_reload_in_progress", False):
            raise AssistantError("PROJECT_BUSY", "Application is busy or reloading.")
        if not self.window._admin_ok():
            return
        report, _ = self.review()
        if not report["ok"]:
            raise AssistantError("VALIDATION_FAILED", "\n".join(i["message"] for i in report["issues"] if i["severity"] == "error"))
        window = self.window
        if window._pending_source_paths or window._source_change_prompt is not None or window._source_reload_notice is not None:
            raise AssistantError("PROJECT_BUSY", "Resolve the existing source-change/reload notice before applying.")
        # No event loop reentry while the short commit holds the GUI-side gate.
        proposal = self.proposal
        designer = getattr(window, "_config_designer", None)
        previous_callbacks = designer._callback_source() if designer else None
        saved = self.transactions.commit(proposal, fingerprint)
        self.last_transaction = saved
        self._undo_fingerprint = None
        for task in self.task_ledger.data['tasks']:
            if task['artifact_id']==proposal.id:
                task['status']='incomplete' if 'prepare_action' in task['work'] and not task.get('completion', {}).get('dispatched') else 'completed'
                task['completion']={**task.get('completion',{}),'applied':True,'transaction_id':saved}
                self.task_ledger.recovered(task)
                task['artifact_id']=None
                self.task_drafts.pop(task['id'],None)
        try:
            self.store.save_tasks(self.session_id,self.task_ledger,self.history,self.settings)
        except OSError as exc:
            self.activity.emit('error','Changes saved, but task-state persistence failed: '+str(exc))
        self.activity.emit('task_state',self.task_ledger.projection())
        window._assistant_reload_hashes = {self.policy.root / e.path: file_hash(self.policy.root / e.path) for e in proposal.edits}
        candidate = json.loads((self.policy.root / "app/data/config.json").read_text(encoding="utf-8"))
        callbacks = (self.policy.root / "callbacks/callbacks.py").read_text(encoding="utf-8")
        warning = ""
        try:
            from app.stub_generator import regenerate_stubs
            regenerate_stubs(candidate)
        except Exception as exc:
            warning = " Saved, but generated stubs need repair: " + str(exc)
        if designer:
            from app.config_designer.document import DesignerDocument
            from app.config_designer.commands import ReplaceDocumentCommand, CallbackSourceCommand
            designer.undo_stack.beginMacro("Assistant changes")
            designer.undo_stack.push(ReplaceDocumentCommand(designer.document, DesignerDocument.from_config(candidate), "Assistant layout"))
            designer.undo_stack.push(CallbackSourceCommand(designer._set_callback_source, previous_callbacks, callbacks, "Assistant callbacks"))
            designer.undo_stack.endMacro()
            designer.document.mark_saved()
            designer._callback_source_override = None
            designer._callback_edit_baseline = None
            designer._reset_callback_tracking()
            designer.undo_stack.setClean()
            designer.run_validation(quiet=True)
        message_designer = getattr(window, "_message_designer", None)
        if message_designer and message_designer.loaded:
            current_manifest = message_designer.loaded.package_dir / "message_library.json"
            if any(self.policy.root / edit.path == current_manifest for edit in proposal.edits):
                from app.tools.message_designer.persistence import load_library
                from app.tools.message_designer.commands import ReplaceManifestCommand
                loaded = load_library(current_manifest.parent)
                message_designer.undo_stack.push(ReplaceManifestCommand(message_designer.document,
                    message_designer.document.snapshot(), loaded.manifest, "Assistant message library"))
                message_designer.document.mark_saved()
                message_designer.loaded = loaded
                message_designer.undo_stack.setClean()
        self.proposal = None
        self.proposal_changed.emit(None)
        self.activity.emit("status", "Saved" + warning)
        if reload:
            self.busy = True
            self.busy_changed.emit(True)
            self._reload_generation = window.global_runtime.generation + 1
            try:
                generation = window._reload_layout(candidate)
                if self._reload_generation is not None:
                    self._reload_generation = generation
                    self.activity.emit("status", "Saved; reloading runtime…" + warning)
            except Exception as exc:
                self._reload_generation = None
                self.busy = False
                self.busy_changed.emit(False)
                self.activity.emit("error", "Files saved, but runtime reload failed: " + str(exc))
        else:
            self.activity.emit("status", "Saved; runtime still uses the previous generation. Reload when ready." + warning)

    def _reloaded(self, generation, success):
        if generation != self._reload_generation:
            return
        self._reload_generation = None
        self.busy = False
        self.busy_changed.emit(False)
        self.activity.emit("status" if success else "error", "Saved and running" if success else "Saved, but reload failed. Review diagnostics or restore the previous contents.")

    def restore(self):
        if not self.last_transaction:
            raise AssistantError("UNDO_UNAVAILABLE", "No saved assistant change to restore in this session.")
        self.proposal = self.transactions.undo_proposal(self.last_transaction, self.snapshot())
        self._undo_fingerprint = self.proposal.fingerprint
        self.proposal_changed.emit(self.proposal)

    def run_action(self, approved_digest):
        if self.busy or self.closing or not self.action:
            raise AssistantError("PROJECT_BUSY", "No runtime action is ready.")
        if not self.window._admin_ok():
            return
        action = copy.deepcopy(self.action)
        snapshot = self.snapshot()
        if approved_digest != digest(action) or snapshot["runtime_generation"] != action["generation"] or digest(snapshot["runtime"]) != action["runtime_revision"]:
            raise AssistantError("STALE_ACTION", "Session state changed; request a new action.")
        task = self.task_ledger.find(self._action_task_id) if self._action_task_id else None
        if not task or task['status'] != 'ready_for_review' or task['artifact_id'] != approved_digest:
            raise AssistantError('STALE_ACTION', 'The action no longer belongs to a task awaiting approval.')
        action_task_id = task['id']
        from app.tool_api import Tools
        # Locate on the owning thread; effect dispatch uses the public APIs.
        session = getattr(Tools, action["tool"]).session(action["session"]) if action["operation"] != "open" else None
        self.action = None  # consume before execution; repeated clicks cannot resend
        self._action_task_id = None
        self.action_changed.emit(None)
        self.busy = True
        self.busy_changed.emit(True)
        self.cancel = threading.Event()
        def worker():
            try:
                operation = action["operation"]
                if operation == "open":
                    methods = {"serial": "_open_serial", "telnet": "_open_telnet", "communication": "_open_communication_hub",
                               "ftp_client": "_open_ftp_client", "ftp_server": "_open_ftp_server",
                               "message_designer": "_open_message_designer", "config_designer": "_open_designer"}
                    result = Tools.registry.call_gui(getattr(self.window, methods[action["tool"]]))
                elif operation == "connect":
                    result = session.start() if action["tool"] == "communication" else session.connect()
                elif operation == "disconnect":
                    result = session.stop() if action["tool"] == "communication" else session.disconnect()
                else:
                    result = session.send(action["payload"]) if action["tool"] == "communication" else session.write(action["payload"].encode("utf-8"))
                if hasattr(result, "result"):
                    result = result.result(timeout=30)
                message = f"{operation.title()} dispatched to {action['tool']} / {action['session']}. Check the tool's connection/status for completion."
                self.activity.emit("status", message)
                self._worker_done.emit({"text": message, "runtime_action": True,'action_task_id':action_task_id})
            except Exception as exc:
                self._worker_done.emit({"error": self.error_text(exc), "runtime_action": True,'action_task_id':action_task_id})
        threading.Thread(target=worker, daemon=True, name="assistant-session-action").start()

    def add_view(self, host=None):
        """Raise the project's tool window, regardless of which menu opened it."""
        if self.closing:
            raise AssistantError("UNAVAILABLE", "Assistant is shutting down.")
        from .ui import AssistantWindow
        view = self.assistant_window
        if view is not None:
            try:
                view.isVisible()
            except RuntimeError:
                view = None
        if view is None:
            view = AssistantWindow(self)
            self.assistant_window = view
        if view.isMinimized():
            view.showNormal()
        else:
            view.show()
        view.raise_()
        view.activateWindow()
        return view


def recover_project(root):
    policy = ProjectPolicy(root)
    store = Store(root)
    if not (store.private / "transactions").exists():
        return []
    return changes.Transactions(policy, store).recover()
