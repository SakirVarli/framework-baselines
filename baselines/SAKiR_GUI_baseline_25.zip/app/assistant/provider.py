"""OpenAI-compatible Chat Completions transport with optional streaming."""
import json
import threading
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPSHandler, HTTPRedirectHandler
import ssl
import time

from .policy import AssistantError


class ChatProvider:
    def __init__(self, settings, api_key, client=None):
        settings.validate()
        self.settings = settings
        self._key = api_key
        self._stream = None
        self.request_deadline = None
        self._lock = threading.Lock()
        self.model_limits = {}
        self.model_profiles = {}
        self.effective_effort = None
        if settings.reasoning_effort != 'auto':
            from .reasoning import resolve_effort
            self.effective_effort = resolve_effort(settings)
        if client is not None:
            self.client = client
        else:
            try:
                # Lazy at runtime, visible to the supervisor's AST dependency scan.
                import openai as sdk
            except ImportError:
                raise AssistantError("DEPENDENCY_MISSING", "Install assistant dependencies: python -m pip install -r app/assistant/requirements.txt") from None
            options = {"base_url": settings.base_url.rstrip("/"), "api_key": api_key,
                       "timeout": settings.timeout, "max_retries": 0}
            if settings.ca_bundle:
                import ssl
                options["http_client"] = sdk.DefaultHttpxClient(verify=ssl.create_default_context(cafile=settings.ca_bundle))
            self.client = sdk.OpenAI(**options)

    def close(self):
        with self._lock:
            stream = self._stream
        if stream:
            stream.close()

    def dispose(self):
        try:
            self.close()
        finally:
            self.client.close()

    def models(self):
        models = self.client.models.list(timeout=min(15,self.settings.timeout)).data
        for model in models:
            levels = getattr(model, 'reasoning_efforts', None) or getattr(model, 'supported_reasoning_efforts', None)
            profile = {'base_url': self.settings.base_url, 'model': model.id, 'context_tokens':0,
                       'reasoning_efforts':[], 'reasoning_adapter':'server', 'reasoning_source':'not advertised by server'}
            revision = getattr(model, 'revision', None)
            if isinstance(revision, (str, int)) and revision:
                profile['model_revision'] = revision
            tool_round_trip = getattr(model, 'tool_round_trip', None)
            if type(tool_round_trip) is bool:
                profile['tool_round_trip'] = tool_round_trip
                streaming = getattr(model, 'streaming', None)
                if type(streaming) is bool:
                    profile['streaming'] = streaming
            if isinstance(levels, list) and levels:
                profile.update(reasoning_adapter='native', reasoning_efforts=levels, reasoning_source='model metadata')
            for key in ("context_length", "context_window", "max_context_length", "max_model_len"):
                value = getattr(model, key, None)
                if type(value) is int and 1024 <= value <= 10000000:
                    self.model_limits[model.id] = value
                    profile['context_tokens'] = value
                    break
            self.model_profiles[model.id] = profile
        # llama.cpp publishes rendered template effort levels. This read-only
        # endpoint is optional; never guess support from a model filename.
        try:
            url = urlsplit(self.settings.base_url)
            class NoRedirect(HTTPRedirectHandler):
                def redirect_request(self, *args, **kwargs):
                    return None
            opener = build_opener(NoRedirect, HTTPSHandler(context=ssl.create_default_context(cafile=self.settings.ca_bundle or None)))
            req = Request(f'{url.scheme}://{url.netloc}/props', headers={'Authorization':'Bearer ' + self._key})
            with opener.open(req, timeout=min(5, self.settings.timeout)) as response:
                props = json.loads(response.read(2_000_001))
            caps = props.get('chat_template_caps', {})
            levels = caps.get('reasoning_effort_levels', [])
            if len(models) == 1:
                from pathlib import Path
                profile = self.model_profiles[models[0].id]
                profile['server_build'] = str(props.get('build_info',''))
                profile['model_file'] = Path(str(props.get('model_path',''))).name
                params = props.get('default_generation_settings', {}).get('params', {})
                profile['generation_defaults'] = {k:params[k] for k in ('seed','temperature','top_p','top_k','presence_penalty','repeat_penalty','reasoning_budget','reasoning_effort') if k in params}
            # /props describes one loaded model, not every router model.
            if len(models) == 1 and isinstance(levels, list) and levels:
                self.model_profiles[models[0].id].update(reasoning_adapter='llama_cpp', reasoning_efforts=levels,
                                                       reasoning_source='server chat_template_caps')
            elif len(models) == 1 and 'enable_thinking' in str(props.get('chat_template') or ''):
                self.model_profiles[models[0].id].update(reasoning_adapter='llama_cpp', reasoning_efforts=['none','enabled'],
                                                       reasoning_source='server template supports thinking on/off; graded effort unavailable')
            capacity = props.get('default_generation_settings', {}).get('n_ctx')
            if len(models) == 1 and type(capacity) is int and capacity >= 1024:
                self.model_limits[models[0].id] = capacity
                self.model_profiles[models[0].id]['context_tokens'] = capacity
        except Exception:
            pass  # Discovery works with servers lacking /props.
        return [model.id for model in models]

    def complete(self, messages, tools, cancel, emit=lambda *args: None, max_tokens=None):
        self._check_request(cancel)
        kwargs = {"model": self.settings.model, "messages": messages, "stream": self.settings.streaming,
                  self.settings.token_parameter: max_tokens or self.settings.max_tokens}
        if self.request_deadline is not None:
            kwargs['timeout'] = max(0.1, min(self.settings.timeout, self.request_deadline - time.monotonic()))
        from .reasoning import request_options
        kwargs.update(request_options(self.settings, self.effective_effort))
        if self.settings.streaming and self.settings.stream_usage:
            kwargs["stream_options"] = {"include_usage": True}
        if tools:
            kwargs.update(tools=tools, tool_choice="auto")
        if not self.settings.usage_headers:
            return self._consume(self.client.chat.completions.create(**kwargs), cancel, emit)
        try:
            # The context manager closes the HTTP response even on parse failure.
            # With stream=True, parse() returns the SDK stream without buffering it.
            with self.client.chat.completions.with_streaming_response.create(**kwargs) as raw:
                self._emit_headers(raw.headers, emit)
                return self._consume(raw.parse(), cancel, emit)
        except Exception as exc:
            response = getattr(exc, "response", None)
            if response is not None:
                self._emit_headers(response.headers, emit)
            raise

    def _emit_headers(self, headers, emit):
        headers = {key.lower(): value for key, value in headers.items()}
        values = {entry["header"].lower(): headers.get(entry["header"].lower())
                  for entry in self.settings.usage_headers}
        emit("usage_headers", {"base_url": self.settings.base_url, "model": self.settings.model,
                               "values": values})

    def _consume(self, response, cancel, emit):
        if not self.settings.streaming:
            self._check_request(cancel)
            if getattr(response, 'model', None):
                emit('response_model', response.model)
            if not response.choices:
                raise AssistantError("MODEL_ERROR", "Server returned no completion choices.")
            if response.usage:
                emit("usage", response.usage.model_dump())
            choice = response.choices[0]
            if choice.finish_reason == "length":
                raise AssistantError("OUTPUT_LIMIT", "Model output was truncated; increase the output limit.")
            message = choice.message.model_dump(exclude_none=True)
            self._reasoning(message, emit)
            message = {k: v for k, v in message.items() if k in {"role", "content", "tool_calls"}}
            emit("text_delta", message.get("content") or "")
            return message
        with self._lock:
            self._stream = response
        content, calls, finish, model = [], {}, None, None
        try:
            for chunk in response:
                self._check_request(cancel)
                if model is None and getattr(chunk, 'model', None):
                    model = chunk.model
                    emit('response_model', model)
                if getattr(chunk, "usage", None):
                    emit("usage", chunk.usage.model_dump())
                if not chunk.choices:
                    continue
                choice = chunk.choices[0]
                finish = choice.finish_reason or finish
                delta = choice.delta
                self._reasoning(delta, emit)
                if delta.content:
                    content.append(delta.content)
                    emit("text_delta", delta.content)
                for tool in delta.tool_calls or []:
                    call = calls.setdefault(tool.index, {"id": "", "type": "function", "function": {"name": "", "arguments": ""}})
                    if tool.id:
                        call["id"] += tool.id
                    if tool.function:
                        call["function"]["name"] += tool.function.name or ""
                        call["function"]["arguments"] += tool.function.arguments or ""
            self._check_request(cancel)
            if finish == "length":
                raise AssistantError("OUTPUT_LIMIT", "Output was truncated; no tool calls were executed.")
            if finish is None:
                raise AssistantError("STREAM_INTERRUPTED", "Stream ended without a completion marker; no calls executed.")
            return {"role": "assistant", "content": "".join(content) or None,
                    **({"tool_calls": [calls[i] for i in sorted(calls)]} if calls else {})}
        finally:
            response.close()
            with self._lock:
                self._stream = None

    def _check_request(self, cancel):
        if cancel.is_set():
            raise AssistantError('CANCELLED', 'Stopped.')
        if self.request_deadline is not None and time.monotonic() >= self.request_deadline:
            raise AssistantError('TASK_LIMIT', 'Workflow deadline reached during model response.')

    @staticmethod
    def _reasoning(value, emit):
        # Only provider-labelled fields qualify. Do not infer reasoning from
        # phrases or parse <think> tags from ordinary answer/code text.
        for key in ("reasoning_content", "reasoning"):
            text = value.get(key) if isinstance(value, dict) else getattr(value, key, None)
            if isinstance(text, str) and text:
                emit("reasoning_delta", text)
                break

    def probe(self, cancel, emit=lambda *args: None):
        tool = {"type": "function", "function": {"name": "connection_echo", "description": "Return the requested test value.",
                "parameters": {"type": "object", "properties": {"value": {"type": "string"}}, "required": ["value"], "additionalProperties": False}}}
        messages = [{"role": "user", "content": "Call connection_echo with value SAKIR_CONNECTION_OK. Do not answer without calling it."}]
        reply = self.complete(messages, [tool], cancel, emit)
        calls = reply.get("tool_calls") or []
        if len(calls) != 1 or calls[0]["function"]["name"] != "connection_echo" or not calls[0].get("id"):
            raise AssistantError("TOOLS_UNSUPPORTED", "Model/server did not return a structured test tool call.")
        try:
            arguments = json.loads(calls[0]["function"]["arguments"])
        except (TypeError, ValueError) as exc:
            raise AssistantError("TOOLS_UNSUPPORTED", "Test tool arguments were invalid JSON.") from exc
        if arguments != {"value": "SAKIR_CONNECTION_OK"}:
            raise AssistantError("TOOLS_UNSUPPORTED", "Test tool arguments were incorrect.")
        messages.extend([reply, {"role": "tool", "tool_call_id": calls[0]["id"], "content": '{"result":"SAKIR_CONNECTION_OK"}'}])
        messages.append({"role": "user", "content": "Report the result of the tool in your final answer; do not call it again."})
        final = self.complete(messages, [], cancel, emit)
        if "SAKIR_CONNECTION_OK" not in (final.get("content") or ""):
            raise AssistantError("TOOLS_UNSUPPORTED", "Model did not consume the tool result correctly.")
        return {"base_url": self.settings.base_url, "model": self.settings.model,
                "tool_round_trip": True, "streaming": self.settings.streaming}
