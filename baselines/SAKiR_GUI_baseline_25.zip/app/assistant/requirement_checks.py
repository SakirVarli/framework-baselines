"""Small independent predicates selected during inspection, before authoring.

These establish explicit names/bindings/properties, not arbitrary program behavior.
"""
import ast
import json

from .task_context import layout_rows
from .tools import obj, STRING
from .policy import AssistantError


CHECK = obj({'requirement': STRING,
             'kind': {'type': 'string', 'enum': ['callback_exists', 'callback_binding', 'callback_return_literal', 'layout_property']},
             'target': STRING, 'property': STRING, 'expected': STRING, 'user_reference': STRING},
            ['requirement', 'kind', 'target', 'expected', 'user_reference'])


def accept(checks, task, request):
    keys = {r['key'] for r in task['requirements']}
    source = '\n'.join([request, task['source_text'], *[
        q['answer']['text'] for q in task['questions'] if q['status'] == 'answered' and q.get('answer')]])
    for row in checks:
        reference = row['user_reference']
        expected = row['expected']
        if row['kind'] in {'layout_property', 'callback_return_literal'}:
            try:
                parsed = json.loads(expected)
                if row['kind'] == 'layout_property' and isinstance(parsed, str):
                    expected = parsed
            except ValueError as exc:
                raise AssistantError('REQUIREMENT_CHECK', 'Expected values for property and literal return checks must be JSON.') from exc
            if row['kind'] == 'callback_return_literal':
                if not row['target'].isidentifier() or row['target'] not in source:
                    raise AssistantError('REQUIREMENT_CHECK', 'Literal return checks need a callback name present in the user request.')
                if type(parsed) not in (str, int, float, bool, type(None)):
                    raise AssistantError('REQUIREMENT_CHECK', 'Literal return checks need a scalar JSON value.')
                if isinstance(parsed, str):
                    expected = parsed
        elif not expected.isidentifier():
            raise AssistantError('REQUIREMENT_CHECK', 'Callback checks expect a Python function name such as export_data, not a sentence or return value.')
        spellings = [expected]
        if row['kind'] == 'callback_return_literal' and (parsed is None or type(parsed) is bool):
            spellings.append(repr(parsed))
        normalized = ''.join(reference.split())
        if (row['requirement'] not in keys or not reference.strip() or reference not in source
                or not any(''.join(value.split()) in normalized for value in spellings)):
            raise AssistantError('REQUIREMENT_CHECK', 'Checks must cite explicit user text containing the expected value.')
        if row['kind'] == 'layout_property' and not row.get('property'):
            raise AssistantError('REQUIREMENT_CHECK', 'Layout checks need a property name.')
    return checks


def verify(checks, proposal, snapshot):
    files = {e.path: e.content for e in proposal.edits}
    source = files.get('callbacks/callbacks.py', snapshot['callbacks']) or ''
    config_text = files.get('app/data/config.json')
    config = json.loads(config_text) if config_text else snapshot['config']
    rows = layout_rows({'config': config})
    functions = [n for n in ast.parse(source).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    results = []
    for row in checks:
        matches = [n for n in rows if row['target'] in (n.get('node_id'), n['selector'],
                   n['properties'].get('name'), n['properties'].get('instance'))]
        if row['kind'] == 'callback_exists':
            passed = sum(n.name == row['expected'] for n in functions) == 1
        elif row['kind'] == 'callback_return_literal':
            definitions = [n for n in functions if n.name == row['target']]
            passed = False
            if len(definitions) == 1 and isinstance(definitions[0], ast.FunctionDef):
                function = definitions[0]
                body = function.body[1:] if ast.get_docstring(function) is not None else function.body
                if not function.decorator_list and len(body) == 1 and isinstance(body[0], ast.Return):
                    try:
                        actual = ast.literal_eval(body[0].value)
                        expected = json.loads(row['expected'])
                        passed = type(actual) is type(expected) and actual == expected
                    except (ValueError, TypeError):
                        pass
        elif row['kind'] == 'callback_binding':
            passed = len(matches) == 1 and matches[0]['properties'].get('callback') == row['expected']
        else:
            passed = len(matches) == 1 and matches[0]['properties'].get(row['property']) == json.loads(row['expected'])
        results.append({'requirement': row['requirement'], 'kind': row['kind'], 'ok': passed,
                        'message': ('Verified ' if passed else 'Unmet explicit requirement: ') + row['user_reference']})
    return results
