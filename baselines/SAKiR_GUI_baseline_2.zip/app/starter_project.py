"""Neutral starter files for a new configuration-driven application.

The templates contain only framework-level names and empty application state.
Callers may preview :func:`starter_project_files` or write the bundle to an
empty directory with :func:`write_starter_project`.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path


def default_ui_config(*, title: str = "{short_name} Framework", phase: str = "baseline") -> dict:
    """Return a minimal branded schema-v2 window with a welcome page."""
    if phase not in {"baseline", "development"}:
        raise ValueError("phase must be 'baseline' or 'development'")
    return {
        "window": {
            "admin_password": None,
            "title": title,
            "icon": "app/favicon/app.ico",
            "theme": "light",
            "phase": phase,
            "version": "0.1.0",
            "app_version_release_notes": "Initial application version.",
            "build": 1,
            "baseline_number": 1,
        },
        "schemaVersion": 2,
        "layout": {
            "mode": "canvas",
            "designSize": [1200, 800],
            "resizeMode": "anchors",
            "snap": 8,
        },
        "widgets": [{
            "type": "tab_widget",
            "instance": "main_tabs",
            "pos": [0, 0, 1, 1],
            "bounds": [0, 0, 1200, 800],
            "anchors": ["left", "right", "top", "bottom"],
            "dock": "fill",
            "zIndex": 0,
            "tabPosition": "top",
            "tabTextOrientation": "native",
            "movable": False,
            "tooltip": "",
            "tabs": [{
                "name": "Home",
                "grid": [6, 4],
                "password": "",
                "layout": {
                    "mode": "canvas",
                    "designSize": [1200, 800],
                    "resizeMode": "anchors",
                    "snap": 8,
                },
                "widgets": [{
                    "type": "output",
                    "instance": "welcome_output",
                    "pos": [0, 0, 6, 4],
                    "bounds": [24, 24, 1152, 752],
                    "anchors": ["left", "right", "top", "bottom"],
                    "dock": "fill",
                    "zIndex": 0,
                    "height": None,
                    "width": None,
                    "output_kind": "html",
                    "df_row_height": None,
                    "df_column_width": None,
                    "df_auto_wrap": True,
                    "editable": False,
                    "dockable": False,
                    "bg": "#F4F7FB",
                    "fg": "#172033",
                    "save_to_file": False,
                    "tooltip": "Welcome to {full_name}",
                }],
            }],
        }],
    }


def default_callbacks_source() -> str:
    """Return the documented branded callback starter module."""
    return '''"""Default application callbacks for the configuration-driven GUI.

The framework imports this module after it has generated ``app.stubs`` from
the current UI and tool configuration.  Runtime APIs including ``display``,
``spawn_input``, ``Tools``, ``GlobalsBase``, ``LifecycleManager``, ``lazy``,
``global_value``, and ``async_global`` are supplied by that generated module.

Configured button callbacks normally use the name
``btn_<sanitized_button_name>_callback``.  Startup hooks run before the UI is
built, then the configured widgets are created, and finally
lazy/async declarations finish, and synchronous ``Globals.init_globals`` runs
in the Qt main thread. Reload and close hooks run for their corresponding
generation transitions. Callback bodies and marked regions may be customized;
the import, Globals base class, and ``init_globals`` signature marked
``DO NOT CHANGE`` are required by the runtime.  Globals survive soft reloads,
so initialization must be safe to run more than once.
"""

from app.branding import FULL_NAME, SHORT_NAME
from app.stubs import *  # DO NOT CHANGE: runtime-generated callback API


def _welcome_html():
    """Build the branded HTML shown by the default welcome output."""
    return f"""
    <div style="margin:36px auto; max-width:820px; padding:44px;
                background:#ffffff; border:1px solid #dbe4f0;
                border-radius:18px; color:#172033; text-align:center;">
      <div style="font-size:13px; font-weight:700; letter-spacing:2px;
                  color:#3f6fd8; text-transform:uppercase;">{FULL_NAME}</div>
      <h1 style="margin:18px 0 10px; font-size:38px; color:#14213d;">
        Welcome to {SHORT_NAME}
      </h1>
      <p style="margin:0 auto; max-width:620px; font-size:17px;
                line-height:1.65; color:#52627a;">
        Your configuration-driven workspace is ready. Review the built-in Help
        first, then use the Config Designer to shape the interface and add
        application behavior in callbacks.py.
      </p>
      <div style="margin-top:30px; padding:16px 20px; background:#eef4ff;
                  border-radius:10px; color:#315aa8; font-size:14px;">
        Start with <b>Help &rarr; Help Contents</b> or press <b>F1</b>.<br><br>
        When ready, open <b>File &rarr; Config Designer...</b>
      </div>
    </div>
    """


# === DEFAULT GLOBALS: edit declarations and initialization body as needed. ===
class Globals(GlobalsBase):  # DO NOT CHANGE: required reload-safe base class
    """Shared reload-safe application state."""

    # --- EDITABLE: class-level values are available before startup hooks. ---
    counter = 0

    def init_globals(self):  # DO NOT CHANGE: called after the UI is built
        """Populate UI-dependent globals in the Qt main thread."""
        # --- EDITABLE: keep this method quick and safe to run after reload. ---
        display("welcome_output", _welcome_html(), mode="replace")


@LifecycleManager.on_startup(priority=0)
def application_starting(window):
    """Perform quick non-UI validation before the configured UI is built."""
    # --- EDITABLE: UI widgets are not available at this lifecycle stage. ---
    pass


@LifecycleManager.on_unload(priority=0)
def application_unloading(window):
    """Release callback-generation wiring before a soft reload."""
    pass


@LifecycleManager.on_reload(priority=0)
def application_reloaded(window):
    """Run after the replacement callback generation becomes initialized."""
    pass


@LifecycleManager.on_close(priority=0)
def application_closing(event=None):
    """Release application-owned resources without blocking shutdown."""
    # --- EDITABLE: make cleanup fast and safe to call more than once. ---
    pass
'''


def default_externals_source() -> str:
    """Return neutral external functions suitable for callback imports."""
    return '''"""Application-specific code kept outside callbacks.py.

Keep functions independent of Qt when possible.  callbacks.py may import these
functions with ``from externals.helpers import ...``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_json_records(path: str | Path) -> list[dict[str, Any]]:
    """Load and validate a JSON list of objects."""
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, list) or not all(isinstance(row, dict) for row in value):
        raise ValueError("Expected a JSON array of objects")
    return value


def parse_message(payload: bytes, context: dict | None = None) -> dict[str, Any]:
    """Communication Hub parser example: decode one JSON message."""
    data = json.loads(payload.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object")
    return {"Name": str(data.get("type", "Message")), **data}


def process_insight_value(value: Any, context: dict | None = None) -> Any:
    """Protocol Insight processor example: normalize a numeric value."""
    return None if value is None else float(value)
'''


def default_tool_settings() -> dict[str, object]:
    """Return clean persisted settings for the built-in tool windows."""
    return {
        "ftp_client.json": {},
        "ftp_server.json": {"users": []},
        "serial.json": {"sessions": [], "selected_index": -1},
        "telnet.json": {"sessions": [], "selected_index": -1},
        "communication_hub.json": {
            "schema_version": 1,
            "sessions": [],
            "selected_session_id": "",
            "saved_messages": [],
            "saved_queries": [],
            "periodic_messages": [],
            "protocol_insights": [],
        },
    }


def starter_project_files(*, title: str = "{short_name} Framework", phase: str = "baseline") -> dict[str, str]:
    """Return relative paths and UTF-8 text without touching the filesystem."""
    files = {
        "app/data/config.json": json.dumps(
            default_ui_config(title=title, phase=phase), indent=2, ensure_ascii=False
        ) + "\n",
        "callbacks/callbacks.py": default_callbacks_source(),
        "externals/__init__.py": '"""Application-specific reusable modules."""\n',
        "externals/helpers.py": default_externals_source(),
    }
    for name, value in default_tool_settings().items():
        files[f"app/data/{name}"] = json.dumps(value, indent=2, ensure_ascii=False) + "\n"
    return copy.deepcopy(files)


def write_starter_project(
    destination: str | Path,
    *,
    title: str = "{short_name} Framework",
    phase: str = "baseline",
    overwrite: bool = False,
) -> list[Path]:
    """Write starter files, refusing to replace files unless explicitly allowed."""
    root = Path(destination).resolve()
    files = starter_project_files(title=title, phase=phase)
    targets = [(root / relative).resolve() for relative in files]
    if any(root != target and root not in target.parents for target in targets):
        raise ValueError("A starter path escaped the destination directory")
    existing = [target for target in targets if target.exists()]
    if existing and not overwrite:
        names = ", ".join(str(path.relative_to(root)) for path in existing)
        raise FileExistsError(f"Refusing to overwrite existing starter files: {names}")
    for (relative, content), target in zip(files.items(), targets):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return targets


__all__ = [
    "default_ui_config",
    "default_callbacks_source",
    "default_externals_source",
    "default_tool_settings",
    "starter_project_files",
    "write_starter_project",
]
