from PyQt5 import QtCore, QtGui, QtWidgets

from app.utils import sanitize_func_name
from .callback_manager import available_callback_symbols
from .commands import PropertyCommand
from .parsing import PropertyParseError, parse_property
from .schema import FEATURES


CATEGORY_ORDER = ["Identity", "Layout", "Appearance", "Behavior", "Data/output", "Security", "Events"]
INTERNAL_LAYOUT_PROPERTIES = {"layout.mode", "grid", "pos"}


class PropertyInspector(QtWidgets.QScrollArea):
    openCallbackRequested = QtCore.pyqtSignal(str)

    def __init__(self, document, undo_stack, callback_source_getter=None, parent=None):
        super().__init__(parent)
        self.document, self.undo_stack = document, undo_stack
        self.callback_source_getter = callback_source_getter
        self.setWidgetResizable(True)
        self.host = QtWidgets.QWidget()
        self.layout = QtWidgets.QVBoxLayout(self.host)
        self.layout.setContentsMargins(6, 6, 6, 6)
        self.setWidget(self.host)
        self.document.on_change(self._document_changed)
        self.rebuild()

    def _clear(self):
        while self.layout.count():
            item = self.layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def rebuild(self):
        self._clear()
        nodes = [self.document.find(node_id) for node_id in self.document.selected_ids]
        nodes = [node for node in nodes if node]
        if not nodes:
            label = QtWidgets.QLabel("Select an item to edit its properties.")
            label.setWordWrap(True)
            label.setProperty("muted", True)
            self.layout.addWidget(label)
            self.layout.addStretch()
            return
        node_type = nodes[0].node_type
        if any(node.node_type != node_type for node in nodes):
            self.layout.addWidget(QtWidgets.QLabel("Select items of the same type for multi-edit."))
            self.layout.addStretch()
            return
        schema = FEATURES.get(node_type, {})
        by_category = {}
        for key, meta in schema.items():
            # These fields remain in the schema solely for migration and
            # backward compatibility. The editor exposes one canvas workflow.
            if key in INTERNAL_LAYOUT_PROPERTIES:
                continue
            by_category.setdefault(meta.get("category", "Appearance"), []).append((key, meta))
        for category in CATEGORY_ORDER:
            entries = by_category.get(category)
            if not entries:
                continue
            group = QtWidgets.QGroupBox(category)
            form = QtWidgets.QFormLayout(group)
            for key, meta in entries:
                values = [
                    (node.properties.get("callback") or
                     sanitize_func_name(node.properties.get("name", "")))
                    if key == "callback"
                    else node.get_property(key, meta.get("default"))
                    for node in nodes
                ]
                shared = values[0] if all(value == values[0] for value in values) else None
                editor = self._make_editor(key, meta, shared, nodes)
                help_text = meta.get("help") or self._default_help(key, meta)
                invalid_value = editor.property("invalidConfigValue")
                editor.setToolTip(
                    f"Invalid imported value: {invalid_value}. Enter a whole number.\n\n{help_text}"
                    if invalid_value is not None else help_text)
                form.addRow(meta["label"], editor)
            self.layout.addWidget(group)
        self.layout.addStretch()

    def _make_editor(self, key, meta, value, nodes):
        kind = meta["type"]
        if kind == "bool":
            editor = QtWidgets.QCheckBox()
            editor.setTristate(value is None)
            editor.setCheckState(QtCore.Qt.PartiallyChecked if value is None else
                                 QtCore.Qt.Checked if value else QtCore.Qt.Unchecked)
            editor.stateChanged.connect(lambda state: self._commit(
                nodes, key, kind, state == QtCore.Qt.Checked, editor))
            return editor
        if kind == "combo":
            editor = QtWidgets.QComboBox()
            editor.addItems(meta.get("options", []))
            editor.setCurrentText("" if value is None else str(value))
            editor.currentTextChanged.connect(lambda text: self._commit(nodes, key, kind, text, editor))
            return editor
        if kind == "readonly":
            editor = QtWidgets.QLineEdit(str(value or ""))
            editor.setReadOnly(True)
            return editor
        if kind == "int":
            editor = QtWidgets.QSpinBox()
            editor.setRange(-1, 100000)
            editor.setSpecialValueText("(not set)")
            if value is None:
                editor.setValue(-1)
            elif isinstance(value, int) and not isinstance(value, bool):
                editor.setValue(value)
            else:
                editor.setValue(-1)
                editor.setProperty("invalidConfigValue", repr(value))
                editor.setStyleSheet("border: 1px solid #d9534f;")
            editor.editingFinished.connect(lambda: self._commit(
                nodes, key, kind, "" if editor.value() < 0 else editor.value(), editor))
            return editor
        if kind == "shortcut":
            editor = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(str(value or "")))
            editor.editingFinished.connect(lambda: self._commit(
                nodes, key, kind, editor.keySequence().toString(), editor))
            return editor
        if kind == "callback":
            return self._make_callback_selector(key, kind, value, nodes)
        editor = QtWidgets.QLineEdit()
        if isinstance(value, list):
            editor.setText(",".join(map(str, value)))
        elif value is not None:
            editor.setText(str(value))
        elif len(nodes) > 1:
            editor.setPlaceholderText("(multiple values)")
        if kind == "password":
            editor.setEchoMode(QtWidgets.QLineEdit.Password)
        editor.editingFinished.connect(lambda: self._commit(nodes, key, kind, editor.text(), editor))
        if kind in {"color", "file", "font", "password"}:
            host = QtWidgets.QWidget()
            row = QtWidgets.QHBoxLayout(host)
            row.setContentsMargins(0, 0, 0, 0)
            row.addWidget(editor)
            button = QtWidgets.QToolButton()
            if kind == "color":
                button.setText("…")
                button.clicked.connect(lambda: self._pick_color(editor))
            elif kind == "file":
                button.setText("…")
                button.clicked.connect(lambda: self._pick_file(editor, meta.get("filter", "All files (*)")))
            elif kind == "font":
                button.setText("A")
                button.clicked.connect(lambda: self._pick_font(editor))
            else:
                button.setText("Show")
                button.setCheckable(True)
                button.toggled.connect(lambda shown: editor.setEchoMode(
                    QtWidgets.QLineEdit.Normal if shown else QtWidgets.QLineEdit.Password))
            row.addWidget(button)
            return host
        return editor

    def _make_callback_selector(self, key, kind, value, nodes):
        available = []
        source_error = False
        if self.callback_source_getter:
            try:
                available = sorted(available_callback_symbols(
                    self.callback_source_getter()))
            except Exception:
                source_error = True

        host = QtWidgets.QWidget()
        column = QtWidgets.QVBoxLayout(host)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(3)
        row = QtWidgets.QHBoxLayout()
        selector = QtWidgets.QComboBox()
        selector.setObjectName("callbackSelector")
        selector.setEditable(True)
        selector.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        selector.addItems(available)
        selector.setCurrentText("" if value is None else str(value))
        selector.setToolTip(
            "Select an existing top-level function from callbacks.py or type a new callback name.")
        selector.lineEdit().setPlaceholderText(
            "(multiple callback names)" if value is None else "Callback function")
        selector.lineEdit().editingFinished.connect(lambda: self._commit(
            nodes, key, kind, selector.currentText().strip(), selector))
        selector.activated[str].connect(lambda text: self._commit(
            nodes, key, kind, text.strip(), selector))
        row.addWidget(selector)
        button = QtWidgets.QToolButton()
        button.setText("Open")
        button.setToolTip("Open the selected callback in the embedded IDE")
        button.clicked.connect(lambda: self.openCallbackRequested.emit(
            selector.currentText().strip()))
        row.addWidget(button)
        column.addLayout(row)

        status = QtWidgets.QLabel()
        status.setWordWrap(True)
        status.setProperty("callbackStatus", True)
        status.setToolTip(
            "Changing the callback assignment creates a new function on Save if it is missing. "
            "Existing Python functions are never renamed or deleted automatically.")
        if value is None:
            status.setText("Multiple callback names selected.")
            status.setStyleSheet("color: #687787;")
        elif not self.callback_source_getter:
            status.setText("Callback status unavailable.")
            status.setStyleSheet("color: #687787;")
        elif source_error:
            status.setText("Callback status unavailable — callbacks.py is malformed")
            status.setStyleSheet("color: #b42318;")
        elif str(value) in available:
            status.setText("Existing function in callbacks.py")
            status.setStyleSheet("color: #287a3d;")
        else:
            status.setText("Missing — a new function will be generated on Save")
            status.setStyleSheet("color: #9a6700;")
        column.addWidget(status)
        return host

    def _pick_color(self, editor):
        color = QtWidgets.QColorDialog.getColor(QtGui.QColor(editor.text()), self)
        if color.isValid():
            editor.setText(color.name())
            editor.editingFinished.emit()

    def _pick_file(self, editor, file_filter):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select file", editor.text(), file_filter)
        if path:
            editor.setText(path)
            editor.editingFinished.emit()

    def _pick_font(self, editor):
        font, accepted = QtWidgets.QFontDialog.getFont(QtGui.QFont(editor.text()), self)
        if accepted:
            editor.setText(font.family())
            editor.editingFinished.emit()

    def _commit(self, nodes, key, kind, raw, editor):
        try:
            value = parse_property(kind, raw)
        except PropertyParseError as error:
            editor.setStyleSheet("border: 1px solid #d9534f;")
            editor.setToolTip(str(error))
            return
        editor.setStyleSheet("")
        editor.setToolTip("")
        if key == "callback":
            current_values = [
                node.properties.get("callback") or
                sanitize_func_name(node.properties.get("name", ""))
                for node in nodes
            ]
        else:
            current_values = [node.get_property(key) for node in nodes]
        if all(current == value for current in current_values):
            return
        self.undo_stack.push(PropertyCommand(
            self.document, [node.node_id for node in nodes], key, value))

    @staticmethod
    def _default_help(key, meta):
        descriptions = {
            "bounds": "Exact X, Y, width and height relative to the parent canvas.",
            "anchors": "Comma-separated parent edges: left, right, top, bottom.",
            "dock": "Dock the control to an edge or fill its parent.",
            "zIndex": "Controls with a higher z-order are drawn in front.",
            "pos": "Grid row, column, row span and column span.",
            "grid": "Number of rows and columns in this container.",
            "callback": "Python function called when this button is clicked.",
        }
        return descriptions.get(key, meta.get("label", ""))

    def _document_changed(self, reason, node):
        if reason in {"selection", "add", "remove", "reparent", "revert", "replace", "property"}:
            self.rebuild()
