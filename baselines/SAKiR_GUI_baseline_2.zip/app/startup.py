import sys
from pathlib import Path
from PyQt5 import QtWidgets, QtGui, QtCore
from multiprocessing.connection import Connection
import math

from app.branding import FULL_NAME, SHORT_NAME, application_id


APP_USER_MODEL_ID = application_id("main")
APP_ICON_PATH = Path(__file__).resolve().parent / "favicon" / "app.ico"


def load_app_icon() -> QtGui.QIcon:
    if APP_ICON_PATH.exists():
        return QtGui.QIcon(str(APP_ICON_PATH))
    return QtGui.QIcon()


def apply_app_icon(window=None, native: bool = True) -> None:
    icon = load_app_icon()
    app = QtWidgets.QApplication.instance()
    if app is not None:
        app.setWindowIcon(icon)
    if window is not None:
        window.setWindowIcon(icon)
        if native and sys.platform.startswith("win") and APP_ICON_PATH.exists():
            try:
                import ctypes
                from ctypes import wintypes
                hwnd = int(window.winId())
                icon_path = str(APP_ICON_PATH)
                load_image = ctypes.windll.user32.LoadImageW
                send_message = ctypes.windll.user32.SendMessageW
                load_image.argtypes = [
                    wintypes.HINSTANCE,
                    wintypes.LPCWSTR,
                    wintypes.UINT,
                    ctypes.c_int,
                    ctypes.c_int,
                    wintypes.UINT,
                ]
                load_image.restype = wintypes.HANDLE
                send_message.argtypes = [
                    wintypes.HWND,
                    wintypes.UINT,
                    wintypes.WPARAM,
                    wintypes.LPARAM,
                ]
                send_message.restype = wintypes.LPARAM
                image_icon = 1
                lr_loadfromfile = 0x0010
                lr_defaultsize = 0x0040
                wm_seticon = 0x0080
                icon_small = 0
                icon_big = 1
                icon_small2 = 2
                big_icon = load_image(
                    None, icon_path, image_icon, 32, 32,
                    lr_loadfromfile
                )
                small_icon = load_image(
                    None, icon_path, image_icon, 16, 16,
                    lr_loadfromfile
                )
                small2_icon = load_image(
                    None, icon_path, image_icon, 24, 24,
                    lr_loadfromfile
                )
                if big_icon:
                    send_message(hwnd, wm_seticon, icon_big, big_icon)
                if small_icon:
                    send_message(hwnd, wm_seticon, icon_small, small_icon)
                if small2_icon:
                    send_message(hwnd, wm_seticon, icon_small2, small2_icon)
            except Exception:
                pass


def set_windows_app_id() -> None:
    if not sys.platform.startswith("win"):
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            APP_USER_MODEL_ID
        )
    except Exception:
        pass

# ============================================================
# ✅ PURE QT SPINNER (OPTIMIZED, SMOOTH)
# ============================================================
class QtSpinner(QtWidgets.QWidget):
    def __init__(self, size=64, line_width=4, parent=None):
        super().__init__(parent)

        self._angle = 0
        self._size = size
        self._line_width = line_width

        self.setFixedSize(size, size)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        base_color = QtGui.QColor(160, 170, 180)
        self._colors = []
        for i in range(8):
            c = QtGui.QColor(base_color)
            c.setAlphaF((i + 1) / 8.0)
            self._colors.append(c)

        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self.rotate)
        self._timer.start(33)  # ~30 FPS

    def rotate(self):
        self._angle = (self._angle + 12) % 360
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)

        rect = self.rect()
        radius = int(min(rect.width(), rect.height()) / 2 - self._line_width)
        center = rect.center()

        for i in range(8):
            pen = QtGui.QPen(
                self._colors[i],
                self._line_width,
                QtCore.Qt.SolidLine,
                QtCore.Qt.RoundCap
            )
            painter.setPen(pen)

            angle = self._angle - i * 45
            painter.save()
            painter.translate(center)
            painter.rotate(angle)

            painter.drawLine(
                0,
                -radius,
                0,
                -radius // 2
            )

            painter.restore()

class QtWin11Spinner(QtWidgets.QWidget):
    """
    Windows 11 spinner:
    - Head rotates forward continuously (unwrapped)
    - Tail chases with elastic lag (unwrapped)
    - Chase distance oscillates (real shrink/expand)
    - No fading
    - No CCW reversal bug
    """

    def __init__(self, size=64, line_width=4, speed=4.0, parent=None):
        super().__init__(parent)

        self._size = size
        self._line_width = line_width
        self._speed = speed

        self._head_angle = 0.0       # unwrapped
        self._tail_angle = -90.0     # unwrapped behind head
        self._phase = 0.0            # controls stretch

        self.setFixedSize(size, size)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        self._color = QtGui.QColor(160, 170, 180)

        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)  # ~60 FPS

    def _tick(self):
        # ✅ Head always moves forward (never wraps)
        self._head_angle += self._speed

        # ✅ Dynamic chase distance (THIS creates real shrink)
        self._phase += 0.05
        min_dist = 1
        max_dist = 140
        chase_dist = min_dist + (math.sin(self._phase) + 1) / 2 * (max_dist - min_dist)

        # ✅ Tail always chases forward (never wraps)
        target = self._head_angle - chase_dist
        self._tail_angle += (target - self._tail_angle) * 0.12

        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)

        rect = self.rect()
        radius = int(min(rect.width(), rect.height()) / 2 - self._line_width)
        center = rect.center()

        painter.translate(center)

        pen = QtGui.QPen(self._color, self._line_width)
        pen.setCapStyle(QtCore.Qt.RoundCap)
        painter.setPen(pen)

        # ✅ Wrap ONLY for drawing
        head = self._head_angle % 360
        tail = self._tail_angle % 360
        span = (head - tail) % 360

        painter.drawArc(
            -radius, -radius,
            radius * 2, radius * 2,
            int(-tail * 16),
            int(-span * 16)
        )

# ============================================================
# ✅ LIGHT THEME STARTUP LOADER (WITH PROGRESS + FADE)
# ============================================================
class StartupLoader(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.head_angle = 0.0
        self.phase = 0.0
        self.setWindowTitle(f"{SHORT_NAME} Startup")
        self.setWindowIcon(load_app_icon())
        self.setWindowFlags(
            QtCore.Qt.FramelessWindowHint |
            QtCore.Qt.WindowStaysOnTopHint |
            QtCore.Qt.CustomizeWindowHint
        )
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setFixedSize(460, 300)

        self._container = QtWidgets.QFrame()
        self._container.setStyleSheet("""
            QFrame {
                background-color: #f7f9fb;
                border-radius: 16px;
                border: 1px solid #d6dbe0;
            }
        """)

        shadow = QtWidgets.QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(32)
        shadow.setXOffset(0)
        shadow.setYOffset(8)
        shadow.setColor(QtGui.QColor(0, 0, 0, 60))
        self._container.setGraphicsEffect(shadow)

        layout = QtWidgets.QVBoxLayout(self._container)
        layout.setAlignment(QtCore.Qt.AlignCenter)
        layout.setSpacing(14)

        self.title = QtWidgets.QLabel(FULL_NAME)
        self.title.setStyleSheet("""
            QLabel {
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
                color: #2c3e50;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.title)

        # ✅ CENTERED SPINNER + OVERLAID PERCENT
        spinner_stack = QtWidgets.QStackedLayout()
        spinner_stack.setStackingMode(QtWidgets.QStackedLayout.StackAll)

        self.spinner = QtWin11Spinner(48, 4)

        spinner_stack.addWidget(self.spinner)

        spinner_wrap = QtWidgets.QWidget()
        spinner_wrap.setLayout(spinner_stack)

        layout.addWidget(spinner_wrap, alignment=QtCore.Qt.AlignCenter)

        self.status = QtWidgets.QLabel("Initializing, please wait...")
        self.status.setStyleSheet("""
            QLabel {
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
                color: #5f6f81;
                font-size: 13px;
            }
        """)
        self.status.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(self.status)

        self.footer = QtWidgets.QLabel(r"© 2025 sakirvarli. All rights reserved.")
        self.footer.setStyleSheet("""
            QLabel {
                background: transparent;
                border: none;
                padding-top: 24px;
                margin: 0px;
                color: #5f6f81;
                font-size: 8px;
            }
        """)
        # self.footer.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(self.footer)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(24, 24, 24, 24)
        root.addWidget(self._container)

        # ✅ FADE IN
        self._fade_in = QtCore.QPropertyAnimation(self, b"windowOpacity")
        self._fade_in.setDuration(300)
        self._fade_in.setStartValue(0)
        self._fade_in.setEndValue(1)

        # ✅ FADE OUT
        self._fade_out = QtCore.QPropertyAnimation(self, b"windowOpacity")
        self._fade_out.setDuration(450)
        self._fade_out.setStartValue(1)
        self._fade_out.setEndValue(0)
        self._fade_out.finished.connect(self.close)

        self.angle = 0

    def center(self):
        screen = QtWidgets.QApplication.primaryScreen().geometry()
        self.move(
            screen.center().x() - self.width() // 2,
            screen.center().y() - self.height() // 2,
        )

    def show_with_fade(self):
        self.setWindowOpacity(0)
        self.center()
        self.show()
        self._fade_in.start()

    def update_progress(self, text):
        self.status.setText(text)

    def close_with_fade(self):
        self._fade_out.start()

    def generate_win11_spinner_icon(self, size=32, line_width=3, phase=0.0, head_angle=40.0):
        """
        Generate a static Win11-style spinner icon.
        - Unwrapped head/tail logic
        - Real shrink/expand span
        - No fading
        - Rounded caps
        """

        pix = QtGui.QPixmap(size, size)
        pix.fill(QtCore.Qt.transparent)

        p = QtGui.QPainter(pix)
        p.setRenderHint(QtGui.QPainter.Antialiasing)

        # === Optional rounded window background (comment out if not needed)
        bg_rect = QtCore.QRectF(1, 1, size - 2, size - 2)
        p.setBrush(QtGui.QColor(35, 35, 40))
        p.setPen(QtGui.QPen(QtGui.QColor(80, 80, 90), 1.2))
        p.drawRoundedRect(bg_rect, 5, 5)

        # === Spinner geometry
        center = QtCore.QPointF(size / 2, size / 2)
        radius = size * 0.32

        p.translate(center)

        color = QtGui.QColor(160, 170, 180)
        pen = QtGui.QPen(color, line_width)
        pen.setCapStyle(QtCore.Qt.RoundCap)
        p.setPen(pen)
        p.setBrush(QtCore.Qt.NoBrush)

        # === EXACT same math as widget ===
        min_dist = 1
        max_dist = 140
        chase_dist = min_dist + (math.sin(phase) + 1) / 2 * (max_dist - min_dist)

        head = head_angle
        tail = head - chase_dist

        # Wrap ONLY for drawing
        head_w = head % 360
        tail_w = tail % 360
        span = (head_w - tail_w) % 360

        arc_rect = QtCore.QRectF(
            -radius, -radius,
            radius * 2, radius * 2
        )

        p.drawArc(
            arc_rect,
            int(-tail_w * 16),
            int(-span * 16)
        )

        p.end()
        return QtGui.QIcon(pix)

    def update_icon(self):
        # Win11-style motion
        self.head_angle += 10.0     # CW rotation speed
        self.phase += 0.1         # stretch / shrink speed

        icon = self.generate_win11_spinner_icon(
            size=32,
            line_width=3,
            phase=self.phase,
            head_angle=self.head_angle
        )

        # Keep this generated spinner out of QApplication/window icons.
        # Windows may cache a temporary icon for the taskbar group.

class LoaderController(QtCore.QObject):
    def __init__(self, pipe: Connection):
        super().__init__()
        self.pipe = pipe

        self.loader = StartupLoader()
        self.loader.show_with_fade()

        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.check_pipe)
        self.timer.start(50)

    def check_pipe(self):
        if not self.pipe.closed:
            if self.pipe.poll():
                msg = self.pipe.recv()

                if msg == "CLOSE":
                    self.pipe.close()  # ✅ CLOSE PIPE FIRST
                    self.loader.close_with_fade()

                    # ✅ Quit AFTER animation ends
                    QtCore.QTimer.singleShot(
                        500,
                        QtWidgets.QApplication.instance().quit
                    )
                
                if msg == "CRASHED": 
                    self.loader._container.setStyleSheet("""
                        QFrame {
                            background-color: #ca3939;
                            border-radius: 16px;
                            border: 1px solid #ab1c1c;
                        }
                    """)
                    self.loader.status.setText("App CRASHED unfortunately, closing...")
                    self.pipe.close()  # ✅ CLOSE PIPE FIRST
                    self.loader.close_with_fade()                

                    # ✅ Quit AFTER animation ends
                    QtCore.QTimer.singleShot(
                        500,
                        QtWidgets.QApplication.instance().quit
                    )


def run_loader(pipe: Connection):
    set_windows_app_id()
    app = QtWidgets.QApplication(sys.argv)
    apply_app_icon()
    controller = LoaderController(pipe)
    sys.exit(app.exec_())
