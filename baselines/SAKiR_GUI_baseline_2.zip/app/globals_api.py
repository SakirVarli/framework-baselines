"""Declarative, reload-aware API layered over :mod:`app.global_store`."""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Any, Callable, Dict, Optional

from PyQt5 import QtCore

from app.global_store import (
    AppGlobalDefinitionError,
    AppGlobals,
    RESERVED_GLOBAL_NAMES,
    validate_global_name,
)


class ReloadPolicy(str, Enum):
    PRESERVE = "preserve"
    RECREATE = "recreate"


def _reload_policy(value: str | ReloadPolicy, default: ReloadPolicy) -> ReloadPolicy:
    if value is None:
        return default
    try:
        return ReloadPolicy(value)
    except (TypeError, ValueError) as error:
        raise AppGlobalDefinitionError(
            f"Invalid reload policy {value!r}; expected 'preserve' or 'recreate'."
        ) from error


@dataclass(frozen=True)
class GlobalValue:
    value: Any
    label: str = ""
    reload: ReloadPolicy = ReloadPolicy.PRESERVE
    dispose: Optional[Callable[[Any], Any]] = None


@dataclass(frozen=True)
class Lazy:
    factory: Callable[[], Any]
    label: str = ""
    reload: ReloadPolicy = ReloadPolicy.RECREATE
    dispose: Optional[Callable[[Any], Any]] = None


@dataclass(frozen=True)
class AsyncLazy:
    factory: Callable[[], Any]
    label: str = ""
    reload: ReloadPolicy = ReloadPolicy.PRESERVE
    dispose: Optional[Callable[[Any], Any]] = None
    timeout: Optional[float] = None


@dataclass(frozen=True)
class GlobalSpec:
    """Normalized declaration retained on the declaring Globals subclass."""

    kind: str
    value: Any = None
    factory: Optional[Callable[[], Any]] = None
    label: str = ""
    reload: ReloadPolicy = ReloadPolicy.PRESERVE
    dispose: Optional[Callable[[Any], Any]] = None
    timeout: Optional[float] = None


def global_value(
    value: Any,
    *,
    label: str = "",
    reload: str | ReloadPolicy = ReloadPolicy.PRESERVE,
    dispose: Optional[Callable[[Any], Any]] = None,
) -> GlobalValue:
    """Declare explicit process-local state with reload/disposal metadata."""
    if dispose is not None and not callable(dispose):
        raise TypeError("dispose must be callable or None")
    return GlobalValue(
        value=value,
        label=str(label or ""),
        reload=_reload_policy(reload, ReloadPolicy.PRESERVE),
        dispose=dispose,
    )


def lazy(
    factory: Callable[[], Any],
    label: str = "",
    *,
    reload: str | ReloadPolicy = ReloadPolicy.RECREATE,
    dispose: Optional[Callable[[Any], Any]] = None,
) -> Lazy:
    """Declare a main-thread value created after the configured UI is built."""
    if not callable(factory):
        raise TypeError("lazy factory must be callable")
    if dispose is not None and not callable(dispose):
        raise TypeError("dispose must be callable or None")
    return Lazy(
        factory=factory,
        label=str(label or ""),
        reload=_reload_policy(reload, ReloadPolicy.RECREATE),
        dispose=dispose,
    )


def async_global(
    factory: Callable[[], Any],
    label: str = "",
    *,
    reload: str | ReloadPolicy = ReloadPolicy.PRESERVE,
    dispose: Optional[Callable[[Any], Any]] = None,
    timeout: Optional[float] = None,
) -> AsyncLazy:
    """Declare a non-Qt value initialized on a worker-owned asyncio loop."""
    if not callable(factory):
        raise TypeError("async_global factory must be callable")
    if dispose is not None and not callable(dispose):
        raise TypeError("dispose must be callable or None")
    if timeout is not None and timeout <= 0:
        raise ValueError("timeout must be greater than zero")
    return AsyncLazy(
        factory=factory,
        label=str(label or ""),
        reload=_reload_policy(reload, ReloadPolicy.PRESERVE),
        dispose=dispose,
        timeout=float(timeout) if timeout is not None else None,
    )


def _is_qt_object(value: Any) -> bool:
    try:
        return isinstance(value, QtCore.QObject)
    except Exception:
        return False


def _looks_like_widgetish(value: Any) -> bool:
    if _is_qt_object(value):
        return True
    try:
        widget = getattr(value, "widget", None)
    except Exception:
        return False
    return widget is not None and _is_qt_object(widget)


def _normalize_declaration(value: Any) -> GlobalSpec:
    if isinstance(value, GlobalValue):
        return GlobalSpec(
            kind="plain", value=value.value, label=value.label,
            reload=value.reload, dispose=value.dispose,
        )
    if isinstance(value, Lazy):
        return GlobalSpec(
            kind="lazy", factory=value.factory, label=value.label,
            reload=value.reload, dispose=value.dispose,
        )
    if isinstance(value, AsyncLazy):
        return GlobalSpec(
            kind="async", factory=value.factory, label=value.label,
            reload=value.reload, dispose=value.dispose, timeout=value.timeout,
        )
    return GlobalSpec(kind="plain", value=value, reload=ReloadPolicy.PRESERVE)


class _GlobalsMeta(type):
    def __new__(mcls, name: str, bases: tuple[type, ...], namespace: Dict[str, Any]):
        framework_base = not bases
        definitions: Dict[str, GlobalSpec] = {}
        for base in bases:
            definitions.update(dict(base.__dict__.get("_definitions", {})))

        for key, value in list(namespace.items()):
            if key.startswith("__") and key.endswith("__"):
                if (
                    not framework_base
                    and key not in {
                        "__module__", "__qualname__", "__doc__",
                        "__annotations__", "__classcell__", "__firstlineno__",
                        "__static_attributes__", "__classdictcell__",
                    }
                ):
                    raise AppGlobalDefinitionError(
                        f"Globals member {key!r} is reserved by the framework."
                    )
                continue
            if not framework_base and key in RESERVED_GLOBAL_NAMES and key != "init_globals":
                validate_global_name(key)
            if key.startswith("_"):
                if (
                    inspect.isfunction(value)
                    or inspect.ismethod(value)
                    or isinstance(value, (classmethod, staticmethod, property))
                ):
                    continue
                validate_global_name(key)
            if (
                inspect.isfunction(value)
                or inspect.ismethod(value)
                or isinstance(value, (classmethod, staticmethod, property))
            ):
                continue
            validate_global_name(key)
            if _looks_like_widgetish(value):
                raise AppGlobalDefinitionError(
                    f"Illegal eager global {key!r} of type {type(value).__name__}. "
                    "Qt objects must be declared with lazy(lambda: ...)."
                )
            if inspect.iscoroutine(value):
                try:
                    value.close()
                except Exception:
                    pass
                raise AppGlobalDefinitionError(
                    f"Illegal coroutine object {key!r}; use async_global(async_factory)."
                )
            spec = _normalize_declaration(value)
            if spec.kind == "plain" and _looks_like_widgetish(spec.value):
                raise AppGlobalDefinitionError(
                    f"Illegal eager global {key!r} of type "
                    f"{type(spec.value).__name__}. Qt objects must be declared "
                    "with lazy(lambda: ...)."
                )
            definitions[key] = spec
            namespace.pop(key)

        namespace["_definitions"] = MappingProxyType(definitions)
        return super().__new__(mcls, name, bases, namespace)

    def __getattr__(cls, name: str) -> Any:
        return getattr(AppGlobals, name)

    def __setattr__(cls, name: str, value: Any) -> None:
        validate_global_name(name)
        setattr(AppGlobals, name, value)

    def __delattr__(cls, name: str) -> None:
        validate_global_name(name)
        delattr(AppGlobals, name)

    def __getitem__(cls, key: str) -> Any:
        return AppGlobals[key]

    def __setitem__(cls, key: str, value: Any) -> None:
        AppGlobals[key] = value

    def __delitem__(cls, key: str) -> None:
        del AppGlobals[key]

    def __contains__(cls, key: object) -> bool:
        return key in AppGlobals

    def keys(cls): return AppGlobals.keys()
    def values(cls): return AppGlobals.values()
    def items(cls): return AppGlobals.items()
    def get(cls, key, default=None): return AppGlobals.get(key, default)
    def pop(cls, key, *default): return AppGlobals.pop(key, *default)
    def setdefault(cls, key, default=None): return AppGlobals.setdefault(key, default)
    def update(cls, values): return AppGlobals.update(values)
    def clear(cls): return AppGlobals.clear()
    def snapshot(cls): return AppGlobals.snapshot()
    def mutate(cls, key, operation): return AppGlobals.mutate(key, operation)

    def __dir__(cls) -> list[str]:
        definitions = set(cls.__dict__.get("_definitions", {}))
        return sorted(set(type.__dir__(cls)) | definitions | set(AppGlobals.keys()))


class GlobalsBase(metaclass=_GlobalsMeta):
    """Base for callback-owned declarations backed by the stable registry."""

    def __getattr__(self, name: str) -> Any:
        return getattr(AppGlobals, name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(AppGlobals, name, value)

    def __delattr__(self, name: str) -> None:
        delattr(AppGlobals, name)

    def __getitem__(self, key: str) -> Any:
        return AppGlobals[key]

    def __setitem__(self, key: str, value: Any) -> None:
        AppGlobals[key] = value

    def __delitem__(self, key: str) -> None:
        del AppGlobals[key]

    def __contains__(self, key: object) -> bool:
        return key in AppGlobals

    def __dir__(self) -> list[str]:
        definitions = set(type(self).__dict__.get("_definitions", {}))
        return sorted(set(object.__dir__(self)) | definitions | set(AppGlobals.keys()))

    def init_globals(self) -> None:
        """Synchronous main-thread hook invoked after all globals and UI exist."""

    @classmethod
    def definitions(cls) -> Dict[str, GlobalSpec]:
        return dict(cls.__dict__.get("_definitions", {}))

__all__ = [
    "AppGlobalDefinitionError",
    "AsyncLazy",
    "GlobalSpec",
    "GlobalValue",
    "GlobalsBase",
    "Lazy",
    "ReloadPolicy",
    "async_global",
    "global_value",
    "lazy",
]
