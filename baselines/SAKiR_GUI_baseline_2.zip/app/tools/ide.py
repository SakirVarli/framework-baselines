import sys, pyqode, re, inspect, os, jedi
from pandas.io.formats.style import Styler
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtWidgets import QTreeWidgetItem
from PyQt5.QtCore import Qt
from pyqode.core.panels import LineNumberPanel, SearchAndReplacePanel
from pyqode.core.api import CodeEdit, TextHelper
from pyqode.core.modes import (
    AutoCompleteMode,
    AutoIndentMode,
    CaretLineHighlighterMode,
    ExtendedSelectionMode,
    FileWatcherMode,
    RightMarginMode,
    ZoomMode,
    SymbolMatcherMode,
    OccurrencesHighlighterMode,
    SpellCheckerMode,
    IndenterMode
)
from pyqode.python.modes import PythonSH
from app.utils import PROJECT_ROOT, IDE_HISTORY_PATH, save_json, load_json
from app.runtime_globals import RuntimeGlobals
from app.tools.variable_explorer import VariableExplorer as SharedVariableExplorer
import numpy as np
import pandas as pd

def _extract_literal_values(annotation_text: str):
    """Parse typing.Literal annotations into a list of values."""
    if not annotation_text or "Literal" not in annotation_text:
        return []
    # remove any "typing." prefix
    annotation_text = annotation_text.replace("typing.", "")
    m = re.search(r"Literal\s*\[(.*?)\]", annotation_text)
    if not m:
        return []
    inner = m.group(1)
    # capture quoted segments 'x' or "x"
    vals = re.findall(r"['\"](.*?)['\"]", inner)
    return [v.strip() for v in vals if v.strip()]

def _extract_enum_values(type_name: str):
    """If type_name refers to an Enum in current modules, return its members."""
    if not type_name or "." not in type_name:
        return []
    parts = type_name.split(".")
    try:
        mod = sys.modules.get(parts[0])
        if not mod:
            mod = __import__(parts[0])
        cls = mod
        for p in parts[1:]:
            cls = getattr(cls, p)
        import enum
        if inspect.isclass(cls) and issubclass(cls, enum.Enum):
            return [f"{type_name}.{m.name}" for m in cls]
    except Exception:
        pass
    return []

def _extract_default_values(param_obj):
    """Try to extract a default value (string) from a Jedi param object safely."""
    try:
        s = str(param_obj.to_string())
        if "=" in s:
            val = s.split("=", 1)[1].strip()
            # Jedi may quote string defaults as tuples sometimes, sanitize
            if isinstance(val, tuple):
                val = " ".join(map(str, val))
            return [val]
    except Exception:
        pass
    return []

class RotatedLabel(QtWidgets.QLabel):
    """
    A QLabel that draws its text rotated 90° counter-clockwise.
    Used for compact vertical labels: 'rows (size=N)'.
    """
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.setAlignment(QtCore.Qt.AlignCenter)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.TextAntialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        painter.translate(self.width() / 2, self.height() / 2)
        painter.rotate(-90)  # rotate counter-clockwise
        painter.translate(-self.height() / 2, -self.width() / 2)
        rect = QtCore.QRect(0, 0, self.height(), self.width())
        painter.drawText(rect, QtCore.Qt.AlignCenter, self.text())

    def sizeHint(self):
        # swap width/height because it's rotated
        s = super().sizeHint()
        return QtCore.QSize(s.height(), s.width())
    
class ArrayViewer(QtWidgets.QDialog):
    """
    Fully Featured MATLAB-Style N-D NumPy Array Viewer
    --------------------------------------------------
    Features:
        ✔ Supports arrays of ANY dimension (1D → ∞D)
        ✔ Dim selectors appear in ONE horizontal scroll row
        ✔ Clean 2D table slice viewer
        ✔ 'rows(size=N)' vertical rotated label
        ✔ 'columns(size=M)' horizontal label
        ✔ Never repeats 'size' on every row/col like before
        ✔ Efficient slicing, no recursion
    """

    def __init__(self, arr, parent=None):
        super().__init__(parent)

        self.arr = arr
        self.shape = arr.shape
        self.nd = arr.ndim

        self.setWindowTitle(f"N-D Array Viewer  (shape={arr.shape})")
        self.resize(1100, 750)

        # =========================================================
        # MAIN LAYOUT
        # =========================================================
        main_layout = QtWidgets.QVBoxLayout(self)

        # =========================================================
        # DIMENSION SELECTORS (horizontal scroll area)
        # =========================================================
        selector_scroll = QtWidgets.QScrollArea()
        selector_scroll.setWidgetResizable(True)
        selector_scroll.setFixedHeight(40)
        selector_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        selector_scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        selector_scroll.setVisible(self.nd > 2)

        selector_widget = QtWidgets.QWidget()
        self.selector_layout = QtWidgets.QHBoxLayout(selector_widget)
        self.selector_layout.setContentsMargins(5, 5, 5, 5)
        self.selector_layout.setSpacing(15)

        selector_scroll.setWidget(selector_widget)
        main_layout.addWidget(selector_scroll)

        # Create dynamic dimension selectors for dims 2..N-1
        self.selectors = []
        if self.nd > 2:
            for dim in range(2, self.nd):
                sz = self.shape[dim]

                lbl = QtWidgets.QLabel(f"dim{dim} (size: {sz}):")
                spin = QtWidgets.QSpinBox()
                spin.setRange(0, sz - 1)
                spin.valueChanged.connect(self._refresh_table)

                self.selector_layout.addWidget(lbl)
                self.selector_layout.addWidget(spin)

                self.selectors.append(spin)

        self.selector_layout.addStretch()

        # =========================================================
        # COLUMN SIZE LABEL
        # =========================================================
        self.col_label = QtWidgets.QLabel("")
        self.col_label.setAlignment(QtCore.Qt.AlignCenter)
        self.col_label.setStyleSheet("font-size: 10px")
        main_layout.addWidget(self.col_label)

        # =========================================================
        # MAIN TABLE LAYOUT WITH ROTATED ROW LABEL
        # =========================================================
        table_container = QtWidgets.QHBoxLayout()

        # Row label (vertical)
        self.row_label = RotatedLabel("")
        self.row_label.setStyleSheet("font-size: 10px")
        self.row_label.setMaximumWidth(10)
        table_container.addWidget(self.row_label)

        # Table widget
        self.table = QtWidgets.QTableWidget()
        self.table.setFont(QtGui.QFont("Consolas", 10))
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)

        table_container.addWidget(self.table)
        main_layout.addLayout(table_container)

        # Initial render
        self._refresh_table()

    # =========================================================
    # SLICE N-D ARRAY TO 2D
    # =========================================================
    def _get_2d_slice(self):
        a = self.arr

        if self.nd == 1:
            return a.reshape(1, -1)

        if self.nd == 2:
            return a

        # Build slicer: [:, :, sel2, sel3, ...]
        slicer = [
            slice(None),  # dim 0 → rows
            slice(None)   # dim 1 → cols
        ]

        for spin in self.selectors:
            slicer.append(spin.value())

        return a[tuple(slicer)]

    # =========================================================
    # REFRESH TABLE
    # =========================================================
    def _refresh_table(self):
        arr2 = self._get_2d_slice()
        rows, cols = arr2.shape

        # update labels ONCE
        self.col_label.setText(f"columns (dim1, size: {cols})")
        self.row_label.setText(f"rows (dim0, size: {rows})")

        # update table structure
        self.table.setRowCount(rows)
        self.table.setColumnCount(cols)

        # headers just index numbers
        self.table.setHorizontalHeaderLabels([str(c) for c in range(cols)])
        self.table.setVerticalHeaderLabels([str(r) for r in range(rows)])

        # Fill table
        for r in range(rows):
            for c in range(cols):
                val = arr2[r, c]
                item = QtWidgets.QTableWidgetItem(str(val))
                item.setFlags(QtCore.Qt.ItemIsEnabled)
                self.table.setItem(r, c, item)

        self.table.resizeColumnsToContents()
        self.table.resizeRowsToContents()

class SortableItem(QtWidgets.QTableWidgetItem):
    """
    QTableWidgetItem subclass that uses an explicit sort_key
    for proper numeric / datetime / bool / NaN / string sorting.
    """

    def __init__(self, text: str, sort_key):
        super().__init__(text)
        self._sort_key = sort_key

    def __lt__(self, other):
        if isinstance(other, SortableItem):
            return self._sort_key < other._sort_key
        return super().__lt__(other)

class DataFrameViewer(QtWidgets.QDialog):
    """
    PRO DataFrame Viewer with:
        • DataFrame + Styler support
        • Sorting (numeric, negative values, datetime, bool, NaN-last)
        • Live search/filter
        • Fancy styling, dtype-aware formatting
        • NaN handling
        • Copy to clipboard
        • Export to CSV
        • Status bar (row/col count)
    """

    def __init__(self, df, parent=None):
        super().__init__(parent)

        # ----------------------------------------------------------
        # Accept DataFrame or DataFrame.style (Styler)
        # ----------------------------------------------------------
        if isinstance(df, Styler):
            self.df = df.data
            self.styler = df
        elif isinstance(df, pd.DataFrame):
            self.df = df
            self.styler = None
        else:
            raise TypeError("DataFrameViewer expects a pandas.DataFrame or pandas.io.formats.style.Styler")

        self.setWindowTitle("DataFrame Viewer")
        self.resize(1300, 800)

        # MAIN LAYOUT
        layout = QtWidgets.QVBoxLayout(self)

        # ==========================================================
        # SEARCH BAR
        # ==========================================================
        search_bar = QtWidgets.QHBoxLayout()
        layout.addLayout(search_bar)

        search_bar.addWidget(QtWidgets.QLabel("Search:"))
        self.search_box = QtWidgets.QLineEdit()
        self.search_box.setPlaceholderText("Type to filter rows...")
        self.search_box.textChanged.connect(self._apply_filter)
        search_bar.addWidget(self.search_box)

        # Buttons
        self.btn_copy = QtWidgets.QPushButton("Copy")
        self.btn_copy.clicked.connect(self._copy_selection)
        search_bar.addWidget(self.btn_copy)

        self.btn_export = QtWidgets.QPushButton("Export CSV")
        self.btn_export.clicked.connect(self._export_csv)
        search_bar.addWidget(self.btn_export)

        search_bar.addStretch()

        # ==========================================================
        # TABLE
        # ==========================================================
        self.table = QtWidgets.QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectItems)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setFont(QtGui.QFont("Consolas", 10))

        layout.addWidget(self.table)

        # ==========================================================
        # STATUS BAR
        # ==========================================================
        self.status = QtWidgets.QLabel("")
        layout.addWidget(self.status)

        # Load data (with sorting temporarily disabled to avoid flicker)
        self.table.setSortingEnabled(False)
        self._load_dataframe(self.df)
        self.table.setSortingEnabled(True)

    # ==========================================================
    # FILTERING (search)
    # ==========================================================
    def _apply_filter(self):
        text = self.search_box.text().lower().strip()

        for row in range(self.table.rowCount()):
            visible = False

            if text == "":
                visible = True
            else:
                for col in range(self.table.columnCount()):
                    item = self.table.item(row, col)
                    if item and text in item.text().lower():
                        visible = True
                        break

            self.table.setRowHidden(row, not visible)

        self._update_status()

    # ==========================================================
    # SORTING HELPER
    # ==========================================================
    def _sort_key(self, val):
        """
        Returns a tuple (group, value) so all keys are comparable:

            group 0 → numbers
            group 1 → datetimes
            group 2 → bools
            group 3 → strings
            group 4 → NaN / missing  (always last)
        """

        # NaN or missing → group 4, place at end
        if pd.isna(val):
            return (4, 0)

        # Numeric types (Python + NumPy)
        if isinstance(val, (int, float, np.integer, np.floating)):
            return (0, float(val))

        # Datetime
        if isinstance(val, (pd.Timestamp, np.datetime64)):
            return (1, pd.Timestamp(val).timestamp())

        # Boolean → treat as 0 or 1
        if isinstance(val, (bool, np.bool_)):
            return (2, int(val))

        # Fallback for objects/strings
        return (3, str(val).lower())

    # ==========================================================
    # STYLER → STYLE MAP
    # ==========================================================
    def _build_style_map(self):
        """
        Build {(row, col): [css_rule, ...]} from Styler.

        Compatible with Styler._compute().ctx or styler.ctx
        depending on pandas version.
        """
        style_map = {}

        if self.styler is None:
            return style_map

        ctx = None
        # Try new internal API
        try:
            ctx = self.styler._compute().ctx
        except Exception:
            # Fallback older API
            ctx = getattr(self.styler, "ctx", None)

        if not ctx:
            return style_map

        for (r, c), rules in ctx.items():
            # rules is usually:
            #   [("background-color", "yellow"), ("color", "red"), ...]
            # or a list of "prop: value" strings.
            style_map[(r, c)] = rules

        return style_map

    def _apply_style(self, item, rules):
        """
        Apply Styler CSS rules to a QTableWidgetItem.
        Accepts:
            - list of "prop: val" strings
            - list of (prop, val) tuples
        """
        for rule in rules:
            if isinstance(rule, tuple) and len(rule) == 2:
                key, val = rule
            else:
                # assume "key: value"
                if ":" not in rule:
                    continue
                key, val = rule.split(":", 1)

            key = key.strip().lower()
            val = val.strip()

            if key in ("background", "background-color"):
                item.setBackground(QtGui.QColor(val))

            elif key == "color":
                item.setForeground(QtGui.QColor(val))

            elif key == "font-weight" and "bold" in val:
                f = item.font()
                f.setBold(True)
                item.setFont(f)

            elif key == "font-style" and "italic" in val:
                f = item.font()
                f.setItalic(True)
                item.setFont(f)

    # ==========================================================
    # LOADING DATAFRAME
    # ==========================================================
    def _load_dataframe(self, df: pd.DataFrame):
        self.table.clear()

        rows, cols = df.shape
        self.table.setRowCount(rows)
        self.table.setColumnCount(cols)

        self.table.setHorizontalHeaderLabels([str(c) for c in df.columns])
        self.table.setVerticalHeaderLabels([str(i) for i in df.index])

        # build style map if Styler exists
        style_map = self._build_style_map()

        # ===========================
        # TABLE POPULATION
        # ===========================
        for r in range(rows):
            for c in range(cols):
                val = df.iat[r, c]

                # text formatting (keep simple to avoid confusing Qt)
                if pd.isna(val):
                    text = "NaN"
                elif isinstance(val, float):
                    # no thousands separators – just a concise numeric string
                    text = f"{val:.6g}"
                else:
                    text = str(val)

                sort_key = self._sort_key(val)
                item = SortableItem(text, sort_key)

                # alignment
                if isinstance(val, (int, float, np.integer, np.floating)):
                    item.setTextAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
                else:
                    item.setTextAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)

                # NA styling
                if pd.isna(val):
                    item.setBackground(QtGui.QColor("#ffd6d6"))
                    item.setForeground(QtGui.QColor("black"))
                    font = item.font()
                    font.setItalic(True)
                    item.setFont(font)

                # Styler formatting
                if (r, c) in style_map:
                    self._apply_style(item, style_map[(r, c)])

                self.table.setItem(r, c, item)

        # auto-size
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)

        self._update_status()

    # ==========================================================
    # COPY TO CLIPBOARD
    # ==========================================================
    def _copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges:
            return

        rng = ranges[0]
        buf = []

        for r in range(rng.topRow(), rng.bottomRow() + 1):
            row_data = []
            for c in range(rng.leftColumn(), rng.rightColumn() + 1):
                item = self.table.item(r, c)
                row_data.append("" if item is None else item.text())
            buf.append("\t".join(row_data))

        QtWidgets.QApplication.clipboard().setText("\n".join(buf))

    # ==========================================================
    # EXPORT CSV
    # ==========================================================
    def _export_csv(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Export CSV", "", "CSV Files (*.csv)"
        )
        if not path:
            return

        # filtered view export
        visible_rows = [
            r for r in range(self.table.rowCount())
            if not self.table.isRowHidden(r)
        ]

        columns = [
            self.table.horizontalHeaderItem(i).text()
            for i in range(self.table.columnCount())
        ]

        out = []
        for r in visible_rows:
            row_vals = []
            for c in range(self.table.columnCount()):
                item = self.table.item(r, c)
                row_vals.append(item.text() if item else "")
            out.append(row_vals)

        pd.DataFrame(out, columns=columns).to_csv(path, index=False)

    # ==========================================================
    # STATUS BAR
    # ==========================================================
    def _update_status(self):
        visible = sum(
            not self.table.isRowHidden(r)
            for r in range(self.table.rowCount())
        )
        self.status.setText(
            f"Showing {visible} / {self.table.rowCount()} rows     |     {self.table.columnCount()} columns"
        )

class ObjectInspector(QtWidgets.QDialog):
    """
    Object inspector with:
        - Summary (type, id, attributes, methods)
        - Docstring
        - Source (if available)
    """
    def __init__(self, obj, parent=None):
        super().__init__(parent)
        self.obj = obj

        self.setWindowTitle(f"Inspector: {type(obj).__name__}")
        self.resize(800, 700)

        layout = QtWidgets.QVBoxLayout(self)

        tabs = QtWidgets.QTabWidget()
        layout.addWidget(tabs)

        # --- SUMMARY TAB ---
        summary = QtWidgets.QTextEdit()
        summary.setReadOnly(True)
        summary.setFontFamily("Consolas")
        summary.setText(self._build_summary(obj))
        tabs.addTab(summary, "Summary")

        # --- DOC TAB ---
        doc = QtWidgets.QTextEdit()
        doc.setReadOnly(True)
        doc.setFontFamily("Consolas")
        doc.setText(inspect.getdoc(obj) or "No docstring available.")
        tabs.addTab(doc, "Docstring")

        # --- SOURCE TAB ---
        src = QtWidgets.QTextEdit()
        src.setReadOnly(True)
        src.setFontFamily("Consolas")
        src.setText(self._get_source(obj))
        tabs.addTab(src, "Source")

    # ------------------------------------------------------------------
    def _build_summary(self, obj):
        lines = []

        lines.append(f"Type: {type(obj)}")
        lines.append(f"ID: {id(obj)}")
        lines.append("")

        # Attributes
        try:
            attrs = vars(obj)
            lines.append(f"Attributes ({len(attrs)}):")
            for k, v in attrs.items():
                try:
                    lines.append(f"  {k} = {repr(v)[:80]}")
                except Exception:
                    lines.append(f"  {k} = <unprintable>")
        except Exception:
            lines.append("No instance attributes.")

        lines.append("")

        # Methods
        methods = []
        for name in dir(obj):
            try:
                v = getattr(obj, name)
                if callable(v) and not name.startswith("__"):
                    sig = ""
                    try:
                        sig = str(inspect.signature(v))
                    except Exception:
                        pass
                    methods.append(f"{name}{sig}")
            except Exception:
                continue

        if methods:
            lines.append(f"Methods ({len(methods)}):")
            for m in methods[:50]:
                lines.append(f"  {m}")
            if len(methods) > 50:
                lines.append("  ...")
        else:
            lines.append("No methods found.")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    def _get_source(self, obj):
        try:
            return inspect.getsource(obj)
        except Exception:
            return "Source code not available for this object."

class _LegacyVariableExplorer(QtCore.QObject):
    """
    Standalone Variable Explorer with:
        • QDockWidget container
        • QTreeWidget listing of variables
        • Safe recursive preview of dict/list/tuple/class/numpy/pandas
        • Context menu for Inspect / ArrayViewer / DataFrameViewer / Plot / Export
        • Double-click actions (view / inspect / edit scalars)
        • Hover tooltips showing detailed info
        • 'Size' column with approximate memory usage
    """

    PATH_ROLE = Qt.UserRole + 1  # stores "path" from env -> this item

    def __init__(self, parent: QtWidgets.QMainWindow):
        super().__init__(parent)
        self.parent = parent
        self._seen_ids = set()
        self._env = None  # current exec environment (dict)
        self._floating_size = (600, 400)

        # -------------------------------
        # QTreeWidget
        # -------------------------------
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels(["Name", "Type", "Preview", "Info", "Size"])
        self.tree.setIndentation(20)
        self.tree.setExpandsOnDoubleClick(True)
        self.tree.header().setStretchLastSection(False)
        self.tree.setSortingEnabled(True)
        self.tree.sortItems(0, Qt.AscendingOrder)

        # Better column behavior will be set in update()

        # Context menu
        self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._context_menu)

        # Double-click behavior
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)

        # Hover tooltip
        self.tree.setMouseTracking(True)
        self.tree.viewport().installEventFilter(self)

        # -------------------------------
        # DOCK widget
        # -------------------------------
        self.dock = QtWidgets.QDockWidget("Variable Explorer", parent)
        self.dock.setFeatures(
            QtWidgets.QDockWidget.DockWidgetFloatable |
            QtWidgets.QDockWidget.DockWidgetMovable |
            QtWidgets.QDockWidget.DockWidgetClosable
        )
        self.dock.setObjectName("VariableExplorerDock")
        self.dock.setWidget(self.tree)
        self.dock.setAllowedAreas(
            QtCore.Qt.BottomDockWidgetArea |
            QtCore.Qt.LeftDockWidgetArea |
            QtCore.Qt.RightDockWidgetArea
        )

        parent.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.dock)
        self.dock.topLevelChanged.connect(self._fix_floating_window)

    # ------------------------------------------------------------------
    # Event filter (used for hover tooltips)
    # ------------------------------------------------------------------
    def eventFilter(self, obj, event):
        if obj is self.tree.viewport():
            if event.type() == QtCore.QEvent.ToolTip:
                index = self.tree.indexAt(event.pos())
                if not index.isValid():
                    QtWidgets.QToolTip.hideText()
                    return True

                item = self.tree.itemFromIndex(index)
                value = getattr(item, "_value", None)
                tip = self._tooltip_text(value)
                if tip:
                    QtWidgets.QToolTip.showText(event.globalPos(), tip, self.tree)
                else:
                    QtWidgets.QToolTip.hideText()
                return True
        return super().eventFilter(obj, event)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def update(self, env: dict):
        """
        Refresh the entire tree based on a variable environment dict.
        """
        self._env = env
        self._seen_ids.clear()
        self.tree.clear()

        for name, value in env.items():
            if name.startswith("__"):
                continue
            top = self._build_item(name, value, level=0,
                                   path=[("root", name)])
            self.tree.addTopLevelItem(top)

        # Column sizing
        header = self.tree.header()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)  # Name
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)  # Type
        header.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)           # Preview
        header.setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)  # Info
        header.setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeToContents)  # Size

    def show(self):
        self.dock.show()

    def hide(self):
        self.dock.hide()

    # ------------------------------------------------------------------
    # Build tree items (recursive)
    # ------------------------------------------------------------------
    def _build_item(self, name, value, level=0, path=None):
        if path is None:
            path = [("root", name)]

        item = QTreeWidgetItem()
        item.setText(0, str(name))
        item.setText(1, type(value).__name__)
        item.setText(2, self._preview(value))
        item.setText(3, self._info(value))
        item.setText(4, self._size_str(value))

        # Store raw value and path
        if isinstance(value, (int, float, str, bool, type(None))):
            item.setData(0, Qt.UserRole, value)
        else:
            item.setData(0, Qt.UserRole, None)

        # STORE REAL OBJECT IN PYTHON SIDE ONLY
        item._value = value
        item.setData(0, self.PATH_ROLE, path)

        # Avoid infinite recursion
        vid = id(value)
        if vid in self._seen_ids:
            return item
        self._seen_ids.add(vid)

        if level >= 3:
            return item

        # -------------------- dict --------------------
        if isinstance(value, dict):
            for k in list(value.keys()):
                try:
                    v = value[k]
                except Exception:
                    continue
                child_path = path + [("dict", k)]
                child = self._build_item(k, v, level + 1, child_path)
                item.addChild(child)

        # -------------------- list / tuple --------------------
        elif isinstance(value, (list, tuple)):
            for i, v in enumerate(value):
                child_path = path + [("index", i)]
                child = self._build_item(f"[{i}]", v, level + 1, child_path)
                item.addChild(child)

        # -------------------- numpy array --------------------
        elif isinstance(value, np.ndarray):
            shape = QTreeWidgetItem(["shape", "tuple", str(value.shape), "", ""])
            shape.setData(0, Qt.UserRole, value.shape)

            flat = ", ".join(map(str, value.flatten()[:10])) + " ..."
            data = QTreeWidgetItem(["data", "ndarray", flat, str(value.dtype), self._size_str(value)])
            data.setData(0, Qt.UserRole, value)

            item.addChild(shape)
            item.addChild(data)

        # -------------------- class instance --------------------
        elif hasattr(value, "__dict__"):
            # attributes
            for k in list(value.__dict__.keys()):
                try:
                    v = value.__dict__[k]
                except Exception:
                    continue
                child_path = path + [("attr", k)]
                child = self._build_item(k, v, level + 1, child_path)
                item.addChild(child)

            # methods (non-dunder), shallow
            for attr in list(dir(value)):
                if attr.startswith("__"):
                    continue
                try:
                    v = getattr(value, attr)
                except Exception:
                    continue
                child = QTreeWidgetItem([attr,
                                         type(v).__name__,
                                         self._preview(v),
                                         self._info(v),
                                         self._size_str(v)])
                if isinstance(v, (int, float, str, bool, type(None))):
                    child.setData(0, Qt.UserRole, v)
                else:
                    child.setData(0, Qt.UserRole, None)

                child._value = v
                # we don't treat methods as editable path-based vars
                item.addChild(child)

        return item

    # ------------------------------------------------------------------
    # Preview helpers
    # ------------------------------------------------------------------
    def _preview(self, v):
        if isinstance(v, (str, int, float, bool)) or v is None:
            s = repr(v)
            return s if len(s) <= 80 else s[:77] + "..."
        if isinstance(v, (list, tuple)):
            return f"{type(v).__name__} (len={len(v)})"
        if isinstance(v, dict):
            return f"dict ({len(v)} keys)"
        if isinstance(v, np.ndarray):
            return f"ndarray shape={v.shape} dtype={v.dtype}"
        if isinstance(v, pd.DataFrame):
            return f"DataFrame {v.shape}"
        if isinstance(v, pd.Series):
            return f"Series len={len(v)}"
        return type(v).__name__

    def _info(self, v):
        try:
            if isinstance(v, np.ndarray):
                return f"{v.shape}, {v.dtype}"
            if isinstance(v, pd.DataFrame):
                return f"{v.shape[0]} rows × {v.shape[1]} cols"
            if isinstance(v, pd.Series):
                return f"{len(v)} items ({v.dtype})"
            if hasattr(v, "__len__"):
                return f"len={len(v)}"
        except Exception:
            pass
        return ""

    def _size_str(self, v):
        """
        Human-readable approximate size.
        """
        import sys
        try:
            if isinstance(v, np.ndarray):
                nbytes = int(v.nbytes)
            elif isinstance(v, pd.DataFrame):
                nbytes = int(v.memory_usage(deep=True).sum())
            elif isinstance(v, pd.Series):
                nbytes = int(v.memory_usage(deep=True))
            else:
                nbytes = int(sys.getsizeof(v))
        except Exception:
            return ""

        for unit in ["B", "KB", "MB", "GB"]:
            if nbytes < 1024.0:
                return f"{nbytes:.1f} {unit}"
            nbytes /= 1024.0
        return f"{nbytes:.1f} TB"

    # ------------------------------------------------------------------
    # Tooltip text
    # ------------------------------------------------------------------
    def _tooltip_text(self, v):
        try:
            lines = [f"Type: {type(v)}"]
            if isinstance(v, np.ndarray):
                lines.append(f"shape: {v.shape}")
                lines.append(f"dtype: {v.dtype}")
            if isinstance(v, pd.DataFrame):
                lines.append(f"DataFrame: {v.shape[0]} rows × {v.shape[1]} cols")
            if isinstance(v, pd.Series):
                lines.append(f"Series: len={len(v)} dtype={v.dtype}")

            r = repr(v)
            if len(r) > 400:
                r = r[:397] + "..."
            lines.append("")
            lines.append(r)
            return "\n".join(lines)
        except Exception:
            return ""

    # ------------------------------------------------------------------
    # Double-click behavior
    # ------------------------------------------------------------------
    def _on_item_double_clicked(self, item, column):
        value = getattr(item, "_value", None)

        # Numpy → ArrayViewer
        if self._is_numpy(value):
            self._view_array(value)
            return

        # DataFrame → DataFrameViewer
        if self._is_dataframe(value):
            self._view_df(value)
            return

        # Simple scalar → edit dialog
        if isinstance(value, (int, float, bool, str)) or value is None:
            self._edit_scalar(item, value)
            return

        # Fallback → ObjectInspector
        self._inspect(value)

    def _edit_scalar(self, item, value):
        """
        Edit a simple scalar in-place and push back to env via path.
        """
        text, ok = QtWidgets.QInputDialog.getText(
            self.parent,
            "Edit value",
            f"New value for {item.text(0)}:",
            text=str(value)
        )
        if not ok:
            return

        # Try to infer type: bool / int / float / str
        new_val = text
        try:
            if isinstance(value, bool):
                lower = text.strip().lower()
                if lower in ("true", "1", "yes", "y"):
                    new_val = True
                elif lower in ("false", "0", "no", "n"):
                    new_val = False
                else:
                    raise ValueError
            elif isinstance(value, int):
                new_val = int(text)
            elif isinstance(value, float):
                new_val = float(text)
            elif value is None:
                # keep as string by default
                new_val = text
        except Exception:
            # fallback: keep as string
            new_val = text

        # Update env if we know how
        path = item.data(0, self.PATH_ROLE)
        if self._env is not None and path:
            self._set_value_by_path(path, new_val)

        # Update displayed value and stored data
        item.setData(0, Qt.UserRole, new_val)
        item.setText(2, self._preview(new_val))
        item.setText(3, self._info(new_val))
        item.setText(4, self._size_str(new_val))

    def _set_value_by_path(self, path, new_val):
        """
        Given a path [("root", name), ("dict", key), ("index", i), ("attr", k), ...]
        write new_val into self._env at the correct location.
        """
        if not path or self._env is None:
            return

        # walk all but last to get container
        holder = self._env
        for kind, key in path[:-1]:
            if kind == "root":
                holder = holder.get(key, None)
            elif kind == "dict":
                holder = holder[key]
            elif kind == "index":
                holder = holder[key]
            elif kind == "attr":
                holder = getattr(holder, key, None)

        last_kind, last_key = path[-1]

        try:
            if last_kind == "root":
                self._env[last_key] = new_val
            elif last_kind == "dict":
                holder[last_key] = new_val
            elif last_kind == "index":
                holder[last_key] = new_val
            elif last_kind == "attr":
                setattr(holder, last_key, new_val)
        except Exception as e:
            QtWidgets.QMessageBox.warning(
                self.parent,
                "Edit failed",
                f"Could not assign value: {e}"
            )

    # ------------------------------------------------------------------
    # Context menu
    # ------------------------------------------------------------------
    def _context_menu(self, pos):
        item = self.tree.itemAt(pos)
        if not item:
            return

        value = getattr(item, "_value", None)
        menu = QtWidgets.QMenu(self.tree)

        # Core actions
        act_inspect = menu.addAction("Inspect Object")
        act_array = menu.addAction("Open Array Viewer")
        act_df = menu.addAction("Open DataFrame Viewer")
        act_plot = menu.addAction("Plot (Matplotlib)")
        act_hist = menu.addAction("Plot Histogram")

        act_array.setEnabled(self._is_numpy(value))
        act_df.setEnabled(self._is_dataframe(value))
        act_plot.setEnabled(self._is_plottable(value))
        act_hist.setEnabled(self._is_histogrammable(value))

        act_inspect.triggered.connect(lambda: self._inspect(value))
        act_array.triggered.connect(lambda: self._view_array(value))
        act_df.triggered.connect(lambda: self._view_df(value))
        act_plot.triggered.connect(lambda: self._plot(value))
        act_hist.triggered.connect(lambda: self._plot_hist(value))

        # Export submenu
        export_menu = menu.addMenu("Export...")
        act_export_npy = export_menu.addAction("as .npy (NumPy)")
        act_export_csv = export_menu.addAction("as .csv")
        act_export_pkl = export_menu.addAction("as .pkl (pickle)")

        act_export_npy.setEnabled(self._is_numpy(value))
        # CSV for DataFrame or 1D/2D numeric-ish
        act_export_csv.setEnabled(
            self._is_dataframe(value) or self._is_plottable(value)
        )

        act_export_npy.triggered.connect(lambda: self._export_npy(value))
        act_export_csv.triggered.connect(lambda: self._export_csv(value))
        act_export_pkl.triggered.connect(lambda: self._export_pickle(value))

        menu.exec_(self.tree.mapToGlobal(pos))

    # ------------------------------------------------------------------
    # Viewer helpers
    # ------------------------------------------------------------------
    def _inspect(self, obj):
        dlg = ObjectInspector(obj, self.parent)
        dlg.exec_()

    def _view_array(self, arr):
        dlg = ArrayViewer(arr, self.parent)
        dlg.exec_()

    def _view_df(self, df):
        dlg = DataFrameViewer(df, self.parent)
        dlg.exec_()

    def _plot(self, v):
        import matplotlib.pyplot as plt
        try:
            plt.figure()
            plt.plot(v)
            plt.title("Plot")
            plt.show()
        except Exception as e:
            QtWidgets.QMessageBox.warning(
                self.parent, "Plot failed", f"Could not plot: {e}"
            )

    def _plot_hist(self, v):
        import matplotlib.pyplot as plt
        try:
            arr = np.asarray(v).ravel()
            plt.figure()
            plt.hist(arr, bins=30)
            plt.title("Histogram")
            plt.show()
        except Exception as e:
            QtWidgets.QMessageBox.warning(
                self.parent, "Histogram failed", f"Could not plot histogram: {e}"
            )

    # ------------------------------------------------------------------
    # Export helpers
    # ------------------------------------------------------------------
    def _export_npy(self, v):
        if not self._is_numpy(v):
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self.parent, "Export NumPy array", "", "NumPy files (*.npy)"
        )
        if not path:
            return
        try:
            np.save(path, v)
        except Exception as e:
            QtWidgets.QMessageBox.warning(
                self.parent, "Export failed", f"Could not save .npy: {e}"
            )

    def _export_csv(self, v):
        import csv
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self.parent, "Export to CSV", "", "CSV files (*.csv)"
        )
        if not path:
            return
        try:
            if isinstance(v, pd.DataFrame):
                v.to_csv(path, index=False)
            else:
                arr = np.asarray(v)
                if arr.ndim == 1:
                    df = pd.DataFrame({"value": arr})
                else:
                    df = pd.DataFrame(arr)
                df.to_csv(path, index=False)
        except Exception as e:
            QtWidgets.QMessageBox.warning(
                self.parent, "Export failed", f"Could not save .csv: {e}"
            )

    def _export_pickle(self, v):
        import pickle
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self.parent, "Export via pickle", "", "Pickle files (*.pkl)"
        )
        if not path:
            return
        try:
            with open(path, "wb") as f:
                pickle.dump(v, f, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            QtWidgets.QMessageBox.warning(
                self.parent, "Export failed", f"Could not save .pkl: {e}"
            )

    # ------------------------------------------------------------------
    # Type checks
    # ------------------------------------------------------------------
    def _is_numpy(self, v):
        return isinstance(v, np.ndarray)

    def _is_dataframe(self, v):
        return isinstance(v, (pd.DataFrame, Styler))

    def _is_plottable(self, v):
        return isinstance(v, (list, tuple, np.ndarray, pd.Series))

    def _is_histogrammable(self, v):
        try:
            arr = np.asarray(v)
            return arr.size > 0 and np.issubdtype(arr.dtype, np.number)
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Fix floating window: restore titlebar
    # ------------------------------------------------------------------
    def _fix_floating_window(self, floating):
        if floating:
            QtCore.QTimer.singleShot(0, self._enable_floating_titlebar)
        else:
            QtCore.QTimer.singleShot(0, self._restore_docked_state)

    def _enable_floating_titlebar(self):
        dock = self.dock
        if not dock.isFloating():
            return

        dock.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowTitleHint |
            QtCore.Qt.WindowSystemMenuHint |
            QtCore.Qt.WindowCloseButtonHint |
            QtCore.Qt.WindowMinMaxButtonsHint
        )
        dock.resize(*self._floating_size)
        dock.show()

    def _restore_docked_state(self):
        dock = self.dock
        if dock.isFloating():
            return

        # DO NOT TOUCH FLAGS!! Qt will fix them itself.
        # Just call show() to re-polish it into dock mode.
        dock.setWindowFlags(QtCore.Qt.Widget)
        dock.show()

# Keep the IDE's long-standing dock API while using the shared lazy explorer.
VariableExplorer = SharedVariableExplorer


class CodeRunner(QtCore.QThread):
    """
    Runs Python code in a background thread and streams stdout/stderr.
    """
    output = QtCore.pyqtSignal(str, str)  # kind, text ('stdout' or 'stderr' or 'system')
    finished_ok = QtCore.pyqtSignal()
    finished_err = QtCore.pyqtSignal(str)
    update_vars = QtCore.pyqtSignal(dict)

    def __init__(self, code, globals_env=None, parent=None):
        super().__init__(parent)
        self.code = code
        self.globals_env = {} if globals_env is None else globals_env

    def run(self):
        # Prepare execution environment
        env = self.globals_env   # <-- use the EXACT SAME environment, do not copy it!
        env.setdefault("__name__", "__main__")
        env.setdefault("__builtins__", __builtins__)
        env["Globals"] = RuntimeGlobals

        old_stdout = sys.stdout
        old_stderr = sys.stderr

        class Stream:
            def __init__(self, kind, outer):
                self._kind = kind
                self._outer = outer

            def write(self, text):
                if text:
                    self._outer.output.emit(self._kind, str(text))

            def flush(self):
                pass

        try:
            sys.stdout = Stream("stdout", self)
            sys.stderr = Stream("stderr", self)

            # Compile for better tracebacks
            code_obj = compile(self.code, "<editor>", "exec")
            exec(code_obj, env)
            self.finished_ok.emit()
            self.update_vars.emit(env)
        except Exception as e:
            import traceback

            # ---------------------------------------------------------
            # AUTO-IMPORT FOR COMMON ALIASES
            # ---------------------------------------------------------
            try:
                msg = str(e)

                # Detect NameError: "name 'np' is not defined"
                if isinstance(e, NameError) and "is not defined" in msg:
                    missing = msg.split("'")[1]

                    AUTO_IMPORTS = {
                        "np":           "import numpy as np",
                        "os":           "import os",
                        "pd":           "import pandas as pd",
                        "plt":          "import matplotlib.pyplot as plt",
                        "sns":          "import seaborn as sns",
                        "torch":        "import torch",
                        "tf":           "import tensorflow as tf",
                        "sp":           "import scipy as sp",
                        "time":         "import time"
                    }

                    if missing in AUTO_IMPORTS:
                        stmt = AUTO_IMPORTS[missing]
                        self.output.emit("system", f"[auto-import] {stmt}\n")
                        try:
                            # run the import
                            exec(stmt, env)

                            # rerun user snippet
                            code_obj = compile(self.code, "<editor>", "exec")
                            exec(code_obj, env)

                            self.finished_ok.emit()
                            self.update_vars.emit(env)
                            return
                        except Exception as sub:
                            # fall-through to normal error
                            pass

                # Normal error (no auto-import possible)
                err = traceback.format_exc()
                self.output.emit("stderr", err)
                self.finished_err.emit(err)

            except Exception:
                # If anything fails in our auto-import logic, fall back to normal error
                err = traceback.format_exc()
                self.output.emit("stderr", err)
                self.finished_err.emit(err)
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

class HoverTooltip(QtWidgets.QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowFlags(
            QtCore.Qt.Tool |
            QtCore.Qt.FramelessWindowHint |
            QtCore.Qt.WindowStaysOnTopHint |
            QtCore.Qt.BypassWindowManagerHint
        )

        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setMouseTracking(True)

        self._max_height = 250  # soft max height

        # -------------------------
        # Scrollable content
        # -------------------------
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setSizeAdjustPolicy(QtWidgets.QAbstractScrollArea.AdjustToContents)

        # Container
        self.content = QtWidgets.QWidget()
        self.vbox = QtWidgets.QVBoxLayout(self.content)
        self.vbox.setContentsMargins(10, 10, 10, 10)

        self.label = QtWidgets.QLabel("")
        self.label.setWordWrap(True)
        self.label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.label.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        self.label.setMinimumWidth(100)
        self.label.setMaximumWidth(600)

        self.vbox.addWidget(self.label)
        self.scroll.setWidget(self.content)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.scroll)
        layout.setContentsMargins(0, 0, 0, 0)

        self.setStyleSheet("""
            QLabel {
                color: #555555;
                font-family: Consolas;
                font-size: 11pt;
            }
        """)

        self._mouse_inside = False

    # ----------------------------------------------------------------------
    def show_text(self, global_pos, text):
        self.label.setText(text)

        self.label.adjustSize()
        self.content.adjustSize()
        self.scroll.adjustSize()

        # natural size
        natural_w = min(self.content.sizeHint().width() + 20, 600)
        natural_h = self.content.sizeHint().height() + 20

        # clamp height
        final_h = min(natural_h, self._max_height)

        self.resize(natural_w, final_h)

        self.move(global_pos + QtCore.QPoint(12, 12))
        self.show()

    def enterEvent(self, event):
        self._mouse_inside = True
        if hasattr(self, "owner") and self.owner:
            self.owner.hide_delay.stop()

    def leaveEvent(self, event):
        self._mouse_inside = False
        if hasattr(self, "owner") and self.owner:
            self.owner.hide_delay.start()
        super().leaveEvent(event)

class HoverDocMode(QtCore.QObject, pyqode.core.api.Mode):
    """
    CTRL + Hover tooltip documentation with scroll, no side panel,
    tooltip stays visible while mouse is inside it.
    """

    def __init__(self):
        QtCore.QObject.__init__(self)
        pyqode.core.api.Mode.__init__(self)

        self.tooltip = HoverTooltip()

        self.timer = QtCore.QTimer()
        self.timer.setSingleShot(True)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self._resolve_hover)

        # NEW: delayed hide timer
        self.hide_delay = QtCore.QTimer()
        self.hide_delay.setSingleShot(True)
        self.hide_delay.setInterval(150)
        self.hide_delay.timeout.connect(self._hide_if_outside)

        self.last_pos = None
        self._extra_selection = None
        self._highlight_key = "_hover_highlight_"

    # ----------------------------------------------------------------------
    def on_install(self, editor):
        super().on_install(editor)
        editor.viewport().installEventFilter(self)
        # Let tooltip know about HoverDocMode (so it can cancel hide)
        self.tooltip.owner = self

    def on_uninstall(self, editor):
        editor.viewport().removeEventFilter(self)
        super().on_uninstall(editor)

    # ----------------------------------------------------------------------
    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.MouseMove:
            self.last_pos = event.pos()
            self.timer.start()

        elif event.type() == QtCore.QEvent.Leave:
            # DO NOT HIDE IMMEDIATELY
            # schedule hide, but tooltip may cancel it
            self.hide_delay.start()

        return False

    # ----------------------------------------------------------------------
    def _hide_if_outside(self):
        """Hide tooltip only if mouse is NOT inside tooltip."""
        if not self.tooltip._mouse_inside:
            self.tooltip.hide()
            self._clear_highlight()

    # ----------------------------------------------------------------------
    def _resolve_hover(self):
        if not (QtWidgets.QApplication.keyboardModifiers() & QtCore.Qt.ControlModifier):
            self.hide_delay.start()
            self._clear_highlight()
            return

        editor = self.editor
        pos = self.last_pos
        if not pos:
            return

        # get symbol under cursor
        cursor = editor.cursorForPosition(pos)
        cursor.select(QtGui.QTextCursor.WordUnderCursor)
        word = cursor.selectedText().strip()

        if not word or not word.isidentifier():
            self.hide_delay.start()
            self._clear_highlight()
            return
        
        # highlight
        self._apply_highlight(cursor)

        # Jedi lookup
        try:
            code = editor.toPlainText()
            path = self._get_path(editor)

            if path:
                if PROJECT_ROOT not in sys.path:
                    sys.path.insert(0, PROJECT_ROOT)

            script = jedi.Script(code, path=path)
            hits = script.infer(cursor.blockNumber() + 1, cursor.columnNumber())

            if not hits:
                self.hide_delay.start()
                return

            doc_text = ""
            for h in hits:
                d = h.docstring()
                if d:
                    doc_text += d + "\n"

            if not doc_text.strip():
                self.hide_delay.start()
                return

            # show tooltip
            global_pos = editor.mapToGlobal(pos)
            self.tooltip.show_text(global_pos, doc_text)

        except Exception as e:
            self.hide_delay.start()
            return

    # ----------------------------------------------------------------------
    def _get_path(self, editor):
        w = editor
        while w is not None:
            if hasattr(w, "path") and w.path:
                return w.path
            w = w.parent()
        return None

    # ----------------------------------------------------------------------
    def _apply_highlight(self, cursor):
        self._clear_highlight()  # remove previous

        selection = QtWidgets.QTextEdit.ExtraSelection()
        selection.cursor = cursor
        selection.format = QtGui.QTextCharFormat()
        selection.format.setUnderlineStyle(QtGui.QTextCharFormat.SingleUnderline)
        selection.format.setUnderlineColor(QtGui.QColor("#4fc3f7"))

        # 🔥 Unique signature to identify our highlight
        selection.format.setProperty(QtCore.Qt.UserRole, self._highlight_key)

        editor = self.editor
        selections = editor.extraSelections()
        selections.append(selection)
        editor.setExtraSelections(selections)

    def _clear_highlight(self):
        editor = self.editor
        if editor is None:
            return

        new_selections = []
        for sel in editor.extraSelections():
            fmt: QtGui.QTextCharFormat = sel.format

            # KEEP all selections that are NOT ours
            if fmt.property(QtCore.Qt.UserRole) != self._highlight_key:
                new_selections.append(sel)

        editor.setExtraSelections(new_selections)

class JediWorker(QtCore.QThread):
    """
    Background worker that performs Jedi completion.
    Emits a dict {prefix, completions, tooltips}.
    """
    completed = QtCore.pyqtSignal(dict)

    def __init__(self, code, line, col, context, parent=None):
        super().__init__(parent)
        self.code = code
        self.line = line
        self.col = col
        self.context = context

    def run(self):
        if self.isInterruptionRequested():
            return

        out = {"prefix": "", "items": [], "tooltips": {}}

        try:
            script = jedi.Script(self.code)
            if self.isInterruptionRequested():
                return
            completions = script.complete(self.line, self.col)
        except Exception:
            completions = []

        for c in completions:
            if self.isInterruptionRequested():
                return
            name = c.name
            if c.type == "statement" or c.type == "param" or c.type == "keyword":
                doc = ""
            else:
                try:
                    doc = c.docstring() or ""
                except:
                    doc = ""
            out["items"].append(name)
            out["tooltips"][name] = doc

        try:
            line_text = self.code.splitlines()[self.line - 1][:self.col]
            if re.search(r"\bGlobals\.[A-Za-z_]*$", line_text):
                runtime_docs = {
                    "snapshot": "Return a locked shallow copy of committed Globals values.",
                    "mutate": "Atomically replace one value while the registry lock is held.",
                    "state": "Current Globals runtime state.",
                    "generation": "Current committed Globals generation ID.",
                    "error": "Most recent Globals initialization error, if any.",
                }
                for name in dir(RuntimeGlobals):
                    if name.startswith("_"):
                        continue
                    if name not in out["items"]:
                        out["items"].append(name)
                    out["tooltips"].setdefault(name, runtime_docs.get(name, "Runtime global value."))
        except Exception:
            pass

        if self.context == "string":
            # return only literal values (your Literal[...] extraction)
            out["items"] = [i for i in out["items"] if i.startswith('"') or i.startswith("'")]

        elif self.context == "default":
            # return only default values
            out["items"] = [i for i in out["items"] if "=" in i]

        if self.isInterruptionRequested():
            return

        try:
            script = jedi.Script(self.code)
            sigs = script.get_signatures(self.line, self.col)
            if sigs:
                sig = sigs[0]
                idx = sig.index
                if idx is not None and idx < len(sig.params):
                    p = sig.params[idx]
                    ann = (
                        getattr(p, "annotation_string", "") or
                        getattr(p, "description", "") or ""
                    )

                    # Extract literal / enum / default values
                    lit = _extract_literal_values(ann)   # raw literal strings
                    env = _extract_enum_values(ann)
                    dfl = _extract_default_values(p)

                    # 1) Literal values — wrap in quotes
                    for v in lit:
                        q = f'"{v}"'
                        out["items"].append(q)
                        out["tooltips"][q] = ""

                    # 2) Enum / default values (keep original form)
                    for v in env + dfl:
                        out["items"].append(v)
                        out["tooltips"][v] = ""
        except:
            pass

        if not self.isInterruptionRequested():
            self.completed.emit(out)

class PythonCompletionMode(QtCore.QObject, pyqode.core.api.Mode):
    """
    Same functionality as before, now fully asynchronous.
    """
    def __init__(self):
        QtCore.QObject.__init__(self)
        pyqode.core.api.Mode.__init__(self)

        self._trigger_symbols = ['.', '(', '"', "'", ',', '=', ' ']
        self._trigger_key = QtCore.Qt.Key_Space
        self._completion_prefix = ""
        self._current_completion = ""
        self._char_width = None
        self._show_tooltips = True
        self._tooltips = {}
        self._stylesheet_initialized = False

        self._completer = None
        self._helper = None
        self._worker = None              # last running worker (auto-cancel)

    # ------------------------------------------------------------------
    def on_install(self, editor):
        super().on_install(editor)
        self._helper = TextHelper(editor)
        self._create_completer()

        editor.key_pressed.connect(self._on_key_pressed)
        editor.post_key_pressed.connect(self._on_key_released)
        editor.focused_in.connect(self._on_focus_in)

    def on_uninstall(self, editor):
        editor.key_pressed.disconnect(self._on_key_pressed)
        editor.post_key_pressed.disconnect(self._on_key_released)
        editor.focused_in.disconnect(self._on_focus_in)
        super().on_uninstall(editor)

    # ------------------------------------------------------------------
    # QCompleter setup
    # ------------------------------------------------------------------
    def _create_completer(self):
        self._completer = QtWidgets.QCompleter([''], self.editor)
        self._completer.setCompletionMode(QtWidgets.QCompleter.PopupCompletion)
        self._completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)

        self._completer.activated.connect(self._insert_completion)
        self._completer.highlighted.connect(self._highlight_changed)
        self._completer.highlighted.connect(self._display_completion_tooltip)

        self._completer.setModel(QtGui.QStandardItemModel())

    def _on_focus_in(self, event):
        self._completer.setWidget(self.editor)

    def _highlight_changed(self, name):
        self._current_completion = name

    # ------------------------------------------------------------------
    # Key events
    # ------------------------------------------------------------------
    def _on_key_pressed(self, event):
        key = event.key()

        # ----------------------------------------------
        # 1) If completion popup is visible, handle TAB/ENTER manually
        # ----------------------------------------------
        popup = self._completer.popup()
        if popup.isVisible():
            if key in (QtCore.Qt.Key_Tab, QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
                self._insert_completion(self._current_completion)
                event.accept()
                return
        
        if self._worker and self._worker.isRunning():
            self._worker.requestInterruption()
        
        text = event.text()

        # TRIGGER STRING COMPLETIONS
        if text in ('"', "'"):
            self._trigger_string_completion()
            return

        # TRIGGER DEFAULT VALUE COMPLETIONS
        if text == "=":
            self._trigger_default_completion()
            return

        # fallback to normal completion
        self._maybe_start_completion()

    def _trigger_string_completion(self):
        cursor = self.editor.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber()
        code = self.editor.toPlainText()

        # Build special request for string context
        self._begin_completion(
            code=code,
            line=line,
            col=col,
            force_context="string"
        )
    
    def _trigger_default_completion(self):
        cursor = self.editor.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber()
        code = self.editor.toPlainText()

        self._begin_completion(
            code=code,
            line=line,
            col=col,
            force_context="default"
        )

    def _maybe_start_completion(self):
        cursor = self.editor.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber()
        code = self.editor.toPlainText()

        # Extract prefix safely
        prefix = self._helper.word_under_cursor(select_whole_word=False).selectedText().strip()

        context = self._classify_context(code, line, col, prefix)

        self._start_worker(code, line, col, prefix, context)

    def _on_key_released(self, event):
        if self._worker and self._worker.isRunning():
            self._worker.requestInterruption()
        
        if event.key() in (QtCore.Qt.Key_Enter,
                           QtCore.Qt.Key_Return,
                           QtCore.Qt.Key_Escape):
            return

        text = event.text()

        if text in self._trigger_symbols:
            self._begin_completion()
            return

        word = self._helper.word_under_cursor(select_whole_word=True).selectedText()
        if len(word) >= 1 and text.strip():
            self._begin_completion()
        else:
            self._hide_popup()

    # ------------------------------------------------------------------
    # Asynchronous completion trigger
    # ------------------------------------------------------------------
    def _begin_completion(self, code=None, line=None, col=None, force_context=None):
        cursor = self.editor.textCursor()

        code = code or self.editor.toPlainText()
        line = line or cursor.blockNumber() + 1
        col = col or cursor.columnNumber()

        # MUST extract the actual text, not the cursor
        prefix = self._helper.word_under_cursor(select_whole_word=False).selectedText().strip()

        if force_context is not None:
            context = force_context
        else:
            context = self._classify_context(code, line, col, prefix)

        self._start_worker(code, line, col, prefix, context)

    def _start_worker(self, code, line, col, prefix, context):
        # Cancel previous worker safely
        if self._worker and self._worker.isRunning():
            self._worker.requestInterruption()
            self._worker.wait()

        # Start new worker
        self._worker = JediWorker(code, line, col, context)
        self._worker.setParent(None)  # avoid auto-delete during editing
        self._worker.completed.connect(self._apply_results)
        self._worker.start()

    # ------------------------------------------------------------------
    # Apply results from background thread
    # ------------------------------------------------------------------
    def _apply_results(self, data):
        items = data["items"]
        self._tooltips = data["tooltips"]

        cursor = self.editor.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber()

        try:
            context = self._classify_context(
                self.editor.toPlainText(),
                line,
                col,
                self._completion_prefix
            )
        except Exception as e:
            context = "normal"

        # Score and sort items
        scored = []
        for name in items:
            try:
                score = self._score_item(name, self._completion_prefix, context)
            except Exception as e:
                score = 0
            scored.append((score, name))
        scored.sort(reverse=True, key=lambda x: x[0])

        model = QtGui.QStandardItemModel()

        for score, name in scored:
            it = QtGui.QStandardItem(name)
            model.appendRow(it)

        self._completer.setModel(model)
        self._show_popup()

    # ------------------------------------------------------------------
    # Insert completion
    # ------------------------------------------------------------------
    def _insert_completion(self, completion):
        if not completion:
            return

        # Strip auto-wrapped literals
        if (completion.startswith('"') and completion.endswith('"')) or \
        (completion.startswith("'") and completion.endswith("'")):
            completion = completion[1:-1]

        editor = self.editor
        tc = editor.textCursor()

        # select ONLY the current prefix string (safe for PyQode)
        word_tc = self._helper.word_under_cursor(select_whole_word=False)
        prefix = word_tc.selectedText()

        # Replace only the prefix (do NOT use select_whole_word=True)
        word_tc.insertText(completion)

        # Move cursor safely to end of inserted text
        new_pos = word_tc.position()
        tc.setPosition(new_pos)
        editor.setTextCursor(tc)

        # Ensure popup closes cleanly
        self._hide_popup()

    # ------------------------------------------------------------------
    # Show popup
    # ------------------------------------------------------------------
    def _show_popup(self):
        cursor = self.editor.textCursor()
        rect = self.editor.cursorRect(cursor)

        if self._char_width is None:
            self._char_width = self.editor.fontMetrics().width('_')

        popup = self._completer.popup()

        width_hint = max(150, popup.sizeHintForColumn(0))
        rect.setWidth(width_hint + popup.verticalScrollBar().sizeHint().width())

        self._completer.complete(rect)

        if not self._stylesheet_initialized:
            popup.setStyleSheet(
                f"""
                background: {self.editor.palette().base().color().name()};
                color: {self.editor.palette().text().color().name()};
                font-family: {self.editor.font_name};
                font-size: {self.editor.font_size};
                """
            )
            self._stylesheet_initialized = True

    def _hide_popup(self):
        self._completer.popup().hide()

    # ------------------------------------------------------------------
    # Helper
    # ------------------------------------------------------------------
    def _is_shortcut(self, event):
        return event.modifiers() == QtCore.Qt.ControlModifier and event.key() == self._trigger_key

    # ------------------------------------------------------------------
    # Tooltip
    # ------------------------------------------------------------------
    def _display_completion_tooltip(self, completion):
        if not self._show_tooltips:
            return

        tip = self._tooltips.get(completion, "")
        if not tip:
            QtWidgets.QToolTip.hideText()
            return

        popup = self._completer.popup()
        pt = popup.mapToGlobal(QtCore.QPoint(popup.width(), 0))
        QtWidgets.QToolTip.showText(pt, tip, self.editor)

    def _classify_context(self, code, line, col, prefix):
        """
        Detect what user is doing (string / call / attribute).
        Safe for empty lines, no crashes.
        """
        lines = code.splitlines()

        if line - 1 < 0 or line - 1 >= len(lines):
            return "normal"

        line_text = lines[line - 1]
        if col > len(line_text):
            col = len(line_text)

        left = line_text[:col]

        # ------------------------------------------------------------------
        # 1) FIXED STRING CONTEXT DETECTION
        #    (walk backwards and detect real open string)
        # ------------------------------------------------------------------
        in_string = False
        escape = False
        for ch in reversed(left):
            if escape:
                escape = False
                continue
            if ch == "\\":
                escape = True
                continue
            if ch in ("'", '"'):
                in_string = not in_string
            if ch == "\n":
                break

        if in_string:
            return "string"
        # ------------------------------------------------------------------

        # 2) function call context
        if re.search(r"[A-Za-z_][A-Za-z0-9_]*\([^()]*$", left):
            return "call"

        # 3) attribute context
        if prefix and "." in prefix:
            return "attribute"

        return "normal"

    def _score_item(self, name, prefix, context):
        try:
            if not isinstance(name, str):
                return 0
            p = prefix.lower() if isinstance(prefix, str) else ""
            n = name.lower()
        except:
            return 0

        score = 0

        if p and n.startswith(p):
            score += 100
        elif p and p in n:
            score += 20

        return score

class EditorTab(QtWidgets.QWidget):
    """
    Single tab containing a pyqode CodeEdit bound to a file path.
    Handles dirty state and external file change detection.
    """
    modified_changed = QtCore.pyqtSignal(bool)
    request_reload_from_disk = QtCore.pyqtSignal()

    def __init__(self, path=None, parent=None):
        super().__init__(parent)
        self.path = path  # can be None for untitled
        self._dirty = False
        self._last_disk_mtime = None

        self.exec_env = {"__name__": "__main__", "Globals": RuntimeGlobals}

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.editor = CodeEdit()
        layout.addWidget(self.editor)

        # panels
        self.editor.panels.append(LineNumberPanel())
        self.editor.panels.append(SearchAndReplacePanel())

        # syntax highlighter
        self.editor.modes.append(PythonSH(self.editor))

        # modes
        self.editor.modes.append(AutoCompleteMode())
        self.editor.modes.append(PythonCompletionMode())
        self.editor.modes.append(CaretLineHighlighterMode())
        self.editor.modes.append(ExtendedSelectionMode())
        self.editor.modes.append(FileWatcherMode())
        self.editor.modes.append(IndenterMode())
        self.editor.modes.append(RightMarginMode())
        self.editor.modes.append(ZoomMode())
        self.editor.modes.append(SymbolMatcherMode())
        self.editor.modes.append(HoverDocMode())
        self.editor.modes.append(OccurrencesHighlighterMode())
        self.editor.modes.append(SpellCheckerMode())
        self.editor.modes.append(AutoIndentMode())
        
        # connect for dirty tracking
        self.editor.textChanged.connect(self._on_text_changed)

    # --------- dirty state ----------
    @property
    def is_dirty(self):
        return self._dirty

    def set_dirty(self, dirty: bool):
        if self._dirty != dirty:
            self._dirty = dirty
            self.modified_changed.emit(dirty)

    def _on_text_changed(self):
        # simply mark as dirty on any change
        self.set_dirty(True)

    # --------- file I/O ----------
    def load_from_disk(self, path):
        import os
        self.path = path
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        self.editor.setPlainText(text, "text/x-python", "utf-8")
        self.set_dirty(False)
        try:
            self._last_disk_mtime = os.path.getmtime(path)
        except OSError:
            self._last_disk_mtime = None

    def save_to_disk(self, path=None):
        import os
        if path is not None:
            self.path = path
        if not self.path:
            return False
        text = self.editor.toPlainText()
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(text)
        self.set_dirty(False)
        try:
            self._last_disk_mtime = os.path.getmtime(self.path)
        except OSError:
            self._last_disk_mtime = None
        return True

    # --------- external changes ----------
    def has_external_change(self):
        """
        Returns True if file exists on disk and its mtime changed
        since last save/load.
        """
        import os
        if not self.path:
            return False
        try:
            mtime = os.path.getmtime(self.path)
        except OSError:
            return False
        if self._last_disk_mtime is None:
            self._last_disk_mtime = mtime
            return False
        return mtime != self._last_disk_mtime

class TerminalWidget(QtWidgets.QPlainTextEdit):
    """
    Simple command panel with:
    - colored stdout/stderr/system messages
    - auto-scroll
    - right-click actions (clear, kill run)
    - error-click detection (File "...", line ...)
    """
    error_clicked = QtCore.pyqtSignal(str, int)  # emitted when clicking traceback lines

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)

        font = QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont)
        self.setFont(font)

        palette = self.palette()
        palette.setColor(QtGui.QPalette.Base, QtGui.QColor("#202020"))
        palette.setColor(QtGui.QPalette.Text, QtGui.QColor("#DDDDDD"))
        self.setPalette(palette)

        # Right-click menu
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

    # ---------------------------------------------------------
    # Write colored messages (stdout, stderr, system)
    # ---------------------------------------------------------
    def append_message(self, text: str, kind: str = "stdout"):
        cursor = self.textCursor()
        cursor.movePosition(QtGui.QTextCursor.End)

        fmt = QtGui.QTextCharFormat()

        if kind == "stdout":
            fmt.setForeground(QtGui.QBrush(QtGui.QColor("#DDDDDD")))
        elif kind == "stderr":
            fmt.setForeground(QtGui.QBrush(QtGui.QColor("#FF5555")))
        else:  # system/info
            fmt.setForeground(QtGui.QBrush(QtGui.QColor("#88CCFF")))

        cursor.setCharFormat(fmt)
        cursor.insertText(text)

        # Auto scroll
        self.setTextCursor(cursor)
        self.ensureCursorVisible()

    def clear(self):
        super().clear()

    # ---------------------------------------------------------
    # Right-click menu
    # ---------------------------------------------------------
    def _show_context_menu(self, pos):
        menu = QtWidgets.QMenu(self)

        clear_act = QtWidgets.QAction("Clear Terminal", self)
        kill_act = QtWidgets.QAction("Kill Running Code", self)

        clear_act.triggered.connect(self.clear)

        # Find MiniIDEWidget to call _kill_run()
        parent = self.parent()
        while parent and not hasattr(parent, "_kill_run"):
            parent = parent.parent()

        if parent:
            kill_act.triggered.connect(parent._kill_run)

        menu.addAction(clear_act)
        menu.addAction(kill_act)
        menu.exec_(self.mapToGlobal(pos))

class FileExplorer(QtWidgets.QTreeView):
    """
    Interactive folder explorer with basic file operations.
    """
    file_open_requested = QtCore.pyqtSignal(str)

    def __init__(self, root_path, parent=None):
        super().__init__(parent)
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.on_context_menu)

        self.model = QtWidgets.QFileSystemModel(self)
        self.model.setRootPath(root_path)
        self.setModel(self.model)
        self.setRootIndex(self.model.index(root_path))
        self.setColumnWidth(0, 250)
        self.setHeaderHidden(True)

        self.doubleClicked.connect(self.on_double_clicked)

        # clipboard for copy/cut
        self._clipboard_path = None
        self._clipboard_cut = False

    def current_path(self):
        index = self.currentIndex()
        if not index.isValid():
            return None
        return self.model.filePath(index)

    def on_double_clicked(self, index):
        if not index.isValid():
            return
        path = self.model.filePath(index)
        if QtCore.QFileInfo(path).isFile():
            self.file_open_requested.emit(path)

    # ---------- context menu ----------
    def on_context_menu(self, pos):
        index = self.indexAt(pos)
        menu = QtWidgets.QMenu(self)

        new_file_act = menu.addAction("New File")
        new_folder_act = menu.addAction("New Folder")
        menu.addSeparator()
        rename_act = menu.addAction("Rename")
        delete_act = menu.addAction("Delete")
        menu.addSeparator()
        copy_act = menu.addAction("Copy")
        cut_act = menu.addAction("Cut")
        paste_act = menu.addAction("Paste")

        action = menu.exec_(self.viewport().mapToGlobal(pos))
        if action is None:
            return

        if not index.isValid():
            base_dir = self.model.rootPath()
        else:
            path = self.model.filePath(index)
            info = QtCore.QFileInfo(path)
            base_dir = path if info.isDir() else info.absolutePath()

        if action == new_file_act:
            self._new_file(base_dir)
        elif action == new_folder_act:
            self._new_folder(base_dir)
        elif action == rename_act and index.isValid():
            self.edit(index)
        elif action == delete_act and index.isValid():
            self._delete_path(self.model.filePath(index))
        elif action == copy_act and index.isValid():
            self._clipboard_path = self.model.filePath(index)
            self._clipboard_cut = False
        elif action == cut_act and index.isValid():
            self._clipboard_path = self.model.filePath(index)
            self._clipboard_cut = True
        elif action == paste_act:
            self._paste_into(base_dir)

    def _new_file(self, base_dir):
        name, ok = QtWidgets.QInputDialog.getText(self, "New File", "File name:")
        if not ok or not name:
            return
        path = QtCore.QDir(base_dir).filePath(name)
        if QtCore.QFileInfo(path).exists():
            QtWidgets.QMessageBox.warning(self, "Error", "File already exists")
            return
        file = QtCore.QFile(path)
        if not file.open(QtCore.QIODevice.WriteOnly):
            QtWidgets.QMessageBox.warning(self, "Error", "Cannot create file")
            return
        file.close()

    def _new_folder(self, base_dir):
        name, ok = QtWidgets.QInputDialog.getText(self, "New Folder", "Folder name:")
        if not ok or not name:
            return
        dir_ = QtCore.QDir(base_dir)
        if not dir_.mkdir(name):
            QtWidgets.QMessageBox.warning(self, "Error", "Cannot create folder")

    def _delete_path(self, path):
        info = QtCore.QFileInfo(path)
        if not QtWidgets.QMessageBox.question(
            self,
            "Delete",
            f"Delete '{path}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
        ) == QtWidgets.QMessageBox.Yes:
            return
        if info.isDir():
            dir_ = QtCore.QDir(path)
            if not dir_.removeRecursively():
                QtWidgets.QMessageBox.warning(self, "Error", "Cannot delete folder")
        else:
            if not QtCore.QFile.remove(path):
                QtWidgets.QMessageBox.warning(self, "Error", "Cannot delete file")

    def _paste_into(self, base_dir):
        import shutil

        if not self._clipboard_path:
            return
        src = self._clipboard_path
        name = QtCore.QFileInfo(src).fileName()
        dst = QtCore.QDir(base_dir).filePath(name)

        if QtCore.QFileInfo(dst).exists():
            QtWidgets.QMessageBox.warning(self, "Error", "Destination already exists")
            return
        try:
            if self._clipboard_cut:
                shutil.move(src, dst)
            else:
                if QtCore.QFileInfo(src).isDir():
                    shutil.copytree(src, dst)
                else:
                    shutil.copy2(src, dst)
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Error", f"Copy/Move failed: {e}")

class MiniIDE(QtWidgets.QMainWindow):
    """
    Fully featured IDE-like widget:
    - File explorer
    - Tabbed pyqode editors
    - Dirty indicator and close/save prompts
    - External file change detection
    - Run selection / run file in background thread
    - Integrated terminal-like output panel
    - Menu bar directly inside the widget (no mainwindow needed)
    """
    file_saved = QtCore.pyqtSignal()
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Embedded PyQt Mini IDE")
        self.resize(1200, 800)

        self.root_path = PROJECT_ROOT
        self._runner = None
        self._force_close = False
        self.var_explorer = VariableExplorer(self)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        main_layout = QtWidgets.QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # ===========================================
        # MENUBAR INSIDE WIDGET (NOT MAINWINDOW)
        # ===========================================
        self.menubar = QtWidgets.QMenuBar(self)
        main_layout.addWidget(self.menubar)

        # -------- FILE MENU --------
        file_menu = self.menubar.addMenu("&File")

        open_act = QtWidgets.QAction("Open...", self)
        open_act.setShortcut("Ctrl+O")
        open_act.triggered.connect(self._open_dialog)

        save_act = QtWidgets.QAction("Save", self)
        save_act.setShortcut("Ctrl+S")
        save_act.triggered.connect(self.save_current)

        save_as_act = QtWidgets.QAction("Save As...", self)
        save_as_act.triggered.connect(self.save_current_as)

        close_tab_act = QtWidgets.QAction("Close Tab", self)
        close_tab_act.setShortcut("Ctrl+W")
        close_tab_act.triggered.connect(lambda: self.close_tab(self.tabs.currentIndex()))

        file_menu.addAction(open_act)
        file_menu.addAction(save_act)
        file_menu.addAction(save_as_act)
        file_menu.addSeparator()
        file_menu.addAction(close_tab_act)

        # -------- RUN MENU --------
        run_menu = self.menubar.addMenu("&Run")

        run_sel_act = QtWidgets.QAction("Run Selection", self)
        run_sel_act.setShortcut("F9")
        run_sel_act.triggered.connect(self.run_selection)

        run_file_act = QtWidgets.QAction("Run File", self)
        run_file_act.setShortcut("F5")
        run_file_act.triggered.connect(self.run_file)

        run_menu.addAction(run_sel_act)
        run_menu.addAction(run_file_act)

        # -------- TERMINAL MENU --------
        term_menu = self.menubar.addMenu("&Terminal")

        self.term_toggle_act = QtWidgets.QAction("Show Terminal", self)
        self.term_toggle_act.setCheckable(True)
        self.term_toggle_act.setChecked(True)
        self.term_toggle_act.triggered.connect(self.toggle_terminal)

        term_menu.addAction(self.term_toggle_act)

        clear_term_act = QtWidgets.QAction("Clear Terminal", self)
        term_menu.addAction(clear_term_act)

        kill_term_act = QtWidgets.QAction("Kill Run", self)
        kill_term_act.triggered.connect(self._kill_run)
        term_menu.addAction(kill_term_act)

        view_menu = self.menubar.addMenu("&View")
        self.act_show_var_explorer = QtWidgets.QAction("Variable Explorer", self)
        self.act_show_var_explorer.setCheckable(True)
        self.act_show_var_explorer.setChecked(False)
        self.act_show_var_explorer.triggered.connect(
            lambda checked: self.var_explorer.dock.setVisible(checked)
        )
        view_menu.addAction(self.act_show_var_explorer)
        self.var_explorer.dock.visibilityChanged.connect(
            lambda v: self.act_show_var_explorer.setChecked(v)
        )

        # NEW TOOLBAR (for comment/uncomment)
        comment_toolbar = QtWidgets.QToolBar("Edit Tools")
        comment_toolbar.setFixedHeight(22)  # adjust size here
        comment_toolbar.setIconSize(QtCore.QSize(20, 20))  # adjust size here
        main_layout.addWidget(comment_toolbar)

        comment_act = QtWidgets.QAction("#", self)
        comment_act.setToolTip("Comment selection")

        uncomment_act = QtWidgets.QAction("U#", self)
        uncomment_act.setToolTip("Uncomment selection")

        toggle_comment_act = QtWidgets.QAction("T#", self)
        toggle_comment_act.setToolTip("Toggle comment (Ctrl+Ö)")

        # Keyboard shortcut: Ctrl+Ö (Turkish layout)
        toggle_comment_act.setShortcut("Ctrl+Ö")

        comment_act.triggered.connect(self.comment_selection)
        uncomment_act.triggered.connect(self.uncomment_selection)
        toggle_comment_act.triggered.connect(self.toggle_comment_selection)

        comment_toolbar.addAction(comment_act)
        comment_toolbar.addAction(uncomment_act)
        comment_toolbar.addAction(toggle_comment_act)

        # ===========================================
        # MAIN SPLITTER (Explorer | Editors + Terminal)
        # ===========================================
        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        main_layout.addWidget(splitter, 1)

        # ---------- LEFT: FILE EXPLORER ----------
        self.explorer = FileExplorer(self.root_path)
        splitter.addWidget(self.explorer)

        # ---------- RIGHT: editor tabs + terminal ----------
        self.right_splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        splitter.addWidget(self.right_splitter)

        # TABS
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.right_splitter.addWidget(self.tabs)

        self.tabs.tabBar().setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tabs.tabBar().customContextMenuRequested.connect(self._show_tab_context_menu)
        self.tabs.setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                        QtWidgets.QSizePolicy.Expanding)
        self.tabs.currentChanged.connect(lambda _: self.save_session())

        # TERMINAL
        self.terminal = TerminalWidget()
        self.right_splitter.addWidget(self.terminal)
        clear_term_act.triggered.connect(self.terminal.clear)

        self.right_splitter.setSizes([600, 150])

        # stretch
        self.right_splitter.setStretchFactor(0, 3)
        self.right_splitter.setStretchFactor(1, 1)

        # Splitter stretch
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 4)

        # Initial widths
        splitter.setSizes([200, 800])

        # Explorer -> open file
        self.explorer.file_open_requested.connect(self.open_file)

        self.restore_session()

        # ===========================================
        # FILE CHANGE POLLING TIMER
        # ===========================================
        self._poll_timer = QtCore.QTimer(self)
        self._poll_timer.setInterval(1500)
        self._poll_timer.timeout.connect(self._poll_external_changes)
        self._poll_timer.start()

    def save_session(self):
        """
        Save open files + cursor positions to SESSION_FILE.
        Same structure and behavior as PythonIDE's session mechanism.
        """
        data = {"files": []}

        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if not isinstance(tab, EditorTab):
                continue

            path = getattr(tab, "path", None)
            if not path or not os.path.exists(path):
                continue  # skip untitled or removed files

            editor = tab.editor
            cursor = editor.textCursor()

            data["files"].append({
                "path": path,
                "position": cursor.position(),
                "modified": tab.is_dirty,   # stored but NOT used in restore (same as PythonIDE)
            })

        # write JSON safely
        try:
            save_json(IDE_HISTORY_PATH, data)
        except Exception as e:
            print("⚠️ Failed to save MiniIDE session:", e)

    def restore_session(self):
        """
        Restore open tabs and cursor positions from SESSION_FILE.
        Same behaviour as PythonIDE:
        - restores only existing files
        - opens them in the same order
        - restores cursor position safely
        - marks them as NOT dirty after load
        - ignores modified flag (only for UI in future)
        """
        try:
            data = load_json(IDE_HISTORY_PATH)
        except Exception as e:
            print("⚠️ Failed to restore MiniIDE session:", e)
            return

        files = data.get("files", [])
        for entry in files:
            path = entry.get("path")
            pos  = entry.get("position", 0)

            if not path or not os.path.exists(path):
                continue

            # open tab
            self.open_file(path)
            tab = self.current_tab()

            # restore cursor
            if tab:
                editor = tab.editor
                text = editor.toPlainText()
                p = min(pos, len(text))

                cursor = editor.textCursor()
                cursor.setPosition(p)
                editor.setTextCursor(cursor)
                editor.ensureCursorVisible()

            # mark restored file as clean (same as PythonIDE)
            if tab:
                tab.set_dirty(False)

    # ------------- tab helpers -------------
    def _create_tab_for_path(self, path):
        tab = EditorTab(path)
        tab.load_from_disk(path)
        tab.modified_changed.connect(lambda dirty, t=tab: self._update_tab_title(t))
        index = self.tabs.addTab(tab, "")
        self.tabs.setCurrentIndex(index)
        self._update_tab_title(tab)
        return tab

    def _update_tab_title(self, tab: EditorTab):
        idx = self.tabs.indexOf(tab)
        if idx == -1:
            return
        name = tab.path if tab.path else "untitled.py"
        import os
        title = os.path.basename(name)
        if tab.is_dirty:
            title = "*" + title
        self.tabs.setTabText(idx, title)
        self.tabs.setTabToolTip(idx, name)

    def current_tab(self) -> EditorTab:
        w = self.tabs.currentWidget()
        if isinstance(w, EditorTab):
            return w
        return None

    def _get_current_editor(self):
        tab = self.current_tab()
        if not tab:
            return None
        return tab.editor
    
    # ------------- file operations -------------
    def open_file(self, path):
        # if already open, just focus tab
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if isinstance(tab, EditorTab) and tab.path == path:
                self.tabs.setCurrentIndex(i)
                return
        self._create_tab_for_path(path)
        self.save_session()

    def _open_dialog(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open file", self.root_path, "Python files (*.py);;All files (*.*)"
        )
        if path:
            self.open_file(path)

    def save_current(self):
        tab = self.current_tab()
        if not tab:
            return
        if not tab.path:
            return self.save_current_as()
        if tab.save_to_disk():
            self._append_system(f"Saved {tab.path}\n")
            self.file_saved.emit()
            self.save_session()

    def save_current_as(self):
        tab = self.current_tab()
        if not tab:
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save as", tab.path or self.root_path, "Python files (*.py);;All files (*.*)"
        )
        if not path:
            return False
        if tab.save_to_disk(path):
            self._append_system(f"Saved {tab.path}\n")
            self._update_tab_title(tab)
            self.file_saved.emit()
            self.save_session()
            return True
        return False

    def close_tab(self, index):
        tab = self.tabs.widget(index)
        if isinstance(tab, EditorTab):
            if tab.is_dirty:
                resp = QtWidgets.QMessageBox.question(
                    self,
                    "Unsaved changes",
                    "This file has unsaved changes. Save before closing?",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No | QtWidgets.QMessageBox.Cancel,
                )
                if resp == QtWidgets.QMessageBox.Cancel:
                    return
                if resp == QtWidgets.QMessageBox.Yes:
                    if not tab.path:
                        if not self.save_current_as():
                            return
                    else:
                        tab.save_to_disk()
            self.tabs.removeTab(index)
            tab.deleteLater()
    
    # ------------- external changes polling -------------
    def _poll_external_changes(self):
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if not isinstance(tab, EditorTab):
                continue
            if tab.has_external_change():
                # If tab dirty, ask what to do
                if tab.is_dirty:
                    resp = QtWidgets.QMessageBox.question(
                        self,
                        "File changed on disk",
                        f"'{tab.path}' was modified on disk.\nReload and lose unsaved changes?",
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    )
                    if resp != QtWidgets.QMessageBox.Yes:
                        # ignore but update stored mtime to avoid repeated prompts
                        tab._last_disk_mtime = None
                        continue
                # reload from disk
                tab.load_from_disk(tab.path)
                self._append_system(f"Reloaded {tab.path} because it changed on disk\n")

    # ------------- run code -------------
    def run_selection(self):
        tab = self.current_tab()
        if not tab:
            return

        editor = tab.editor
        cursor = editor.textCursor()

        # --- If nothing selected, run the current line ---
        if cursor.hasSelection():
            text = cursor.selectedText()
        else:
            cursor.select(QtGui.QTextCursor.LineUnderCursor)
            text = cursor.selectedText()

        code = text.replace("\u2029", "\n")

        # --- Normalize indentation (critical for running inside classes/methods) ---
        # Split into lines
        lines = code.split("\n")

        # Remove completely empty leading/trailing lines
        while lines and not lines[0].strip():
            lines.pop(0)
        while lines and not lines[-1].strip():
            lines.pop()

        if not lines:
            return

        # Compute the minimal indentation of non-empty lines
        def leading_spaces(s):
            return len(s) - len(s.lstrip(" "))

        indents = [leading_spaces(line) for line in lines if line.strip()]
        min_indent = min(indents) if indents else 0

        # Remove minimum indent from all lines
        normalized = [line[min_indent:] if line.strip() else "" for line in lines]

        final_code = "\n".join(normalized)

        # --- Run the cleaned code ---
        self._run_code(final_code)

    def run_file(self):
        tab = self.current_tab()
        if not tab:
            return
        code = tab.editor.toPlainText()
        self._run_code(code)

    def _run_code(self, code):
        if self._runner is not None and self._runner.isRunning():
            QtWidgets.QMessageBox.warning(self, "Running", "A script is already running.")
            return
        self.ensure_terminal_visible()
        self._append_system("\n=== Running code ===\n")
        tab = self.current_tab()
        self._runner = CodeRunner(code, globals_env=tab.exec_env)
        self._runner.output.connect(self._on_runner_output)
        self._runner.update_vars.connect(self.var_explorer.update)
        self._runner.finished_ok.connect(
            lambda: (self._append_system("=== Finished OK ===\n"))
        )
        self._runner.finished_err.connect(lambda err: self._append_system("=== Finished with errors ===\n"))
        self._runner.start()

    def _on_runner_output(self, kind, text):
        self.terminal.append_message(text, kind)

    def _append_system(self, text):
        self.terminal.append_message(text, "system")

    # ---------------------------
    # Comment / Uncomment logic
    # ---------------------------

    def _get_selected_lines(self, editor):
        cursor = editor.textCursor()

        if cursor.hasSelection():
            start = cursor.selectionStart()
            end = cursor.selectionEnd()
        else:
            start = cursor.position()
            end = cursor.position()

        # Expand selection to full lines
        cursor.setPosition(start)
        cursor.movePosition(cursor.StartOfLine)

        start_line = cursor.blockNumber()

        cursor.setPosition(end)
        if cursor.atBlockStart():
            end_line = cursor.blockNumber()
        else:
            cursor.movePosition(cursor.EndOfLine)
            end_line = cursor.blockNumber()

        return start_line, end_line

    def comment_selection(self):
        editor = self._get_current_editor()
        if not editor:
            return

        start_line, end_line = self._get_selected_lines(editor)

        doc = editor.document()
        cursor = editor.textCursor()

        cursor.beginEditBlock()
        for line in range(start_line, end_line + 1):
            block = doc.findBlockByNumber(line)
            text = block.text()
            if not text.lstrip().startswith("#"):  # avoid double comment
                indent = len(text) - len(text.lstrip())
                new_text = " " * indent + "# " + text[indent:]
                cursor.setPosition(block.position())
                cursor.movePosition(cursor.EndOfBlock, cursor.KeepAnchor)
                cursor.insertText(new_text)
        cursor.endEditBlock()

    def uncomment_selection(self):
        editor = self._get_current_editor()
        if not editor:
            return

        start_line, end_line = self._get_selected_lines(editor)

        doc = editor.document()
        cursor = editor.textCursor()

        cursor.beginEditBlock()
        for line in range(start_line, end_line + 1):
            block = doc.findBlockByNumber(line)
            text = block.text()
            stripped = text.lstrip()

            if stripped.startswith("#"):
                indent = len(text) - len(stripped)
                # remove "# " or "#"
                if stripped.startswith("# "):
                    new_text = " " * indent + stripped[2:]
                else:
                    new_text = " " * indent + stripped[1:]

                cursor.setPosition(block.position())
                cursor.movePosition(cursor.EndOfBlock, cursor.KeepAnchor)
                cursor.insertText(new_text)
        cursor.endEditBlock()

    def toggle_comment_selection(self):
        editor = self._get_current_editor()
        if not editor:
            return

        start_line, end_line = self._get_selected_lines(editor)
        doc = editor.document()

        # Decide mode based on first selected line
        first_line = doc.findBlockByNumber(start_line).text()
        first_is_commented = first_line.lstrip().startswith("#")

        if first_is_commented:
            self.uncomment_selection()
        else:
            self.comment_selection()
    
    # ---------------------------
    # Terminal
    # ---------------------------

    def toggle_terminal(self, checked):
        """
        VSCode-style Show/Hide terminal.
        - When hidden: terminal collapses completely.
        - When shown: restored to last used height.
        """

        # splitter sizes: [tabs, terminal]
        sizes = self.right_splitter.sizes()

        if checked:
            # Show terminal — restore last size or default
            restore_size = getattr(self, "_last_terminal_height", 200)
            tab_size = max(100, self.right_splitter.height() - restore_size)
            self.right_splitter.setSizes([tab_size, restore_size])
            self.term_toggle_act.setText("Hide Terminal")
        else:
            # Hide terminal — remember last terminal height
            self._last_terminal_height = sizes[1]
            self.right_splitter.setSizes([sizes[0] + sizes[1], 0])
            self.term_toggle_act.setText("Show Terminal")
    
    def ensure_terminal_visible(self):
        """
        Makes sure terminal is shown before running any code.
        """
        if not self.term_toggle_act.isChecked():
            # Simulate clicking "Show Terminal"
            self.term_toggle_act.setChecked(True)
            self.toggle_terminal(True)

        # Scroll terminal to bottom (if it supports it)
        try:
            self.terminal.ensureCursorVisible()
        except:
            pass
    
    def _kill_run(self):
        if self._runner and self._runner.isRunning():
            self._runner.terminate()
            self.terminal.append_message("\n[RUN TERMINATED]\n", "system")

    # ---------------------------
    # Variable Explorer
    # ---------------------------

    # ------------- close handling -------------
    def maybe_close(self):
        """
        Ask to save dirty files. Return True if it's ok to close.
        """
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if not isinstance(tab, EditorTab):
                continue
            if tab.is_dirty:
                self.tabs.setCurrentIndex(i)
                resp = QtWidgets.QMessageBox.question(
                    self,
                    "Unsaved changes",
                    f"File '{tab.path or 'untitled.py'}' has unsaved changes. Save?",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No | QtWidgets.QMessageBox.Cancel,
                )
                if resp == QtWidgets.QMessageBox.Cancel:
                    return False
                if resp == QtWidgets.QMessageBox.Yes:
                    if not tab.path:
                        if not self.save_current_as():
                            return False
                    else:
                        tab.save_to_disk()
        return True
    
    def _show_tab_context_menu(self, pos):
        """
        Right-click menu for tab bar (top), includes Run Selection (F9).
        """
        menu = QtWidgets.QMenu(self)

        run_sel_act = QtWidgets.QAction("Run Selection", self)
        run_sel_act.setShortcut("F9")
        run_sel_act.triggered.connect(self.run_selection)

        run_file_act = QtWidgets.QAction("Run File", self)
        run_file_act.setShortcut("F5")
        run_file_act.triggered.connect(self.run_file)

        close_tab_act = QtWidgets.QAction("Close Tab", self)
        close_tab_act.triggered.connect(lambda: self.close_tab(self.tabs.currentIndex()))

        close_others_act = QtWidgets.QAction("Close Other Tabs", self)
        close_others_act.triggered.connect(self._close_other_tabs)

        close_all_act = QtWidgets.QAction("Close All Tabs", self)
        close_all_act.triggered.connect(self._close_all_tabs)

        # Add actions
        menu.addAction(run_sel_act)
        menu.addAction(run_file_act)
        menu.addSeparator()
        menu.addAction(close_tab_act)
        menu.addAction(close_others_act)
        menu.addSeparator()
        menu.addAction(close_all_act)

        menu.exec_(self.tabs.tabBar().mapToGlobal(pos))
    
    def _close_other_tabs(self):
        current = self.tabs.currentIndex()
        for i in reversed(range(self.tabs.count())):
            if i != current:
                self.close_tab(i)

    def _close_all_tabs(self):
        for i in reversed(range(self.tabs.count())):
            self.close_tab(i)

    def cleanup_before_exit(self):
        """
        Stop worker threads and global pyqode processes.
        Editors' backends are already stopped in close_tab().
        """

        # 1) Stop code runner
        if self._runner and self._runner.isRunning():
            self._runner.terminate()
            self._runner.wait()

        # 3) Stop polling timer
        try:
            self._poll_timer.stop()
        except:
            pass

        # 5) Garbage collect Qt wrappers
        import gc
        gc.collect()

    def closeEvent(self, event):
        """
        When closing the whole IDE window:
        1) Ask about dirty tabs
        2) Actually CLOSE all tabs (so close_tab() runs)
        3) Then cleanup threads
        """
        # Step 1: Ask user for dirty tabs
        if not self._force_close:
            if not self.maybe_close():
                event.ignore()
                return
        
        # Save session BEFORE clean-up
        self.save_session()

        # Step 3: Cleanup background workers
        self.cleanup_before_exit()

        if self.var_explorer.dock.isFloating():
            self.var_explorer.dock.close()
        event.accept()
