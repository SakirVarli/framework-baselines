from __future__ import annotations

import importlib
import inspect
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable


class Direction(str, Enum):
    RX = "RX"
    TX = "TX"


@dataclass(frozen=True)
class ParseResult:
    name: str
    data: dict[str, Any] | bytes
    parsed: bool
    status: str
    error: str = ""
    duration_ns: int = 0


class ParserRuntime:
    def __init__(self, config: dict):
        self.config = config
        self.function: Callable | None = None
        if config.get("enabled"):
            module = importlib.import_module(config["module"])
            self.function = getattr(module, config["function"])
            if not callable(self.function):
                raise TypeError("Configured parser is not callable")
            signature = inspect.signature(self.function)
            if len(signature.parameters) != 2:
                raise TypeError("Parser must accept exactly two parameters: bytes and direction")

    def parse(self, message: bytes, direction: Direction) -> ParseResult:
        """Parse the exact complete bytes sent or reconstructed on receive."""
        if self.function is None:
            return ParseResult("Unknown", bytes(message), False, "not_configured")
        started = time.perf_counter_ns()
        try:
            data = self.function(bytes(message), direction)
            if not isinstance(data, dict):
                raise TypeError(f"Parser returned {type(data).__name__}; expected dict")
            name_key = self.config.get("name_key", "Name")
            name = data.get(name_key, "Unknown")
            name = "Unknown" if name is None or str(name).strip() == "" else str(name)
            return ParseResult(name, data, True, "ok", duration_ns=time.perf_counter_ns() - started)
        except BaseException as error:
            return ParseResult(
                "Unknown",
                bytes(message),
                False,
                "error",
                error=f"{type(error).__name__}: {error}"[:1000],
                duration_ns=time.perf_counter_ns() - started,
            )
