from __future__ import annotations

import copy
import json
import re
import time
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from app.utils import COMMUNICATION_HUB_SETTINGS, PROJECT_ROOT, load_json, save_json

from .protocol_insights import (
    ProtocolInsightsPanel,
    default_protocol_insight_config, default_protocol_insight_source,
    normalize_protocol_insight_config, normalize_protocol_insight_source,
)
from .config import default_session_config, normalize_session_config
from .controller import SessionController
from .excel_export import export_messages_excel
from .protocol_insight_runtime import (
    default_protocol_insight_runtime_config,
    normalize_protocol_insight_runtime_config,
)
from .protocol_insight_output import inspect_protocol_insight_workbook
from .protocol_insight_service import (
    ProtocolInsightServiceController,
    normalize_protocol_insight_service_config,
)
from .local_time import local_display, local_iso, local_now_iso, timestamp_ns


TIMESTAMP_FIELDS = {"timestamp", "first_timestamp", "last_timestamp"}


def _local_timestamp_text(value, *, include_zone=True):
    return local_display(value, include_zone=include_zone)


def _timestamp_sort_ns(value, explicit=None):
    try:
        return int(explicit) if explicit not in {None, ""} else timestamp_ns(value)
    except (TypeError, ValueError, OverflowError):
        return 0


def _local_query_value(value):
    if isinstance(value, (list, tuple)):
        return [_local_query_value(item) for item in value]
    if isinstance(value, str):
        return _local_timestamp_text(value, include_zone=False)
    return value


def _local_stored_query_value(value):
    """Normalize timestamp text entered in the UI as offset-aware local time."""
    if isinstance(value, (list, tuple)):
        return [_local_stored_query_value(item) for item in value]
    if not isinstance(value, str):
        return value
    try:
        return local_iso(value)
    except (TypeError, ValueError):
        return value


class _AsyncCall(QtCore.QThread):
    succeeded = QtCore.pyqtSignal(object)
    failed = QtCore.pyqtSignal(str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self.function = function

    def run(self):
        try:
            self.succeeded.emit(self.function())
        except BaseException:
            self.failed.emit(traceback.format_exc())


class _DoubleClickButton(QtWidgets.QPushButton):
    activated = QtCore.pyqtSignal()
    doubleClicked = QtCore.pyqtSignal()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._single_click_timer = QtCore.QTimer(self)
        self._single_click_timer.setSingleShot(True)
        self._single_click_timer.timeout.connect(self.activated)
        self.clicked.connect(self._queue_single_click)

    def _queue_single_click(self, _checked=False):
        application = QtWidgets.QApplication.instance()
        interval = application.doubleClickInterval() if application is not None else 400
        self._single_click_timer.start(interval)

    def mouseDoubleClickEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self._single_click_timer.stop()
            self.doubleClicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


class _CheckableHeaderView(QtWidgets.QHeaderView):
    checkStateChanged = QtCore.pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(QtCore.Qt.Horizontal, parent)
        self.checkbox = QtWidgets.QCheckBox(self.viewport())
        self.checkbox.setTristate(True)
        self.checkbox.setCheckState(QtCore.Qt.Unchecked)
        self.checkbox.setCursor(QtCore.Qt.PointingHandCursor)
        self.checkbox.setToolTip("Check or clear every conflict rule.")
        self.checkbox.setAccessibleName("Select all conflict rules")
        self.checkbox.installEventFilter(self)
        self.sectionResized.connect(lambda *_args: self._position_checkbox())
        self.sectionMoved.connect(lambda *_args: self._position_checkbox())
        self.geometriesChanged.connect(self._position_checkbox)

    def checkState(self):
        return self.checkbox.checkState()

    def setCheckState(self, state):
        state = QtCore.Qt.CheckState(state)
        if self.checkbox.checkState() == state:
            return
        self.checkbox.blockSignals(True)
        self.checkbox.setCheckState(state)
        self.checkbox.blockSignals(False)

    def _position_checkbox(self):
        if self.isSectionHidden(0):
            self.checkbox.hide()
            return
        size = self.checkbox.sizeHint()
        x = self.sectionViewportPosition(0) + max(0, (self.sectionSize(0) - size.width()) // 2)
        y = max(0, (self.height() - size.height()) // 2)
        self.checkbox.setGeometry(x, y, size.width(), size.height())
        self.checkbox.show()
        self.checkbox.raise_()

    def eventFilter(self, watched, event):
        activate = (
            watched is self.checkbox
            and (
                (event.type() == QtCore.QEvent.MouseButtonPress and event.button() == QtCore.Qt.LeftButton)
                or (event.type() == QtCore.QEvent.KeyPress and event.key() in {QtCore.Qt.Key_Space, QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter})
            )
        )
        if activate:
            state = QtCore.Qt.Unchecked if self.checkbox.checkState() == QtCore.Qt.Checked else QtCore.Qt.Checked
            self.setCheckState(state)
            self.checkStateChanged.emit(int(state))
            event.accept()
            return True
        return super().eventFilter(watched, event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_checkbox()

    def showEvent(self, event):
        super().showEvent(event)
        self._position_checkbox()


class SessionConfigDialog(QtWidgets.QDialog):
    def __init__(self, config=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Communication Session Configuration")
        self.setWindowFlag(QtCore.Qt.WindowContextHelpButtonHint, True)
        self._configuration_help_pending = False
        self.resize(980, 780)
        self.original = normalize_session_config(config or default_session_config())
        root = QtWidgets.QVBoxLayout(self)
        self.tabs = QtWidgets.QTabWidget()
        root.addWidget(self.tabs)
        self.basic = QtWidgets.QWidget()
        self.framing = QtWidgets.QWidget()
        self.storage = QtWidgets.QWidget()
        self.advanced = QtWidgets.QWidget()
        self.tabs.addTab(self.basic, "Session and Transport")
        self.tabs.addTab(self.framing, "Receive Framing and Parser")
        self.tabs.addTab(self.storage, "Storage")
        self.tabs.addTab(self.advanced, "Advanced JSON")
        self.tabs.setTabToolTip(0, "Session identity and the commonly used settings for the selected transport protocol.")
        self.tabs.setTabToolTip(1, "Receive-only message boundaries, complete-message parser, and decoded header metadata.")
        self.tabs.setTabToolTip(2, "In-memory table batching, row retention, update-on-conflict rules, and disk persistence.")
        self.tabs.setTabToolTip(3, "Complete normalized session configuration, including uncommon transport options.")
        self._build_basic()
        self._build_framing()
        self._build_storage()
        advanced_layout = QtWidgets.QVBoxLayout(self.advanced)
        advanced_note = QtWidgets.QLabel("The complete validated session configuration. Keep this tab selected when pressing OK to apply manual JSON edits.")
        advanced_note.setWordWrap(True); advanced_note.setToolTip("This includes uncommon transport options plus normalized storage and persistence configuration.")
        advanced_layout.addWidget(advanced_note)
        self.json_edit = QtWidgets.QPlainTextEdit()
        self.json_edit.setToolTip("Edit advanced options directly. JSON is validated and normalized before the session configuration is accepted.")
        self.json_edit.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        advanced_layout.addWidget(self.json_edit)
        self.tabs.currentChanged.connect(self._tab_changed)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        self._load(self.original)

    def event(self, event):
        if event.type() == QtCore.QEvent.EnterWhatsThisMode:
            QtWidgets.QWhatsThis.leaveWhatsThisMode()
            if not self._configuration_help_pending:
                self._configuration_help_pending = True
                QtCore.QTimer.singleShot(0, self._open_configuration_help_from_title_bar)
            return True
        return super().event(event)

    def _open_configuration_help_from_title_bar(self):
        self._configuration_help_pending = False
        self._show_configuration_help()

    @staticmethod
    def _configuration_help_html():
        return '''
<html><head><style>
body { font-family: sans-serif; line-height: 1.35; }
h1 { font-size: 20px; } h2 { font-size: 16px; margin-top: 22px; }
h3 { font-size: 14px; margin-top: 16px; }
pre { background: #eef1f4; color: #20252b; border: 1px solid #c8cdd2; padding: 9px; white-space: pre-wrap; }
code { background: #eef1f4; color: #20252b; padding: 1px 3px; }
.warning { background: #fff4df; color: #663c00; border: 1px solid #e3bc70; padding: 9px; }
.safe { background: #eaf5ec; color: #174d24; border: 1px solid #91c49c; padding: 9px; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #c8cdd2; padding: 5px; text-align: left; vertical-align: top; }
</style></head><body>
<h1>Communication Session configuration reference</h1>
<p>The first three tabs provide guarded editors for common transport, receive-framing, parser, in-memory storage, conflict, and persistence settings. The <b>Advanced JSON</b> tab exposes the complete normalized session object.</p>

<h2>Safe Advanced JSON workflow</h2>
<div class="warning"><b>Important:</b> Opening the Advanced JSON tab regenerates its contents from the form. Keep Advanced JSON selected when pressing OK. If you leave it, change form fields, and reopen it, unsaved manual JSON edits are replaced by a newly generated normalized configuration.</div>
<ol>
<li>Stop the session before editing it.</li>
<li>Configure the common fields on the first two tabs.</li>
<li>Open Advanced JSON. This produces a complete object with defaults added.</li>
<li>Copy the JSON somewhere safe before making a large manual change.</li>
<li>Edit only the required value or add a supported key in its documented parent object.</li>
<li>Keep Advanced JSON selected and press OK.</li>
<li>The complete object is parsed, validated, and normalized. Invalid JSON or invalid framing/parser/persistence values are rejected without saving.</li>
</ol>
<div class="safe">When a future application version introduces a new default setting, it will appear automatically in the regenerated Advanced JSON object. Add only settings documented by the installed version. Unknown keys may be preserved but are ignored by the worker.</div>

<h2>JSON syntax rules</h2>
<ul>
<li>Use double quotes around keys and strings.</li>
<li>Use lowercase <code>true</code>, <code>false</code>, and <code>null</code>.</li>
<li>Do not add comments or trailing commas.</li>
<li>Numbers and booleans must not be quoted.</li>
<li>Relative paths are resolved from the project root.</li>
<li>Keep <code>id</code> stable. Use Duplicate Session when a new identity is required.</li>
<li>Keep <code>schema_version</code> unless migration documentation explicitly says otherwise.</li>
</ul>

<h2>Top-level sections</h2>
<table>
<tr><th>Section</th><th>Purpose</th></tr>
<tr><td><code>transport</code></td><td>Connection, socket, and serial-driver behavior.</td></tr>
<tr><td><code>lifecycle</code></td><td>Whether the session continues after the Hub closes and whether its previous running state is restored.</td></tr>
<tr><td><code>framing</code></td><td>Receive-only message boundaries and decoded header metadata. It never changes TX bytes.</td></tr>
<tr><td><code>parser</code></td><td>Complete-message Python parser module, function, and name key.</td></tr>
<tr><td><code>storage</code></td><td>Pandas batching, retention, append/update/ignore conflict policy.</td></tr>
<tr><td><code>persistence</code></td><td>Periodic and final table snapshots.</td></tr>
</table>

<h2>Session lifecycle</h2>
<p><code>lifecycle.scope</code> accepts <code>window</code> or <code>application</code>. The default
<code>window</code> behavior stops the session when Communication Hub closes. With
<code>application</code>, its worker, periodic sends, persistence, and Protocol Insights continue
while the main application remains open. Closing the main application always performs an
orderly stop. Reopening Communication Hub reconnects its tabs to the retained runtime state.</p>
<p><code>restore_last_state</code> independently controls whether a session that was running at
the previous Hub close starts again when the Hub opens. <code>autostart</code> always starts a
session; restore-last-state starts it only when its recorded state was running.</p>
<pre>"lifecycle": {"scope": "application", "restore_last_state": true}</pre>

<h2>Transport keys</h2>
<p>The protocol-specific form exposes the commonly used keys. Advanced JSON can still be used to review or precisely enter them.</p>
<table>
<tr><th>Protocol</th><th>Supported transport keys</th></tr>
<tr><td>TCP Client</td><td><code>host</code>, <code>port</code>, <code>connect_timeout</code>, <code>read_chunk_size</code>, <code>reconnect</code>, <code>reconnect_initial_seconds</code>, <code>reconnect_max_seconds</code></td></tr>
<tr><td>TCP Server</td><td><code>bind_host</code>, <code>bind_port</code>, <code>read_chunk_size</code>, <code>max_clients</code></td></tr>
<tr><td>Serial</td><td><code>serial_port</code>, <code>baudrate</code>, <code>bytesize</code>, <code>parity</code>, <code>stopbits</code>, <code>read_timeout</code>, <code>write_timeout</code>, <code>read_chunk_size</code>, <code>rtscts</code>, <code>xonxoff</code>, <code>dsrdtr</code></td></tr>
<tr><td>Telnet</td><td><code>host</code>, <code>port</code>, <code>connect_timeout</code>. Telnet may transform protocol control bytes.</td></tr>
</table>

<h2>Advanced receive-header fields</h2>
<p>The row editor manages <code>name</code>, <code>offset</code>, <code>size</code>, <code>type</code>, and <code>endianness</code>. Advanced JSON additionally supports <code>signed</code> for numeric fields and <code>encoding</code>/<code>errors</code> for text fields.</p>
<pre>{
  "framing": {
    "header_fields": [
      {"name": "temperature", "offset": 0, "size": 2,
       "type": "int", "endianness": "big", "signed": true},
      {"name": "device_tag", "offset": 2, "size": 8,
       "type": "text", "encoding": "ascii", "errors": "replace"}
    ]
  }
}</pre>
<p>Merge the shown keys into the existing <code>framing</code> object; do not replace other required framing keys. Header fields must have unique names, remain inside <code>header_size</code>, and not overlap one another. Uncovered regions are emitted as <code>unknown_offset_size</code>.</p>

<h2>Storage and update-on-conflict</h2>
<p><code>default_conflict_action</code> supports <code>append</code>, <code>update</code>, or <code>ignore</code>. Rules are checked in order. A rule can match <code>direction</code>, <code>parsed</code>, and a name matcher of type <code>exact</code>, <code>contains</code>, <code>prefix</code>, or <code>regex</code>.</p>
<h3>What Update identity means</h3>
<p>Update identity answers: <i>which existing row should this new message replace?</i> Communication Hub combines the current values of every listed field into one identity. If an existing Update row has the same identity, it is replaced with the newest message while retaining its row ID and first timestamp. Its update count increases. If no row has that identity, a new row is created.</p>
<p>For example, <code>direction, name, data.DeviceId</code> maintains one latest row for each message name, transport direction, and device. A new RX Status message for device 10 updates only the RX Status row for device 10; device 11 remains a separate row. Removing <code>data.DeviceId</code> would cause every RX Status message, regardless of device, to share one row.</p>
<p>Identity fields may use message-table columns such as <code>direction</code>, <code>name</code>, <code>protocol</code>, <code>connection_id</code>, or <code>peer</code>, and parsed-data paths such as <code>data.DeviceId</code> or <code>data.Sensor.Channel</code>. Update identity is ignored for Append and Ignore actions. When omitted, Update uses <code>direction, name</code>.</p>
<pre>{
  "storage": {
    "default_conflict_action": "append",
    "conflict_rules": [
      {
        "direction": "RX",
        "parsed": true,
        "name_match": {"type": "exact", "value": "Status"},
        "action": "update",
        "key": ["direction", "name", "data.DeviceId"]
      },
      {
        "name_match": {"type": "prefix", "value": "Debug"},
        "action": "ignore"
      }
    ],
    "ingest_batch_rows": 250,
    "ingest_flush_ms": 50,
    "maximum_rows": 1000000,
    "retention": "drop_oldest"
  }
}</pre>
<p><code>retention</code> accepts <code>drop_oldest</code> or <code>drop_newest</code>. A <code>maximum_rows</code> value of 0 disables the row limit.</p>

<h2>Periodic table persistence</h2>
<pre>{
  "persistence": {
    "enabled": true,
    "directory": "app/data/communication_hub/logs",
    "interval_seconds": 30,
    "save_on_stop": true
  }
}</pre>
<p>The worker writes paired Pandas pickle snapshots under <code>directory/session_id</code>: <code>messages_*.pkl</code> contains the complete message table and <code>message_counts_*.pkl</code> contains the per-name totals and latest timestamps. The interval must be positive when persistence is enabled. <code>save_on_stop</code> writes final paired snapshots during an orderly stop. When Communication Hub reopens, it restores the newest final or periodic message snapshot before optional autostart.</p>

<h2>Protocol Insights</h2>
<p>Protocol Insights is the single workspace for eligible-message filtering, per-series extraction and processing, live or scheduled collection, synchronized plots, retained Insight data, recovery, and optional Excel output.</p>
<p>Protocol Insight configurations are stored at Communication Hub level rather than inside a session. Use the Protocol Insights tab to select current, chosen, or all sessions; define stream identity; configure retention and checkpoint recovery; and decide independently which series are plotted or written to Excel.</p>
<h2>Adding a supported setting</h2>
<ol>
<li>Locate its parent object, such as <code>storage</code> or <code>persistence</code>.</li>
<li>Add a comma after the previous property if needed.</li>
<li>Add the documented key with the correct JSON value type.</li>
<li>Keep Advanced JSON selected and press OK.</li>
</ol>
<pre>Before:
"persistence": {"enabled": false}

After:
"persistence": {
  "enabled": true,
  "directory": "app/data/communication_hub/logs",
  "interval_seconds": 30,
  "save_on_stop": true
}</pre>
</body></html>
'''

    def _show_configuration_help(self):
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Communication Session Configuration Help")
        dialog.resize(920, 760)
        layout = QtWidgets.QVBoxLayout(dialog)
        search_row = QtWidgets.QHBoxLayout()
        search = QtWidgets.QLineEdit(); search.setPlaceholderText("Find in help...")
        find_next = QtWidgets.QPushButton("Find next")
        search_row.addWidget(search, 1); search_row.addWidget(find_next); layout.addLayout(search_row)
        browser = QtWidgets.QTextBrowser(); browser.setHtml(self._configuration_help_html()); layout.addWidget(browser, 1)

        def find():
            text = search.text()
            if not text:
                return
            if not browser.find(text):
                cursor = browser.textCursor(); cursor.movePosition(QtGui.QTextCursor.Start)
                browser.setTextCursor(cursor); browser.find(text)

        find_next.clicked.connect(find); search.returnPressed.connect(find)
        QtWidgets.QShortcut(QtGui.QKeySequence.Find, dialog, activated=search.setFocus)
        close = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        close.rejected.connect(dialog.reject); layout.addWidget(close)
        dialog.exec_()

    @staticmethod
    def _add_form_row(form, label, widget, explanation):
        widget.setToolTip(explanation)
        if label:
            caption = QtWidgets.QLabel(label); caption.setToolTip(explanation)
            form.addRow(caption, widget)
        else:
            form.addRow("", widget)

    @staticmethod
    def _seconds_spin(maximum=3600.0):
        value = QtWidgets.QDoubleSpinBox(); value.setRange(0.0, maximum)
        value.setDecimals(2); value.setSingleStep(0.1); value.setSuffix(" s")
        return value

    @staticmethod
    def _chunk_spin():
        value = QtWidgets.QSpinBox(); value.setRange(1, 16 * 1024 * 1024)
        value.setSingleStep(1024); value.setSuffix(" bytes")
        return value

    def _build_basic(self):
        outer = QtWidgets.QVBoxLayout(self.basic)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        content = QtWidgets.QWidget(); layout = QtWidgets.QVBoxLayout(content); scroll.setWidget(content); outer.addWidget(scroll)

        session_group = QtWidgets.QGroupBox("Session identity")
        session_form = QtWidgets.QFormLayout(session_group)
        self.name = QtWidgets.QLineEdit()
        self.protocol = QtWidgets.QComboBox()
        for title, value in (("TCP Client", "tcp_client"), ("TCP Server", "tcp_server"), ("Serial", "serial"), ("Telnet", "telnet")):
            self.protocol.addItem(title, value)
        self.protocol_label = QtWidgets.QLineEdit()
        self.protocol_label.setPlaceholderText("For example: RADAR_V2 or SENSOR_FRAME_JSON")
        self.autostart = QtWidgets.QCheckBox("Start this session when Communication Hub opens")
        self.application_lifetime = QtWidgets.QCheckBox(
            "Keep this session running when Communication Hub is closed"
        )
        self.restore_last_state = QtWidgets.QCheckBox(
            "Restore the previous running state when Communication Hub opens"
        )
        self._add_form_row(session_form, "Session name", self.name, "Friendly name shown in the session table and Send destination selector.")
        self._add_form_row(session_form, "Transport protocol", self.protocol, "Select how this session connects. Only settings relevant to the selected protocol are shown below.")
        self._add_form_row(session_form, "Application protocol label", self.protocol_label, "Optional label for the application-level protocol carried by this transport; it is stored with every message row.")
        self._add_form_row(session_form, "", self.autostart, "Start this worker process automatically when the Communication Hub tool opens.")
        self._add_form_row(
            session_form, "", self.application_lifetime,
            "Keep the session worker, periodic sends, persistence, and Protocol Insights active "
            "after the Communication Hub window is closed. They still stop when the main "
            "application exits. Leave this clear to retain the existing window-dependent behavior.",
        )
        self._add_form_row(
            session_form, "", self.restore_last_state,
            "If this session was running when Communication Hub last closed, start it again the next time the Hub opens. "
            "A deliberately stopped session remains stopped. This is independent from always starting the session when the Hub opens.",
        )
        layout.addWidget(session_group)

        self.transport_stack = QtWidgets.QStackedWidget(); layout.addWidget(self.transport_stack)

        tcp_client = QtWidgets.QGroupBox("TCP client connection")
        form = QtWidgets.QFormLayout(tcp_client)
        self.host = QtWidgets.QLineEdit(); self.host.setPlaceholderText("127.0.0.1 or hostname")
        self.port = QtWidgets.QSpinBox(); self.port.setRange(1, 65535)
        self.tcp_client_connect_timeout = self._seconds_spin(300.0); self.tcp_client_read_chunk = self._chunk_spin()
        self.reconnect = QtWidgets.QCheckBox("Reconnect automatically after connection loss")
        self.reconnect_initial = self._seconds_spin(); self.reconnect_maximum = self._seconds_spin()
        self._add_form_row(form, "Remote host", self.host, "IPv4, IPv6, or DNS name of the remote TCP server.")
        self._add_form_row(form, "Remote port", self.port, "TCP port exposed by the remote server (1-65535).")
        self._add_form_row(form, "Connect timeout", self.tcp_client_connect_timeout, "Maximum time allowed for each TCP connection attempt.")
        self._add_form_row(form, "Read chunk size", self.tcp_client_read_chunk, "Maximum bytes requested from the socket per low-level read. Receive framing still reconstructs complete messages across chunks.")
        self._add_form_row(form, "", self.reconnect, "Retry automatically if the initial connection fails or an established connection is lost.")
        self._add_form_row(form, "Initial reconnect delay", self.reconnect_initial, "Delay before the first reconnect attempt.")
        self._add_form_row(form, "Maximum reconnect delay", self.reconnect_maximum, "Upper limit for exponential reconnect backoff.")
        self.transport_stack.addWidget(tcp_client)

        tcp_server = QtWidgets.QGroupBox("TCP server listener")
        form = QtWidgets.QFormLayout(tcp_server)
        self.bind_host = QtWidgets.QLineEdit(); self.bind_host.setPlaceholderText("127.0.0.1 or 0.0.0.0")
        self.bind_port = QtWidgets.QSpinBox(); self.bind_port.setRange(0, 65535)
        self.tcp_server_max_clients = QtWidgets.QSpinBox(); self.tcp_server_max_clients.setRange(1, 10000)
        self.tcp_server_read_chunk = self._chunk_spin()
        self._add_form_row(form, "Bind host", self.bind_host, "Local interface to listen on. Use 127.0.0.1 for local-only access or 0.0.0.0 for every IPv4 interface.")
        self._add_form_row(form, "Bind port", self.bind_port, "Local listening port. Port 0 asks the operating system to choose an available port.")
        self._add_form_row(form, "Maximum clients", self.tcp_server_max_clients, "Maximum simultaneous TCP clients accepted by this session.")
        self._add_form_row(form, "Read chunk size", self.tcp_server_read_chunk, "Maximum bytes requested from each client socket per low-level read.")
        self.transport_stack.addWidget(tcp_server)

        serial_group = QtWidgets.QGroupBox("Serial connection")
        form = QtWidgets.QFormLayout(serial_group)
        self.serial_port = QtWidgets.QLineEdit(); self.serial_port.setPlaceholderText("COM3, loop://, or socket://host:port")
        self.baudrate = QtWidgets.QSpinBox(); self.baudrate.setRange(1, 20_000_000)
        self.serial_bytesize = QtWidgets.QComboBox(); self.serial_bytesize.addItems(["5", "6", "7", "8"])
        self.serial_parity = QtWidgets.QComboBox()
        for title, value in (("None", "N"), ("Even", "E"), ("Odd", "O"), ("Mark", "M"), ("Space", "S")):
            self.serial_parity.addItem(title, value)
        self.serial_stopbits = QtWidgets.QComboBox()
        for title, value in (("1", 1.0), ("1.5", 1.5), ("2", 2.0)): self.serial_stopbits.addItem(title, value)
        self.serial_read_timeout = self._seconds_spin(60.0); self.serial_write_timeout = self._seconds_spin(60.0)
        self.serial_read_chunk = self._chunk_spin()
        self.serial_rtscts = QtWidgets.QCheckBox("RTS/CTS hardware flow control")
        self.serial_xonxoff = QtWidgets.QCheckBox("XON/XOFF software flow control")
        self.serial_dsrdtr = QtWidgets.QCheckBox("DSR/DTR hardware flow control")
        self._add_form_row(form, "Port or URL", self.serial_port, "Physical COM port or PySerial URL. loop:// provides an in-memory echo port for testing.")
        self._add_form_row(form, "Baud rate", self.baudrate, "Serial symbols per second; this must match the connected device.")
        self._add_form_row(form, "Data bits", self.serial_bytesize, "Number of data bits in each serial character.")
        self._add_form_row(form, "Parity", self.serial_parity, "Parity-bit mode used for serial error detection.")
        self._add_form_row(form, "Stop bits", self.serial_stopbits, "Number of stop bits terminating each serial character.")
        self._add_form_row(form, "Read timeout", self.serial_read_timeout, "How long a low-level serial read may wait. Zero selects non-blocking reads.")
        self._add_form_row(form, "Write timeout", self.serial_write_timeout, "Maximum time allowed for a serial write operation.")
        self._add_form_row(form, "Read chunk size", self.serial_read_chunk, "Maximum bytes requested from the serial driver per low-level read.")
        self._add_form_row(form, "", self.serial_rtscts, "Enable RTS/CTS hardware flow control when required by the device.")
        self._add_form_row(form, "", self.serial_xonxoff, "Enable XON/XOFF software flow control when required by the device.")
        self._add_form_row(form, "", self.serial_dsrdtr, "Enable DSR/DTR hardware flow control when required by the device.")
        self.transport_stack.addWidget(serial_group)

        telnet_group = QtWidgets.QGroupBox("Telnet connection")
        form = QtWidgets.QFormLayout(telnet_group)
        self.telnet_host = QtWidgets.QLineEdit(); self.telnet_host.setPlaceholderText("127.0.0.1 or hostname")
        self.telnet_port = QtWidgets.QSpinBox(); self.telnet_port.setRange(1, 65535)
        self.telnet_connect_timeout = self._seconds_spin(300.0)
        note = QtWidgets.QLabel("Telnet is not byte-transparent: negotiation and NVT rules may transform control bytes. Use TCP Client for arbitrary binary protocols.")
        note.setWordWrap(True); note.setStyleSheet("color: palette(mid); padding: 4px;")
        self._add_form_row(form, "Remote host", self.telnet_host, "IPv4, IPv6, or DNS name of the remote Telnet server.")
        self._add_form_row(form, "Remote port", self.telnet_port, "TCP port of the remote Telnet service; port 23 is the conventional default.")
        self._add_form_row(form, "Connect timeout", self.telnet_connect_timeout, "Maximum time allowed while opening the Telnet connection.")
        form.addRow(note)
        self.transport_stack.addWidget(telnet_group)

        layout.addStretch(1)
        self.protocol.currentIndexChanged.connect(self._protocol_changed)
        self._protocol_changed()

    def _protocol_changed(self, _index=None):
        protocol = self.protocol.currentData()
        index = {"tcp_client": 0, "tcp_server": 1, "serial": 2, "telnet": 3}.get(protocol, 0)
        self.transport_stack.setCurrentIndex(index)

    def _build_storage(self):
        outer = QtWidgets.QVBoxLayout(self.storage)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        content = QtWidgets.QWidget(); layout = QtWidgets.QVBoxLayout(content); scroll.setWidget(content); outer.addWidget(scroll)

        memory_group = QtWidgets.QGroupBox("In-memory Pandas message table")
        memory_form = QtWidgets.QFormLayout(memory_group)
        self.storage_batch_rows = QtWidgets.QSpinBox(); self.storage_batch_rows.setRange(1, 1_000_000)
        self.storage_batch_rows.setSuffix(" rows")
        self.storage_flush_ms = QtWidgets.QSpinBox(); self.storage_flush_ms.setRange(0, 3_600_000)
        self.storage_flush_ms.setSuffix(" ms")
        self.storage_maximum_rows = QtWidgets.QSpinBox(); self.storage_maximum_rows.setRange(0, 2_000_000_000)
        self.storage_maximum_rows.setSpecialValueText("Unlimited"); self.storage_maximum_rows.setSuffix(" rows")
        self.storage_retention = QtWidgets.QComboBox()
        self.storage_retention.addItem("Discard oldest rows (keep newest)", "drop_oldest")
        self.storage_retention.addItem("Discard newest rows (keep oldest)", "drop_newest")
        self.storage_default_action = QtWidgets.QComboBox()
        self.storage_default_action.addItem("Append a new row", "append")
        self.storage_default_action.addItem("Update matching direction + name row", "update")
        self.storage_default_action.addItem("Ignore the message", "ignore")
        self._add_form_row(memory_form, "Batch size", self.storage_batch_rows, "Flush pending messages into the Pandas DataFrame after this many rows. Larger batches improve throughput but delay table visibility and use more temporary memory.")
        self._add_form_row(memory_form, "Maximum batch wait", self.storage_flush_ms, "Flush a non-empty pending batch after this delay even when the batch-size threshold has not been reached. Zero requests immediate due flushing.")
        self._add_form_row(memory_form, "Maximum retained rows", self.storage_maximum_rows, "Maximum rows retained by this session process. Select Unlimited (0) to disable row-count retention; memory can then grow without a bound.")
        self._add_form_row(memory_form, "When the limit is exceeded", self.storage_retention, "Choose whether retention removes the oldest rows to keep live data, or rejects the newest rows to preserve the earliest history.")
        self._add_form_row(memory_form, "Default message behavior", self.storage_default_action, "Fallback used when no ordered conflict rule matches. Default Update identifies rows by direction and name; unparsed Unknown messages remain append-only for safety.")
        layout.addWidget(memory_group)

        rules_group = QtWidgets.QGroupBox("Ordered per-message conflict rules")
        rules_layout = QtWidgets.QVBoxLayout(rules_group)
        rules_note = QtWidgets.QLabel(
            "Rules are evaluated from top to bottom and the first match wins. Update identity answers which existing row should be replaced: "
            "the listed field values are combined, an equal identity updates that row, and a new identity creates a new row. For example, "
            "direction, name, data.DeviceId keeps one latest row per direction, message, and device. Check rules on the left to remove or reorder them."
        )
        rules_note.setWordWrap(True); rules_note.setStyleSheet("color: palette(mid);")
        rules_note.setToolTip("Append always creates a row, Update replaces the latest indexed row with the same identity, and Ignore stores no row.")
        rules_layout.addWidget(rules_note)
        self.storage_rules = QtWidgets.QTableWidget(0, 7)
        self.storage_rule_header = _CheckableHeaderView(self.storage_rules)
        self.storage_rules.setHorizontalHeader(self.storage_rule_header)
        self.storage_rules.setHorizontalHeaderLabels([
            "", "Direction", "Data form", "Name match", "Match value", "Action", "Update identity",
        ])
        self.storage_rules.horizontalHeaderItem(0).setToolTip("Check or clear every conflict rule.")
        self.storage_rules.horizontalHeaderItem(6).setToolTip(
            "Comma-separated fields that uniquely identify the row to replace. Equal values update an existing row; new values create a row."
        )
        self.storage_rules.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.storage_rules.setAlternatingRowColors(True); self.storage_rules.setMinimumHeight(190)
        self.storage_rules.verticalHeader().setVisible(False)
        self.storage_rules.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Fixed)
        self.storage_rules.setColumnWidth(0, 34)
        for column in (1, 2, 3, 5):
            self.storage_rules.horizontalHeader().setSectionResizeMode(column, QtWidgets.QHeaderView.ResizeToContents)
        self.storage_rules.horizontalHeader().setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)
        self.storage_rules.horizontalHeader().setSectionResizeMode(6, QtWidgets.QHeaderView.Stretch)
        self.storage_rules.setToolTip("Ordered rules controlling whether matching messages append, update, or are ignored.")
        self.storage_rule_header.checkStateChanged.connect(self._set_all_storage_rule_checks)
        rules_layout.addWidget(self.storage_rules)
        rule_actions = QtWidgets.QHBoxLayout(); rule_actions.addStretch(1)
        self.add_storage_rule_button = QtWidgets.QPushButton("Add rule")
        self.remove_storage_rule_button = QtWidgets.QPushButton("Remove checked")
        self.move_storage_rule_up_button = QtWidgets.QPushButton("Move up")
        self.move_storage_rule_down_button = QtWidgets.QPushButton("Move down")
        self.remove_storage_rule_button.setEnabled(False)
        self.move_storage_rule_up_button.setEnabled(False)
        self.move_storage_rule_down_button.setEnabled(False)
        self.add_storage_rule_button.setToolTip("Add a rule that initially updates parsed RX messages by direction and name.")
        self.remove_storage_rule_button.setToolTip("Remove every checked rule.")
        self.move_storage_rule_up_button.setToolTip("Move one checked rule earlier so it has higher priority.")
        self.move_storage_rule_down_button.setToolTip("Move one checked rule later so it has lower priority.")
        self.add_storage_rule_button.clicked.connect(self._add_storage_rule)
        self.remove_storage_rule_button.clicked.connect(self._remove_storage_rules)
        self.move_storage_rule_up_button.clicked.connect(lambda: self._move_storage_rule(-1))
        self.move_storage_rule_down_button.clicked.connect(lambda: self._move_storage_rule(1))
        for button in (
            self.add_storage_rule_button, self.remove_storage_rule_button,
            self.move_storage_rule_up_button, self.move_storage_rule_down_button,
        ):
            rule_actions.addWidget(button)
        rules_layout.addLayout(rule_actions); layout.addWidget(rules_group)

        processing_group = QtWidgets.QGroupBox("I/O to data-processing overload handling")
        processing_form = QtWidgets.QFormLayout(processing_group)
        self.processing_queue_capacity = QtWidgets.QSpinBox()
        self.processing_queue_capacity.setRange(1, 1_000_000)
        self.processing_queue_capacity.setSuffix(" frames")
        self.processing_overload_policy = QtWidgets.QComboBox()
        self.processing_overload_policy.addItem("Block I/O until space is available (no intentional loss)", "block")
        self.processing_overload_policy.addItem("Drop the newest completed frame", "drop_newest")
        self.processing_overload_policy.addItem("Drop the oldest queued frame", "drop_oldest")
        self.processing_batch_records = QtWidgets.QSpinBox(); self.processing_batch_records.setRange(1, 1_000_000)
        self.processing_time_slice_ms = QtWidgets.QSpinBox(); self.processing_time_slice_ms.setRange(1, 1000); self.processing_time_slice_ms.setSuffix(" ms")
        self._add_form_row(processing_form, "Queue capacity", self.processing_queue_capacity, "Maximum complete RX/TX frames waiting between the isolated I/O and data-processing processes.")
        self._add_form_row(processing_form, "When queue is full", self.processing_overload_policy, "Block preserves frames but can eventually delay capture. Drop policies preserve I/O responsiveness and report every loss in session metrics.")
        self._add_form_row(processing_form, "Processing batch", self.processing_batch_records, "Maximum queued frames parsed before the data process checks for commands.")
        self._add_form_row(processing_form, "Processing time slice", self.processing_time_slice_ms, "Maximum ingestion time before the data process gives queries and status commands another chance to run.")
        layout.addWidget(processing_group)

        persistence_group = QtWidgets.QGroupBox("Periodic and final disk snapshots")
        persistence_form = QtWidgets.QFormLayout(persistence_group)
        self.persistence_enabled = QtWidgets.QCheckBox("Periodically save this session's complete table")
        self.persistence_directory = QtWidgets.QLineEdit(); self.persistence_directory.setPlaceholderText("app/data/communication_hub/logs")
        self.persistence_browse_button = QtWidgets.QPushButton("Browse...")
        self.persistence_directory.setToolTip(
            "Absolute snapshot directory or path relative to the project root. Each session writes beneath its own ID folder."
        )
        self.persistence_browse_button.setToolTip("Choose the snapshot directory using a folder browser.")
        directory_row = QtWidgets.QWidget(); directory_layout = QtWidgets.QHBoxLayout(directory_row)
        directory_layout.setContentsMargins(0, 0, 0, 0); directory_layout.addWidget(self.persistence_directory, 1)
        directory_layout.addWidget(self.persistence_browse_button)
        self.persistence_interval = QtWidgets.QSpinBox(); self.persistence_interval.setRange(1, 31_536_000)
        self.persistence_interval.setSuffix(" s")
        self.persistence_save_on_stop = QtWidgets.QCheckBox("Write one final snapshot when the session stops cleanly")
        self._add_form_row(persistence_form, "", self.persistence_enabled, "Enable periodic paired Pandas snapshots for the complete message table and per-name counts. The newest snapshot is restored when Communication Hub reopens. Existing snapshots are not deleted when this option is disabled.")
        self._add_form_row(persistence_form, "Snapshot directory", directory_row, "Absolute path or a path relative to the project root. Files are written beneath a session-id subdirectory.")
        self._add_form_row(persistence_form, "Snapshot interval", self.persistence_interval, "Seconds between complete table snapshots while the session is running.")
        self._add_form_row(persistence_form, "", self.persistence_save_on_stop, "Write the final table state during an orderly session stop, independently of whether the periodic interval has just elapsed.")
        self.persistence_browse_button.clicked.connect(self._browse_persistence_directory)
        self.persistence_enabled.toggled.connect(self._update_persistence_controls)
        self._persistence_controls = [
            directory_row, self.persistence_directory, self.persistence_browse_button,
            self.persistence_interval, self.persistence_save_on_stop,
        ]
        layout.addWidget(persistence_group)

        caution = QtWidgets.QLabel(
            "Parsing, table storage, persistence, and Insights publishing belong to this session's isolated data-processing process. Very high or unlimited row counts can consume substantial memory, and frequent full snapshots can increase disk and CPU usage."
        )
        caution.setWordWrap(True); caution.setStyleSheet("color: palette(mid); padding: 4px;")
        layout.addWidget(caution); layout.addStretch(1)

    def _browse_persistence_directory(self):
        configured = self.persistence_directory.text().strip()
        initial = Path(configured) if configured else Path(PROJECT_ROOT)
        if not initial.is_absolute():
            initial = Path(PROJECT_ROOT) / initial
        selected = QtWidgets.QFileDialog.getExistingDirectory(self, "Select snapshot directory", str(initial))
        if not selected:
            return
        selected_path = Path(selected)
        try:
            selected_path = selected_path.relative_to(Path(PROJECT_ROOT))
        except ValueError:
            pass
        self.persistence_directory.setText(selected_path.as_posix())

    def _update_persistence_controls(self, enabled):
        for widget in self._persistence_controls:
            widget.setEnabled(enabled)

    def _add_storage_rule(self, rule=None, checked=False):
        if isinstance(rule, bool):
            checked = True
            rule = None
        rule = dict(rule or {
            "direction": "RX", "parsed": True,
            "name_match": {"type": "exact", "value": ""},
            "action": "update", "key": ["direction", "name"],
        })
        matcher = dict(rule.get("name_match") or {})
        row = self.storage_rules.rowCount(); self.storage_rules.insertRow(row)
        selector = QtWidgets.QCheckBox()
        selector.setCheckState(QtCore.Qt.Checked if checked else QtCore.Qt.Unchecked)
        selector.setToolTip("Check this rule to remove or reorder it.")
        selector.setAccessibleName(f"Select conflict rule {row + 1}")
        selector.stateChanged.connect(lambda _state: self._update_storage_rule_check_state())
        selector_cell = QtWidgets.QWidget()
        selector_layout = QtWidgets.QHBoxLayout(selector_cell)
        selector_layout.setContentsMargins(0, 0, 0, 0); selector_layout.setSpacing(0)
        selector_layout.addWidget(selector, 0, QtCore.Qt.AlignCenter)
        self.storage_rules.setCellWidget(row, 0, selector_cell)
        direction = QtWidgets.QComboBox()
        for title, value in (("Any", ""), ("RX", "RX"), ("TX", "TX")): direction.addItem(title, value)
        direction.setCurrentIndex(max(0, direction.findData(str(rule.get("direction", "")))))
        direction.setToolTip("Restrict this rule to received or transmitted messages, or match both directions.")
        parsed = QtWidgets.QComboBox()
        parsed.addItem("Any", None); parsed.addItem("Parsed", True); parsed.addItem("Binary/unparsed", False)
        parsed_index = parsed.findData(rule.get("parsed")) if "parsed" in rule else 0
        parsed.setCurrentIndex(max(0, parsed_index)); parsed.setToolTip("Restrict the rule by whether the parser produced structured data.")
        match_type = QtWidgets.QComboBox()
        for title, value in (("Any name", ""), ("Exact", "exact"), ("Contains", "contains"), ("Prefix", "prefix"), ("Regular expression", "regex")):
            match_type.addItem(title, value)
        match_type.setCurrentIndex(max(0, match_type.findData(str(matcher.get("type", "")))))
        match_type.setToolTip("Select how the message name is compared. Any name omits the name condition.")
        match_value = QtWidgets.QLineEdit(str(matcher.get("value", "")))
        match_value.setPlaceholderText("Message name or regular expression")
        match_value.setToolTip("Comparison text or Python regular expression used against the complete message name.")
        match_value.setProperty("original_rule", rule)
        action = QtWidgets.QComboBox()
        for title, value in (("Append", "append"), ("Update", "update"), ("Ignore", "ignore")): action.addItem(title, value)
        action.setCurrentIndex(max(0, action.findData(str(rule.get("action", "append")))))
        action.setToolTip("Append creates a new row; Update replaces a matching row; Ignore does not store the message.")
        key = QtWidgets.QLineEdit(", ".join(str(value) for value in rule.get("key", ["direction", "name"])))
        key.setPlaceholderText("direction, name, data.DeviceId (comma-separated)")
        key.setToolTip(
            "Which existing row should this message replace? Enter comma-separated table fields or parsed paths. "
            "For example, direction, name, data.DeviceId keeps one latest row per device. Matching values replace that row; "
            "a previously unseen combination creates a new row. Used only by Update."
        )
        self.storage_rules.setCellWidget(row, 1, direction); self.storage_rules.setCellWidget(row, 2, parsed)
        self.storage_rules.setCellWidget(row, 3, match_type); self.storage_rules.setCellWidget(row, 4, match_value)
        self.storage_rules.setCellWidget(row, 5, action); self.storage_rules.setCellWidget(row, 6, key)
        match_type.currentIndexChanged.connect(lambda _index, value=match_value, selector=match_type: value.setEnabled(bool(selector.currentData())))
        action.currentIndexChanged.connect(lambda _index, value=key, selector=action: value.setEnabled(selector.currentData() == "update"))
        match_value.setEnabled(bool(match_type.currentData())); key.setEnabled(action.currentData() == "update")
        self._update_storage_rule_check_state()

    def _storage_rules_from_table(self):
        rules = []
        for row in range(self.storage_rules.rowCount()):
            direction = self.storage_rules.cellWidget(row, 1)
            parsed = self.storage_rules.cellWidget(row, 2)
            match_type = self.storage_rules.cellWidget(row, 3)
            match_value = self.storage_rules.cellWidget(row, 4)
            action = self.storage_rules.cellWidget(row, 5)
            key = self.storage_rules.cellWidget(row, 6)
            rule = copy.deepcopy(match_value.property("original_rule") or {})
            if direction.currentData(): rule["direction"] = direction.currentData()
            else: rule.pop("direction", None)
            if parsed.currentIndex() > 0: rule["parsed"] = bool(parsed.currentData())
            else: rule.pop("parsed", None)
            if match_type.currentData():
                rule["name_match"] = {"type": match_type.currentData(), "value": match_value.text()}
            else:
                rule.pop("name_match", None)
            rule["action"] = action.currentData()
            fields = [field.strip() for field in key.text().split(",") if field.strip()]
            if action.currentData() == "update": rule["key"] = fields or ["direction", "name"]
            else: rule.pop("key", None)
            rules.append(rule)
        return rules

    def _checked_storage_rule_rows(self):
        return [
            row for row in range(self.storage_rules.rowCount())
            if (selector := self._storage_rule_checkbox(row)) is not None
            and selector.checkState() == QtCore.Qt.Checked
        ]

    def _storage_rule_checkbox(self, row):
        cell = self.storage_rules.cellWidget(row, 0)
        return cell.findChild(QtWidgets.QCheckBox) if cell is not None else None

    def _set_all_storage_rule_checks(self, state):
        for row in range(self.storage_rules.rowCount()):
            selector = self._storage_rule_checkbox(row)
            if selector is None: continue
            selector.blockSignals(True)
            selector.setCheckState(QtCore.Qt.CheckState(state))
            selector.blockSignals(False)
        self._update_storage_rule_check_state()

    def _update_storage_rule_check_state(self):
        checked = self._checked_storage_rule_rows()
        total = self.storage_rules.rowCount()
        state = QtCore.Qt.Unchecked if not checked else (QtCore.Qt.Checked if len(checked) == total else QtCore.Qt.PartiallyChecked)
        self.storage_rule_header.setCheckState(state)
        self.remove_storage_rule_button.setEnabled(bool(checked))
        one = len(checked) == 1
        row = checked[0] if one else -1
        self.move_storage_rule_up_button.setEnabled(one and row > 0)
        self.move_storage_rule_down_button.setEnabled(one and row < total - 1)

    def _remove_storage_rules(self):
        rows = sorted(self._checked_storage_rule_rows(), reverse=True)
        for row in rows: self.storage_rules.removeRow(row)
        self._update_storage_rule_check_state()

    def _move_storage_rule(self, change):
        rows = self._checked_storage_rule_rows()
        if len(rows) != 1:
            return
        source = rows[0]; target = source + change
        if target < 0 or target >= self.storage_rules.rowCount():
            return
        rules = self._storage_rules_from_table(); rule = rules.pop(source); rules.insert(target, rule)
        self.storage_rules.setRowCount(0)
        for index, value in enumerate(rules): self._add_storage_rule(value, checked=index == target)

    def _build_framing(self):
        layout = QtWidgets.QVBoxLayout(self.framing)
        group = QtWidgets.QGroupBox("Receive message boundaries (header + length)")
        form = QtWidgets.QFormLayout(group)
        self.framed = QtWidgets.QCheckBox("Incoming messages have a fixed header containing a length field")
        self.header_size = QtWidgets.QSpinBox(); self.header_size.setRange(1, 65535)
        self.length_offset = QtWidgets.QSpinBox(); self.length_offset.setRange(0, 65534)
        self.length_size = QtWidgets.QSpinBox(); self.length_size.setRange(1, 16)
        self.endianness = QtWidgets.QComboBox(); self.endianness.addItems(["little", "big"])
        self.length_meaning = QtWidgets.QComboBox(); self.length_meaning.addItems(["payload_length", "total_frame_length"])
        self.length_adjustment = QtWidgets.QSpinBox(); self.length_adjustment.setRange(-1_000_000_000, 1_000_000_000)
        self.maximum_payload = QtWidgets.QSpinBox(); self.maximum_payload.setRange(1, 1_000_000_000)
        self.partial_timeout = QtWidgets.QSpinBox(); self.partial_timeout.setRange(1, 3_600_000); self.partial_timeout.setSuffix(" ms")
        self._add_form_row(form, "", self.framed, "Enable receive-side message reconstruction. The setting never changes outgoing bytes.")
        self._add_form_row(form, "Header size", self.header_size, "Exact fixed number of bytes read before the payload length is calculated.")
        self._add_form_row(form, "Length field offset", self.length_offset, "Zero-based byte offset of the length field inside the header.")
        self._add_form_row(form, "Length field size", self.length_size, "Number of bytes occupied by the unsigned or signed length integer.")
        self._add_form_row(form, "Length endianness", self.endianness, "Byte order used to decode the length field: little-endian or big-endian.")
        self._add_form_row(form, "Length means", self.length_meaning, "payload_length means the field describes only payload bytes; total_frame_length includes the fixed header.")
        self._add_form_row(form, "Length adjustment", self.length_adjustment, "Fixed signed value added after decoding the declared length and, for total-frame length, subtracting the header size.")
        self._add_form_row(form, "Maximum payload", self.maximum_payload, "Safety limit applied to the calculated payload size before the worker waits or allocates storage.")
        self._add_form_row(form, "Partial frame timeout", self.partial_timeout, "Maximum time allowed between receiving the first partial bytes and completing the message.")
        layout.addWidget(group)
        parser_group = QtWidgets.QGroupBox("Complete-message parser: parser(header + payload, direction) -> dict")
        parser_form = QtWidgets.QFormLayout(parser_group)
        self.parser_enabled = QtWidgets.QCheckBox("Enable parser")
        self.parser_module = QtWidgets.QLineEdit(); self.parser_module.setPlaceholderText("my_project.protocol.parser")
        self.parser_function = QtWidgets.QLineEdit(); self.parser_function.setPlaceholderText("parse_message")
        self.parser_name_key = QtWidgets.QLineEdit(); self.parser_name_key.setPlaceholderText("Name")
        self._add_form_row(parser_form, "", self.parser_enabled, "Call a project Python function for every complete TX and RX message. Disabled sessions store complete binary bytes.")
        self._add_form_row(parser_form, "Python module", self.parser_module, "Importable dotted module path. It must be available inside the spawned session worker process.")
        self._add_form_row(parser_form, "Function", self.parser_function, "Callable accepting exactly (message_bytes, direction) and returning a dictionary.")
        self._add_form_row(parser_form, "Message-name key", self.parser_name_key, "Dictionary key whose value is copied into the message table's name column; missing values become Unknown.")
        self.create_parser_example_button = QtWidgets.QPushButton("Create example parser module...")
        self.create_parser_example_button.setToolTip(
            "Create a documented Python parser under PROJECT_ROOT/externals and fill the module and function fields automatically."
        )
        self.create_parser_example_button.clicked.connect(self._create_example_parser_module)
        parser_form.addRow("", self.create_parser_example_button)
        layout.addWidget(parser_group)
        header_fields_group = QtWidgets.QGroupBox("Optional fields decoded from received headers")
        header_fields_layout = QtWidgets.QVBoxLayout(header_fields_group)
        header_fields_note = QtWidgets.QLabel(
            "Define known header regions below. Uncovered bytes are automatically stored as "
            "unknown_<offset>_<size> byte fields; the configured length region is stored as declared_length."
        )
        header_fields_note.setWordWrap(True); header_fields_note.setStyleSheet("color: palette(mid);")
        header_fields_note.setToolTip("These fields are receive metadata only. The parser still receives the complete header plus payload bytes.")
        header_fields_layout.addWidget(header_fields_note)
        self.header_fields = QtWidgets.QTableWidget(0, 5)
        self.header_fields.setHorizontalHeaderLabels(["Name", "Offset", "Size", "Type", "Endianness"])
        self.header_fields.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.header_fields.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.header_fields.setAlternatingRowColors(True); self.header_fields.setMinimumHeight(150)
        self.header_fields.verticalHeader().setVisible(False)
        self.header_fields.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        for column in range(1, 5):
            self.header_fields.horizontalHeader().setSectionResizeMode(column, QtWidgets.QHeaderView.ResizeToContents)
        self.header_fields.setToolTip("Known fields decoded from fixed positions in each received header.")
        header_fields_layout.addWidget(self.header_fields)
        field_actions = QtWidgets.QHBoxLayout(); field_actions.addStretch(1)
        self.add_header_field_button = QtWidgets.QPushButton("Add field")
        self.remove_header_field_button = QtWidgets.QPushButton("Remove selected")
        self.add_header_field_button.setToolTip("Add a decoded receive-header field with editable name, offset, size, type, and byte order.")
        self.remove_header_field_button.setToolTip("Remove every selected decoded header-field row.")
        self.add_header_field_button.clicked.connect(self._add_header_field)
        self.remove_header_field_button.clicked.connect(self._remove_header_fields)
        field_actions.addWidget(self.add_header_field_button); field_actions.addWidget(self.remove_header_field_button)
        header_fields_layout.addLayout(field_actions); layout.addWidget(header_fields_group)
        self._framing_controls = [
            self.header_size, self.length_offset, self.length_size, self.endianness,
            self.length_meaning, self.length_adjustment, self.maximum_payload,
            self.partial_timeout, self.header_fields, self.add_header_field_button,
            self.remove_header_field_button,
        ]
        self._parser_controls = [self.parser_module, self.parser_function, self.parser_name_key]
        self.framed.toggled.connect(self._update_framing_controls)
        self.parser_enabled.toggled.connect(self._update_parser_controls)

    def _update_framing_controls(self, enabled):
        for widget in self._framing_controls: widget.setEnabled(enabled)

    def _update_parser_controls(self, enabled):
        for widget in self._parser_controls: widget.setEnabled(enabled)

    def _next_header_field_offset(self):
        occupied = set(range(self.length_offset.value(), self.length_offset.value() + self.length_size.value()))
        for row in range(self.header_fields.rowCount()):
            offset = self.header_fields.cellWidget(row, 1).value()
            size = self.header_fields.cellWidget(row, 2).value()
            occupied.update(range(offset, offset + size))
        for offset in range(self.header_size.value()):
            if offset not in occupied:
                return offset
        return max(0, self.header_size.value() - 1)

    def _add_header_field(self, field=None):
        field = dict(field or {})
        default_offset = self._next_header_field_offset()
        row = self.header_fields.rowCount(); self.header_fields.insertRow(row)
        name = QtWidgets.QTableWidgetItem(str(field.get("name", f"field_{row + 1}")))
        name.setData(QtCore.Qt.UserRole, field); self.header_fields.setItem(row, 0, name)
        offset = QtWidgets.QSpinBox(); offset.setRange(0, 65534)
        offset.setValue(int(field.get("offset", default_offset)))
        offset.setToolTip("Zero-based byte offset inside the fixed receive header.")
        size = QtWidgets.QSpinBox(); size.setRange(1, 65535); size.setValue(int(field.get("size", 1)))
        size.setToolTip("Number of consecutive header bytes occupied by this field.")
        field_type = QtWidgets.QComboBox(); field_type.addItems(["uint", "int", "bytes", "text"])
        field_type.setCurrentText(str(field.get("type", "uint")))
        field_type.setToolTip("uint/int decode a number; bytes preserves raw bytes; text decodes using the field's advanced JSON encoding.")
        endianness = QtWidgets.QComboBox(); endianness.addItems(["little", "big"])
        endianness.setCurrentText(str(field.get("endianness", "little")))
        endianness.setToolTip("Byte order for uint and int fields; it is not used for bytes or text.")
        field_type.currentTextChanged.connect(
            lambda value, combo=endianness: combo.setEnabled(value in {"uint", "int"})
        )
        endianness.setEnabled(field_type.currentText() in {"uint", "int"})
        self.header_fields.setCellWidget(row, 1, offset); self.header_fields.setCellWidget(row, 2, size)
        self.header_fields.setCellWidget(row, 3, field_type); self.header_fields.setCellWidget(row, 4, endianness)

    def _remove_header_fields(self):
        rows = sorted({index.row() for index in self.header_fields.selectionModel().selectedRows()}, reverse=True)
        for row in rows: self.header_fields.removeRow(row)

    def _header_fields_from_table(self):
        fields = []
        for row in range(self.header_fields.rowCount()):
            item = self.header_fields.item(row, 0)
            field = dict(item.data(QtCore.Qt.UserRole) or {})
            field.update({
                "name": item.text().strip(),
                "offset": self.header_fields.cellWidget(row, 1).value(),
                "size": self.header_fields.cellWidget(row, 2).value(),
                "type": self.header_fields.cellWidget(row, 3).currentText(),
                "endianness": self.header_fields.cellWidget(row, 4).currentText(),
            })
            fields.append(field)
        return fields

    @staticmethod
    def _example_parser_source():
        return '''\
"""Example Communication Hub complete-message parser.

Parser contract
===============

``parse_message`` is called as::

    parse_message(message_bytes: bytes, direction: Direction) -> dict[str, Any]

Inputs
------
message_bytes:
    Always a ``bytes`` object.

    * TX: exactly the bytes supplied to ``session.send`` or the Send tab.
    * RX with header framing: the reconstructed ``header + payload`` bytes.
    * RX without header framing: the byte chunk delivered by the transport.

direction:
    A ``Direction`` enum. It is either ``Direction.TX`` or ``Direction.RX``.
    ``direction.value`` returns the strings ``"TX"`` and ``"RX"``.

Output
------
Return a dictionary. The configured message-name key defaults to ``"Name"``.
Its value is written to the table's ``name`` column; the complete dictionary is
written to ``data``. If the key is missing or empty, the row name is ``Unknown``.

Errors
------
It is safe to raise an exception for malformed data. Communication Hub catches
it, stores the original complete bytes, and records the exception in
``parse_error``. Never return a non-dictionary value.

Example protocol
----------------
This starter decodes the demo seven-byte header:

* bytes 0-1: message ID, unsigned little-endian
* byte 2: protocol direction/flags
* bytes 3-6: payload length, unsigned little-endian
* remaining bytes: UTF-8 JSON payload

Edit the constants and decoding logic to match your real protocol.
"""

from __future__ import annotations

import json
from typing import Any

from app.tools.communication_hub.parser_runtime import Direction


HEADER_SIZE = 7
MESSAGE_ID_OFFSET = 0
PROTOCOL_DIRECTION_OFFSET = 2
LENGTH_OFFSET = 3
LENGTH_SIZE = 4
BYTE_ORDER = "little"


def parse_message(message_bytes: bytes, direction: Direction) -> dict[str, Any]:
    """Decode one complete TX or RX message into table-friendly values.

    Args:
        message_bytes: Exact complete message bytes described in the module
            documentation above.
        direction: Actual transport direction, ``Direction.TX`` or
            ``Direction.RX``. Do not confuse this with a direction field that
            may exist inside the protocol header.

    Returns:
        A dictionary. Keep values JSON-like where practical: strings, numbers,
        booleans, ``None``, lists, nested dictionaries, or bytes.

    Raises:
        ValueError: If the message is shorter than its header or the declared
            payload length does not match the supplied complete bytes.
        UnicodeDecodeError: If the payload is not valid UTF-8.
        json.JSONDecodeError: If the payload is not valid JSON.
    """
    if not isinstance(message_bytes, bytes):
        raise TypeError(f"message_bytes must be bytes, got {type(message_bytes).__name__}")
    if len(message_bytes) < HEADER_SIZE:
        raise ValueError(f"Message has {len(message_bytes)} bytes; expected at least {HEADER_SIZE}")

    header = message_bytes[:HEADER_SIZE]
    payload = message_bytes[HEADER_SIZE:]
    message_id = int.from_bytes(header[MESSAGE_ID_OFFSET:MESSAGE_ID_OFFSET + 2], BYTE_ORDER)
    protocol_direction = header[PROTOCOL_DIRECTION_OFFSET]
    declared_payload_length = int.from_bytes(
        header[LENGTH_OFFSET:LENGTH_OFFSET + LENGTH_SIZE], BYTE_ORDER
    )
    if declared_payload_length != len(payload):
        raise ValueError(
            f"Header declares {declared_payload_length} payload bytes; received {len(payload)}"
        )

    decoded_payload = json.loads(payload.decode("utf-8"))
    if not isinstance(decoded_payload, dict):
        raise TypeError("Example JSON payload must decode to an object/dictionary")

    # Copy the payload so adding metadata does not mutate a shared object.
    result: dict[str, Any] = dict(decoded_payload)
    result.setdefault("Name", result.get("Command", "ExampleMessage"))
    result["TransportDirection"] = direction.value
    result["MessageId"] = message_id
    result["ProtocolDirection"] = protocol_direction
    result["HeaderHex"] = header.hex()
    result["PayloadByteCount"] = len(payload)
    return result
'''

    def _create_example_parser_module(self):
        import keyword
        import re

        requested, accepted = QtWidgets.QInputDialog.getText(
            self, "Create example parser", "Module filename", text="communication_parser_example.py"
        )
        if not accepted:
            return
        stem = str(requested).strip()
        if stem.lower().endswith(".py"):
            stem = stem[:-3]
        stem = re.sub(r"[^A-Za-z0-9_]", "_", stem).strip("_").lower()
        if not stem:
            QtWidgets.QMessageBox.warning(self, "Invalid filename", "Enter a valid Python module filename."); return
        if stem[0].isdigit() or keyword.iskeyword(stem):
            stem = f"parser_{stem}"
        if stem.upper() in {"CON", "PRN", "AUX", "NUL"} or re.fullmatch(r"(?:COM|LPT)[1-9]", stem.upper()):
            QtWidgets.QMessageBox.warning(self, "Invalid filename", f"'{stem}' is reserved by Windows."); return

        directory = Path(PROJECT_ROOT) / "externals"
        target = directory / f"{stem}.py"
        if target.exists():
            QtWidgets.QMessageBox.warning(
                self, "Parser module already exists",
                f"The file already exists and was not overwritten:\n\n{target}\n\nChoose another module filename.",
            )
            return
        try:
            directory.mkdir(parents=True, exist_ok=True)
            init_file = directory / "__init__.py"
            if not init_file.exists(): init_file.write_text("", encoding="utf-8")
            with target.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(self._example_parser_source())
        except BaseException as error:
            QtWidgets.QMessageBox.critical(self, "Could not create parser module", f"{type(error).__name__}: {error}")
            return

        self.parser_enabled.setChecked(True)
        self.parser_module.setText(f"externals.{stem}")
        self.parser_function.setText("parse_message")
        self.parser_name_key.setText("Name")
        QtWidgets.QMessageBox.information(
            self, "Example parser created",
            f"Created:\n{target}\n\nThe parser fields now reference externals.{stem}.parse_message.",
        )

    def _load(self, config):
        transport, framing, parser = config["transport"], config["framing"], config["parser"]
        storage_config, persistence = config["storage"], config["persistence"]
        processing = config.get("processing", {})
        self.name.setText(config["name"])
        protocol_index = self.protocol.findData(config["protocol"])
        self.protocol.setCurrentIndex(protocol_index if protocol_index >= 0 else 0)
        self.protocol_label.setText(config.get("protocol_label", "")); self.autostart.setChecked(config.get("autostart", False))
        self.application_lifetime.setChecked(
            config.get("lifecycle", {}).get("scope", "window") == "application"
        )
        self.restore_last_state.setChecked(
            bool(config.get("lifecycle", {}).get("restore_last_state", True))
        )
        self.host.setText(str(transport.get("host", ""))); self.port.setValue(int(transport.get("port", 0)))
        self.tcp_client_connect_timeout.setValue(float(transport.get("connect_timeout", 5.0)))
        self.tcp_client_read_chunk.setValue(int(transport.get("read_chunk_size", 65536)))
        self.reconnect_initial.setValue(float(transport.get("reconnect_initial_seconds", 1.0)))
        self.reconnect_maximum.setValue(float(transport.get("reconnect_max_seconds", 30.0)))
        self.bind_host.setText(str(transport.get("bind_host", ""))); self.bind_port.setValue(int(transport.get("bind_port", 0)))
        self.tcp_server_max_clients.setValue(int(transport.get("max_clients", 32)))
        self.tcp_server_read_chunk.setValue(int(transport.get("read_chunk_size", 65536)))
        self.serial_port.setText(str(transport.get("serial_port", ""))); self.baudrate.setValue(int(transport.get("baudrate", 115200)))
        self.serial_bytesize.setCurrentText(str(int(transport.get("bytesize", 8))))
        parity_index = self.serial_parity.findData(str(transport.get("parity", "N")))
        self.serial_parity.setCurrentIndex(parity_index if parity_index >= 0 else 0)
        stopbits_index = self.serial_stopbits.findData(float(transport.get("stopbits", 1.0)))
        self.serial_stopbits.setCurrentIndex(stopbits_index if stopbits_index >= 0 else 0)
        self.serial_read_timeout.setValue(float(transport.get("read_timeout", 0.05)))
        self.serial_write_timeout.setValue(float(transport.get("write_timeout", 1.0)))
        self.serial_read_chunk.setValue(int(transport.get("read_chunk_size", 65536)))
        self.serial_rtscts.setChecked(bool(transport.get("rtscts", False)))
        self.serial_xonxoff.setChecked(bool(transport.get("xonxoff", False)))
        self.serial_dsrdtr.setChecked(bool(transport.get("dsrdtr", False)))
        self.telnet_host.setText(str(transport.get("host", ""))); self.telnet_port.setValue(int(transport.get("port", 23)))
        self.telnet_connect_timeout.setValue(float(transport.get("connect_timeout", 5.0)))
        self.reconnect.setChecked(bool(transport.get("reconnect", False)))
        self.framed.setChecked(framing.get("mode") == "header_length")
        self.header_size.setValue(max(1, int(framing.get("header_size", 1))))
        length = framing.get("length_field", {})
        self.length_offset.setValue(int(length.get("offset", 0))); self.length_size.setValue(max(1, int(length.get("size", 1))))
        self.endianness.setCurrentText(length.get("endianness", "little")); self.length_meaning.setCurrentText(length.get("meaning", "payload_length"))
        self.length_adjustment.setValue(int(length.get("adjustment", 0))); self.maximum_payload.setValue(int(framing.get("maximum_payload_size", 10 * 1024 * 1024)))
        self.partial_timeout.setValue(int(framing.get("partial_frame_timeout_ms", 5000)))
        self.header_fields.setRowCount(0)
        for field in framing.get("header_fields", []): self._add_header_field(field)
        self.parser_enabled.setChecked(bool(parser.get("enabled"))); self.parser_module.setText(parser.get("module", ""))
        self.parser_function.setText(parser.get("function", "")); self.parser_name_key.setText(parser.get("name_key", "Name"))
        self.storage_batch_rows.setValue(int(storage_config.get("ingest_batch_rows", 250)))
        self.storage_flush_ms.setValue(int(storage_config.get("ingest_flush_ms", 50)))
        self.storage_maximum_rows.setValue(int(storage_config.get("maximum_rows", 1_000_000)))
        retention_index = self.storage_retention.findData(storage_config.get("retention", "drop_oldest"))
        self.storage_retention.setCurrentIndex(retention_index if retention_index >= 0 else 0)
        action_index = self.storage_default_action.findData(storage_config.get("default_conflict_action", "append"))
        self.storage_default_action.setCurrentIndex(action_index if action_index >= 0 else 0)
        self.storage_rules.setRowCount(0)
        for rule in storage_config.get("conflict_rules", []): self._add_storage_rule(rule)
        self.processing_queue_capacity.setValue(int(processing.get("queue_capacity", 4096)))
        policy_index = self.processing_overload_policy.findData(processing.get("overload_policy", "block"))
        self.processing_overload_policy.setCurrentIndex(max(0, policy_index))
        self.processing_batch_records.setValue(int(processing.get("batch_records", 512)))
        self.processing_time_slice_ms.setValue(int(processing.get("time_slice_ms", 8)))
        self.persistence_enabled.setChecked(bool(persistence.get("enabled", False)))
        self.persistence_directory.setText(str(persistence.get("directory", "app/data/communication_hub/logs")))
        self.persistence_interval.setValue(int(persistence.get("interval_seconds", 30)))
        self.persistence_save_on_stop.setChecked(bool(persistence.get("save_on_stop", True)))
        self._protocol_changed(); self._update_framing_controls(self.framed.isChecked())
        self._update_parser_controls(self.parser_enabled.isChecked())
        self._update_persistence_controls(self.persistence_enabled.isChecked())

    def _from_form(self):
        config = copy.deepcopy(self.original)
        protocol = self.protocol.currentData()
        config.update({
            "name": self.name.text().strip(),
            "protocol": protocol,
            "protocol_label": self.protocol_label.text().strip(),
            "autostart": self.autostart.isChecked(),
            "lifecycle": {
                "scope": "application" if self.application_lifetime.isChecked() else "window",
                "restore_last_state": self.restore_last_state.isChecked(),
                "last_running_on_close": bool(
                    config.get("lifecycle", {}).get("last_running_on_close", False)
                ),
            },
        })
        transport = config["transport"]
        if protocol == "tcp_client":
            transport.update({
                "host": self.host.text().strip(), "port": self.port.value(),
                "connect_timeout": self.tcp_client_connect_timeout.value(),
                "read_chunk_size": self.tcp_client_read_chunk.value(),
                "reconnect": self.reconnect.isChecked(),
                "reconnect_initial_seconds": self.reconnect_initial.value(),
                "reconnect_max_seconds": self.reconnect_maximum.value(),
            })
        elif protocol == "tcp_server":
            transport.update({
                "bind_host": self.bind_host.text().strip(), "bind_port": self.bind_port.value(),
                "max_clients": self.tcp_server_max_clients.value(),
                "read_chunk_size": self.tcp_server_read_chunk.value(),
            })
        elif protocol == "serial":
            transport.update({
                "serial_port": self.serial_port.text().strip(), "baudrate": self.baudrate.value(),
                "bytesize": int(self.serial_bytesize.currentText()), "parity": self.serial_parity.currentData(),
                "stopbits": self.serial_stopbits.currentData(), "read_timeout": self.serial_read_timeout.value(),
                "write_timeout": self.serial_write_timeout.value(), "read_chunk_size": self.serial_read_chunk.value(),
                "rtscts": self.serial_rtscts.isChecked(), "xonxoff": self.serial_xonxoff.isChecked(),
                "dsrdtr": self.serial_dsrdtr.isChecked(),
            })
        elif protocol == "telnet":
            transport.update({
                "host": self.telnet_host.text().strip(), "port": self.telnet_port.value(),
                "connect_timeout": self.telnet_connect_timeout.value(),
            })
        config["framing"].update({
            "mode": "header_length" if self.framed.isChecked() else "raw_chunk",
            "header_size": self.header_size.value() if self.framed.isChecked() else 0,
            "maximum_payload_size": self.maximum_payload.value(),
            "partial_frame_timeout_ms": self.partial_timeout.value(),
            "header_fields": self._header_fields_from_table(),
        })
        config["framing"]["length_field"].update({
            "offset": self.length_offset.value(), "size": self.length_size.value(),
            "endianness": self.endianness.currentText(), "meaning": self.length_meaning.currentText(),
            "adjustment": self.length_adjustment.value(),
        })
        config["parser"].update({
            "enabled": self.parser_enabled.isChecked(), "module": self.parser_module.text().strip(),
            "function": self.parser_function.text().strip(), "name_key": self.parser_name_key.text().strip() or "Name",
        })
        config["storage"].update({
            "default_conflict_action": self.storage_default_action.currentData(),
            "conflict_rules": self._storage_rules_from_table(),
            "ingest_batch_rows": self.storage_batch_rows.value(),
            "ingest_flush_ms": self.storage_flush_ms.value(),
            "maximum_rows": self.storage_maximum_rows.value(),
            "retention": self.storage_retention.currentData(),
        })
        config["processing"] = {
            "queue_capacity": self.processing_queue_capacity.value(),
            "overload_policy": self.processing_overload_policy.currentData(),
            "batch_records": min(self.processing_batch_records.value(), self.processing_queue_capacity.value()),
            "time_slice_ms": self.processing_time_slice_ms.value(),
        }
        config["persistence"].update({
            "enabled": self.persistence_enabled.isChecked(),
            "directory": self.persistence_directory.text().strip(),
            "interval_seconds": self.persistence_interval.value(),
            "save_on_stop": self.persistence_save_on_stop.isChecked(),
        })
        return normalize_session_config(config)

    def _tab_changed(self, index):
        if self.tabs.widget(index) is self.advanced:
            try:
                self.json_edit.setPlainText(json.dumps(self._from_form(), indent=2))
            except BaseException as error:
                QtWidgets.QMessageBox.warning(self, "Configuration", str(error))

    def _accept(self):
        try:
            self.result_config = normalize_session_config(json.loads(self.json_edit.toPlainText())) if self.tabs.currentWidget() is self.advanced else self._from_form()
        except BaseException as error:
            QtWidgets.QMessageBox.critical(self, "Invalid configuration", str(error))
            return
        self.accept()


class QueryConditionDialog(QtWidgets.QDialog):
    OPERATIONS = (
        ("Equals", "equals", "Exact value equality."),
        ("Does not equal", "not_equals", "Values that differ from the supplied value."),
        ("Is one of", "in", "Value must be a JSON array, for example [\"RX\", \"TX\"]."),
        ("Contains", "contains", "Text, bytes, lists, or dictionaries containing the supplied item."),
        ("Contains nested value", "contains_value", "Search recursively inside parsed dictionaries and lists."),
        ("Contains byte sequence", "contains_bytes", "Search raw bytes using hexadecimal text such as 01FF."),
        ("Starts with", "starts_with", "Text representation starts with the supplied value."),
        ("Ends with", "ends_with", "Text representation ends with the supplied value."),
        ("Matches regular expression", "regex", "Python regular expression search."),
        ("Matches wildcard", "glob", "Shell-style pattern such as Status*."),
        ("Exists / is not null", "exists", "Field is present and has a value."),
        ("Missing / is null", "missing", "Field is absent or null."),
        ("Has Python type", "type_is", "Type name such as int, float, str, bytes, list, or dict."),
        ("Greater than", "gt", "Numeric, text, or timestamp comparison."),
        ("Greater than or equal", "gte", "Numeric, text, or timestamp comparison."),
        ("Less than", "lt", "Numeric, text, or timestamp comparison."),
        ("Less than or equal", "lte", "Numeric, text, or timestamp comparison."),
        ("Before", "before", "Timestamp or ordered-value comparison."),
        ("After", "after", "Timestamp or ordered-value comparison."),
        ("Between inclusive", "between", "Value must be [minimum, maximum]."),
        ("Within the last", "within_last", "Relative timestamp window using the selected time unit."),
        ("Byte at offset equals", "byte_at", "Value must be [zero_based_offset, expected_byte]."),
        ("Decoded text contains", "decoded_text_contains", "Decode raw bytes with the selected encoding and search text."),
    )

    def __init__(self, parent=None, condition=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Filter Condition" if condition else "Add Filter Condition")
        self.resize(570, 330)
        form = QtWidgets.QFormLayout(self)
        self.field = QtWidgets.QComboBox(); self.field.setEditable(True)
        self.field.addItems([
            "id", "timestamp", "first_timestamp", "direction", "protocol", "protocol_label",
            "name", "parsed", "size", "frame_size", "peer", "connection_id", "session_id",
            "parse_status", "parse_error", "parse_duration_ns", "update_count", "header",
            "data.", "header_fields.",
        ])
        self.field.setToolTip("Choose a table column, or enter data.<path> / header_fields.<path> for nested values.")
        self.operation = QtWidgets.QComboBox()
        for title, value, explanation in self.OPERATIONS:
            self.operation.addItem(title, value); self.operation.setItemData(self.operation.count() - 1, explanation, QtCore.Qt.ToolTipRole)
        self.value = QtWidgets.QLineEdit(); self.value.setPlaceholderText('JSON or text: "RX", 42, [1, 10], Status, or 01FF')
        self.unit = QtWidgets.QComboBox(); self.unit.addItems(["milliseconds", "seconds", "minutes", "hours"])
        self.case_sensitive = QtWidgets.QCheckBox("Case-sensitive regular expression"); self.case_sensitive.setChecked(True)
        self.text_encoding = QtWidgets.QComboBox(); self.text_encoding.setEditable(True)
        self.text_encoding.addItems(["utf-8", "ascii", "latin-1", "utf-16-le", "utf-16-be"])
        self.decode_errors = QtWidgets.QComboBox(); self.decode_errors.addItems(["replace", "strict", "ignore"])
        self.operation.setToolTip("Select the comparison applied to the chosen field. Hover individual choices for operation-specific guidance.")
        self.value.setToolTip("Enter JSON for typed values and arrays, or plain text when a string comparison is intended.")
        self.unit.setToolTip("Time unit for the Within the last comparison.")
        self.case_sensitive.setToolTip("Enable exact letter-case matching for the Python regular expression.")
        self.text_encoding.setToolTip("Character encoding used before searching a raw byte value as text.")
        self.decode_errors.setToolTip("Choose whether invalid byte sequences are replaced, rejected, or ignored during text decoding.")
        self.explanation = QtWidgets.QLabel(); self.explanation.setWordWrap(True)
        self.explanation.setStyleSheet("color: palette(mid); padding: 4px 0;")
        form.addRow("Field", self.field); form.addRow("Comparison", self.operation); form.addRow("Value", self.value)
        form.addRow("Relative-time unit", self.unit); form.addRow("", self.case_sensitive)
        form.addRow("Byte-text encoding", self.text_encoding); form.addRow("Decode errors", self.decode_errors)
        form.addRow("", self.explanation)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept); buttons.rejected.connect(self.reject); form.addRow(buttons)
        self.operation.currentIndexChanged.connect(self._operation_changed)
        self.field.currentTextChanged.connect(self._operation_changed)
        if condition:
            self.field.setCurrentText(str(condition.get("field", "")))
            operation_index = self.operation.findData(condition.get("operation", "equals"))
            self.operation.setCurrentIndex(operation_index if operation_index >= 0 else 0)
            if "value" in condition:
                value = condition["value"]
                if str(condition.get("field", "")) in TIMESTAMP_FIELDS:
                    value = _local_query_value(value)
                try: rendered_value = json.dumps(value, ensure_ascii=False)
                except TypeError: rendered_value = str(value)
                if str(condition.get("field", "")) in TIMESTAMP_FIELDS and isinstance(value, str):
                    rendered_value = value
                self.value.setText(rendered_value)
            self.unit.setCurrentText(str(condition.get("unit", "seconds")))
            self.case_sensitive.setChecked(bool(condition.get("case_sensitive", True)))
            self.text_encoding.setCurrentText(str(condition.get("encoding", "utf-8")))
            self.decode_errors.setCurrentText(str(condition.get("errors", "replace")))
        self._operation_changed()

    def _operation_changed(self, _index=None):
        operation = self.operation.currentData()
        timestamp_field = self.field.currentText().strip() in TIMESTAMP_FIELDS
        needs_value = operation not in {"exists", "missing"}
        self.value.setVisible(needs_value)
        self.layout().labelForField(self.value).setVisible(needs_value)
        self.unit.setVisible(operation == "within_last")
        self.layout().labelForField(self.unit).setVisible(operation == "within_last")
        self.case_sensitive.setVisible(operation == "regex")
        byte_text = operation == "decoded_text_contains"
        self.text_encoding.setVisible(byte_text); self.layout().labelForField(self.text_encoding).setVisible(byte_text)
        self.decode_errors.setVisible(byte_text); self.layout().labelForField(self.decode_errors).setVisible(byte_text)
        explanation = self.operation.itemData(self.operation.currentIndex(), QtCore.Qt.ToolTipRole) or ""
        if timestamp_field and operation != "within_last":
            self.value.setPlaceholderText(
                "Local time: YYYY-MM-DD HH:MM:SS (or a JSON [start, end] range)"
            )
            explanation = (
                f"{explanation} Timestamp values are entered and shown in local time; "
                "Communication Hub stores the query boundary with its local numeric offset."
            )
        else:
            self.value.setPlaceholderText('JSON or text: "RX", 42, [1, 10], Status, or 01FF')
        self.explanation.setText(str(explanation))

    def _accept(self):
        operation = self.operation.currentData()
        raw = self.value.text()
        try: value = json.loads(raw) if raw else None
        except ValueError: value = raw
        self.condition = {"field": self.field.currentText().strip(), "operation": operation}
        if self.condition["field"] in TIMESTAMP_FIELDS and operation != "within_last":
            value = _local_stored_query_value(value)
        if operation not in {"exists", "missing"}: self.condition["value"] = value
        if operation == "within_last": self.condition["unit"] = self.unit.currentText()
        if operation == "regex": self.condition["case_sensitive"] = self.case_sensitive.isChecked()
        if operation == "decoded_text_contains":
            self.condition["encoding"] = self.text_encoding.currentText().strip() or "utf-8"
            self.condition["errors"] = self.decode_errors.currentText()
        if not self.condition["field"]:
            QtWidgets.QMessageBox.warning(self, "Query", "Field is required."); return
        if operation == "regex":
            import re
            try: re.compile(str(value))
            except re.error as error:
                QtWidgets.QMessageBox.warning(self, "Query", f"Invalid regular expression: {error}"); return
        if operation in {"between", "byte_at"} and (not isinstance(value, list) or len(value) != 2):
            QtWidgets.QMessageBox.warning(self, "Query", "This comparison requires a two-item JSON array."); return
        self.accept()


class _ContentAwareTree(QtWidgets.QTreeWidget):
    """Tree whose preferred height follows its currently visible rows."""

    def __init__(self, parent=None, *, minimum_rows=1, maximum_hint_rows=16, fill_available=False):
        super().__init__(parent)
        self.minimum_rows = max(1, int(minimum_rows))
        self.maximum_hint_rows = max(self.minimum_rows, int(maximum_hint_rows))
        self.fill_available = bool(fill_available)
        policy = QtWidgets.QSizePolicy.Expanding if self.fill_available else QtWidgets.QSizePolicy.Fixed
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, policy)
        self.itemExpanded.connect(lambda _item: self.updateGeometry())
        self.itemCollapsed.connect(lambda _item: self.updateGeometry())

    def _visible_row_count(self):
        count = 0

        def visit(item):
            nonlocal count
            count += 1
            if item.isExpanded():
                for child_index in range(item.childCount()):
                    visit(item.child(child_index))

        for index in range(self.topLevelItemCount()):
            visit(self.topLevelItem(index))
        return max(self.minimum_rows, min(count, self.maximum_hint_rows))

    def _content_height(self):
        header_height = self.header().sizeHint().height() if not self.header().isHidden() else 0
        row_height = max(22, self.fontMetrics().height() + 8)
        return header_height + self._visible_row_count() * row_height + self.frameWidth() * 2 + 4

    def sizeHint(self):
        hint = super().sizeHint()
        return QtCore.QSize(hint.width(), self._content_height())

    def minimumSizeHint(self):
        hint = super().minimumSizeHint()
        minimum_height = self.header().sizeHint().height() + max(22, self.fontMetrics().height() + 8)
        return QtCore.QSize(hint.width(), minimum_height + self.frameWidth() * 2 + 4)


class _CollapsibleSection(QtWidgets.QWidget):
    def __init__(
        self, title, content, parent=None, expanded=True, fill_available=False,
        minimum_expanded_height=0,
    ):
        super().__init__(parent)
        self.fill_available = bool(fill_available)
        self.minimum_expanded_height = max(0, int(minimum_expanded_height))
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(0)
        self.toggle = QtWidgets.QToolButton()
        self.toggle.setText(title); self.toggle.setCheckable(True); self.toggle.setChecked(expanded)
        self.toggle.setToolTip(f"Show or hide the {title} fields.")
        self.toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.toggle.setStyleSheet("QToolButton { font-weight: 600; padding: 6px; text-align: left; border: 1px solid palette(mid); }")
        self.content = content
        self.content.setVisible(expanded)
        self.toggle.toggled.connect(self.setExpanded)
        layout.addWidget(self.toggle); layout.addWidget(self.content)
        self._update_vertical_policy(expanded)

    def _update_vertical_policy(self, expanded):
        policy = QtWidgets.QSizePolicy.Expanding if self.fill_available and expanded else QtWidgets.QSizePolicy.Fixed
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, policy)
        self.content.setSizePolicy(QtWidgets.QSizePolicy.Expanding, policy)
        self.setMinimumHeight(self.minimum_expanded_height if expanded else 0)

    def setExpanded(self, expanded):
        self.toggle.blockSignals(True); self.toggle.setChecked(bool(expanded)); self.toggle.blockSignals(False)
        self.toggle.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.content.setVisible(bool(expanded))
        self._update_vertical_policy(bool(expanded))
        self.updateGeometry()


class MessageDetailDialog(QtWidgets.QDialog):
    """Scrollable, collapsible inspector for one serialized message-table row."""

    FIELD_GROUPS = (
        ("Identity and timestamps", ("id", "timestamp", "first_timestamp", "update_count")),
        ("Message and routing", ("name", "direction", "protocol", "protocol_label", "session_id", "connection_id", "peer")),
        ("Storage and parser", ("parsed", "size", "frame_size", "parse_status", "parse_error", "parse_duration_ns")),
    )

    def __init__(self, record, parent=None):
        super().__init__(parent)
        self.record = copy.deepcopy(record or {})
        for field in TIMESTAMP_FIELDS:
            if field in self.record:
                try:
                    self.record[field] = local_iso(self.record[field])
                except (TypeError, ValueError):
                    pass
        self.sections = []
        self.setWindowTitle(f"Message Details - row {self.record.get('id', '?')}")
        self.resize(980, 760)
        root = QtWidgets.QVBoxLayout(self)

        summary = QtWidgets.QLabel(
            f"Row {self.record.get('id', '?')}  ·  {self.record.get('direction', '')}  ·  "
            f"{self.record.get('name', 'Unknown')}  ·  {self.record.get('timestamp', '')}"
        )
        summary.setStyleSheet("font-weight: 600; padding: 4px;"); summary.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        toolbar = QtWidgets.QHBoxLayout(); toolbar.addWidget(summary, 1)
        expand_sections = QtWidgets.QPushButton("Expand sections")
        collapse_sections = QtWidgets.QPushButton("Collapse sections")
        for button in (expand_sections, collapse_sections): button.setMaximumHeight(25)
        toolbar.addWidget(expand_sections); toolbar.addWidget(collapse_sections); root.addLayout(toolbar)

        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        body = QtWidgets.QWidget(); self.body_layout = QtWidgets.QVBoxLayout(body); self.body_layout.setSpacing(7)
        scroll.setWidget(body); root.addWidget(scroll, 1)

        included = set()
        for title, fields in self.FIELD_GROUPS:
            present = [field for field in fields if field in self.record]
            if present:
                included.update(present)
                self._add_section(title, self._field_table(present), expanded=title == "Identity and timestamps")

        if "header" in self.record or "header_fields" in self.record:
            included.update({"header", "header_fields"})
            header_tree = self._new_value_tree()
            if "header" in self.record: self._append_value(header_tree, None, "header", self.record.get("header"))
            if "header_fields" in self.record: self._append_value(header_tree, None, "header_fields", self.record.get("header_fields"))
            header_tree.expandToDepth(1)
            self._add_section("Header and decoded header fields", header_tree, expanded=False)

        included.add("data")
        data_panel = QtWidgets.QWidget(); data_layout = QtWidgets.QVBoxLayout(data_panel)
        data_layout.setContentsMargins(7, 7, 7, 7); data_layout.setSpacing(5)
        data_actions = QtWidgets.QHBoxLayout()
        expand_data = QtWidgets.QPushButton("Expand data")
        collapse_data = QtWidgets.QPushButton("Collapse data")
        copy_path = QtWidgets.QPushButton("Copy selected path")
        copy_value = QtWidgets.QPushButton("Copy selected value")
        for button in (expand_data, collapse_data, copy_path, copy_value): button.setMaximumHeight(24)
        data_actions.addWidget(expand_data); data_actions.addWidget(collapse_data); data_actions.addStretch(1)
        data_actions.addWidget(copy_path); data_actions.addWidget(copy_value); data_layout.addLayout(data_actions)
        self.data_tree = self._new_value_tree(fill_available=True)
        self._append_value(self.data_tree, None, "data", self.record.get("data"))
        self.data_tree.expandToDepth(2); data_layout.addWidget(self.data_tree)
        expand_data.clicked.connect(self.data_tree.expandAll); collapse_data.clicked.connect(self.data_tree.collapseAll)
        copy_path.clicked.connect(lambda: self._copy_tree_data(self.data_tree, QtCore.Qt.UserRole))
        copy_value.clicked.connect(lambda: self._copy_tree_data(self.data_tree, QtCore.Qt.UserRole + 1))
        self.data_section = self._add_section(
            "Data (nested parser output or raw bytes)", data_panel, expanded=True,
            fill_available=True, minimum_expanded_height=350,
        )

        other = [field for field in self.record if field not in included]
        if other: self._add_section("Other fields", self._field_table(other), expanded=False)
        expand_sections.clicked.connect(lambda: self._set_all_sections(True))
        collapse_sections.clicked.connect(lambda: self._set_all_sections(False))
        close = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        close.rejected.connect(self.reject); root.addWidget(close)

    @staticmethod
    def _value_type(value):
        if isinstance(value, dict) and set(value) == {"$bytes_hex"}: return "bytes"
        if value is None: return "null"
        return type(value).__name__

    @staticmethod
    def _value_text(value, maximum=4096):
        if isinstance(value, dict) and set(value) == {"$bytes_hex"}:
            compact = str(value.get("$bytes_hex", "")); rendered = " ".join(compact[index:index + 2].upper() for index in range(0, len(compact), 2))
        elif isinstance(value, (dict, list)):
            rendered = f"{len(value)} item{'s' if len(value) != 1 else ''}"
        elif isinstance(value, str): rendered = value
        else:
            try: rendered = json.dumps(value, ensure_ascii=False)
            except TypeError: rendered = str(value)
        return rendered if len(rendered) <= maximum else rendered[:maximum] + f"… ({len(rendered):,} characters)"

    @staticmethod
    def _copy_text(value):
        if isinstance(value, str): return value
        try: return json.dumps(value, indent=2, ensure_ascii=False)
        except TypeError: return str(value)

    def _new_value_tree(self, *, fill_available=False):
        tree = _ContentAwareTree(minimum_rows=2 if fill_available else 1, fill_available=fill_available)
        tree.setHeaderLabels(["Field path", "Type", "Value"])
        tree.setAlternatingRowColors(True); tree.setUniformRowHeights(True)
        tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        return tree

    def _append_value(self, tree, parent, path, value):
        item = QtWidgets.QTreeWidgetItem([path, self._value_type(value), self._value_text(value)])
        item.setData(0, QtCore.Qt.UserRole, path)
        item.setData(0, QtCore.Qt.UserRole + 1, self._copy_text(value))
        (parent.addChild(item) if parent is not None else tree.addTopLevelItem(item))
        if isinstance(value, dict) and set(value) != {"$bytes_hex"}:
            for key, child in value.items(): self._append_value(tree, item, f"{path}.{key}", child)
        elif isinstance(value, list):
            for index, child in enumerate(value): self._append_value(tree, item, f"{path}.{index}", child)
        return item

    def _field_table(self, fields):
        tree = self._new_value_tree(); tree.setRootIsDecorated(False)
        for field in fields:
            value = self.record.get(field)
            self._append_value(
                tree, None, field,
                _local_timestamp_text(value) if field in TIMESTAMP_FIELDS else value,
            )
        return tree

    def _add_section(
        self, title, content, expanded=True, fill_available=False, minimum_expanded_height=0,
    ):
        section = _CollapsibleSection(
            title, content, self, expanded, fill_available, minimum_expanded_height
        )
        self.sections.append(section); self.body_layout.addWidget(section, 1 if fill_available else 0)
        return section

    def _set_all_sections(self, expanded):
        for section in self.sections: section.setExpanded(expanded)

    @staticmethod
    def _copy_tree_data(tree, role):
        item = tree.currentItem()
        if item is not None: QtWidgets.QApplication.clipboard().setText(str(item.data(0, role) or ""))


class MessageFilterDesignerWidget(QtWidgets.QWidget):
    """Reusable container and API for the complete message-table filter designer.

    The host remains responsible for table/session persistence and query execution;
    this widget owns the visual designer surface and provides a stable boundary for
    embedding it in tabs, dialogs, or future dock areas.
    """

    queryChanged = QtCore.pyqtSignal(object)
    validationChanged = QtCore.pyqtSignal(bool, str)
    modeChanged = QtCore.pyqtSignal(str)

    def __init__(self, host, content=None, parent=None):
        super().__init__(parent)
        self.host = host
        self._standalone = content is None
        self.setObjectName("messageFilterDesignerWidget")
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(0)
        if content is None:
            self.content = self._build_standalone(); layout.addWidget(self.content)
        else:
            content.setParent(self); layout.addWidget(content); self.content = content
        self.setToolTip(
            "Reusable message filter designer with saved queries, common presets, guided conditions, Advanced JSON, validation, and per-scope state."
        )

    @property
    def guided_tab(self):
        return self._guided_tab if self._standalone else self.host.query_guided_tab

    @property
    def advanced_tab(self):
        return self._advanced_tab if self._standalone else self.host.query_advanced_tab

    @property
    def tabs(self):
        return self._tabs if self._standalone else self.host.query_tabs

    def query(self):
        """Return the validated active guided or Advanced JSON query."""
        if not self._standalone: return copy.deepcopy(self.host._query())
        query = json.loads(self._advanced_edit.toPlainText() or "{}") if self.mode() == "advanced" else self._query_from_standalone_builder()
        self.host._validate_query_node(query)
        return copy.deepcopy(query)

    def set_query(self, query, *, apply=False):
        """Load a query without losing nested-query fallback behavior."""
        if not self._standalone:
            self.host._load_query_into_ui(copy.deepcopy(query or {}), apply=apply); return
        query = copy.deepcopy(query or {}); self.host._validate_query_node(query)
        if self._populate_standalone_builder(query): self._tabs.setCurrentWidget(self._guided_tab)
        else:
            self._advanced_edit.blockSignals(True)
            self._advanced_edit.setPlainText(json.dumps(query, indent=2, ensure_ascii=False))
            self._advanced_edit.blockSignals(False)
            self._tabs.setCurrentWidget(self._advanced_tab)
        self._standalone_changed()

    def clear_query(self, *, refresh=True):
        if self._standalone:
            self._condition_tree.clear(); self._match_mode.setCurrentIndex(0); self._exclude.setChecked(False)
            self._tabs.setCurrentWidget(self._guided_tab); self._standalone_changed(); return
        if refresh:
            self.host._clear_query()
        else:
            self.host.query_conditions.clear()
            self.host.query_match_mode.setCurrentIndex(0)
            self.host.query_exclude.setChecked(False)
            self.host.query_tabs.setCurrentWidget(self.host.query_guided_tab)
            self.host._visual_query_changed()

    def mode(self):
        return "advanced" if self.tabs.currentWidget() is self.advanced_tab else "guided"

    def focus_editor(self):
        if self._standalone:
            (self._advanced_edit if self.mode() == "advanced" else self._condition_tree).setFocus()
        elif self.mode() == "advanced": self.host.query_edit.setFocus()
        else: self.host.query_conditions.setFocus()

    def notify_query_state(self, valid, message, query=None):
        self.validationChanged.emit(bool(valid), str(message))
        self.modeChanged.emit(self.mode())
        if valid:
            self.queryChanged.emit(copy.deepcopy(query or {}))

    def _build_standalone(self):
        page = QtWidgets.QWidget(); root = QtWidgets.QVBoxLayout(page); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(6)
        quick = QtWidgets.QHBoxLayout(); root.addLayout(quick)
        self._saved_combo = QtWidgets.QComboBox(); self._saved_combo.addItem("Load saved filter...", None)
        for entry in self.host.config.get("saved_queries", []):
            if isinstance(entry, dict) and entry.get("id"): self._saved_combo.addItem(str(entry.get("name", "Unnamed")), entry.get("id"))
        self._saved_combo.setToolTip("Load a saved Communication Hub filter into this Protocol Insight source.")
        self._saved_combo.currentIndexChanged.connect(self._load_standalone_saved)
        quick.addWidget(self._saved_combo, 1)
        presets = QtWidgets.QComboBox(); presets.addItem("Common filter...", None)
        for title, tooltip, query in self.host._common_query_definitions(): presets.addItem(title, copy.deepcopy(query)); presets.setItemData(presets.count() - 1, tooltip, QtCore.Qt.ToolTipRole)
        presets.currentIndexChanged.connect(lambda index: self.set_query(presets.itemData(index)) if index > 0 else None)
        presets.setToolTip("Start from a common validated filter and then customize it.")
        quick.addWidget(presets)
        self._tabs = QtWidgets.QTabWidget(); self._tabs.setToolTip("Switch between the table-based builder and complete nested query JSON."); root.addWidget(self._tabs, 1)
        self._guided_tab = QtWidgets.QWidget(); guided_layout = QtWidgets.QVBoxLayout(self._guided_tab)
        mode_row = QtWidgets.QHBoxLayout(); guided_layout.addLayout(mode_row)
        self._match_mode = QtWidgets.QComboBox(); self._match_mode.addItem("Match all conditions (AND)", "and"); self._match_mode.addItem("Match any condition (OR)", "or")
        self._exclude = QtWidgets.QCheckBox("Exclude matching rows (NOT)")
        self._match_mode.setToolTip("Choose whether every guided condition or at least one guided condition must match.")
        self._exclude.setToolTip("Invert the complete guided filter while preserving all of its conditions.")
        mode_row.addWidget(self._match_mode); mode_row.addWidget(self._exclude); mode_row.addStretch(1)
        self._condition_tree = QtWidgets.QTreeWidget(); self._condition_tree.setHeaderLabels(["Field", "Comparison", "Value", "Options"])
        self._condition_tree.setRootIsDecorated(False); self._condition_tree.setAlternatingRowColors(True)
        self._condition_tree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection); self._condition_tree.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self._condition_tree.setToolTip("Editable condition table. Double-click a row to configure every option supported by Filter Designer.")
        for column, mode in ((0, QtWidgets.QHeaderView.Stretch), (1, QtWidgets.QHeaderView.ResizeToContents), (2, QtWidgets.QHeaderView.Stretch), (3, QtWidgets.QHeaderView.ResizeToContents)): self._condition_tree.header().setSectionResizeMode(column, mode)
        self._condition_tree.itemDoubleClicked.connect(lambda *_args: self._edit_standalone_condition())
        guided_layout.addWidget(self._condition_tree, 1)
        actions = QtWidgets.QHBoxLayout(); actions.addStretch(1); guided_layout.addLayout(actions)
        for text_value, slot, tooltip in (
            ("Add condition...", self._add_standalone_condition, "Add any supported message-table field comparison."),
            ("Edit selected...", self._edit_standalone_condition, "Edit the selected condition."),
            ("Duplicate", self._duplicate_standalone_condition, "Duplicate the selected condition."),
            ("Remove selected", self._remove_standalone_conditions, "Remove selected conditions."),
            ("Clear", lambda _checked=False: self.clear_query(), "Clear this complete filter."),
        ):
            button = QtWidgets.QPushButton(text_value); button.setToolTip(tooltip); button.clicked.connect(slot); actions.addWidget(button)
        guided_index = self._tabs.addTab(self._guided_tab, "Guided Filter Builder")
        self._tabs.setTabToolTip(guided_index, "Build a flat AND/OR filter with editable condition rows.")
        self._advanced_tab = QtWidgets.QWidget(); advanced_layout = QtWidgets.QVBoxLayout(self._advanced_tab)
        note_row = QtWidgets.QHBoxLayout(); advanced_layout.addLayout(note_row)
        note = QtWidgets.QLabel("Nested AND/OR/NOT groups and every supported query operation are available here."); note.setWordWrap(True); note.setStyleSheet("color: palette(mid);")
        guide = QtWidgets.QPushButton("Query language guide..."); guide.clicked.connect(self.host._show_advanced_query_guide)
        guide.setToolTip("Open field, operator, value, and nested-group examples for Advanced JSON.")
        note_row.addWidget(note, 1); note_row.addWidget(guide)
        self._advanced_edit = QtWidgets.QPlainTextEdit("{}"); self._advanced_edit.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont)); self._advanced_edit.setToolTip("Edit nested AND, OR, and NOT query JSON with immediate validation."); advanced_layout.addWidget(self._advanced_edit, 1)
        self._validation = QtWidgets.QLabel("Valid query JSON"); advanced_layout.addWidget(self._validation)
        advanced_index = self._tabs.addTab(self._advanced_tab, "Advanced JSON")
        self._tabs.setTabToolTip(advanced_index, "Use nested groups and the complete query language without guided-mode simplification.")
        self._match_mode.currentIndexChanged.connect(self._standalone_changed); self._exclude.toggled.connect(self._standalone_changed)
        self._advanced_edit.textChanged.connect(self._standalone_changed); self._tabs.currentChanged.connect(self._standalone_changed)
        self._standalone_changed()
        return page

    def _standalone_condition_item(self, condition, select=False):
        condition = copy.deepcopy(condition); value = condition.get("value", "")
        display_value = (
            _local_query_value(value)
            if str(condition.get("field", "")) in TIMESTAMP_FIELDS else value
        )
        item = QtWidgets.QTreeWidgetItem([
            str(condition.get("field", "")), self.host._operation_title(condition.get("operation", "equals")),
            display_value if isinstance(display_value, str) else json.dumps(display_value, ensure_ascii=False), self.host._condition_options(condition),
        ])
        item.setData(0, QtCore.Qt.UserRole, condition); self._condition_tree.addTopLevelItem(item)
        if select: self._condition_tree.setCurrentItem(item); item.setSelected(True)
        return item

    def _query_from_standalone_builder(self):
        conditions = [copy.deepcopy(self._condition_tree.topLevelItem(index).data(0, QtCore.Qt.UserRole)) for index in range(self._condition_tree.topLevelItemCount())]
        if not conditions: return {}
        if len(conditions) == 1 and not self._exclude.isChecked(): return conditions[0]
        result = {"operator": self._match_mode.currentData() or "and", "conditions": conditions}
        if self._exclude.isChecked(): result["not"] = True
        return result

    def _populate_standalone_builder(self, query):
        if not query: operator, excluded, conditions = "and", False, []
        elif "conditions" in query and all(isinstance(item, dict) and "conditions" not in item for item in query.get("conditions", [])): operator, excluded, conditions = str(query.get("operator", "and")), bool(query.get("not", False)), query.get("conditions", [])
        elif "conditions" not in query: operator, excluded, conditions = "and", False, [query]
        else: return False
        self._condition_tree.clear(); self._match_mode.setCurrentIndex(max(0, self._match_mode.findData(operator))); self._exclude.setChecked(excluded)
        for condition in conditions: self._standalone_condition_item(condition)
        return True

    def _standalone_changed(self, *_args):
        if not self._standalone: return
        if self.mode() == "guided":
            query = self._query_from_standalone_builder(); self._advanced_edit.blockSignals(True); self._advanced_edit.setPlainText(json.dumps(query, indent=2, ensure_ascii=False)); self._advanced_edit.blockSignals(False)
        try:
            query = json.loads(self._advanced_edit.toPlainText() or "{}") if self.mode() == "advanced" else self._query_from_standalone_builder(); self.host._validate_query_node(query)
        except (TypeError, ValueError) as error:
            message = f"Invalid query: {error}"; self._validation.setText(message); self._validation.setStyleSheet("color: #A12622;"); self.notify_query_state(False, message)
        else:
            message = f"Valid filter - {self.host._query_condition_count(query)} condition(s)"; self._validation.setText(message); self._validation.setStyleSheet("color: #1B7F3A;"); self.notify_query_state(True, message, query)

    def _load_standalone_saved(self, index):
        query_id = self._saved_combo.itemData(index)
        entry = self.host._saved_query_by_id(query_id)
        if entry is not None: self.set_query(entry.get("query", {}))

    def _add_standalone_condition(self):
        dialog = QueryConditionDialog(self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted: self._standalone_condition_item(dialog.condition, True); self._standalone_changed()

    def _edit_standalone_condition(self):
        item = self._condition_tree.currentItem()
        if item is None: return
        dialog = QueryConditionDialog(self, item.data(0, QtCore.Qt.UserRole))
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        row = self._condition_tree.indexOfTopLevelItem(item)
        self._condition_tree.takeTopLevelItem(row)
        replacement = self._standalone_condition_item(dialog.condition)
        moved = self._condition_tree.takeTopLevelItem(
            self._condition_tree.indexOfTopLevelItem(replacement)
        )
        self._condition_tree.insertTopLevelItem(row, moved)
        self._condition_tree.setCurrentItem(moved)
        self._standalone_changed()

    def _duplicate_standalone_condition(self):
        item = self._condition_tree.currentItem()
        if item is not None: self._standalone_condition_item(item.data(0, QtCore.Qt.UserRole), True); self._standalone_changed()

    def _remove_standalone_conditions(self):
        rows = sorted({self._condition_tree.indexOfTopLevelItem(item) for item in self._condition_tree.selectedItems()}, reverse=True)
        for row in rows: self._condition_tree.takeTopLevelItem(row)
        self._standalone_changed()


class CommunicationHubWidget(QtWidgets.QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Communication Hub")
        self.resize(1250, 900)
        self.controllers: dict[str, SessionController] = {}
        self._session_operations: dict[str, str] = {}
        self._persisted_table_loads: set[str] = set()
        self._periodic_inflight: set[str] = set()
        self._periodic_worker_inflight: set[str] = set()
        self._periodic_status_inflight: set[str] = set()
        self._periodic_status_errors: dict[str, str] = {}
        self._periodic_status_error_until: dict[str, float] = {}
        self._periodic_status_error_active: set[str] = set()
        self._periodic_schedule_revisions: dict[str, int] = {}
        self._periodic_refresh_pending = False
        self._shutting_down = False
        self._ui_attached = True
        self._application_shutdown_requested = False
        self._window_detach_stops: set[str] = set()
        self._calls: set[_AsyncCall] = set()
        self._protocol_insight_session_states: dict[tuple[str, str], tuple[str, str]] = {}
        self._active_saved_query_id = None
        self.page = 0
        self.page_size = 200
        self._last_table_version = -1
        self._last_name_summary_version = -1
        self._query_state_ready = False
        self._table_indicator_flash_step = 0
        self._table_session_id = None
        self.config = self._load_config()
        self._session_restore_ids: set[str] = {
            str(session.get("id", ""))
            for session in self.config.get("sessions", [])
            if isinstance(session, dict)
            and session.get("lifecycle", {}).get("restore_last_state", True)
            and session.get("lifecycle", {}).get("last_running_on_close", False)
        }
        self._session_detached_restore_ids: set[str] = set()
        # A process cannot survive an application restart, but the user's last
        # intentional running state can. Keep it separate from current process
        # activity and from the unconditional autostart preference.
        self._protocol_insight_restore_ids: set[str] = set()
        self._protocol_insight_detached_restore_ids: set[str] = set()
        for insight in self.config.get("protocol_insights", []):
            dataset = insight.get("dataset", {}) if isinstance(insight, dict) else {}
            runtime = dataset.setdefault("runtime", {})
            lifecycle = insight.get("lifecycle", {}) if isinstance(insight, dict) else {}
            if (
                bool(lifecycle.get("restore_last_state", True))
                and bool(runtime.get("last_active_on_close", runtime.get("active", False)))
            ):
                self._protocol_insight_restore_ids.add(str(insight.get("id", "")))
            runtime["active"] = False
            runtime["paused"] = False
        self.config["protocol_insight_service"] = normalize_protocol_insight_service_config(
            self.config.get("protocol_insight_service")
        )
        self.protocol_insight_service = ProtocolInsightServiceController(
            PROJECT_ROOT, self.config["protocol_insight_service"]
        )
        self._protocol_insight_service_status: dict[str, Any] = {}
        self._normalize_message_table_scope(self.config)
        self._message_table_scope = self.config["message_table_scope"]
        query_state = self.config.get("query_ui_state", {})
        if isinstance(query_state, dict):
            try: self.page = max(0, int(query_state.get("page", self.page)))
            except (TypeError, ValueError): pass
            try: self.page_size = int(query_state.get("page_size", self.page_size))
            except (TypeError, ValueError): pass
            if self.page_size not in {100, 200, 500, 1000}: self.page_size = 200
        self._build_ui()
        self._reload_sessions()
        self._restore_query_ui_state()
        self._query_state_ready = True
        self.timer = QtCore.QTimer(self); self.timer.setInterval(1000); self.timer.timeout.connect(self._poll_status); self.timer.start()
        self.periodic_timer = QtCore.QTimer(self)
        self.periodic_timer.setInterval(500); self.periodic_timer.timeout.connect(self._periodic_tick); self.periodic_timer.start()
        QtCore.QTimer.singleShot(0, self._restore_persisted_tables_then_autostart)

    def _load_config(self):
        try:
            value = load_json(COMMUNICATION_HUB_SETTINGS)
            if isinstance(value, dict):
                value.setdefault("sessions", []); value.setdefault("saved_messages", [])
                value.setdefault("periodic_messages", []); value.setdefault("periodic_panel_visible", False)
                value.setdefault("saved_queries", [])
                value.setdefault("query_ui_state", {})
                configurations = value.get("protocol_insights", [])
                if not isinstance(configurations, list):
                    configurations = []
                configurations = [
                    normalize_protocol_insight_config(item)
                    for item in configurations if isinstance(item, dict)
                ]
                if not configurations:
                    configurations = [default_protocol_insight_config("Protocol Insight 1")]
                value["protocol_insights"] = configurations
                active = str(value.get("active_protocol_insight_id", ""))
                ids = {str(item.get("id", "")) for item in configurations}
                value["active_protocol_insight_id"] = active if active in ids else configurations[0]["id"]
                self._normalize_session_query_states(value)
                self._normalize_last_period_filter(value)
                self._normalize_common_name_filter(value)
                self._normalize_common_datetime_filters(value)
                self._normalize_common_filter_mode(value)
                self._normalize_message_table_scope(value)
                value.setdefault("periodic_max_inflight", 16)
                self._normalize_saved_queries(value)
                self._normalize_periodic_settings(value)
                return value
            return {"schema_version": 1, "sessions": [], "protocol_insights": [default_protocol_insight_config("Protocol Insight 1")], "saved_messages": [], "saved_queries": [], "query_ui_state": {}, "query_ui_state_by_session": {}, "message_table_scope": "per_session", "common_filter_mode": "replace", "last_period_filter": {"amount": 10, "unit": "seconds"}, "common_name_filter": {"name": "Unknown"}, "common_datetime_filters": {}, "periodic_messages": [], "periodic_panel_visible": False, "periodic_max_inflight": 16}
        except BaseException:
            return {"schema_version": 1, "sessions": [], "protocol_insights": [default_protocol_insight_config("Protocol Insight 1")], "saved_messages": [], "saved_queries": [], "query_ui_state": {}, "query_ui_state_by_session": {}, "message_table_scope": "per_session", "common_filter_mode": "replace", "last_period_filter": {"amount": 10, "unit": "seconds"}, "common_name_filter": {"name": "Unknown"}, "common_datetime_filters": {}, "periodic_messages": [], "periodic_panel_visible": False, "periodic_max_inflight": 16}

    @staticmethod
    def _normalize_session_query_states(settings):
        states = settings.get("query_ui_state_by_session", {})
        if not isinstance(states, dict): states = {}
        states = {str(key): copy.deepcopy(value) for key, value in states.items() if isinstance(value, dict)}
        legacy = settings.get("query_ui_state", {})
        sessions = settings.get("sessions", [])
        if not states and isinstance(legacy, dict) and legacy and sessions:
            first_id = str(sessions[0].get("id", ""))
            if first_id: states[first_id] = copy.deepcopy(legacy)
        settings["query_ui_state_by_session"] = states

    @staticmethod
    def _normalize_last_period_filter(settings):
        raw = settings.get("last_period_filter", {})
        if not isinstance(raw, dict): raw = {}
        try: amount = float(raw.get("amount", 10) or 10)
        except (TypeError, ValueError): amount = 10.0
        unit = str(raw.get("unit", "seconds"))
        if unit not in {"milliseconds", "seconds", "minutes", "hours"}: unit = "seconds"
        settings["last_period_filter"] = {"amount": min(1_000_000.0, max(0.001, amount)), "unit": unit}

    @staticmethod
    def _normalize_common_name_filter(settings):
        raw = settings.get("common_name_filter", {})
        if not isinstance(raw, dict): raw = {}
        settings["common_name_filter"] = {"name": str(raw.get("name", "Unknown") or "Unknown").strip() or "Unknown"}

    @staticmethod
    def _normalize_common_datetime_filters(settings):
        raw = settings.get("common_datetime_filters", {})
        if not isinstance(raw, dict): raw = {}
        fallback = local_now_iso(timespec="seconds")
        normalized = {}
        for kind in ("before", "after"):
            entry = raw.get(kind, {})
            if not isinstance(entry, dict): entry = {}
            value = str(entry.get("datetime", fallback) or fallback).strip()
            try:
                value = local_iso(value)
            except (TypeError, ValueError):
                value = fallback
            normalized[kind] = {"datetime": value, "inclusive": bool(entry.get("inclusive", False))}
        settings["common_datetime_filters"] = normalized

    @staticmethod
    def _normalize_common_filter_mode(settings):
        mode = str(settings.get("common_filter_mode", "replace")).lower()
        settings["common_filter_mode"] = mode if mode in {"replace", "append"} else "replace"

    @staticmethod
    def _normalize_message_table_scope(settings):
        scope = str(settings.get("message_table_scope", "per_session")).lower()
        settings["message_table_scope"] = scope if scope in {"global", "per_session"} else "per_session"

    @staticmethod
    def _normalize_saved_queries(settings):
        raw_queries = settings.get("saved_queries", [])
        if not isinstance(raw_queries, list): raw_queries = []
        normalized = []
        for raw in raw_queries:
            if not isinstance(raw, dict) or not isinstance(raw.get("query", {}), dict):
                continue
            normalized.append({
                "id": str(raw.get("id") or uuid.uuid4()),
                "name": str(raw.get("name") or "Saved query"),
                "query": copy.deepcopy(raw.get("query", {})),
            })
        settings["saved_queries"] = normalized

    @staticmethod
    def _normalize_periodic_settings(settings):
        normalized = []
        raw_entries = settings.get("periodic_messages", [])
        if not isinstance(raw_entries, list): raw_entries = []
        for raw in raw_entries:
            if not isinstance(raw, dict):
                continue
            entry = copy.deepcopy(raw)
            try: interval = float(entry.get("interval_seconds", 1.0) or 1.0)
            except (TypeError, ValueError): interval = 1.0
            try: sent_count = max(0, int(entry.get("sent_count", 0) or 0))
            except (TypeError, ValueError): sent_count = 0
            encoding = str(entry.get("encoding", "utf-8"))
            if encoding not in {"utf-8", "ascii", "hex"}: encoding = "utf-8"
            entry.update({
                "id": str(entry.get("id") or uuid.uuid4()),
                "name": str(entry.get("name") or "Periodic message"),
                "session_id": str(entry.get("session_id") or ""),
                "target": str(entry.get("target") or ""),
                "target_label": str(entry.get("target_label") or "Configured endpoint"),
                "encoding": encoding,
                "content": str(entry.get("content", "")),
                "interval_seconds": min(86_400.0, max(0.05, interval)),
                "enabled": bool(entry.get("enabled", True)),
                "paused_by_session_stop": bool(entry.get("paused_by_session_stop", False)),
                "auto_start": bool(entry.get("auto_start", True)),
                "start_with_session": bool(entry.get("start_with_session", True)),
                "sent_count": sent_count,
                "last_sent_at": str(entry.get("last_sent_at", "") or ""),
                "last_error": str(entry.get("last_error", "") or ""),
            })
            normalized.append(entry)
        settings["periodic_messages"] = normalized
        try: maximum = int(settings.get("periodic_max_inflight", 16) or 16)
        except (TypeError, ValueError): maximum = 16
        settings["periodic_max_inflight"] = min(64, max(1, maximum))

    def _save(self):
        save_json(COMMUNICATION_HUB_SETTINGS, self.config)

    def _build_ui(self):
        root = QtWidgets.QHBoxLayout(self)
        left = QtWidgets.QVBoxLayout(); root.addLayout(left, 0)
        self.sessions = QtWidgets.QTreeWidget(); self.sessions.setMinimumWidth(430)
        self.sessions.setHeaderLabels(["", "", "Session", "Protocol", "Status"])
        self.sessions.setRootIsDecorated(False); self.sessions.setItemsExpandable(False)
        self.sessions.setAlternatingRowColors(True); self.sessions.setUniformRowHeights(True)
        self.sessions.setAllColumnsShowFocus(True)
        self.sessions.header().setMinimumSectionSize(12)
        self.sessions.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Fixed)
        self.sessions.header().resizeSection(0, 30)
        self.sessions.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.sessions.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.sessions.header().setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        self.sessions.header().setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeToContents)
        self.sessions.setStyleSheet(
            "QTreeWidget { border: 1px solid palette(mid); alternate-background-color: palette(alternate-base); }"
            "QTreeWidget::item { padding: 0; }"
            "QHeaderView::section { font-weight: 600; padding: 5px; border: 0; border-bottom: 1px solid palette(mid); }"
        )
        self.sessions.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.sessions.setToolTip(
            "Select one session to inspect or route messages. Ctrl/Shift-select multiple rows for bulk start, stop, or removal. "
            "Use the icon at the left of a row to start or stop it, and right-click for configuration actions."
        )
        self.sessions.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.sessions.currentItemChanged.connect(self._session_tree_selection_changed)
        self.sessions.itemSelectionChanged.connect(self._session_selection_changed)
        self.sessions.customContextMenuRequested.connect(self._session_context_menu)
        left.addWidget(QtWidgets.QLabel("Sessions")); left.addWidget(self.sessions, 1)
        session_edit_actions = QtWidgets.QHBoxLayout(); left.addLayout(session_edit_actions)
        self.new_session_button = QtWidgets.QPushButton("New Session")
        self.remove_sessions_button = QtWidgets.QPushButton("Remove Selected")
        self.new_session_button.setToolTip("Create and configure a new communication session.")
        self.remove_sessions_button.setToolTip("Remove all selected stopped sessions after confirmation.")
        self.new_session_button.clicked.connect(self._add_session)
        self.remove_sessions_button.clicked.connect(self._remove_session)
        session_run_actions = QtWidgets.QHBoxLayout(); left.addLayout(session_run_actions)
        self.run_selected_sessions_button = QtWidgets.QPushButton("Run Selected")
        self.stop_selected_sessions_button = QtWidgets.QPushButton("Stop Selected")
        self.select_all_sessions_button = QtWidgets.QPushButton("Select All")
        self.run_selected_sessions_button.setToolTip("Start every selected session that is currently stopped.")
        self.stop_selected_sessions_button.setToolTip("Stop every selected session that is currently running.")
        self.select_all_sessions_button.setToolTip("Select every session row so a bulk action can be applied.")
        self.run_selected_sessions_button.clicked.connect(self._run_selected_sessions)
        self.stop_selected_sessions_button.clicked.connect(self._stop_selected_sessions)
        self.select_all_sessions_button.clicked.connect(self._select_all_sessions)
        session_edit_actions.addWidget(self.new_session_button)
        session_edit_actions.addWidget(self.select_all_sessions_button)
        session_run_actions.addWidget(self.run_selected_sessions_button)
        session_run_actions.addWidget(self.stop_selected_sessions_button)
        session_run_actions.addWidget(self.remove_sessions_button)
        self.tabs = QtWidgets.QTabWidget(); root.addWidget(self.tabs, 1)
        self._build_monitor_tab(); self._build_table_tab(); self._build_protocol_insights_tab()
        for tab, tooltip in (
            (self.monitor_tab, "Choose a session, compose exact outgoing bytes, send once or periodically, and inspect live activity."),
            (self.table_tab, "Query, inspect, delete, summarize, and export rows from current or retained message tables."),
            (self.protocol_insights_tab, "Explore retained protocol messages, turn useful series into a live insight dataset, and manage sampling, thresholds, retention, and output in one tool."),
        ):
            self.tabs.setTabToolTip(self.tabs.indexOf(tab), tooltip)
        self.tabs.currentChanged.connect(self._main_tab_changed)

    def _main_tab_changed(self, _index):
        insights_active = self._protocol_insights_active("explore")
        if hasattr(self, "insight_panel"):
            self.insight_panel.set_tab_active(insights_active)
        current = self.tabs.currentWidget()
        if insights_active:
            self.insight_panel.request_authoritative_snapshot()
            QtCore.QTimer.singleShot(0, self.insight_panel.refresh)
        elif current is self.table_tab:
            self._last_table_version = -1
            self._last_name_summary_version = -1
            QtCore.QTimer.singleShot(0, lambda: self._refresh_table(reset=True))
            QtCore.QTimer.singleShot(0, lambda: self._refresh_name_summary(force=True))
        elif current is self.monitor_tab:
            QtCore.QTimer.singleShot(0, self._poll_status)

    def _build_protocol_insights_tab(self):
        self.protocol_insights_tab = ProtocolInsightsPanel(self, self)
        self.insight_panel = self.protocol_insights_tab
        self.tabs.addTab(self.protocol_insights_tab, "Protocol Insights")

    def _protocol_insights_active(self, mode=None):
        return bool(
            hasattr(self, "protocol_insights_tab")
            and self.tabs.currentWidget() is self.protocol_insights_tab
        )

    def _open_protocol_insights(self, mode="explore"):
        self.tabs.setCurrentWidget(self.protocol_insights_tab)

    def _insights_mode_changed(self, index):
        QtCore.QTimer.singleShot(0, self.insight_panel.refresh)

    def _refresh_insights_status(self):
        return

    @staticmethod
    def _insight_series_query(series):
        conditions = []
        if isinstance(series.get("query"), dict) and series.get("query"):
            conditions.append(copy.deepcopy(series["query"]))
        if series.get("session_id"):
            conditions.append({
                "field": "session_id", "operation": "equals",
                "value": str(series["session_id"]),
            })
        names = [str(item) for item in series.get("message_names", []) if str(item)]
        if names:
            conditions.append({
                "operator": "or", "conditions": [
                    {"field": "name", "operation": "glob", "value": name}
                    for name in names
                ],
            })
        if series.get("direction") in {"RX", "TX"}:
            conditions.append({
                "field": "direction", "operation": "equals",
                "value": series["direction"],
            })
        if not conditions:
            return {}
        return conditions[0] if len(conditions) == 1 else {
            "operator": "and", "conditions": conditions,
        }

    def _protocol_insight_sessions(self, view):
        insight_source = normalize_protocol_insight_source(
            view.get("source"), view.get("scope", "current")
        )
        scope = insight_source.get("scope", "current")
        if scope == "all":
            return list(self.config.get("sessions", []))
        if scope == "selected":
            selected_ids = {str(item) for item in insight_source.get("session_ids", [])}
            return [
                item for item in self.config.get("sessions", [])
                if str(item.get("id")) in selected_ids
            ]
        current = self._selected_config()
        return [current] if current else []

    def _ensure_protocol_insight_service(self):
        started = not self.protocol_insight_service.running
        if not started:
            # This helper is called by the GUI refresh path. Never turn it into
            # a synchronous service round trip while live collection is busy.
            return self._protocol_insight_service_status
        try:
            status = self.protocol_insight_service.start()
        except BaseException as error:
            if not self._is_protocol_insight_ipc_failure(error):
                raise
            status = self._rebuild_protocol_insight_ipc()
        self._protocol_insight_service_status = status if isinstance(status, dict) else {}
        if started:
            for view in self.config.get("protocol_insights", []):
                dataset = view.get("dataset", {}) if isinstance(view, dict) else {}
                if (
                    not dataset.get("enabled")
                    or not dataset.get("runtime", {}).get("active", False)
                ):
                    continue
                runtime = self._protocol_insight_runtime_config(view)
                self.protocol_insight_service.request("upsert", {"config": runtime})
                if dataset.get("runtime", {}).get("paused", False):
                    self.protocol_insight_service.request(
                        "pause", {"protocol_insight_id": runtime["id"]}
                    )
            self._protocol_insight_service_status = self.protocol_insight_service.request(
                "status", timeout=5
            )
        return self._protocol_insight_service_status

    @staticmethod
    def _is_protocol_insight_ipc_failure(error):
        if isinstance(error, (BrokenPipeError, ConnectionError, EOFError, OSError)):
            return True
        text = f"{type(error).__name__}: {error}"
        return any(marker in text for marker in (
            "WinError 5", "WinError 109", "WinError 232",
            "PermissionError", "Access is denied", "pipe is being closed",
            "pipe has been ended",
        ))

    def _rebuild_protocol_insight_ipc(self):
        """Recreate service/queue handles and rebind every live session worker."""
        running = []
        for session_id, controller in list(self.controllers.items()):
            if controller.running:
                running.append((session_id, controller))
                controller.stop(timeout=15)

        self.protocol_insight_service.discard_broken_process()
        self.protocol_insight_service.replace_ingress_queue()

        try:
            status = self.protocol_insight_service.start(timeout=15)
            ingress = self.protocol_insight_service.ingress_queue
            for controller in self.controllers.values():
                controller.protocol_insight_ingress = ingress
            for _session_id, controller in running:
                controller.start(timeout=15)
        except BaseException as error:
            raise RuntimeError(
                "Protocol Insights could not rebuild its Windows IPC channel"
            ) from error

        return status

    def _protocol_insight_service_request(
        self, command, payload=None, timeout=30.0,
    ):
        self._ensure_protocol_insight_service()
        try:
            result = self.protocol_insight_service.request(
                command, payload, timeout=timeout
            )
        except (BrokenPipeError, ConnectionError, EOFError, OSError) as error:
            # WinError 109/232 means the isolated process or its pipe ended.
            # Recreate it once and restore enabled runtime configurations before
            # retrying the idempotent command instead of leaking an OS error.
            try:
                self._rebuild_protocol_insight_ipc()
                result = self.protocol_insight_service.request(
                    command, payload, timeout=timeout
                )
            except BaseException as retry_error:
                raise RuntimeError(
                    "The isolated Protocol Insights service stopped unexpectedly "
                    "and could not be restarted"
                ) from retry_error
        if command in {"status", "protocol_insight_status"} and isinstance(result, dict):
            self._protocol_insight_service_status = result
        return result

    def _protocol_insight_state(self, view):
        dataset = view.get("dataset", {}) if isinstance(view.get("dataset"), dict) else {}
        if not dataset.get("enabled"):
            return "disabled", ""
        sessions = self._protocol_insight_sessions(view)
        if not dataset.get("runtime", {}).get("active", False):
            return "stopped", "Final checkpoint and Excel output completed; collection and display are stopped"
        if dataset.get("runtime", {}).get("paused", False):
            return "paused", f"{len(sessions)} session(s)"
        runtime_id = str(dataset.get("id", ""))
        service_running = self.protocol_insight_service.running
        runtime_metrics = next((
            item for item in self._protocol_insight_service_status.get("runtimes", [])
            if str(item.get("id", "")) == runtime_id
        ), None)
        running_sessions = [
            session for session in sessions
            if self.controllers.get(session.get("id")) is not None
            and self.controllers[session.get("id")].running
        ]
        if not service_running:
            return "starting", "Starting isolated Protocol Insights service"
        if runtime_metrics is not None and runtime_metrics.get("last_error"):
            return "error", str(runtime_metrics.get("last_error"))
        states = [self._protocol_insight_session_states.get(
            (runtime_id, str(session.get("id", ""))),
            ("starting", "Connecting session publisher to isolated Insight service"),
        ) for session in running_sessions]
        failures = [detail for state, detail in states if state == "error"]
        if failures:
            return "error", f"{len(failures)} session(s) failed; {failures[0]}"
        stale = sum(1 for state, _detail in states if state == "stale")
        if stale:
            return "stale", f"Changes pending for {stale} session(s); select Start to apply"
        ready = sum(1 for state, _detail in states if state == "ready")
        if running_sessions and ready == len(running_sessions):
            return "running", f"{ready} Insight-ready session(s)"
        if running_sessions:
            return "starting", (
                f"Connecting {len(running_sessions) - ready} session publisher(s) "
                f"to the isolated service; {ready} ready"
            )
        return "running", f"Waiting for {len(sessions)} configured session(s) to start"

    def _set_protocol_insight_session_state(
        self, runtime_id, session_id, state, detail="",
    ):
        self._protocol_insight_session_states[(str(runtime_id), str(session_id))] = (
            str(state), str(detail),
        )
        self._update_protocol_insight_runtime_ui(runtime_id)

    def _clear_protocol_insight_session_states(self, session_id):
        session_id = str(session_id)
        for key in [item for item in self._protocol_insight_session_states if item[1] == session_id]:
            self._protocol_insight_session_states.pop(key, None)

    def _mark_protocol_insight_sessions_ready(self, runtime_id, session_ids):
        for session_id in session_ids:
            self._protocol_insight_session_states[(str(runtime_id), str(session_id))] = (
                "ready", "Session publisher connected",
            )
        self._update_protocol_insight_runtime_ui(runtime_id)

    def _mark_protocol_insight_runtime_stale(self, view, detail="Configuration changed"):
        dataset = view.get("dataset", {}) if isinstance(view, dict) else {}
        if (
            not dataset.get("enabled")
            or not dataset.get("runtime", {}).get("active", False)
        ):
            return
        runtime_id = str(dataset.get("id", ""))
        for session in self._protocol_insight_sessions(view):
            session_id = str(session.get("id", ""))
            controller = self.controllers.get(session_id)
            if controller is not None and controller.running:
                self._protocol_insight_session_states[(runtime_id, session_id)] = (
                    "stale", str(detail),
                )
        self._update_protocol_insight_runtime_ui(runtime_id)

    def _update_protocol_insight_runtime_ui(self, runtime_id):
        if not self._ui_attached or not hasattr(self, "insight_panel"):
            return
        view = next((
            item for item in self.config.get("protocol_insights", [])
            if str(item.get("dataset", {}).get("id", "")) == str(runtime_id)
        ), None)
        if view is None or self.insight_panel._view().get("id") != view.get("id"):
            return
        state, detail = self._protocol_insight_state(view)
        self.insight_panel.dataset_editor.set_runtime_state(state, detail)

    @staticmethod
    def _protocol_insight_error_text(error):
        lines = [line.strip() for line in str(error).splitlines() if line.strip()]
        message = lines[-1] if lines else "Protocol Insight runtime registration failed"
        if message.startswith("RuntimeError:"):
            message = message.split(":", 1)[1].strip()
        return message

    def _protocol_insight_registration_failed(self, runtime_id, session_id, error):
        self._set_protocol_insight_session_state(
            runtime_id, session_id, "error", self._protocol_insight_error_text(error),
        )

    def _protocol_insight_session_operation(
        self, runtime_config, sessions, command, payload=None, *, ensure=True,
    ):
        runtime_id = str(runtime_config.get("id", ""))
        try:
            if ensure:
                self._protocol_insight_service_request(
                    "ensure", {"config": runtime_config}
                )
            result = self._protocol_insight_service_request(
                command, {"protocol_insight_id": runtime_id, **(payload or {})}
            )
        except BaseException as error:
            detail = self._protocol_insight_error_text(error)
            return [{
                "session_id": str(session.get("id", "")),
                "session_name": str(session.get("name", "")),
                "ok": False, "error": detail,
            } for session in sessions] or [{
                "session_id": "service", "session_name": "Insight service",
                "ok": False, "error": detail,
            }]
        return [{
            "session_id": str(session.get("id", "")),
            "session_name": str(session.get("name", "")),
            "ok": True, "result": result,
        } for session in sessions] or [{
            "session_id": "service", "session_name": "Insight service",
            "ok": True, "result": result,
        }]

    def _protocol_insight_session_operation_finished(
        self, runtime_id, action_label, results, editor,
    ):
        failures = []
        for result in results:
            if result.get("ok"):
                self._set_protocol_insight_session_state(
                    runtime_id, result["session_id"], "ready", "Insight service ready",
                )
            else:
                detail = str(result.get("error", "Protocol Insight action failed"))
                failures.append(f"{result['session_name']}: {detail}")
                self._set_protocol_insight_session_state(
                    runtime_id, result["session_id"], "error", detail,
                )
        if hasattr(self, "insight_panel"):
            self.insight_panel.refresh()
        if failures:
            QtWidgets.QMessageBox.warning(
                self, f"Protocol Insights — {action_label}",
                f"{action_label} could not complete for {len(failures)} session(s):\n\n"
                + "\n".join(failures),
            )
        elif results:
            view = next((
                item for item in self.config.get("protocol_insights", [])
                if str(item.get("dataset", {}).get("id", "")) == str(runtime_id)
            ), None)
            if view is not None:
                state, detail = self._protocol_insight_state(view)
                editor.set_runtime_state(state, detail)

    def _edit_protocol_insight_filter(self, view, target, finished=None):
        source = view.setdefault("source", default_protocol_insight_source())
        current = source.get("data_filter", {})
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Protocol Insight eligible-message filter")
        dialog.resize(980, 700)
        layout = QtWidgets.QVBoxLayout(dialog)
        explanation = QtWidgets.QLabel(
            "This is the same validated filter designer used by Message Table / Query. "
            "Matching rows become eligible input for every configured series."
        )
        explanation.setWordWrap(True); explanation.setStyleSheet("color: palette(mid);")
        layout.addWidget(explanation)
        editor = MessageFilterDesignerWidget(self, parent=dialog); editor.set_query(current)
        layout.addWidget(editor, 1)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); layout.addWidget(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return False
        try: configured = editor.query()
        except (TypeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Invalid Protocol Insight filter", str(error)); return False
        source["data_filter"] = configured
        self._save()
        if callable(finished): finished()
        return True

    def _handle_protocol_insight_action(self, action, view, editor):
        dataset = view.setdefault("dataset", {})
        sessions = self._protocol_insight_sessions(view)
        if action == "validate":
            try:
                monitor = self._protocol_insight_runtime_config(view)
            except BaseException as error:
                QtWidgets.QMessageBox.warning(self, "Validate Workbook", str(error)); return
            raw_path = str(monitor.get("excel", {}).get("append_path", "")).strip()
            if not raw_path:
                QtWidgets.QMessageBox.information(
                    self, "Validate Workbook",
                    "Enter the existing workbook path in the Append / Workbook row first.",
                )
                return
            path = Path(raw_path)
            if not path.is_absolute(): path = Path(PROJECT_ROOT) / path
            if not path.is_file():
                QtWidgets.QMessageBox.warning(self, "Validate Workbook", f"Workbook does not exist:\n{path}")
                return
            editor.set_runtime_state("ready", "Inspecting append workbook")
            self._run_async(
                lambda: inspect_protocol_insight_workbook(path, monitor),
                lambda result: self._protocol_insights_workbook_validated(result, editor),
                quiet=True,
                failure=lambda error: editor.set_runtime_state("error", str(error).splitlines()[-1]),
            )
            return
        try:
            monitor = self._protocol_insight_runtime_config(view)
        except BaseException as error:
            QtWidgets.QMessageBox.warning(self, "Protocol Insights", str(error))
            editor.set_runtime_state("error", str(error)); return
        offline_checkpoint_export = (
            action == "final_export"
            and not bool(dataset.get("runtime", {}).get("active", False))
        )
        if offline_checkpoint_export:
            try:
                checkpoint_info = self._protocol_insight_service_request(
                    "checkpoint_info", {"config": monitor}, timeout=30
                )
            except BaseException as error:
                QtWidgets.QMessageBox.warning(
                    self, "Checkpoint unavailable",
                    "The selected insight is stopped and its checkpoint could not "
                    f"be read.\n\n{self._protocol_insight_error_text(error)}",
                )
                editor.set_runtime_state("error", "Checkpoint unavailable")
                return
            if not checkpoint_info.get("available"):
                QtWidgets.QMessageBox.information(
                    self, "No checkpoint available",
                    "The selected insight is stopped and has no checkpoint to export. "
                    "Start it to collect data, or enable checkpoints before capture.",
                )
                editor.set_runtime_state("stopped", "No checkpoint available")
                return
            saved_at = (
                checkpoint_info.get("saved_at")
                or checkpoint_info.get("modified_at")
                or checkpoint_info.get("created_at")
                or "unknown"
            )
            modified_at = checkpoint_info.get("modified_at") or "unknown"
            created_at = checkpoint_info.get("created_at") or "unknown"
            answer = QtWidgets.QMessageBox.warning(
                self, "Export older checkpoint?",
                "This insight is not running. The workbook will be recovered from "
                "its last checkpoint and can include data only through that save.\n\n"
                f"Checkpoint saved: {saved_at}\n"
                f"File last modified: {modified_at}\n"
                f"File created: {created_at}\n"
                f"Saved samples: {int(checkpoint_info.get('samples', 0) or 0):,}\n\n"
                "Create the Excel workbook from this checkpoint?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return
        if not sessions and not offline_checkpoint_export:
            QtWidgets.QMessageBox.information(
                self, "Protocol Insights",
                "No session is available for the selected insight scope. Select a session or change Session scope in the source settings.",
            )
            editor.set_runtime_state("error", "No session selected"); return
        try:
            self._ensure_protocol_insight_service()
        except BaseException as error:
            QtWidgets.QMessageBox.warning(self, "Protocol Insights", str(error))
            editor.set_runtime_state("error", str(error)); return
        if (
            monitor.get("excel", {}).get("enabled")
            and
            monitor.get("excel", {}).get("periodic_mode") == "append_formatted"
            and len(sessions) > 1
        ):
            QtWidgets.QMessageBox.warning(
                self, "Protocol Insights",
                "Append formatted workbook supports one session per insight. Select one session, or use Rotating snapshots / Replace latest for multi-session output.",
            )
            editor.set_runtime_state("error", "Append workbook requires one session")
            return
        runtime_id = monitor["id"]
        if action == "start":
            if not monitor.get("series"):
                QtWidgets.QMessageBox.information(self, "Start Protocol Insight", "Define at least one value series first.")
                return
            running_sources = [
                session for session in sessions
                if self.controllers.get(str(session.get("id", ""))) is not None
                and self.controllers[str(session.get("id", ""))].running
            ]
            collection = monitor.get("insights", {}).get("source", {}).get(
                "collection", {}
            )
            if (
                not running_sources
                and collection.get("start_position", "new_messages") == "new_messages"
            ):
                answer = QtWidgets.QMessageBox.question(
                    self,
                    "Start source sessions?",
                    "This insight collects new messages, but none of its source "
                    "communication sessions is running. Start the configured "
                    f"source session(s) now?\n\n{len(sessions)} session(s) are in scope.",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.Yes,
                )
                if answer != QtWidgets.QMessageBox.Yes:
                    editor.set_runtime_state(
                        "configured",
                        "Start at least one source communication session first",
                    )
                    return
                for session in sessions:
                    self._start_session_config(session, quiet=True)
            # Start owns dataset activation. Excel remains an independent sink
            # controlled by its own checkbox in Excel Output.
            editor.dataset_enabled.setChecked(True)
            dataset = view.setdefault("dataset", {})
            editor.set_runtime_state("starting")
            dataset["enabled"] = True
            dataset.setdefault("runtime", {})["active"] = True
            dataset["runtime"]["paused"] = False
            dataset["runtime"]["last_active_on_close"] = True
            editor.set_collection_runtime_state(active=True, paused=False)
            self.insight_panel.start_runtime_frontend(view.get("id"))
            monitor["enabled"] = True
            self._save()
            if self._apply_protocol_insight_to_sessions(monitor, sessions):
                state, detail = self._protocol_insight_state(view)
                editor.set_runtime_state(state, detail)
            return
        if action in {"pause", "resume"}:
            paused = action == "pause"
            dataset.setdefault("runtime", {})["paused"] = paused
            editor.set_collection_runtime_state(active=True, paused=paused)
            self._save()
            for session in sessions:
                self._sync_protocol_insights_for_session(str(session.get("id", "")))
            state, detail = self._protocol_insight_state(view)
            editor.set_runtime_state(state, detail)
            command = "protocol_insight_pause" if paused else "protocol_insight_resume"
            action_label = "Pause Protocol Insight" if paused else "Resume Protocol Insight"
            self._run_async(
                lambda: self._protocol_insight_session_operation(
                    monitor, sessions, command,
                ),
                lambda results: self._protocol_insight_session_operation_finished(
                    runtime_id, action_label, results, editor,
                ),
                quiet=True,
            )
            return
        if action == "stop":
            if QtWidgets.QMessageBox.question(
                self, "Stop Protocol Insights?",
                "Stop this Protocol Insight orderly? The current plots remain static. Enabled final checkpoint and final Excel settings are honored, and the insight reports Stopped only after those writes finish. No collection, display refresh, checkpoint, or Excel write continues afterward.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No,
            ) != QtWidgets.QMessageBox.Yes:
                return
            dataset = view.setdefault("dataset", {})
            dataset.setdefault("runtime", {})["active"] = False
            dataset["runtime"]["paused"] = False
            dataset["runtime"]["last_active_on_close"] = False
            editor.set_collection_runtime_state(active=False)
            self.insight_panel.stop_runtime_frontend(view.get("id"))
            self._save()
            for session in sessions:
                self._sync_protocol_insights_for_session(str(session.get("id", "")))
            editor.set_runtime_state("stopping")
            self._run_async(
                lambda: self._protocol_insight_service_request(
                    "delete", {"protocol_insight_id": runtime_id}
                ),
                lambda _result: (
                    editor.set_runtime_state(
                        "stopped", "Final enabled outputs completed; recurring backend and display work stopped"
                    ),
                    self.insight_panel.complete_runtime_stop(view.get("id")),
                ),
                quiet=True,
                failure=lambda error: editor.set_runtime_state(
                    "error", self._protocol_insight_error_text(error)
                ),
            )
            return
        final_export = action == "final_export"
        command = "protocol_insight_final_export" if final_export else "protocol_insight_export"
        action_label = "Create final Excel" if final_export else "Export now"
        payload = {"config": monitor} if final_export else {"final": False}
        editor.set_runtime_state("starting", f"{action_label} in progress")
        self._run_async(
            lambda: self._protocol_insight_session_operation(
                monitor, sessions, command, payload,
                ensure=not offline_checkpoint_export,
            ),
            lambda results: self._protocol_insight_export_operation_finished(
                runtime_id, action_label, results, editor, final_export,
            ),
            quiet=True,
            failure=(
                self.insight_panel._protocol_insight_export_failed
                if final_export else None
            ),
        )

    def _protocol_insight_export_operation_finished(
        self, runtime_id, action_label, results, editor, final_export,
    ):
        self._protocol_insight_session_operation_finished(
            runtime_id, action_label, results, editor,
        )
        if not final_export:
            return
        failure = next((item for item in results if not item.get("ok")), None)
        if failure:
            self.insight_panel._protocol_insight_export_failed(
                failure.get("error", "Final Excel creation failed")
            )
            return
        exported = next((item.get("result") for item in results if item.get("ok")), None)
        if isinstance(exported, dict):
            self.insight_panel._protocol_insight_exported(exported)

    def _protocol_insights_workbook_validated(self, result, editor):
        compatible = bool(result.get("compatible"))
        details = [f"{result.get('samples', 0):,} existing sample(s)"]
        if result.get("missing_series"):
            details.append("missing series: " + ", ".join(map(str, result["missing_series"])))
        if result.get("additional_series"):
            details.append("additional series: " + ", ".join(map(str, result["additional_series"])))
        message = "; ".join(details)
        editor.set_runtime_state("ready" if compatible else "error", message)
        QtWidgets.QMessageBox.information(
            self, "Append Workbook Validation",
            ("Compatible. " if compatible else "Not compatible. ") + message + ".",
        )

    def _protocol_insight_runtime_config(self, view):
        monitor = default_protocol_insight_runtime_config()
        dataset = view.get("dataset", {}) if isinstance(view.get("dataset"), dict) else {}
        monitor["id"] = str(dataset.get("id") or uuid.uuid4())
        monitor["name"] = f"{view.get('name', 'Protocol Insights')}"
        monitor["enabled"] = bool(
            dataset.get("enabled", False)
            and dataset.get("runtime", {}).get("active", False)
        )
        monitor["threshold_details"] = bool(dataset.get("threshold_details", False))
        for key in ("sampling", "retention", "checkpoint", "excel"):
            if isinstance(dataset.get(key), dict):
                monitor[key].update(copy.deepcopy(dataset[key]))
        monitor["excel"]["layout"] = "wide_aligned"
        monitor["insights"] = {
            "protocol_insight_id": str(view.get("id", "")),
            "x_axis": copy.deepcopy(view.get("x_axis", {})),
            "event_markers": copy.deepcopy(view.get("event_markers", [])),
            "scope": str(view.get("scope", "current")),
            "source": copy.deepcopy(view.get("source", {})),
            "insight_only_subplots": copy.deepcopy([
                subplot for subplot in view.get("subplots", [])
                if subplot.get("kind") == "timeline"
            ]),
        }
        monitor["series"] = []
        monitor["display"]["subplots"] = []
        monitor["display"]["series"] = {}
        used_names = set()
        for subplot in view.get("subplots", []):
            if subplot.get("kind") == "timeline":
                continue
            subplot_id = str(subplot.get("id") or uuid.uuid4())
            monitor["display"]["subplots"].append({
                "id": subplot_id, "title": str(subplot.get("title") or "Subplot"),
                "unit": str(subplot.get("unit") or ""),
            })
            for index, series in enumerate(subplot.get("series", []), 1):
                base = str(series.get("label") or f"Series {index}")
                name = base; suffix = 2
                while name in used_names:
                    name = f"{base} ({suffix})"; suffix += 1
                used_names.add(name)
                source = copy.deepcopy(series.get("source", {}))
                extractor = {"type": source.pop("kind", "parsed_field"), **source}
                transform = series.get("transform", {})
                extractor["scale"] = transform.get("scale", 1.0)
                extractor["offset_value"] = transform.get("offset", 0.0)
                series_query = self._insight_series_query(series)
                raw_thresholds = series.get("thresholds", {})
                monitor_thresholds = {}
                for common, monitor_key in (
                    ("minimum", "min"), ("maximum", "max"),
                    ("equal", "eq"), ("not_equal", "noteq"),
                ):
                    if common in raw_thresholds:
                        monitor_thresholds[monitor_key] = raw_thresholds[common]
                for key in ("min", "max", "eq", "noteq"):
                    if key in raw_thresholds:
                        monitor_thresholds[key] = raw_thresholds[key]
                entry = {
                    "id": str(series.get("id") or uuid.uuid4()),
                    "name": name, "enabled": bool(series.get("enabled", True)),
                    # Every configured value is computed and retained once by the
                    # insight dataset. Excel is only a projection of that dataset.
                    "export_enabled": bool(series.get("export_enabled", True)),
                    "extractor": extractor,
                    "thresholds": monitor_thresholds,
                    "query": series_query,
                    "processor": copy.deepcopy(series.get("processor", {})),
                    "stream_identity": copy.deepcopy(series.get("stream_identity", {})),
                    "collection": copy.deepcopy(series.get("collection", {})),
                }
                monitor["series"].append(entry)
                plot = series.get("plot", {})
                monitor["display"]["series"][name] = {
                    "subplot_id": subplot_id,
                    "subplot": str(subplot.get("title") or "Subplot"),
                    "style": plot.get("type", "line") if series.get("plot_enabled", series.get("visible", True)) else "hidden",
                    "color": plot.get("color", "#0072B2"),
                }
        insight_source = normalize_protocol_insight_source(
            view.get("source"), view.get("scope", "current")
        )
        data_filter = copy.deepcopy(insight_source.get("data_filter", {}))
        collection = insight_source.get("collection", {})
        # The runtime-level query owns only the insight's eligible-message
        # filter. Per-series restrictions are evaluated by each engine series.
        # Folding them into this query discarded messages needed exclusively
        # by event overlays and event-lane subplots.
        monitor["source"]["query"] = data_filter
        monitor["sampling"]["mode"] = "every_event"
        display_config = view.get("display") if isinstance(view.get("display"), dict) else {}
        display_window = display_config.get("window") if isinstance(display_config.get("window"), dict) else view.get("time_window", {})
        monitor["display"]["window_seconds"] = (
            float(display_window.get("amount", 60.0))
            * {"milliseconds": .001, "seconds": 1, "minutes": 60, "hours": 3600}.get(
                display_window.get("unit", "seconds"), 1
            )
            if display_window.get("mode") == "last" else 0
        )
        monitor["display"]["maximum_points"] = int(display_config.get("maximum_points", view.get("maximum_rows", 10_000)))
        monitor["display"]["refresh_ms"] = int(display_config.get("refresh_ms", view.get("refresh_ms", 1000)))
        monitor["display"]["live_refresh"] = bool(display_config.get("live", view.get("live", True)))
        source_scope = insight_source.get("scope", "current")
        monitor["runtime_scope"] = {
            "mode": "all" if source_scope == "all" else "sessions",
            "session_ids": [
                str(session.get("id", ""))
                for session in self._protocol_insight_sessions(view)
                if isinstance(session, dict) and session.get("id")
            ],
        }
        return normalize_protocol_insight_runtime_config(monitor, existing=True)

    def _session_tree_selection_changed(self, current, _previous):
        if self._query_state_ready and not self._global_table_scope() and _previous is not None:
            previous_id = _previous.data(0, QtCore.Qt.UserRole)
            if previous_id: self._save_query_ui_state(str(previous_id))
        self._session_selected(self.sessions.indexOfTopLevelItem(current) if current is not None else -1)

    def _session_selection_changed(self):
        selected = bool(self.sessions.selectedItems())
        self.run_selected_sessions_button.setEnabled(selected)
        self.stop_selected_sessions_button.setEnabled(selected)

    def _session_context_menu(self, position):
        item = self.sessions.itemAt(position)
        if item is None:
            return
        if not item.isSelected():
            self.sessions.clearSelection(); item.setSelected(True)
        self.sessions.setCurrentItem(item)
        config = self._selected_config()
        if config is None:
            return
        controller = self.controllers.get(config["id"])
        running = bool(controller and controller.running)
        operating = config["id"] in self._session_operations
        menu = QtWidgets.QMenu(self.sessions)
        edit_action = menu.addAction("Edit session..."); edit_action.setEnabled(not running and not operating)
        duplicate_action = menu.addAction("Duplicate session")
        protocol_insight_action = menu.addAction("Protocol Insights...")
        menu.addSeparator()
        start_action = menu.addAction("Start session"); start_action.setEnabled(not running and not operating)
        stop_action = menu.addAction("Stop session"); stop_action.setEnabled(running and not operating)
        menu.addSeparator()
        remove_action = menu.addAction("Remove selected...")
        edit_action.triggered.connect(self._edit_session)
        duplicate_action.triggered.connect(self._duplicate_session)
        protocol_insight_action.triggered.connect(self._open_selected_session_protocol_insights)
        start_action.triggered.connect(self._start_session)
        stop_action.triggered.connect(self._stop_session)
        remove_action.triggered.connect(self._remove_session)
        menu.exec_(self.sessions.viewport().mapToGlobal(position))

    def _open_selected_session_protocol_insights(self):
        session = self._selected_config()
        if session is None:
            return
        session_id = str(session.get("id", ""))
        existing = next((
            insight for insight in self.config.get("protocol_insights", [])
            if session_id in insight.get("source", {}).get("session_ids", [])
        ), None)
        if existing is None:
            view = default_protocol_insight_config(f"{session.get('name', 'Session')} Insights")
            view["source"]["scope"] = "selected"
            view["source"]["session_ids"] = [session_id]
            self.config.setdefault("protocol_insights", []).append(view)
            existing = view
        self.config["active_protocol_insight_id"] = existing["id"]
        self._save(); self.insight_panel._normalize_settings(); self.insight_panel._reload_views()
        self._open_protocol_insights()
        self.status_label.setText(
            "Protocol Insights opened for this session. Edit series in the table, then preview or start live collection."
        )

    def _build_monitor_tab(self):
        tab = QtWidgets.QWidget(); self.monitor_tab = tab
        outer = QtWidgets.QVBoxLayout(tab); outer.setContentsMargins(0, 0, 0, 0)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.monitor_scroll = scroll
        content = QtWidgets.QWidget(); layout = QtWidgets.QVBoxLayout(content); scroll.setWidget(content); outer.addWidget(scroll)
        layout.setSpacing(10)
        intro = QtWidgets.QLabel(
            "Send a message in three steps: choose a session, choose the message format, then press Send."
        )
        intro.setWordWrap(True); intro.setStyleSheet("color: palette(mid); padding: 2px 4px;")
        layout.addWidget(intro)

        routing_group = QtWidgets.QGroupBox("Destination")
        routing = QtWidgets.QFormLayout(routing_group)
        routing.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self.send_session_combo = QtWidgets.QComboBox(); self.send_session_combo.setEditable(True)
        self.send_session_combo.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        self.send_session_combo.setMinimumContentsLength(42)
        self.send_session_combo.setToolTip("Select a session, or type its number, label, name, full ID, or unique ID prefix.")
        self.send_session_combo.currentIndexChanged.connect(self._send_session_changed)
        self.send_session_combo.lineEdit().editingFinished.connect(self._resolve_typed_send_session)
        self.send_endpoint_label = QtWidgets.QLabel("No session selected")
        self.send_endpoint_label.setWordWrap(True)
        self.send_endpoint_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.status_label = QtWidgets.QLabel("Stopped")
        self.status_label.setStyleSheet(
            "font-weight: 600; padding: 4px 8px; border-radius: 3px; background: palette(alternate-base);"
        )
        self.send_peer_row = QtWidgets.QWidget()
        peer_layout = QtWidgets.QHBoxLayout(self.send_peer_row); peer_layout.setContentsMargins(0, 0, 0, 0)
        self.send_peer_label = QtWidgets.QLabel("Connected client")
        self.send_target = QtWidgets.QComboBox(); self.send_target.setEditable(True)
        self.send_target.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        self.send_target.setToolTip(
            "For TCP servers, choose one connected client or all clients. Other protocols use their configured endpoint."
        )
        self.refresh_peers_button = QtWidgets.QToolButton(); self.refresh_peers_button.setText("Refresh clients")
        self.refresh_peers_button.setToolTip("Reload the currently connected TCP server clients.")
        self.refresh_peers_button.clicked.connect(self._refresh_send_targets)
        peer_layout.addWidget(self.send_target, 1); peer_layout.addWidget(self.refresh_peers_button)
        routing.addRow("Session to send through", self.send_session_combo)
        routing.addRow("Configured endpoint", self.send_endpoint_label)
        routing.addRow("Session status", self.status_label)
        routing.addRow(self.send_peer_label, self.send_peer_row)
        layout.addWidget(routing_group)

        message_group = QtWidgets.QGroupBox("Message")
        message_group.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        message = QtWidgets.QFormLayout(message_group)
        message.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        saved_row = QtWidgets.QHBoxLayout()
        self.saved_message_combo = QtWidgets.QComboBox()
        self.saved_message_combo.setToolTip("Load a reusable message. Saved messages are available to every session.")
        self.saved_message_combo.currentIndexChanged.connect(self._load_saved_message)
        save_message_button = QtWidgets.QPushButton("Save current..."); save_message_button.clicked.connect(self._save_current_message)
        self.delete_saved_message_button = QtWidgets.QPushButton("Delete"); self.delete_saved_message_button.clicked.connect(self._delete_saved_message)
        save_message_button.setToolTip("Save the current input format and editor content for later reuse, independently of the destination.")
        self.delete_saved_message_button.setToolTip("Delete the selected reusable saved message after confirmation.")
        for compact_button in (save_message_button, self.delete_saved_message_button):
            compact_button.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
            compact_button.setMaximumHeight(28)
            compact_button.setStyleSheet("QPushButton { padding: 2px 8px; }")
        saved_row.addWidget(self.saved_message_combo, 1)
        saved_row.addWidget(save_message_button); saved_row.addWidget(self.delete_saved_message_button)
        message.addRow("Saved message", saved_row)
        self.send_encoding = QtWidgets.QComboBox()
        self.send_encoding.addItem("Text (UTF-8)", "utf-8")
        self.send_encoding.addItem("Text (ASCII)", "ascii")
        self.send_encoding.addItem("Hexadecimal bytes", "hex")
        self.send_encoding.setToolTip("This only converts the editor contents to bytes; it does not add or remove protocol data.")
        message.addRow("Input format", self.send_encoding)
        self.send_payload_label = QtWidgets.QLabel("Message text")
        self.send_data = QtWidgets.QPlainTextEdit(); self.send_data.setMinimumHeight(110)
        self.send_data.setToolTip(
            "Enter exactly the message content to convert and send. Communication Hub does not add framing, headers, checksums, or terminators."
        )
        self.send_data.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.send_data.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        message.addRow(self.send_payload_label, self.send_data)
        preview_widget = QtWidgets.QWidget()
        preview_layout = QtWidgets.QVBoxLayout(preview_widget); preview_layout.setContentsMargins(0, 0, 0, 0)
        preview_top = QtWidgets.QHBoxLayout()
        self.send_preview_summary = QtWidgets.QLabel("0 bytes")
        self.send_preview_summary.setStyleSheet("font-weight: 600;")
        copy_preview = QtWidgets.QToolButton(); copy_preview.setText("Copy full hex")
        copy_preview.setToolTip("Copy the complete outgoing byte sequence as hexadecimal text without spaces.")
        copy_preview.clicked.connect(self._copy_send_preview)
        preview_top.addWidget(self.send_preview_summary); preview_top.addStretch(1); preview_top.addWidget(copy_preview)
        self.send_preview = QtWidgets.QPlainTextEdit(); self.send_preview.setReadOnly(True)
        self.send_preview.setToolTip(
            "Read-only preview of the exact bytes that will be sent. Large messages may be visually truncated, but sending uses all bytes."
        )
        self.send_preview.setMinimumHeight(72)
        self.send_preview.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.send_preview.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.send_preview.setStyleSheet(
            "QPlainTextEdit { background-color: #E9ECEF; color: #495057; "
            "border: 1px solid #C7CCD1; border-radius: 3px; padding: 4px; }"
        )
        self.send_preview.setPlaceholderText("The exact outgoing bytes will appear here in hexadecimal.")
        preview_layout.addLayout(preview_top); preview_layout.addWidget(self.send_preview)
        message.addRow("Final bytes", preview_widget)

        self.send_help = QtWidgets.QLabel(
            "The hub sends exactly these bytes to the endpoint. Include any protocol header, delimiter, checksum, or terminator required by the remote endpoint."
        ); self.send_help.setWordWrap(True)
        self.send_help.setStyleSheet("color: palette(mid);")

        actions = QtWidgets.QHBoxLayout()
        clear_button = QtWidgets.QPushButton("Clear message"); clear_button.clicked.connect(self.send_data.clear)
        self.send_button = QtWidgets.QPushButton("Send message")
        clear_button.setToolTip("Clear only the message editor; the selected session and saved messages are unchanged.")
        self.send_button.setToolTip("Send the complete previewed byte sequence once through the selected session and target.")
        self.send_button.setDefault(True); self.send_button.clicked.connect(self._send)
        self.periodic_send_toggle = QtWidgets.QCheckBox("Periodic sending")
        self.periodic_send_toggle.setToolTip("Show the scheduler used to snapshot this message and send it repeatedly without blocking the editor.")
        for compact_button in (clear_button, self.send_button):
            compact_button.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
            compact_button.setMaximumHeight(28)
            compact_button.setStyleSheet("QPushButton { padding: 2px 8px; }")
        actions.addWidget(self.send_help, 1); actions.addWidget(self.periodic_send_toggle)
        actions.addWidget(clear_button); actions.addWidget(self.send_button)
        message.addRow(actions)
        self._build_periodic_send_panel()
        message.addRow(self.periodic_panel)
        layout.addWidget(message_group, 1)

        activity_group = QtWidgets.QGroupBox("Selected session activity")
        activity = QtWidgets.QVBoxLayout(activity_group)
        cards = QtWidgets.QGridLayout(); cards.setSpacing(8)
        self.activity_values = {}
        for column, (key, title) in enumerate((
            ("rx", "Received"), ("tx", "Sent"), ("rows", "Stored rows"),
            ("parser_errors", "Parser errors"),
            ("protocol_insight_records_published", "Insight records published"),
        )):
            card = QtWidgets.QFrame(); card.setFrameShape(QtWidgets.QFrame.StyledPanel)
            card.setStyleSheet("QFrame { background: palette(alternate-base); border-radius: 4px; }")
            card_layout = QtWidgets.QVBoxLayout(card); card_layout.setContentsMargins(12, 8, 12, 8)
            caption = QtWidgets.QLabel(title); caption.setStyleSheet("color: palette(mid);")
            value = QtWidgets.QLabel("-"); value.setAlignment(QtCore.Qt.AlignRight)
            value.setStyleSheet("font-size: 20px; font-weight: 600;")
            card_layout.addWidget(caption); card_layout.addWidget(value)
            cards.addWidget(card, 0, column); self.activity_values[key] = value
        activity.addLayout(cards)
        self.activity_summary = QtWidgets.QLabel("Start the selected session to see live activity.")
        self.activity_summary.setWordWrap(True); self.activity_summary.setStyleSheet("padding: 3px 2px;")
        activity.addWidget(self.activity_summary)
        self.activity_error = QtWidgets.QLabel(); self.activity_error.setWordWrap(True)
        self.activity_error.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.activity_error.setStyleSheet(
            "QLabel { color: #a12622; background: #fff0ef; border: 1px solid #e7aaa6; border-radius: 3px; padding: 6px; }"
        )
        self.activity_error.hide(); activity.addWidget(self.activity_error)
        self.activity_details_button = QtWidgets.QToolButton()
        self.activity_details_button.setText("Show technical details")
        self.activity_details_button.setToolTip(
            "Show or hide transport state, endpoint information, connection details, counters, and recent errors."
        )
        self.activity_details_button.setCheckable(True); self.activity_details_button.setArrowType(QtCore.Qt.RightArrow)
        self.activity_details_button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.activity_details_button.toggled.connect(self._toggle_activity_details)
        activity.addWidget(self.activity_details_button, 0, QtCore.Qt.AlignLeft)
        self.metrics = QtWidgets.QPlainTextEdit(); self.metrics.setReadOnly(True)
        self.metrics.setToolTip("Read-only technical status for the selected session. Refreshes preserve the current scroll and selection position.")
        self.metrics.setMaximumHeight(150); self.metrics.hide()
        self.metrics.setPlaceholderText("Technical session status will appear here.")
        activity.addWidget(self.metrics); layout.addWidget(activity_group, 0)
        self.send_encoding.currentIndexChanged.connect(self._send_encoding_changed)
        self.send_data.textChanged.connect(self._update_send_preview)
        self._send_encoding_changed()
        self._reload_saved_messages()
        self.periodic_send_toggle.setChecked(bool(self.config.get("periodic_panel_visible", False)))
        self.periodic_panel.setVisible(self.periodic_send_toggle.isChecked())
        self.periodic_send_toggle.toggled.connect(self._toggle_periodic_panel)
        self._reload_periodic_messages(reset_schedule=True)
        self.tabs.addTab(tab, "Live / Send")
        if self.periodic_send_toggle.isChecked():
            QtCore.QTimer.singleShot(0, lambda: self.monitor_scroll.ensureWidgetVisible(self.periodic_panel, 0, 20))

    def _build_periodic_send_panel(self):
        self.periodic_panel = QtWidgets.QGroupBox("Periodic message scheduler")
        layout = QtWidgets.QVBoxLayout(self.periodic_panel)
        note = QtWidgets.QLabel(
            "Adding an entry snapshots the current destination, input format, and exact editor content. The scheduler then runs independently, so the message editor remains available for loading, editing, and sending other messages."
        )
        note.setWordWrap(True); note.setStyleSheet("color: palette(mid);"); layout.addWidget(note)

        setup = QtWidgets.QHBoxLayout()
        self.periodic_name = QtWidgets.QLineEdit(); self.periodic_name.setPlaceholderText("Optional schedule name")
        self.periodic_name.setToolTip("Friendly table name. If left empty, the selected saved-message name or an automatic name is used.")
        self.periodic_interval = QtWidgets.QDoubleSpinBox(); self.periodic_interval.setRange(0.05, 86_400.0)
        self.periodic_interval.setDecimals(3); self.periodic_interval.setValue(1.0); self.periodic_interval.setSuffix(" s")
        self.periodic_interval.setToolTip("Delay between completed dispatch attempts. Missed intervals are skipped rather than sent as a burst.")
        self.periodic_auto_start = QtWidgets.QCheckBox("Start session automatically")
        self.periodic_auto_start.setChecked(True)
        self.periodic_auto_start.setToolTip("Start and wait for the destination session when it is stopped. Disable to record an error instead.")
        self.periodic_start_with_session = QtWidgets.QCheckBox("Start when session starts")
        self.periodic_start_with_session.setChecked(True)
        self.periodic_start_with_session.setToolTip(
            "Resume this schedule whenever its destination session is started. Disable to keep the schedule paused until you resume it explicitly."
        )
        self.add_periodic_message_button = QtWidgets.QPushButton("Send Periodically")
        self.add_periodic_message_button.setToolTip("Snapshot the current editor bytes and current destination, then begin periodic sending after one interval.")
        self.add_periodic_message_button.clicked.connect(self._add_periodic_message)
        setup.addWidget(QtWidgets.QLabel("Name")); setup.addWidget(self.periodic_name, 1)
        setup.addWidget(QtWidgets.QLabel("Period")); setup.addWidget(self.periodic_interval)
        setup.addWidget(self.periodic_auto_start); setup.addWidget(self.periodic_start_with_session)
        setup.addWidget(self.add_periodic_message_button)
        layout.addLayout(setup)

        self.periodic_table = QtWidgets.QTreeWidget()
        self.periodic_table.setToolTip(
            "Saved periodic schedules. Select one or more rows for bulk actions, double-click a row to edit its message, "
            "or use the left icon to pause or resume that schedule."
        )
        self.periodic_table.setHeaderLabels(["", "Name", "Session", "Target", "Bytes", "Period", "State", "Sent", "Last result"])
        self.periodic_table.setRootIsDecorated(False); self.periodic_table.setItemsExpandable(False)
        self.periodic_table.setAlternatingRowColors(True); self.periodic_table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.periodic_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.periodic_table.setMinimumHeight(180); self.periodic_table.setUniformRowHeights(True)
        self.periodic_table.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Fixed); self.periodic_table.header().resizeSection(0, 30)
        self.periodic_table.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.periodic_table.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.periodic_table.header().setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        for column in range(4, 8): self.periodic_table.header().setSectionResizeMode(column, QtWidgets.QHeaderView.ResizeToContents)
        self.periodic_table.header().setSectionResizeMode(8, QtWidgets.QHeaderView.Stretch)
        self.periodic_table.itemSelectionChanged.connect(self._update_periodic_action_buttons)
        self.periodic_table.itemDoubleClicked.connect(lambda _item, _column: self._edit_periodic_message())
        layout.addWidget(self.periodic_table)

        actions = QtWidgets.QHBoxLayout(); actions.addStretch(1)
        self.periodic_send_now_button = QtWidgets.QPushButton("Send Selected Now")
        self.periodic_pause_button = QtWidgets.QPushButton("Pause Selected")
        self.periodic_resume_button = QtWidgets.QPushButton("Resume Selected")
        self.periodic_edit_period_button = QtWidgets.QPushButton("Edit Period…")
        self.periodic_edit_message_button = QtWidgets.QPushButton("Edit Message…")
        self.periodic_remove_button = QtWidgets.QPushButton("Remove Selected…")
        periodic_tooltips = {
            self.periodic_send_now_button: "Immediately dispatch every selected schedule once without changing its next periodic due time.",
            self.periodic_pause_button: "Pause every selected running schedule. Saved definitions and counters are retained.",
            self.periodic_resume_button: "Resume every selected paused schedule and schedule its next send after one full period.",
            self.periodic_edit_period_button: "Assign the same send interval to all selected schedules.",
            self.periodic_edit_message_button: "Edit the name, input format, exact message, and auto-start behavior of one selected schedule.",
            self.periodic_remove_button: "Permanently remove the selected periodic schedules after confirmation.",
        }
        for widget, tooltip in periodic_tooltips.items():
            widget.setToolTip(tooltip)
        self.periodic_send_now_button.clicked.connect(self._send_periodic_selected_now)
        self.periodic_pause_button.clicked.connect(lambda: self._set_selected_periodic_enabled(False))
        self.periodic_resume_button.clicked.connect(lambda: self._set_selected_periodic_enabled(True))
        self.periodic_edit_period_button.clicked.connect(self._edit_periodic_period)
        self.periodic_edit_message_button.clicked.connect(self._edit_periodic_message)
        self.periodic_remove_button.clicked.connect(self._remove_periodic_messages)
        for button in (
            self.periodic_send_now_button, self.periodic_pause_button, self.periodic_resume_button,
            self.periodic_edit_period_button, self.periodic_edit_message_button, self.periodic_remove_button,
        ):
            actions.addWidget(button)
        layout.addLayout(actions)
        self._update_periodic_action_buttons()

    def _toggle_periodic_panel(self, visible):
        self.periodic_panel.setVisible(visible)
        self.config["periodic_panel_visible"] = bool(visible)
        self._save()
        if visible:
            self._reload_periodic_messages()
            QtCore.QTimer.singleShot(0, lambda: self.monitor_scroll.ensureWidgetVisible(self.periodic_panel, 0, 20))

    @staticmethod
    def _periodic_bytes(entry):
        encoding = str(entry.get("encoding", "utf-8"))
        content = str(entry.get("content", ""))
        return bytes.fromhex("".join(content.split())) if encoding == "hex" else content.encode(encoding)

    def _periodic_entry_by_id(self, entry_id):
        return next(
            (entry for entry in self.config.get("periodic_messages", [])
             if isinstance(entry, dict) and entry.get("id") == entry_id),
            None,
        )

    def _periodic_worker_definitions(self, session_id):
        definitions = []
        for entry in self.config.get("periodic_messages", []):
            if (
                not isinstance(entry, dict)
                or str(entry.get("session_id", "")) != str(session_id)
                or not entry.get("id")
            ):
                continue
            try:
                data = self._periodic_bytes(entry)
            except (LookupError, UnicodeEncodeError, ValueError) as error:
                entry["last_error"] = f"Invalid stored message: {error}"[:500]
                continue
            definitions.append({
                "id": str(entry["id"]),
                "name": str(entry.get("name", "Unnamed")),
                "data": data,
                "target": str(entry.get("target", "")),
                "interval_seconds": max(
                    0.05, float(entry.get("interval_seconds", 1.0) or 1.0),
                ),
                "enabled": bool(entry.get("enabled", True)),
                "sent_count": int(entry.get("sent_count", 0) or 0),
                "last_sent_at": str(entry.get("last_sent_at", "")),
            })
        return definitions

    def _sync_periodic_schedule_for_session(self, session_id):
        """Install recurring schedules in the owning session process."""
        controller = self.controllers.get(str(session_id))
        if controller is None or not controller.running:
            return
        definitions = self._periodic_worker_definitions(session_id)
        session_id = str(session_id)
        revision = self._periodic_schedule_revisions.get(session_id, 0) + 1
        self._periodic_schedule_revisions[session_id] = revision
        self._run_async(
            lambda: controller.request(
                "periodic_configure",
                {
                    "entries": definitions,
                    "revision": revision,
                    "maximum_inflight": min(64, max(
                        1, int(self.config.get("periodic_max_inflight", 16) or 16),
                    )),
                },
                timeout=10,
            ),
            lambda statuses, selected_id=session_id:
                self._periodic_worker_status_received(selected_id, statuses),
            quiet=True,
            failure=lambda error, selected_id=session_id:
                self._periodic_worker_status_failed(selected_id, error),
        )

    def _periodic_worker_status_received(self, session_id, statuses):
        session_id = str(session_id)
        self._periodic_status_inflight.discard(session_id)
        self._periodic_status_error_active.discard(session_id)
        if time.monotonic() >= self._periodic_status_error_until.get(session_id, 0.0):
            self._periodic_status_errors.pop(session_id, None)
            self._periodic_status_error_until.pop(session_id, None)
        by_id = {
            str(item.get("id", "")): item
            for item in statuses if isinstance(item, dict)
        }
        session_entry_ids = {
            str(entry.get("id", ""))
            for entry in self.config.get("periodic_messages", [])
            if str(entry.get("session_id", "")) == str(session_id)
        }
        self._periodic_worker_inflight.difference_update(session_entry_ids)
        for entry in self.config.get("periodic_messages", []):
            if str(entry.get("session_id", "")) != str(session_id):
                continue
            status = by_id.get(str(entry.get("id", "")))
            if status is None:
                continue
            previous_count = int(entry.get("sent_count", 0) or 0)
            status_count = int(status.get("sent_count", 0) or 0)
            if status_count >= previous_count:
                entry["sent_count"] = status_count
                entry["last_sent_at"] = str(status.get("last_sent_at", ""))
            entry["last_error"] = str(status.get("last_error", ""))
            if status.get("inflight", False):
                self._periodic_worker_inflight.add(str(entry.get("id", "")))
        self._schedule_periodic_table_refresh()

    def _periodic_worker_status_failed(self, session_id, error):
        session_id = str(session_id)
        self._periodic_status_inflight.discard(session_id)
        lines = [line.strip() for line in str(error).splitlines() if line.strip()]
        self._periodic_status_errors[session_id] = (
            lines[-1] if lines else str(error)
        )[:500]
        self._periodic_status_error_until[session_id] = time.monotonic() + 10.0
        self._periodic_status_error_active.add(session_id)
        self._schedule_periodic_table_refresh()

    def _pause_periodic_messages_for_session(self, session_id):
        paused_ids = set()
        for entry in self.config.get("periodic_messages", []):
            if not isinstance(entry, dict) or entry.get("session_id") != session_id:
                continue
            entry_id = entry.get("id")
            if entry.get("enabled", True):
                entry["enabled"] = False
                entry["paused_by_session_stop"] = True
                if entry_id: paused_ids.add(entry_id)
        if paused_ids:
            self._save()
            self._reload_periodic_messages(selected_ids=paused_ids)
        return paused_ids

    def _resume_periodic_messages_paused_by_session(self, session_id):
        resumed_ids = set()
        for entry in self.config.get("periodic_messages", []):
            if not isinstance(entry, dict) or entry.get("session_id") != session_id:
                continue
            if not entry.get("paused_by_session_stop", False):
                continue
            if not entry.get("start_with_session", True):
                continue
            entry["paused_by_session_stop"] = False
            entry["enabled"] = True
            entry_id = entry.get("id")
            if entry_id:
                resumed_ids.add(entry_id)
        if resumed_ids:
            self._save()
            self._reload_periodic_messages(selected_ids=resumed_ids)
        return resumed_ids

    def _periodic_sends_inflight_for_session(self, session_id):
        return {
            entry_id for entry_id in self._periodic_inflight
            if (entry := self._periodic_entry_by_id(entry_id)) is not None
            and entry.get("session_id") == session_id
        }

    def _selected_periodic_ids(self):
        return [item.data(0, QtCore.Qt.UserRole) for item in self.periodic_table.selectedItems()]

    def _current_periodic_target(self, config):
        if config.get("protocol") != "tcp_server":
            return "", self._session_endpoint_text(config)
        target = self.send_target.currentData()
        if target is None:
            target = self.send_target.currentText().split(" · ", 1)[0].strip()
        target = str(target or "all")
        label = self.send_target.currentText().strip() or ("All connected clients" if target == "all" else target)
        return target, label

    def _add_periodic_message(self):
        config = self._resolve_typed_send_session()
        if config is None:
            return
        try:
            data = self._message_bytes()
        except (LookupError, UnicodeEncodeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Cannot add periodic message", str(error)); return
        import uuid
        saved = self._saved_message_by_id(self.saved_message_combo.currentData())
        automatic_name = str(saved.get("name")) if saved else f"Periodic message {len(self.config.get('periodic_messages', [])) + 1}"
        target, target_label = self._current_periodic_target(config)
        entry = {
            "id": str(uuid.uuid4()),
            "name": self.periodic_name.text().strip() or automatic_name,
            "session_id": config["id"],
            "target": target,
            "target_label": target_label,
            "encoding": self.send_encoding.currentData() or self.send_encoding.currentText(),
            "content": self.send_data.toPlainText(),
            "interval_seconds": float(self.periodic_interval.value()),
            "enabled": True,
            "auto_start": self.periodic_auto_start.isChecked(),
            "start_with_session": self.periodic_start_with_session.isChecked(),
            "sent_count": 0,
            "last_sent_at": "",
            "last_error": "",
            "byte_length": len(data),
        }
        self.config.setdefault("periodic_messages", []).append(entry)
        self._save(); self._reload_periodic_messages(selected_ids={entry["id"]})
        self._sync_periodic_schedule_for_session(config["id"])
        self.periodic_name.clear()

    def _periodic_session_label(self, entry):
        config = self._config_by_id(entry.get("session_id"))
        if config is None:
            return "Missing session"
        index = self.config.get("sessions", []).index(config)
        return f"#{index + 1:02d} {config.get('name', 'Unnamed')}"

    def _update_periodic_row(self, item, entry):
        entry_id = entry["id"]
        interval = max(0.05, float(entry.get("interval_seconds", 1.0) or 1.0))
        enabled = bool(entry.get("enabled", True))
        inflight = (
            entry_id in self._periodic_inflight
            or entry_id in self._periodic_worker_inflight
        )
        try:
            byte_count = len(self._periodic_bytes(entry)); byte_text = f"{byte_count:,}"
        except (LookupError, UnicodeEncodeError, ValueError):
            byte_count = 0; byte_text = "Invalid"
        state = "Sending" if inflight else (
            "Running" if enabled else (
                "Waiting for session" if entry.get("paused_by_session_stop") else "Paused"
            )
        )
        last_error = str(entry.get("last_error", "") or "").strip()
        status_error = self._periodic_status_errors.get(
            str(entry.get("session_id", "")), ""
        )
        if str(entry.get("session_id", "")) in self._periodic_status_error_active and not inflight:
            state = "Status unavailable"
        last_result = status_error or last_error or str(entry.get("last_sent_at", "") or "Never")
        target_label = str(entry.get("target_label", "") or "Configured endpoint")
        values = [
            "", str(entry.get("name", "Unnamed")), self._periodic_session_label(entry),
            target_label, byte_text, f"{interval:g} s", state,
            f"{int(entry.get('sent_count', 0) or 0):,}", last_result,
        ]
        for column, value in enumerate(values):
            if item.text(column) != value:
                item.setText(column, value)
        item.setData(0, QtCore.Qt.UserRole, entry_id)
        item.setTextAlignment(4, QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        item.setTextAlignment(5, QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        item.setTextAlignment(7, QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        item.setForeground(
            8,
            QtGui.QBrush(QtGui.QColor("#A12622")) if (status_error or last_error) else QtGui.QBrush(),
        )
        preview = ""
        try:
            preview = self._periodic_bytes(entry)[:128].hex(" ").upper()
        except (LookupError, UnicodeEncodeError, ValueError):
            pass
        tooltip = (
            f"{entry.get('name', 'Unnamed')}\nSession: {self._periodic_session_label(entry)}\n"
            f"Target: {target_label}\nPeriod: {interval:g} seconds\n"
            f"Starts stopped session: {'yes' if entry.get('auto_start', True) else 'no'}\n"
            f"Starts with session: {'yes' if entry.get('start_with_session', True) else 'no'}\n"
            f"Format: {entry.get('encoding', 'utf-8')}\n"
            f"Exact bytes ({byte_count}): {preview}{'…' if byte_count > 128 else ''}"
        )
        if status_error:
            tooltip += f"\nScheduler status error: {status_error}"
        if last_error:
            tooltip += f"\nLast send error: {last_error}"
        for column in range(self.periodic_table.columnCount()):
            item.setToolTip(column, tooltip)

        cell = self.periodic_table.itemWidget(item, 0)
        control = cell.findChild(QtWidgets.QToolButton) if cell is not None else None
        if control is None:
            control = QtWidgets.QToolButton(self.periodic_table)
            control.setIconSize(QtCore.QSize(14, 14))
            control.setFixedSize(25, 25)
            control.setProperty("periodic_id", entry_id)
            control.clicked.connect(
                lambda _checked=False, selected_id=entry_id:
                self._toggle_periodic_entry(selected_id)
            )
            cell = QtWidgets.QWidget(self.periodic_table)
            cell_layout = QtWidgets.QHBoxLayout(cell)
            cell_layout.setContentsMargins(0, 0, 5, 0)
            cell_layout.addWidget(control, 0, QtCore.Qt.AlignVCenter)
            self.periodic_table.setItemWidget(item, 0, cell)
        icon_type = QtWidgets.QStyle.SP_MediaPause if enabled else QtWidgets.QStyle.SP_MediaPlay
        control.setIcon(self.style().standardIcon(icon_type))
        control.setEnabled(not inflight)
        control.setToolTip("Pause this periodic message" if enabled else "Resume this periodic message")
        return item

    def _reload_periodic_messages(self, selected_ids=None, reset_schedule=False):
        if not hasattr(self, "periodic_table"):
            return
        vertical = self.periodic_table.verticalScrollBar()
        horizontal = self.periodic_table.horizontalScrollBar()
        vertical_position, horizontal_position = vertical.value(), horizontal.value()
        vertical_at_end = vertical.maximum() > 0 and vertical_position >= vertical.maximum()
        horizontal_at_end = horizontal.maximum() > 0 and horizontal_position >= horizontal.maximum()
        if selected_ids is None:
            selected_ids = set(self._selected_periodic_ids())
        else:
            selected_ids = set(selected_ids)
        current_id = self.periodic_table.currentItem().data(0, QtCore.Qt.UserRole) if self.periodic_table.currentItem() else None
        entries = [entry for entry in self.config.get("periodic_messages", []) if isinstance(entry, dict) and entry.get("id")]
        desired_ids = [entry["id"] for entry in entries]
        existing_ids = [
            self.periodic_table.topLevelItem(index).data(0, QtCore.Qt.UserRole)
            for index in range(self.periodic_table.topLevelItemCount())
        ]
        structure_changed = existing_ids != desired_ids
        self.periodic_table.blockSignals(True)
        if structure_changed:
            self.periodic_table.clear()
            for _entry in entries:
                self.periodic_table.addTopLevelItem(QtWidgets.QTreeWidgetItem())
        current_item = None; first_selected_item = None
        for index, entry in enumerate(entries):
            entry_id = entry["id"]
            item = self._update_periodic_row(
                self.periodic_table.topLevelItem(index), entry,
            )
            if entry_id in selected_ids:
                item.setSelected(True)
                if first_selected_item is None: first_selected_item = item
            else:
                item.setSelected(False)
            if entry_id == current_id: current_item = item
        target_item = current_item or first_selected_item
        if target_item is not None:
            self.periodic_table.setCurrentItem(target_item)
            for index in range(self.periodic_table.topLevelItemCount()):
                item = self.periodic_table.topLevelItem(index)
                item.setSelected(item.data(0, QtCore.Qt.UserRole) in selected_ids)
        self.periodic_table.blockSignals(False)
        self.periodic_table.doItemsLayout()
        vertical.setValue(vertical.maximum() if vertical_at_end else min(vertical_position, vertical.maximum()))
        horizontal.setValue(horizontal.maximum() if horizontal_at_end else min(horizontal_position, horizontal.maximum()))
        self._update_periodic_action_buttons()

    def _update_periodic_action_buttons(self):
        if not hasattr(self, "periodic_send_now_button"):
            return
        entries = [self._periodic_entry_by_id(entry_id) for entry_id in self._selected_periodic_ids()]
        entries = [entry for entry in entries if entry is not None]
        any_selected = bool(entries)
        self.periodic_send_now_button.setEnabled(any_selected)
        self.periodic_pause_button.setEnabled(any(bool(entry.get("enabled", True)) for entry in entries))
        self.periodic_resume_button.setEnabled(any(not bool(entry.get("enabled", True)) for entry in entries))
        self.periodic_edit_period_button.setEnabled(any_selected)
        self.periodic_edit_message_button.setEnabled(len(entries) == 1)
        self.periodic_remove_button.setEnabled(any_selected)

    def _toggle_periodic_entry(self, entry_id):
        entry = self._periodic_entry_by_id(entry_id)
        if entry is None: return
        entry["enabled"] = not bool(entry.get("enabled", True))
        entry["paused_by_session_stop"] = False
        self._save(); self._reload_periodic_messages(selected_ids={entry_id})
        self._sync_periodic_schedule_for_session(entry.get("session_id"))

    def _set_selected_periodic_enabled(self, enabled):
        selected_ids = set(self._selected_periodic_ids())
        session_ids = set()
        for entry_id in selected_ids:
            entry = self._periodic_entry_by_id(entry_id)
            if entry is None: continue
            session_ids.add(str(entry.get("session_id", "")))
            entry["enabled"] = bool(enabled)
            entry["paused_by_session_stop"] = False
        if selected_ids: self._save(); self._reload_periodic_messages(selected_ids=selected_ids)
        for session_id in session_ids:
            self._sync_periodic_schedule_for_session(session_id)

    def _edit_periodic_period(self):
        selected_ids = set(self._selected_periodic_ids())
        entries = [self._periodic_entry_by_id(entry_id) for entry_id in selected_ids]
        entries = [entry for entry in entries if entry is not None]
        if not entries: return
        initial = float(entries[0].get("interval_seconds", 1.0) or 1.0)
        value, accepted = QtWidgets.QInputDialog.getDouble(
            self, "Edit periodic interval", "Send every", initial, 0.05, 86_400.0, 3,
        )
        if not accepted: return
        session_ids = set()
        for entry in entries:
            entry["interval_seconds"] = float(value)
            session_ids.add(str(entry.get("session_id", "")))
        self._save(); self._reload_periodic_messages(selected_ids=selected_ids)
        for session_id in session_ids:
            self._sync_periodic_schedule_for_session(session_id)

    def _edit_periodic_message(self):
        selected_ids = self._selected_periodic_ids()
        if len(selected_ids) != 1: return
        entry = self._periodic_entry_by_id(selected_ids[0])
        if entry is None: return
        dialog = QtWidgets.QDialog(self); dialog.setWindowTitle("Edit periodic message"); dialog.resize(650, 430)
        form = QtWidgets.QFormLayout(dialog)
        name = QtWidgets.QLineEdit(str(entry.get("name", "")))
        encoding = QtWidgets.QComboBox()
        for title, value in (("Text (UTF-8)", "utf-8"), ("Text (ASCII)", "ascii"), ("Hexadecimal bytes", "hex")):
            encoding.addItem(title, value)
        encoding.setCurrentIndex(max(0, encoding.findData(entry.get("encoding", "utf-8"))))
        content = QtWidgets.QPlainTextEdit(str(entry.get("content", "")))
        content.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        summary = QtWidgets.QLabel()
        auto_start = QtWidgets.QCheckBox("Start the destination session automatically when needed")
        auto_start.setChecked(bool(entry.get("auto_start", True)))
        start_with_session = QtWidgets.QCheckBox("Start this schedule when the destination session starts")
        start_with_session.setChecked(bool(entry.get("start_with_session", True)))
        form.addRow("Schedule name", name); form.addRow("Input format", encoding); form.addRow("Message", content)
        form.addRow("Final bytes", summary); form.addRow("", auto_start)
        form.addRow("", start_with_session)

        def update_summary():
            try:
                value = content.toPlainText(); selected_encoding = encoding.currentData()
                data = bytes.fromhex("".join(value.split())) if selected_encoding == "hex" else value.encode(selected_encoding)
                summary.setText(f"{len(data):,} bytes · {data[:64].hex(' ').upper()}{'…' if len(data) > 64 else ''}")
                summary.setStyleSheet("")
            except (LookupError, UnicodeEncodeError, ValueError) as error:
                summary.setText(f"Invalid input: {error}"); summary.setStyleSheet("color: #A12622;")

        content.textChanged.connect(update_summary); encoding.currentIndexChanged.connect(update_summary); update_summary()
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); form.addRow(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return
        try:
            value = content.toPlainText(); selected_encoding = encoding.currentData()
            data = bytes.fromhex("".join(value.split())) if selected_encoding == "hex" else value.encode(selected_encoding)
        except (LookupError, UnicodeEncodeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Invalid periodic message", str(error)); return
        entry.update({
            "name": name.text().strip() or str(entry.get("name", "Unnamed")),
            "encoding": selected_encoding, "content": value, "byte_length": len(data),
            "auto_start": auto_start.isChecked(), "last_error": "",
            "start_with_session": start_with_session.isChecked(),
        })
        self._save(); self._reload_periodic_messages(selected_ids={entry["id"]})
        self._sync_periodic_schedule_for_session(entry.get("session_id"))

    def _remove_periodic_messages(self):
        selected_ids = set(self._selected_periodic_ids())
        if not selected_ids: return
        entries = [self._periodic_entry_by_id(entry_id) for entry_id in selected_ids]
        entries = [entry for entry in entries if entry is not None]
        names = "\n".join(f"- {entry.get('name', 'Unnamed')}" for entry in entries[:12])
        if len(entries) > 12: names += f"\n- …and {len(entries) - 12} more"
        if QtWidgets.QMessageBox.question(
            self, "Remove periodic messages?",
            "Remove these schedules? A send already in progress cannot be cancelled.\n\n" + names,
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        ) != QtWidgets.QMessageBox.Yes:
            return
        session_ids = {str(entry.get("session_id", "")) for entry in entries}
        self.config["periodic_messages"] = [
            entry for entry in self.config.get("periodic_messages", []) if entry.get("id") not in selected_ids
        ]
        self._periodic_worker_inflight.difference_update(selected_ids)
        self._save(); self._reload_periodic_messages()
        for session_id in session_ids:
            self._sync_periodic_schedule_for_session(session_id)

    def _send_periodic_selected_now(self):
        for entry_id in self._selected_periodic_ids():
            entry = self._periodic_entry_by_id(entry_id)
            if entry is not None: self._dispatch_periodic_message(entry)

    def _send_encoding_changed(self):
        encoding = self.send_encoding.currentData() or self.send_encoding.currentText()
        if encoding == "hex":
            self.send_payload_label.setText("Hexadecimal bytes")
            self.send_data.setPlaceholderText("Example: 01 03 FF 0A")
        else:
            self.send_payload_label.setText("Message text")
            self.send_data.setPlaceholderText(f"Text encoded as {str(encoding).upper()}")
        self._update_send_preview()

    def _message_bytes(self):
        encoding = self.send_encoding.currentData() or self.send_encoding.currentText()
        value = self.send_data.toPlainText()
        if encoding == "hex":
            return bytes.fromhex("".join(value.split()))
        return value.encode(str(encoding))

    def _update_send_preview(self):
        try:
            data = self._message_bytes()
        except (LookupError, UnicodeEncodeError, ValueError) as error:
            self._send_preview_bytes = None
            self.send_preview_summary.setText(f"Invalid input: {error}")
            self.send_preview_summary.setStyleSheet("font-weight: 600; color: #a12622;")
            self.send_preview.setPlainText("")
            return
        self._send_preview_bytes = data
        self.send_preview_summary.setStyleSheet("font-weight: 600;")
        limit = 4096
        shown = data[:limit]
        suffix = f" - showing first {limit:,}" if len(data) > limit else " - complete preview"
        self.send_preview_summary.setText(f"{len(data):,} bytes{suffix}")
        self.send_preview.setPlainText(shown.hex(" ").upper() if shown else "(empty message)")

    def _copy_send_preview(self):
        if self._send_preview_bytes is not None:
            QtWidgets.QApplication.clipboard().setText(self._send_preview_bytes.hex().upper())

    def _saved_message_label(self, entry):
        encoding = str(entry.get("encoding", "utf-8"))
        content = str(entry.get("content", ""))
        try:
            data = bytes.fromhex("".join(content.split())) if encoding == "hex" else content.encode(encoding)
            size = f"{len(data):,} bytes"
        except (LookupError, UnicodeEncodeError, ValueError):
            size = "invalid input"
        return f"{entry.get('name', 'Unnamed')}  ·  {size}  ·  {encoding.upper()}"

    def _reload_saved_messages(self, selected_id=None):
        if selected_id is None:
            selected_id = self.saved_message_combo.currentData()
        self.saved_message_combo.blockSignals(True); self.saved_message_combo.clear()
        self.saved_message_combo.addItem("Select a saved message...", None)
        for entry in self.config.get("saved_messages", []):
            if isinstance(entry, dict) and entry.get("id"):
                self.saved_message_combo.addItem(self._saved_message_label(entry), entry["id"])
        index = self.saved_message_combo.findData(selected_id)
        self.saved_message_combo.setCurrentIndex(index if index >= 0 else 0)
        self.saved_message_combo.blockSignals(False)
        self.delete_saved_message_button.setEnabled(self.saved_message_combo.currentData() is not None)

    def _saved_message_by_id(self, message_id):
        return next(
            (entry for entry in self.config.get("saved_messages", [])
             if isinstance(entry, dict) and entry.get("id") == message_id),
            None,
        )

    def _load_saved_message(self, _index):
        entry = self._saved_message_by_id(self.saved_message_combo.currentData())
        self.delete_saved_message_button.setEnabled(entry is not None)
        if entry is None:
            return
        encoding_index = self.send_encoding.findData(entry.get("encoding", "utf-8"))
        self.send_encoding.setCurrentIndex(encoding_index if encoding_index >= 0 else 0)
        self.send_data.setPlainText(str(entry.get("content", "")))

    def _save_current_message(self):
        try:
            self._message_bytes()
        except (LookupError, UnicodeEncodeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Cannot save message", str(error)); return
        current = self._saved_message_by_id(self.saved_message_combo.currentData())
        default_name = str(current.get("name")) if current else f"Message {len(self.config.get('saved_messages', [])) + 1}"
        name, accepted = QtWidgets.QInputDialog.getText(self, "Save message", "Message name", text=default_name)
        name = name.strip()
        if not accepted or not name:
            return
        messages = self.config.setdefault("saved_messages", [])
        same_name = next((entry for entry in messages if str(entry.get("name", "")).casefold() == name.casefold()), None)
        if current is not None and same_name is not None and same_name is not current:
            QtWidgets.QMessageBox.warning(self, "Message name already used", f"A saved message named '{name}' already exists.")
            return
        target = current or same_name
        if target is not None and QtWidgets.QMessageBox.question(
            self, "Replace saved message?", f"Replace the saved message '{target.get('name', name)}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.Yes,
        ) != QtWidgets.QMessageBox.Yes:
            return
        if target is None:
            import uuid
            target = {"id": str(uuid.uuid4())}; messages.append(target)
        target.update({
            "name": name,
            "encoding": self.send_encoding.currentData() or self.send_encoding.currentText(),
            "content": self.send_data.toPlainText(),
        })
        self._save(); self._reload_saved_messages(target["id"])

    def _delete_saved_message(self):
        entry = self._saved_message_by_id(self.saved_message_combo.currentData())
        if entry is None:
            return
        if QtWidgets.QMessageBox.question(
            self, "Delete saved message?", f"Delete '{entry.get('name', 'this message')}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        ) != QtWidgets.QMessageBox.Yes:
            return
        self.config["saved_messages"].remove(entry)
        self._save(); self._reload_saved_messages()

    def _toggle_activity_details(self, visible):
        self.metrics.setVisible(visible)
        self.activity_details_button.setArrowType(QtCore.Qt.DownArrow if visible else QtCore.Qt.RightArrow)
        self.activity_details_button.setText("Hide technical details" if visible else "Show technical details")

    @staticmethod
    def _format_byte_count(value):
        size = float(value or 0)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if abs(size) < 1024.0 or unit == "TB":
                return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
            size /= 1024.0

    def _reset_activity(self, message="Start the selected session to see live activity."):
        for value in self.activity_values.values(): value.setText("-")
        self.activity_summary.setText(message)
        self.activity_error.clear(); self.activity_error.hide()
        self.metrics.clear()

    def _set_metrics_text_preserving_view(self, text):
        vertical = self.metrics.verticalScrollBar()
        horizontal = self.metrics.horizontalScrollBar()
        vertical_position, horizontal_position = vertical.value(), horizontal.value()
        old_cursor = self.metrics.textCursor()
        cursor_position, cursor_anchor = old_cursor.position(), old_cursor.anchor()
        self.metrics.setPlainText(text)
        new_cursor = self.metrics.textCursor()
        document_length = max(0, self.metrics.document().characterCount() - 1)
        new_cursor.setPosition(min(cursor_anchor, document_length))
        new_cursor.setPosition(min(cursor_position, document_length), QtGui.QTextCursor.KeepAnchor)
        self.metrics.setTextCursor(new_cursor)
        vertical.setValue(min(vertical_position, vertical.maximum()))
        horizontal.setValue(min(horizontal_position, horizontal.maximum()))

    def _build_table_tab(self):
        tab = QtWidgets.QWidget(); self.table_tab = tab; layout = QtWidgets.QVBoxLayout(tab); layout.setSpacing(8)
        intro = QtWidgets.QLabel(
            "Filter the selected session's message table in three ways: choose a common filter, build conditions visually, or edit Advanced JSON for nested AND/OR/NOT logic."
        )
        intro.setWordWrap(True); intro.setStyleSheet("color: palette(mid); padding: 2px 4px;"); layout.addWidget(intro)
        self.table_session_indicator = QtWidgets.QLabel("No session table selected")
        self.table_session_indicator.setWordWrap(True)
        self.table_session_indicator.setStyleSheet(
            "font-weight: 600; color: #174EA6; background: #E8F0FE; border: 1px solid #A9C1EA; "
            "border-radius: 3px; padding: 5px 8px;"
        )
        self.table_session_indicator.setToolTip(
            "This identifies the session whose message and per-name summary tables are currently displayed."
        )
        indicator_row = QtWidgets.QHBoxLayout(); indicator_row.setSpacing(6)
        indicator_row.addWidget(self.table_session_indicator, 1)
        indicator_row.addWidget(QtWidgets.QLabel("Table behavior"))
        self.message_table_scope_combo = QtWidgets.QComboBox()
        self.message_table_scope_combo.addItem("Per session", "per_session")
        self.message_table_scope_combo.addItem("Global · combine sessions", "global")
        self._normalize_message_table_scope(self.config)
        self.message_table_scope_combo.setCurrentIndex(
            max(0, self.message_table_scope_combo.findData(self.config["message_table_scope"]))
        )
        self.message_table_scope_combo.setToolTip(
            "Per session shows and remembers each selected session independently. Global combines the latest "
            "running or retained tables from every session and keeps a separate global query state."
        )
        self.message_table_scope_combo.currentIndexChanged.connect(self._message_table_scope_changed)
        indicator_row.addWidget(self.message_table_scope_combo)
        layout.addLayout(indicator_row)
        self.table_session_indicator_timer = QtCore.QTimer(self)
        self.table_session_indicator_timer.setInterval(180)
        self.table_session_indicator_timer.timeout.connect(self._advance_table_session_indicator_flash)

        designer_header = QtWidgets.QHBoxLayout()
        self.query_designer_toggle = QtWidgets.QToolButton()
        self.query_designer_toggle.setText("Hide filter designer")
        self.query_designer_toggle.setCheckable(True); self.query_designer_toggle.setChecked(True)
        self.query_designer_toggle.setArrowType(QtCore.Qt.DownArrow)
        self.query_designer_toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.query_designer_toggle.setToolTip(
            "Show or hide the filter designer. When hidden, the message summary uses the full workspace width."
        )
        self.query_designer_toggle.toggled.connect(self._toggle_query_designer)
        self.name_summary_toggle = QtWidgets.QToolButton()
        self.name_summary_toggle.setText("Hide message summary")
        self.name_summary_toggle.setCheckable(True); self.name_summary_toggle.setChecked(True)
        self.name_summary_toggle.setArrowType(QtCore.Qt.DownArrow)
        self.name_summary_toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.name_summary_toggle.setToolTip("Show or hide the per-name message totals and latest timestamps.")
        self.name_summary_toggle.toggled.connect(self._toggle_name_summary)
        designer_header.addWidget(self.query_designer_toggle)
        designer_header.addWidget(self.name_summary_toggle)
        designer_header.addStretch(1); layout.addLayout(designer_header)
        self.query_designer_panel = QtWidgets.QWidget()
        self.query_designer_panel.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        designer_layout = QtWidgets.QVBoxLayout(self.query_designer_panel)
        designer_layout.setContentsMargins(0, 0, 0, 0); designer_layout.setSpacing(5)

        saved_group = QtWidgets.QGroupBox("Saved query / filter")
        self.saved_query_group = saved_group
        saved_group.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        saved_layout = QtWidgets.QHBoxLayout(saved_group)
        saved_layout.setContentsMargins(7, 3, 7, 4); saved_layout.setSpacing(5)
        self.saved_query_combo = QtWidgets.QComboBox()
        self.saved_query_combo.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        self.saved_query_combo.setMaximumHeight(24)
        self.saved_query_combo.setToolTip("Load a reusable query. Saved queries are available for every Communication Hub session.")
        self.saved_query_combo.currentIndexChanged.connect(self._load_saved_query)
        self.saved_query_notice = QtWidgets.QLabel()
        self.saved_query_notice.setStyleSheet("color: #1B7F3A; font-weight: 600; padding: 0 3px;")
        self.saved_query_notice.hide()
        self.saved_query_notice_timer = QtCore.QTimer(self); self.saved_query_notice_timer.setSingleShot(True)
        self.saved_query_notice_timer.timeout.connect(self.saved_query_notice.hide)
        self.save_query_button = QtWidgets.QPushButton("Save Current…")
        self.delete_saved_query_button = QtWidgets.QPushButton("Delete Saved…")
        self.save_query_button.setToolTip("Save the currently active guided or Advanced JSON query for later reuse.")
        self.delete_saved_query_button.setToolTip("Delete a selected saved query definition. Message rows are not deleted.")
        self.save_query_button.clicked.connect(self._save_current_query)
        self.delete_saved_query_button.clicked.connect(self._delete_saved_query)
        for button in (self.save_query_button, self.delete_saved_query_button):
            button.setMaximumHeight(24); button.setStyleSheet("QPushButton { padding: 1px 7px; }")
        saved_layout.addWidget(self.saved_query_combo, 1); saved_layout.addWidget(self.saved_query_notice)
        saved_layout.addWidget(self.save_query_button)
        saved_layout.addWidget(self.delete_saved_query_button)
        designer_layout.addWidget(saved_group)

        common_group = QtWidgets.QGroupBox("Common filters")
        self.common_filters_group = common_group
        common_group.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        common_layout = QtWidgets.QGridLayout(common_group); common_layout.setSpacing(5)
        common_columns = 6
        self.common_filter_mode_combo = QtWidgets.QComboBox()
        self.common_filter_mode_combo.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        self.common_filter_mode_combo.addItem("Replace filters", "replace")
        self.common_filter_mode_combo.addItem("Append to current list", "append")
        self._normalize_common_filter_mode(self.config)
        mode_index = self.common_filter_mode_combo.findData(self.config["common_filter_mode"])
        self.common_filter_mode_combo.setCurrentIndex(max(0, mode_index))
        self.common_filter_mode_combo.setToolTip(
            "Choose how common-filter buttons affect the current query. Replace discards existing conditions. "
            "Append adds the new condition while preserving the current guided AND/OR mode."
        )
        self.common_filter_mode_combo.currentIndexChanged.connect(self._common_filter_mode_changed)
        common_layout.addWidget(self.common_filter_mode_combo, 0, 0)
        for index, (title, tooltip, query) in enumerate(self._common_query_definitions()):
            button = QtWidgets.QPushButton(title); button.setToolTip(tooltip)
            button.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
            button.setFixedHeight(28); button.setStyleSheet("QPushButton { padding: 3px 8px; }")
            button.clicked.connect(lambda _checked=False, value=query: self._apply_common_query(value))
            position = index + 1
            common_layout.addWidget(button, position // common_columns, position % common_columns)
        name_index = len(self._common_query_definitions()) + 1
        self.common_name_filter_button = _DoubleClickButton("Name: Unknown")
        self.common_name_filter_button.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        self.common_name_filter_button.setFixedHeight(28)
        self.common_name_filter_button.setStyleSheet("QPushButton { padding: 3px 8px; }")
        self.common_name_filter_button.activated.connect(self._apply_common_name_filter)
        self.common_name_filter_button.doubleClicked.connect(self._configure_common_name_filter)
        common_layout.addWidget(self.common_name_filter_button, name_index // common_columns, name_index % common_columns)
        self._update_common_name_filter_button()

        relative_index = name_index + 1
        self.last_period_filter_button = _DoubleClickButton("Last… period")
        self.last_period_filter_button.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        self.last_period_filter_button.setFixedHeight(28)
        self.last_period_filter_button.setStyleSheet("QPushButton { padding: 3px 8px; }")
        self.last_period_filter_button.activated.connect(self._apply_last_period_filter)
        self.last_period_filter_button.doubleClicked.connect(self._configure_last_period_filter)
        common_layout.addWidget(self.last_period_filter_button, relative_index // common_columns, relative_index % common_columns)
        self._update_last_period_filter_tooltip()

        for offset, kind in enumerate(("before", "after"), 1):
            button = _DoubleClickButton(f"{kind.title()} datetime")
            button.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
            button.setFixedHeight(28); button.setStyleSheet("QPushButton { padding: 3px 8px; }")
            button.activated.connect(lambda selected_kind=kind: self._apply_common_datetime_filter(selected_kind))
            button.doubleClicked.connect(lambda selected_kind=kind: self._configure_common_datetime_filter(selected_kind))
            common_layout.addWidget(button, (relative_index + offset) // common_columns, (relative_index + offset) % common_columns)
            setattr(self, f"{kind}_datetime_filter_button", button)
            self._update_common_datetime_filter_button(kind)
        common_layout.setContentsMargins(7, 3, 7, 3)
        for column in range(common_columns): common_layout.setColumnStretch(column, 1)
        designer_layout.addWidget(common_group)

        self.query_tabs = QtWidgets.QTabWidget()
        self.query_tabs.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        self.query_tabs.setFixedHeight(320)
        designer_layout.addWidget(self.query_tabs, 1)
        guided = QtWidgets.QWidget(); self.query_guided_tab = guided; guided_layout = QtWidgets.QVBoxLayout(guided)
        guided_top = QtWidgets.QHBoxLayout()
        self.query_match_mode = QtWidgets.QComboBox()
        self.query_match_mode.addItem("Match all conditions (AND)", "and")
        self.query_match_mode.addItem("Match any condition (OR)", "or")
        self.query_exclude = QtWidgets.QCheckBox("Exclude matching rows (NOT)")
        self.query_match_mode.setToolTip("AND requires every guided condition to match; OR requires at least one condition to match.")
        self.query_exclude.setToolTip("Invert the complete guided condition group so matching rows are excluded.")
        self.query_match_mode.currentIndexChanged.connect(self._visual_query_changed)
        self.query_exclude.toggled.connect(self._visual_query_changed)
        guided_top.addWidget(self.query_match_mode); guided_top.addWidget(self.query_exclude); guided_top.addStretch(1)
        guided_layout.addLayout(guided_top)
        self.query_conditions = QtWidgets.QTreeWidget(); self.query_conditions.setHeaderLabels(["Field", "Comparison", "Value", "Options"])
        self.query_conditions.setToolTip(
            "Guided query conditions in evaluation order. Double-click a row to edit it and Ctrl/Shift-select rows for bulk removal."
        )
        self.query_conditions.setRootIsDecorated(False); self.query_conditions.setAlternatingRowColors(True)
        self.query_conditions.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.query_conditions.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.query_conditions.setMinimumHeight(115)
        self.query_conditions.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.query_conditions.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.query_conditions.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.query_conditions.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.query_conditions.header().setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        self.query_conditions.itemDoubleClicked.connect(lambda _item, _column: self._edit_visual_query_condition())
        guided_layout.addWidget(self.query_conditions, 1)
        builder_actions = QtWidgets.QHBoxLayout(); builder_actions.addStretch(1)
        for text, slot, tooltip in (
            ("Add Condition…", self._add_visual_query_condition, "Add a field comparison to the guided filter."),
            ("Edit Selected…", self._edit_visual_query_condition, "Edit the currently selected guided condition."),
            ("Duplicate", self._duplicate_visual_query_condition, "Copy the selected condition so it can be adjusted independently."),
            ("Remove Selected", self._remove_visual_query_conditions, "Remove all selected conditions from the designer."),
            ("Clear Conditions", self._clear_query, "Clear the complete active query and return to showing all messages."),
        ):
            button = QtWidgets.QPushButton(text); button.clicked.connect(slot)
            button.setToolTip(tooltip)
            button.setMaximumHeight(24); button.setStyleSheet("QPushButton { padding: 1px 6px; }")
            builder_actions.addWidget(button)
        guided_layout.addLayout(builder_actions)
        self.query_tabs.addTab(guided, "Guided Filter Builder")

        advanced = QtWidgets.QWidget(); self.query_advanced_tab = advanced; advanced_layout = QtWidgets.QVBoxLayout(advanced)
        advanced_header = QtWidgets.QHBoxLayout()
        advanced_note = QtWidgets.QLabel(
            "Advanced JSON supports nested condition groups with operator: and/or and optional not: true. JSON edited here is used when this tab is selected. Guided changes regenerate this JSON preview."
        )
        advanced_note.setWordWrap(True); advanced_note.setStyleSheet("color: palette(mid);")
        self.advanced_query_guide_button = QtWidgets.QPushButton("Advanced Query Guide…")
        self.advanced_query_guide_button.setMaximumHeight(24)
        self.advanced_query_guide_button.setToolTip("Open the complete Advanced JSON query language reference and examples.")
        self.advanced_query_guide_button.clicked.connect(self._show_advanced_query_guide)
        advanced_header.addWidget(advanced_note, 1); advanced_header.addWidget(self.advanced_query_guide_button, 0, QtCore.Qt.AlignTop)
        advanced_layout.addLayout(advanced_header)
        self.query_edit = QtWidgets.QPlainTextEdit("{}")
        self.query_edit.setToolTip(
            "Edit the complete query object directly. This supports nested AND/OR groups and NOT logic unavailable in the flat guided builder."
        )
        self.query_edit.setMinimumHeight(125)
        self.query_edit.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.query_edit.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.query_edit.textChanged.connect(self._validate_advanced_query)
        advanced_layout.addWidget(self.query_edit, 1)
        self.query_json_status = QtWidgets.QLabel("Valid query JSON")
        self.query_json_status.setStyleSheet("color: #1B7F3A;"); advanced_layout.addWidget(self.query_json_status)
        self.query_tabs.addTab(advanced, "Advanced JSON")
        self.query_tabs.currentChanged.connect(self._query_mode_changed)

        # The complete legacy-compatible designer is now a reusable widget.
        # Keep query_designer_panel as an alias so persisted visibility/splitter
        # behavior and external integrations continue to work unchanged.
        self.filter_designer_widget = MessageFilterDesignerWidget(
            self, self.query_designer_panel, self,
        )
        self.query_designer_panel = self.filter_designer_widget

        self.name_summary_panel = QtWidgets.QGroupBox("Messages by name")
        self.name_summary_panel.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        summary_layout = QtWidgets.QVBoxLayout(self.name_summary_panel)
        summary_layout.setContentsMargins(6, 6, 6, 6); summary_layout.setSpacing(4)
        self.name_summary_label = QtWidgets.QLabel("No recorded message names")
        self.name_summary_label.setStyleSheet("color: palette(mid); padding: 0 2px;")
        self.name_summary_table = QtWidgets.QTableWidget(0, 3)
        self.name_summary_table.setToolTip(
            "Message totals and latest timestamps by name for the same session/global scope as the message table."
        )
        self.name_summary_table.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.name_summary_table.setHorizontalHeaderLabels(["Name", "Messages", "Last timestamp (local)"])
        self.name_summary_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.name_summary_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.name_summary_table.setAlternatingRowColors(True)
        self.name_summary_table.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollPerPixel)
        self.name_summary_table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.name_summary_table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.name_summary_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        summary_layout.addWidget(self.name_summary_label); summary_layout.addWidget(self.name_summary_table, 1)

        self.query_workspace_splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        self.query_workspace_splitter.setChildrenCollapsible(True)
        self.query_workspace_splitter.addWidget(self.query_designer_panel)
        self.query_workspace_splitter.addWidget(self.name_summary_panel)
        self.query_workspace_splitter.setStretchFactor(0, 2); self.query_workspace_splitter.setStretchFactor(1, 1)
        self.query_workspace_splitter.setSizes([720, 360])
        layout.addWidget(self.query_workspace_splitter, 0)

        controls = QtWidgets.QHBoxLayout(); layout.addLayout(controls)
        self.apply_filter_button = QtWidgets.QPushButton("Apply Filter")
        self.apply_filter_button.setToolTip("Apply the active guided or Advanced JSON query and return to the first result page.")
        self.apply_filter_button.clicked.connect(lambda: self._refresh_table(reset=True, report_unavailable=True))
        self.show_all_button = QtWidgets.QPushButton("Show All")
        self.show_all_button.setToolTip("Clear the active query and show every currently retained message row.")
        self.show_all_button.clicked.connect(lambda: self._clear_query(report_unavailable=True))
        self.export_excel_button = QtWidgets.QPushButton("Export Excel\u2026")
        self.export_excel_button.setToolTip(
            "Export every row matching the current filter to a formatted Excel workbook. "
            "The export follows the current per-session or global table scope, not only the visible page."
        )
        self.export_excel_button.clicked.connect(self._export_message_table_excel)
        self.delete_matching_button = QtWidgets.QPushButton("Delete Matching\u2026")
        self.delete_matching_button.setToolTip("Delete every row matching the active query after showing a confirmation count.")
        self.delete_matching_button.clicked.connect(self._delete_matching)
        self.delete_all_button = QtWidgets.QPushButton("Delete All\u2026")
        self.delete_all_button.setToolTip("Delete every row in the selected session's in-memory message table after confirmation.")
        self.delete_all_button.clicked.connect(self._delete_all)
        previous = QtWidgets.QPushButton("Previous"); previous.clicked.connect(self._previous_page)
        following = QtWidgets.QPushButton("Next"); following.clicked.connect(self._next_page)
        previous.setToolTip("Show the previous page of the current filtered result.")
        following.setToolTip("Show the next page of the current filtered result.")
        self.page_size_combo = QtWidgets.QComboBox()
        for size in (100, 200, 500, 1000): self.page_size_combo.addItem(f"{size} rows/page", size)
        self.page_size_combo.setCurrentIndex(max(0, self.page_size_combo.findData(self.page_size)))
        self.page_size_combo.currentIndexChanged.connect(self._page_size_changed)
        self.page_size_combo.setToolTip("Maximum message rows rendered on each UI page. This does not limit stored or exported rows.")
        self.page_label = QtWidgets.QLabel("0 rows")
        self.query_summary = QtWidgets.QLabel("Showing all messages")
        self.query_summary.setStyleSheet("font-weight: 600;")
        self.auto_refresh = QtWidgets.QCheckBox("Auto refresh"); self.auto_refresh.setChecked(True)
        self.auto_refresh.setToolTip("Refresh the visible message page and name summary automatically while this tab is active.")
        for button in (self.apply_filter_button, self.show_all_button, self.export_excel_button, self.delete_matching_button, self.delete_all_button, previous, following):
            button.setMaximumHeight(25); button.setStyleSheet("QPushButton { padding: 1px 7px; }")
        for widget in (self.apply_filter_button, self.show_all_button, self.export_excel_button, self.delete_matching_button, self.delete_all_button): controls.addWidget(widget)
        controls.addSpacing(8)
        for widget in (previous, following, self.page_size_combo): controls.addWidget(widget)
        controls.addSpacing(8)
        for widget in (self.auto_refresh, self.page_label): controls.addWidget(widget)
        controls.addStretch(1); controls.addWidget(self.query_summary)
        self.table = QtWidgets.QTableWidget(); self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows); self.table.setAlternatingRowColors(True)
        self.table.setToolTip("Double-click a row to inspect all message fields and nested parser data.")
        self.table.cellDoubleClicked.connect(self._open_message_detail)
        self._displayed_message_rows = []
        layout.addWidget(self.table)
        self._reload_saved_queries()
        self._visual_query_changed()
        self.tabs.addTab(tab, "Message Table / Query")

    def _selected_config(self):
        current = self.sessions.currentItem()
        row = self.sessions.indexOfTopLevelItem(current) if current is not None else -1
        return self.config["sessions"][row] if 0 <= row < len(self.config["sessions"]) else None

    def _selected_controller(self):
        config = self._selected_config()
        return self.controllers.get(config["id"]) if config else None

    @staticmethod
    def _protocol_title(protocol):
        return str(protocol).replace("_", " ").upper()

    def _session_display_text(self, index, config):
        label = str(config.get("protocol_label", "")).strip()
        suffix = f" / {label}" if label else ""
        return f"#{index + 1:02d}  {self._protocol_title(config['protocol'])}{suffix}  ·  {config['name']}  ·  ID {config['id']}"

    def _session_endpoint_text(self, config):
        transport, protocol = config.get("transport", {}), config.get("protocol")
        if protocol == "tcp_server":
            return f"TCP server clients on {transport.get('bind_host', '0.0.0.0')}:{transport.get('bind_port', '')}"
        if protocol == "tcp_client":
            return f"TCP remote {transport.get('host', '')}:{transport.get('port', '')}"
        if protocol == "telnet":
            return f"Telnet remote {transport.get('host', '')}:{transport.get('port', '')}"
        if protocol == "serial":
            return f"Serial {transport.get('serial_port', '')} @ {transport.get('baudrate', '')} baud"
        return self._protocol_title(protocol)

    def _update_session_row(self, item, index, config):
        controller = self.controllers.get(config["id"])
        operation = self._session_operations.get(config["id"])
        state = operation or ("running" if controller and controller.running else "stopped")
        running = bool(controller and controller.running)
        values = [
            "", f"{index + 1:02d}", str(config["name"]),
            {
                "tcp_client": "TCP Client", "tcp_server": "TCP Server",
                "serial": "Serial", "telnet": "Telnet",
            }.get(config["protocol"], self._protocol_title(config["protocol"])),
            state.title(),
        ]
        for column, value in enumerate(values):
            if item.text(column) != value:
                item.setText(column, value)
        item.setData(0, QtCore.Qt.UserRole, config["id"])
        item.setTextAlignment(1, QtCore.Qt.AlignCenter)
        item.setTextAlignment(4, QtCore.Qt.AlignCenter)
        state_color = "#1B7F3A" if state == "running" else ("#174EA6" if operation else "#6B7280")
        item.setForeground(4, QtGui.QBrush(QtGui.QColor(state_color)))
        tooltip = (
            self._session_display_text(index, config) + "\n"
            + self._session_endpoint_text(config)
            + (
                "\nLifecycle: continues while the main application is open"
                if self._session_runs_in_background(config)
                else "\nLifecycle: stops when Communication Hub is closed"
            )
            + (
                "\nRestart: restores the previous running state"
                if config.get("lifecycle", {}).get("restore_last_state", True)
                else "\nRestart: does not restore the previous running state"
            )
        )
        for column in range(5):
            item.setToolTip(column, tooltip)

        control_cell = self.sessions.itemWidget(item, 0)
        control = control_cell.findChild(QtWidgets.QToolButton) if control_cell is not None else None
        if control is None:
            control = QtWidgets.QToolButton(self.sessions)
            control.setStyleSheet("QToolButton { padding: 0; margin: 0; }")
            control.setFixedSize(25, 25)
            control.setCursor(QtCore.Qt.PointingHandCursor)
            control.setProperty("session_id", config["id"])
            control.clicked.connect(
                lambda _checked=False, session_id=config["id"]:
                self._toggle_session_by_id(session_id)
            )
            control_cell = QtWidgets.QWidget(self.sessions)
            control_layout = QtWidgets.QHBoxLayout(control_cell)
            control_layout.setContentsMargins(0, 0, 5, 0); control_layout.setSpacing(0)
            control_layout.addWidget(control, 0, QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
            self.sessions.setItemWidget(item, 0, control_cell)
        control.setText("…" if operation else "")
        control.setIcon(QtGui.QIcon())
        if not operation:
            icon_type = QtWidgets.QStyle.SP_MediaPause if running else QtWidgets.QStyle.SP_MediaPlay
            control.setIcon(self.style().standardIcon(icon_type))
            control.setIconSize(QtCore.QSize(14, 14))
        control.setToolTip(
            f"{state.title()} '{config['name']}'" if operation
            else (f"Stop '{config['name']}'" if running else f"Start '{config['name']}'")
        )
        control.setAccessibleName(
            f"Session {state}" if operation else ("Stop session" if running else "Start session")
        )
        control.setProperty("running", running)
        control.setEnabled(not operation)
        return item

    def _reload_sessions(self):
        current = self.sessions.currentItem() if hasattr(self, "sessions") else None
        selected = self.sessions.indexOfTopLevelItem(current) if current is not None else -1
        current_id = current.data(0, QtCore.Qt.UserRole) if current is not None else None
        selected_ids = {
            item.data(0, QtCore.Qt.UserRole) for item in self.sessions.selectedItems()
        } if hasattr(self, "sessions") else set()
        send_session_id = self.send_session_combo.currentData() if hasattr(self, "send_session_combo") else None
        configs = self.config.get("sessions", [])
        desired_ids = [config["id"] for config in configs]
        existing_ids = [
            self.sessions.topLevelItem(index).data(0, QtCore.Qt.UserRole)
            for index in range(self.sessions.topLevelItemCount())
        ]
        structure_changed = existing_ids != desired_ids
        self.sessions.blockSignals(True)
        if structure_changed:
            self.sessions.clear()
            for _config in configs:
                self.sessions.addTopLevelItem(QtWidgets.QTreeWidgetItem())
        for index, config in enumerate(configs):
            self._update_session_row(self.sessions.topLevelItem(index), index, config)

        combo_ids = [
            self.send_session_combo.itemData(index)
            for index in range(self.send_session_combo.count())
        ]
        self.send_session_combo.blockSignals(True)
        if combo_ids != desired_ids:
            self.send_session_combo.clear()
            for index, config in enumerate(configs):
                self.send_session_combo.addItem(self._session_display_text(index, config), config["id"])
        else:
            for index, config in enumerate(configs):
                self.send_session_combo.setItemText(index, self._session_display_text(index, config))
        for index, config in enumerate(configs):
            self.send_session_combo.setItemData(index, self._session_endpoint_text(config), QtCore.Qt.ToolTipRole)
        send_index = self.send_session_combo.findData(send_session_id)
        if send_index < 0 and self.send_session_combo.count(): send_index = max(0, min(selected, self.send_session_combo.count() - 1))
        self.send_session_combo.setCurrentIndex(send_index); self.send_session_combo.blockSignals(False)
        if self.sessions.topLevelItemCount():
            row = next(
                (index for index in range(self.sessions.topLevelItemCount())
                 if self.sessions.topLevelItem(index).data(0, QtCore.Qt.UserRole) == current_id),
                max(0, min(selected, self.sessions.topLevelItemCount() - 1)),
            )
            self.sessions.setCurrentItem(self.sessions.topLevelItem(row))
            for index in range(self.sessions.topLevelItemCount()):
                item = self.sessions.topLevelItem(index)
                if item.data(0, QtCore.Qt.UserRole) in selected_ids:
                    item.setSelected(True)
        self.sessions.blockSignals(False)
        self.run_selected_sessions_button.setEnabled(bool(self.sessions.selectedItems()))
        self.stop_selected_sessions_button.setEnabled(bool(self.sessions.selectedItems()))
        self.select_all_sessions_button.setEnabled(self.sessions.topLevelItemCount() > 0)
        self._update_send_routing()
        if hasattr(self, "periodic_table"): self._reload_periodic_messages()

    def _config_by_id(self, session_id):
        return next((config for config in self.config.get("sessions", []) if config.get("id") == session_id), None)

    @staticmethod
    def _session_runs_in_background(config):
        return config.get("lifecycle", {}).get("scope", "window") == "application"

    @staticmethod
    def _protocol_insight_runs_in_background(config):
        return config.get("lifecycle", {}).get("scope", "window") == "application"

    def _controller_for_config(self, config):
        """Return a controller whose immutable worker configuration matches the saved session."""
        session_id = config["id"]
        controller = self.controllers.get(session_id)
        normalized = normalize_session_config(config)
        if controller is None or (
            not controller.running and getattr(controller, "config", normalized) != normalized
        ):
            retained_state_getter = getattr(controller, "retained_table_state", None) if controller is not None else None
            retained_state = retained_state_getter() if callable(retained_state_getter) else None
            self._ensure_protocol_insight_service()
            controller = SessionController(
                normalized, PROJECT_ROOT, retained_state,
                self.protocol_insight_service.ingress_queue,
                self.config["protocol_insight_service"]["publisher_capacity_per_session"],
            )
            self.controllers[session_id] = controller
        return controller

    def _session_from_reference(self, reference):
        text = str(reference or "").strip()
        if not text:
            return None, None
        simplified = text.casefold()
        number = simplified[1:] if simplified.startswith("#") else simplified
        if number.isdigit():
            index = int(number) - 1
            if 0 <= index < len(self.config.get("sessions", [])):
                return index, self.config["sessions"][index]
        exact = []
        for index, config in enumerate(self.config.get("sessions", [])):
            candidates = {
                str(config.get("id", "")).casefold(), str(config.get("name", "")).casefold(),
                str(config.get("protocol_label", "")).casefold(), str(config.get("protocol", "")).casefold(),
                self._session_display_text(index, config).casefold(),
            }
            if simplified in candidates:
                exact.append((index, config))
        if len(exact) == 1:
            return exact[0]
        prefix = [(index, config) for index, config in enumerate(self.config.get("sessions", []))
                  if str(config.get("id", "")).casefold().startswith(simplified)]
        if len(prefix) == 1:
            return prefix[0]
        return None, None

    def _resolve_typed_send_session(self, show_error=True):
        current_index = self.send_session_combo.currentIndex()
        if current_index >= 0 and self.send_session_combo.currentText() == self.send_session_combo.itemText(current_index):
            config = self._config_by_id(self.send_session_combo.currentData())
            return config
        index, config = self._session_from_reference(self.send_session_combo.currentText())
        if config is None:
            if show_error and self.send_session_combo.currentText().strip():
                QtWidgets.QMessageBox.warning(
                    self, "Session not found",
                    "Enter a unique session number (#1), session name, protocol label, full session ID, or unique ID prefix."
                )
            return None
        self.send_session_combo.blockSignals(True); self.send_session_combo.setCurrentIndex(index); self.send_session_combo.blockSignals(False)
        self.sessions.setCurrentItem(self.sessions.topLevelItem(index)); self._update_send_routing()
        return config

    def _send_session_changed(self, index):
        if index < 0:
            return
        session_id = self.send_session_combo.itemData(index)
        for row in range(self.sessions.topLevelItemCount()):
            item = self.sessions.topLevelItem(row)
            if item.data(0, QtCore.Qt.UserRole) == session_id:
                if self.sessions.currentItem() is not item: self.sessions.setCurrentItem(item)
                break
        self._update_send_routing()

    def _update_send_routing(self):
        config = self._config_by_id(self.send_session_combo.currentData()) if self.send_session_combo.currentIndex() >= 0 else None
        if config is None:
            self.send_endpoint_label.setText("No session selected")
            self.send_target.clear(); self.send_target.setEnabled(False)
            self.send_peer_label.setVisible(False); self.send_peer_row.setVisible(False)
            self.send_button.setEnabled(False)
            self._activity_session_id = None
            self._reset_activity("Select a session to see its activity.")
            return
        index = self.config.get("sessions", []).index(config)
        self.send_endpoint_label.setText(self._session_endpoint_text(config))
        self.send_button.setEnabled(True)
        self.send_target.blockSignals(True); self.send_target.clear()
        if config["protocol"] == "tcp_server":
            self.send_peer_label.setText("TCP server peer")
            self.send_peer_label.setVisible(True); self.send_peer_row.setVisible(True)
            self.send_target.setEnabled(True); self.send_target.setEditable(True)
            self.send_target.addItem("All connected clients", "all")
            self.send_target.lineEdit().setPlaceholderText("All clients or a client ID")
        else:
            self.send_peer_label.setText("Protocol endpoint")
            self.send_peer_label.setVisible(False); self.send_peer_row.setVisible(False)
            self.send_target.setEditable(False); self.send_target.setEnabled(False)
            self.send_target.addItem(self._session_endpoint_text(config), "")
        self.send_target.blockSignals(False)
        controller = self.controllers.get(config["id"])
        state = "running" if controller and controller.running else "stopped"
        self.status_label.setText(f"#{index + 1:02d} {config['name']} · {state}")
        if getattr(self, "_activity_session_id", None) != config["id"]:
            self._activity_session_id = config["id"]
            self._reset_activity("Refreshing live activity..." if state == "running" else "Start this session to see live activity.")
        elif state == "stopped":
            self._reset_activity("Start this session to see live activity.")
        if config["protocol"] == "tcp_server" and controller and controller.running:
            self._refresh_send_targets()

    def _refresh_send_targets(self):
        config = self._resolve_typed_send_session(show_error=False)
        if not config or config.get("protocol") != "tcp_server":
            return
        controller = self.controllers.get(config["id"])
        if not controller or not controller.running:
            return
        session_id = config["id"]
        self._run_async(
            lambda: controller.request("clients", timeout=5),
            lambda clients: self._show_send_targets(session_id, clients),
            quiet=True,
        )

    def _show_send_targets(self, session_id, clients):
        if self.send_session_combo.currentData() != session_id:
            return
        current = self.send_target.currentData() or self.send_target.currentText()
        self.send_target.blockSignals(True); self.send_target.clear(); self.send_target.addItem("All connected clients", "all")
        for client in clients:
            connection_id, peer = client.get("connection_id", ""), client.get("peer", "")
            self.send_target.addItem(f"{connection_id} · {peer}", connection_id)
        target_index = self.send_target.findData(current)
        self.send_target.setCurrentIndex(target_index if target_index >= 0 else 0)
        self.send_target.blockSignals(False)

    def _add_session(self):
        dialog = SessionConfigDialog(parent=self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            self.config["sessions"].append(dialog.result_config); self._save(); self._reload_sessions()
            self.sessions.setCurrentItem(self.sessions.topLevelItem(self.sessions.topLevelItemCount() - 1))

    def _edit_session(self):
        config = self._selected_config()
        if not config: return
        controller = self.controllers.get(config["id"])
        if config["id"] in self._session_operations or (controller and controller.running):
            QtWidgets.QMessageBox.information(self, "Session running", "Stop the session before editing its configuration."); return
        dialog = SessionConfigDialog(config, self)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            row = self.sessions.indexOfTopLevelItem(self.sessions.currentItem())
            self.controllers.pop(config["id"], None)
            self.config["sessions"][row] = dialog.result_config; self._save(); self._reload_sessions()

    def _duplicate_session(self):
        import uuid
        config = self._selected_config()
        if not config: return
        value = copy.deepcopy(config); value["id"] = str(uuid.uuid4()); value["name"] += " Copy"; value["autostart"] = False
        self.config["sessions"].append(value); self._save(); self._reload_sessions()

    def _remove_session(self):
        rows = sorted({self.sessions.indexOfTopLevelItem(item) for item in self.sessions.selectedItems()})
        current = self.sessions.currentItem()
        current_row = self.sessions.indexOfTopLevelItem(current) if current is not None else -1
        if not rows and current_row >= 0:
            rows = [current_row]
        if not rows:
            return
        configs = [self.config["sessions"][row] for row in rows]
        busy = [
            config["name"] for config in configs
            if config["id"] in self._session_operations
            or (config["id"] in self.controllers and self.controllers[config["id"]].running)
        ]
        if busy:
            QtWidgets.QMessageBox.warning(
                self, "Sessions busy",
                "Stop these sessions, or wait for their current operation to finish, before removing them:\n\n"
                + "\n".join(busy),
            )
            return
        names = "\n".join(f"- {config['name']}" for config in configs[:12])
        if len(configs) > 12:
            names += f"\n- ...and {len(configs) - 12} more"
        removed_ids = {config["id"] for config in configs}
        affected_periodic = [
            entry for entry in self.config.get("periodic_messages", [])
            if entry.get("session_id") in removed_ids
        ]
        periodic_warning = (
            f"\n\n{len(affected_periodic)} periodic schedule(s) use these sessions and will be paused."
            if affected_periodic else ""
        )
        title = "Remove session?" if len(configs) == 1 else f"Remove {len(configs)} sessions?"
        if QtWidgets.QMessageBox.question(
            self, title, f"This removes the following configuration entries:\n\n{names}{periodic_warning}",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        ) != QtWidgets.QMessageBox.Yes:
            return
        for row in reversed(rows):
            config = self.config["sessions"].pop(row)
            self.controllers.pop(config["id"], None)
            self.config.setdefault("query_ui_state_by_session", {}).pop(config["id"], None)
        for entry in affected_periodic:
            entry["enabled"] = False
            entry["last_error"] = "Destination session was removed"
        self._save(); self._reload_sessions()

    def _select_all_sessions(self):
        self.sessions.selectAll()
        if self.sessions.topLevelItemCount() and self.sessions.currentItem() is None:
            self.sessions.setCurrentItem(self.sessions.topLevelItem(0))

    def _run_selected_sessions(self):
        selected_ids = {
            item.data(0, QtCore.Qt.UserRole) for item in self.sessions.selectedItems()
        }
        for config in self.config.get("sessions", []):
            if config.get("id") not in selected_ids:
                continue
            controller = self.controllers.get(config["id"])
            if config["id"] not in self._session_operations and not (controller and controller.running):
                self._start_session_config(config)

    def _stop_selected_sessions(self):
        selected_ids = {
            item.data(0, QtCore.Qt.UserRole) for item in self.sessions.selectedItems()
        }
        for config in self.config.get("sessions", []):
            if config.get("id") not in selected_ids or config["id"] in self._session_operations:
                continue
            controller = self.controllers.get(config["id"])
            if controller and controller.running:
                self._stop_session_config(config, controller)

    def _toggle_session_by_id(self, session_id):
        if session_id in self._session_operations:
            return
        config = self._config_by_id(session_id)
        if config is None:
            return
        controller = self.controllers.get(session_id)
        if controller and controller.running:
            self._stop_session_config(config, controller)
        else:
            self._start_session_config(config)

    def _show_session_operation(self, session_id, operation):
        self._session_operations[session_id] = operation
        if self._ui_attached:
            self._reload_sessions()
        selected = self._selected_config()
        if self._ui_attached and selected and selected.get("id") == session_id:
            self.status_label.setText(f"{operation.title()}…")

    def _finish_session_operation(self, session_id):
        self._session_operations.pop(session_id, None)
        if self._ui_attached:
            self._reload_sessions()

    def _display_session_status(self, session_id, result):
        if not self._ui_attached or self.tabs.currentWidget() is not self.monitor_tab:
            return
        selected = self._selected_config()
        if selected and selected.get("id") == session_id:
            self._display_status(result)

    def _session_started(self, session_id, result):
        self._clear_protocol_insight_session_states(session_id)
        self._periodic_status_errors.pop(str(session_id), None)
        self._periodic_status_error_until.pop(str(session_id), None)
        self._periodic_status_error_active.discard(str(session_id))
        self._resume_periodic_messages_paused_by_session(session_id)
        self._sync_periodic_schedule_for_session(session_id)
        self._sync_protocol_insights_for_session(session_id)
        config = self._config_by_id(session_id)
        if config is not None:
            config.setdefault("lifecycle", {})["last_running_on_close"] = True
            self._save()
        if self._ui_attached:
            self._display_session_status(session_id, result)
            self._flash_table_session_indicator(session_id)

    def _sync_protocol_insights_for_session(self, session_id):
        session = self._config_by_id(session_id)
        controller = self.controllers.get(session_id)
        if session is None or controller is None or not controller.running:
            return
        applicable = []
        for configuration in self.config.get("protocol_insights", []):
            dataset = configuration.get("dataset", {}) if isinstance(configuration.get("dataset"), dict) else {}
            if (
                not dataset.get("enabled")
                or not dataset.get("runtime", {}).get("active", False)
                or dataset.get("runtime", {}).get("paused", False)
            ):
                continue
            if session not in self._protocol_insight_sessions(configuration):
                continue
            applicable.append(configuration)
            try:
                runtime = self._protocol_insight_runtime_config(configuration)
            except BaseException as error:
                runtime_id = str(dataset.get("id", ""))
                self._protocol_insight_registration_failed(runtime_id, session_id, error)
                continue
            runtime_id = str(runtime.get("id", ""))
            self._set_protocol_insight_session_state(
                runtime_id, session_id, "starting",
                "Connecting session publisher to isolated Insight service",
            )

        def publisher_updated(_result):
            for configuration in applicable:
                runtime_id = str(configuration.get("dataset", {}).get("id", ""))
                self._set_protocol_insight_session_state(
                    runtime_id, session_id, "ready",
                    "Session publisher connected",
                )

        def publisher_failed(error):
            for configuration in applicable:
                runtime_id = str(configuration.get("dataset", {}).get("id", ""))
                self._protocol_insight_registration_failed(
                    runtime_id, session_id, error,
                )

        self._run_async(
            lambda: controller.request(
                "protocol_insight_publisher", {"enabled": bool(applicable)}
            ),
            publisher_updated,
            quiet=True,
            failure=publisher_failed,
        )

    def _start_session_config(self, config, quiet=False):
        session_id = config["id"]
        self._clear_protocol_insight_session_states(session_id)
        controller = self._controller_for_config(config)
        if controller.running or session_id in self._session_operations:
            return
        self._show_session_operation(session_id, "starting")
        call = self._run_async(
            controller.start,
            lambda result, selected_id=session_id: self._session_started(selected_id, result),
            quiet=quiet,
        )
        call.finished.connect(lambda selected_id=session_id: self._finish_session_operation(selected_id))

    def _stop_session_config(self, config, controller=None):
        session_id = config["id"]
        controller = controller or self.controllers.get(session_id)
        if controller is None or not controller.running or session_id in self._session_operations:
            return
        self._show_session_operation(session_id, "stopping")
        config.setdefault("lifecycle", {})["last_running_on_close"] = False
        self._pause_periodic_messages_for_session(session_id)
        self._finish_stop_after_periodic_sends(session_id, controller)

    def _finish_stop_after_periodic_sends(self, session_id, controller):
        if self._session_operations.get(session_id) != "stopping":
            return
        if self._periodic_sends_inflight_for_session(session_id):
            QtCore.QTimer.singleShot(
                50,
                lambda selected_id=session_id, selected_controller=controller:
                    self._finish_stop_after_periodic_sends(selected_id, selected_controller),
            )
            return
        call = self._run_async(controller.stop)
        call.finished.connect(lambda selected_id=session_id: (
            self._clear_protocol_insight_session_states(selected_id),
            self._finish_session_operation(selected_id),
        ))

    def _start_session(self):
        config = self._selected_config()
        if config: self._start_session_config(config)

    def _stop_session(self):
        config = self._selected_config()
        if config: self._stop_session_config(config)

    @staticmethod
    def _send_bytes_operation(controller, config, data, encoding, target, auto_start):
        should_start = not controller.running
        if should_start and not auto_start:
            raise RuntimeError(f"Session '{config['name']}' is stopped and automatic startup is disabled")
        if should_start:
            controller.start()
            expected_state = "listening" if config["protocol"] == "tcp_server" else "connected"
            transport = config.get("transport", {})
            deadline = time.monotonic() + max(10.0, float(transport.get("connect_timeout", 5.0)) + 5.0)
            last_state = "starting"
            while time.monotonic() < deadline:
                last_state = str(controller.status().get("state", "starting"))
                if last_state == expected_state:
                    break
                if last_state == "error":
                    raise RuntimeError("Session entered error state before sending")
                time.sleep(0.05)
            else:
                raise TimeoutError(
                    f"Session did not become {expected_state} before sending (last state: {last_state})"
                )
        return controller.send(data, encoding=encoding, target=target)

    def _periodic_tick(self):
        if self._shutting_down:
            return
        session_ids = {
            str(entry.get("session_id", ""))
            for entry in self.config.get("periodic_messages", [])
            if isinstance(entry, dict) and entry.get("id")
        }
        for session_id in session_ids:
            config = self._config_by_id(session_id)
            if (
                not self._ui_attached
                and config is not None
                and not self._session_runs_in_background(config)
            ):
                continue
            controller = self.controllers.get(session_id)
            if controller is None or not controller.running:
                # Auto-start remains a frontend lifecycle decision; recurring
                # deadlines themselves are worker-owned once the session runs.
                entries = [
                    entry for entry in self.config.get("periodic_messages", [])
                    if str(entry.get("session_id", "")) == session_id
                ]
                if any(
                    entry.get("enabled", True)
                    and entry.get("auto_start", True)
                    and not entry.get("paused_by_session_stop", False)
                    for entry in entries
                ):
                    if config is not None and session_id not in self._session_operations:
                        self._start_session_config(config, quiet=True)
                continue
            if self.tabs.currentWidget() is not self.monitor_tab:
                continue
            if session_id in self._periodic_status_inflight:
                continue
            self._periodic_status_inflight.add(session_id)
            self._run_async(
                lambda selected=controller: selected.request(
                    "periodic_status", timeout=5,
                ),
                lambda statuses, selected_id=session_id:
                    self._periodic_worker_status_received(selected_id, statuses),
                quiet=True,
                failure=lambda error, selected_id=session_id:
                    self._periodic_worker_status_failed(selected_id, error),
            )

    def _dispatch_periodic_message(self, entry):
        entry_id = entry.get("id")
        if not entry_id or entry_id in self._periodic_inflight or self._shutting_down:
            return
        if self._session_operations.get(entry.get("session_id")) == "stopping":
            return
        maximum_inflight = min(64, max(1, int(self.config.get("periodic_max_inflight", 16) or 16)))
        if len(self._periodic_inflight) >= maximum_inflight:
            return
        config = self._config_by_id(entry.get("session_id"))
        if config is None:
            self._periodic_send_failed(entry_id, "Destination session no longer exists")
            return
        try:
            data = self._periodic_bytes(entry)
        except (LookupError, UnicodeEncodeError, ValueError) as error:
            self._periodic_send_failed(entry_id, f"Invalid stored message: {error}")
            return
        controller = self._controller_for_config(config)
        auto_start = bool(entry.get("auto_start", True))
        if not controller.running and not auto_start:
            self._periodic_send_failed(entry_id, "Destination session is stopped and automatic startup is disabled")
            return
        self._periodic_inflight.add(entry_id); self._schedule_periodic_table_refresh()
        operation = lambda: self._send_bytes_operation(
            controller, config, data, str(entry.get("encoding", "utf-8")), str(entry.get("target", "")), auto_start,
        )
        self._run_async(
            operation,
            lambda result, selected_id=entry_id: self._periodic_send_succeeded(selected_id, result),
            quiet=True,
            failure=lambda error, selected_id=entry_id: self._periodic_send_failed(selected_id, error),
        )

    def _periodic_send_succeeded(self, entry_id, _result):
        self._periodic_inflight.discard(entry_id)
        entry = self._periodic_entry_by_id(entry_id)
        if entry is not None:
            entry["sent_count"] = int(entry.get("sent_count", 0) or 0) + 1
            entry["last_sent_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            entry["last_error"] = ""
            self._sync_periodic_session_state(entry.get("session_id"))
            self._sync_periodic_schedule_for_session(entry.get("session_id"))
        self._schedule_periodic_table_refresh()

    def _periodic_send_failed(self, entry_id, error):
        self._periodic_inflight.discard(entry_id)
        entry = self._periodic_entry_by_id(entry_id)
        if entry is not None:
            lines = [line.strip() for line in str(error).splitlines() if line.strip()]
            entry["last_error"] = (lines[-1] if lines else str(error))[:500]
            self._sync_periodic_session_state(entry.get("session_id"))
        self._schedule_periodic_table_refresh()

    def _sync_periodic_session_state(self, session_id):
        if not self._ui_attached:
            return
        controller = self.controllers.get(session_id)
        expected = "Running" if controller and controller.running else "Stopped"
        for index in range(self.sessions.topLevelItemCount()):
            item = self.sessions.topLevelItem(index)
            if item.data(0, QtCore.Qt.UserRole) == session_id:
                if item.text(4) != expected: self._reload_sessions()
                return

    def _schedule_periodic_table_refresh(self):
        if self._periodic_refresh_pending or self._shutting_down or not self._ui_attached:
            return
        self._periodic_refresh_pending = True
        QtCore.QTimer.singleShot(100, self._flush_periodic_table_refresh)

    def _flush_periodic_table_refresh(self):
        self._periodic_refresh_pending = False
        if not self._shutting_down and self._ui_attached and self.periodic_panel.isVisible():
            self._reload_periodic_messages()

    def _send(self):
        config = self._resolve_typed_send_session()
        if not config:
            return
        controller = self._controller_for_config(config)
        should_start = not controller.running
        if should_start and QtWidgets.QMessageBox.question(
            self, "Start session?", f"'{config['name']}' is stopped. Start it and send the message?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.Yes,
        ) != QtWidgets.QMessageBox.Yes:
            return
        encoding = self.send_encoding.currentData() or self.send_encoding.currentText()
        try:
            data = self._message_bytes()
        except (LookupError, UnicodeEncodeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Invalid message input", str(error)); return
        if config["protocol"] == "tcp_server":
            target = self.send_target.currentData()
            if target is None:
                target = self.send_target.currentText().split(" · ", 1)[0].strip()
            target = str(target or "all")
        else:
            target = ""
        def send_operation():
            return self._send_bytes_operation(controller, config, data, encoding, target, auto_start=True)

        def sent(result):
            if should_start:
                self._resume_periodic_messages_paused_by_session(config["id"])
            self.status_label.setText(
                f"Sent through #{self.config['sessions'].index(config) + 1:02d} {self._protocol_title(config['protocol'])} · {config['name']} · {result}"
            )
            self._reload_sessions()

        self.status_label.setText(f"Sending through {config['name']}…")
        self._run_async(send_operation, sent)

    @staticmethod
    def _common_query_definitions():
        return [
            ("All", "Remove every filter and show all stored messages.", {}),
            ("Received", "Messages received from the endpoint.", {"field": "direction", "operation": "equals", "value": "RX"}),
            ("Sent", "Messages transmitted to the endpoint.", {"field": "direction", "operation": "equals", "value": "TX"}),
            ("Parsed", "Messages successfully represented as structured parser data.", {"field": "parsed", "operation": "equals", "value": True}),
            ("Binary", "Unparsed messages stored as raw bytes.", {"field": "parsed", "operation": "equals", "value": False}),
            ("Parser errors", "Messages for which the parser raised an error.", {"field": "parse_status", "operation": "equals", "value": "error"}),
        ]

    def _common_name_filter_settings(self):
        self._normalize_common_name_filter(self.config)
        return self.config["common_name_filter"]

    def _update_common_name_filter_button(self):
        name = self._common_name_filter_settings()["name"]
        self.common_name_filter_button.setText(f"Name: {name}")
        self.common_name_filter_button.setToolTip(
            f"Current exact-name filter: {name}.\n"
            "Click once to apply it. Double-click to choose a recorded name or enter any name.\n"
            "This configured common filter is shared by all Communication Hub sessions."
        )

    def _apply_common_name_filter(self):
        name = self._common_name_filter_settings()["name"]
        self._apply_common_query({"field": "name", "operation": "equals", "value": name})

    def _configure_common_name_filter(self):
        if self._global_table_scope():
            self._run_async(
                lambda: sorted({name for _config, item in self._available_table_controllers() for name in item.request("names", {})}),
                self._show_common_name_filter_dialog,
            )
            return
        controller = self._selected_controller()
        table_available = bool(controller and getattr(controller, "table_available", controller.running))
        if table_available:
            self._run_async(
                lambda: controller.request("names", timeout=10),
                self._show_common_name_filter_dialog,
            )
        else:
            self._show_common_name_filter_dialog([])

    def _show_common_name_filter_dialog(self, available_names):
        current = self._common_name_filter_settings()["name"]
        suggestions = ["Unknown"]
        suggestions.extend(str(name) for name in (available_names or []) if str(name).strip())
        suggestions = list(dict.fromkeys(suggestions))
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Configure Common Name Filter")
        form = QtWidgets.QFormLayout(dialog)
        name = QtWidgets.QComboBox(); name.setEditable(True)
        name.addItems(suggestions); name.setCurrentText(current)
        name.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        name.setToolTip("Choose a recorded message name or type any exact name.")
        explanation = QtWidgets.QLabel(
            "Recorded names from the selected session are suggestions only. You may type any name."
        )
        explanation.setWordWrap(True)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        form.addRow("Message name", name); form.addRow(explanation); form.addRow(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return
        selected_name = name.currentText().strip()
        if not selected_name:
            QtWidgets.QMessageBox.warning(self, "Name filter", "Message name cannot be empty.")
            return
        self.config["common_name_filter"] = {"name": selected_name}
        self._normalize_common_name_filter(self.config)
        self._update_common_name_filter_button()
        self._save()
        self._apply_common_name_filter()

    def _last_period_filter_settings(self):
        self._normalize_last_period_filter(self.config)
        return self.config["last_period_filter"]

    @staticmethod
    def _format_period_amount(amount):
        return f"{float(amount):g}"

    def _update_last_period_filter_tooltip(self):
        period = self._last_period_filter_settings()
        amount = self._format_period_amount(period["amount"])
        unit = period["unit"]
        display_unit = unit[:-1] if float(period["amount"]) == 1.0 and unit.endswith("s") else unit
        self.last_period_filter_button.setText(f"Last {amount} {display_unit}")
        self.last_period_filter_button.setToolTip(
            f"Current period: last {amount} {display_unit}.\n"
            "Click once to apply this filter. Double-click to change the amount and time unit.\n"
            "The configured period is shared by all Communication Hub sessions."
        )

    def _apply_last_period_filter(self, _checked=False):
        period = self._last_period_filter_settings()
        self._apply_common_query({
            "field": "timestamp", "operation": "within_last",
            "value": period["amount"], "unit": period["unit"],
        })

    def _configure_last_period_filter(self):
        period = self._last_period_filter_settings()
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Configure Last Period Filter")
        form = QtWidgets.QFormLayout(dialog)
        amount = QtWidgets.QDoubleSpinBox()
        amount.setRange(0.001, 1_000_000.0); amount.setDecimals(3)
        amount.setValue(float(period["amount"])); amount.setAccelerated(True)
        unit = QtWidgets.QComboBox(); unit.addItems(["milliseconds", "seconds", "minutes", "hours"])
        unit.setCurrentText(period["unit"])
        explanation = QtWidgets.QLabel(
            "This period is used by the Last… period common filter for every session."
        )
        explanation.setWordWrap(True)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        form.addRow("Amount", amount); form.addRow("Unit", unit); form.addRow(explanation); form.addRow(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return
        self.config["last_period_filter"] = {"amount": amount.value(), "unit": unit.currentText()}
        self._normalize_last_period_filter(self.config)
        self._update_last_period_filter_tooltip()
        self._save()
        self._apply_last_period_filter()

    def _common_datetime_filter_settings(self, kind):
        if kind not in {"before", "after"}: raise ValueError(f"Unsupported datetime filter: {kind}")
        self._normalize_common_datetime_filters(self.config)
        return self.config["common_datetime_filters"][kind]

    @staticmethod
    def _display_datetime(value):
        return local_display(value, milliseconds=False)

    def _update_common_datetime_filter_button(self, kind):
        setting = self._common_datetime_filter_settings(kind)
        button = getattr(self, f"{kind}_datetime_filter_button")
        comparison = "including" if setting["inclusive"] else "excluding"
        button.setText(f"{kind.title()} datetime")
        button.setToolTip(
            f"Current boundary: {self._display_datetime(setting['datetime'])} ({comparison} the selected datetime).\n"
            "Click once to apply this filter. Double-click to change the date, time, and inclusion setting.\n"
            "The configured boundary is shared by all Communication Hub sessions."
        )

    def _apply_common_datetime_filter(self, kind):
        setting = self._common_datetime_filter_settings(kind)
        operation = {("before", False): "before", ("before", True): "lte", ("after", False): "after", ("after", True): "gte"}[
            (kind, setting["inclusive"])
        ]
        self._apply_common_query({
            "field": "timestamp", "operation": operation, "value": setting["datetime"],
        })

    def _configure_common_datetime_filter(self, kind):
        setting = self._common_datetime_filter_settings(kind)
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle(f"Configure {kind.title()} Datetime Filter")
        form = QtWidgets.QFormLayout(dialog)
        selected_datetime = QtWidgets.QDateTimeEdit(); selected_datetime.setCalendarPopup(True)
        selected_datetime.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        stored = QtCore.QDateTime.fromString(setting["datetime"], QtCore.Qt.ISODateWithMs)
        if not stored.isValid(): stored = QtCore.QDateTime.currentDateTime()
        selected_datetime.setDateTime(stored)
        inclusive = QtWidgets.QCheckBox("Include messages exactly at the selected datetime")
        inclusive.setChecked(setting["inclusive"])
        explanation = QtWidgets.QLabel(
            f"The editor and stored boundary use local time with its numeric offset for the message timestamp {kind} comparison."
        )
        explanation.setWordWrap(True)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        form.addRow("Date and time", selected_datetime); form.addRow("", inclusive)
        form.addRow(explanation); form.addRow(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return
        local_value = local_iso(selected_datetime.dateTime().toMSecsSinceEpoch() * 1_000_000)
        self.config.setdefault("common_datetime_filters", {})[kind] = {
            "datetime": local_value, "inclusive": inclusive.isChecked(),
        }
        self._normalize_common_datetime_filters(self.config)
        self._update_common_datetime_filter_button(kind)
        self._save()
        self._apply_common_datetime_filter(kind)

    @staticmethod
    def _query_condition_count(query):
        if not query: return 0
        if isinstance(query, dict) and "conditions" in query:
            return sum(CommunicationHubWidget._query_condition_count(item) for item in query.get("conditions", []))
        return 1

    @staticmethod
    def _operation_title(operation):
        return next((title for title, value, _description in QueryConditionDialog.OPERATIONS if value == operation), str(operation))

    @staticmethod
    def _condition_options(condition):
        operation = condition.get("operation")
        if operation == "within_last": return str(condition.get("unit", "seconds"))
        if operation == "regex": return "case-sensitive" if condition.get("case_sensitive", True) else "ignore case"
        if operation == "decoded_text_contains":
            return f"{condition.get('encoding', 'utf-8')} / {condition.get('errors', 'replace')}"
        return ""

    def _add_query_condition_item(self, condition, select=False):
        condition = copy.deepcopy(condition)
        value = condition.get("value", "")
        value_text = json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value
        item = QtWidgets.QTreeWidgetItem([
            str(condition.get("field", "")), self._operation_title(condition.get("operation", "equals")),
            value_text, self._condition_options(condition),
        ])
        item.setData(0, QtCore.Qt.UserRole, condition)
        tooltip = json.dumps(condition, indent=2, ensure_ascii=False)
        for column in range(4): item.setToolTip(column, tooltip)
        self.query_conditions.addTopLevelItem(item)
        if select:
            self.query_conditions.clearSelection(); item.setSelected(True); self.query_conditions.setCurrentItem(item)
        return item

    def _query_from_builder(self):
        conditions = [
            copy.deepcopy(self.query_conditions.topLevelItem(index).data(0, QtCore.Qt.UserRole))
            for index in range(self.query_conditions.topLevelItemCount())
        ]
        if not conditions: return {}
        if len(conditions) == 1 and not self.query_exclude.isChecked(): return conditions[0]
        query = {"operator": self.query_match_mode.currentData() or "and", "conditions": conditions}
        if self.query_exclude.isChecked(): query["not"] = True
        return query

    def _visual_query_changed(self, _value=None):
        if not hasattr(self, "query_edit"): return
        query = self._query_from_builder()
        self.query_edit.blockSignals(True); self.query_edit.setPlainText(json.dumps(query, indent=2, ensure_ascii=False)); self.query_edit.blockSignals(False)
        count = self._query_condition_count(query)
        if not count: summary = "Showing all messages"
        else:
            mode = "all" if self.query_match_mode.currentData() == "and" else "any"
            summary = f"{count} condition{'s' if count != 1 else ''} · match {mode}"
            if self.query_exclude.isChecked(): summary += " · excluded"
        self.query_summary.setText(summary)
        self._validate_advanced_query()

    def _validate_advanced_query(self):
        if not hasattr(self, "query_json_status"): return
        valid = False; message = ""; value = None
        try:
            value = json.loads(self.query_edit.toPlainText() or "{}")
            if not isinstance(value, dict): raise ValueError("The top-level query must be a JSON object")
            self._validate_query_node(value)
        except (TypeError, ValueError) as error:
            message = f"Invalid query: {error}"
            self.query_json_status.setText(message)
            self.query_json_status.setStyleSheet("color: #A12622;")
        else:
            valid = True; message = "Valid query JSON"
            self.query_json_status.setText(message)
            self.query_json_status.setStyleSheet("color: #1B7F3A;")
            if hasattr(self, "query_tabs") and self.query_tabs.currentWidget() is self.query_advanced_tab and hasattr(self, "query_summary"):
                self.query_summary.setText(f"Advanced query · {self._query_condition_count(value)} conditions")

        designer = getattr(self, "filter_designer_widget", None)
        if designer is not None:
            designer.notify_query_state(valid, message, value if valid else None)

    def _query_mode_changed(self, _index=None):
        if self.query_tabs.currentWidget() is self.query_advanced_tab:
            self._validate_advanced_query()
            try: query = json.loads(self.query_edit.toPlainText() or "{}")
            except ValueError: return
            self.query_summary.setText(f"Advanced query · {self._query_condition_count(query)} conditions")
        else:
            self._visual_query_changed()

    def _toggle_query_designer(self, visible):
        self.query_designer_panel.setVisible(visible)
        self.query_designer_toggle.setArrowType(QtCore.Qt.DownArrow if visible else QtCore.Qt.RightArrow)
        self.query_designer_toggle.setText("Hide filter designer" if visible else "Show filter designer")
        self._update_query_workspace_visibility()

    def _toggle_name_summary(self, visible):
        self.name_summary_panel.setVisible(visible)
        self.name_summary_toggle.setArrowType(QtCore.Qt.DownArrow if visible else QtCore.Qt.RightArrow)
        self.name_summary_toggle.setText("Hide message summary" if visible else "Show message summary")
        self._update_query_workspace_visibility()
        if visible:
            self._refresh_name_summary(force=True)

    def _update_query_workspace_visibility(self):
        # isVisible() is false while the whole Communication Hub has not been shown yet;
        # isHidden() reflects whether each panel was explicitly collapsed by its toggle.
        visible = not self.query_designer_panel.isHidden() or not self.name_summary_panel.isHidden()
        self.query_workspace_splitter.setVisible(visible)

    def _update_table_session_indicator(self, started_session_id=None, loading=False):
        if self.table_session_indicator_timer.isActive() and started_session_id is None and not loading:
            return
        if self._global_table_scope():
            available = len(self._available_table_controllers())
            text = f"Showing global tables · {available} session table{'s' if available != 1 else ''} combined"
            if started_session_id:
                started = self._config_by_id(started_session_id)
                if started: text += f"   |   {started.get('name', 'A session')} started; global tables are refreshing."
            self.table_session_indicator.setText(text)
            return
        config = self._selected_config()
        if config is None:
            self.table_session_indicator.setText("No session table selected")
            return
        index = self.config.get("sessions", []).index(config) + 1
        state = "Loading tables for" if loading else "Showing tables for"
        text = f"{state} #{index:02d} · {config.get('name', 'Unnamed')} · {self._protocol_title(config.get('protocol', ''))} · ID {config.get('id', '')}"
        if started_session_id and started_session_id != config.get("id"):
            started = self._config_by_id(started_session_id)
            if started:
                text += f"   |   {started.get('name', 'Another session')} started; displayed tables remain unchanged."
        self.table_session_indicator.setText(text)

    def _global_table_scope(self):
        return getattr(self, "_message_table_scope", "per_session") == "global"

    def _query_state_key(self, scope=None, session_id=None):
        scope = scope or getattr(self, "_message_table_scope", "per_session")
        if scope == "global": return "__global__"
        if session_id: return str(session_id)
        selected = self._selected_config()
        return str(selected.get("id")) if selected else None

    def _message_table_scope_changed(self, _index=None):
        new_scope = self.message_table_scope_combo.currentData() or "per_session"
        old_scope = getattr(self, "_message_table_scope", "per_session")
        if self._query_state_ready:
            self._save_query_ui_state(self._query_state_key(scope=old_scope))
        self._message_table_scope = new_scope
        self.config["message_table_scope"] = new_scope
        if self._query_state_ready:
            self._restore_query_ui_state(self._query_state_key(scope=new_scope))
            self._clear_displayed_message_views()
            self.page = 0; self._last_name_summary_version = -1
            self._refresh_table(reset=True); self._refresh_name_summary(force=True)
            self._flash_table_session_indicator(loading=True)
            self._save()

    def _flash_table_session_indicator(self, started_session_id=None, loading=False):
        self._update_table_session_indicator(started_session_id, loading=loading)
        self._table_indicator_flash_step = 0
        self.table_session_indicator_timer.start()

    def _advance_table_session_indicator_flash(self):
        self._table_indicator_flash_step += 1
        highlighted = self._table_indicator_flash_step % 2 == 1
        self.table_session_indicator.setStyleSheet(
            "font-weight: 600; color: #6B3E00; background: #FFF2CC; border: 1px solid #D6A84B; border-radius: 3px; padding: 5px 8px;"
            if highlighted else
            "font-weight: 600; color: #174EA6; background: #E8F0FE; border: 1px solid #A9C1EA; border-radius: 3px; padding: 5px 8px;"
        )
        if self._table_indicator_flash_step >= 6:
            self.table_session_indicator_timer.stop()
            self._update_table_session_indicator()

    @staticmethod
    def _advanced_query_guide_html():
        return r'''
<html><head><style>
body { font-family: sans-serif; line-height: 1.35; }
h1 { font-size: 20px; } h2 { font-size: 16px; margin-top: 22px; } h3 { font-size: 14px; margin-top: 16px; }
pre { background: #eef1f4; color: #20252b; border: 1px solid #c8cdd2; padding: 9px; white-space: pre-wrap; }
code { background: #eef1f4; color: #20252b; padding: 1px 3px; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #c8cdd2; padding: 5px; text-align: left; vertical-align: top; }
.note { background: #eaf3ff; color: #153b66; border: 1px solid #8bb5df; padding: 9px; }
.warning { background: #fff4df; color: #663c00; border: 1px solid #e3bc70; padding: 9px; }
</style></head><body>
<h1>Advanced JSON query guide</h1>
<p>Advanced JSON uses the same fields and comparisons as the Guided Filter Builder, plus arbitrarily nested <code>and</code>, <code>or</code>, and <code>not</code> groups. The top-level value must always be a JSON object.</p>
<div class="note"><b>Safe workflow:</b> edit the JSON, confirm that the status below the editor says <i>Valid query JSON</i>, then choose <b>Apply Filter</b>. Use <b>Save Current…</b> to retain a named reusable query. An empty object <code>{}</code> means show all rows.</div>

<h2>1. Query building blocks</h2>
<h3>Condition</h3>
<pre>{
  "field": "name",
  "operation": "contains",
  "value": "Status"
}</pre>
<p>A condition requires <code>field</code> and <code>operation</code>. Most operations also require <code>value</code>. Operation-specific options such as <code>unit</code>, <code>case_sensitive</code>, <code>encoding</code>, and <code>errors</code> belong beside them.</p>

<h3>Condition group</h3>
<pre>{
  "operator": "and",
  "conditions": [
    {"field": "direction", "operation": "equals", "value": "RX"},
    {"field": "parsed", "operation": "equals", "value": true}
  ]
}</pre>
<p><code>operator</code> accepts <code>and</code> or <code>or</code>. A group may contain conditions and other groups. Add <code>"not": true</code> to invert the complete result of that group.</p>
<pre>{
  "operator": "and",
  "not": true,
  "conditions": [
    {"field": "name", "operation": "regex", "value": "^Debug"},
    {"field": "protocol", "operation": "equals", "value": "serial"}
  ]
}</pre>
<p>This example means “not (a Debug-name message and Serial protocol).” It does not negate each child independently.</p>

<h2>2. Available fields</h2>
<table>
<tr><th>Field</th><th>Meaning</th></tr>
<tr><td><code>id</code></td><td>Stable in-memory row ID. An updated conflict row keeps its ID.</td></tr>
<tr><td><code>timestamp</code></td><td>Time of the latest bytes represented by the row.</td></tr>
<tr><td><code>first_timestamp</code></td><td>Time the conflict-updated row was first created.</td></tr>
<tr><td><code>direction</code></td><td><code>RX</code> or <code>TX</code>.</td></tr>
<tr><td><code>protocol</code></td><td><code>tcp_client</code>, <code>tcp_server</code>, <code>serial</code>, or <code>telnet</code>.</td></tr>
<tr><td><code>protocol_label</code></td><td>User-defined application protocol label.</td></tr>
<tr><td><code>name</code></td><td>Parser-provided message name or <code>Unknown</code>.</td></tr>
<tr><td><code>parsed</code></td><td>Boolean indicating structured parser output.</td></tr>
<tr><td><code>data</code></td><td>Parsed dictionary/list/value, or raw bytes when not parsed.</td></tr>
<tr><td><code>data.path</code></td><td>Nested parser value, for example <code>data.Device.Id</code>. Numeric path components address list positions, such as <code>data.Values.0</code>.</td></tr>
<tr><td><code>header</code></td><td>Raw received header bytes. TX normally has an empty header.</td></tr>
<tr><td><code>header_fields.path</code></td><td>Configured decoded header value, for example <code>header_fields.message_id</code>.</td></tr>
<tr><td><code>size</code>, <code>frame_size</code></td><td>Stored complete-message byte length.</td></tr>
<tr><td><code>peer</code>, <code>connection_id</code></td><td>Remote endpoint and transport connection identity.</td></tr>
<tr><td><code>session_id</code></td><td>Communication session identity.</td></tr>
<tr><td><code>parse_status</code>, <code>parse_error</code>, <code>parse_duration_ns</code></td><td>Parser outcome, error text, and execution duration.</td></tr>
<tr><td><code>update_count</code></td><td>Number of messages merged into an update-on-conflict row.</td></tr>
</table>
<p>A missing column or nested path behaves like a null value. Use <code>exists</code> or <code>missing</code> when testing field availability.</p>

<h2>3. Operations</h2>
<table>
<tr><th>Operation</th><th>Value / options</th><th>Purpose</th></tr>
<tr><td><code>equals</code>, <code>not_equals</code></td><td>Any JSON value</td><td>Exact equality or inequality. Types matter: <code>10</code> differs from <code>"10"</code>.</td></tr>
<tr><td><code>in</code></td><td>JSON array</td><td>Match one of several exact values, e.g. <code>["RX", "TX"]</code>.</td></tr>
<tr><td><code>contains</code></td><td>Item</td><td>Substring, byte subsequence, list item, or dictionary key containment.</td></tr>
<tr><td><code>contains_value</code></td><td>Any JSON value</td><td>Recursively search values inside parsed dictionaries and lists.</td></tr>
<tr><td><code>starts_with</code>, <code>ends_with</code></td><td>Text/value</td><td>Compare the beginning or end of the value’s text representation.</td></tr>
<tr><td><code>regex</code></td><td>Python regex; optional <code>case_sensitive</code></td><td>Regular-expression search. Case sensitivity defaults to <code>true</code>.</td></tr>
<tr><td><code>glob</code></td><td>Wildcard text</td><td>Case-sensitive shell pattern such as <code>Status*</code> or <code>*Error?</code>.</td></tr>
<tr><td><code>exists</code>, <code>missing</code></td><td>No <code>value</code></td><td>Test for non-null or null/missing data.</td></tr>
<tr><td><code>type_is</code></td><td>Type name</td><td>Match <code>int</code>, <code>float</code>, <code>str</code>, <code>bytes</code>, <code>list</code>, <code>dict</code>, etc.</td></tr>
<tr><td><code>gt</code>, <code>gte</code>, <code>lt</code>, <code>lte</code></td><td>Ordered value</td><td>Numeric, text, or timestamp comparisons.</td></tr>
<tr><td><code>before</code>, <code>after</code></td><td>Ordered value / timestamp</td><td>Readable aliases for less-than and greater-than behavior.</td></tr>
<tr><td><code>between</code></td><td><code>[minimum, maximum]</code></td><td>Inclusive range comparison.</td></tr>
<tr><td><code>within_last</code></td><td>Number plus <code>unit</code></td><td>Relative timestamp window. Unit: milliseconds, seconds, minutes, or hours.</td></tr>
<tr><td><code>contains_bytes</code></td><td>Hex string</td><td>Find bytes, for example <code>"01 FF A0"</code>.</td></tr>
<tr><td><code>byte_at</code></td><td><code>[offset, expected_byte]</code></td><td>Compare a byte value from 0 to 255. Negative offsets count from the end.</td></tr>
<tr><td><code>decoded_text_contains</code></td><td>Text plus optional <code>encoding</code>/<code>errors</code></td><td>Decode raw bytes and search text. Errors: replace, strict, or ignore.</td></tr>
</table>

<h2>4. Value syntax</h2>
<p>Advanced mode is strict JSON: strings require double quotes; booleans are lowercase <code>true</code>/<code>false</code>; null is <code>null</code>; arrays use square brackets. Comments and trailing commas are invalid.</p>
<pre>{"field": "data.DeviceId", "operation": "equals", "value": 42}
{"field": "parsed", "operation": "equals", "value": true}
{"field": "direction", "operation": "in", "value": ["RX", "TX"]}</pre>

<h2>5. Timestamp examples</h2>
<pre>{
  "field": "timestamp",
  "operation": "within_last",
  "value": 10,
  "unit": "seconds"
}</pre>
<pre>{
  "field": "timestamp",
  "operation": "between",
  "value": ["2026-07-20T08:00:00+03:00", "2026-07-20T09:00:00+03:00"]
}</pre>
<p>Use ISO-8601 local timestamps with an explicit numeric time-zone offset, such as <code>+03:00</code>.</p>

<h2>6. Raw-byte and header examples</h2>
<pre>{"field": "data", "operation": "contains_bytes", "value": "AA 55 01"}</pre>
<pre>{"field": "data", "operation": "byte_at", "value": [3, 255]}</pre>
<pre>{
  "field": "data",
  "operation": "decoded_text_contains",
  "value": "READY",
  "encoding": "ascii",
  "errors": "replace"
}</pre>
<pre>{"field": "header_fields.message_id", "operation": "equals", "value": 7}</pre>

<h2>7. Nested practical example</h2>
<pre>{
  "operator": "or",
  "conditions": [
    {
      "operator": "and",
      "conditions": [
        {"field": "direction", "operation": "equals", "value": "RX"},
        {"field": "parsed", "operation": "equals", "value": true},
        {"field": "data.DeviceId", "operation": "exists"}
      ]
    },
    {
      "operator": "and",
      "conditions": [
        {"field": "parsed", "operation": "equals", "value": false},
        {"field": "data", "operation": "contains_bytes", "value": "DE AD BE EF"}
      ]
    }
  ]
}</pre>

<h2>8. Validation, performance, and destructive actions</h2>
<ul>
<li>The status below the editor reports syntax and supported-operation errors before application.</li>
<li>Comparisons should match the stored value type. A numeric comparison against text may fail or produce no matches.</li>
<li>Regex, recursive value searches, decoded-byte searches, and deeply nested logic can be expensive on very large tables. Page size limits displayed rows, not the number evaluated by the filter.</li>
<li><b>Delete Matching…</b> uses the exact active query and shows a count before confirmation. Review the filtered results first.</li>
<li>Switching to Guided mode and editing a guided condition regenerates the JSON preview. Nested queries remain in Advanced mode because Guided mode cannot represent them safely.</li>
</ul>
<div class="warning"><b>Important:</b> <code>{}</code> matches every row. Applying it is safe, but using <b>Delete Matching…</b> with it targets the entire table after confirmation.</div>
</body></html>
'''

    def _show_advanced_query_guide(self):
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Advanced JSON Query Guide")
        dialog.resize(940, 760)
        layout = QtWidgets.QVBoxLayout(dialog)
        search_row = QtWidgets.QHBoxLayout()
        search = QtWidgets.QLineEdit(); search.setPlaceholderText("Find field, operation, or example…")
        find_next = QtWidgets.QPushButton("Find next")
        search_row.addWidget(search, 1); search_row.addWidget(find_next); layout.addLayout(search_row)
        browser = QtWidgets.QTextBrowser(); browser.setOpenExternalLinks(False)
        browser.setHtml(self._advanced_query_guide_html()); layout.addWidget(browser, 1)

        def find():
            text = search.text()
            if not text:
                return
            if not browser.find(text):
                cursor = browser.textCursor(); cursor.movePosition(QtGui.QTextCursor.Start)
                browser.setTextCursor(cursor); browser.find(text)

        find_next.clicked.connect(find); search.returnPressed.connect(find)
        QtWidgets.QShortcut(QtGui.QKeySequence.Find, dialog, activated=search.setFocus)
        close = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        close.rejected.connect(dialog.reject); layout.addWidget(close)
        dialog.exec_()

    def _save_query_ui_state(self, session_id=None):
        if not hasattr(self, "query_tabs"):
            return
        state = {
            "mode": "advanced" if self.query_tabs.currentWidget() is self.query_advanced_tab else "guided",
            "guided_query": copy.deepcopy(self._query_from_builder()),
            "advanced_text": self.query_edit.toPlainText(),
            "designer_visible": self.query_designer_toggle.isChecked(),
            "name_summary_visible": self.name_summary_toggle.isChecked(),
            "query_workspace_sizes": self.query_workspace_splitter.sizes(),
            "selected_saved_query_id": self.saved_query_combo.currentData(),
            "active_saved_query_id": self._active_saved_query_id,
            "page_size": self.page_size,
            "auto_refresh": self.auto_refresh.isChecked(),
            "page": self.page,
        }
        self.config["query_ui_state"] = copy.deepcopy(state)  # Legacy compatibility.
        if session_id is None:
            session_id = self._query_state_key()
        if session_id:
            self.config.setdefault("query_ui_state_by_session", {})[str(session_id)] = copy.deepcopy(state)

    def _restore_query_ui_state(self, session_id=None):
        if session_id is None:
            session_id = self._query_state_key()
        self._normalize_session_query_states(self.config)
        state = copy.deepcopy(self.config.get("query_ui_state_by_session", {}).get(str(session_id), {}))

        guided_query = state.get("guided_query", {})
        if isinstance(guided_query, dict):
            try:
                self._validate_query_node(guided_query)
                self._populate_query_builder(guided_query)
            except (TypeError, ValueError):
                pass

        if state.get("mode") == "advanced":
            advanced_text = state.get("advanced_text", "{}")
            self.query_edit.setPlainText(advanced_text if isinstance(advanced_text, str) else "{}")
            self.query_tabs.setCurrentWidget(self.query_advanced_tab)
        else:
            self.query_tabs.setCurrentWidget(self.query_guided_tab)
            self._visual_query_changed()

        saved_query_id = state.get("selected_saved_query_id")
        saved_index = self.saved_query_combo.findData(saved_query_id)
        self.saved_query_combo.blockSignals(True)
        self.saved_query_combo.setCurrentIndex(saved_index if saved_index >= 0 else 0)
        self.saved_query_combo.blockSignals(False)
        self._active_saved_query_id = state.get("active_saved_query_id")
        self.delete_saved_query_button.setEnabled(
            self._saved_query_by_id(self.saved_query_combo.currentData() or self._active_saved_query_id) is not None
        )

        designer_visible = bool(state.get("designer_visible", True))
        self.query_designer_toggle.blockSignals(True)
        self.query_designer_toggle.setChecked(designer_visible)
        self.query_designer_toggle.blockSignals(False)
        self._toggle_query_designer(designer_visible)
        name_summary_visible = bool(state.get("name_summary_visible", True))
        self.name_summary_toggle.blockSignals(True)
        self.name_summary_toggle.setChecked(name_summary_visible)
        self.name_summary_toggle.blockSignals(False)
        self._toggle_name_summary(name_summary_visible)
        splitter_sizes = state.get("query_workspace_sizes", [720, 360])
        if isinstance(splitter_sizes, list) and len(splitter_sizes) == 2:
            try: self.query_workspace_splitter.setSizes([max(1, int(value)) for value in splitter_sizes])
            except (TypeError, ValueError): pass
        self.auto_refresh.setChecked(bool(state.get("auto_refresh", True)))
        try: restored_page_size = int(state.get("page_size", self.page_size))
        except (TypeError, ValueError): restored_page_size = self.page_size
        if restored_page_size in {100, 200, 500, 1000}:
            self.page_size = restored_page_size
            page_size_index = self.page_size_combo.findData(restored_page_size)
            self.page_size_combo.blockSignals(True)
            self.page_size_combo.setCurrentIndex(page_size_index)
            self.page_size_combo.blockSignals(False)
        try: self.page = max(0, int(state.get("page", 0)))
        except (TypeError, ValueError): self.page = 0

    @classmethod
    def _validate_query_node(cls, node):
        if not isinstance(node, dict): raise ValueError("Every query node must be an object")
        if not node: return
        if "conditions" in node:
            if node.get("operator", "and").lower() not in {"and", "or"}: raise ValueError("Group operator must be and or or")
            conditions = node.get("conditions")
            if not isinstance(conditions, list): raise ValueError("Group conditions must be a list")
            for child in conditions: cls._validate_query_node(child)
            return
        if not str(node.get("field", "")).strip(): raise ValueError("Every condition requires a field")
        supported = {value for _title, value, _description in QueryConditionDialog.OPERATIONS}
        operation = str(node.get("operation", "equals")).lower()
        if operation not in supported: raise ValueError(f"Unsupported query operation: {operation}")
        if operation not in {"exists", "missing"} and "value" not in node: raise ValueError(f"{operation} requires a value")
        if operation in {"between", "byte_at"}:
            value = node.get("value")
            if not isinstance(value, list) or len(value) != 2: raise ValueError(f"{operation} requires a two-item array")
        if operation == "regex":
            import re
            try: re.compile(str(node.get("value", "")))
            except re.error as error: raise ValueError(f"Invalid regular expression: {error}") from error

    def _query(self):
        query = (
            json.loads(self.query_edit.toPlainText() or "{}")
            if self.query_tabs.currentWidget() is self.query_advanced_tab else self._query_from_builder()
        )
        if not isinstance(query, dict): raise ValueError("The top-level query must be a JSON object")
        self._validate_query_node(query)
        return query

    def _populate_query_builder(self, query):
        query = copy.deepcopy(query or {})
        if not query:
            operator, excluded, conditions = "and", False, []
        elif "conditions" in query and all(isinstance(item, dict) and "conditions" not in item for item in query.get("conditions", [])):
            operator = str(query.get("operator", "and")).lower(); excluded = bool(query.get("not", False)); conditions = query.get("conditions", [])
        elif "conditions" not in query:
            operator, excluded, conditions = "and", False, [query]
        else:
            return False
        self.query_conditions.clear()
        mode_index = self.query_match_mode.findData(operator)
        self.query_match_mode.blockSignals(True); self.query_match_mode.setCurrentIndex(mode_index if mode_index >= 0 else 0); self.query_match_mode.blockSignals(False)
        self.query_exclude.blockSignals(True); self.query_exclude.setChecked(excluded); self.query_exclude.blockSignals(False)
        for condition in conditions: self._add_query_condition_item(condition)
        self._visual_query_changed(); return True

    def _load_query_into_ui(self, query, apply=False):
        query = copy.deepcopy(query or {})
        self._validate_query_node(query)
        if self._populate_query_builder(query):
            self.query_tabs.setCurrentWidget(self.query_guided_tab)
        else:
            self.query_edit.setPlainText(json.dumps(query, indent=2, ensure_ascii=False))
            self.query_tabs.setCurrentWidget(self.query_advanced_tab)
            self.query_summary.setText(f"Advanced query · {self._query_condition_count(query)} conditions")
        if apply: self._refresh_table(reset=True)

    def _common_filter_mode_changed(self, _index=None):
        self.config["common_filter_mode"] = self.common_filter_mode_combo.currentData() or "replace"
        self._normalize_common_filter_mode(self.config)
        self._save()

    def _append_common_query(self, current, addition):
        current, addition = copy.deepcopy(current or {}), copy.deepcopy(addition or {})
        if not current: return addition
        if not addition: return current
        if "conditions" in current and not current.get("not"):
            current.setdefault("operator", "and")
            current["conditions"] = list(current.get("conditions", [])) + [addition]
            return current
        operator = (
            self.query_match_mode.currentData() or "and"
            if self.query_tabs.currentWidget() is self.query_guided_tab else "and"
        )
        return {"operator": operator, "conditions": [current, addition]}

    def _apply_common_query(self, query):
        query = copy.deepcopy(query or {})
        # "All" always means clear the query; appending an empty condition would be a no-op.
        if query and self.common_filter_mode_combo.currentData() == "append":
            try: query = self._append_common_query(self._query(), query)
            except (TypeError, ValueError) as error:
                QtWidgets.QMessageBox.warning(self, "Cannot append common filter", str(error)); return
        self._load_query_into_ui(query, apply=True)

    def _add_visual_query_condition(self):
        dialog = QueryConditionDialog(self)
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return
        self._add_query_condition_item(dialog.condition, select=True); self._visual_query_changed()

    def _edit_visual_query_condition(self):
        item = self.query_conditions.currentItem()
        if item is None: return
        dialog = QueryConditionDialog(self, item.data(0, QtCore.Qt.UserRole))
        if dialog.exec_() != QtWidgets.QDialog.Accepted: return
        row = self.query_conditions.indexOfTopLevelItem(item); self.query_conditions.takeTopLevelItem(row)
        replacement = self._add_query_condition_item(dialog.condition)
        moved = self.query_conditions.takeTopLevelItem(self.query_conditions.indexOfTopLevelItem(replacement))
        self.query_conditions.insertTopLevelItem(row, moved); self.query_conditions.setCurrentItem(moved); moved.setSelected(True)
        self._visual_query_changed()

    def _duplicate_visual_query_condition(self):
        item = self.query_conditions.currentItem()
        if item is None: return
        self._add_query_condition_item(item.data(0, QtCore.Qt.UserRole), select=True); self._visual_query_changed()

    def _remove_visual_query_conditions(self):
        rows = sorted({self.query_conditions.indexOfTopLevelItem(item) for item in self.query_conditions.selectedItems()}, reverse=True)
        for row in rows: self.query_conditions.takeTopLevelItem(row)
        self._visual_query_changed()

    def _clear_query(self, report_unavailable=False):
        self.query_conditions.clear()
        self.query_match_mode.setCurrentIndex(0); self.query_exclude.setChecked(False)
        self.query_tabs.setCurrentWidget(self.query_guided_tab); self._visual_query_changed()
        self._refresh_table(reset=True, report_unavailable=report_unavailable)

    def _saved_query_by_id(self, query_id):
        return next((entry for entry in self.config.get("saved_queries", []) if isinstance(entry, dict) and entry.get("id") == query_id), None)

    def _reload_saved_queries(self, selected_id=None):
        if selected_id is None and hasattr(self, "saved_query_combo"): selected_id = self.saved_query_combo.currentData()
        self.saved_query_combo.blockSignals(True); self.saved_query_combo.clear(); self.saved_query_combo.addItem("Select a saved query...", None)
        for entry in self.config.get("saved_queries", []):
            if isinstance(entry, dict) and entry.get("id"):
                count = self._query_condition_count(entry.get("query", {}))
                self.saved_query_combo.addItem(f"{entry.get('name', 'Unnamed')}  ·  {count} condition{'s' if count != 1 else ''}", entry["id"])
        index = self.saved_query_combo.findData(selected_id); self.saved_query_combo.setCurrentIndex(index if index >= 0 else 0)
        self.saved_query_combo.blockSignals(False)
        self.delete_saved_query_button.setEnabled(
            self._saved_query_by_id(self.saved_query_combo.currentData() or self._active_saved_query_id) is not None
        )

    def _load_saved_query(self, _index):
        entry = self._saved_query_by_id(self.saved_query_combo.currentData())
        if entry is not None:
            try: self._load_query_into_ui(entry.get("query", {}), apply=True)
            except (TypeError, ValueError) as error: QtWidgets.QMessageBox.warning(self, "Invalid saved query", str(error))
            else:
                self._active_saved_query_id = entry["id"]
                self.saved_query_combo.blockSignals(True)
                self.saved_query_combo.setCurrentIndex(0)
                self.saved_query_combo.blockSignals(False)
                self.saved_query_notice.setText("Loaded successfully")
                self.saved_query_notice.setToolTip(f"Loaded saved query: {entry.get('name', 'Unnamed')}")
                self.saved_query_notice.show(); self.saved_query_notice_timer.start(3000)
        self.delete_saved_query_button.setEnabled(
            self._saved_query_by_id(self.saved_query_combo.currentData() or self._active_saved_query_id) is not None
        )

    def _save_current_query(self):
        try: query = self._query()
        except (TypeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Cannot save query", str(error)); return
        current = self._saved_query_by_id(self.saved_query_combo.currentData() or self._active_saved_query_id)
        default_name = str(current.get("name")) if current else f"Query {len(self.config.get('saved_queries', [])) + 1}"
        name, accepted = QtWidgets.QInputDialog.getText(self, "Save query", "Query name", text=default_name)
        name = name.strip()
        if not accepted or not name: return
        queries = self.config.setdefault("saved_queries", [])
        same_name = next((entry for entry in queries if str(entry.get("name", "")).casefold() == name.casefold()), None)
        if current is not None and same_name is not None and same_name is not current:
            QtWidgets.QMessageBox.warning(self, "Query name already used", f"A saved query named '{name}' already exists."); return
        target = current or same_name
        if target is not None and QtWidgets.QMessageBox.question(
            self, "Replace saved query?", f"Replace the saved query '{target.get('name', name)}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.Yes,
        ) != QtWidgets.QMessageBox.Yes: return
        if target is None:
            target = {"id": str(uuid.uuid4())}; queries.append(target)
        target.update({"name": name, "query": copy.deepcopy(query)})
        self._active_saved_query_id = target["id"]
        self._save(); self._reload_saved_queries(target["id"])

    def _delete_saved_query(self):
        entry = self._saved_query_by_id(self.saved_query_combo.currentData() or self._active_saved_query_id)
        if entry is None: return
        if QtWidgets.QMessageBox.question(
            self, "Delete saved query?", f"Delete '{entry.get('name', 'this query')}'?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        ) != QtWidgets.QMessageBox.Yes: return
        self.config["saved_queries"].remove(entry)
        if self._active_saved_query_id == entry.get("id"): self._active_saved_query_id = None
        self._save(); self._reload_saved_queries()

    def _page_size_changed(self, _index=None):
        self.page_size = int(self.page_size_combo.currentData() or 200)
        self._refresh_table(reset=True)

    def _table_action_controller(self, action, report_unavailable=True):
        controller = self._selected_controller()
        if controller and bool(getattr(controller, "table_available", controller.running)):
            return controller
        if report_unavailable:
            config = self._selected_config()
            detail = (
                f"Start '{config.get('name', 'the selected session')}' first. No retained message table exists for it yet."
                if config else "Select a session first."
            )
            QtWidgets.QMessageBox.information(self, action, detail)
        return None

    def _available_table_controllers(self):
        available = []
        for config in self.config.get("sessions", []):
            controller = self.controllers.get(config.get("id"))
            if controller and bool(getattr(controller, "table_available", controller.running)):
                available.append((config, controller))
        return available

    def _query_global_tables(self, query, page, page_size):
        required = max(1, (int(page) + 1) * int(page_size))
        rows, total, versions = [], 0, {}
        for config, controller in self._available_table_controllers():
            result = controller.query(query, page=0, page_size=required)
            rows.extend(result.get("rows", [])); total += int(result.get("total", 0) or 0)
            versions[config["id"]] = int(result.get("version", -1))
        rows.sort(
            key=lambda row: _timestamp_sort_ns(row.get("timestamp"), row.get("timestamp_ns")), reverse=True,
        )
        start = max(0, int(page)) * max(1, int(page_size))
        return {
            "rows": rows[start:start + max(1, int(page_size))], "total": total,
            "page": page, "page_size": page_size, "versions": versions,
        }

    def _summarize_global_tables(self):
        combined, versions = {}, {}
        for config, controller in self._available_table_controllers():
            result = controller.request("name_summary", {})
            versions[config["id"]] = int(result.get("version", -1))
            for row in result.get("rows", []):
                name = str(row.get("name", "Unknown"))
                target = combined.setdefault(name, {"name": name, "message_count": 0, "last_timestamp": "", "last_timestamp_ns": 0})
                target["message_count"] += int(row.get("message_count", 0) or 0)
                value_ns = _timestamp_sort_ns(row.get("last_timestamp"), row.get("last_timestamp_ns"))
                if value_ns > int(target["last_timestamp_ns"]):
                    target["last_timestamp_ns"] = value_ns
                    target["last_timestamp"] = row.get("last_timestamp", "")
        rows = sorted(combined.values(), key=lambda row: int(row["last_timestamp_ns"]), reverse=True)
        return {"rows": rows, "total_names": len(rows), "versions": versions, "version": hash(tuple(sorted(versions.items())))}

    def _refresh_table(self, reset=False, report_unavailable=False):
        if (
            not self._ui_attached
            or not hasattr(self, "tabs")
            or self.tabs.currentWidget() is not self.table_tab
        ):
            return
        global_scope = self._global_table_scope()
        controller = None if global_scope else self._table_action_controller("Cannot query message table", report_unavailable)
        if not global_scope and controller is None:
            if hasattr(self, "page_label"): self.page_label.setText("No retained table for this session")
            if hasattr(self, "name_summary_label"): self.name_summary_label.setText("No recorded message names")
            if hasattr(self, "table_session_indicator"): self._update_table_session_indicator()
            return
        config = self._selected_config()
        if not global_scope and config is None: return
        session_id = "__global__" if global_scope else config["id"]
        if reset: self.page = 0
        try: query = self._query()
        except (TypeError, ValueError) as error: QtWidgets.QMessageBox.warning(self, "Invalid query", str(error)); return
        page = self.page
        if global_scope:
            operation = lambda: self._query_global_tables(query, page, self.page_size)
        else:
            operation = lambda: controller.query(query, page=page, page_size=self.page_size)
        self._run_async(
            operation,
            lambda result, selected_id=session_id: self._show_page(result, selected_id),
        )

    def _show_page(self, result, session_id=None):
        if not self._ui_attached or self.tabs.currentWidget() is not self.table_tab:
            return
        selected = self._selected_config()
        if session_id == "__global__" and not self._global_table_scope(): return
        if session_id not in {None, "__global__"} and (selected is None or selected.get("id") != session_id or self._global_table_scope()): return
        columns = ["id", "timestamp", "direction", "protocol", "name", "data", "size", "peer", "parse_status"]
        if session_id == "__global__": columns.insert(2, "session_id")
        rows = result.get("rows", [])
        self._displayed_message_rows = list(rows) if isinstance(rows, list) else []
        headers = ["Timestamp (local)" if column == "timestamp" else column for column in columns]
        self.table.setColumnCount(len(columns)); self.table.setHorizontalHeaderLabels(headers); self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, column in enumerate(columns):
                value = row.get(column, "")
                text = (
                    _local_timestamp_text(value)
                    if column in TIMESTAMP_FIELDS else
                    json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value)
                )
                item = QtWidgets.QTableWidgetItem(text)
                if column in TIMESTAMP_FIELDS:
                    item.setData(QtCore.Qt.UserRole, value)
                self.table.setItem(r, c, item)
        self.table.resizeColumnsToContents(); self.page_label.setText(f"{result.get('total', 0)} rows · page {self.page + 1}")
        self._update_table_session_indicator()

    def _clear_displayed_message_views(self):
        if not hasattr(self, "table"): return
        self._displayed_message_rows = []
        self.table.setRowCount(0)
        self.page_label.setText("Loading…")
        self.name_summary_table.setRowCount(0)
        self.name_summary_label.setText("Loading message-name summary…")

    def _refresh_name_summary(self, force=False):
        if (
            not self._ui_attached
            or not hasattr(self, "tabs")
            or self.tabs.currentWidget() is not self.table_tab
        ):
            return
        if not hasattr(self, "name_summary_panel") or self.name_summary_panel.isHidden(): return
        global_scope = self._global_table_scope()
        controller = None if global_scope else self._table_action_controller("Cannot summarize message table", report_unavailable=False)
        config = self._selected_config()
        if not global_scope and (controller is None or config is None or not callable(getattr(controller, "request", None))): return
        session_id = "__global__" if global_scope else config["id"]
        operation = self._summarize_global_tables if global_scope else lambda: controller.request("name_summary", {})
        self._run_async(
            operation,
            lambda result, selected_id=session_id: self._show_name_summary(result, selected_id),
            quiet=not force,
        )

    def _show_name_summary(self, result, session_id=None):
        if not self._ui_attached or self.tabs.currentWidget() is not self.table_tab:
            return
        selected = self._selected_config()
        if session_id == "__global__" and not self._global_table_scope(): return
        if session_id not in {None, "__global__"} and (selected is None or selected.get("id") != session_id or self._global_table_scope()): return
        rows = result.get("rows", []) if isinstance(result, dict) else []
        self._last_name_summary_version = int(result.get("version", -1)) if isinstance(result, dict) else -1
        self.name_summary_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = [
                row.get("name", "Unknown"), int(row.get("message_count", 0) or 0),
                _local_timestamp_text(row.get("last_timestamp", "")),
            ]
            for column, value in enumerate(values):
                item = QtWidgets.QTableWidgetItem(str(value))
                if column == 1: item.setTextAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
                self.name_summary_table.setItem(row_index, column, item)
        self.name_summary_label.setText(
            f"{len(rows):,} message name{'s' if len(rows) != 1 else ''} · totals include update-on-conflict occurrences"
            if rows else "No recorded message names"
        )

    def _export_message_table_excel(self):
        try:
            query = self._query()
        except (TypeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Cannot export message table", str(error)); return

        if self._global_table_scope():
            available = self._available_table_controllers()
            if not available:
                QtWidgets.QMessageBox.information(
                    self, "Cannot export message table", "No running or retained session tables are available."
                ); return
            source_specs = [(copy.deepcopy(config), controller) for config, controller in available]
            scope_label = f"Global table — {len(source_specs)} session(s)"
            base_name = "communication_hub_global"
        else:
            config = self._selected_config()
            controller = self._table_action_controller("Cannot export message table", report_unavailable=True)
            if config is None or controller is None: return
            source_specs = [(copy.deepcopy(config), controller)]
            scope_label = f"Session: {config.get('name', 'Unnamed')} ({self._protocol_title(config.get('protocol', ''))})"
            base_name = str(config.get("name", "communication_hub"))

        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", base_name).strip("_") or "communication_hub"
        export_directory = Path(self.config.get("message_export_directory") or (Path(PROJECT_ROOT) / "exports"))
        suggested = export_directory / f"{safe_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        path, _selected_filter = QtWidgets.QFileDialog.getSaveFileName(
            self, "Export Current Message Table", str(suggested), "Excel Workbook (*.xlsx)"
        )
        if not path: return
        destination = Path(path)
        if destination.suffix.casefold() != ".xlsx": destination = destination.with_suffix(".xlsx")
        self.config["message_export_directory"] = str(destination.parent)
        self._save()
        self.export_excel_button.setEnabled(False)
        self.status_label.setText("Exporting the complete filtered message table to Excel…")

        def operation():
            sources = []
            for source_config, source_controller in source_specs:
                sources.append({
                    "session_name": str(source_config.get("name", "Unnamed")),
                    "session_id": str(source_config.get("id", "")),
                    "protocol": str(source_config.get("protocol", "")),
                    "frame": source_controller.table_snapshot(),
                })
            return export_messages_excel(destination, sources, query, scope_label)

        call = self._run_async(
            operation, self._message_table_exported, quiet=True,
            failure=self._message_table_export_failed,
        )
        call.finished.connect(lambda: self.export_excel_button.setEnabled(True))

    def _message_table_exported(self, result):
        rows = int(result.get("rows", 0) or 0)
        path = str(result.get("path", ""))
        self.status_label.setText(f"Exported {rows:,} message rows to {path}")
        QtWidgets.QMessageBox.information(
            self, "Message table exported",
            f"Exported {rows:,} matching message rows.\n\n{path}",
        )

    def _message_table_export_failed(self, error):
        self.status_label.setText("Message table Excel export failed")
        QtWidgets.QMessageBox.critical(self, "Message table export failed", str(error))

    def _refresh_message_views_after_delete(self, _result=None):
        self._refresh_table(reset=True)
        self._refresh_name_summary(force=True)

    def _global_delete_preview(self, query):
        previews = []
        for config, controller in self._available_table_controllers():
            result = controller.request("delete_preview", {"query": query})
            previews.append({"session_id": config["id"], "count": int(result.get("count", 0) or 0)})
        return {"count": sum(item["count"] for item in previews), "sessions": previews}

    def _global_delete(self, query):
        deleted = 0
        for _config, controller in self._available_table_controllers():
            result = controller.request("delete", {"query": query})
            deleted += int(result.get("deleted", 0) or 0)
        return {"deleted": deleted}

    def _open_message_detail(self, row, _column=0):
        if row < 0 or row >= len(self._displayed_message_rows):
            return
        MessageDetailDialog(self._displayed_message_rows[row], self).exec_()

    def _delete_matching(self):
        global_scope = self._global_table_scope()
        controller = None if global_scope else self._table_action_controller("Cannot delete messages")
        if not global_scope and controller is None: return
        try: query = self._query()
        except (TypeError, ValueError) as error:
            QtWidgets.QMessageBox.warning(self, "Invalid query", str(error)); return
        def previewed(preview):
            if not preview["count"]: QtWidgets.QMessageBox.information(self, "Delete", "No rows match the query."); return
            if QtWidgets.QMessageBox.question(self, "Delete matching rows", f"Delete {preview['count']} matching rows?", QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No) == QtWidgets.QMessageBox.Yes:
                # The session may receive data while the confirmation dialog is open. Delete
                # against the current table so normal live traffic cannot invalidate the action.
                delete_operation = (
                    (lambda: self._global_delete(query)) if global_scope
                    else (lambda: controller.request("delete", {"query": query}))
                )
                self._run_async(delete_operation, self._refresh_message_views_after_delete)
        operation = (
            (lambda: self._global_delete_preview(query)) if global_scope
            else (lambda: controller.request("delete_preview", {"query": query}))
        )
        self._run_async(operation, previewed)

    def _delete_all(self):
        global_scope = self._global_table_scope()
        controller = None if global_scope else self._table_action_controller("Cannot delete messages")
        if not global_scope and controller is None: return

        def previewed(preview):
            count = int(preview.get("count", 0) or 0)
            if not count:
                scope_text = "combined global tables are" if global_scope else "selected session's message table is"
                QtWidgets.QMessageBox.information(self, "Delete all rows", f"The {scope_text} already empty.")
                return
            answer = QtWidgets.QMessageBox.question(
                self,
                "Delete all message rows?",
                f"Permanently delete all {count:,} rows from {'all combined session tables' if global_scope else 'the selected session table'}?\n\n"
                "This cannot be undone.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No,
            )
            if answer == QtWidgets.QMessageBox.Yes:
                self._run_async(
                    # New RX/TX rows can arrive during confirmation; deleting the current
                    # contents is the expected meaning of Delete All for a live table.
                    (lambda: self._global_delete({})) if global_scope else (lambda: controller.request("delete", {"query": {}})),
                    self._refresh_message_views_after_delete,
                )

        operation = (
            (lambda: self._global_delete_preview({})) if global_scope
            else (lambda: controller.request("delete_preview", {"query": {}}))
        )
        self._run_async(operation, previewed)

    def _previous_page(self): self.page = max(0, self.page - 1); self._refresh_table()
    def _next_page(self): self.page += 1; self._refresh_table()

    def _session_selected(self, row):
        session_id = None
        if 0 <= row < len(self.config.get("sessions", [])):
            session_id = self.config["sessions"][row]["id"]
            combo_index = self.send_session_combo.findData(session_id)
            if combo_index >= 0 and self.send_session_combo.currentIndex() != combo_index:
                self.send_session_combo.blockSignals(True); self.send_session_combo.setCurrentIndex(combo_index); self.send_session_combo.blockSignals(False)
            self._update_send_routing()
            if self._query_state_ready and not self._global_table_scope():
                self._restore_query_ui_state(session_id)
        session_changed = bool(session_id and session_id != self._table_session_id)
        if session_id: self._table_session_id = session_id
        self._clear_displayed_message_views()
        self._update_table_session_indicator(loading=True)
        self.page = 0; self._last_name_summary_version = -1
        self._poll_status(); self._refresh_table(reset=True); self._refresh_name_summary(force=True)
        controller = self._selected_controller()
        table_available = (
            bool(self._available_table_controllers()) if self._global_table_scope()
            else bool(controller and getattr(controller, "table_available", controller.running))
        )
        if session_changed:
            self._flash_table_session_indicator(loading=table_available)
        elif not self.table_session_indicator_timer.isActive():
            self._update_table_session_indicator(loading=table_available)
        if hasattr(self, "insight_panel") and self.insight_panel.isVisible():
            self.insight_panel.refresh()

    def _poll_status(self):
        if not self._ui_attached:
            return
        if self._global_table_scope() and self.tabs.currentWidget() is self.table_tab:
            if any(call.isRunning() for call in self._calls): return
            if self.auto_refresh.isChecked():
                self._refresh_table()
                self._refresh_name_summary()
            return
        if self.tabs.currentWidget() is not self.monitor_tab:
            return
        config = self._selected_config()
        if config and config.get("id") in self._session_operations: return
        controller = self._selected_controller()
        if not controller or not bool(getattr(controller, "table_available", controller.running)): return
        if any(call.isRunning() for call in self._calls): return
        session_id = config.get("id") if config else None
        self._run_async(
            controller.status,
            lambda result, selected_id=session_id: self._display_session_status(selected_id, result),
            quiet=True,
        )

    def _display_status(self, result):
        state = str(result.get("state", "unknown"))
        status_message = str(result.get("status_message", "") or "")
        state_title = state.replace("_", " ").title()
        self.status_label.setText(f"{state_title} | {status_message}" if status_message else state_title)
        foreground, background = {
            "connected": ("#1b5e20", "#e8f5e9"),
            "listening": ("#1b5e20", "#e8f5e9"),
            "connecting": ("#174ea6", "#e8f0fe"),
            "reconnecting": ("#8a4b08", "#fff4df"),
            "error": ("#a12622", "#fff0ef"),
            "stopped": ("#4b5563", "#eef0f2"),
        }.get(state.casefold(), ("#374151", "#eef0f2"))
        self.status_label.setStyleSheet(
            f"font-weight: 600; color: {foreground}; background: {background}; "
            "padding: 4px 8px; border-radius: 3px;"
        )
        for key in (
            "rx", "tx", "rows", "parser_errors",
            "protocol_insight_records_published",
        ):
            self.activity_values[key].setText(f"{int(result.get(key, 0) or 0):,}")
        rows = int(result.get("rows", 0) or 0)
        parsed = int(result.get("parsed", 0) or 0)
        parsed_percent = (parsed / rows * 100.0) if rows else 0.0
        self.activity_summary.setText(
            f"Parsed: {parsed:,} of {rows:,} ({parsed_percent:.1f}%)   |   "
            f"Memory: {self._format_byte_count(result.get('memory_bytes', 0))}   |   "
            f"Table version: {int(result.get('version', 0) or 0):,}   |   "
            f"Insight IPC dropped: {int(result.get('protocol_insight_records_dropped', 0) or 0):,}"
            + (
                f" ({int(result.get('protocol_insight_publish_errors', 0) or 0):,} errors)"
                if int(result.get("protocol_insight_publish_errors", 0) or 0) else ""
            )
            + (
                f"   |   Processing queue: {int(result.get('processing_queue_depth', result.get('capture_queue_depth', 0)) or 0):,}"
                f"/{int(result.get('processing_queue_capacity', result.get('capture_queue_capacity', 0)) or 0):,}"
                f"   |   Capture dropped: {int(result.get('capture_dropped', 0) or 0):,}"
            )
        )
        errors = []
        last_error = str(result.get("last_error", "") or "").strip()
        persistence_error = str(result.get("persistence_last_error", "") or "").strip()
        processing_error = str(result.get("processing_last_error", "") or "").strip()
        overload_error = str(result.get("capture_last_overload_error", "") or "").strip()
        transport_error = str(result.get("transport_last_error", "") or "").strip()
        if last_error:
            errors.append(f"Worker error: {last_error}")
        if persistence_error:
            errors.append(f"Persistence error: {persistence_error}")
        if processing_error:
            errors.append(f"Data-processing error: {processing_error}")
        if overload_error:
            errors.append(f"Capture overload: {overload_error}")
        if transport_error:
            occurred = str(result.get("transport_last_error_at", "") or "").strip()
            suffix = f" ({occurred})" if occurred else ""
            errors.append(f"Transport error{suffix}: {transport_error}")
        self.activity_error.setText("\n".join(errors))
        self.activity_error.setVisible(bool(errors))
        self._activity_session_id = result.get("session_id", getattr(self, "_activity_session_id", None))
        self._set_metrics_text_preserving_view(json.dumps(result, indent=2, ensure_ascii=False))
        version = int(result.get("version", -1))
        if self.auto_refresh.isChecked() and self.tabs.currentWidget() is self.table_tab and version != self._last_table_version:
            self._last_table_version = version
            self._refresh_table()
        if (
            self.tabs.currentWidget() is self.table_tab
            and self.name_summary_panel.isVisible()
            and version != self._last_name_summary_version
        ):
            self._refresh_name_summary()
    def _run_async(self, function, success=None, quiet=False, failure=None):
        call = _AsyncCall(function, self); self._calls.add(call)
        if success: call.succeeded.connect(success)
        if failure: call.failed.connect(failure)
        if not quiet: call.failed.connect(self._show_async_error)
        call.finished.connect(lambda: self._calls.discard(call)); call.finished.connect(call.deleteLater); call.start()
        return call

    def _show_async_error(self, error):
        text = str(error)
        stopping = any(operation == "stopping" for operation in self._session_operations.values())
        expected_close_markers = (
            "BrokenPipeError", "ConnectionResetError", "ConnectionAbortedError",
            "EOFError", "[WinError 109]", "[WinError 232]", "handle is closed",
        )
        if (self._shutting_down or stopping) and any(marker in text for marker in expected_close_markers):
            # Queries, status refreshes, and a just-completed periodic dispatch can
            # still be returning while an intentional stop closes the socket/IPC
            # pipe. Their failure is expected and must not produce a modal dialog.
            return
        QtWidgets.QMessageBox.critical(self, "Communication Hub", text)

    def _apply_protocol_insight_to_sessions(self, runtime_config, sessions):
        sessions = [session for session in sessions if isinstance(session, dict)]
        if not sessions:
            return False
        runtime_id = str(runtime_config.get("id", ""))
        def still_active():
            return any(
                str(item.get("dataset", {}).get("id", "")) == runtime_id
                and item.get("dataset", {}).get("runtime", {}).get("active", False)
                for item in self.config.get("protocol_insights", [])
                if isinstance(item, dict)
            )
        running_session_ids = []
        for session in sessions:
            session_id = str(session.get("id", ""))
            controller = self.controllers.get(session_id)
            if controller and controller.running:
                running_session_ids.append(session_id)
                self._set_protocol_insight_session_state(
                    runtime_id, session_id, "starting", "Connecting to isolated Insight service",
                )

        def install():
            if not still_active():
                return {
                    "result": None, "replayed_records": 0,
                    "publisher_ready": [], "publisher_failures": [],
                    "cancelled": True,
                }
            config = copy.deepcopy(runtime_config)
            result = self._protocol_insight_service_request(
                "upsert", {"config": config}, timeout=30
            )
            collection = config.get("insights", {}).get("source", {}).get(
                "collection", {}
            )
            replayed = 0
            if collection.get("start_position") == "retained_then_new":
                records = []
                for session in sessions:
                    controller = self.controllers.get(str(session.get("id", "")))
                    if controller is None or not controller.table_available:
                        continue
                    frame = controller.table_snapshot(timeout=60)
                    rows = frame.to_dict(orient="records")
                    for row in rows:
                        row.setdefault("session_name", str(session.get("name", "")))
                    records.extend(rows)
                if records:
                    replayed = int(self._protocol_insight_service_request(
                        "replay", {
                            "protocol_insight_id": runtime_id,
                            "records": records,
                        }, timeout=120,
                    ) or 0)
            # Stop may have been selected while recovery/upsert was in flight.
            # Delete the just-created runtime before connecting publishers so
            # an asynchronous Start can never outlive a later Stop command.
            if not still_active():
                self._protocol_insight_service_request(
                    "delete", {"protocol_insight_id": runtime_id}, timeout=120
                )
                return {
                    "result": result, "replayed_records": replayed,
                    "publisher_ready": [], "publisher_failures": [],
                    "cancelled": True,
                }
            # Connect live publishers only after the runtime and any retained
            # recovery are ready. This prevents the first live burst from
            # arriving before the new insight exists.
            publisher_ready = []
            publisher_failures = []
            for session in sessions:
                session_id = str(session.get("id", ""))
                controller = self.controllers.get(session_id)
                if controller is not None and controller.running:
                    try:
                        controller.request(
                            "protocol_insight_publisher", {"enabled": True}
                        )
                        publisher_ready.append(session_id)
                    except (BrokenPipeError, ConnectionError, EOFError, OSError) as error:
                        publisher_failures.append((
                            session_id,
                            "Session stopped while its Insight publisher was connecting",
                        ))
                    except BaseException as error:
                        publisher_failures.append((
                            session_id, self._protocol_insight_error_text(error),
                        ))
            return {
                "result": result,
                "replayed_records": replayed,
                "publisher_ready": publisher_ready,
                "publisher_failures": publisher_failures,
            }

        def installed(result):
            if result.get("cancelled") or not still_active():
                return
            ready_ids = result.get("publisher_ready", [])
            self._mark_protocol_insight_sessions_ready(runtime_id, ready_ids)
            for session_id, detail in result.get("publisher_failures", []):
                self._set_protocol_insight_session_state(
                    runtime_id, session_id, "error", detail,
                )
            self.insight_panel.refresh()

        self._run_async(
            install,
            installed,
            quiet=True,
            failure=lambda error, rid=runtime_id, ids=tuple(running_session_ids): [
                self._protocol_insight_registration_failed(rid, sid, error)
                for sid in ids
            ],
        )
        return True

    def _autostart(self):
        for config in self.config.get("sessions", []):
            restore_previous = str(config.get("id", "")) in (
                self._session_restore_ids | self._session_detached_restore_ids
            )
            if (
                (config.get("autostart") or restore_previous)
                and config.get("id") not in self._persisted_table_loads
                and (
                    self._ui_attached
                    or self._session_runs_in_background(config)
                )
            ):
                self._start_session_config(config, quiet=True)
                self._session_restore_ids.discard(str(config.get("id", "")))
                self._session_detached_restore_ids.discard(str(config.get("id", "")))
        self._autostart_protocol_insights()

    def _autostart_protocol_insights(self):
        changed = False
        for view in self.config.get("protocol_insights", []):
            if not isinstance(view, dict):
                continue
            restore_previous = str(view.get("id", "")) in (
                self._protocol_insight_restore_ids
                | self._protocol_insight_detached_restore_ids
            )
            if not view.get("autostart", False) and not restore_previous:
                continue
            dataset = view.get("dataset", {}) if isinstance(view.get("dataset"), dict) else {}
            runtime = dataset.setdefault("runtime", {})
            if runtime.get("active", False):
                continue
            sessions = self._protocol_insight_sessions(view)
            try:
                monitor = self._protocol_insight_runtime_config(view)
            except BaseException as error:
                if self._ui_attached and self.insight_panel._view().get("id") == view.get("id"):
                    self.insight_panel.dataset_editor.set_runtime_state(
                        "error", self._protocol_insight_error_text(error)
                    )
                continue
            if not sessions or not monitor.get("series"):
                if self._ui_attached and self.insight_panel._view().get("id") == view.get("id"):
                    detail = (
                        "Autostart needs at least one source session"
                        if not sessions else "Autostart needs at least one configured series"
                    )
                    self.insight_panel.dataset_editor.set_runtime_state("error", detail)
                continue
            dataset["enabled"] = True
            runtime["active"] = True
            runtime["paused"] = False
            runtime["last_active_on_close"] = True
            monitor["enabled"] = True
            changed = True
            if self._ui_attached and self.insight_panel._view().get("id") == view.get("id"):
                self.insight_panel.dataset_editor.set_collection_runtime_state(
                    active=True, paused=False
                )
                self.insight_panel.dataset_editor.set_runtime_state(
                    "starting", (
                        "Restoring the previous running state"
                        if restore_previous else "Starting automatically"
                    )
                )
                self.insight_panel.start_runtime_frontend(view.get("id"))
            self._apply_protocol_insight_to_sessions(monitor, sessions)
        if changed:
            self._save()
        self._protocol_insight_restore_ids.clear()
        self._protocol_insight_detached_restore_ids.clear()

    def _restore_persisted_tables_then_autostart(self):
        persistent = [
            config for config in self.config.get("sessions", [])
            if config.get("persistence", {}).get("enabled")
        ]
        for config in persistent:
            session_id = config["id"]
            controller = self._controller_for_config(config)
            self._persisted_table_loads.add(session_id)
            self._show_session_operation(session_id, "loading snapshot")
            call = self._run_async(
                controller.load_latest_persisted_table,
                lambda result, selected_id=session_id: self._persisted_table_loaded(selected_id, result),
            )
            call.finished.connect(
                lambda selected_id=session_id: self._persisted_table_load_finished(selected_id)
            )
        self._autostart()

    def _persisted_table_loaded(self, session_id, result):
        if not result.get("loaded") or not self._ui_attached:
            return
        selected = self._selected_config()
        if selected and selected.get("id") == session_id:
            self.status_label.setText(
                f"Loaded {int(result.get('rows', 0)):,} saved rows · session remains stopped"
            )
            self._refresh_table(reset=True)
            self._refresh_name_summary(force=True)

    def _persisted_table_load_finished(self, session_id):
        self._persisted_table_loads.discard(session_id)
        self._finish_session_operation(session_id)
        config = self._config_by_id(session_id)
        if (
            config
            and (
                config.get("autostart")
                or str(config.get("id", "")) in (
                    self._session_restore_ids | self._session_detached_restore_ids
                )
            )
            and (
                self._ui_attached
                or self._session_runs_in_background(config)
            )
        ):
            self._start_session_config(config, quiet=True)
            self._session_restore_ids.discard(str(config.get("id", "")))
            self._session_detached_restore_ids.discard(str(config.get("id", "")))

    def shutdown(self):
        if self._ui_attached:
            self._remember_protocol_insight_close_state()
        self._remember_session_close_state()
        self._shutting_down = True
        self._ui_attached = False
        self.timer.stop()
        if hasattr(self, "periodic_timer"): self.periodic_timer.stop()
        if hasattr(self, "insight_panel"): self.insight_panel.shutdown()
        for insight in self.config.get("protocol_insights", []):
            dataset = insight.get("dataset", {}) if isinstance(insight, dict) else {}
            dataset.setdefault("runtime", {})["active"] = False
            dataset["runtime"]["paused"] = False
        self._save_query_ui_state()
        try: self._save()
        except BaseException: pass
        for controller in list(self.controllers.values()): controller.stop()
        self.protocol_insight_service.stop()

    def _remember_protocol_insight_close_state(self):
        """Persist intent before orderly shutdown changes process state."""
        for insight in self.config.get("protocol_insights", []):
            if not isinstance(insight, dict):
                continue
            dataset = insight.get("dataset", {})
            if not isinstance(dataset, dict):
                continue
            runtime = dataset.setdefault("runtime", {})
            runtime["last_active_on_close"] = bool(runtime.get("active", False))

    def _remember_session_close_state(self):
        """Persist running intent before window-owned workers are stopped."""
        for session in self.config.get("sessions", []):
            if not isinstance(session, dict):
                continue
            session_id = str(session.get("id", ""))
            controller = self.controllers.get(session_id)
            running = bool(controller and controller.running)
            if not self._ui_attached and session_id in self._session_detached_restore_ids:
                running = True
            session.setdefault("lifecycle", {})["last_running_on_close"] = running

    def prepare_application_shutdown(self):
        """Make the next close terminal even when the Hub is currently hidden."""
        self._application_shutdown_requested = True

    def _stop_window_lifetime_sessions(self):
        for config in self.config.get("sessions", []):
            if self._session_runs_in_background(config):
                continue
            session_id = config["id"]
            controller = self.controllers.get(session_id)
            if (
                controller is None
                or not controller.running
                or session_id in self._session_operations
            ):
                continue
            self._window_detach_stops.add(session_id)
            self._session_operations[session_id] = "stopping"
            self._finish_window_detach_stop(session_id, controller)

    def _stop_window_lifetime_protocol_insights(self):
        stopped_runtime_ids = []
        for view in self.config.get("protocol_insights", []):
            if self._protocol_insight_runs_in_background(view):
                continue
            dataset = view.get("dataset", {}) if isinstance(view, dict) else {}
            runtime = dataset.setdefault("runtime", {})
            if not runtime.get("active", False):
                continue
            runtime["active"] = False
            runtime["paused"] = False
            runtime_id = str(dataset.get("id", ""))
            if runtime_id:
                stopped_runtime_ids.append(runtime_id)
            if hasattr(self, "insight_panel"):
                self.insight_panel.stop_runtime_frontend(view.get("id"))
        if not stopped_runtime_ids:
            return
        for session in self.config.get("sessions", []):
            self._sync_protocol_insights_for_session(str(session.get("id", "")))
        if self.protocol_insight_service.running:
            for runtime_id in stopped_runtime_ids:
                self._run_async(
                    lambda selected_id=runtime_id: self._protocol_insight_service_request(
                        "delete", {"protocol_insight_id": selected_id}, timeout=120
                    ),
                    quiet=True,
                )

    def _finish_window_detach_stop(self, session_id, controller):
        inflight = any(
            entry.get("session_id") == session_id
            and entry.get("id") in self._periodic_inflight
            for entry in self.config.get("periodic_messages", [])
            if isinstance(entry, dict)
        )
        if inflight:
            QtCore.QTimer.singleShot(
                50,
                lambda selected_id=session_id, selected_controller=controller:
                self._finish_window_detach_stop(selected_id, selected_controller),
            )
            return
        call = self._run_async(controller.stop, quiet=True)
        call.finished.connect(
            lambda selected_id=session_id:
            self._window_detach_stop_finished(selected_id)
        )

    def _window_detach_stop_finished(self, session_id):
        self._window_detach_stops.discard(session_id)
        self._session_operations.pop(session_id, None)
        config = self._config_by_id(session_id)
        if self._ui_attached and config and (
            config.get("autostart")
            or session_id in self._session_detached_restore_ids
        ):
            self._start_session_config(config, quiet=True)
        elif self._ui_attached:
            self._reload_sessions()

    def detach_ui(self):
        """Suspend frontend work while application-lifetime sessions continue."""
        if not self._ui_attached:
            return
        self._session_detached_restore_ids = {
            str(session.get("id", ""))
            for session in self.config.get("sessions", [])
            if isinstance(session, dict)
            and session.get("lifecycle", {}).get("restore_last_state", True)
            and bool(
                (controller := self.controllers.get(str(session.get("id", ""))))
                and controller.running
            )
        }
        self._remember_session_close_state()
        self._protocol_insight_detached_restore_ids = {
            str(insight.get("id", ""))
            for insight in self.config.get("protocol_insights", [])
            if isinstance(insight, dict)
            and insight.get("lifecycle", {}).get("restore_last_state", True)
            and insight.get("dataset", {}).get("runtime", {}).get("active", False)
        }
        self._remember_protocol_insight_close_state()
        self._stop_window_lifetime_protocol_insights()
        self._save_query_ui_state()
        try:
            self._save()
        except BaseException:
            pass
        self._ui_attached = False
        self.timer.stop()
        if hasattr(self, "insight_panel"):
            self.insight_panel.suspend()
        self._stop_window_lifetime_sessions()

    def reattach_ui(self):
        """Resume frontend refreshes and synchronize tabs with retained workers."""
        if self._shutting_down:
            return
        self._ui_attached = True
        self.timer.start()
        if hasattr(self, "insight_panel"):
            self.insight_panel.resume()
        self._reload_sessions()
        self._autostart()
        self._last_table_version = -1
        self._last_name_summary_version = -1
        self._poll_status()
        self._refresh_table(reset=True)
        self._refresh_name_summary(force=True)
        if hasattr(self, "insight_panel"):
            self.insight_panel.refresh()

    def closeEvent(self, event):
        keep_runtime = any(
            self._session_runs_in_background(config)
            for config in self.config.get("sessions", [])
        )
        keep_runtime = keep_runtime or any(
            self._protocol_insight_runs_in_background(config)
            and config.get("dataset", {}).get("runtime", {}).get("active", False)
            for config in self.config.get("protocol_insights", [])
        )
        if (
            keep_runtime
            and not self._application_shutdown_requested
            and not self._shutting_down
        ):
            self.detach_ui()
            event.ignore()
            self.hide()
            return
        self.shutdown()
        super().closeEvent(event)
