"""Lazy, live variable inspection for application Globals and IDE namespaces.

The explorer deliberately treats inspected objects as untrusted.  Generic
objects are described from ``__dict__``/``__slots__`` only; properties and
methods are never invoked merely to render the UI.  Large containers are
paged and table-shaped values are exposed through Qt models rather than
materialized as one widget per cell.
"""

from __future__ import annotations

import ast
import array as _array
import copy
import dataclasses
import datetime as _datetime
import decimal
import enum
import fractions
import itertools
import pathlib
import sys
import time
import types
import uuid
from collections import OrderedDict, defaultdict, deque
from collections.abc import Mapping, Sequence, Set as AbstractSet
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd
from pandas.io.formats.style import Styler
from PyQt5 import QtCore, QtGui, QtWidgets

from app.runtime_globals import RuntimeGlobals


PAGE_SIZE = 200
HISTORY_LIMIT = 500
DEFAULT_REFRESH_MS = 750
MAX_PREVIEW = 160
MAX_REPR = 10_000
VALUE_ROLE = QtCore.Qt.UserRole + 20
PATH_ROLE = QtCore.Qt.UserRole + 21
SORT_ROLE = QtCore.Qt.UserRole + 22


class ExplorerError(RuntimeError):
    """Base error for safe explorer operations."""


class EditConflictError(ExplorerError):
    """Raised when a staged edit no longer targets its original value."""


@dataclass(frozen=True)
class PathStep:
    kind: str
    value: Any

    def display(self) -> str:
        if self.kind == "key":
            return f"[{safe_repr(self.value, 80)}]"
        if self.kind in {"index", "series_iat"}:
            return f"[{self.value}]"
        if self.kind in {"array_index", "df_iat"}:
            return "[" + ", ".join(str(v) for v in self.value) + "]"
        if self.kind == "df_col":
            return f".column[{self.value}]"
        if self.kind == "styler_data":
            return ".data"
        return f".{self.value}"


@dataclass(frozen=True)
class ValuePath:
    root: str
    steps: tuple[PathStep, ...] = ()

    def child(self, step: PathStep) -> "ValuePath":
        return ValuePath(self.root, self.steps + (step,))

    def display(self) -> str:
        return self.root + "".join(step.display() for step in self.steps)

    def key(self) -> str:
        return self.display()


@dataclass
class ChildSpec:
    name: str
    value: Any
    step: PathStep


@dataclass
class ChildPage:
    entries: list[ChildSpec]
    total: int
    error: str = ""


@dataclass
class ChangeRecord:
    timestamp: float
    path: str
    kind: str
    old_summary: str
    new_summary: str
    generation: int
    origin: str = "runtime"


@dataclass
class PendingEdit:
    path: ValuePath
    old_value: Any
    new_value: Any
    expected_fingerprint: Any
    error: str = ""


_SCALAR_TYPES = (
    str,
    bytes,
    bytearray,
    memoryview,
    bool,
    int,
    float,
    complex,
    type(None),
    decimal.Decimal,
    fractions.Fraction,
    _datetime.date,
    _datetime.time,
    _datetime.datetime,
    _datetime.timedelta,
    pathlib.PurePath,
    uuid.UUID,
    enum.Enum,
)


def _trusted_scalar(value: Any) -> bool:
    return (
        isinstance(value, _SCALAR_TYPES)
        or isinstance(value, np.generic)
        or isinstance(value, (pd.Timestamp, pd.Timedelta, pd.Period, pd.Interval))
        or value is pd.NA
        or value is pd.NaT
    )


def safe_repr(value: Any, limit: int = MAX_PREVIEW) -> str:
    """Return a bounded representation without calling arbitrary object reprs."""
    try:
        if _trusted_scalar(value):
            text = repr(value)
        elif isinstance(value, (list, tuple, dict, set, frozenset, deque, _array.array)):
            text = _container_preview(value)
        elif isinstance(value, np.ndarray):
            text = f"array(shape={value.shape}, dtype={value.dtype})"
        elif isinstance(value, pd.DataFrame):
            text = f"DataFrame(shape={value.shape})"
        elif isinstance(value, pd.Series):
            text = f"Series(len={len(value)}, dtype={value.dtype})"
        elif isinstance(value, (pd.Index, Styler)):
            text = f"{type(value).__name__}"
        else:
            cls = type(value)
            text = f"<{cls.__module__}.{cls.__qualname__} at 0x{id(value):x}>"
    except Exception as error:
        text = f"<unavailable: {type(error).__name__}>"
    if len(text) > limit:
        return text[: max(0, limit - 1)] + "…"
    return text


def _container_preview(value: Any) -> str:
    try:
        length = len(value)
    except Exception:
        length = "?"
    return f"{type(value).__name__}(len={length})"


def human_size(number: int | None) -> str:
    if number is None:
        return ""
    size = float(max(0, number))
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024.0 or unit == "TiB":
            return f"{size:.1f} {unit}"
        size /= 1024.0
    return ""


def _safe_len(value: Any) -> int | None:
    try:
        return len(value)
    except Exception:
        return None


def _safe_size(value: Any) -> int | None:
    try:
        if isinstance(value, np.ndarray):
            return int(value.nbytes)
        if isinstance(value, pd.DataFrame):
            # deep=True walks every Python object and can freeze the GUI for a
            # large object-dtype frame.  The explorer promises an estimate.
            return int(value.memory_usage(index=True, deep=False).sum())
        if isinstance(value, (pd.Series, pd.Index)):
            return int(value.memory_usage(deep=False))
        return int(sys.getsizeof(value))
    except Exception:
        return None


def value_info(value: Any) -> str:
    try:
        if isinstance(value, np.ndarray):
            return f"shape={value.shape}; dtype={value.dtype}"
        if isinstance(value, pd.DataFrame):
            return f"{value.shape[0]} rows × {value.shape[1]} columns"
        if isinstance(value, pd.Series):
            return f"len={len(value)}; dtype={value.dtype}"
        if isinstance(value, pd.Index):
            return f"len={len(value)}; dtype={value.dtype}"
        length = _safe_len(value)
        return f"len={length}" if length is not None else ""
    except Exception as error:
        return f"unavailable ({type(error).__name__})"


def value_summary(value: Any) -> str:
    return safe_repr(value, MAX_PREVIEW)


def _sample_sequence(value: Any, maximum: int = 16) -> tuple[Any, ...]:
    length = _safe_len(value) or 0
    if not length:
        return ()
    indexes = list(range(min(length, maximum)))
    if length > maximum:
        indexes.append(length - 1)
    sampled = []
    for index in indexes:
        try:
            sampled.append(value[index])
        except Exception as error:
            sampled.append(("error", type(error).__name__))
    return tuple(sampled)


def value_fingerprint(value: Any, _seen: set[int] | None = None) -> Any:
    """Return a bounded, type-aware fingerprint suitable for live sampling."""
    if _seen is None:
        _seen = set()
    if not _trusted_scalar(value):
        value_id = id(value)
        if value_id in _seen:
            return (type(value), value_id, "cycle")
        _seen.add(value_id)
    try:
        if _trusted_scalar(value):
            if isinstance(value, float) and np.isnan(value):
                return (type(value).__name__, "nan")
            if isinstance(value, np.generic):
                return ("numpy-scalar", str(value.dtype), safe_repr(value, 120))
            return (type(value), safe_repr(value, 240))
        if isinstance(value, np.ndarray):
            flattened = value.reshape(-1) if value.size else value
            samples = _sample_sequence(flattened, 12)
            return (
                "ndarray", id(value), value.shape, str(value.dtype), int(value.nbytes),
                tuple(safe_repr(item, 80) for item in samples),
            )
        if isinstance(value, pd.DataFrame):
            rows, cols = value.shape
            samples = []
            for row in sorted(set(range(min(rows, 3))) | ({rows - 1} if rows else set())):
                for col in sorted(set(range(min(cols, 3))) | ({cols - 1} if cols else set())):
                    try:
                        samples.append((row, col, safe_repr(value.iat[row, col], 60)))
                    except Exception as error:
                        samples.append((row, col, type(error).__name__))
            return (
                "dataframe", id(value), value.shape,
                tuple(str(dtype) for dtype in value.dtypes), tuple(samples),
            )
        if isinstance(value, pd.Series):
            sample_positions = list(range(min(len(value), 12)))
            if len(value) > 12:
                sample_positions.append(len(value) - 1)
            samples = tuple(value.iloc[pos] for pos in sample_positions)
            return (
                "series", id(value), len(value), str(value.dtype),
                tuple(safe_repr(item, 60) for item in samples),
            )
        if isinstance(value, Mapping):
            try:
                keys = list(itertools.islice(value.keys(), 16))
                return (
                    type(value), id(value), len(value),
                    tuple(safe_repr(key, 60) for key in keys),
                )
            except Exception as error:
                return (type(value), id(value), "unstable", type(error).__name__)
        if isinstance(value, (list, tuple, deque, _array.array)):
            return (
                type(value), id(value), _safe_len(value),
                tuple(value_fingerprint(item, _seen) for item in _sample_sequence(value, 8)),
            )
        if isinstance(value, (set, frozenset)):
            try:
                samples = sorted(safe_repr(v, 50) for v in itertools.islice(value, 12))
            except Exception as error:
                samples = [type(error).__name__]
            return (type(value), id(value), _safe_len(value), tuple(samples))
        attrs = safe_attributes(value)
        if attrs is not None:
            return (type(value), id(value), tuple(attrs.keys()))
        return (type(value), id(value))
    except Exception as error:
        return (type(value), id(value), "error", type(error).__name__)


def safe_attributes(value: Any) -> OrderedDict[str, Any] | None:
    """Read stored attributes only; never walk ``dir`` or evaluate properties."""
    if isinstance(value, (QtCore.QObject, types.ModuleType)) or callable(value):
        return None
    result: OrderedDict[str, Any] = OrderedDict()
    try:
        namespace = vars(value)
    except Exception:
        namespace = None
    if isinstance(namespace, dict):
        for name, item in namespace.items():
            if not str(name).startswith("_"):
                result[str(name)] = item
    slots = getattr(type(value), "__slots__", ())
    if isinstance(slots, str):
        slots = (slots,)
    for name in slots:
        if name in result or str(name).startswith("_"):
            continue
        try:
            result[str(name)] = object.__getattribute__(value, name)
        except Exception:
            continue
    return result or None


class ValueAdapter:
    name = "value"

    def matches(self, value: Any) -> bool:
        return False

    def child_count(self, value: Any) -> int:
        return 0

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        return ChildPage([], self.child_count(value))

    def preview(self, value: Any) -> str:
        return value_summary(value)

    def info(self, value: Any) -> str:
        return value_info(value)

    def size(self, value: Any) -> str:
        return human_size(_safe_size(value))


class ScalarAdapter(ValueAdapter):
    name = "scalar"

    def matches(self, value: Any) -> bool:
        return _trusted_scalar(value)


class NumpyAdapter(ValueAdapter):
    name = "numpy"

    def matches(self, value: Any) -> bool:
        return isinstance(value, (np.ndarray, np.generic))

    def child_count(self, value: Any) -> int:
        if not isinstance(value, np.ndarray):
            return 0
        return 1 if value.ndim == 0 else int(value.shape[0])

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        total = self.child_count(value)
        entries: list[ChildSpec] = []
        try:
            if value.ndim == 0 and offset == 0:
                entries.append(ChildSpec("[()]", value[()], PathStep("array_index", ())))
            elif value.ndim:
                stop = min(total, offset + limit)
                for index in range(offset, stop):
                    entries.append(
                        ChildSpec(f"[{index}]", value[index], PathStep("index", index))
                    )
        except Exception as error:
            return ChildPage(entries, total, f"{type(error).__name__}: {error}")
        return ChildPage(entries, total)


class PandasAdapter(ValueAdapter):
    name = "pandas"

    def matches(self, value: Any) -> bool:
        return isinstance(value, (pd.DataFrame, pd.Series, pd.Index, Styler))

    def child_count(self, value: Any) -> int:
        if isinstance(value, Styler):
            return 1
        if isinstance(value, pd.DataFrame):
            return int(value.shape[1])
        return len(value)

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        total = self.child_count(value)
        entries: list[ChildSpec] = []
        try:
            if isinstance(value, Styler):
                if offset == 0:
                    entries.append(
                        ChildSpec("data", value.data, PathStep("styler_data", None))
                    )
            elif isinstance(value, pd.DataFrame):
                for pos in range(offset, min(total, offset + limit)):
                    label = value.columns[pos]
                    entries.append(
                        ChildSpec(
                            f"[{pos}] {safe_repr(label, 80)}",
                            value.iloc[:, pos],
                            PathStep("df_col", pos),
                        )
                    )
            elif isinstance(value, pd.Series):
                for pos in range(offset, min(total, offset + limit)):
                    label = value.index[pos]
                    entries.append(
                        ChildSpec(
                            f"[{pos}] {safe_repr(label, 80)}",
                            value.iloc[pos],
                            PathStep("series_iat", pos),
                        )
                    )
            else:
                for pos in range(offset, min(total, offset + limit)):
                    entries.append(
                        ChildSpec(f"[{pos}]", value[pos], PathStep("index", pos))
                    )
        except Exception as error:
            return ChildPage(entries, total, f"{type(error).__name__}: {error}")
        return ChildPage(entries, total)


class MappingAdapter(ValueAdapter):
    name = "mapping"

    def matches(self, value: Any) -> bool:
        return isinstance(value, Mapping)

    def child_count(self, value: Any) -> int:
        return len(value)

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        total = self.child_count(value)
        entries: list[ChildSpec] = []
        try:
            iterator = itertools.islice(value.items(), offset, offset + limit)
            for key, item in iterator:
                entries.append(
                    ChildSpec(
                        key if isinstance(key, str) else safe_repr(key, 100),
                        item,
                        PathStep("key", key),
                    )
                )
        except Exception as error:
            return ChildPage(entries, total, f"{type(error).__name__}: {error}")
        return ChildPage(entries, total)


class DataclassAdapter(ValueAdapter):
    name = "dataclass"

    def matches(self, value: Any) -> bool:
        return dataclasses.is_dataclass(value) and not isinstance(value, type)

    def child_count(self, value: Any) -> int:
        return len(dataclasses.fields(value))

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        fields = dataclasses.fields(value)
        entries = []
        try:
            for definition in fields[offset : offset + limit]:
                entries.append(
                    ChildSpec(
                        definition.name,
                        object.__getattribute__(value, definition.name),
                        PathStep("attr", definition.name),
                    )
                )
        except Exception as error:
            return ChildPage(entries, len(fields), f"{type(error).__name__}: {error}")
        return ChildPage(entries, len(fields))


class NamedTupleAdapter(ValueAdapter):
    name = "namedtuple"

    def matches(self, value: Any) -> bool:
        return isinstance(value, tuple) and hasattr(type(value), "_fields")

    def child_count(self, value: Any) -> int:
        return len(value)

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        fields = tuple(getattr(type(value), "_fields", ()))
        entries = []
        for pos in range(offset, min(len(value), offset + limit)):
            entries.append(
                ChildSpec(fields[pos], value[pos], PathStep("attr", fields[pos]))
            )
        return ChildPage(entries, len(value))


class SequenceAdapter(ValueAdapter):
    name = "sequence"

    def matches(self, value: Any) -> bool:
        return isinstance(value, (list, tuple, deque, range, _array.array))

    def child_count(self, value: Any) -> int:
        return len(value)

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        total = len(value)
        entries: list[ChildSpec] = []
        try:
            for pos in range(offset, min(total, offset + limit)):
                entries.append(
                    ChildSpec(f"[{pos}]", value[pos], PathStep("index", pos))
                )
        except Exception as error:
            return ChildPage(entries, total, f"{type(error).__name__}: {error}")
        return ChildPage(entries, total)


class SetAdapter(ValueAdapter):
    name = "set"

    def matches(self, value: Any) -> bool:
        return isinstance(value, (set, frozenset))

    def child_count(self, value: Any) -> int:
        return len(value)

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        total = len(value)
        entries = []
        try:
            for pos, item in enumerate(itertools.islice(value, offset, offset + limit), offset):
                entries.append(ChildSpec(f"[{pos}]", item, PathStep("set_item", pos)))
        except Exception as error:
            return ChildPage(entries, total, f"{type(error).__name__}: {error}")
        return ChildPage(entries, total)


class GenericObjectAdapter(ValueAdapter):
    name = "object"

    def matches(self, value: Any) -> bool:
        return safe_attributes(value) is not None

    def child_count(self, value: Any) -> int:
        return len(safe_attributes(value) or ())

    def children(self, value: Any, offset: int, limit: int) -> ChildPage:
        attributes = safe_attributes(value) or OrderedDict()
        entries = [
            ChildSpec(name, item, PathStep("attr", name))
            for name, item in itertools.islice(attributes.items(), offset, offset + limit)
        ]
        return ChildPage(entries, len(attributes))


class FallbackAdapter(ValueAdapter):
    name = "fallback"

    def matches(self, value: Any) -> bool:
        return True


class AdapterRegistry:
    """Ordered internal registry; callers may prepend future type adapters."""

    def __init__(self, adapters: Iterable[ValueAdapter] | None = None):
        self.adapters = list(
            adapters
            or (
                ScalarAdapter(),
                NumpyAdapter(),
                PandasAdapter(),
                DataclassAdapter(),
                NamedTupleAdapter(),
                MappingAdapter(),
                SequenceAdapter(),
                SetAdapter(),
                GenericObjectAdapter(),
                FallbackAdapter(),
            )
        )

    def register(self, adapter: ValueAdapter, *, first: bool = True) -> None:
        if first:
            self.adapters.insert(0, adapter)
        else:
            self.adapters.insert(max(0, len(self.adapters) - 1), adapter)

    def for_value(self, value: Any) -> ValueAdapter:
        for adapter in self.adapters:
            try:
                if adapter.matches(value):
                    return adapter
            except Exception:
                continue
        return FallbackAdapter()


DEFAULT_ADAPTERS = AdapterRegistry()


def resolve_path(root: Any, steps: tuple[PathStep, ...]) -> Any:
    value = root
    for step in steps:
        if step.kind == "key":
            value = value[step.value]
        elif step.kind == "index":
            value = value[step.value]
        elif step.kind == "attr":
            if dataclasses.is_dataclass(value) or (
                isinstance(value, tuple) and hasattr(type(value), "_fields")
            ):
                value = object.__getattribute__(value, step.value)
            else:
                attributes = safe_attributes(value) or {}
                value = attributes[step.value]
        elif step.kind == "array_index":
            value = value[step.value]
        elif step.kind == "df_iat":
            value = value.iat[step.value[0], step.value[1]]
        elif step.kind == "df_col":
            value = value.iloc[:, step.value]
        elif step.kind == "series_iat":
            value = value.iloc[step.value]
        elif step.kind == "styler_data":
            value = value.data
        else:
            raise ExplorerError(f"Path step {step.kind!r} is not resolvable")
    return value


def parse_edited_value(text: str, old_value: Any) -> Any:
    """Parse editor text according to the existing leaf type without eval()."""
    raw = str(text)
    stripped = raw.strip()
    if isinstance(old_value, str):
        return raw
    if isinstance(old_value, bytes):
        parsed = ast.literal_eval(stripped)
        if not isinstance(parsed, bytes):
            raise ValueError("Expected a bytes literal such as b'data'")
        return parsed
    if isinstance(old_value, bytearray):
        parsed = ast.literal_eval(stripped)
        if isinstance(parsed, (bytes, bytearray)):
            return bytearray(parsed)
        raise ValueError("Expected a bytes or bytearray-compatible literal")
    if old_value is None:
        parsed = ast.literal_eval(stripped)
        return parsed
    if old_value is pd.NA or old_value is pd.NaT:
        if stripped.lower() in {"na", "nat", "null", "none", "<na>"}:
            return old_value
        return ast.literal_eval(stripped)
    if isinstance(old_value, bool):
        lowered = stripped.lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        raise ValueError("Expected true or false")
    if isinstance(old_value, enum.Enum):
        enum_type = type(old_value)
        if stripped in enum_type.__members__:
            return enum_type[stripped]
        parsed = ast.literal_eval(stripped)
        return enum_type(parsed)
    if isinstance(old_value, np.generic):
        if np.issubdtype(old_value.dtype, np.datetime64) or np.issubdtype(
            old_value.dtype, np.timedelta64
        ):
            return np.asarray(stripped.strip("'\""), dtype=old_value.dtype)[()]
        if old_value.dtype.kind == "U":
            return np.asarray(raw, dtype=old_value.dtype)[()]
        return np.asarray(ast.literal_eval(stripped), dtype=old_value.dtype)[()]
    if isinstance(old_value, int) and not isinstance(old_value, bool):
        return type(old_value)(stripped, 0) if type(old_value) is int else type(old_value)(stripped)
    if isinstance(old_value, float):
        return type(old_value)(stripped)
    if isinstance(old_value, complex):
        return type(old_value)(stripped)
    if isinstance(old_value, decimal.Decimal):
        return decimal.Decimal(stripped)
    if isinstance(old_value, fractions.Fraction):
        return fractions.Fraction(stripped)
    if isinstance(old_value, pathlib.PurePath):
        return type(old_value)(raw)
    if isinstance(old_value, uuid.UUID):
        return uuid.UUID(stripped)
    if isinstance(old_value, pd.Timestamp):
        return pd.Timestamp(stripped)
    if isinstance(old_value, pd.Timedelta):
        return pd.Timedelta(stripped)
    if isinstance(old_value, pd.Period):
        return pd.Period(stripped, freq=old_value.freq)
    if isinstance(old_value, pd.Interval):
        parsed = ast.literal_eval(stripped)
        if not isinstance(parsed, tuple) or len(parsed) not in (2, 3):
            raise ValueError("Expected (left, right) or (left, right, closed)")
        return pd.Interval(*parsed)
    if isinstance(old_value, _datetime.datetime):
        return _datetime.datetime.fromisoformat(stripped)
    if isinstance(old_value, _datetime.date):
        return _datetime.date.fromisoformat(stripped)
    if isinstance(old_value, _datetime.time):
        return _datetime.time.fromisoformat(stripped)
    if isinstance(old_value, _datetime.timedelta):
        return _datetime.timedelta(seconds=float(stripped))
    if isinstance(old_value, (list, tuple, dict, set, frozenset)):
        parsed = ast.literal_eval(stripped)
        if isinstance(old_value, tuple):
            return tuple(parsed)
        if isinstance(old_value, frozenset):
            return frozenset(parsed)
        if not isinstance(parsed, type(old_value)):
            raise ValueError(f"Expected a {type(old_value).__name__} literal")
        return parsed
    return ast.literal_eval(stripped)


def can_edit_value(value: Any) -> bool:
    # Existing structure is intentionally fixed: edit scalar leaves and table
    # cells, never replace a container with a literal that adds/removes items.
    return _trusted_scalar(value)


def editable_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, enum.Enum):
        return value.name
    if isinstance(value, (pd.Timestamp, _datetime.datetime, _datetime.date, _datetime.time)):
        return value.isoformat()
    if isinstance(value, pd.Timedelta):
        return str(value)
    if isinstance(value, pd.Period):
        return str(value)
    if isinstance(value, pd.Interval):
        return repr((value.left, value.right, value.closed))
    if isinstance(value, _datetime.timedelta):
        return str(value.total_seconds())
    if isinstance(value, (pathlib.PurePath, uuid.UUID, decimal.Decimal, fractions.Fraction)):
        return str(value)
    if isinstance(value, np.generic):
        return str(value)
    return safe_repr(value, 2000)


def _group_edits(
    edits: list[tuple[tuple[PathStep, ...], Any]],
) -> tuple[Any, dict[PathStep, list[tuple[tuple[PathStep, ...], Any]]]]:
    direct = [new_value for steps, new_value in edits if not steps]
    if direct:
        if len(edits) != 1:
            raise ExplorerError("Cannot replace a value and its descendants together")
        return direct[0], {}
    groups: dict[PathStep, list[tuple[tuple[PathStep, ...], Any]]] = {}
    for steps, new_value in edits:
        head, tail = steps[0], steps[1:]
        groups.setdefault(head, []).append((tail, new_value))
    return _NO_VALUE, groups


_NO_VALUE = object()


def apply_copy_on_write(
    value: Any, edits: list[tuple[tuple[PathStep, ...], Any]]
) -> Any:
    """Apply a group of path edits while copying each traversed container once."""
    direct, groups = _group_edits(edits)
    if direct is not _NO_VALUE:
        return direct

    if isinstance(value, np.ndarray):
        if not value.flags.writeable:
            raise ExplorerError("This NumPy array is read-only")
        clone = value.copy()
        for step, nested in groups.items():
            if step.kind not in {"index", "array_index"}:
                raise ExplorerError(f"Cannot apply {step.kind!r} to a NumPy array")
            key = step.value
            current = clone[key]
            clone[key] = apply_copy_on_write(current, nested)
        return clone

    if isinstance(value, pd.DataFrame):
        clone = value.copy(deep=True)
        for step, nested in groups.items():
            if step.kind == "df_iat":
                row, col = step.value
                clone.iat[row, col] = apply_copy_on_write(clone.iat[row, col], nested)
            elif step.kind == "df_col":
                col = step.value
                updated = apply_copy_on_write(clone.iloc[:, col].copy(deep=True), nested)
                if hasattr(clone, "isetitem"):
                    clone.isetitem(col, updated)
                else:
                    clone.iloc[:, col] = updated
            else:
                raise ExplorerError(f"Cannot apply {step.kind!r} to a DataFrame")
        return clone

    if isinstance(value, pd.Series):
        clone = value.copy(deep=True)
        for step, nested in groups.items():
            if step.kind not in {"series_iat", "index"}:
                raise ExplorerError(f"Cannot apply {step.kind!r} to a Series")
            pos = step.value
            clone.iloc[pos] = apply_copy_on_write(clone.iloc[pos], nested)
        return clone

    if isinstance(value, (dict, OrderedDict, defaultdict)):
        clone = copy.copy(value)
        for step, nested in groups.items():
            if step.kind != "key":
                raise ExplorerError(f"Cannot apply {step.kind!r} to a mapping")
            clone[step.value] = apply_copy_on_write(value[step.value], nested)
        return clone

    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        replacements = {}
        for step, nested in groups.items():
            if step.kind != "attr":
                raise ExplorerError(f"Cannot apply {step.kind!r} to a dataclass")
            current = object.__getattribute__(value, step.value)
            replacements[step.value] = apply_copy_on_write(current, nested)
        return dataclasses.replace(value, **replacements)

    if isinstance(value, tuple) and hasattr(type(value), "_fields"):
        replacements = {}
        for step, nested in groups.items():
            if step.kind != "attr":
                raise ExplorerError(f"Cannot apply {step.kind!r} to a named tuple")
            current = object.__getattribute__(value, step.value)
            replacements[step.value] = apply_copy_on_write(current, nested)
        return value._replace(**replacements)

    if isinstance(value, list):
        clone = list(value)
        for step, nested in groups.items():
            if step.kind != "index":
                raise ExplorerError(f"Cannot apply {step.kind!r} to a list")
            clone[step.value] = apply_copy_on_write(value[step.value], nested)
        return clone

    if isinstance(value, tuple):
        clone = list(value)
        for step, nested in groups.items():
            if step.kind != "index":
                raise ExplorerError(f"Cannot apply {step.kind!r} to a tuple")
            clone[step.value] = apply_copy_on_write(value[step.value], nested)
        return tuple(clone)

    if isinstance(value, deque):
        clone = list(value)
        for step, nested in groups.items():
            if step.kind != "index":
                raise ExplorerError(f"Cannot apply {step.kind!r} to a deque")
            clone[step.value] = apply_copy_on_write(value[step.value], nested)
        return deque(clone, maxlen=value.maxlen)

    if isinstance(value, _array.array):
        clone = _array.array(value.typecode, value)
        for step, nested in groups.items():
            if step.kind != "index":
                raise ExplorerError(f"Cannot apply {step.kind!r} to an array.array")
            clone[step.value] = apply_copy_on_write(value[step.value], nested)
        return clone

    raise ExplorerError(f"Values inside {type(value).__name__} are read-only")


class VariableSource:
    """Minimal source interface consumed by the shared explorer widget."""

    def snapshot(self) -> dict[str, Any]:
        raise NotImplementedError

    @property
    def generation(self) -> int:
        return 0

    @property
    def state(self) -> str:
        return "READY"

    def metadata(self, name: str) -> dict[str, Any]:
        return {}

    def apply(
        self,
        root_name: str,
        expected_generation: int,
        expected_root: Any,
        edits: list[PendingEdit],
    ) -> Any:
        raise ExplorerError("This source is read-only")


class GlobalsVariableSource(VariableSource):
    def __init__(self, runtime=None):
        self.runtime = runtime

    def snapshot(self) -> dict[str, Any]:
        return RuntimeGlobals.snapshot()

    @property
    def generation(self) -> int:
        return RuntimeGlobals.generation

    @property
    def state(self) -> str:
        return RuntimeGlobals.state

    def metadata(self, name: str) -> dict[str, Any]:
        runtime = self.runtime
        globals_class = getattr(runtime, "current_globals_class", None)
        if globals_class is None:
            return {}
        try:
            spec = globals_class.definitions().get(name)
        except Exception:
            spec = None
        if spec is None:
            return {"declaration": "dynamic"}
        return {
            "declaration": spec.kind,
            "label": spec.label,
            "reload": getattr(spec.reload, "value", str(spec.reload)),
            "timeout": spec.timeout,
        }

    def apply(
        self,
        root_name: str,
        expected_generation: int,
        expected_root: Any,
        edits: list[PendingEdit],
    ) -> Any:
        def operation(current):
            if self.generation != expected_generation:
                raise EditConflictError("Globals reloaded while edits were pending")
            if current is not expected_root:
                raise EditConflictError(f"Global {root_name!r} was replaced")
            for edit in edits:
                current_leaf = resolve_path(current, edit.path.steps)
                if value_fingerprint(current_leaf) != edit.expected_fingerprint:
                    raise EditConflictError(f"{edit.path.display()} changed after editing began")
            patch = [(edit.path.steps, edit.new_value) for edit in edits]
            return apply_copy_on_write(current, patch)

        return RuntimeGlobals.mutate(root_name, operation)


class EnvironmentVariableSource(VariableSource):
    def __init__(self, mapping: dict[str, Any] | None = None):
        self.mapping = mapping if mapping is not None else {}
        self._generation = 0

    def set_mapping(self, mapping: dict[str, Any]) -> None:
        if mapping is not self.mapping:
            self.mapping = mapping
            self._generation += 1

    def touch(self) -> None:
        self._generation += 1

    def snapshot(self) -> dict[str, Any]:
        try:
            return {
                name: value
                for name, value in list(self.mapping.items())
                if not str(name).startswith("__")
            }
        except Exception:
            return {}

    @property
    def generation(self) -> int:
        return self._generation

    def apply(
        self,
        root_name: str,
        expected_generation: int,
        expected_root: Any,
        edits: list[PendingEdit],
    ) -> Any:
        current = self.mapping[root_name]
        if self.generation != expected_generation or current is not expected_root:
            raise EditConflictError(f"Variable {root_name!r} changed")
        for edit in edits:
            current_leaf = resolve_path(current, edit.path.steps)
            if value_fingerprint(current_leaf) != edit.expected_fingerprint:
                raise EditConflictError(f"{edit.path.display()} changed after editing began")
        updated = apply_copy_on_write(
            current, [(edit.path.steps, edit.new_value) for edit in edits]
        )
        self.mapping[root_name] = updated
        self.touch()
        return updated


@dataclass
class TreeNode:
    name: str
    value: Any
    path: ValuePath | None
    parent: "TreeNode | None" = None
    adapter: ValueAdapter | None = None
    ancestors: frozenset[int] = frozenset()
    reference: str = ""
    children: list["TreeNode"] = field(default_factory=list)
    fetched: int = 0
    total: int = 0
    error: str = ""

    def row(self) -> int:
        if self.parent is None:
            return 0
        try:
            return self.parent.children.index(self)
        except ValueError:
            return 0


class VariableTreeModel(QtCore.QAbstractItemModel):
    HEADERS = ("Name", "Type", "Value", "Shape / Length", "Size", "Modified")

    def __init__(self, adapters: AdapterRegistry | None = None, parent=None):
        super().__init__(parent)
        self.adapters = adapters or DEFAULT_ADAPTERS
        self.root = TreeNode("<root>", None, None)
        self.modified_paths: dict[str, tuple[float, str]] = {}
        self.pending_paths: set[str] = set()
        self.error_paths: set[str] = set()
        self._first_paths: dict[int, str] = {}

    def set_snapshot(self, snapshot: Mapping[str, Any]) -> None:
        self.beginResetModel()
        self.root.children.clear()
        self._first_paths.clear()
        for name in sorted(snapshot, key=lambda item: str(item).lower()):
            value = snapshot[name]
            path = ValuePath(str(name))
            node = self._new_node(str(name), value, path, self.root, frozenset())
            self.root.children.append(node)
        self.root.total = len(self.root.children)
        self.root.fetched = self.root.total
        self.endResetModel()

    def _new_node(
        self,
        name: str,
        value: Any,
        path: ValuePath,
        parent: TreeNode,
        ancestors: frozenset[int],
    ) -> TreeNode:
        adapter = self.adapters.for_value(value)
        reference = ""
        expandable = False
        try:
            expandable = adapter.child_count(value) > 0
        except Exception:
            pass
        value_id = id(value)
        if expandable:
            if value_id in ancestors:
                reference = "cycle"
            elif value_id in self._first_paths:
                reference = f"shared → {self._first_paths[value_id]}"
            else:
                self._first_paths[value_id] = path.display()
        node = TreeNode(
            name=name,
            value=value,
            path=path,
            parent=parent,
            adapter=adapter,
            ancestors=ancestors,
            reference=reference,
        )
        if not reference:
            try:
                node.total = adapter.child_count(value)
            except Exception as error:
                node.error = f"{type(error).__name__}: {error}"
        return node

    def index(self, row, column, parent=QtCore.QModelIndex()):
        parent_node = parent.internalPointer() if parent.isValid() else self.root
        if row < 0 or row >= len(parent_node.children):
            return QtCore.QModelIndex()
        return self.createIndex(row, column, parent_node.children[row])

    def parent(self, index):
        if not index.isValid():
            return QtCore.QModelIndex()
        node = index.internalPointer()
        parent = node.parent
        if parent is None or parent is self.root:
            return QtCore.QModelIndex()
        return self.createIndex(parent.row(), 0, parent)

    def rowCount(self, parent=QtCore.QModelIndex()):
        node = parent.internalPointer() if parent.isValid() else self.root
        return len(node.children)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return len(self.HEADERS)

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Horizontal:
            if 0 <= section < len(self.HEADERS):
                return self.HEADERS[section]
        return None

    def hasChildren(self, parent=QtCore.QModelIndex()):
        node = parent.internalPointer() if parent.isValid() else self.root
        return bool(node.children) or node.total > node.fetched

    def canFetchMore(self, parent):
        if not parent.isValid():
            return False
        node = parent.internalPointer()
        return not node.reference and node.fetched < node.total

    def fetchMore(self, parent):
        if not parent.isValid():
            return
        node: TreeNode = parent.internalPointer()
        if node.reference or node.fetched >= node.total:
            return
        page = node.adapter.children(node.value, node.fetched, PAGE_SIZE)
        if not page.entries:
            node.fetched = page.total
            node.total = page.total
            node.error = page.error
            return
        start = len(node.children)
        end = start + len(page.entries) - 1
        self.beginInsertRows(parent, start, end)
        ancestors = node.ancestors | {id(node.value)}
        for child in page.entries:
            child_path = node.path.child(child.step)
            node.children.append(
                self._new_node(child.name, child.value, child_path, node, ancestors)
            )
        node.fetched += len(page.entries)
        node.total = page.total
        node.error = page.error
        self.endInsertRows()

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        node: TreeNode = index.internalPointer()
        path_key = node.path.key() if node.path else ""
        if role == VALUE_ROLE:
            return node.value
        if role == PATH_ROLE:
            return node.path
        if role == QtCore.Qt.ToolTipRole:
            extra = f"\nReference: {node.reference}" if node.reference else ""
            error = f"\nRead error: {node.error}" if node.error else ""
            return f"{node.path.display()}\nType: {type(node.value)!r}{extra}{error}"
        if role == QtCore.Qt.BackgroundRole:
            if path_key in self.error_paths:
                return QtGui.QBrush(QtGui.QColor("#ffd6d6"))
            if path_key in self.pending_paths:
                return QtGui.QBrush(QtGui.QColor("#cfe8ff"))
            modified = self.modified_paths.get(path_key)
            if modified and time.time() - modified[0] < 5.0:
                color = "#d8f5d0" if modified[1] == "added" else "#fff0b3"
                return QtGui.QBrush(QtGui.QColor(color))
        if role != QtCore.Qt.DisplayRole:
            return None
        if index.column() == 0:
            return node.name
        if index.column() == 1:
            return type(node.value).__name__
        if index.column() == 2:
            return node.reference or node.adapter.preview(node.value)
        if index.column() == 3:
            return node.adapter.info(node.value)
        if index.column() == 4:
            return node.adapter.size(node.value)
        if index.column() == 5:
            if path_key in self.error_paths:
                return "conflict"
            if path_key in self.pending_paths:
                return "pending"
            modified = self.modified_paths.get(path_key)
            if modified:
                return time.strftime("%H:%M:%S", time.localtime(modified[0]))
        return None

    def flags(self, index):
        if not index.isValid():
            return QtCore.Qt.NoItemFlags
        return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable

    def loaded_nodes(self) -> list[TreeNode]:
        result = []
        stack = list(reversed(self.root.children))
        while stack:
            node = stack.pop()
            result.append(node)
            stack.extend(reversed(node.children))
        return result

    def find_loaded(self, path_key: str) -> TreeNode | None:
        for node in self.loaded_nodes():
            if node.path and node.path.key() == path_key:
                return node
        return None

    def index_for_node(self, node: TreeNode, column: int = 0):
        if node.parent is None:
            return QtCore.QModelIndex()
        return self.createIndex(node.row(), column, node)

    def refresh_decorations(self) -> None:
        if not self.root.children:
            return
        top_left = self.index(0, 0)
        bottom_right = self.index(len(self.root.children) - 1, len(self.HEADERS) - 1)
        self.dataChanged.emit(
            top_left,
            bottom_right,
            [QtCore.Qt.BackgroundRole, QtCore.Qt.DisplayRole],
        )


class RecursiveFilterProxy(QtCore.QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFilterCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.setRecursiveFilteringEnabled(True)
        self.setFilterKeyColumn(-1)
        self.setDynamicSortFilter(True)


class ChangeHistoryModel(QtCore.QAbstractTableModel):
    HEADERS = ("Time", "Path", "Kind", "Old", "New", "Generation", "Origin")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.records: list[ChangeRecord] = []

    def add(self, record: ChangeRecord) -> None:
        if len(self.records) >= HISTORY_LIMIT:
            remove = len(self.records) - HISTORY_LIMIT + 1
            self.beginRemoveRows(QtCore.QModelIndex(), 0, remove - 1)
            del self.records[:remove]
            self.endRemoveRows()
        row = len(self.records)
        self.beginInsertRows(QtCore.QModelIndex(), row, row)
        self.records.append(record)
        self.endInsertRows()

    def clear(self) -> None:
        self.beginResetModel()
        self.records.clear()
        self.endResetModel()

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.records)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return len(self.HEADERS)

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Horizontal:
            return self.HEADERS[section]
        return None

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        record = self.records[index.row()]
        if role == QtCore.Qt.BackgroundRole:
            colors = {
                "added": "#d8f5d0",
                "changed": "#fff0b3",
                "edited": "#cfe8ff",
                "removed": "#ffd6d6",
                "generation": "#e8def8",
            }
            color = colors.get(record.kind)
            return QtGui.QBrush(QtGui.QColor(color)) if color else None
        if role != QtCore.Qt.DisplayRole:
            return None
        values = (
            time.strftime("%H:%M:%S", time.localtime(record.timestamp)),
            record.path,
            record.kind,
            record.old_summary,
            record.new_summary,
            record.generation,
            record.origin,
        )
        return values[index.column()]


class EditSession(QtCore.QObject):
    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.root_name = ""
        self.generation = -1
        self.root_object: Any = None
        self.edits: OrderedDict[str, PendingEdit] = OrderedDict()

    @property
    def active(self) -> bool:
        return bool(self.edits)

    def stage(
        self,
        source: VariableSource,
        snapshot: Mapping[str, Any],
        path: ValuePath,
        old_value: Any,
        new_value: Any,
    ) -> None:
        if self.active and path.root != self.root_name:
            raise ExplorerError("Pending edits belong to another root variable")
        if not self.active:
            self.root_name = path.root
            self.generation = source.generation
            self.root_object = snapshot[path.root]
        key = path.key()
        existing = self.edits.get(key)
        if existing is None:
            self.edits[key] = PendingEdit(
                path=path,
                old_value=old_value,
                new_value=new_value,
                expected_fingerprint=value_fingerprint(old_value),
            )
        else:
            existing.new_value = new_value
            existing.error = ""
        self.changed.emit()

    def pending(self, path: ValuePath) -> PendingEdit | None:
        return self.edits.get(path.key())

    def discard(self) -> None:
        self.root_name = ""
        self.generation = -1
        self.root_object = None
        self.edits.clear()
        self.changed.emit()

    def apply(self, source: VariableSource) -> Any:
        if not self.active:
            return None
        try:
            result = source.apply(
                self.root_name,
                self.generation,
                self.root_object,
                list(self.edits.values()),
            )
        except Exception as error:
            for edit in self.edits.values():
                edit.error = str(error)
            self.changed.emit()
            raise
        self.discard()
        return result


def is_editable_path(root: Any, path: ValuePath) -> bool:
    current = root
    if not path.steps:
        return can_edit_value(current)
    for step in path.steps:
        if isinstance(current, np.ndarray):
            if not current.flags.writeable or step.kind not in {"index", "array_index"}:
                return False
        elif isinstance(current, pd.DataFrame):
            if step.kind not in {"df_iat", "df_col"}:
                return False
        elif isinstance(current, pd.Series):
            if step.kind not in {"series_iat", "index"}:
                return False
        elif isinstance(current, (dict, OrderedDict, defaultdict)):
            if step.kind != "key":
                return False
        elif dataclasses.is_dataclass(current) and not isinstance(current, type):
            if step.kind != "attr":
                return False
        elif isinstance(current, tuple) and hasattr(type(current), "_fields"):
            if step.kind != "attr":
                return False
        elif isinstance(current, (list, tuple, deque, _array.array)):
            if step.kind != "index":
                return False
        else:
            return False
        try:
            current = resolve_path(current, (step,))
        except Exception:
            return False
    return can_edit_value(current)


def safe_details_repr(value: Any, depth: int = 0, budget: list[int] | None = None) -> str:
    if budget is None:
        budget = [250]
    if budget[0] <= 0:
        return "…"
    budget[0] -= 1
    if _trusted_scalar(value):
        return safe_repr(value, 500)
    if depth >= 5:
        return value_summary(value)
    try:
        if isinstance(value, Mapping):
            parts = []
            for key, item in itertools.islice(value.items(), 50):
                parts.append(
                    f"{safe_repr(key, 100)}: {safe_details_repr(item, depth + 1, budget)}"
                )
            suffix = ", …" if len(value) > len(parts) else ""
            return "{" + ", ".join(parts) + suffix + "}"
        if isinstance(value, (list, tuple, deque, _array.array)):
            parts = [
                safe_details_repr(item, depth + 1, budget)
                for item in itertools.islice(value, 50)
            ]
            suffix = ", …" if len(value) > len(parts) else ""
            left, right = ("[", "]") if isinstance(value, list) else ("(", ")")
            return left + ", ".join(parts) + suffix + right
        if isinstance(value, (set, frozenset)):
            parts = [
                safe_details_repr(item, depth + 1, budget)
                for item in itertools.islice(value, 50)
            ]
            suffix = ", …" if len(value) > len(parts) else ""
            return "{" + ", ".join(parts) + suffix + "}"
        if isinstance(value, np.ndarray):
            if value.dtype.hasobject:
                return value_summary(value) + "\n<object array: inspect cells in Data>"
            return np.array2string(value, threshold=200, edgeitems=4)
        if isinstance(value, (pd.DataFrame, pd.Series, pd.Index)):
            return value_summary(value) + "\n<use the Data tab for content>"
        attributes = safe_attributes(value)
        if attributes:
            parts = [
                f"{name}={safe_details_repr(item, depth + 1, budget)}"
                for name, item in itertools.islice(attributes.items(), 50)
            ]
            return f"{type(value).__name__}(" + ", ".join(parts) + ")"
    except Exception as error:
        return f"<representation unavailable: {type(error).__name__}: {error}>"
    return value_summary(value)


class _EditableTableModel(QtCore.QAbstractTableModel):
    def __init__(
        self,
        value: Any,
        path: ValuePath,
        stage: Callable[[ValuePath, Any, str], bool],
        pending: Callable[[ValuePath], PendingEdit | None],
        parent=None,
    ):
        super().__init__(parent)
        self.value = value
        self.path = path
        self._stage = stage
        self._pending = pending

    def path_for_index(self, index: QtCore.QModelIndex) -> ValuePath | None:
        return None

    def value_for_index(self, index: QtCore.QModelIndex) -> Any:
        return None

    def _display_value(self, path: ValuePath, value: Any) -> Any:
        edit = self._pending(path)
        return edit.new_value if edit else value

    def _common_data(self, index, path, value, role):
        shown = self._display_value(path, value)
        if role == QtCore.Qt.DisplayRole:
            return safe_repr(shown, 240)
        if role == QtCore.Qt.EditRole:
            return editable_text(shown)
        if role == VALUE_ROLE:
            return shown
        if role == PATH_ROLE:
            return path
        if role == SORT_ROLE:
            if _trusted_scalar(shown):
                return shown
            return safe_repr(shown, 240)
        if role == QtCore.Qt.BackgroundRole and self._pending(path):
            color = "#ffd6d6" if self._pending(path).error else "#cfe8ff"
            return QtGui.QBrush(QtGui.QColor(color))
        if role == QtCore.Qt.ToolTipRole:
            return f"{path.display()}\n{type(shown)!r}\n{safe_repr(shown, 500)}"
        return None

    def setData(self, index, value, role=QtCore.Qt.EditRole):
        if not index.isValid() or role != QtCore.Qt.EditRole:
            return False
        path = self.path_for_index(index)
        old = self.value_for_index(index)
        if path is None or not can_edit_value(old):
            return False
        if self._stage(path, old, str(value)):
            self.dataChanged.emit(
                index,
                index,
                [QtCore.Qt.DisplayRole, QtCore.Qt.BackgroundRole],
            )
            return True
        return False


class ArrayTableModel(_EditableTableModel):
    def __init__(self, value, path, stage, pending, selectors=(), parent=None):
        self.selectors = tuple(selectors)
        super().__init__(value, path, stage, pending, parent)

    def set_selectors(self, selectors: Iterable[int]) -> None:
        self.beginResetModel()
        self.selectors = tuple(selectors)
        self.endResetModel()

    def rowCount(self, parent=QtCore.QModelIndex()):
        if parent.isValid():
            return 0
        if self.value.ndim <= 1:
            return 1
        return int(self.value.shape[0])

    def columnCount(self, parent=QtCore.QModelIndex()):
        if parent.isValid():
            return 0
        if self.value.ndim == 0:
            return 1
        if self.value.ndim == 1:
            return int(self.value.shape[0])
        return int(self.value.shape[1])

    def _array_key(self, index):
        if self.value.ndim == 0:
            return ()
        if self.value.ndim == 1:
            return (index.column(),)
        return (index.row(), index.column()) + self.selectors

    def path_for_index(self, index):
        return self.path.child(PathStep("array_index", self._array_key(index)))

    def value_for_index(self, index):
        return self.value[self._array_key(index)]

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        try:
            path = self.path_for_index(index)
            value = self.value_for_index(index)
        except Exception:
            return None
        return self._common_data(index, path, value, role)

    def flags(self, index):
        flags = QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable
        if self.value.flags.writeable:
            try:
                if can_edit_value(self.value_for_index(index)):
                    flags |= QtCore.Qt.ItemIsEditable
            except Exception:
                pass
        return flags

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole:
            return str(section)
        return None


class PandasTableModel(_EditableTableModel):
    def __init__(self, value, path, stage, pending, editable=True, parent=None):
        self.editable = editable
        super().__init__(value, path, stage, pending, parent)

    def rowCount(self, parent=QtCore.QModelIndex()):
        if parent.isValid():
            return 0
        if isinstance(self.value, pd.DataFrame):
            return int(self.value.shape[0])
        return len(self.value)

    def columnCount(self, parent=QtCore.QModelIndex()):
        if parent.isValid():
            return 0
        return int(self.value.shape[1]) if isinstance(self.value, pd.DataFrame) else 1

    def path_for_index(self, index):
        if isinstance(self.value, pd.DataFrame):
            return self.path.child(PathStep("df_iat", (index.row(), index.column())))
        if isinstance(self.value, pd.Series):
            return self.path.child(PathStep("series_iat", index.row()))
        return self.path.child(PathStep("index", index.row()))

    def value_for_index(self, index):
        if isinstance(self.value, pd.DataFrame):
            return self.value.iat[index.row(), index.column()]
        if isinstance(self.value, pd.Series):
            return self.value.iloc[index.row()]
        return self.value[index.row()]

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        try:
            path = self.path_for_index(index)
            value = self.value_for_index(index)
        except Exception:
            return None
        if role == QtCore.Qt.TextAlignmentRole:
            if isinstance(value, (int, float, complex, np.number)):
                return QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter
        return self._common_data(index, path, value, role)

    def flags(self, index):
        flags = QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable
        if self.editable and not isinstance(self.value, pd.Index):
            try:
                if can_edit_value(self.value_for_index(index)):
                    flags |= QtCore.Qt.ItemIsEditable
            except Exception:
                pass
        return flags

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role != QtCore.Qt.DisplayRole:
            return None
        try:
            if orientation == QtCore.Qt.Horizontal:
                if isinstance(self.value, pd.DataFrame):
                    return str(self.value.columns[section])
                return str(getattr(self.value, "name", "value") or "value")
            return str(self.value.index[section] if hasattr(self.value, "index") else section)
        except Exception:
            return str(section)


class SequenceTableModel(_EditableTableModel):
    def __init__(self, value, path, stage, pending, parent=None):
        self.matrix = False
        self.columns = 1
        try:
            sample = list(itertools.islice(value, 64))
            self.matrix = bool(sample) and all(
                isinstance(item, (list, tuple)) for item in sample
            )
            if self.matrix:
                self.columns = max(1, min(10_000, max(len(item) for item in sample)))
        except Exception:
            pass
        super().__init__(value, path, stage, pending, parent)

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.value)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else self.columns

    def _exists(self, index):
        return not self.matrix or index.column() < len(self.value[index.row()])

    def path_for_index(self, index):
        path = self.path.child(PathStep("index", index.row()))
        if self.matrix:
            path = path.child(PathStep("index", index.column()))
        return path

    def value_for_index(self, index):
        row_value = self.value[index.row()]
        return row_value[index.column()] if self.matrix else row_value

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid() or not self._exists(index):
            return None
        try:
            return self._common_data(
                index, self.path_for_index(index), self.value_for_index(index), role
            )
        except Exception:
            return None

    def flags(self, index):
        flags = QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable
        if self._exists(index):
            try:
                if can_edit_value(self.value_for_index(index)):
                    flags |= QtCore.Qt.ItemIsEditable
            except Exception:
                pass
        return flags

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole:
            return str(section)
        return None


class MappingTableModel(_EditableTableModel):
    def __init__(self, value, path, stage, pending, parent=None):
        try:
            self.items = list(itertools.islice(value.items(), PAGE_SIZE))
        except Exception:
            self.items = []
        super().__init__(value, path, stage, pending, parent)

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.items)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return 2

    def path_for_index(self, index):
        if index.column() != 1:
            return None
        return self.path.child(PathStep("key", self.items[index.row()][0]))

    def value_for_index(self, index):
        return self.items[index.row()][index.column()]

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        if index.column() == 0:
            if role in (QtCore.Qt.DisplayRole, QtCore.Qt.EditRole):
                return safe_repr(self.items[index.row()][0], 240)
            return None
        path = self.path_for_index(index)
        return self._common_data(index, path, self.items[index.row()][1], role)

    def flags(self, index):
        flags = QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable
        if index.column() == 1 and isinstance(self.value, (dict, OrderedDict, defaultdict)):
            if can_edit_value(self.items[index.row()][1]):
                flags |= QtCore.Qt.ItemIsEditable
        return flags

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Horizontal:
            return ("Key", "Value")[section]
        return None


class DataSortProxy(QtCore.QSortFilterProxyModel):
    def lessThan(self, left, right):
        left_value = left.data(SORT_ROLE)
        right_value = right.data(SORT_ROLE)
        try:
            if pd.isna(left_value):
                return False
            if pd.isna(right_value):
                return True
        except Exception:
            pass
        try:
            return left_value < right_value
        except Exception:
            return str(left_value).lower() < str(right_value).lower()


class AttributeTableModel(QtCore.QAbstractTableModel):
    def __init__(self, value=None, parent=None):
        super().__init__(parent)
        self.set_value(value)

    def set_value(self, value):
        self.beginResetModel()
        self.attributes = list((safe_attributes(value) or {}).items())
        self.endResetModel()

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.attributes)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return 3

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid() or role != QtCore.Qt.DisplayRole:
            return None
        name, value = self.attributes[index.row()]
        return (name, type(value).__name__, safe_repr(value, 300))[index.column()]

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Horizontal:
            return ("Attribute", "Type", "Value")[section]
        return None


class ArrayDataView(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.selector_scroll = QtWidgets.QScrollArea()
        self.selector_scroll.setWidgetResizable(True)
        self.selector_scroll.setMaximumHeight(48)
        self.selector_widget = QtWidgets.QWidget()
        self.selector_layout = QtWidgets.QHBoxLayout(self.selector_widget)
        self.selector_layout.setContentsMargins(4, 2, 4, 2)
        self.selector_scroll.setWidget(self.selector_widget)
        layout.addWidget(self.selector_scroll)
        self.table = QtWidgets.QTableView()
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(False)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        layout.addWidget(self.table)
        self.spins: list[QtWidgets.QSpinBox] = []
        self.model: ArrayTableModel | None = None

    def set_array(self, value, path, stage, pending):
        old_model = self.table.model()
        if old_model is not None:
            self.table.setModel(None)
            old_model.deleteLater()
        while self.selector_layout.count():
            item = self.selector_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.spins.clear()
        selectors = []
        for dimension in range(2, value.ndim):
            label = QtWidgets.QLabel(f"dim {dimension}:")
            spin = QtWidgets.QSpinBox()
            spin.setRange(0, max(0, int(value.shape[dimension]) - 1))
            spin.valueChanged.connect(self._slice_changed)
            self.selector_layout.addWidget(label)
            self.selector_layout.addWidget(spin)
            self.spins.append(spin)
            selectors.append(0)
        self.selector_layout.addStretch()
        self.selector_scroll.setVisible(value.ndim > 2)
        self.model = ArrayTableModel(value, path, stage, pending, selectors, self)
        self.table.setModel(self.model)
        self.table.horizontalHeader().setDefaultSectionSize(90)
        self.table.verticalHeader().setDefaultSectionSize(22)

    def _slice_changed(self):
        if self.model:
            self.model.set_selectors(spin.value() for spin in self.spins)


class VariableExplorerWidget(QtWidgets.QWidget):
    """Shared widget used by the standalone Globals window and IDE dock."""

    def __init__(self, source: VariableSource, runtime=None, parent=None):
        super().__init__(parent)
        self.source = source
        self.runtime = runtime
        self.snapshot: dict[str, Any] = {}
        self._fingerprints: dict[str, tuple[Any, str, ValuePath]] = {}
        self._baseline_ready = False
        self._last_generation = source.generation
        self._partial_scan = False
        self._known_root_names: set[str] = set()
        self._removed_path_keys: set[str] = set()
        self._suppress_next_roots: set[str] = set()
        self._detail_history: list[tuple[Any, ValuePath]] = []
        self._current_detail: tuple[Any, ValuePath] | None = None
        self._table_sorts: dict[str, tuple[int, QtCore.Qt.SortOrder]] = {}
        self._current_table_path = ""
        self._setting_table_sort = False

        self.edit_session = EditSession(self)
        self.edit_session.changed.connect(self._pending_changed)
        self.history_model = ChangeHistoryModel(self)
        self.tree_model = VariableTreeModel(parent=self)
        self.proxy = RecursiveFilterProxy(self)
        self.proxy.setSourceModel(self.tree_model)

        self._build_ui()
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(DEFAULT_REFRESH_MS)
        self._timer.timeout.connect(self.refresh)
        self._timer.start()
        self.refresh(force=True)

    def _build_ui(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(4, 4, 4, 4)

        controls = QtWidgets.QHBoxLayout()
        self.live = QtWidgets.QCheckBox("Live")
        self.live.setChecked(True)
        self.live.toggled.connect(self._live_toggled)
        controls.addWidget(self.live)
        self.refresh_button = QtWidgets.QPushButton("Refresh")
        self.refresh_button.clicked.connect(lambda: self.refresh(force=True))
        controls.addWidget(self.refresh_button)
        controls.addWidget(QtWidgets.QLabel("Interval:"))
        self.interval = QtWidgets.QSpinBox()
        self.interval.setRange(250, 10_000)
        self.interval.setSingleStep(250)
        self.interval.setSuffix(" ms")
        self.interval.setValue(DEFAULT_REFRESH_MS)
        self.interval.valueChanged.connect(self._timer_interval_changed)
        controls.addWidget(self.interval)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Search variables and loaded nodes…")
        self.search.textChanged.connect(self.proxy.setFilterWildcard)
        controls.addWidget(self.search, 1)
        self.apply_button = QtWidgets.QPushButton("Apply")
        self.apply_button.clicked.connect(self.apply_edits)
        self.discard_button = QtWidgets.QPushButton("Discard")
        self.discard_button.clicked.connect(self.edit_session.discard)
        controls.addWidget(self.apply_button)
        controls.addWidget(self.discard_button)
        outer.addLayout(controls)

        self.status = QtWidgets.QLabel()
        self.status.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        outer.addWidget(self.status)

        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        outer.addWidget(splitter, 1)

        self.tree = QtWidgets.QTreeView()
        self.tree.setModel(self.proxy)
        self.tree.setSortingEnabled(True)
        self.tree.sortByColumn(0, QtCore.Qt.AscendingOrder)
        self.tree.setAlternatingRowColors(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._tree_menu)
        self.tree.selectionModel().currentChanged.connect(self._tree_selection_changed)
        self.tree.doubleClicked.connect(self._tree_double_clicked)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        splitter.addWidget(self.tree)

        detail = QtWidgets.QWidget()
        detail_layout = QtWidgets.QVBoxLayout(detail)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        detail_bar = QtWidgets.QHBoxLayout()
        self.back_button = QtWidgets.QPushButton("Back")
        self.back_button.setEnabled(False)
        self.back_button.clicked.connect(self._detail_back)
        detail_bar.addWidget(self.back_button)
        self.detail_title = QtWidgets.QLabel("Select a variable")
        self.detail_title.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        detail_bar.addWidget(self.detail_title, 1)
        detail_layout.addLayout(detail_bar)

        self.tabs = QtWidgets.QTabWidget()
        detail_layout.addWidget(self.tabs, 1)
        self.summary = QtWidgets.QTextEdit()
        self.summary.setReadOnly(True)
        self.summary.setFontFamily("Consolas")
        self.tabs.addTab(self.summary, "Summary")

        self.data_stack = QtWidgets.QStackedWidget()
        self.data_empty = QtWidgets.QLabel("This value has no tabular view.")
        self.data_empty.setAlignment(QtCore.Qt.AlignCenter)
        self.array_view = ArrayDataView()
        self.array_view.table.customContextMenuRequested.connect(self._array_menu)
        self.table_view = QtWidgets.QTableView()
        self.table_view.setAlternatingRowColors(True)
        self.table_view.setWordWrap(False)
        self.table_view.setSortingEnabled(True)
        self.table_view.horizontalHeader().setSortIndicatorShown(False)
        self.table_view.horizontalHeader().sortIndicatorChanged.connect(
            self._table_sort_changed
        )
        self.table_view.doubleClicked.connect(self._table_double_clicked)
        self.data_stack.addWidget(self.data_empty)
        self.data_stack.addWidget(self.array_view)
        self.data_stack.addWidget(self.table_view)
        self.tabs.addTab(self.data_stack, "Data")

        self.representation = QtWidgets.QTextEdit()
        self.representation.setReadOnly(True)
        self.representation.setFontFamily("Consolas")
        self.tabs.addTab(self.representation, "Representation")

        self.attribute_view = QtWidgets.QTableView()
        self.attribute_model = AttributeTableModel(parent=self)
        self.attribute_view.setModel(self.attribute_model)
        self.attribute_view.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.attribute_view, "Attributes")

        self.history_view = QtWidgets.QTableView()
        self.history_view.setModel(self.history_model)
        self.history_view.setSortingEnabled(False)
        self.history_view.setAlternatingRowColors(True)
        self.history_view.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.history_view, "Changes")

        splitter.addWidget(detail)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        self._pending_changed()

    def _live_toggled(self, enabled):
        if enabled:
            self._timer.start(self.interval.value())
            self.refresh(force=True)
        else:
            self._timer.stop()
            self._update_status()

    def _timer_interval_changed(self, value):
        self._timer.setInterval(value)
        if self.live.isChecked():
            self._timer.start(value)

    def _capture_view_state(self):
        expanded: list[ValuePath] = []
        for node in self.tree_model.loaded_nodes():
            source_index = self.tree_model.index_for_node(node)
            proxy_index = self.proxy.mapFromSource(source_index)
            if proxy_index.isValid() and self.tree.isExpanded(proxy_index):
                expanded.append(node.path)
        current = self.tree.currentIndex()
        selected = None
        if current.isValid():
            selected = self.proxy.mapToSource(current).data(PATH_ROLE)
        return (
            expanded[:1000],
            selected,
            self.tree.verticalScrollBar().value(),
            self.tree.horizontalScrollBar().value(),
        )

    def _ensure_path(self, path: ValuePath) -> TreeNode | None:
        node = next(
            (child for child in self.tree_model.root.children if child.path.root == path.root),
            None,
        )
        if node is None:
            return None
        for depth, step in enumerate(path.steps, 1):
            target_steps = path.steps[:depth]
            while True:
                child = next(
                    (item for item in node.children if item.path.steps == target_steps),
                    None,
                )
                if child is not None:
                    node = child
                    break
                if node.fetched >= node.total:
                    return None
                self.tree_model.fetchMore(self.tree_model.index_for_node(node))
        return node

    def _restore_view_state(self, expanded, selected, vertical=0, horizontal=0):
        for path in sorted(expanded, key=lambda item: len(item.steps)):
            node = self._ensure_path(path)
            if node is not None:
                proxy_index = self.proxy.mapFromSource(self.tree_model.index_for_node(node))
                if proxy_index.isValid():
                    self.tree.setExpanded(proxy_index, True)
        if selected is not None:
            node = self._ensure_path(selected)
            if node is not None:
                proxy_index = self.proxy.mapFromSource(self.tree_model.index_for_node(node))
                if proxy_index.isValid():
                    self.tree.setCurrentIndex(proxy_index)
        self.tree.verticalScrollBar().setValue(vertical)
        self.tree.horizontalScrollBar().setValue(horizontal)

    def _capture_detail_state(self):
        state = {
            "path": self._current_detail[1] if self._current_detail else None,
            "tab": self.tabs.currentIndex(),
            "array_selectors": [spin.value() for spin in self.array_view.spins],
            "table_vertical": self.table_view.verticalScrollBar().value(),
            "table_horizontal": self.table_view.horizontalScrollBar().value(),
            "table_current": (
                self.table_view.currentIndex().row(),
                self.table_view.currentIndex().column(),
            ),
        }
        return state

    def _restore_detail_state(self, state):
        path = state.get("path")
        if path is not None and path.root in self.snapshot:
            try:
                value = resolve_path(self.snapshot[path.root], path.steps)
                self._display_value(value, path, push=False)
            except Exception:
                pass
        self.tabs.setCurrentIndex(min(state.get("tab", 0), self.tabs.count() - 1))
        if self.data_stack.currentWidget() is self.array_view:
            for spin, selected in zip(
                self.array_view.spins, state.get("array_selectors", ())
            ):
                spin.setValue(min(spin.maximum(), max(spin.minimum(), selected)))
        elif self.data_stack.currentWidget() is self.table_view:
            row, column = state.get("table_current", (-1, -1))
            if (
                0 <= row < self.table_view.model().rowCount()
                and 0 <= column < self.table_view.model().columnCount()
            ):
                self.table_view.setCurrentIndex(self.table_view.model().index(row, column))
        self.table_view.verticalScrollBar().setValue(state.get("table_vertical", 0))
        self.table_view.horizontalScrollBar().setValue(state.get("table_horizontal", 0))

    @QtCore.pyqtSlot()
    def refresh(self, force=False):
        if (
            not force
            and (
                self.table_view.state() == QtWidgets.QAbstractItemView.EditingState
                or self.array_view.table.state()
                == QtWidgets.QAbstractItemView.EditingState
                or QtWidgets.QApplication.activePopupWidget() is not None
                or QtWidgets.QApplication.activeModalWidget() is not None
            )
        ):
            return
        expanded, selected, tree_vertical, tree_horizontal = self._capture_view_state()
        detail_state = self._capture_detail_state()
        previously_loaded = [
            node.path for node in self.tree_model.loaded_nodes() if node.path is not None
        ][:1000]
        try:
            snapshot = self.source.snapshot()
        except Exception as error:
            self.status.setText(f"Refresh failed: {type(error).__name__}: {error}")
            return
        generation = self.source.generation
        self.snapshot = snapshot
        self._mark_pending_conflicts(snapshot, generation)
        self.tree_model.set_snapshot(snapshot)
        self._restore_view_state(
            expanded, selected, tree_vertical, tree_horizontal
        )
        self._restore_detail_state(detail_state)

        candidates: OrderedDict[str, ValuePath] = OrderedDict()
        for node in self.tree_model.loaded_nodes():
            if node.path:
                candidates[node.path.key()] = node.path
        for path in previously_loaded:
            candidates.setdefault(path.key(), path)
        for key, (_fingerprint, _summary, path) in self._fingerprints.items():
            candidates.setdefault(key, path)

        current: dict[str, tuple[Any, str, ValuePath]] = {}
        scanned: set[str] = set()
        missing: set[str] = set()
        start = time.perf_counter()
        self._partial_scan = False
        for count, (key, path) in enumerate(candidates.items()):
            if count >= 1000 or (time.perf_counter() - start) >= 0.020:
                self._partial_scan = True
                break
            scanned.add(key)
            try:
                root = snapshot[path.root]
                value = resolve_path(root, path.steps)
            except Exception:
                missing.add(key)
                continue
            current[key] = (value_fingerprint(value), value_summary(value), path)
        # A bounded scan must not manufacture remove/add events for entries it
        # simply did not reach during this tick.  Retain their prior baseline.
        for key, previous in self._fingerprints.items():
            if key not in scanned and key not in missing:
                current.setdefault(key, previous)

        now = time.time()
        if self._baseline_ready:
            old_keys = set(self._fingerprints)
            new_keys = set(current)
            for key in sorted(new_keys - old_keys):
                fingerprint, summary, _path = current[key]
                if (
                    (not _path.steps and _path.root not in self._known_root_names)
                    or key in self._removed_path_keys
                ):
                    if _path.root not in self._suppress_next_roots:
                        self._record_change(now, key, "added", "", summary, generation)
                    self.tree_model.modified_paths[key] = (now, "added")
                    self._removed_path_keys.discard(key)
            for key in sorted(old_keys - new_keys):
                _fingerprint, summary, _path = self._fingerprints[key]
                root_name = _path.root
                if root_name not in snapshot or key in missing:
                    if root_name not in self._suppress_next_roots:
                        self._record_change(now, key, "removed", summary, "", generation)
                    self._removed_path_keys.add(key)
            for key in sorted(old_keys & new_keys):
                old_fp, old_summary, _old_path = self._fingerprints[key]
                new_fp, new_summary, _new_path = current[key]
                if old_fp != new_fp:
                    if _new_path.root not in self._suppress_next_roots:
                        self._record_change(
                            now, key, "changed", old_summary, new_summary, generation
                        )
                    self.tree_model.modified_paths[key] = (now, "changed")
            if generation != self._last_generation:
                self._record_change(
                    now,
                    "<Globals generation>",
                    "generation",
                    str(self._last_generation),
                    str(generation),
                    generation,
                )
        else:
            self._baseline_ready = True
        self._fingerprints = current
        self._known_root_names = set(snapshot)
        self._last_generation = generation
        self._suppress_next_roots.clear()
        self.tree_model.pending_paths = set(self.edit_session.edits)
        self.tree_model.error_paths = {
            key for key, edit in self.edit_session.edits.items() if edit.error
        }
        self.tree_model.refresh_decorations()
        self.tree.viewport().update()
        self._update_status()

    def _mark_pending_conflicts(self, snapshot, generation):
        if not self.edit_session.active:
            return
        root = snapshot.get(self.edit_session.root_name, _NO_VALUE)
        root_error = ""
        if generation != self.edit_session.generation:
            root_error = "Globals generation changed while edits were pending"
        elif root is _NO_VALUE:
            root_error = "The edited root variable was removed"
        elif root is not self.edit_session.root_object:
            root_error = "The edited root variable was replaced"
        for edit in self.edit_session.edits.values():
            if root_error:
                edit.error = root_error
                continue
            try:
                current = resolve_path(root, edit.path.steps)
                if value_fingerprint(current) != edit.expected_fingerprint:
                    edit.error = "The live leaf changed while this edit was pending"
            except Exception as error:
                edit.error = f"The edited path is no longer available: {error}"

    def _record_change(self, now, path, kind, old, new, generation, origin="runtime"):
        self.history_model.add(
            ChangeRecord(now, path, kind, old, new, generation, origin)
        )
        if self.history_model.records:
            self.history_view.scrollToBottom()

    def _update_status(self):
        sampling = "; partial bounded scan" if self._partial_scan else ""
        live = "live" if self.live.isChecked() else "paused"
        pending = len(self.edit_session.edits)
        conflicts = sum(bool(edit.error) for edit in self.edit_session.edits.values())
        conflict_text = f"; {conflicts} conflicts" if conflicts else ""
        self.status.setText(
            f"State: {self.source.state}  |  Generation: {self.source.generation}  |  "
            f"{len(self.snapshot)} variables  |  {live}{sampling}  |  "
            f"{pending} pending edits{conflict_text}"
        )

    def _source_node(self, proxy_index):
        if not proxy_index.isValid():
            return None
        return self.proxy.mapToSource(proxy_index).internalPointer()

    def _tree_selection_changed(self, current, previous):
        node = self._source_node(current)
        if node and node.path:
            self._detail_history.clear()
            self._display_value(node.value, node.path, push=False)

    def _tree_double_clicked(self, index):
        node = self._source_node(index)
        if node and node.path and not node.total and can_edit_value(node.value):
            self.edit_value(node.path, node.value)

    def _tree_menu(self, position):
        index = self.tree.indexAt(position)
        node = self._source_node(index)
        if node is None or node.path is None:
            return
        menu = QtWidgets.QMenu(self.tree)
        edit = menu.addAction("Edit value…")
        root = self.snapshot.get(node.path.root)
        edit.setEnabled(root is not None and is_editable_path(root, node.path))
        edit.triggered.connect(lambda: self.edit_value(node.path, node.value))
        copy_path = menu.addAction("Copy path")
        copy_path.triggered.connect(
            lambda: QtWidgets.QApplication.clipboard().setText(node.path.display())
        )
        copy_value = menu.addAction("Copy safe representation")
        copy_value.triggered.connect(
            lambda: QtWidgets.QApplication.clipboard().setText(
                safe_details_repr(node.value)
            )
        )
        menu.addSeparator()
        refresh = menu.addAction("Refresh")
        refresh.triggered.connect(lambda: self.refresh(force=True))
        menu.exec_(self.tree.viewport().mapToGlobal(position))

    def _display_value(self, value, path: ValuePath, *, push=True):
        if push and self._current_detail is not None:
            self._detail_history.append(self._current_detail)
        self._current_detail = (value, path)
        self.back_button.setEnabled(bool(self._detail_history))
        self.detail_title.setText(path.display())
        metadata = self.source.metadata(path.root)
        lines = [
            f"Path: {path.display()}",
            f"Type: {type(value).__module__}.{type(value).__qualname__}",
            f"Identity: 0x{id(value):x}",
            f"Summary: {value_summary(value)}",
            f"Info: {value_info(value)}",
            f"Approximate size: {human_size(_safe_size(value)) or 'unknown'}",
        ]
        if metadata:
            lines.append("")
            lines.append("Global declaration:")
            lines.extend(f"  {key}: {item}" for key, item in metadata.items() if item not in (None, ""))
        self.summary.setPlainText("\n".join(lines))
        self.representation.setPlainText(safe_details_repr(value)[:MAX_REPR])
        self.attribute_model.set_value(value)
        self._set_data_value(value, path)

    def _set_data_value(self, value, path):
        source_model = None
        self._current_table_path = ""
        old_proxy = self.table_view.model()
        if old_proxy is not None:
            old_source = (
                old_proxy.sourceModel()
                if isinstance(old_proxy, QtCore.QSortFilterProxyModel)
                else None
            )
            self.table_view.setModel(None)
            old_proxy.deleteLater()
            if old_source is not None:
                old_source.deleteLater()
        if isinstance(value, np.ndarray):
            self.array_view.set_array(
                value, path, self._stage_text, self.edit_session.pending
            )
            self.data_stack.setCurrentWidget(self.array_view)
            return
        if isinstance(value, Styler):
            value = value.data
            path = path.child(PathStep("styler_data", None))
            source_model = PandasTableModel(
                value, path, self._stage_text, self.edit_session.pending, editable=False
            )
        elif isinstance(value, (pd.DataFrame, pd.Series, pd.Index)):
            source_model = PandasTableModel(
                value,
                path,
                self._stage_text,
                self.edit_session.pending,
                editable=not isinstance(value, pd.Index),
            )
        elif isinstance(value, (list, tuple, deque, _array.array)):
            source_model = SequenceTableModel(
                value, path, self._stage_text, self.edit_session.pending
            )
        elif isinstance(value, Mapping):
            source_model = MappingTableModel(
                value, path, self._stage_text, self.edit_session.pending
            )
        if source_model is None:
            self.table_view.setModel(None)
            self.table_view.horizontalHeader().setSortIndicatorShown(False)
            self.data_stack.setCurrentWidget(self.data_empty)
            return
        proxy = DataSortProxy(self.table_view)
        proxy.setSourceModel(source_model)
        proxy.setDynamicSortFilter(False)
        proxy.sort(-1)
        self.table_view.setModel(proxy)
        self.table_view._source_model = source_model
        self.table_view._proxy_model = proxy
        self.table_view.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.Interactive
        )
        self._current_table_path = path.key()
        sort_state = self._table_sorts.get(self._current_table_path)
        self._setting_table_sort = True
        try:
            self.table_view.horizontalHeader().setSortIndicatorShown(bool(sort_state))
            if sort_state is not None:
                self.table_view.sortByColumn(*sort_state)
        finally:
            self._setting_table_sort = False
        self.data_stack.setCurrentWidget(self.table_view)

    def _table_sort_changed(self, column, order):
        if self._setting_table_sort or not self._current_table_path:
            return
        self._table_sorts[self._current_table_path] = (column, order)
        self.table_view.horizontalHeader().setSortIndicatorShown(True)

    def _detail_back(self):
        if not self._detail_history:
            return
        value, path = self._detail_history.pop()
        self._display_value(value, path, push=False)
        self.back_button.setEnabled(bool(self._detail_history))

    def _table_double_clicked(self, index):
        model = self.table_view.model()
        if isinstance(model, QtCore.QSortFilterProxyModel):
            source_index = model.mapToSource(index)
            source_model = model.sourceModel()
        else:
            source_index = index
            source_model = model
        if not hasattr(source_model, "value_for_index"):
            return
        try:
            value = source_model.value_for_index(source_index)
            path = source_model.path_for_index(source_index)
        except Exception:
            return
        if path is not None and not can_edit_value(value):
            self._display_value(value, path, push=True)

    def _array_menu(self, position):
        model = self.array_view.model
        if model is None:
            return
        indexes = self.array_view.table.selectedIndexes()
        menu = QtWidgets.QMenu(self.array_view.table)
        stage = menu.addAction("Set selected cells…")
        stage.setEnabled(bool(indexes) and len(indexes) <= 10_000)
        stage.setToolTip("Selections larger than 10,000 cells are not staged at once")
        stage.triggered.connect(lambda: self._stage_array_selection(indexes))
        copy_action = menu.addAction("Copy selection")
        copy_action.setEnabled(bool(indexes))
        copy_action.triggered.connect(
            lambda: self._copy_table_selection(self.array_view.table)
        )
        menu.exec_(self.array_view.table.viewport().mapToGlobal(position))

    def _stage_array_selection(self, indexes):
        model = self.array_view.model
        if model is None or not indexes:
            return
        if len(indexes) > 10_000:
            QtWidgets.QMessageBox.warning(
                self, "Selection too large", "Select at most 10,000 array cells."
            )
            return
        first = model.value_for_index(indexes[0])
        text, accepted = QtWidgets.QInputDialog.getText(
            self,
            "Stage array selection",
            f"New value for {len(indexes)} selected cells:",
            text=editable_text(first),
        )
        if not accepted:
            return
        prepared = []
        try:
            for index in indexes:
                old = model.value_for_index(index)
                if not can_edit_value(old):
                    raise ValueError(
                        f"{model.path_for_index(index).display()} is not a scalar cell"
                    )
                prepared.append(
                    (model.path_for_index(index), old, parse_edited_value(text, old))
                )
        except Exception as error:
            QtWidgets.QMessageBox.warning(
                self, "Invalid selection value", f"No cells were staged.\n\n{error}"
            )
            return
        if not self._prepare_root_switch(prepared[0][0].root):
            return
        blocker = QtCore.QSignalBlocker(self.edit_session)
        try:
            for path, old, parsed in prepared:
                self.edit_session.stage(
                    self.source, self.snapshot, path, old, parsed
                )
        finally:
            del blocker
        self.edit_session.changed.emit()

    @staticmethod
    def _copy_table_selection(table):
        indexes = sorted(table.selectedIndexes(), key=lambda item: (item.row(), item.column()))
        if not indexes:
            return
        rows: dict[int, dict[int, str]] = {}
        for index in indexes:
            rows.setdefault(index.row(), {})[index.column()] = str(index.data())
        minimum = min(index.column() for index in indexes)
        maximum = max(index.column() for index in indexes)
        text = "\n".join(
            "\t".join(columns.get(column, "") for column in range(minimum, maximum + 1))
            for _row, columns in sorted(rows.items())
        )
        QtWidgets.QApplication.clipboard().setText(text)

    def _prepare_root_switch(self, root_name: str) -> bool:
        if not self.edit_session.active or self.edit_session.root_name == root_name:
            return True
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle("Pending edits")
        box.setText(
            f"Apply or discard pending edits for {self.edit_session.root_name!r} "
            f"before editing {root_name!r}."
        )
        apply_button = box.addButton("Apply", QtWidgets.QMessageBox.AcceptRole)
        discard_button = box.addButton("Discard", QtWidgets.QMessageBox.DestructiveRole)
        box.addButton(QtWidgets.QMessageBox.Cancel)
        box.exec_()
        if box.clickedButton() is apply_button:
            return self.apply_edits()
        if box.clickedButton() is discard_button:
            self.edit_session.discard()
            return True
        return False

    def edit_value(self, path: ValuePath, old_value: Any):
        root = self.snapshot.get(path.root, _NO_VALUE)
        if root is _NO_VALUE or not is_editable_path(root, path):
            QtWidgets.QMessageBox.information(
                self,
                "Read-only value",
                "This value or one of its containers is not safely editable.",
            )
            return
        current = (
            self.edit_session.pending(path).new_value
            if self.edit_session.pending(path)
            else old_value
        )
        initial = editable_text(current)
        text, accepted = QtWidgets.QInputDialog.getMultiLineText(
            self, "Stage value edit", path.display(), initial
        )
        if accepted:
            self._stage_text(path, old_value, text)

    def _stage_text(self, path: ValuePath, old_value: Any, text: str) -> bool:
        if not self._prepare_root_switch(path.root):
            return False
        root = self.snapshot.get(path.root, _NO_VALUE)
        if root is _NO_VALUE or not is_editable_path(root, path):
            QtWidgets.QMessageBox.warning(
                self, "Read-only value", f"{path.display()} is not safely editable."
            )
            return False
        try:
            parsed = parse_edited_value(text, old_value)
            self.edit_session.stage(self.source, self.snapshot, path, old_value, parsed)
        except Exception as error:
            QtWidgets.QMessageBox.warning(
                self, "Invalid value", f"Could not stage {path.display()}:\n{error}"
            )
            return False
        return True

    def apply_edits(self) -> bool:
        if not self.edit_session.active:
            return True
        edits = list(self.edit_session.edits.values())
        root_name = self.edit_session.root_name
        old_summaries = {edit.path.key(): value_summary(edit.old_value) for edit in edits}
        try:
            self.edit_session.apply(self.source)
        except EditConflictError as error:
            QtWidgets.QMessageBox.warning(
                self,
                "Edit conflict",
                f"No edits were applied. Refresh and review the pending values.\n\n{error}",
            )
            return False
        except Exception as error:
            QtWidgets.QMessageBox.warning(
                self, "Apply failed", f"No edits were applied.\n\n{type(error).__name__}: {error}"
            )
            return False
        now = time.time()
        generation = self.source.generation
        self._suppress_next_roots.add(root_name)
        for edit in edits:
            self._record_change(
                now,
                edit.path.display(),
                "edited",
                old_summaries[edit.path.key()],
                value_summary(edit.new_value),
                generation,
                origin="explorer",
            )
            self.tree_model.modified_paths[edit.path.key()] = (now, "changed")
        self.refresh(force=True)
        if root_name in self.snapshot:
            root = self.snapshot[root_name]
            current_path = self._current_detail[1] if self._current_detail else ValuePath(root_name)
            try:
                self._display_value(resolve_path(root, current_path.steps), current_path, push=False)
            except Exception:
                pass
        return True

    def _pending_changed(self):
        active = self.edit_session.active
        self.apply_button.setEnabled(active)
        self.discard_button.setEnabled(active)
        self.apply_button.setText(
            f"Apply ({len(self.edit_session.edits)})" if active else "Apply"
        )
        self.tree_model.pending_paths = set(self.edit_session.edits)
        self.tree_model.error_paths = {
            key for key, edit in self.edit_session.edits.items() if edit.error
        }
        self.tree_model.refresh_decorations()
        self.tree.viewport().update()
        self._update_status()
        models = [self.array_view.model]
        table_model = self.table_view.model()
        if isinstance(table_model, QtCore.QSortFilterProxyModel):
            models.append(table_model.sourceModel())
        elif table_model is not None:
            models.append(table_model)
        for model in models:
            if model is None or model.rowCount() <= 0 or model.columnCount() <= 0:
                continue
            model.dataChanged.emit(
                model.index(0, 0),
                model.index(model.rowCount() - 1, model.columnCount() - 1),
                [QtCore.Qt.DisplayRole, QtCore.Qt.BackgroundRole],
            )

    def request_close(self) -> bool:
        if not self.edit_session.active:
            return True
        reply = QtWidgets.QMessageBox.question(
            self,
            "Discard pending edits?",
            "Closing Variable Explorer will discard staged edits. Continue?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No,
        )
        if reply == QtWidgets.QMessageBox.Yes:
            self.edit_session.discard()
            return True
        return False


class VariableExplorerWindow(QtWidgets.QMainWindow):
    def __init__(self, runtime=None, parent=None):
        super().__init__(parent)
        self._application_shutdown = False
        self.setWindowTitle("Variable Explorer — Application Globals")
        self.resize(1300, 820)
        self.explorer = VariableExplorerWidget(
            GlobalsVariableSource(runtime), runtime=runtime, parent=self
        )
        self.setCentralWidget(self.explorer)
        if runtime is not None:
            for signal_name in ("state_changed", "ready", "reload_finished"):
                signal = getattr(runtime, signal_name, None)
                if signal is not None:
                    signal.connect(self._runtime_changed)

    def _runtime_changed(self, *args):
        if self.explorer.live.isChecked():
            QtCore.QTimer.singleShot(0, lambda: self.explorer.refresh(force=True))

    def prepare_application_shutdown(self):
        self._application_shutdown = True
        self.explorer.edit_session.discard()
        self.explorer._timer.stop()

    def closeEvent(self, event):
        if self._application_shutdown or self.explorer.request_close():
            self.explorer._timer.stop()
            event.accept()
        else:
            event.ignore()


class VariableExplorer(QtCore.QObject):
    """IDE-compatible dock wrapper around :class:`VariableExplorerWidget`."""

    def __init__(self, parent: QtWidgets.QMainWindow):
        super().__init__(parent)
        self.parent = parent
        self.source = EnvironmentVariableSource()
        self.widget = VariableExplorerWidget(self.source, parent=parent)
        self.dock = QtWidgets.QDockWidget("Variable Explorer", parent)
        self.dock.setObjectName("VariableExplorerDock")
        self.dock.setWidget(self.widget)
        self.dock.setAllowedAreas(
            QtCore.Qt.BottomDockWidgetArea
            | QtCore.Qt.LeftDockWidgetArea
            | QtCore.Qt.RightDockWidgetArea
        )
        self.dock.setFeatures(
            QtWidgets.QDockWidget.DockWidgetFloatable
            | QtWidgets.QDockWidget.DockWidgetMovable
            | QtWidgets.QDockWidget.DockWidgetClosable
        )
        parent.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.dock)
        self.dock.hide()

    def update(self, env: dict):
        self.source.set_mapping(env)
        self.source.touch()
        self.widget.refresh(force=True)

    def show(self):
        self.dock.show()

    def hide(self):
        self.dock.hide()


__all__ = [
    "AdapterRegistry",
    "ChangeRecord",
    "EditConflictError",
    "EnvironmentVariableSource",
    "GlobalsVariableSource",
    "PathStep",
    "PendingEdit",
    "ValueAdapter",
    "ValuePath",
    "VariableExplorer",
    "VariableExplorerWidget",
    "VariableExplorerWindow",
    "apply_copy_on_write",
    "parse_edited_value",
    "resolve_path",
    "safe_repr",
    "value_fingerprint",
]
