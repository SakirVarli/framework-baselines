"""Application-specific code kept outside callbacks.py.

Keep functions independent of Qt when possible.  callbacks.py may import these
functions with ``from externals.helpers import ...``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_json_records(path: str | Path) -> list[dict[str, Any]]:
    """Load and validate a JSON list of objects."""
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, list) or not all(isinstance(row, dict) for row in value):
        raise ValueError("Expected a JSON array of objects")
    return value


def parse_message(payload: bytes, context: dict | None = None) -> dict[str, Any]:
    """Communication Hub parser example: decode one JSON message."""
    data = json.loads(payload.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Expected a JSON object")
    return {"Name": str(data.get("type", "Message")), **data}


def process_insight_value(value: Any, context: dict | None = None) -> Any:
    """Protocol Insight processor example: normalize a numeric value."""
    return None if value is None else float(value)
