from __future__ import annotations

import ast
import keyword
import re
import struct
import math
from dataclasses import dataclass, replace
from typing import Any

from .model import FORMAT_NAME, PACKAGE_RE, SCHEMA_VERSION, normalize_manifest, walk_fields
from .behavior_identity import resolve_behavior_classes
from .object_defaults import array_item_owner, guided_errors, guided_supported, guided_expression, _bitfield_name, _inline_name
from .enum_schema import value_range, reserved_members, reserved_definition_names
from .field_capabilities import automatic_default_available as _automatic_default_available
from .data_definitions import DATA_MODES, encoding_error, value_errors as data_value_errors
from .field_references import scope_candidates, dependency_available
from .field_logic import effective_expression, fallback_case, fallback_expression, TYPED_VALUE_KINDS, option_errors
from .scalar_definitions import scalar_errors
from .dependency_graph import build_cycles
from .array_definitions import ARRAY_MODES, PREFIX_FORMATS, prefix_expression, literal_initial_count, expression_paths


_UNKNOWN_LITERAL = object()


RESERVED_MEMBERS = {
    "WIRE_SCHEMA", "MESSAGE_ID", "MESSAGE_NAME", "codec", "decode", "encode",
    "from_bytes", "to_bytes", "send",
    '_ARRAY_INITIALIZERS', '_FIELD_INITIALIZERS', '_FIELD_ENCODINGS', '_DEFAULT_VALUE_SCHEMA',
}
FIELD_KINDS = {
    "uint", "int", "bytes_integer", "varint", "zigzag", "float", "bool",
    "enum", "bytes", "string", "bitfield", "array", "struct", "inline_struct", "conditional",
    "switch", "const", "default", "padding", "aligned", "computed", "rebuild",
    "checksum", "advanced",
}


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    severity: str
    code: str
    message: str
    uid: str = ""
    path: str = ""
    phase: str = "definition"
    option: str = ""

    @property
    def blocking(self) -> bool:
        return self.severity == "error"


def _identifier(value: Any) -> bool:
    return isinstance(value, str) and value.isidentifier() and not keyword.iskeyword(value)


def _parse_expression(expression: Any) -> bool:
    if not isinstance(expression, str) or not expression.strip():
        return False
    try:
        ast.parse(expression, mode="eval")
        return True
    except SyntaxError:
        return False


def validate_manifest(data: dict[str, Any]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    if data.get("schema_version") in range(1, SCHEMA_VERSION + 1):
        data = normalize_manifest(data)
    if data.get("format") != FORMAT_NAME:
        issues.append(ValidationIssue("error", "format", "Not a SAKiR message-library manifest."))
    if data.get("schema_version") != SCHEMA_VERSION:
        issues.append(ValidationIssue("error", "version", f"Unsupported manifest version: {data.get('schema_version')}"))

    library = data.get("library", {})
    package_name = library.get("package_name", "")
    if not PACKAGE_RE.fullmatch(str(package_name)):
        issues.append(ValidationIssue("error", "package-name", "Package name must be a Python identifier.", library.get("uid", "")))
    for statement in library.get("extra_imports", []):
        try:
            parsed = ast.parse(statement)
            if len(parsed.body) != 1 or not isinstance(parsed.body[0], (ast.Import, ast.ImportFrom)):
                raise SyntaxError
        except (SyntaxError, TypeError):
            issues.append(ValidationIssue("error", "extra-import", f"Invalid import statement: {statement!r}.", library.get("uid", "")))

    all_uids: set[str] = set()
    for category in ("enums", "structures", "groups", "messages"):
        for item in data.get(category, []):
            uid = item.get("uid", "")
            if not uid or uid in all_uids:
                issues.append(ValidationIssue("error", "duplicate-uid", "Every definition needs a unique stable ID.", uid))
            all_uids.add(uid)

    enums = {item.get("uid"): item for item in data.get("enums", [])}
    structures = {item.get("uid"): item for item in data.get("structures", [])}
    groups = {item.get("uid"): item for item in data.get("groups", [])}
    type_names: dict[str, str] = {}
    generated_names = {item.get('name', '') + 'Schema' for item in structures.values()}
    generated_names.update({'AUTO_ARRAY', 'ArrayCodec', 'IndexedSwitch', 'DynamicSwitch', 'BranchDefault', 'initialize_arrays', 'initialize_fields',
                            'DataCodec', 'data_length', 'ConditionalIf', 'WireCapture', 'captured_data', 'ScalarLimits', 'PaddingBytes', 'AlignedValue', 'StrictEnum'})
    generated_names.update(item.get('behavior_class') or item.get('name', '') + 'Behavior' for item in data.get('messages', []))
    for item in [*enums.values(), *structures.values(), *data.get("messages", [])]:
        name = item.get("name", "")
        uid = item.get("uid", "")
        if not _identifier(name):
            issues.append(ValidationIssue("error", "identifier", f"'{name}' is not a valid Python class name.", uid))
        elif name in type_names:
            issues.append(ValidationIssue("error", "duplicate-type", f"Duplicate type name '{name}'.", uid))
        elif name in reserved_definition_names() or name in generated_names:
            issues.append(ValidationIssue('error', 'reserved-type', f"The name '{name}' conflicts with a generated import or built-in type; rename it.", uid))
        type_names[name] = uid

    _validate_generated_value_names(data, set(type_names) | generated_names, issues)

    for enum in enums.values():
        if enum.get('unknown_policy', 'preserve') not in {'preserve', 'reject'}:
            issues.append(ValidationIssue('error', 'enum-unknown-policy', 'Choose preserve or reject for unknown numeric enum values.', enum['uid']))
        names: set[str] = set()
        values: set[int] = set()
        bounds = None
        try:
            bounds = value_range(enum)
        except (ValueError, TypeError) as error:
            issues.append(ValidationIssue("error", "enum-storage", str(error), enum["uid"]))
        reserved = reserved_members()
        for member in enum.get("values", []):
            name, value = member.get("name", ""), member.get("value")
            if not _identifier(name):
                issues.append(ValidationIssue("error", "enum-name", f"Invalid enum member '{name}'.", enum["uid"]))
            if name in names:
                issues.append(ValidationIssue("error", "enum-name", f"Duplicate enum member '{name}'.", enum["uid"]))
            if isinstance(name, str) and (name in reserved or name.startswith('_')):
                issues.append(ValidationIssue("error", "enum-member-reserved", f"Enum member '{name}' conflicts with Construct attribute access; rename it.", enum["uid"]))
            if not isinstance(value, int) or isinstance(value, bool):
                issues.append(ValidationIssue("error", "enum-value", f"Enum value for '{name}' must be an integer.", enum["uid"]))
            elif value in values:
                issues.append(ValidationIssue("warning", "enum-alias", f"Enum value {value} is an alias.", enum["uid"]))
            if type(value) is int and bounds and not bounds[0] <= value <= bounds[1]:
                issues.append(ValidationIssue("error", "enum-range", f"Enum member '{name}' must be between {bounds[0]} and {bounds[1]} for its storage subtype.", enum["uid"]))
            names.add(name)
            if type(value) is int:
                values.add(value)

    group_names = set()
    for group in groups.values():
        uid = group.get('uid', '')
        name = group.get('name', '')
        if not isinstance(name, str) or not name.strip() or name.casefold() in group_names:
            issues.append(ValidationIssue('error', 'group-name', 'Group names must be nonempty and unique.', uid))
        group_names.add(str(name).casefold())
        parent_uid = group.get('parent_group_uid', '')
        if parent_uid and parent_uid != library.get('uid') and parent_uid not in groups:
            issues.append(ValidationIssue('error', 'group-parent', 'Group references a missing parent.', uid))
    _validate_group_cycles(groups, issues)

    behavior_names: set[str] = set()
    registry_names: set[str] = set()
    for message in data.get("messages", []):
        group_uid = message.get("group_uid") or library.get("uid")
        if group_uid != library.get("uid") and group_uid not in groups:
            issues.append(ValidationIssue("error", "message-group", "Message references a missing group.", message.get("uid", "")))
        direction = str(message.get("direction", message.get("tx_rx", "ANY"))).upper()
        if direction not in {"TX", "RX", "ANY"}:
            issues.append(ValidationIssue("error", "message-direction", "Direction must be TX, RX, or ANY.", message.get("uid", "")))
        behavior = message.get("behavior_class", "")
        if not _identifier(behavior):
            issues.append(ValidationIssue("error", "behavior-name", f"Invalid behavior class '{behavior}'.", message.get("uid", "")))
        elif behavior in behavior_names:
            issues.append(ValidationIssue("error", "behavior-name", f"Duplicate behavior class '{behavior}'.", message.get("uid", "")))
        behavior_names.add(behavior)
        registry_name = message.get("display_name") or message.get("name")
        if registry_name in registry_names:
            issues.append(ValidationIssue("error", "registry-name", f"Duplicate message registry name '{registry_name}'.", message.get("uid", "")))
        registry_names.add(registry_name)
        _validate_members(message, enums, structures, issues)

    for structure in structures.values():
        _validate_fields(structure.get("fields", []), enums, structures, issues, structure.get("uid", ""),
                         path=structure.get('name', ''), visiting=frozenset({structure.get('uid')}))
    _validate_cycles(structures, issues)
    _validate_new_routing(data, issues)
    return issues


def validate_behavior_methods(source: str | None, messages: list[dict[str, Any]]) -> list[ValidationIssue]:
    """Report behavior-file drift without modifying user-owned method bodies."""
    issues: list[ValidationIssue] = []
    if source is None:
        for message in messages:
            for method in message.get("methods", []):
                issues.append(ValidationIssue(
                    "warning", "empty-method",
                    f"Method {message['behavior_class']}.{method['name']} has an empty generated stub.",
                    method.get("uid", ""),
                ))
        return issues
    try:
        _, _, classes = resolve_behavior_classes(source, messages)
    except SyntaxError as error:
        return [ValidationIssue("error", "behavior-syntax", f"behaviors.py has invalid syntax: {error}")]
    except ValueError as error:
        return [ValidationIssue("error", "behavior-identity", str(error))]
    for message in messages:
        class_name = message.get("behavior_class", "")
        class_node = classes.get(class_name)
        if class_node is None:
            issues.append(ValidationIssue(
                "warning", "missing-behavior-class",
                f"Behavior mixin {class_name} is missing from behaviors.py; it will be recreated on save.",
                message.get("uid", ""),
            ))
            continue
        methods = {
            node.name: node for node in class_node.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        if "send" in methods:
            issues.append(ValidationIssue(
                "error", "reserved-behavior-method",
                f"Method {class_name}.send overrides the BinaryMessage send API; rename it in behaviors.py.",
                message.get("uid", ""),
            ))
        for declaration in message.get("methods", []):
            label = f"{class_name}.{declaration['name']}"
            node = methods.get(declaration["name"])
            if node is None:
                issues.append(ValidationIssue(
                    "warning", "missing-method",
                    f"Method {label} is missing from behaviors.py; it will be recreated on save.",
                    declaration.get("uid", ""),
                ))
                continue
            actual_kind = _behavior_method_kind(node)
            expected_kind = declaration.get("kind", "instance")
            if actual_kind != expected_kind:
                issues.append(ValidationIssue(
                    "warning", "method-kind-drift",
                    f"Method {label} is {actual_kind} in behaviors.py but {expected_kind} in the designer; save will restore the designer kind.",
                    declaration.get("uid", ""),
                ))
            if not _behavior_signature_matches(node, expected_kind):
                issues.append(ValidationIssue(
                    "warning", "method-signature-drift",
                    f"Method {label} does not have the default {expected_kind} signature; save will restore it while preserving the body.",
                    declaration.get("uid", ""),
                ))
            if _empty_method_body(node.body):
                issues.append(ValidationIssue(
                    "warning", "empty-method", f"Method {label} is empty.", declaration.get("uid", ""),
                ))
    return issues


def _behavior_method_kind(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    if isinstance(node, ast.AsyncFunctionDef):
        return "async"
    decorators = {
        decorator.id for decorator in node.decorator_list if isinstance(decorator, ast.Name)
    }
    for kind in ("class", "static", "property"):
        decorator = "classmethod" if kind == "class" else ("staticmethod" if kind == "static" else "property")
        if decorator in decorators:
            return kind
    return "instance"


def _empty_method_body(statements: list[ast.stmt]) -> bool:
    body = list(statements)
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body.pop(0)
    return not body or all(isinstance(statement, ast.Pass) for statement in body)


def _behavior_signature_matches(node: ast.FunctionDef | ast.AsyncFunctionDef, kind: str) -> bool:
    expected = ["cls"] if kind == "class" else ([] if kind == "static" else ["self"])
    arguments = node.args
    positional = [*arguments.posonlyargs, *arguments.args]
    return (
        [argument.arg for argument in positional] == expected
        and all(argument.annotation is None for argument in positional)
        and not arguments.vararg
        and not arguments.kwarg
        and not arguments.kwonlyargs
        and not arguments.defaults
        and not arguments.kw_defaults
        and node.returns is None
    )


def _validate_members(message, enums, structures, issues):
    names: set[str] = set()
    for category in ("fields", "runtime_attributes", "constants", "methods"):
        for item in message.get(category, []):
            name = item.get("name", "")
            if not _identifier(name):
                issues.append(ValidationIssue("error", "member-name", f"Invalid member name '{name}'.", item.get("uid", "")))
            if name in names or name in RESERVED_MEMBERS:
                issues.append(ValidationIssue("error", "member-collision", f"Member name '{name}' is duplicated or reserved.", item.get("uid", "")))
            names.add(name)
    _validate_fields(message.get("fields", []), enums, structures, issues, message.get("uid", ""), path=message.get('name', ''))
    for method in message.get("methods", []):
        if method.get("kind") not in {"instance", "class", "static", "async", "property"}:
            issues.append(ValidationIssue("error", "method-kind", "Unknown method kind.", method.get("uid", "")))
    for item in [*message.get("runtime_attributes", []), *message.get("constants", [])]:
        annotation = item.get("annotation", "")
        if annotation and not _parse_expression(annotation):
            issues.append(ValidationIssue("error", "attribute-annotation", f"Invalid annotation '{annotation}'.", item.get("uid", "")))
        expression = item.get("default") if item in message.get("runtime_attributes", []) else item.get("value")
        if expression and not _parse_expression(expression):
            issues.append(ValidationIssue("error", "attribute-default", f"Invalid value expression '{expression}'.", item.get("uid", "")))


def _validate_generated_value_names(data, names, issues):
    """Reject any remaining Python symbol collisions before importing generated code."""
    def visit(fields, owner):
        for field in fields:
            kind = field.get("kind")
            name = str(field.get("name", ""))
            if kind in {"inline_struct", "bitfield"}:
                class_name = _inline_name(owner, name) if kind == "inline_struct" else _bitfield_name(owner, name)
                if class_name in names:
                    issues.append(ValidationIssue("error", "generated-type-collision",
                                                  f"Generated class '{class_name}' is already used. Rename the field or containing array.", field.get("uid", "")))
                names.add(class_name)
                if kind == "inline_struct":
                    visit(field.get("fields", []), class_name)
            item = field.get("item")
            if isinstance(item, dict):
                item_owner = array_item_owner(owner, {"name": name}) if kind == "array" else owner
                visit([item], item_owner)
            for index, case in enumerate(field.get('cases', [])):
                if isinstance(case.get('item'), dict):
                    case_owner = owner + ''.join(part.capitalize() for part in name.split('_')) + f"Case{case.get('class_index', index)}"
                    visit([case['item']], case_owner)

    for definition in [*data.get("structures", []), *data.get("messages", [])]:
        visit(definition.get("fields", []), str(definition.get("name", "")))


def _validate_fields(fields, enums, structures, issues, owner_uid, prior_context=None, ancestors=(), *, path='', visiting=frozenset()):
    prior_fields = dict(prior_context or {})
    prior_names = set(prior_fields)
    for depth, ancestor in enumerate(ancestors, 1):
        for key, value in ancestor.items():
            prior_fields['_.' * depth + key] = value
    prior_names.update(prior_fields)
    seen: set[str] = set()
    default_seen = False
    derived_names = {field.get('count_field') for field in fields if field.get('kind') == 'array'
                     and field.get('mode') == 'count_field' and field.get('rebuild_count')
                     and field.get('initial_policy') == 'resolve'}
    derived_names.update(field.get('length_field') for field in fields if field.get('kind') in {'bytes', 'string'}
                         and field.get('mode') == 'count_field' and field.get('rebuild_length'))
    for field in fields:
        issue_start = len(issues)
        field = dict(field)
        scope_fields = list({f.get('uid'): f for f in [*(v for k, v in prior_fields.items() if not k.startswith('_.')), *fields]}.values())
        manifest_view = {'enums': list(enums.values()), 'structures': list(structures.values()),
                         'messages': [{'fields': scope_fields}], 'reference_fields': prior_fields}
        for option in {'conditional': ('condition',), 'switch': ('selector',), 'computed': ('expression',),
                       'rebuild': ('expression',), 'checksum': ('source',)}.get(field.get('kind'), ()):
            try:
                field[option] = effective_expression(field, option, manifest_view)
            except ValueError as error:
                issues.append(ValidationIssue('error', 'field-expression', str(error), field.get('uid', owner_uid), option=option))
        uid, name, kind = field.get("uid", owner_uid), field.get("name", ""), field.get("kind")
        field_path = f'{path}.{name}' if path else name
        for error in option_errors(field):
            issues.append(ValidationIssue('error', 'field-option', error, uid))
        if not _identifier(name):
            issues.append(ValidationIssue("error", "field-name", f"Invalid field name '{name}'.", uid))
        if name in seen:
            issues.append(ValidationIssue("error", "duplicate-field", f"Duplicate field '{name}'.", uid))
        seen.add(name)
        if kind not in FIELD_KINDS:
            issues.append(ValidationIssue("error", "field-kind", f"Unknown field kind '{kind}'.", uid))
            continue
        if kind != "padding" and name not in derived_names:
            default_mode = field.get("object_default_mode", "required")
            initialization_field = field
            if (kind == 'array' and field.get('mode') == 'count_field' and field.get('initial_policy') == 'resolve'
                    and field.get('initial_count') is None and not field.get('rebuild_count')):
                known_count = _known_integer_default(prior_fields.get(field.get('count_field'), {}), enums)
                if known_count is not None:
                    initialization_field = {**field, 'initial_count': known_count}
            if default_mode not in {"required", "automatic", "custom", "guided"}:
                issues.append(ValidationIssue("error", "object-default-mode", "Object default must be Required, Automatic, Guided, or Python expression.", uid))
            elif default_mode == "custom" and not _parse_expression(field.get("object_default")):
                issues.append(ValidationIssue("error", "object-default-expression", "Custom object default must be a valid Python expression.", uid))
            elif default_mode == "automatic" and not _automatic_default_available(initialization_field, enums, structures, set()):
                issues.append(ValidationIssue(
                    "error", "object-default-unavailable",
                    "An automatic object default cannot be created for this field. Add defaults to required nested fields or use a custom expression.", uid,
                ))
            elif default_mode == "guided":
                manifest_view = {"enums": list(enums.values()), "structures": list(structures.values())}
                if not guided_supported(field, manifest_view):
                    issues.append(ValidationIssue(
                        "error", "object-default-guided-unavailable",
                        "A guided object default is unavailable until this field's type references are complete.", uid,
                    ))
                else:
                    for message in guided_errors(field, field.get("object_default_value"), manifest_view):
                        issues.append(ValidationIssue("error", "object-default-guided", message, uid))
            if default_mode == "required":
                if default_seen:
                    issues.append(ValidationIssue(
                        "error", "required-after-default",
                        "Required fields must appear before fields with object defaults.", uid,
                    ))
            else:
                default_seen = True
        if kind in {"uint", "int"} and field.get("width") not in {1, 2, 3, 4, 8}:
            issues.append(ValidationIssue("error", "integer-width", "Integer width must be 1, 2, 3, 4, or 8 bytes.", uid))
        if kind == 'bytes_integer' and (type(field.get('length')) is not int or field['length'] <= 0):
            issues.append(ValidationIssue('error', 'integer-length', 'Byte integer length must be a positive integer.', uid))
        if kind == "float" and field.get("width") not in {2, 4, 8}:
            issues.append(ValidationIssue("error", "float-width", "Float width must be 2, 4, or 8 bytes.", uid))
        if kind in {'uint', 'int', 'bytes_integer', 'varint', 'zigzag', 'float'}:
            if type(field.get('finite_only', False)) is not bool:
                issues.append(ValidationIssue('error', 'scalar-limit', 'Finite-only must be a boolean setting.', uid))
            for key in ('minimum', 'maximum'):
                bound = field.get(key)
                allowed = {int, float} if kind == 'float' else {int}
                if bound is not None and (type(bound) not in allowed or type(bound) is float and not math.isfinite(bound)):
                    issues.append(ValidationIssue('error', 'scalar-limit', f'{key} must be a finite number or unset.', uid))
            lower, upper = field.get('minimum'), field.get('maximum')
            if type(lower) in {int, float} and type(upper) in {int, float} and lower > upper:
                issues.append(ValidationIssue('error', 'scalar-limit', 'Protocol minimum exceeds maximum.', uid))
            limit = field.get('max_encoded_bytes')
            if limit is not None and (kind not in {'varint', 'zigzag'} or type(limit) is not int or limit < 1):
                issues.append(ValidationIssue('error', 'scalar-limit', 'An encoded-byte limit requires a positive integer on VarInt/ZigZag.', uid))
            known = _literal_default(field)
            if known is not None and field.get('object_default_mode') != 'guided':
                for message in scalar_errors(field, known):
                    issues.append(ValidationIssue('error', 'scalar-default', f'{name} {message}.', uid))
        if field.get("endian") not in {None, "big", "little"}:
            issues.append(ValidationIssue("error", "endian", "Byte order must be big or little.", uid))
        if kind == "enum" and field.get("enum_uid") not in enums:
            issues.append(ValidationIssue("error", "enum-reference", "Enum field references a missing enum.", uid))
        if kind == "enum" and any(key in field for key in ("width", "endian", "signed")):
            issues.append(ValidationIssue("error", "enum-field-storage", "Select storage on the enum definition, not the enum field.", uid))
        if kind == "struct" and field.get("struct_uid") not in structures:
            issues.append(ValidationIssue("error", "struct-reference", "Structure field references a missing structure.", uid))
        if kind in {"bytes", "string"}:
            _validate_data(field, fields, prior_fields, enums, structures, owner_uid, issues)
        if kind == "array":
            mode = field.get("mode")
            if field.get('initial_policy', 'legacy') not in {'legacy', 'resolve'}:
                issues.append(ValidationIssue('error', 'array-initial-policy', 'Choose resolve or legacy array initialization.', uid))
            if mode not in ARRAY_MODES:
                issues.append(ValidationIssue("error", "array-mode", f"Unsupported array mode '{mode}'.", uid))
            for key in ('min_count', 'max_count', 'initial_count', 'max_bytes'):
                value = field.get(key)
                if key == 'min_count' and value is None or value is not None and (type(value) is not int or value < 0):
                    issues.append(ValidationIssue('error', 'array-limit', f'{key} must be a nonnegative integer or unset.', uid))
            minimum, maximum = field.get('min_count', 0), field.get('max_count')
            if type(minimum) is int and type(maximum) is int and minimum > maximum:
                issues.append(ValidationIssue('error', 'array-limit', 'Minimum item count exceeds maximum.', uid))
            if mode == 'fixed' and type(field.get('count')) is int:
                count = field['count']
                if type(minimum) is int and count < minimum or type(maximum) is int and count > maximum:
                    issues.append(ValidationIssue('error', 'array-limit', 'Fixed count is outside the configured item limits.', uid))
            if mode in {'sentinel', 'repeat_until'} and maximum == 0:
                issues.append(ValidationIssue('error', 'array-limit', 'A terminated array needs at least its terminating item.', uid))
            if mode in {'prefixed', 'byte_prefixed'}:
                try: prefix_expression(field)
                except ValueError as error: issues.append(ValidationIssue('error', 'array-prefix', str(error), uid))
                if field.get('prefix_endian', 'little') not in {'little', 'big'}:
                    issues.append(ValidationIssue('error', 'array-prefix', 'Prefix byte order must be little or big.', uid))
                initial = literal_initial_count(field)
                prefix = field.get('prefix_format', 'uint16')
                if mode == 'prefixed' and initial is not None and prefix in PREFIX_FORMATS and prefix != 'varint' and initial >= 1 << int(prefix[4:]):
                    issues.append(ValidationIssue('error', 'array-prefix-capacity', 'Initial item count exceeds the selected prefix capacity.', uid))
            if mode in {'count_expression', 'byte_expression'} and not _parse_expression(field.get('count_expression')):
                issues.append(ValidationIssue('error', 'array-expression', 'Enter a valid count/byte-length expression.', uid))
            elif mode in {'count_expression', 'byte_expression'}:
                for path in expression_paths(field['count_expression']):
                    if path.startswith(('_index', '_params', '_root')):
                        continue
                    available = dependency_available(path, prior_fields, structures)
                    if not available:
                        external = path.startswith('_.') and owner_uid in structures
                        issues.append(ValidationIssue('warning' if external else 'error', 'array-dependency',
                                                      f"Count dependency '{path}' requires a matching enclosing context." if external else f"Count dependency '{path}' must be available before this array is parsed; later/self references are not valid.", uid))
            if mode == 'sentinel':
                try: ast.literal_eval(field.get('sentinel', ''))
                except (ValueError, SyntaxError): issues.append(ValidationIssue('error', 'array-sentinel', 'Enter a literal terminating item.', uid))
            if mode == 'repeat_until' and not _parse_expression(field.get('predicate')):
                issues.append(ValidationIssue('error', 'array-predicate', 'Enter a predicate using obj, items, and ctx.', uid))
            if mode == 'greedy' and fields[-1].get('uid') != field.get('uid'):
                severity = 'error' if field.get('initial_policy') == 'resolve' else 'warning'
                issues.append(ValidationIssue(severity, 'array-boundary', 'An unbounded greedy array cannot safely precede other fields. Use a byte boundary, count, or termination rule.', uid))
            if mode in {"count_field", "byte_field"}:
                source_key = 'count_field' if mode == 'count_field' else 'length_field'
                reference = field.get(source_key)
                if reference not in prior_names:
                    external = isinstance(reference, str) and reference.startswith('_.') and owner_uid in structures
                    issues.append(ValidationIssue('warning' if external else 'error', "count-reference", "Array count/length requires a matching enclosing context." if external else "Array count must reference an earlier field in the same structure or an available ancestor.", uid))
                elif not _is_integer_reference(prior_fields.get(reference, {})):
                    issues.append(ValidationIssue("error", "count-reference-type", "Array count must reference an integer-compatible field.", uid))
                elif (field.get(source_key + '_uid') and field.get(source_key + '_uid') != prior_fields[reference].get('uid')):
                    issues.append(ValidationIssue('error', 'count-reference-scope', 'The referenced count/length field is no longer accessible in this scope. Select it again explicitly.', uid))
                else:
                    count_definition = prior_fields[reference]
                    if mode == 'byte_field':
                        pass
                    elif field.get("rebuild_count", False):
                        storage = count_definition
                        while storage.get("kind") == "default" and isinstance(storage.get("item"), dict):
                            storage = storage["item"]
                        if storage.get("kind") in {"const", "rebuild"}:
                            issues.append(ValidationIssue("error", "count-rebuild-conflict", "Use an ordinary integer count field when rebuilding its value from an array.", uid))
                        if any(other.get('uid') != field.get('uid') and other.get("kind") == "array"
                               and other.get("mode") == "count_field" and other.get("rebuild_count", False)
                               and other.get("count_field") == reference for other in fields):
                            issues.append(ValidationIssue("error", "count-rebuild-conflict", "Only one array may rebuild a shared count field.", uid))
                    else:
                        rebuilt_from = next((other for other in fields if other.get("kind") == "array"
                                             and other.get("mode") == "count_field" and other.get("rebuild_count", False)
                                             and other.get("count_field") == reference), None)
                        count_default = (_known_array_default_length(rebuilt_from) if rebuilt_from is not None
                                         else _known_integer_default(count_definition, enums))
                        array_length = _known_array_default_length(field)
                        if field.get('object_default_mode') == 'automatic' and field.get('initial_policy') == 'resolve' and field.get('initial_count') is None:
                            array_length = count_default
                        if count_default is not None and array_length is not None and count_default != array_length:
                            issues.append(ValidationIssue(
                                "error", "array-default-count",
                                f"Array '{name}' defaults to {array_length} items but '{reference}' resolves to {count_default}. Match their defaults or enable rebuilding the count from the list.", uid,
                            ))
        if kind == "bitfield":
            bit_names: set[str] = set()
            total = 0
            for member in field.get("members", []):
                member_name = member.get("name", "")
                member_kind = member.get("kind")
                bits = member.get("bits", 0)
                if member_kind not in {"flag", "signed", "unsigned", "padding"}:
                    issues.append(ValidationIssue("error", "bit-kind", f"Unknown bit member kind '{member_kind}'.", uid))
                if member_kind == 'flag' and bits != 1:
                    issues.append(ValidationIssue('error', 'bit-flag-width', 'A flag occupies exactly one bit.', uid))
                if not isinstance(bits, int) or isinstance(bits, bool) or bits <= 0:
                    issues.append(ValidationIssue("error", "bit-width", "Bit member widths must be positive integers.", uid))
                else:
                    total += bits
                if member_kind != "padding":
                    if not _identifier(member_name) or member_name in bit_names:
                        issues.append(ValidationIssue("error", "bit-name", f"Invalid or duplicate bit member '{member_name}'.", uid))
                    bit_names.add(member_name)
            if total <= 0 or total % 8:
                issues.append(ValidationIssue("error", "bit-alignment", "A bit group must contain a positive multiple of eight bits.", uid))
        if kind in {"bytes", "string"} and field.get("mode") == "fixed":
            if not isinstance(field.get("length"), int) or isinstance(field.get("length"), bool) or field.get("length") < 0:
                issues.append(ValidationIssue("error", "fixed-length", "Fixed length must be a non-negative integer.", uid))
        if kind == "array" and field.get("mode") == "fixed":
            if not isinstance(field.get("count"), int) or isinstance(field.get("count"), bool) or field.get("count") < 0:
                issues.append(ValidationIssue("error", "array-count", "Fixed array count must be a non-negative integer.", uid))
        if kind == "switch":
            case_values: set[str] = set()
            identities, class_indices = set(), set()
            for case in field.get("cases", []):
                value_text = str(case.get("value", "")).strip()
                try:
                    literal = ast.literal_eval(value_text)
                    value_key = repr(int(literal) if isinstance(literal, (bool, int, float)) and int(literal) == literal else literal)
                except (ValueError, SyntaxError, OverflowError, TypeError):
                    value_key = value_text
                    for enum in enums.values():
                        for member in enum.get('values', []):
                            if value_text == f"{enum['name']}.{member['name']}":
                                value_key = repr(member['value'])
                if case.get('uid') in identities:
                    issues.append(ValidationIssue('error', 'switch-case-identity', 'Switch cases require distinct stable identities.', uid))
                identities.add(case.get('uid'))
                if case.get('class_index') in class_indices:
                    issues.append(ValidationIssue('error', 'switch-case-type', 'Switch branches require distinct type identities.', uid))
                class_indices.add(case.get('class_index'))
                if case.get('enum_value_uid') and not any(member.get('uid') == case['enum_value_uid'] for enum in enums.values() for member in enum.get('values', [])):
                    issues.append(ValidationIssue('error', 'switch-case-member', 'A switch case selects a removed enum member.', uid))
                if value_key in case_values:
                    issues.append(ValidationIssue("error", "switch-case", f"Duplicate switch case '{value_text}'.", uid))
                case_values.add(value_key)
            if field.get('default_mode') == 'case' and fallback_case(field) is None:
                issues.append(ValidationIssue('error', 'switch-default', 'Select an available fallback case field.', uid))
            default = fallback_expression(field)
            if default and not _parse_expression(default):
                issues.append(ValidationIssue("error", "switch-default", "Switch default must be a Construct expression.", uid))
            selector = str(field.get("selector", ""))
            if field.get('default_mode', 'expression') == 'expression' and not field.get('default') and selector.startswith("this."):
                selector_field = prior_fields.get(selector.removeprefix("this."))
                if selector_field and selector_field.get("kind") == "enum":
                    expected = {str(member["value"]) for member in enums[selector_field["enum_uid"]].get("values", [])}
                    if expected != case_values:
                        issues.append(ValidationIssue("error", "switch-coverage", "Switch cases must cover every enum value when no default is provided.", uid))
        for key in ('condition_field', 'selector_field', 'source_field', 'source_end_field'):
            active = ((key == 'condition_field' and field.get('condition_mode') == 'field') or
                      (key == 'selector_field' and field.get('selector_mode') == 'field') or
                      (key == 'source_field' and (field.get('expression_mode') == 'guided' or field.get('source_mode') in {'bytes', 'wire', 'range'})) or
                      (key == 'source_end_field' and field.get('source_mode') == 'range'))
            if active:
                candidates = {**prior_fields, **({f.get('name'): f for f in fields} if kind == 'rebuild' else {})}
                target = candidates.get(field.get(key))
                if target is None:
                    external = str(field.get(key, '')).startswith('_.') and owner_uid in structures
                    issues.append(ValidationIssue('warning' if external else 'error', 'field-reference',
                                                  f'{key}: requires a matching enclosing context.' if external else f'{key}: select an available source field.', uid, option=key))
                elif field.get(key + '_uid') and field[key + '_uid'] != target.get('uid'):
                    issues.append(ValidationIssue('error', 'field-reference-scope', f'{key}: source identity is no longer accessible; select it again.', uid, option=key))
                elif target:
                    source = target
                    while source.get('kind') in {'const', 'default', 'aligned', 'rebuild'}:
                        source = source.get('item', {})
                    source_kind = source.get('kind')
                    operation = field.get('derive_operation', 'copy')
                    if kind == 'checksum' and field.get('source_mode') == 'bytes' and source_kind != 'bytes':
                        issues.append(ValidationIssue('error', 'checksum-source-type', 'Choose a bytes-valued field, or capture its wire bytes.', uid))
                    if field.get('expression_mode') == 'guided' and operation == 'byte_length' and source_kind not in {'bytes', 'string'}:
                        issues.append(ValidationIssue('error', 'derived-source-type', 'Encoded byte length requires bytes or encoded text.', uid))
                    if field.get('expression_mode') == 'guided' and operation in {'count', 'sum'} and source_kind not in {'array', 'bytes', 'string'}:
                        issues.append(ValidationIssue('error', 'derived-source-type', 'This operation requires a sequence source.', uid))
        if kind == 'conditional' and field.get('condition_mode') == 'field' and field.get('comparison') not in {'truthy', 'falsy'} and field.get('comparison_value_uid'):
            source = prior_fields.get(field.get('condition_field'), {})
            while source.get('kind') in {'const', 'default', 'rebuild'}:
                source = source.get('item', {})
            if not source or source.get('kind') == 'enum':
                members = enums.get(source.get('enum_uid'), {}).get('values', []) if source else [m for enum in enums.values() for m in enum.get('values', [])]
                if not any(member.get('uid') == field['comparison_value_uid'] for member in members):
                    issues.append(ValidationIssue('error', 'condition-member', 'The comparison selects a removed or incompatible enum member.', uid))
        if kind in {'const', 'default'} and field.get('wire_value_mode') == 'guided':
            if field.get('item', {}).get('kind') not in TYPED_VALUE_KINDS:
                issues.append(ValidationIssue('error', 'wire-value', 'Typed wire values require scalar, enum, bytes, or text storage.', uid))
            else:
                for message in guided_errors(field['item'], field.get('wire_value'), manifest_view):
                    issues.append(ValidationIssue('error', 'wire-value', message, uid))
        elif kind in {"const", "default"} and not _parse_expression(field.get("value")):
            issues.append(ValidationIssue("error", "field-value", f"{kind.title()} value must be an expression.", uid))
        if kind in {'const', 'default'}:
            try:
                wire = (guided_expression(field['item'], field.get('wire_value') or {}, 'Owner', enums, structures)
                        if field.get('wire_value_mode') == 'guided' else field.get('value', '0'))
                literal = ast.literal_eval(wire)
            except (ValueError, SyntaxError, TypeError, KeyError, StopIteration):
                literal = _UNKNOWN_LITERAL
            if literal is not _UNKNOWN_LITERAL:
                child = field.get('item', {})
                messages = (data_value_errors(child, literal) if child.get('kind') in {'bytes', 'string'} else scalar_errors(child, literal))
                for message in messages:
                    issues.append(ValidationIssue('error', 'wire-value-storage', f'Wire value {message}.', uid))
                if kind == 'const' and field.get('object_default_mode') == 'custom':
                    initialized = _literal_default(field)
                    if initialized is not None and initialized != literal:
                        issues.append(ValidationIssue('error', 'constant-default', 'The constructor default contradicts the constant wire value.', uid))
        if kind == "padding" and (not isinstance(field.get("length"), int) or isinstance(field.get("length"), bool) or field.get("length") < 0):
            issues.append(ValidationIssue("error", "padding-length", "Padding length must be a non-negative integer.", uid))
        if kind == "aligned" and (not isinstance(field.get("modulus"), int) or isinstance(field.get("modulus"), bool) or field.get("modulus") <= 0):
            issues.append(ValidationIssue("error", "alignment", "Alignment modulus must be a positive integer.", uid))
        if kind in {'padding', 'aligned'}:
            try:
                pattern = bytes.fromhex(field.get('pattern', '00'))
                if len(pattern) != 1:
                    raise ValueError()
            except (ValueError, TypeError):
                issues.append(ValidationIssue('error', 'padding-pattern', 'Choose exactly one fill byte in hexadecimal.', uid))
        if kind == 'advanced':
            if field.get('python_type') and not _parse_expression(field['python_type']):
                issues.append(ValidationIssue('error', 'advanced-type-hint', 'The Python type hint must be an expression.', uid))
            hint = field.get('size_hint')
            if hint is not None and (type(hint) is not int or hint < 0):
                issues.append(ValidationIssue('error', 'advanced-size-hint', 'A declared size must be a nonnegative integer.', uid))
            for dependency in str(field.get('dependency_hints') or '').split(','):
                if dependency.strip():
                    _validate_dependencies('this.' + dependency.strip().removeprefix('this.'), prior_fields, owner_uid in structures, uid, 'dependency_hints', issues, structures=structures)
        if kind == "checksum":
            algorithm = field.get("algorithm", "")
            if algorithm == 'custom' and not _parse_expression(field.get('custom_algorithm')):
                issues.append(ValidationIssue('error', 'checksum-algorithm', 'Enter a custom checksum callable expression.', uid))
            elif algorithm not in {"crc32", "sum8", "sha256", "custom"} and not _parse_expression(algorithm):
                issues.append(ValidationIssue("error", "checksum-algorithm", "Checksum algorithm must be crc32, sum8, sha256, or a callable expression.", uid))
            storage = field.get('item', {})
            while storage.get('kind') in {'const', 'default', 'aligned', 'rebuild'}:
                storage = storage.get('item', {})
            severity = 'error' if field.get('checksum_policy') == 'strict' else 'warning'
            if algorithm in {'crc32', 'sum8'}:
                bits = (storage.get('width', 0) * 8 if storage.get('kind') in {'int', 'uint'} else
                        storage.get('length', 0) * 8 if storage.get('kind') == 'bytes_integer' else 0)
                signed = storage.get('kind') == 'int' or storage.get('kind') == 'bytes_integer' and storage.get('signed')
                needed = 32 if algorithm == 'crc32' else 8
                if type(bits) is not int or bits - bool(signed) < needed:
                    issues.append(ValidationIssue(severity, 'checksum-storage', f'{algorithm} requires integer storage covering unsigned {needed}-bit values.', uid))
            if algorithm == 'sha256' and (storage.get('kind') != 'bytes' or storage.get('mode') == 'fixed' and storage.get('length') != 32):
                issues.append(ValidationIssue(severity, 'checksum-storage', 'SHA-256 produces a 32-byte digest; choose compatible bytes storage.', uid))
        for expression_key in ("expression", "condition", "selector", "source"):
            if expression_key in field and not _parse_expression(field.get(expression_key)):
                issues.append(ValidationIssue("error", "expression", f"Invalid expression in {name}.{expression_key}.", uid))
            elif expression_key in field and kind in {'conditional', 'switch', 'checksum', 'computed', 'rebuild'}:
                # Build-time rebuilt values can depend on later supplied values.
                available = {**prior_fields, **({item.get('name'): item for item in fields} if kind == 'rebuild' else {})}
                _validate_dependencies(field[expression_key], available, owner_uid in structures, uid, expression_key, issues, structures=structures)
        for nested_key in ("item",):
            nested = field.get(nested_key)
            if isinstance(nested, dict):
                _validate_fields([nested], enums, structures, issues, owner_uid, prior_context=prior_fields,
                                 ancestors=ancestors, path=field_path, visiting=visiting)
        if kind == "inline_struct":
            local_prior = {key: value for key, value in prior_fields.items() if not key.startswith('_.')}
            _validate_fields(field.get("fields", []), enums, structures, issues, owner_uid, ancestors=(local_prior, *ancestors),
                             path=field_path, visiting=visiting)
        if kind == 'struct' and field.get('struct_uid') in structures and field['struct_uid'] not in visiting:
            local_prior = {key: value for key, value in prior_fields.items() if not key.startswith('_.')}
            _validate_fields(structures[field['struct_uid']].get('fields', []), enums, structures, issues, owner_uid,
                             ancestors=(local_prior, *ancestors), path=field_path, visiting=visiting | {field['struct_uid']})
        for case in field.get("cases", []):
            if not _parse_expression(case.get("value")):
                issues.append(ValidationIssue("error", "switch-value", "Switch case value must be an expression.", uid))
            if isinstance(case.get("item"), dict):
                _validate_fields([case["item"]], enums, structures, issues, owner_uid, prior_context=prior_fields,
                                 ancestors=ancestors, path=field_path, visiting=visiting)
        for index in range(issue_start, len(issues)):
            if not issues[index].path:
                issues[index] = replace(issues[index], path=field_path)
        prior_names.add(name)
        prior_fields[name] = field
    for cycle in build_cycles(fields, {'enums': list(enums.values()), 'structures': list(structures.values()), 'messages': [{'fields': fields}]}):
        definition = next(field for field in fields if field.get('name') == cycle[0])
        guarded = any(field.get('name') in cycle and field.get('kind') in {'conditional', 'switch'} for field in fields)
        issues.append(ValidationIssue('warning' if guarded else 'error', 'build-dependency-cycle',
                                      'Build dependency cycle' + (' depends on branch guards' if guarded else '') + ': ' + ' -> '.join(cycle),
                                      definition.get('uid', owner_uid), path + '.' + cycle[0] if path else cycle[0], 'build'))


def _validate_dependencies(expression, available, external_scope, uid, option, issues, *, structures=None):
    try:
        paths = expression_paths(expression)
    except (SyntaxError, TypeError, ValueError):
        issues.append(ValidationIssue('error', 'field-dependency-expression', f'{option}: enter valid field paths.', uid, option=option))
        return
    for path in paths:
        if path.startswith(('_index', '_params', '_root')):
            continue
        if dependency_available(path, available, structures or {}):
            continue
        external = path.startswith('_.') and external_scope
        issues.append(ValidationIssue('warning' if external else 'error', 'field-dependency',
                                      f"{option}: dependency '{path}' requires a matching enclosing context." if external else
                                      f"{option}: dependency '{path}' must be available before this field is parsed.", uid,
                                      phase='parse', option=option))


def _validate_data(field, fields, prior, enums, structures, owner_uid, issues):
    uid, mode = field.get('uid', owner_uid), field.get('mode')
    def issue(code, message, severity='error'):
        issues.append(ValidationIssue(severity, code, message, uid))
    if mode not in DATA_MODES:
        issue('data-mode', f'Unsupported {field["kind"]} mode {mode!r}.')
    for key in ('data_policy', 'initial_policy'):
        allowed = {'strict', 'legacy'} if key == 'data_policy' else {'resolve', 'legacy'}
        if field.get(key, 'legacy') not in allowed:
            issue('data-policy', f'Unsupported {key}.')
    minimum, maximum = field.get('min_bytes', 0), field.get('max_bytes')
    for key, value in (('min_bytes', minimum), ('max_bytes', maximum)):
        if key == 'min_bytes' and value is None or value is not None and (type(value) is not int or value < 0):
            issue('data-limit', f'{key} must be a nonnegative integer or unset.')
    if type(minimum) is int and type(maximum) is int and minimum > maximum:
        issue('data-limit', 'Minimum byte length exceeds maximum.')
    if type(field.get('rebuild_length', False)) is not bool:
        issue('data-policy', 'Calculate length must be a boolean setting.')
    error = encoding_error(field)
    if error:
        issue('data-encoding', error)
    if mode in {'prefixed', 'pascal'}:
        if mode == 'prefixed':
            try:
                prefix_expression(field)
            except ValueError as error:
                issue('data-prefix', str(error))
            if field.get('prefix_endian', 'little') not in {'big', 'little'}:
                issue('data-prefix', 'Prefix byte order must be little or big.')
        prefix = 'uint16' if mode == 'pascal' else field.get('prefix_format', 'uint16')
        if prefix in PREFIX_FORMATS and prefix != 'varint' and type(minimum) is int and minimum >= 1 << int(prefix[4:]):
            issue('data-prefix-capacity', 'Minimum byte length exceeds the selected prefix capacity.')
    expected = field.get('length') if mode == 'fixed' else None
    if mode == 'count_expression':
        expression = field.get('length_expression', '')
        if not _parse_expression(expression):
            issue('data-expression', 'Enter a byte-length expression.')
        else:
            _validate_dependencies(expression, prior, owner_uid in structures, uid, 'length_expression', issues, structures=structures)
            try:
                expected = ast.literal_eval(expression)
                if type(expected) is not int or expected < 0:
                    issue('data-length', 'Byte length must be a nonnegative integer.')
            except (ValueError, SyntaxError):
                pass
    if mode == 'count_field':
        reference = field.get('length_field', '')
        source = prior.get(reference)
        if source is None:
            external = isinstance(reference, str) and reference.startswith('_.') and owner_uid in structures
            issue('length-reference', 'Length requires a matching enclosing context.' if external else
                  'Length must reference an earlier integer field or an available ancestor.', 'warning' if external else 'error')
        elif not _is_integer_reference(source):
            issue('length-reference-type', 'Length must reference an integer-compatible field.')
        elif field.get('length_field_uid') and source.get('uid') != field['length_field_uid']:
            issue('length-reference-scope', 'The referenced length is no longer accessible. Select it again explicitly.')
        else:
            expected = _known_integer_default(source, enums)
            if field.get('rebuild_length'):
                expected = None
                storage = source
                while storage.get('kind') in {'const', 'default', 'rebuild'}:
                    storage = storage.get('item', {})
                if source.get('kind') in {'const', 'rebuild'} or storage.get('kind') == 'enum':
                    issue('length-owner', 'A derived length needs ordinary integer storage without another calculation or constant.')
        if field.get('rebuild_length'):
            if str(reference).startswith('_.'):
                issue('length-owner', 'Derive a length from a payload in the same structure; ancestor lengths are manual.')
            writers = [candidate for candidate in fields if candidate.get('mode') == 'count_field' and
                       (candidate.get('kind') in {'bytes', 'string'} and candidate.get('length_field') == reference and candidate.get('rebuild_length')
                        or candidate.get('kind') == 'array' and candidate.get('count_field') == reference and candidate.get('rebuild_count'))]
            if len(writers) > 1:
                issue('length-owner', 'Choose one authoritative payload for this derived length; other payloads must use manual/shared validation.')
    if type(expected) is int and expected < 0:
        issue('data-length', 'Byte length must be nonnegative.')
    if mode == 'greedy' and fields[-1].get('uid') != field.get('uid'):
        issue('data-boundary', 'A greedy payload cannot safely precede other fields. Use a byte length, prefix, or terminator.',
              'error' if field.get('data_policy') == 'strict' else 'warning')
    value = _literal_default(field)
    if field.get('object_default_mode') == 'guided' and field.get('kind') == 'bytes':
        try:
            value = bytes.fromhex((field.get('object_default_value') or {}).get('hex', ''))
        except (ValueError, TypeError):
            value = None
    if field.get('object_default_mode') == 'automatic':
        # Do not allocate the default merely to validate a potentially huge definition.
        if field.get('kind') == 'string' and mode not in {'count_field', 'count_expression'}:
            value = ''
        elif field.get('initial_policy') == 'legacy' and mode != 'fixed':
            value = '' if field.get('kind') == 'string' else b''
    if value is not None:
        for message in data_value_errors(field, value, expected):
            issue('data-default', f"{field.get('name')}: {message}.")
    elif type(expected) is int:
        if type(minimum) is int and expected < minimum or type(maximum) is int and expected > maximum:
            issue('data-limit', 'Known payload boundary is outside the byte limits.')


def _is_integer_reference(field):
    kind = field.get("kind")
    if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "enum"}:
        return True
    if kind in {"const", "default", "rebuild"} and isinstance(field.get("item"), dict):
        return _is_integer_reference(field["item"])
    return False


def _literal_default(field):
    """Inspect literal constructor defaults without running trusted Python code."""
    if field.get("object_default_mode") == "guided":
        return (field.get("object_default_value") or {}).get("value")
    if field.get("object_default_mode") == "custom":
        try:
            return ast.literal_eval(field.get("object_default", ""))
        except (ValueError, SyntaxError, TypeError):
            pass
    return None


def _known_integer_default(field, enums):
    if field.get("kind") == "rebuild":
        return None
    if field.get("object_default_mode") == "automatic":
        if field.get("kind") == "enum":
            values = enums.get(field.get("enum_uid"), {}).get("values", [])
            return values[0].get("value") if values else None
        return 0
    value = _literal_default(field)
    if field.get('kind') == 'enum' and field.get('object_default_mode') == 'guided':
        chosen = (field.get('object_default_value') or {}).get('value_uid')
        value = next((member['value'] for member in enums.get(field.get('enum_uid'), {}).get('values', []) if member.get('uid') == chosen), None)
    if field.get("object_default_mode") == "guided" and isinstance(value, str):
        try:
            value = int(value, 0)
        except ValueError:
            return None
    return value if type(value) is int else None


def _known_array_default_length(field):
    mode = field.get("object_default_mode", "required")
    if mode == "automatic":
        if field.get('initial_policy') == 'resolve':
            return literal_initial_count(field)
        return field.get("count", 0) if field.get("mode") == "fixed" else 0
    if mode == "guided":
        items = (field.get("object_default_value") or {}).get("items")
        return len(items) if isinstance(items, list) else None
    value = _literal_default(field)
    return len(value) if isinstance(value, (list, tuple)) else None


def _validate_cycles(structures, issues):
    graph = {
        uid: {
            field.get("struct_uid")
            for field in walk_fields(structure.get("fields", []))
            if field.get("kind") == "struct" and field.get("struct_uid") in structures
        }
        for uid, structure in structures.items()
    }
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(uid: str) -> bool:
        if uid in visiting:
            return True
        if uid in visited:
            return False
        visiting.add(uid)
        cyclic = any(visit(child) for child in graph.get(uid, set()))
        visiting.remove(uid)
        visited.add(uid)
        return cyclic

    for uid in graph:
        if visit(uid):
            issues.append(ValidationIssue("error", "struct-cycle", f"Reusable structure '{structures[uid].get('name')}' is recursive.", uid))


def _validate_group_cycles(groups, issues):
    for group in groups.values():
        seen = set(); current = group
        while current and current.get("parent_group_uid"):
            uid = current.get("uid")
            if uid in seen:
                issues.append(ValidationIssue(
                    "error", "group-cycle", f"Message group '{group.get('name', '')}' has a circular parent chain.",
                    group.get("uid", ""),
                ))
                break
            seen.add(uid)
            current = groups.get(current.get("parent_group_uid"))


def _validate_new_routing(data, issues):
    from app.binary_messages.compiled_routing import Identifier
    from .routing_model import owners_by_uid, parent_owner, resolve_definitions, compile_manifest_routing
    owners = owners_by_uid(data)
    resolved_identifiers = {}
    routing_errors = False
    identifier_uids = set(owners)
    for owner in owners.values():
        uid = owner['uid']
        names = set()
        if owner.get('legacy_routing'):
            issues.append(ValidationIssue('error', 'routing-migration', 'Legacy candidate-specific signatures must be converted to group identifier definitions.', uid))
            routing_errors = True
        try:
            definitions = resolve_definitions(data, owner)
            resolved_identifiers[uid] = []
            for definition in definitions:
                identifier = Identifier(**definition)
                resolved_identifiers[uid].append(identifier)
                if not _identifier(identifier.name) or identifier.name in names or identifier.uid in identifier_uids:
                    raise ValueError('Identifier names must be unique Python names within their group, and identifier IDs must be unique.')
                names.add(identifier.name)
                identifier_uids.add(identifier.uid)
        except (ValueError, TypeError, LookupError, OverflowError, struct.error) as error:
            issues.append(ValidationIssue('error', 'routing-definition', str(error), uid))
            routing_errors = True
    for item in [*data.get('groups', []), *data.get('messages', [])]:
        if item.get('legacy_signatures'):
            issues.append(ValidationIssue('error', 'routing-migration', 'Legacy signatures are preserved. Assign values for the new parent identifiers to complete conversion.', item['uid']))
            routing_errors = True
        values = item.get('expected_values')
        if values is None:
            continue
        parent = parent_owner(data, item)
        if parent is None:
            continue
        try:
            if not isinstance(values, dict):
                raise ValueError('Expected identifier values must be an object or unassigned')
            for identifier in resolved_identifiers.get(parent['uid'], []):
                if values.get(identifier.uid) is not None:
                    identifier.encode(values[identifier.uid])
        except (ValueError, TypeError, LookupError, OverflowError, struct.error) as error:
            issues.append(ValidationIssue('error', 'routing-value', str(error), item['uid']))
            routing_errors = True
    if not routing_errors and not any(issue.code in {'group-cycle', 'group-parent', 'message-group'} for issue in issues):
        try:
            compile_manifest_routing(data)
        except (ValueError, TypeError, LookupError, OverflowError, struct.error) as error:
            issues.append(ValidationIssue('error', 'routing-collision', str(error), data['library']['uid']))


def blocking_issues(data: dict[str, Any]) -> list[ValidationIssue]:
    return [issue for issue in validate_manifest(data) if issue.blocking]
