"""Typed, Construct-backed binary message models."""

from .base import BinaryMessage
from .conversion import dataclass_from_mapping, dataclass_to_mapping
from .errors import (
    BinaryMessageError,
    MessageDecodeError,
    MessageDefinitionError,
    MessageEncodeError,
    MessageJsonError,
    MessageSendError,
    DispatcherConfigurationError,
    AmbiguousMessageIdError,
    DuplicateMessageIdError,
    UnknownMessageIdError,
)
from .identity import Direction, TxRx
from .fields import runtime_field, wire_field
from .json_codec import from_json_value, to_json_value
from .registry import FixedIdExtractor, MessageRegistry
from .sending import MessageSendSession

__all__ = [
    "BinaryMessage",
    "BinaryMessageError",
    "AmbiguousMessageIdError",
    "MessageDecodeError",
    "MessageDefinitionError",
    "DispatcherConfigurationError",
    "DuplicateMessageIdError",
    "MessageEncodeError",
    "MessageJsonError",
    "MessageSendError",
    "MessageSendSession",
    "FixedIdExtractor",
    "MessageRegistry",
    "Direction",
    "TxRx",
    "UnknownMessageIdError",
    "dataclass_from_mapping",
    "dataclass_to_mapping",
    "from_json_value",
    "runtime_field",
    "to_json_value",
    "wire_field",
]
