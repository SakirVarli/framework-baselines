from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from .base import BinaryMessage
from .errors import (
    DispatcherConfigurationError,
    AmbiguousMessageIdError,
    DuplicateMessageIdError,
    UnknownMessageIdError,
)
from .identity import Direction


@dataclass(frozen=True, slots=True)
class FixedIdExtractor:
    offset: int
    width: int
    byteorder: str = "big"
    mask: int | None = None
    shift: int = 0

    def __post_init__(self) -> None:
        if self.offset < 0:
            raise DispatcherConfigurationError("ID offset cannot be negative")
        if self.width not in {1, 2, 3, 4, 8}:
            raise DispatcherConfigurationError("ID width must be 1, 2, 3, 4, or 8")
        if self.byteorder not in {"big", "little"}:
            raise DispatcherConfigurationError("ID byte order must be big or little")
        if self.shift < 0:
            raise DispatcherConfigurationError("ID shift cannot be negative")
        if self.mask is not None and self.mask < 0:
            raise DispatcherConfigurationError("ID mask cannot be negative")

    def extract(self, data: bytes | bytearray | memoryview) -> int:
        view = memoryview(data)
        end = self.offset + self.width
        if len(view) < end:
            raise DispatcherConfigurationError(
                f"Need {end} bytes to extract the message ID; received {len(view)}"
            )
        value = int.from_bytes(view[self.offset:end], self.byteorder, signed=False)
        if self.mask is not None:
            value &= self.mask
        return value >> self.shift


class MessageRegistry:
    def __init__(
        self,
        message_types: Iterable[type[BinaryMessage]] = (),
        *,
        extractor: FixedIdExtractor | None = None,
    ) -> None:
        by_key: dict[tuple[int, Direction], type[BinaryMessage]] = {}
        id_groups: dict[int, list[type[BinaryMessage]]] = {}
        by_name: dict[str, type[BinaryMessage]] = {}
        for message_type in message_types:
            if not isinstance(message_type, type) or not issubclass(message_type, BinaryMessage):
                raise TypeError("Registry entries must be BinaryMessage classes")
            message_id = message_type.MESSAGE_ID
            if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id < 0:
                raise ValueError(f"{message_type.__name__}.MESSAGE_ID must be a non-negative integer")
            raw_direction = (
                message_type.__dict__["DIRECTION"] if "DIRECTION" in message_type.__dict__
                else message_type.__dict__.get("TX_RX", Direction.ANY)
            )
            direction = Direction.normalize(raw_direction)
            key = (message_id, direction)
            existing_directions = {direction for registered_id, direction in by_key if registered_id == message_id}
            if key in by_key:
                raise DuplicateMessageIdError(
                    f"Message identity ({message_id}, {direction.value}) is used by both "
                    f"{by_key[key].__name__} and {message_type.__name__}"
                )
            if existing_directions and (direction == Direction.ANY or Direction.ANY in existing_directions):
                raise DuplicateMessageIdError(
                    f"Message ID {message_id} cannot combine direction ANY with TX or RX"
                )
            name = message_type.MESSAGE_NAME or message_type.__name__
            if name in by_name:
                raise ValueError(f"Duplicate message name: {name}")
            by_key[key] = message_type
            id_groups.setdefault(message_id, []).append(message_type)
            by_name[name] = message_type
        self._by_key = MappingProxyType(by_key)
        self._by_id = MappingProxyType({key: values[0] for key, values in id_groups.items() if len(values) == 1})
        self._by_name = MappingProxyType(by_name)
        self.extractor = extractor

    @property
    def by_id(self) -> Mapping[int, type[BinaryMessage]]:
        return self._by_id

    @property
    def by_name(self) -> Mapping[str, type[BinaryMessage]]:
        return self._by_name

    @property
    def by_key(self) -> Mapping[tuple[int, Direction], type[BinaryMessage]]:
        return self._by_key

    def get_message_type(self, message_id: int, direction: Direction | str | None = None, **legacy: Any) -> type[BinaryMessage]:
        direction = Direction.normalize(_with_legacy_direction(direction, legacy))
        if legacy:
            raise TypeError("Unexpected lookup options: " + ", ".join(sorted(legacy)))
        if direction is not None:
            message_type = self._by_key.get((message_id, direction)) or self._by_key.get((message_id, Direction.ANY))
            if message_type is None:
                raise UnknownMessageIdError(f"Unknown message identity: ({message_id}, {direction.value})")
            return message_type
        candidates = [message_type for (registered_id, _), message_type in self._by_key.items() if registered_id == message_id]
        if not candidates:
            raise UnknownMessageIdError(f"Unknown message ID: {message_id}")
        if len(candidates) > 1:
            raise AmbiguousMessageIdError(f"Message ID {message_id} has TX and RX definitions; provide direction")
        return candidates[0]

    def decode(
        self,
        message_id: int,
        data: bytes | bytearray | memoryview,
        *,
        direction: Direction | str | None = None,
        **context: Any,
    ) -> BinaryMessage:
        direction = _with_legacy_direction(direction, context)
        return self.get_message_type(message_id, direction).decode(data, **context)

    def decode_auto(
        self,
        data: bytes | bytearray | memoryview,
        *,
        direction: Direction | str | None = None,
        **context: Any,
    ) -> BinaryMessage:
        if self.extractor is None:
            raise DispatcherConfigurationError("No automatic message-ID extractor is configured")
        direction = _with_legacy_direction(direction, context)
        return self.decode(self.extractor.extract(data), data, direction=direction, **context)


def _with_legacy_direction(direction, values):
    legacy = values.pop("tx_rx", None)
    if direction is not None and legacy is not None:
        raise TypeError("Provide direction, not both direction and legacy tx_rx")
    return direction if direction is not None else legacy
