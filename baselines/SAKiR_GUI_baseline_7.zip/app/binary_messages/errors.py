from __future__ import annotations


class BinaryMessageError(Exception):
    """Base exception for the binary message package."""


class MessageDefinitionError(BinaryMessageError, TypeError):
    """Raised when a message class has an invalid definition."""


class MessageDecodeError(BinaryMessageError, ValueError):
    """Raised when bytes cannot be decoded into a message."""


class MessageEncodeError(BinaryMessageError, ValueError):
    """Raised when a message cannot be encoded into bytes."""


class MessageSendError(BinaryMessageError, RuntimeError):
    """Raised when a message cannot be handed to a communication session."""


class MessageJsonError(BinaryMessageError, ValueError):
    """Raised when a message cannot be converted to or from JSON."""


class UnknownMessageIdError(BinaryMessageError, LookupError):
    """Raised when a registry does not contain a requested message ID."""


class DuplicateMessageIdError(BinaryMessageError, ValueError):
    """Raised when two message classes claim the same ID/direction identity."""


class AmbiguousMessageIdError(BinaryMessageError, LookupError):
    """Raised when an ID has multiple directional message classes."""


class DispatcherConfigurationError(BinaryMessageError, ValueError):
    """Raised when automatic message-ID extraction is unavailable or invalid."""
