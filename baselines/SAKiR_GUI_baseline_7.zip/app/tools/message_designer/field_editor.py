from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .generation import construct_expression
from .model import new_field, new_id
from .validation import FIELD_KINDS


class FieldOptionsEditor(QtWidgets.QWidget):
    """Friendly, type-specific editor for every visual wire-field family."""

    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._loading = False
        self._base: dict[str, Any] = new_field("field")
        self._manifest: dict[str, Any] = {}
        self._widgets: dict[str, QtWidgets.QWidget] = {}
        self._case_items: list[dict[str, Any]] = []
        self._layout = QtWidgets.QFormLayout(self)
        self._layout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self._layout.setSizeConstraint(QtWidgets.QLayout.SetMinAndMaxSize)
        self.changed.connect(self._update_raw_format)

    def load_field(self, field: dict[str, Any], manifest: dict[str, Any]) -> None:
        self._manifest = manifest
        self._base = copy.deepcopy(field)
        self._build(field.get("kind", "uint"), field)

    def change_kind(self, kind: str, name: str = "field") -> None:
        if kind not in FIELD_KINDS:
            return
        replacement = new_field(name or "field", kind)
        replacement["uid"] = self._base.get("uid", replacement["uid"])
        self._base = replacement
        self._build(kind, replacement)
        self.changed.emit()

    def value(self) -> dict[str, Any]:
        result = copy.deepcopy(self._base)
        kind = result["kind"]
        for key, widget in self._widgets.items():
            if isinstance(widget, QtWidgets.QSpinBox):
                result[key] = widget.value()
            elif isinstance(widget, QtWidgets.QCheckBox):
                result[key] = widget.isChecked()
            elif isinstance(widget, QtWidgets.QComboBox):
                result[key] = widget.currentData() if widget.currentData() is not None else widget.currentText()
                if key == "width":
                    result[key] = int(result[key])
            elif isinstance(widget, (QtWidgets.QLineEdit, QtWidgets.QPlainTextEdit)):
                result[key] = widget.text() if isinstance(widget, QtWidgets.QLineEdit) else widget.toPlainText()
        if kind == "bitfield":
            result["members"] = self._read_members()
        elif kind == "switch":
            result["cases"] = self._read_cases()
        return result

    def _clear(self) -> None:
        while self._layout.rowCount():
            self._layout.removeRow(0)
        self._widgets.clear()

    def _build(self, kind: str, field: dict[str, Any]) -> None:
        self._loading = True
        self._clear()
        wire_heading = QtWidgets.QLabel("Wire format")
        wire_heading.setStyleSheet("font-weight: 600;")
        self._layout.addRow(wire_heading)
        if kind in {"uint", "int"}:
            self._width(field, [1, 2, 3, 4, 8]); self._endian(field)
        elif kind == "bytes_integer":
            self._spin("length", "Byte length", field, 1, 4096); self._check("signed", "Signed", field); self._endian(field)
        elif kind in {"varint", "zigzag", "bool"}:
            self._note("This field has no additional wire settings.")
        elif kind == "float":
            self._width(field, [2, 4, 8]); self._endian(field)
        elif kind == "enum":
            self._reference("enum_uid", "Enum", self._manifest.get("enums", []), field); self._width(field, [1, 2, 3, 4, 8]); self._endian(field)
        elif kind in {"bytes", "string"}:
            self._combo("mode", "Size mode", ["fixed", "count_field", "prefixed", "greedy", "null_terminated", "pascal"], field)
            self._spin("length", "Fixed length", field, 0, 2**31 - 1)
            self._field_reference("length_field", "Length field", field)
            if kind == "string": self._combo("encoding", "Encoding", ["utf8", "ascii", "latin1", "utf16", "utf-16-le", "utf-16-be"], field, editable=True)
            self._connect_mode_visibility("mode", {
                "length": {"fixed"},
                "length_field": {"count_field"},
            })
        elif kind == "bitfield":
            self._members_table(field)
        elif kind == "array":
            self._combo("mode", "Array mode", ["fixed", "count_field", "prefixed", "greedy"], field)
            self._spin("count", "Fixed count", field, 0, 2**31 - 1); self._field_reference("count_field", "Count field", field)
            self._connect_mode_visibility("mode", {
                "count": {"fixed"},
                "count_field": {"count_field"},
            })
            self._note("Edit the array item using its child node in the definition tree.")
        elif kind == "struct":
            self._reference("struct_uid", "Reusable structure", self._manifest.get("structures", []), field)
        elif kind == "inline_struct":
            self._note("Add and edit inline fields using this field's context menu and child nodes.")
        elif kind == "conditional":
            self._line("condition", "Condition expression", field); self._note("Edit the conditional value using its child node.")
        elif kind == "switch":
            self._line("selector", "Selector expression", field); self._line("default", "Default Construct", field); self._cases_table(field)
        elif kind in {"const", "default"}:
            self._line("value", "Value expression", field); self._note("Edit the wrapped value using its child node.")
        elif kind == "padding":
            self._spin("length", "Padding bytes", field, 0, 2**31 - 1)
        elif kind == "aligned":
            self._spin("modulus", "Alignment modulus", field, 1, 2**31 - 1); self._note("Edit the aligned value using its child node.")
        elif kind in {"computed", "rebuild"}:
            self._line("expression", "Construct expression", field)
            if kind == "rebuild": self._note("Edit the rebuilt value using its child node.")
        elif kind == "checksum":
            self._combo("algorithm", "Algorithm", ["crc32", "sum8", "sha256", "custom"], field, editable=True)
            self._line("source", "Source expression", field); self._note("Edit the checksum field using its child node.")
        elif kind == "advanced":
            edit = QtWidgets.QPlainTextEdit(str(field.get("expression", "Int8ub"))); edit.setMinimumHeight(100)
            self._add("expression", "Construct expression", edit)
            self._note("Trusted developer code. Preview execution is isolated for reliability, not security.")
        if kind != "padding":
            self._object_default_section(field)
        self._raw_format_section()
        self._loading = False
        self._layout.invalidate()
        self._layout.activate()
        self.updateGeometry()
        QtCore.QTimer.singleShot(0, self._refresh_geometry)

    def _object_default_section(self, field: dict[str, Any]) -> None:
        separator = QtWidgets.QFrame()
        separator.setFrameShape(QtWidgets.QFrame.HLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        self._layout.addRow(separator)
        heading = QtWidgets.QLabel("Python object initialization")
        heading.setStyleSheet("font-weight: 600;")
        self._layout.addRow(heading)

        default_mode = QtWidgets.QComboBox()
        default_mode.addItem("Required", "required")
        default_mode.addItem("Automatic", "automatic")
        default_mode.addItem("Custom expression", "custom")
        selected_mode = default_mode.findData(field.get("object_default_mode", "required"))
        default_mode.setCurrentIndex(max(0, selected_mode))
        self._add("object_default_mode", "Object default", default_mode)
        self._line("object_default", "Custom default expression", field)
        default_expression = self._widgets["object_default"]
        default_expression_label = self._layout.labelForField(default_expression)

        def show_custom_default(mode=None):
            visible = default_mode.currentData() == "custom"
            default_expression.setVisible(visible)
            if default_expression_label is not None:
                default_expression_label.setVisible(visible)

        default_mode.currentIndexChanged.connect(show_custom_default)
        show_custom_default()
        self._note(
            "Required must be supplied when creating the object. Automatic uses a safe type-aware "
            "value. Custom expressions are trusted Python code and create a fresh value for every object."
        )

    def _refresh_geometry(self) -> None:
        self._layout.invalidate()
        self._layout.activate()
        self.updateGeometry()
        parent = self.parentWidget()
        while parent is not None and not isinstance(parent, QtWidgets.QScrollArea):
            parent = parent.parentWidget()
        if parent is not None:
            parent.updateGeometry()
            parent.viewport().updateGeometry()
            parent.viewport().update()

    def _raw_format_section(self) -> None:
        separator = QtWidgets.QFrame()
        separator.setFrameShape(QtWidgets.QFrame.HLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        self._layout.addRow(separator)
        heading = QtWidgets.QLabel("Raw Construct format")
        heading.setStyleSheet("font-weight: 600;")
        self._layout.addRow(heading)
        note = QtWidgets.QLabel(
            "Read-only preview of the Construct expression generated for this field. "
            "Use its adapter names when looking up Construct documentation."
        )
        note.setWordWrap(True); note.setStyleSheet("color: #52627a;")
        self._layout.addRow(note)
        self.raw_format = QtWidgets.QPlainTextEdit()
        self.raw_format.setReadOnly(True)
        self.raw_format.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.raw_format.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.raw_format.setMinimumHeight(58)
        self.raw_format.setMaximumHeight(92)
        self._layout.addRow("Construct expression", self.raw_format)
        self._update_raw_format()

    def _update_raw_format(self) -> None:
        preview = getattr(self, "raw_format", None)
        if preview is None:
            return
        try:
            expression = construct_expression(self.value(), self._manifest)
        except (KeyError, TypeError, ValueError) as error:
            expression = f"Unavailable until the field settings are complete: {error}"
        preview.setPlainText(expression)

    def _connect_mode_visibility(self, mode_key: str, visibility: dict[str, set[str]]) -> None:
        mode = self._widgets[mode_key]

        def update_rows(*args):
            selected = str(mode.currentData() if mode.currentData() is not None else mode.currentText())
            for key, visible_modes in visibility.items():
                self._set_row_visible(key, selected in visible_modes)
            self._layout.invalidate()
            self._layout.activate()
            self.updateGeometry()

        mode.currentIndexChanged.connect(update_rows)
        update_rows()

    def _set_row_visible(self, key: str, visible: bool) -> None:
        widget = self._widgets.get(key)
        if widget is None:
            return
        widget.setVisible(visible)
        label = self._layout.labelForField(widget)
        if label is not None:
            label.setVisible(visible)

    def _field_reference(self, key: str, label: str, field: dict[str, Any]) -> None:
        widget = QtWidgets.QComboBox()
        candidates = [
            candidate for candidate in _prior_sibling_fields(self._manifest, field.get("uid", ""))
            if _is_integer_reference(candidate)
        ]
        if candidates:
            widget.addItem("— Select an earlier integer field —", "")
            for candidate in candidates:
                widget.addItem(candidate.get("name", "Unnamed"), candidate.get("name", ""))
        else:
            widget.addItem("— No earlier integer fields in this scope —", "")
        selected = str(field.get(key, ""))
        index = widget.findData(selected)
        if selected and index < 0:
            widget.addItem(f"⚠ Missing or incompatible: {selected}", selected)
            index = widget.count() - 1
        widget.setCurrentIndex(max(0, index))
        widget.setToolTip(
            "Only earlier integer fields in the same Construct structure can be referenced."
        )
        self._add(key, label, widget)

    def _add(self, key: str, label: str, widget: QtWidgets.QWidget) -> None:
        self._widgets[key] = widget
        self._layout.addRow(label, widget)
        if isinstance(widget, QtWidgets.QLineEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QPlainTextEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QSpinBox): widget.valueChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QCheckBox): widget.toggled.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QComboBox): widget.currentIndexChanged.connect(self._emit_changed)

    def _emit_changed(self, *args) -> None:
        if not self._loading:
            self.changed.emit()

    def _note(self, text: str) -> None:
        label = QtWidgets.QLabel(text); label.setWordWrap(True); label.setStyleSheet("color: #52627a;")
        self._layout.addRow(label)

    def _spin(self, key, label, field, minimum, maximum):
        widget = QtWidgets.QSpinBox(); widget.setRange(minimum, maximum); widget.setValue(int(field.get(key, minimum)))
        self._add(key, label, widget)

    def _check(self, key, label, field):
        widget = QtWidgets.QCheckBox(); widget.setChecked(bool(field.get(key, False))); self._add(key, label, widget)

    def _line(self, key, label, field):
        self._add(key, label, QtWidgets.QLineEdit(str(field.get(key, ""))))

    def _combo(self, key, label, values, field, editable=False):
        widget = QtWidgets.QComboBox(); widget.setEditable(editable); widget.addItems(values); widget.setCurrentText(str(field.get(key, values[0])))
        self._add(key, label, widget)

    def _width(self, field, values): self._combo("width", "Width (bytes)", [str(v) for v in values], {"width": str(field.get("width", values[0]))})
    def _endian(self, field): self._combo("endian", "Byte order", ["big", "little"], field)

    def _reference(self, key, label, values, field):
        widget = QtWidgets.QComboBox(); widget.addItem("— Select —", "")
        for value in values: widget.addItem(value.get("name", "Unnamed"), value.get("uid", ""))
        index = widget.findData(field.get(key, "")); widget.setCurrentIndex(max(0, index)); self._add(key, label, widget)

    def _members_table(self, field):
        table = QtWidgets.QTableWidget(0, 3); table.setHorizontalHeaderLabels(["Name", "Kind", "Bits"]); table.horizontalHeader().setStretchLastSection(True)
        for member in field.get("members", []): self._append_member(table, member)
        controls = QtWidgets.QWidget(); row = QtWidgets.QHBoxLayout(controls); row.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton("Add member"); remove = QtWidgets.QPushButton("Remove selected"); row.addWidget(add); row.addWidget(remove); row.addStretch()
        add.clicked.connect(lambda: self._add_member(table))
        remove.clicked.connect(lambda: self._remove_member(table))
        table.itemChanged.connect(self._emit_changed); self._layout.addRow("Bit members", table); self._layout.addRow("", controls); self._widgets["_members"] = table

    def _append_member(self, table, member):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row)
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(member.get("name", "flag"))))
            combo = QtWidgets.QComboBox(); combo.addItems(["flag", "unsigned", "signed", "padding"]); combo.setCurrentText(member.get("kind", "flag")); combo.currentIndexChanged.connect(self._emit_changed); table.setCellWidget(row, 1, combo)
            table.setItem(row, 2, QtWidgets.QTableWidgetItem(str(member.get("bits", 1)))); table.item(row, 0).setData(QtCore.Qt.UserRole, member.get("uid", new_id()))
        finally:
            table.blockSignals(previous)

    def _add_member(self, table):
        self._append_member(table, {"uid": new_id(), "name": "flag", "kind": "flag", "bits": 1})
        self.changed.emit()

    def _remove_member(self, table):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try: table.removeRow(row)
            finally: table.blockSignals(previous)
            self.changed.emit()

    def _read_members(self):
        table = self._widgets["_members"]; result = []
        for row in range(table.rowCount()):
            try: bits = int(table.item(row, 2).text())
            except (AttributeError, ValueError): bits = 1
            result.append({"uid": table.item(row, 0).data(QtCore.Qt.UserRole) or new_id(), "name": table.item(row, 0).text(), "kind": table.cellWidget(row, 1).currentText(), "bits": bits})
        return result

    def _cases_table(self, field):
        table = QtWidgets.QTableWidget(0, 2); table.setHorizontalHeaderLabels(["Case value", "Field type"]); table.horizontalHeader().setStretchLastSection(True)
        self._case_items = []
        for case in field.get("cases", []): self._append_case(table, case)
        controls = QtWidgets.QWidget(); row = QtWidgets.QHBoxLayout(controls); row.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton("Add case"); remove = QtWidgets.QPushButton("Remove selected"); row.addWidget(add); row.addWidget(remove); row.addStretch()
        add.clicked.connect(lambda: self._add_case(table))
        remove.clicked.connect(lambda: self._remove_case(table)); table.itemChanged.connect(self._emit_changed)
        self._layout.addRow("Cases", table); self._layout.addRow("", controls); self._widgets["_cases"] = table

    def _append_case(self, table, case):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row); self._case_items.append(copy.deepcopy(case.get("item") or new_field("case")))
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(case.get("value", "0"))))
            combo = QtWidgets.QComboBox(); combo.addItems(sorted(FIELD_KINDS)); combo.setCurrentText(self._case_items[-1].get("kind", "uint")); combo.currentIndexChanged.connect(self._emit_changed); table.setCellWidget(row, 1, combo)
        finally:
            table.blockSignals(previous)

    def _add_case(self, table):
        self._append_case(table, {"value": "0", "item": new_field("case", "uint")})
        self.changed.emit()

    def _remove_case(self, table):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try:
                table.removeRow(row); self._case_items.pop(row)
            finally:
                table.blockSignals(previous)
            self.changed.emit()

    def _read_cases(self):
        table = self._widgets["_cases"]; result = []
        for row in range(table.rowCount()):
            item = copy.deepcopy(self._case_items[row]); selected = table.cellWidget(row, 1).currentText()
            if item.get("kind") != selected:
                uid = item.get("uid"); item = new_field(item.get("name", "case"), selected); item["uid"] = uid or item["uid"]
            result.append({"value": table.item(row, 0).text(), "item": item})
        return result


def _prior_sibling_fields(manifest: dict[str, Any], target_uid: str) -> list[dict[str, Any]]:
    """Find earlier fields in the target's exact Construct Struct scope."""
    for owner in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        found, prior = _find_field_scope(owner.get("fields", []), target_uid)
        if found:
            return prior
    return []


def _find_field_scope(fields: list[dict[str, Any]], target_uid: str):
    prior = []
    for field in fields:
        if field.get("uid") == target_uid:
            return True, prior
        if field.get("kind") == "inline_struct":
            found, nested_prior = _find_field_scope(field.get("fields", []), target_uid)
            if found:
                return True, nested_prior
        nested = field.get("item")
        if isinstance(nested, dict):
            found, nested_prior = _find_field_scope([nested], target_uid)
            if found:
                return True, nested_prior
        for case in field.get("cases", []):
            nested = case.get("item")
            if isinstance(nested, dict):
                found, nested_prior = _find_field_scope([nested], target_uid)
                if found:
                    return True, nested_prior
        prior.append(field)
    return False, []


def _is_integer_reference(field: dict[str, Any]) -> bool:
    kind = field.get("kind")
    if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "enum"}:
        return True
    if kind in {"const", "default", "rebuild"} and isinstance(field.get("item"), dict):
        return _is_integer_reference(field["item"])
    return False
