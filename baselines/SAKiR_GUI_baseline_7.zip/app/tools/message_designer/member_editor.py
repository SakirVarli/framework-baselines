from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .model import new_id


DEFAULT_TAG_COLOR = "#5B6ACB"


class TagAssignmentEditor(QtWidgets.QWidget):
    """Assign catalog tags while allowing new names to be staged as plain text."""

    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._catalog: list[dict[str, Any]] = []
        self._assigned: list[str] = []
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.tags = QtWidgets.QListWidget(); self.tags.setMaximumHeight(92)
        self.tags.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tags.itemChanged.connect(self._tag_checked)
        layout.addWidget(self.tags)
        row = QtWidgets.QHBoxLayout()
        self.input = QtWidgets.QLineEdit(); self.input.setPlaceholderText("Type a new tag, then press Enter")
        self.remove_button = QtWidgets.QPushButton("Unassign selected")
        row.addWidget(self.input, 1); row.addWidget(self.remove_button); layout.addLayout(row)
        self.input.returnPressed.connect(self._accept_input)
        self.input.textChanged.connect(self._accept_comma)
        self.remove_button.clicked.connect(self._remove_selected)

    def load_tags(self, assigned_uids, catalog):
        self._catalog = copy.deepcopy(catalog)
        valid = {tag.get("uid") for tag in self._catalog}
        self._assigned = [uid for uid in assigned_uids if uid in valid]
        self._refresh()
        completer = QtWidgets.QCompleter([tag.get("name", "") for tag in self._catalog], self)
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        completer.setFilterMode(QtCore.Qt.MatchContains)
        self.input.setCompleter(completer)

    def value(self):
        return list(self._assigned), copy.deepcopy(self._catalog)

    def _accept_comma(self, text):
        if text.endswith(","):
            self.input.setText(text[:-1])
            self._accept_input()

    def _accept_input(self):
        name = self.input.text().strip()
        if not name:
            return
        match = next((tag for tag in self._catalog if tag.get("name", "").casefold() == name.casefold()), None)
        if match is None:
            match = {"uid": new_id(), "name": name, "color": DEFAULT_TAG_COLOR, "description": ""}
            self._catalog.append(match)
        if match["uid"] not in self._assigned:
            self._assigned.append(match["uid"])
            self.changed.emit()
        self.input.clear(); self._refresh()

    def _remove_selected(self):
        item = self.tags.currentItem()
        if item is not None and item.checkState() == QtCore.Qt.Checked:
            item.setCheckState(QtCore.Qt.Unchecked)

    def _tag_checked(self, item):
        uid = item.data(QtCore.Qt.UserRole)
        if not uid:
            return
        changed = False
        if item.checkState() == QtCore.Qt.Checked and uid not in self._assigned:
            self._assigned.append(uid); changed = True
        elif item.checkState() != QtCore.Qt.Checked and uid in self._assigned:
            self._assigned.remove(uid); changed = True
        previous = self.tags.blockSignals(True)
        try:
            font = item.font(); font.setBold(item.checkState() == QtCore.Qt.Checked); item.setFont(font)
        finally:
            self.tags.blockSignals(previous)
        if changed:
            self.changed.emit()

    def _refresh(self):
        previous = self.tags.blockSignals(True)
        try:
            self.tags.clear()
            for tag in self._catalog:
                uid = tag.get("uid")
                item = QtWidgets.QListWidgetItem(tag.get("name", ""))
                item.setData(QtCore.Qt.UserRole, uid)
                item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
                assigned = uid in self._assigned
                item.setCheckState(QtCore.Qt.Checked if assigned else QtCore.Qt.Unchecked)
                font = item.font(); font.setBold(assigned); item.setFont(font)
                color = QtGui.QColor(tag.get("color", DEFAULT_TAG_COLOR))
                if not color.isValid():
                    color = QtGui.QColor(DEFAULT_TAG_COLOR)
                pixmap = QtGui.QPixmap(10, 10); pixmap.fill(color); item.setIcon(QtGui.QIcon(pixmap))
                item.setToolTip(tag.get("description", ""))
                self.tags.addItem(item)
        finally:
            self.tags.blockSignals(previous)


class TagCatalogEditor(QtWidgets.QWidget):
    """Staged editor for the library-wide managed tag catalog."""

    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._uids: list[str] = []
        self._usage: dict[str, int] = {}
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.table = QtWidgets.QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Tag name", "Color", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.table.itemChanged.connect(self._item_changed)
        layout.addWidget(self.table)
        controls = QtWidgets.QHBoxLayout()
        self.add_button = QtWidgets.QPushButton("Add tag")
        self.color_button = QtWidgets.QPushButton("Choose color")
        self.remove_button = QtWidgets.QPushButton("Delete selected tag")
        self.add_button.clicked.connect(self._add_tag)
        self.color_button.clicked.connect(self._choose_color)
        self.remove_button.clicked.connect(self._remove_tag)
        controls.addWidget(self.add_button); controls.addWidget(self.color_button)
        controls.addWidget(self.remove_button); controls.addStretch()
        layout.addLayout(controls)

    def load_tags(self, tags, usage):
        previous = self.table.blockSignals(True)
        try:
            self.table.setRowCount(0); self._uids = []; self._usage = dict(usage)
            for tag in tags:
                self._append(tag)
        finally:
            self.table.blockSignals(previous)

    def value(self):
        result = []
        for row, uid in enumerate(self._uids):
            result.append({
                "uid": uid,
                "name": self.table.item(row, 0).text().strip(),
                "color": self.table.item(row, 1).text().strip(),
                "description": self.table.item(row, 2).text(),
            })
        return result

    def _append(self, tag):
        row = self.table.rowCount(); self.table.insertRow(row); self._uids.append(tag.get("uid", new_id()))
        self.table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(tag.get("name", "New tag"))))
        color_item = QtWidgets.QTableWidgetItem(str(tag.get("color", DEFAULT_TAG_COLOR)))
        self.table.setItem(row, 1, color_item); self._style_color(color_item)
        self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(str(tag.get("description", ""))))

    def _add_tag(self):
        previous = self.table.blockSignals(True)
        try:
            self._append({"uid": new_id(), "name": "New tag", "color": DEFAULT_TAG_COLOR, "description": ""})
        finally:
            self.table.blockSignals(previous)
        self.table.setCurrentCell(self.table.rowCount() - 1, 0); self.changed.emit()

    def _item_changed(self, item):
        if item.column() == 1:
            previous = self.table.blockSignals(True)
            try:
                self._style_color(item)
            finally:
                self.table.blockSignals(previous)
        self.changed.emit()

    def _style_color(self, item):
        color = QtGui.QColor(item.text())
        item.setBackground(QtGui.QBrush(color if color.isValid() else QtGui.QColor("transparent")))
        if color.isValid():
            item.setForeground(QtGui.QBrush(QtCore.Qt.white if color.lightness() < 150 else QtCore.Qt.black))

    def _choose_color(self):
        row = self.table.currentRow()
        if row < 0:
            return
        initial = QtGui.QColor(self.table.item(row, 1).text())
        color = QtWidgets.QColorDialog.getColor(initial if initial.isValid() else QtGui.QColor(DEFAULT_TAG_COLOR), self)
        if color.isValid():
            self.table.item(row, 1).setText(color.name().upper())

    def _remove_tag(self):
        row = self.table.currentRow()
        if row < 0:
            return
        uid = self._uids[row]; count = self._usage.get(uid, 0)
        if count:
            answer = QtWidgets.QMessageBox.question(
                self, "Delete assigned tag",
                f"This tag is assigned to {count} definition{'s' if count != 1 else ''}. "
                "Delete it and remove every assignment?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return
        previous = self.table.blockSignals(True)
        try:
            self.table.removeRow(row); self._uids.pop(row)
        finally:
            self.table.blockSignals(previous)
        self.changed.emit()


class DefinitionOptionsEditor(QtWidgets.QWidget):
    """Typed editors for enums and non-wire class members."""

    changed = QtCore.pyqtSignal()
    SUPPORTED = {"Library", "Message", "Enum", "Runtime", "Constant", "Method"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._kind = ""
        self._base: dict[str, Any] = {}
        self._loading = False
        self._widgets: dict[str, QtWidgets.QWidget] = {}
        self._value_uids: list[str] = []
        self._display_name = "custom_method"
        self._layout = QtWidgets.QFormLayout(self)
        self._layout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)

    def load_definition(self, value: dict[str, Any], kind: str) -> None:
        self._loading = True
        self._kind = kind
        self._base = copy.deepcopy(value)
        self._clear()
        if kind == "Library":
            self._library_settings(value)
        elif kind == "Message":
            message_id = QtWidgets.QSpinBox(); message_id.setRange(0, 2**31 - 1); message_id.setValue(int(value.get("message_id", 0)))
            self._add("message_id", "Message ID", message_id)
            self._combo("direction", "Direction", ["ANY", "TX", "RX"], {"direction": str(value.get("direction", "ANY")).upper()})
            self._line("display_name", "Registry display name", value)
            behavior = QtWidgets.QLabel(str(value.get("behavior_class", ""))); behavior.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._layout.addRow("Behavior mixin", behavior)
        elif kind == "Enum":
            self._enum_values(value)
        elif kind == "Runtime":
            self._line("annotation", "Type annotation", value)
            self._line("default", "Default expression", value)
            self._check("repr", "Include in repr", value)
        elif kind == "Constant":
            self._line("annotation", "Type annotation", value)
            self._line("value", "Value expression", value)
        elif kind == "Method":
            self._display_name = value.get("name", "custom_method")
            self._combo("kind", "Method kind", ["instance", "class", "static", "async", "property"], value)
            self._signature_label = QtWidgets.QLabel()
            self._signature_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._signature_label.setStyleSheet("font-family: Consolas, monospace; padding: 6px;")
            self._layout.addRow("Generated signature", self._signature_label)
            self._widgets["kind"].currentTextChanged.connect(self._update_signature)
            self._update_signature()
        self._loading = False

    def value(self) -> dict[str, Any]:
        result = copy.deepcopy(self._base)
        if self._kind == "Library":
            result["package_name"] = self._widgets["package_name"].text().strip()
            if self._widgets["extractor_enabled"].isChecked():
                mask_text = self._widgets["extractor_mask"].text().strip()
                mask = None if not mask_text or mask_text.lower() == "none" else int(mask_text, 0)
                result["id_extractor"] = {
                    "offset": self._widgets["extractor_offset"].value(),
                    "width": self._widgets["extractor_width"].value(),
                    "byteorder": self._widgets["extractor_byteorder"].currentText(),
                    "mask": mask,
                    "shift": self._widgets["extractor_shift"].value(),
                }
            else:
                result["id_extractor"] = None
            return result
        for key, widget in self._widgets.items():
            if isinstance(widget, QtWidgets.QLineEdit): result[key] = widget.text()
            elif isinstance(widget, QtWidgets.QPlainTextEdit): result[key] = widget.toPlainText()
            elif isinstance(widget, QtWidgets.QCheckBox): result[key] = widget.isChecked()
            elif isinstance(widget, QtWidgets.QComboBox): result[key] = widget.currentText()
            elif isinstance(widget, QtWidgets.QSpinBox): result[key] = widget.value()
        if self._kind == "Enum": result["values"] = self._read_enum_values()
        elif self._kind == "Method":
            result.pop("parameters", None)
            result.pop("return_annotation", None)
            result.pop("docstring", None)
        return result

    def set_display_name(self, name: str) -> None:
        self._display_name = name or "custom_method"
        if self._kind == "Method": self._update_signature()

    def _update_signature(self, *args) -> None:
        kind = self._widgets.get("kind").currentText() if self._widgets.get("kind") else "instance"
        decorators = {"class": "@classmethod\n", "static": "@staticmethod\n", "property": "@property\n"}
        first = "cls" if kind == "class" else ("" if kind == "static" else "self")
        async_prefix = "async " if kind == "async" else ""
        self._signature_label.setText(f"{decorators.get(kind, '')}{async_prefix}def {self._display_name}({first}):")

    def _clear(self):
        while self._layout.rowCount(): self._layout.removeRow(0)
        self._widgets.clear()

    def _emit_changed(self, *args):
        if not self._loading: self.changed.emit()

    def _add(self, key, label, widget):
        self._widgets[key] = widget; self._layout.addRow(label, widget)
        if isinstance(widget, QtWidgets.QLineEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QPlainTextEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QCheckBox): widget.toggled.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QComboBox): widget.currentIndexChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QSpinBox): widget.valueChanged.connect(self._emit_changed)

    def _line(self, key, label, value): self._add(key, label, QtWidgets.QLineEdit(str(value.get(key, ""))))

    def _check(self, key, label, value):
        widget = QtWidgets.QCheckBox(); widget.setChecked(bool(value.get(key, True))); self._add(key, label, widget)

    def _combo(self, key, label, values, value):
        widget = QtWidgets.QComboBox(); widget.addItems(values); widget.setCurrentText(str(value.get(key, values[0]))); self._add(key, label, widget)

    def _library_settings(self, value):
        self._line("package_name", "Python package name", value)
        extractor = value.get("id_extractor") or {}
        enabled = QtWidgets.QCheckBox("Read the message ID from a fixed byte location")
        enabled.setChecked(value.get("id_extractor") is not None)
        self._add("extractor_enabled", "Automatic decode", enabled)

        offset = QtWidgets.QSpinBox(); offset.setRange(0, 2**31 - 1); offset.setValue(int(extractor.get("offset", 0)))
        self._add("extractor_offset", "ID byte offset", offset)
        width = QtWidgets.QSpinBox(); width.setRange(1, 1024); width.setValue(int(extractor.get("width", 1)))
        self._add("extractor_width", "ID width (bytes)", width)
        byteorder = QtWidgets.QComboBox(); byteorder.addItems(["big", "little"]); byteorder.setCurrentText(extractor.get("byteorder", "big"))
        self._add("extractor_byteorder", "ID byte order", byteorder)
        mask = extractor.get("mask")
        mask_edit = QtWidgets.QLineEdit("" if mask is None else hex(mask)); mask_edit.setPlaceholderText("Optional, for example 0xF0")
        self._add("extractor_mask", "Bit mask", mask_edit)
        shift = QtWidgets.QSpinBox(); shift.setRange(0, 2**31 - 1); shift.setValue(int(extractor.get("shift", 0)))
        self._add("extractor_shift", "Right shift", shift)
        enabled.toggled.connect(self._update_extractor_enabled)
        self._update_extractor_enabled()

    def _update_extractor_enabled(self, *args):
        enabled = self._widgets.get("extractor_enabled")
        active = enabled.isChecked() if enabled else False
        for key in ("extractor_offset", "extractor_width", "extractor_byteorder", "extractor_mask", "extractor_shift"):
            if key in self._widgets: self._widgets[key].setEnabled(active)

    def _table_controls(self, table, add_text, add_callback, remove_callback):
        controls = QtWidgets.QWidget(); layout = QtWidgets.QHBoxLayout(controls); layout.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton(add_text); remove = QtWidgets.QPushButton("Remove selected")
        add.clicked.connect(add_callback); remove.clicked.connect(remove_callback)
        layout.addWidget(add); layout.addWidget(remove); layout.addStretch(); return controls

    def _enum_values(self, value):
        table = QtWidgets.QTableWidget(0, 2); table.setHorizontalHeaderLabels(["Member name", "Integer value"])
        table.horizontalHeader().setStretchLastSection(True); self._value_uids = []
        for member in value.get("values", []): self._append_enum_value(table, member)
        controls = self._table_controls(
            table, "Add enum value",
            lambda: self._add_enum_value(table),
            lambda: self._remove_row(table, self._value_uids),
        )
        table.itemChanged.connect(self._emit_changed)
        self._layout.addRow("Enum values", table); self._layout.addRow("", controls); self._widgets["_enum_values"] = table

    def _append_enum_value(self, table, member):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row); self._value_uids.append(member.get("uid", new_id()))
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(member.get("name", "VALUE"))))
            table.setItem(row, 1, QtWidgets.QTableWidgetItem(str(member.get("value", 0))))
        finally:
            table.blockSignals(previous)

    def _add_enum_value(self, table):
        self._append_enum_value(table, {"uid": new_id(), "name": "VALUE", "value": 0})
        self.changed.emit()

    def _read_enum_values(self):
        table = self._widgets["_enum_values"]; result = []
        for row in range(table.rowCount()):
            text = table.item(row, 1).text().strip()
            try: number = int(text, 0)
            except ValueError: number = text
            result.append({"uid": self._value_uids[row], "name": table.item(row, 0).text(), "value": number})
        return result

    def _remove_row(self, table, uid_list):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try:
                table.removeRow(row); uid_list.pop(row)
            finally:
                table.blockSignals(previous)
            self.changed.emit()
