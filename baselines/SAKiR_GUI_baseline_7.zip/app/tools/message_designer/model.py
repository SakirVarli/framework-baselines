from __future__ import annotations

import copy
import re
import uuid
from collections.abc import Callable, Iterable
from typing import Any


FORMAT_NAME = "sakir-message-library"
SCHEMA_VERSION = 2
PACKAGE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def new_id() -> str:
    return uuid.uuid4().hex


def new_manifest(package_name: str = "protocol_messages") -> dict[str, Any]:
    return {
        "format": FORMAT_NAME,
        "schema_version": SCHEMA_VERSION,
        "library": {
            "uid": new_id(),
            "package_name": package_name,
            "display_name": package_name.replace("_", " ").title(),
            "id_extractor": None,
            "extra_imports": [],
        },
        "tags": [],
        "enums": [],
        "structures": [],
        "messages": [],
        "compatibility_history": [],
        "generated_hashes": {},
        "behavior_hash": "",
    }


def normalize_manifest(data: dict[str, Any]) -> dict[str, Any]:
    """Migrate compatible in-memory manifests to the current identity spelling."""
    result = copy.deepcopy(data)
    result["schema_version"] = SCHEMA_VERSION
    result.setdefault("tags", [])
    for definition in [
        *result.get("enums", []), *result.get("structures", []), *result.get("messages", []),
    ]:
        definition.setdefault("tag_uids", [])
    for message in result.get("messages", []):
        legacy_direction = message.pop("tx_rx", None)
        direction = message.get("direction", legacy_direction or "ANY")
        message["direction"] = str(direction).upper()
    return result


def new_enum(name: str = "NewEnum") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "tag_uids": [],
        "values": [{"uid": new_id(), "name": "VALUE", "value": 0}],
    }


def new_structure(name: str = "NewStruct") -> dict[str, Any]:
    return {"uid": new_id(), "name": name, "tag_uids": [], "fields": []}


def new_message(name: str = "NewMessage", message_id: int = 0) -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "display_name": name,
        "message_id": message_id,
        "direction": "ANY",
        "tag_uids": [],
        "behavior_class": f"{name}Behavior",
        "fields": [],
        "runtime_attributes": [],
        "constants": [],
        "methods": [],
    }


def new_field(name: str = "field", kind: str = "uint") -> dict[str, Any]:
    defaults: dict[str, Any] = {
        "uint": {"width": 1, "endian": "big"},
        "int": {"width": 1, "endian": "big"},
        "bytes_integer": {"length": 3, "signed": False, "endian": "big"},
        "varint": {},
        "zigzag": {},
        "float": {"width": 4, "endian": "big"},
        "bool": {},
        "enum": {"enum_uid": "", "width": 1, "endian": "big"},
        "bytes": {"mode": "fixed", "length": 1, "length_field": ""},
        "string": {"mode": "fixed", "length": 1, "encoding": "utf8", "length_field": ""},
        "bitfield": {"members": [
            {"uid": new_id(), "name": "flag", "kind": "flag", "bits": 1},
            {"uid": new_id(), "name": "reserved", "kind": "padding", "bits": 7},
        ]},
        "array": {"mode": "fixed", "count": 1, "count_field": ""},
        "struct": {"struct_uid": ""},
        "inline_struct": {"fields": []},
        "conditional": {"condition": "this.enabled"},
        "switch": {"selector": "this.kind", "cases": [], "default": "Pass"},
        "const": {"value": "0"},
        "default": {"value": "0"},
        "padding": {"length": 1},
        "aligned": {"modulus": 4},
        "computed": {"expression": "0"},
        "rebuild": {"expression": "0"},
        "checksum": {"algorithm": "crc32", "source": "this.payload"},
        "advanced": {"expression": "Int8ub"},
    }
    if kind not in defaults:
        raise ValueError(f"Unknown field kind: {kind}")
    result = {
        "uid": new_id(), "name": name, "kind": kind,
        "object_default_mode": "required", "object_default": "",
        **copy.deepcopy(defaults[kind]),
    }
    if kind in {"array", "conditional", "const", "default", "aligned", "rebuild", "checksum"}:
        result["item"] = new_field("value" if kind != "array" else "item", "uint")
    return result


def new_runtime_attribute(name: str = "runtime_value") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "annotation": "Any",
        "default": "None",
        "repr": True,
    }


def new_constant(name: str = "CONSTANT") -> dict[str, Any]:
    return {"uid": new_id(), "name": name, "annotation": "Any", "value": "None"}


def new_method(name: str = "custom_method") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "kind": "instance",
    }


class MessageDesignerDocument:
    def __init__(self, data: dict[str, Any] | None = None) -> None:
        self.data = normalize_manifest(data or new_manifest())
        self.saved_snapshot = copy.deepcopy(self.data)
        self.path: str | None = None
        self._listeners: list[Callable[[str], None]] = []

    def on_change(self, callback: Callable[[str], None]) -> None:
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[str], None]) -> None:
        if callback in self._listeners:
            self._listeners.remove(callback)

    def notify(self, reason: str = "changed") -> None:
        for callback in tuple(self._listeners):
            callback(reason)

    @property
    def is_dirty(self) -> bool:
        return self.data != self.saved_snapshot

    def snapshot(self) -> dict[str, Any]:
        return copy.deepcopy(self.data)

    def replace(self, data: dict[str, Any], *, reason: str = "changed") -> None:
        self.data = normalize_manifest(data)
        self.notify(reason)

    def mark_saved(self, data: dict[str, Any] | None = None) -> None:
        if data is not None:
            self.data = copy.deepcopy(data)
        self.saved_snapshot = copy.deepcopy(self.data)
        self.notify("saved")

    def restore_saved(self) -> None:
        self.data = copy.deepcopy(self.saved_snapshot)
        self.notify("restored")

    def all_objects(self) -> Iterable[dict[str, Any]]:
        yield self.data["library"]
        yield from self.data.get("enums", [])
        yield from self.data.get("structures", [])
        for structure in self.data.get("structures", []):
            yield from walk_fields(structure.get("fields", []))
        yield from self.data.get("messages", [])
        for message in self.data.get("messages", []):
            yield from walk_fields(message.get("fields", []))
            yield from message.get("runtime_attributes", [])
            yield from message.get("constants", [])
            yield from message.get("methods", [])

    def find(self, uid: str) -> dict[str, Any] | None:
        return next((item for item in self.all_objects() if item.get("uid") == uid), None)


def walk_fields(fields: Iterable[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    for field in fields:
        yield field
        for key in ("item",):
            nested = field.get(key)
            if isinstance(nested, dict):
                yield from walk_fields([nested])
        yield from walk_fields(field.get("fields", []))
        for member in field.get("members", []):
            if isinstance(member, dict):
                yield member
        for case in field.get("cases", []):
            nested = case.get("item")
            if isinstance(nested, dict):
                yield from walk_fields([nested])
