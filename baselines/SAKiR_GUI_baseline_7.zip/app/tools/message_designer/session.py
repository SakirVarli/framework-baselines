from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any


SESSION_VERSION = 2


def default_session_path() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".sakir"))
    return base / "SAKiR" / "message-designer-session.json"


def save_session(
    path: Path,
    manifest: dict[str, Any],
    saved_snapshot: dict[str, Any],
    *,
    package_dir: Path | None,
    selected_uid: str,
    expanded_tree_keys: list[str] | None = None,
) -> None:
    payload = {
        "session_version": SESSION_VERSION,
        "manifest": manifest,
        "saved_snapshot": saved_snapshot,
        "package_dir": str(package_dir) if package_dir else None,
        "selected_uid": selected_uid,
        "expanded_tree_keys": sorted(set(expanded_tree_keys or [])),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def load_session(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("session_version") not in {1, SESSION_VERSION}:
        return None
    if not isinstance(payload.get("manifest"), dict) or not isinstance(payload.get("saved_snapshot"), dict):
        return None
    payload["session_version"] = SESSION_VERSION
    payload.setdefault("expanded_tree_keys", [])
    return copy.deepcopy(payload)


def clear_session(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
