from __future__ import annotations

import ast
import keyword
import re
from dataclasses import dataclass
from typing import Any

from .model import FORMAT_NAME, PACKAGE_RE, SCHEMA_VERSION, walk_fields


RESERVED_MEMBERS = {
    "WIRE_SCHEMA", "MESSAGE_ID", "MESSAGE_NAME", "codec", "decode", "encode",
    "from_bytes", "to_bytes", "send",
}
FIELD_KINDS = {
    "uint", "int", "bytes_integer", "varint", "zigzag", "float", "bool",
    "enum", "bytes", "string", "bitfield", "array", "struct", "inline_struct", "conditional",
    "switch", "const", "default", "padding", "aligned", "computed", "rebuild",
    "checksum", "advanced",
}


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    severity: str
    code: str
    message: str
    uid: str = ""

    @property
    def blocking(self) -> bool:
        return self.severity == "error"


def _identifier(value: Any) -> bool:
    return isinstance(value, str) and value.isidentifier() and not keyword.iskeyword(value)


def _parse_expression(expression: Any) -> bool:
    if not isinstance(expression, str) or not expression.strip():
        return False
    try:
        ast.parse(expression, mode="eval")
        return True
    except SyntaxError:
        return False


def validate_manifest(data: dict[str, Any]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    if data.get("format") != FORMAT_NAME:
        issues.append(ValidationIssue("error", "format", "Not a SAKiR message-library manifest."))
    if data.get("schema_version") != SCHEMA_VERSION:
        issues.append(ValidationIssue("error", "version", f"Unsupported manifest version: {data.get('schema_version')}"))

    library = data.get("library", {})
    package_name = library.get("package_name", "")
    if not PACKAGE_RE.fullmatch(str(package_name)):
        issues.append(ValidationIssue("error", "package-name", "Package name must be a Python identifier.", library.get("uid", "")))
    for statement in library.get("extra_imports", []):
        try:
            parsed = ast.parse(statement)
            if len(parsed.body) != 1 or not isinstance(parsed.body[0], (ast.Import, ast.ImportFrom)):
                raise SyntaxError
        except (SyntaxError, TypeError):
            issues.append(ValidationIssue("error", "extra-import", f"Invalid import statement: {statement!r}.", library.get("uid", "")))

    all_uids: set[str] = set()
    for category in ("enums", "structures", "messages"):
        for item in data.get(category, []):
            uid = item.get("uid", "")
            if not uid or uid in all_uids:
                issues.append(ValidationIssue("error", "duplicate-uid", "Every definition needs a unique stable ID.", uid))
            all_uids.add(uid)

    tag_uids: set[str] = set()
    tag_names: set[str] = set()
    tag_issue_uid = library.get("uid", "")
    for tag in data.get("tags", []):
        uid = tag.get("uid", "")
        name = tag.get("name", "")
        color = tag.get("color", "")
        if not uid or uid in all_uids or uid in tag_uids:
            issues.append(ValidationIssue("error", "tag-uid", "Every tag needs a unique stable ID.", tag_issue_uid))
        tag_uids.add(uid)
        normalized_name = name.strip().casefold() if isinstance(name, str) else ""
        if not isinstance(name, str) or name != name.strip() or not (1 <= len(name) <= 64) or "," in name or "\n" in name or "\r" in name:
            issues.append(ValidationIssue("error", "tag-name", "Tag names must be trimmed, 1–64 characters, and cannot contain commas or newlines.", tag_issue_uid))
        elif normalized_name in tag_names:
            issues.append(ValidationIssue("error", "tag-name", f"Duplicate tag name '{name}'.", tag_issue_uid))
        tag_names.add(normalized_name)
        if not isinstance(color, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
            issues.append(ValidationIssue("error", "tag-color", f"Tag color for '{name}' must use #RRGGBB.", tag_issue_uid))
        if not isinstance(tag.get("description", ""), str):
            issues.append(ValidationIssue("error", "tag-description", f"Tag description for '{name}' must be text.", tag_issue_uid))

    for definition in [*data.get("enums", []), *data.get("structures", []), *data.get("messages", [])]:
        assigned = definition.get("tag_uids", [])
        if not isinstance(assigned, list) or len(assigned) != len(set(assigned)):
            issues.append(ValidationIssue("error", "tag-assignment", "Tag assignments must be a unique ordered list.", definition.get("uid", "")))
            continue
        for tag_uid in assigned:
            if tag_uid not in tag_uids:
                issues.append(ValidationIssue("error", "tag-reference", "Definition references a missing tag.", definition.get("uid", "")))

    enums = {item.get("uid"): item for item in data.get("enums", [])}
    structures = {item.get("uid"): item for item in data.get("structures", [])}
    type_names: dict[str, str] = {}
    for item in [*enums.values(), *structures.values(), *data.get("messages", [])]:
        name = item.get("name", "")
        uid = item.get("uid", "")
        if not _identifier(name):
            issues.append(ValidationIssue("error", "identifier", f"'{name}' is not a valid Python class name.", uid))
        elif name in type_names:
            issues.append(ValidationIssue("error", "duplicate-type", f"Duplicate type name '{name}'.", uid))
        type_names[name] = uid

    for enum in enums.values():
        names: set[str] = set()
        values: set[int] = set()
        for member in enum.get("values", []):
            name, value = member.get("name", ""), member.get("value")
            if not _identifier(name):
                issues.append(ValidationIssue("error", "enum-name", f"Invalid enum member '{name}'.", enum["uid"]))
            if name in names:
                issues.append(ValidationIssue("error", "enum-name", f"Duplicate enum member '{name}'.", enum["uid"]))
            if not isinstance(value, int) or isinstance(value, bool):
                issues.append(ValidationIssue("error", "enum-value", f"Enum value for '{name}' must be an integer.", enum["uid"]))
            elif value in values:
                issues.append(ValidationIssue("warning", "enum-alias", f"Enum value {value} is an alias.", enum["uid"]))
            names.add(name)
            values.add(value)

    identities: dict[tuple[int, str], str] = {}
    directions_by_id: dict[int, set[str]] = {}
    behavior_names: set[str] = set()
    registry_names: set[str] = set()
    for message in data.get("messages", []):
        message_id = message.get("message_id")
        direction = str(message.get("direction", message.get("tx_rx", "ANY"))).upper()
        if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id < 0:
            issues.append(ValidationIssue("error", "message-id", "Message ID must be a non-negative integer.", message.get("uid", "")))
        elif direction not in {"TX", "RX", "ANY"}:
            issues.append(ValidationIssue("error", "message-direction", "Direction must be TX, RX, or ANY.", message.get("uid", "")))
        else:
            key = (message_id, direction)
            prior_directions = directions_by_id.setdefault(message_id, set())
            if key in identities:
                issues.append(ValidationIssue("error", "duplicate-message-id", f"Message identity ({message_id}, {direction}) is already used by {identities[key]}.", message.get("uid", "")))
            elif prior_directions and (direction == "ANY" or "ANY" in prior_directions):
                issues.append(ValidationIssue("error", "ambiguous-message-id", f"Message ID {message_id} cannot combine ANY with TX or RX definitions.", message.get("uid", "")))
            else:
                identities[key] = message.get("name", "")
                prior_directions.add(direction)
        behavior = message.get("behavior_class", "")
        if not _identifier(behavior):
            issues.append(ValidationIssue("error", "behavior-name", f"Invalid behavior class '{behavior}'.", message.get("uid", "")))
        elif behavior in behavior_names:
            issues.append(ValidationIssue("error", "behavior-name", f"Duplicate behavior class '{behavior}'.", message.get("uid", "")))
        behavior_names.add(behavior)
        registry_name = message.get("display_name") or message.get("name")
        if registry_name in registry_names:
            issues.append(ValidationIssue("error", "registry-name", f"Duplicate message registry name '{registry_name}'.", message.get("uid", "")))
        registry_names.add(registry_name)
        _validate_members(message, enums, structures, issues)

    for structure in structures.values():
        _validate_fields(structure.get("fields", []), enums, structures, issues, structure.get("uid", ""))
    _validate_cycles(structures, issues)
    _validate_extractor(library.get("id_extractor"), issues, library.get("uid", ""))
    return issues


def validate_behavior_methods(source: str | None, messages: list[dict[str, Any]]) -> list[ValidationIssue]:
    """Report behavior-file drift without modifying user-owned method bodies."""
    issues: list[ValidationIssue] = []
    if source is None:
        for message in messages:
            for method in message.get("methods", []):
                issues.append(ValidationIssue(
                    "warning", "empty-method",
                    f"Method {message['behavior_class']}.{method['name']} has an empty generated stub.",
                    method.get("uid", ""),
                ))
        return issues
    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        return [ValidationIssue("error", "behavior-syntax", f"behaviors.py has invalid syntax: {error}")]
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    for message in messages:
        class_name = message.get("behavior_class", "")
        class_node = classes.get(class_name)
        if class_node is None:
            issues.append(ValidationIssue(
                "warning", "missing-behavior-class",
                f"Behavior mixin {class_name} is missing from behaviors.py; it will be recreated on save.",
                message.get("uid", ""),
            ))
            continue
        methods = {
            node.name: node for node in class_node.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        if "send" in methods:
            issues.append(ValidationIssue(
                "error", "reserved-behavior-method",
                f"Method {class_name}.send overrides the BinaryMessage send API; rename it in behaviors.py.",
                message.get("uid", ""),
            ))
        for declaration in message.get("methods", []):
            label = f"{class_name}.{declaration['name']}"
            node = methods.get(declaration["name"])
            if node is None:
                issues.append(ValidationIssue(
                    "warning", "missing-method",
                    f"Method {label} is missing from behaviors.py; it will be recreated on save.",
                    declaration.get("uid", ""),
                ))
                continue
            actual_kind = _behavior_method_kind(node)
            expected_kind = declaration.get("kind", "instance")
            if actual_kind != expected_kind:
                issues.append(ValidationIssue(
                    "warning", "method-kind-drift",
                    f"Method {label} is {actual_kind} in behaviors.py but {expected_kind} in the designer; save will restore the designer kind.",
                    declaration.get("uid", ""),
                ))
            if not _behavior_signature_matches(node, expected_kind):
                issues.append(ValidationIssue(
                    "warning", "method-signature-drift",
                    f"Method {label} does not have the default {expected_kind} signature; save will restore it while preserving the body.",
                    declaration.get("uid", ""),
                ))
            if _empty_method_body(node.body):
                issues.append(ValidationIssue(
                    "warning", "empty-method", f"Method {label} is empty.", declaration.get("uid", ""),
                ))
    return issues


def _behavior_method_kind(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    if isinstance(node, ast.AsyncFunctionDef):
        return "async"
    decorators = {
        decorator.id for decorator in node.decorator_list if isinstance(decorator, ast.Name)
    }
    for kind in ("class", "static", "property"):
        decorator = "classmethod" if kind == "class" else ("staticmethod" if kind == "static" else "property")
        if decorator in decorators:
            return kind
    return "instance"


def _empty_method_body(statements: list[ast.stmt]) -> bool:
    body = list(statements)
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body.pop(0)
    return not body or all(isinstance(statement, ast.Pass) for statement in body)


def _behavior_signature_matches(node: ast.FunctionDef | ast.AsyncFunctionDef, kind: str) -> bool:
    expected = ["cls"] if kind == "class" else ([] if kind == "static" else ["self"])
    arguments = node.args
    positional = [*arguments.posonlyargs, *arguments.args]
    return (
        [argument.arg for argument in positional] == expected
        and all(argument.annotation is None for argument in positional)
        and not arguments.vararg
        and not arguments.kwarg
        and not arguments.kwonlyargs
        and not arguments.defaults
        and not arguments.kw_defaults
        and node.returns is None
    )


def _validate_members(message, enums, structures, issues):
    names: set[str] = set()
    for category in ("fields", "runtime_attributes", "constants", "methods"):
        for item in message.get(category, []):
            name = item.get("name", "")
            if not _identifier(name):
                issues.append(ValidationIssue("error", "member-name", f"Invalid member name '{name}'.", item.get("uid", "")))
            if name in names or name in RESERVED_MEMBERS:
                issues.append(ValidationIssue("error", "member-collision", f"Member name '{name}' is duplicated or reserved.", item.get("uid", "")))
            names.add(name)
    _validate_fields(message.get("fields", []), enums, structures, issues, message.get("uid", ""))
    for method in message.get("methods", []):
        if method.get("kind") not in {"instance", "class", "static", "async", "property"}:
            issues.append(ValidationIssue("error", "method-kind", "Unknown method kind.", method.get("uid", "")))
    for item in [*message.get("runtime_attributes", []), *message.get("constants", [])]:
        annotation = item.get("annotation", "")
        if annotation and not _parse_expression(annotation):
            issues.append(ValidationIssue("error", "attribute-annotation", f"Invalid annotation '{annotation}'.", item.get("uid", "")))
        expression = item.get("default") if item in message.get("runtime_attributes", []) else item.get("value")
        if expression and not _parse_expression(expression):
            issues.append(ValidationIssue("error", "attribute-default", f"Invalid value expression '{expression}'.", item.get("uid", "")))


def _validate_fields(fields, enums, structures, issues, owner_uid):
    prior_names: set[str] = set()
    prior_fields: dict[str, dict[str, Any]] = {}
    seen: set[str] = set()
    default_seen = False
    for field in fields:
        uid, name, kind = field.get("uid", owner_uid), field.get("name", ""), field.get("kind")
        if not _identifier(name):
            issues.append(ValidationIssue("error", "field-name", f"Invalid field name '{name}'.", uid))
        if name in seen:
            issues.append(ValidationIssue("error", "duplicate-field", f"Duplicate field '{name}'.", uid))
        seen.add(name)
        if kind not in FIELD_KINDS:
            issues.append(ValidationIssue("error", "field-kind", f"Unknown field kind '{kind}'.", uid))
            continue
        if kind != "padding":
            default_mode = field.get("object_default_mode", "required")
            if default_mode not in {"required", "automatic", "custom"}:
                issues.append(ValidationIssue("error", "object-default-mode", "Object default must be Required, Automatic, or Custom.", uid))
            elif default_mode == "custom" and not _parse_expression(field.get("object_default")):
                issues.append(ValidationIssue("error", "object-default-expression", "Custom object default must be a valid Python expression.", uid))
            elif default_mode == "automatic" and not _automatic_default_available(field, enums, structures, set()):
                issues.append(ValidationIssue(
                    "error", "object-default-unavailable",
                    "An automatic object default cannot be created for this field. Add defaults to required nested fields or use a custom expression.", uid,
                ))
            if default_mode == "required":
                if default_seen:
                    issues.append(ValidationIssue(
                        "error", "required-after-default",
                        "Required fields must appear before fields with object defaults.", uid,
                    ))
            else:
                default_seen = True
        if kind in {"uint", "int"} and field.get("width") not in {1, 2, 3, 4, 8}:
            issues.append(ValidationIssue("error", "integer-width", "Integer width must be 1, 2, 3, 4, or 8 bytes.", uid))
        if kind == "float" and field.get("width") not in {2, 4, 8}:
            issues.append(ValidationIssue("error", "float-width", "Float width must be 2, 4, or 8 bytes.", uid))
        if field.get("endian") not in {None, "big", "little"}:
            issues.append(ValidationIssue("error", "endian", "Byte order must be big or little.", uid))
        if kind == "enum" and field.get("enum_uid") not in enums:
            issues.append(ValidationIssue("error", "enum-reference", "Enum field references a missing enum.", uid))
        if kind == "struct" and field.get("struct_uid") not in structures:
            issues.append(ValidationIssue("error", "struct-reference", "Structure field references a missing structure.", uid))
        if kind in {"bytes", "string"}:
            mode = field.get("mode")
            if mode not in {"fixed", "count_field", "greedy", "null_terminated", "pascal"}:
                issues.append(ValidationIssue("error", "data-mode", f"Unsupported {kind} mode '{mode}'.", uid))
            if mode == "count_field":
                reference = field.get("length_field")
                if reference not in prior_names:
                    issues.append(ValidationIssue("error", "length-reference", "Length field must reference an earlier field in the same structure.", uid))
                elif not _is_integer_reference(prior_fields.get(reference, {})):
                    issues.append(ValidationIssue("error", "length-reference-type", "Length field must reference an integer-compatible field.", uid))
        if kind == "array":
            mode = field.get("mode")
            if mode not in {"fixed", "count_field", "prefixed", "greedy"}:
                issues.append(ValidationIssue("error", "array-mode", f"Unsupported array mode '{mode}'.", uid))
            if mode == "count_field":
                reference = field.get("count_field")
                if reference not in prior_names:
                    issues.append(ValidationIssue("error", "count-reference", "Array count must reference an earlier field in the same structure.", uid))
                elif not _is_integer_reference(prior_fields.get(reference, {})):
                    issues.append(ValidationIssue("error", "count-reference-type", "Array count must reference an integer-compatible field.", uid))
        if kind == "bitfield":
            bit_names: set[str] = set()
            total = 0
            for member in field.get("members", []):
                member_name = member.get("name", "")
                member_kind = member.get("kind")
                bits = member.get("bits", 0)
                if member_kind not in {"flag", "signed", "unsigned", "padding"}:
                    issues.append(ValidationIssue("error", "bit-kind", f"Unknown bit member kind '{member_kind}'.", uid))
                if not isinstance(bits, int) or isinstance(bits, bool) or bits <= 0:
                    issues.append(ValidationIssue("error", "bit-width", "Bit member widths must be positive integers.", uid))
                else:
                    total += bits
                if member_kind != "padding":
                    if not _identifier(member_name) or member_name in bit_names:
                        issues.append(ValidationIssue("error", "bit-name", f"Invalid or duplicate bit member '{member_name}'.", uid))
                    bit_names.add(member_name)
            if total <= 0 or total % 8:
                issues.append(ValidationIssue("error", "bit-alignment", "A bit group must contain a positive multiple of eight bits.", uid))
        if kind in {"bytes", "string"} and field.get("mode") == "fixed":
            if not isinstance(field.get("length"), int) or isinstance(field.get("length"), bool) or field.get("length") < 0:
                issues.append(ValidationIssue("error", "fixed-length", "Fixed length must be a non-negative integer.", uid))
        if kind == "array" and field.get("mode") == "fixed":
            if not isinstance(field.get("count"), int) or isinstance(field.get("count"), bool) or field.get("count") < 0:
                issues.append(ValidationIssue("error", "array-count", "Fixed array count must be a non-negative integer.", uid))
        if kind == "switch":
            case_values: set[str] = set()
            for case in field.get("cases", []):
                value_text = str(case.get("value", "")).strip()
                if value_text in case_values:
                    issues.append(ValidationIssue("error", "switch-case", f"Duplicate switch case '{value_text}'.", uid))
                case_values.add(value_text)
            default = field.get("default", "")
            if default and not _parse_expression(default):
                issues.append(ValidationIssue("error", "switch-default", "Switch default must be a Construct expression.", uid))
            selector = str(field.get("selector", ""))
            if not default and selector.startswith("this."):
                selector_field = prior_fields.get(selector.removeprefix("this."))
                if selector_field and selector_field.get("kind") == "enum":
                    expected = {str(member["value"]) for member in enums[selector_field["enum_uid"]].get("values", [])}
                    if expected != case_values:
                        issues.append(ValidationIssue("error", "switch-coverage", "Switch cases must cover every enum value when no default is provided.", uid))
        if kind in {"const", "default"} and not _parse_expression(field.get("value")):
            issues.append(ValidationIssue("error", "field-value", f"{kind.title()} value must be an expression.", uid))
        if kind == "padding" and (not isinstance(field.get("length"), int) or isinstance(field.get("length"), bool) or field.get("length") < 0):
            issues.append(ValidationIssue("error", "padding-length", "Padding length must be a non-negative integer.", uid))
        if kind == "aligned" and (not isinstance(field.get("modulus"), int) or isinstance(field.get("modulus"), bool) or field.get("modulus") <= 0):
            issues.append(ValidationIssue("error", "alignment", "Alignment modulus must be a positive integer.", uid))
        if kind == "checksum":
            algorithm = field.get("algorithm", "")
            if algorithm not in {"crc32", "sum8", "sha256"} and not _parse_expression(algorithm):
                issues.append(ValidationIssue("error", "checksum-algorithm", "Checksum algorithm must be crc32, sum8, sha256, or a callable expression.", uid))
        for expression_key in ("expression", "condition", "selector", "source"):
            if expression_key in field and not _parse_expression(field.get(expression_key)):
                issues.append(ValidationIssue("error", "expression", f"Invalid expression in {name}.{expression_key}.", uid))
        for nested_key in ("item",):
            nested = field.get(nested_key)
            if isinstance(nested, dict):
                _validate_fields([nested], enums, structures, issues, owner_uid)
        if kind == "inline_struct":
            _validate_fields(field.get("fields", []), enums, structures, issues, owner_uid)
        for case in field.get("cases", []):
            if not _parse_expression(case.get("value")):
                issues.append(ValidationIssue("error", "switch-value", "Switch case value must be an expression.", uid))
            if isinstance(case.get("item"), dict):
                _validate_fields([case["item"]], enums, structures, issues, owner_uid)
        prior_names.add(name)
        prior_fields[name] = field


def _automatic_default_available(field, enums, structures, visiting):
    kind = field.get("kind")
    if kind == "enum":
        enum = enums.get(field.get("enum_uid"))
        return bool(enum and enum.get("values"))
    if kind == "struct":
        uid = field.get("struct_uid")
        structure = structures.get(uid)
        if structure is None or uid in visiting:
            return False
        return _fields_default_constructible(
            structure.get("fields", []), enums, structures, visiting | {uid}
        )
    if kind == "inline_struct":
        return _fields_default_constructible(field.get("fields", []), enums, structures, visiting)
    if kind == "array":
        item = field.get("item")
        return isinstance(item, dict) and _automatic_default_available(item, enums, structures, visiting)
    if kind in {"const", "default", "aligned", "rebuild", "checksum"}:
        item = field.get("item")
        return isinstance(item, dict) and _automatic_default_available(item, enums, structures, visiting)
    if kind in {"switch", "advanced"}:
        return False
    return kind in FIELD_KINDS


def _is_integer_reference(field):
    kind = field.get("kind")
    if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "enum"}:
        return True
    if kind in {"const", "default", "rebuild"} and isinstance(field.get("item"), dict):
        return _is_integer_reference(field["item"])
    return False


def _fields_default_constructible(fields, enums, structures, visiting):
    for nested in fields:
        if nested.get("kind") == "padding":
            continue
        mode = nested.get("object_default_mode", "required")
        if mode == "required":
            return False
        if mode == "automatic" and not _automatic_default_available(nested, enums, structures, visiting):
            return False
    return True


def _validate_cycles(structures, issues):
    graph = {
        uid: {
            field.get("struct_uid")
            for field in walk_fields(structure.get("fields", []))
            if field.get("kind") == "struct" and field.get("struct_uid") in structures
        }
        for uid, structure in structures.items()
    }
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(uid: str) -> bool:
        if uid in visiting:
            return True
        if uid in visited:
            return False
        visiting.add(uid)
        cyclic = any(visit(child) for child in graph.get(uid, set()))
        visiting.remove(uid)
        visited.add(uid)
        return cyclic

    for uid in graph:
        if visit(uid):
            issues.append(ValidationIssue("error", "struct-cycle", f"Reusable structure '{structures[uid].get('name')}' is recursive.", uid))


def _validate_extractor(extractor, issues, uid):
    if extractor is None:
        return
    if not isinstance(extractor, dict):
        issues.append(ValidationIssue("error", "extractor", "Message-ID extractor must be an object.", uid))
        return
    if extractor.get("offset", -1) < 0 or extractor.get("width") not in {1, 2, 3, 4, 8}:
        issues.append(ValidationIssue("error", "extractor", "ID extractor needs a non-negative offset and supported width.", uid))
    if extractor.get("byteorder") not in {"big", "little"}:
        issues.append(ValidationIssue("error", "extractor", "ID extractor byte order must be big or little.", uid))


def blocking_issues(data: dict[str, Any]) -> list[ValidationIssue]:
    return [issue for issue in validate_manifest(data) if issue.blocking]
