"""Task-bound question cards: explicit answers, never execution approval."""
import copy
from PyQt5 import QtCore, QtWidgets


class ClarificationPanel(QtWidgets.QWidget):
    def __init__(self, controller, can_edit, select_changes, report_error, parent=None):
        super().__init__(parent)
        self.controller, self.can_edit = controller, can_edit
        self.select_changes, self.report_error = select_changes, report_error
        self.tasks, self.answer_inputs, self.revision_key = {}, {}, None
        self.setAccessibleName('Task questions and pending decisions')
        layout=QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        self.task_selector=QtWidgets.QComboBox()
        self.task_selector.setAccessibleName('Task needing input')
        self.task_selector.currentIndexChanged.connect(self.render)
        layout.addWidget(self.task_selector)
        self.scroll=QtWidgets.QScrollArea()
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setWidgetResizable(True)
        self.scroll.setMaximumHeight(260)
        self.scroll.setMinimumHeight(90)
        layout.addWidget(self.scroll)
        self.hide()

    def set_projection(self, projection):
        tasks={t['id']:copy.deepcopy(t) for t in self.controller.task_ledger.data['tasks']}
        active=projection.get('active_task')
        if active:
            tasks[active['id']]=copy.deepcopy(active)
        candidates={key:t for key,t in tasks.items() if any(q['status']=='pending' for q in t.get('questions',[]))
                    or t['status'] in {'awaiting_mode_change','incomplete'}}
        signature=[(key,t['revision'],t['status'],[(q['id'],q['status']) for q in t.get('questions',[])]) for key,t in candidates.items()]
        if signature==self.revision_key:
            self.set_busy(self.controller.busy)
            return
        self.revision_key, self.tasks = signature, candidates
        selected=self.task_selector.currentData()
        self.task_selector.blockSignals(True)
        self.task_selector.clear()
        for key,task in candidates.items():
            self.task_selector.addItem(task['summary'],key)
        preferred=selected if selected in candidates else (active or {}).get('id')
        if preferred in candidates:
            self.task_selector.setCurrentIndex(self.task_selector.findData(preferred))
        self.task_selector.blockSignals(False)
        self.setVisible(bool(candidates))
        self.task_selector.setVisible(len(candidates)>1)
        self.render()

    @staticmethod
    def label(value):
        widget=QtWidgets.QLabel(value)
        widget.setTextFormat(QtCore.Qt.PlainText)
        widget.setWordWrap(True)
        return widget

    def render(self, *unused):
        entered={key:widget.text() for key,widget in self.answer_inputs.items()}
        self.answer_inputs={}
        content=QtWidgets.QWidget()
        content.setObjectName('questionContent')
        content.setStyleSheet('QWidget#questionContent { background: #f6f8fb; border: 1px solid #dce1e8; border-radius: 8px; }')
        layout=QtWidgets.QVBoxLayout(content)
        task=self.tasks.get(self.task_selector.currentData())
        if task:
            if task['status']=='awaiting_mode_change':
                layout.addWidget(self.label('Create Changes prepares a draft for review; it does not apply or execute anything.'))
                button=QtWidgets.QPushButton('Switch to Create Changes')
                button.clicked.connect(lambda checked=False,t=task:self.resume(t,True))
                layout.addWidget(button)
            pending=[q for q in task.get('questions',[]) if q['status']=='pending']
            self.scroll.setMinimumHeight(200 if any(q['required'] for q in pending) else 140 if pending else 100)
            for q in pending[:3]:
                layout.addWidget(self.label(('Required: ' if q['required'] else 'Optional: ')+q['question']))
                if q.get('impact'):
                    layout.addWidget(self.label(q['impact']))
                choices=QtWidgets.QGridLayout()
                for index,option in enumerate(q['options']):
                    button=QtWidgets.QPushButton(option['label'])
                    button.setToolTip(option.get('description',''))
                    button.setAccessibleName('Answer: '+option['label'])
                    button.clicked.connect(lambda checked=False,t=task,question=q,o=option:self.answer(t,question,option_id=o['id']))
                    choices.addWidget(button,index//2,index%2)
                layout.addLayout(choices)
                row=QtWidgets.QHBoxLayout()
                entry=QtWidgets.QLineEdit(entered.get(q['id'],''))
                entry.setMaxLength(2000)
                entry.setPlaceholderText('Or write your answer…')
                entry.setAccessibleName('Answer to '+q['question'])
                self.answer_inputs[q['id']]=entry
                submit=QtWidgets.QPushButton('Answer')
                submit.clicked.connect(lambda checked=False,t=task,question=q,e=entry:self.answer(t,question,value=e.text()))
                entry.returnPressed.connect(lambda t=task,question=q,e=entry:self.answer(t,question,value=e.text()))
                row.addWidget(entry,1)
                row.addWidget(submit)
                if q.get('allow_delegate'):
                    delegate=QtWidgets.QPushButton('You choose')
                    delegate.clicked.connect(lambda checked=False,t=task,question=q:self.answer(t,question,delegate=True))
                    row.addWidget(delegate)
                layout.addLayout(row)
            if not pending and task['status'] in {'incomplete','gathering_evidence'}:
                button=QtWidgets.QPushButton('Continue task')
                button.clicked.connect(lambda checked=False,t=task:self.resume(t,False))
                layout.addWidget(button)
        layout.addStretch(1)
        old=self.scroll.takeWidget()
        self.scroll.setWidget(content)
        if old:
            old.deleteLater()
        self.set_busy(self.controller.busy)

    def set_busy(self, busy):
        self.task_selector.setEnabled(not busy)
        if self.scroll.widget():
            self.scroll.widget().setEnabled(not busy)

    def answer(self, task, question, **answer):
        try:
            self.controller.answer_question(task['id'],question['id'],task['revision'],can_edit=self.can_edit(),**answer)
        except Exception as exc:
            self.report_error(exc)

    def resume(self, task, change_mode):
        try:
            if change_mode:
                self.select_changes()
            self.controller.resume_task(task['id'],self.can_edit())
        except Exception as exc:
            self.report_error(exc)
