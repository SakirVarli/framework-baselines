"""Capability-bound reasoning controls, independent of output and task limits."""
from .policy import AssistantError


LEVELS = ('none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra', 'enabled')


def merge_profile(previous, discovered):
    result = {**previous, **discovered}
    if str(previous.get('reasoning_source','')).startswith('user configuration'):
        for key in ('reasoning_source','reasoning_efforts','reasoning_adapter'):
            if key in previous:
                result[key] = previous[key]
    return result


def profile_for(settings):
    profile = settings.capability_profile or {}
    return profile if (profile.get('base_url'), profile.get('model')) == (settings.base_url, settings.model) else {}


def supported_efforts(settings):
    profile = profile_for(settings)
    if profile.get('reasoning_adapter') not in {'native','llama_cpp'}:
        return []
    values = profile.get('reasoning_efforts', [])
    return [v for v in LEVELS if v in values and (v != 'enabled' or profile['reasoning_adapter']=='llama_cpp')] if isinstance(values, list) else []


def resolve_effort(settings, domains=(), exploration=False):
    levels = supported_efforts(settings)
    selected = settings.reasoning_effort
    if selected != 'auto':
        if selected not in levels:
            raise AssistantError('REASONING_UNSUPPORTED', 'This model has no verified support for effort ' + selected + '. Refresh models or select Auto.')
        return selected
    if not levels:
        return None  # Omit unsupported parameters; preserve the server default.
    if set(levels) <= {'none', 'enabled'}:
        return None  # Binary thinking is not a calibrated effort scale.
    wanted = 'high' if 'diagnosis' in domains or len(domains) > 2 else 'medium' if exploration or 'callbacks' in domains else 'low'
    return min(levels, key=lambda value: abs(LEVELS.index(value) - LEVELS.index(wanted)))


def request_options(settings, effort):
    if effort is None:
        return {}
    if effort not in supported_efforts(settings):
        raise AssistantError('REASONING_UNSUPPORTED', 'Unsupported reasoning effort for this connection.')
    adapter = profile_for(settings).get('reasoning_adapter')
    if adapter == 'native':
        if effort == 'enabled':
            raise AssistantError('REASONING_UNSUPPORTED', 'This provider does not support binary thinking control.')
        return {'reasoning_effort': effort}
    if adapter == 'llama_cpp':
        if effort == 'enabled':
            return {'extra_body': {'chat_template_kwargs': {'enable_thinking': True}}}
        return {'reasoning_effort': effort, 'extra_body': {'chat_template_kwargs': {'enable_thinking': effort != 'none'}}}
    raise AssistantError('REASONING_UNSUPPORTED', 'No verified reasoning adapter for this connection.')
