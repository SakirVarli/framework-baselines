"""Versioned user responses and turn provenance, separate from stage summaries."""
from dataclasses import asdict, dataclass, field
import uuid
import ast
import re
import textwrap
import warnings

from .policy import AssistantError


@dataclass(frozen=True)
class TurnEnvelope:
    origin: str = 'user_message'
    task_id: str | None = None
    user_message_id: str | None = None
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    version: int = 1

    def __post_init__(self):
        if self.origin not in {'user_message', 'resume_button', 'clarification_answer', 'retry'}:
            raise AssistantError('TURN_PROTOCOL', 'Unknown turn origin.')
        if self.origin in {'resume_button', 'retry'} and not self.task_id:
            raise AssistantError('TURN_PROTOCOL', 'Resume requires an explicit task binding.')

    def export(self):
        return asdict(self)


@dataclass(frozen=True)
class ResponseDraft:
    answer: str
    kind: str = 'explanation'
    evidence: tuple = ()
    limitations: tuple = ()
    version: int = 1

    def __post_init__(self):
        if (self.kind not in {'conversation', 'explanation', 'inspection'} or not isinstance(self.answer, str)
                or not self.answer.strip() or len(self.answer) > 48000):
            raise AssistantError('RESPONSE_REQUIRED', 'Provide the actual user-facing answer, not an internal completion summary.')
        for values in (self.evidence, self.limitations):
            if len(values) > 20 or any(not isinstance(v, str) or len(v) > 2000 for v in values):
                raise AssistantError('RESPONSE_PROTOCOL', 'Response evidence and limitations must be bounded text lists.')

    def export(self):
        return asdict(self)

    def text(self):
        text = self.answer.strip()
        if self.limitations:
            text += '\n\nLimitations: ' + '; '.join(self.limitations)
        return text


def validate_examples(answer):
    """Check the installed callback contract in Python examples; never execute.

    Class methods are intentionally excluded. This is a narrow framework check,
    not a claim to verify arbitrary explanation semantics or Python behavior.
    """
    for code in re.findall(r'```(?:python|py)\s*\n(.*?)```', answer, flags=re.I | re.S):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',SyntaxWarning)
                tree = ast.parse(textwrap.dedent(code))
        except SyntaxError:
            continue  # Incomplete illustrative snippets are not executable tests.
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                arguments = [*node.args.posonlyargs, *node.args.args]
                if any(a.arg == 'self' for a in arguments):
                    raise AssistantError('RESPONSE_CONTRACT', 'Framework callback examples must be top-level zero-argument functions, not methods taking self. Use display(instance, data, mode=...) and inspect the installed API before giving examples.')
