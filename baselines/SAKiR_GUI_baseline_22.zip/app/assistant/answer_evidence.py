"""Bounded host-owned evidence for answers and factual review. No code execution."""
import re
from urllib.parse import urlsplit, parse_qs, unquote

from .policy import AssistantError
from .retrieval import tokens


def discusses_help_topic(answer, records):
    """A cited procedure is not the only way to make an installed-tool claim."""
    terms = set(tokens(answer))
    return any(row.get('kind')=='help' and len(topic := set(tokens(row.get('title',''))))>=2
               and topic <= terms for row in records)


def citation_key(reference):
    if reference.startswith('sakir-help:'):
        return ('app/data/help.json', reference.removeprefix('sakir-help:').split('#')[0])
    if reference.startswith('sakir-source:'):
        parsed = urlsplit(reference)
        return (unquote(parsed.path),None)
    match = re.fullmatch(r'([\w./-]+)(?::(\d+))?', reference)
    return (match[1], None) if match else None


def citation_matches(reference, record):
    if citation_key(reference) != (record['path'],record.get('section_id')):
        return False
    if reference.startswith('sakir-source:'):
        parsed = urlsplit(reference)
        revision = parse_qs(parsed.query).get('revision',[None])[0]
        if revision and revision != record.get('content_revision'):
            return False
        match = re.fullmatch(r'L(\d+)',parsed.fragment)
        if parsed.fragment and not match:
            return False
    else:
        match = re.search(r':(\d+)$',reference)
    if match:
        first = record.get('line',record.get('start_line',1))
        last = record.get('end_line', first)
        return first <= int(match[1]) <= last
    return True


def resolve_citations(response, proofs, records):
    for reference in response.evidence:
        if not any(citation_matches(reference,r) for r in [*proofs,*records]):
            raise AssistantError('API_EVIDENCE_MISMATCH', 'Citation was not retrieved or inspected in this run: '+reference)


def review_bundle(tools, response, proofs):
    """Cited material is required. Other relevant inspected evidence is optional."""
    def required(row):
        return any(citation_matches(r,row) for r in response.evidence)
    terms = set(tokens(response.answer))
    rows = list(tools.answer_evidence)
    for proof in proofs:
        record = tools.index.cache.get(proof['path'], {})
        first = max(0, proof['line']-1)
        text = '\n'.join(record.get('text', '').splitlines()[first:first+65])
        rows.append({**proof, 'kind':'static_contract', 'text':text[:5000],
                     'truncated':True, 'basis':'static_api_contract'})
    rows.sort(key=lambda r: (required(r),
                            len(terms & set(tokens(r.get('title','')+' '+r.get('text','')[:1000])))), reverse=True)
    selected, seen, omitted = [], set(), []
    for row in rows:
        key = (row['path'], row.get('section_id'), row.get('line'), row.get('offset',0))
        if key in seen:
            continue
        seen.add(key)
        item = dict(row, required=required(row))
        if len(selected)<12 or item['required']:
            selected.append(item)
        else:
            omitted.append({'path':row['path'],'section_id':row.get('section_id'),'reason':'review_record_limit'})
    return selected, omitted
