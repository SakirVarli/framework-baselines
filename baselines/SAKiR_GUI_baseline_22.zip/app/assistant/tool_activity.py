"""Session-only tool details and read-only previews of retained results."""
import copy
import json

from PyQt5 import QtCore, QtGui, QtWidgets


def formatted(value):
    return json.dumps(value, ensure_ascii=False, indent=2, default=str)


class ToolCard(QtWidgets.QFrame):
    preview_requested = QtCore.pyqtSignal(object)

    def __init__(self, entry, parent=None):
        super().__init__(parent)
        self.setObjectName("toolCard")
        self.entry = entry
        self._details_key = None
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        self.toggle = QtWidgets.QToolButton()
        self.toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle.setCheckable(True)
        self.toggle.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.toggle.toggled.connect(self.expand)
        layout.addWidget(self.toggle)
        self.status = QtWidgets.QLabel()
        self.status.setTextFormat(QtCore.Qt.PlainText)
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.preview_button = QtWidgets.QPushButton("Preview result")
        self.preview_button.clicked.connect(lambda: self.preview_requested.emit(self.entry))
        layout.addWidget(self.preview_button)
        self.details = QtWidgets.QWidget()
        detail_layout = QtWidgets.QVBoxLayout(self.details)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        self.arguments = self.editor("Tool arguments", detail_layout)
        self.result = self.editor("Returned result", detail_layout)
        layout.addWidget(self.details)
        self.details.hide()
        self.update_entry(entry)

    @staticmethod
    def editor(title, layout):
        layout.addWidget(QtWidgets.QLabel(title))
        editor = QtWidgets.QPlainTextEdit()
        editor.setAccessibleName(title)
        editor.setReadOnly(True)
        editor.setFont(QtGui.QFont("Consolas", 9))
        editor.setMinimumHeight(90)
        editor.setMaximumHeight(180)
        layout.addWidget(editor)
        return editor

    def expand(self, expanded):
        self.toggle.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.details.setVisible(expanded)
        if expanded:
            self.refresh_details()

    def refresh_details(self):
        key = (self.entry.get("arguments"), self.entry.get("result"), self.entry.get("error"))
        if key == self._details_key:
            return
        self._details_key = copy.deepcopy(key)
        self.arguments.setPlainText(formatted(key[0]) if key[0] is not None else "Arguments unavailable.")
        self.result.setPlainText(formatted(key[1]) if key[1] is not None else key[2] or "Awaiting result…")

    def update_entry(self, entry):
        self.entry = entry
        name = entry["name"].replace("_", " ").capitalize()
        self.toggle.setText(name)
        self.toggle.setToolTip(name + " · Expand call details")
        self.toggle.setArrowType(QtCore.Qt.DownArrow if self.toggle.isChecked() else QtCore.Qt.RightArrow)
        status = entry["status"].capitalize()
        if entry.get("duration_ms") is not None:
            status += f" · {entry['duration_ms'] / 1000:.1f}s"
        result = entry.get("result")
        data = result.get("data", {}) if isinstance(result, dict) else {}
        if isinstance(result, dict) and result.get("truncated"):
            status += " · Tool result truncated"
        if isinstance(result, dict) and result.get("display_truncated"):
            status += " · Display shortened"
        if isinstance(data, dict) and "sample" in data:
            status += " · Sample"
        if isinstance(entry.get("preview"), dict) and entry["preview"].get("truncated"):
            status += " · Diff shortened"
        if isinstance(data, dict) and data.get("truncated"):
            status += " · Partial source"
        if isinstance(entry.get("arguments"), dict) and entry["arguments"].get("display_truncated"):
            status += " · Arguments shortened"
        if entry.get("error"):
            status += "\n" + entry["error"]
        self.status.setText(status)
        self.status.setTextFormat(QtCore.Qt.PlainText)
        self.status.setStyleSheet("color: #ad3d32;" if entry["status"] in {"failed", "interrupted"} else "")
        self.preview_button.setVisible(result is not None)
        self.preview_button.setText("Diff preview" if entry.get("preview") else "Data preview" if entry["name"] == "inspect_file" else
                                    "Source preview" if entry["name"] == "read_source" else "Preview result")
        if self.toggle.isChecked():
            self.refresh_details()


class ToolActivityPanel(QtWidgets.QFrame):
    preview_requested = QtCore.pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("toolsSidebar")
        self.setMinimumWidth(260)
        self.setMaximumWidth(520)
        self.cards = {}
        self.groups = {}
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 20, 14, 16)
        heading = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("Tools & Previews")
        title.setObjectName("brand")
        heading.addWidget(title, 1)
        layout.addLayout(heading)
        self.review_layout = QtWidgets.QVBoxLayout()
        layout.addLayout(self.review_layout)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.content = QtWidgets.QWidget()
        self.content.setObjectName("toolActivityContent")
        self.calls = QtWidgets.QVBoxLayout(self.content)
        self.calls.setContentsMargins(0, 0, 0, 0)
        self.empty = QtWidgets.QLabel("Tool calls and their previews will appear here.\nDetails are kept for this open chat session.")
        self.empty.setObjectName("muted")
        self.empty.setWordWrap(True)
        self.calls.addWidget(self.empty)
        self.calls.addStretch(1)
        self.scroll.setWidget(self.content)
        layout.addWidget(self.scroll, 1)

    def sync(self, activities, messages):
        bar = self.scroll.verticalScrollBar()
        follow = bar.maximum() - bar.value() <= 24
        for turn, activity in activities.items():
            for entry in activity.entries:
                if entry["kind"] != "tool":
                    continue
                if turn not in self.groups:
                    request = getattr(activity, 'request_label', messages[turn]['content'] if turn < len(messages) else 'Resumed task')
                    label = QtWidgets.QLabel(" ".join(request.split())[:100])
                    label.setTextFormat(QtCore.Qt.PlainText)
                    label.setObjectName("eyebrow")
                    label.setWordWrap(True)
                    self.calls.insertWidget(self.calls.count() - 1, label)
                    self.groups[turn] = label
                key = (turn, entry["message_id"], entry["id"])
                if key not in self.cards:
                    card = ToolCard(entry)
                    card.preview_requested.connect(self.preview_requested)
                    self.calls.insertWidget(self.calls.count() - 1, card)
                    self.cards[key] = card
                else:
                    self.cards[key].update_entry(entry)
        self.empty.setVisible(not self.cards)
        if follow:
            QtCore.QTimer.singleShot(0, lambda: bar.setValue(bar.maximum()))

    def clear(self):
        for widget in [*self.cards.values(), *self.groups.values()]:
            self.calls.removeWidget(widget)
            widget.deleteLater()
        self.cards.clear()
        self.groups.clear()
        self.empty.show()

    def show_turn(self, turn):
        if turn in self.groups:
            self.scroll.ensureWidgetVisible(self.groups[turn])


class ToolPreviewDialog(QtWidgets.QDialog):
    def __init__(self, entry, parent=None):
        super().__init__(parent)
        self.setWindowTitle(entry["name"].replace("_", " ").capitalize() + " · Result preview")
        self.resize(850, 600)
        layout = QtWidgets.QVBoxLayout(self)
        result = entry["result"]
        data = result.get("data", result) if isinstance(result, dict) else result
        notes = ["Retained result from this call. Read-only."]
        if entry.get("preview"):
            data = entry["preview"]
            notes = ["Retained proposal diff from this call. Read-only; use Review changes to apply the current proposal."]
        if isinstance(result, dict) and result.get("truncated"):
            notes.append("Tool result was truncated before being sent to the model.")
        if isinstance(result, dict) and result.get("display_truncated"):
            notes.append("Display shortened; the model received more content than this display retains.")
        if isinstance(data, dict):
            for key in ("path", "filename", "sheet", "state", "note"):
                if data.get(key):
                    notes.append(f"{key.capitalize()}: {data[key]}")
            if "sample" in data:
                notes.append("Sample only; this may not represent the complete file.")
            if data.get("truncated"):
                notes.append("Preview shortened; additional content is not shown.")
        note = QtWidgets.QLabel("\n".join(notes))
        note.setTextFormat(QtCore.Qt.PlainText)
        note.setWordWrap(True)
        layout.addWidget(note)
        if isinstance(data, dict) and isinstance(data.get("rows"), list) and isinstance(data.get("columns"), list):
            columns, rows = data["columns"], data["rows"]
            self.preview = QtWidgets.QTableWidget(len(rows), len(columns))
            self.preview.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.preview.setHorizontalHeaderLabels([str(value) for value in columns])
            for i, row in enumerate(rows):
                for j, value in enumerate(row[:len(columns)]):
                    self.preview.setItem(i, j, QtWidgets.QTableWidgetItem(str(value)))
        else:
            self.preview = QtWidgets.QPlainTextEdit()
            self.preview.setReadOnly(True)
            self.preview.setFont(QtGui.QFont("Consolas", 10))
            self.preview.setPlainText(data["text"] if isinstance(data, dict) and isinstance(data.get("text"), str) else formatted(data))
        layout.addWidget(self.preview, 1)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
