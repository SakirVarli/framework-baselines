"""Display-only, bounded activity for one user request. Never model history."""
import html
import time

from .tool_details import snapshot
from .chat_rendering import content_html, activity_html


class TurnActivity:
    def __init__(self):
        self.entries = []
        self.expanded = False
        self.started_at = time.monotonic()
        self.finished_at = None

    @property
    def elapsed_seconds(self):
        end = self.finished_at if self.finished_at is not None else time.monotonic()
        return max(0, int(end - self.started_at))

    @property
    def title(self):
        hours, remainder = divmod(self.elapsed_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        duration = ((f"{hours}h " if hours else "")
                    + (f"{minutes}m " if hours or minutes else "") + f"{seconds}s")
        return ("Working for " if self.finished_at is None else "Worked for ") + duration

    def text(self, kind, text, message_id=None):
        if not text:
            return
        if kind in {"reasoning", "pending"}:
            entry = next((item for item in self.entries if item["kind"] == kind and item.get("message_id") == message_id), None)
            if entry is not None:
                self._append(entry, text)
                return
        entry = {"kind": kind, "text": "", "message_id": message_id}
        self._append(entry, text)
        self.entries.append(entry)

    def complete_message(self, message_id, phase, text=""):
        """Replace the optional live preview instead of duplicating final text."""
        self.entries = [entry for entry in self.entries
                        if not (entry["kind"] == "pending" and entry.get("message_id") == message_id)]
        if phase in {"commentary", "interrupted"}:
            self.text(phase, text, message_id)

    @staticmethod
    def _append(entry, text):
        remaining = max(0, 8000 - len(entry["text"]))
        entry["text"] += text[:remaining]
        if len(text) > remaining:
            entry["shortened"] = True

    def tool(self, value, completed=False):
        entry = next((item for item in self.entries if item["kind"] == "tool"
                      and (item["id"], item["message_id"]) == (value["id"], value["message_id"])), None)
        if entry is None:
            entry = {"kind": "tool", "id": value["id"], "message_id": value["message_id"], "name": value["name"]}
            self.entries.append(entry)
        entry["status"] = value.get("status", "completed") if completed else "running"
        if "arguments" in value:
            entry["arguments"] = snapshot(value["arguments"], 16000)
        if completed:
            entry["duration_ms"] = value.get("duration_ms")
            entry["error"] = value.get("error", "")[:500]

    def tool_result(self, value):
        entry = next((item for item in reversed(self.entries) if item["kind"] == "tool"
                      and item["name"] == value["tool"]
                      and ("id" not in value or (item["id"], item["message_id"]) ==
                           (value["id"], value["message_id"]))), None)
        if entry is not None:
            entry["result"] = snapshot(value["result"])
            if value.get("preview"):
                entry["preview"] = snapshot(value["preview"])

    def finish(self):
        if self.finished_at is None:
            self.finished_at = time.monotonic()
        for entry in self.entries:
            if entry["kind"] == "tool" and entry["status"] == "running":
                entry["status"] = "interrupted"

    def render(self, turn, include_tools=True):
        state = "expanded" if self.expanded else "collapsed"
        arrow = f'<img src="sakir-icon:activity-{state}" width="12" height="12">'
        title = self.title
        failed = sum(item["kind"] == "tool" and item["status"] == "failed" for item in self.entries)
        suffix = f" · {failed} failed" if failed else ""
        parts = [f'<p style="margin:4px 0; font-size:9pt;"><a href="sakir-activity:{turn}" '
                 f'style="color:#697180; text-decoration:none;">{title}</a>{suffix}&nbsp; '
                 f'<a href="sakir-activity:{turn}" style="color:#697180; text-decoration:none;">{arrow}</a></p>']
        tool_count = sum(item["kind"] == "tool" for item in self.entries)
        if tool_count and not include_tools:
            noun = "tool call" if tool_count == 1 else "tool calls"
            parts.append(f'<p><a href="sakir-tools:{turn}">{tool_count} {noun} · View tools</a></p>')
        if self.expanded or any(e["kind"] in {"commentary", "pending", "interrupted"} for e in self.entries):
            entries = [entry for entry in self.entries
                       if (include_tools or entry["kind"] != "tool")
                       and (self.expanded or entry["kind"] != "reasoning")]
            if not entries:
                parts.append('<p style="color:#697180; font-size:9pt;">No additional details provided.</p>')
            for entry in entries:
                if entry["kind"] == "tool":
                    name = entry["name"].replace("_", " ").capitalize()
                    label = name + " · " + entry["status"]
                    if type(entry.get("duration_ms")) is int:
                        label += f" · {entry['duration_ms'] / 1000:.1f}s"
                    text = entry.get("error", "")
                    color = "#ad3d32" if entry["status"] in {"failed", "interrupted"} else "#697180"
                else:
                    label = "Provider reasoning" if entry["kind"] == "reasoning" else ""
                    text, color = entry["text"], "#697180"
                    if entry.get("shortened"):
                        text += "\n[Preview shortened]"
                if entry["kind"] in {"commentary", "pending", "interrupted"}:
                    parts.append(activity_html(text))
                else:
                    parts.append(f'<p style="margin:6px 0; color:{color}; font-size:9pt;"><b>{html.escape(label)}</b></p>'
                                 + (content_html(text) if text else ""))
        if self.finished_at is None:
            # Reserve document space for the existing native shimmer widget.
            parts.append(f'<p style="margin:0;"><a href="sakir-status:{turn}">'
                         '<img src="sakir-icon:live-status" width="1" height="28"></a></p>')
        return '<table width="100%" cellspacing="0" cellpadding="10"><tr><td>' + "".join(parts) + "</td></tr></table>"
