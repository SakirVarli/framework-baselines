"""Small installed-framework contracts. Property metadata comes from FEATURES."""
from copy import deepcopy
import re
from .retrieval import tokens


CONTRACT_VERSION = 1
CONTRACTS = {
    'layout': {
        'aliases': 'widget button group tab position bounds margin align anchor layout background color colour tooltip shortcut dugme buton konum',
        'tools': ['get_layout_schema', 'propose_layout', 'propose_tab', 'propose_tab_with_button_and_output'],
        'source': 'app/config_designer/schema.py',
        'contract': 'Canvas bounds=[x,y,width,height] use parent-relative logical pixels. Grid pos=[row,column,rowspan,colspan]. Inspect parent mode. anchors preserve edge distances; dock consumes available space. Button name is its label; callback is its explicit binding. Rename a label by updating name only, preserving callback. Center/relative modes set initial bounds, not persistent alignment constraints. Never invent position/size fields. Use propose_layout; do not replace config to add a widget.',
        'example': {'summary':'Add Run with 16 pixel bottom/right margins','operations':[{'action':'add','parent':'root/0','widget_type':'button','properties':{'name':'Run'},'placement':{'mode':'bottom_right','size':[100,36],'margin':16}}]}},
    'callbacks': {
        'aliases': 'callback function helper click clicked clicking press pressed pressing event behavior code python',
        'tools': ['get_symbol', 'read_source', 'search_source', 'propose_callback', 'propose_helper', 'propose_button_with_callback'],
        'source': 'app/stub_generator.py',
        'contract': 'Read affected existing code before edits. Preserve imports, unrelated definitions, GlobalsBase/init_globals and lifecycle contracts. Use propose_helper for a named function in externals/, propose_callback for top-level callbacks. Use propose_button_with_callback for a new button/function pair. If staging separately, create the button with its callback field before binding; do not bind a nonexistent button. Generated features execute locally without model calls.'},
    'data': {
        'aliases': 'file excel csv json xml mat binary spreadsheet workbook sheet column rows data veri dosya',
        'tools': ['inspect_file', 'list_project_files'],
        'source': 'app/assistant/readers.py',
        'contract': 'Inspect attached/project files before inferring columns or sheet names. Excel physical row numbers are 1-based. BIN/DAT needs an explicit schema. Samples are bounded; do not infer whole-file facts from a sample. Use app.stubs.PROJECT_ROOT for portable project paths.'},
    'output': {
        'aliases': 'output table display plot chart dataframe image text append replace tablo grafik',
        'tools': ['get_symbol', 'read_source', 'search_source', 'get_layout_schema', 'propose_layout'],
        'source': 'app/output_widgets.py',
        'contract': "Use display(instance,data,mode='replace') for outputs, with an existing or staged instance. To append use display(instance,data,mode='append'). This is a runtime display API, not a widget layout property. Inspect type-specific signatures for unfamiliar behavior. File processing must not block the GUI thread.",
        'examples': ["display('status', data, mode='replace')", "display('status', data, mode='append')"]},
    'lifecycle': {
        'aliases': 'globals global lifecycle thread worker startup reload resource dispose initialization kuresel',
        'tools': ['get_symbol', 'read_source', 'search_source'],
        'source': 'app/globals_api.py',
        'contract': 'Preserve Globals(GlobalsBase), init_globals(self), and reload ownership. Inspect exact lifecycle/worker APIs before custom code. Do not run blocking work on Qt GUI thread or dispose borrowed Tools services.'},
    'sessions': {
        'aliases': 'serial telnet ftp communication session connect disconnect send connection port baglanti',
        'tools': ['list_sessions', 'propose_runtime_action', 'propose_open_tool', 'get_symbol', 'read_source'],
        'source': 'app/tool_api.py',
        'contract': 'Inspection must not create/connect sessions. Only existing sessions support pending runtime actions. Stage connect/disconnect/send for the separate user Run Action click; never report staged actions as executed. Saved settings and current runtime status are different facts.'},
    'messages': {
        'aliases': 'message protocol manifest construct byte endian wire library packet framing',
        'tools': ['get_message_template', 'propose_message_library', 'inspect_file', 'get_symbol', 'read_source'],
        'source': 'app/tools/message_designer/model.py',
        'contract': 'Use propose_message_library to validate and generate libraries under externals. Preserve custom behaviors. Check field types, order, endianness, defaults and compatibility. Generation and syntax validation do not prove device interoperability.'},
    'diagnosis': {
        'aliases': 'error exception traceback broken fails failing diagnose debug wrong nothing failure hata',
        'tools': ['get_recent_errors', 'get_relationships', 'get_symbol', 'search_source', 'read_source', 'get_index_coverage'],
        'source': 'app/assistant/project_map.py',
        'contract': 'Trace captured errors and widget -> callback -> helper/output relationships. Configuration bindings are verified; inferred call candidates are not proof of runtime dispatch. Distinguish saved, unsaved, and runtime generations.'},
}


def route(request, snapshot):
    words = set(tokens(request))
    words |= {w[:-1] for w in words if w.endswith('s')}
    domains = {name for name, entry in CONTRACTS.items() if words & set(tokens(entry['aliases']))}
    if re.search(r'\.(?:csv|tsv|xlsx?|xlsm|json|xml|mat|bin|dat|txt)\b', request, re.I):
        domains.add('data')
    for row in snapshot.get('layout_tree', []):
        properties = row.get('properties', {})
        for name in (properties.get('name'), properties.get('instance')):
            if isinstance(name,str) and name and re.search(r'(?<!\w)'+re.escape(name)+r'(?!\w)',request,re.I):
                domains.add('layout')
                if row.get('type') in {'output','info'}:
                    domains.add('output')
    selected = set(snapshot.get('selected_nodes', []))
    if any(row.get('node_id') in selected or row.get('selector') == snapshot.get('selection')
           for row in snapshot.get('layout_tree', [])):
        domains.add('layout')
    return domains or {'diagnosis'}


def contracts(domains=None):
    return [{'id': name, 'version': CONTRACT_VERSION, **{k: v for k, v in entry.items() if k != 'aliases'}}
            for name, entry in CONTRACTS.items() if not domains or name in domains]


def widget_schema(widget_type):
    from app.config_designer.schema import FEATURES
    from app.config_designer.document import ALLOWED_CHILDREN
    from .policy import AssistantError
    if widget_type not in FEATURES:
        raise AssistantError('INVALID_ARGUMENTS', 'Unknown widget type. Allowed: ' + ', '.join(FEATURES))
    metadata = {name: {k:deepcopy(value) for k,value in spec.items() if k in {'type','default','options','help'}}
                for name,spec in FEATURES[widget_type].items()}
    return {'widget_type': widget_type, 'properties': metadata,
            'allowed_children': sorted(ALLOWED_CHILDREN.get(widget_type, [])),
            'placement': ({'structural': 'A tab is a page of a tab_widget. Add with parent and optional index/ref; never pass placement, bounds, or pos for the tab itself. Its layout.mode controls its children.'} if widget_type == 'tab' else
                          {'bounds': '[x,y,width,height], canvas parent only', 'pos': '[row,column,rowspan,colspan], grid parent'})}
