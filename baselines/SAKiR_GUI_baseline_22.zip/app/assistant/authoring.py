"""Trusted authoring adapters compile intentions to reviewed edits, never live state."""
import ast
import copy
import io
import re
import tokenize
from .policy import AssistantError
from .task_context import layout_rows


def layout_candidate(snapshot, operations, config=None, document=None, references=None):
    from app.config_designer.document import DesignerDocument
    from app.config_designer.schema import FEATURES
    document = copy.deepcopy(document) if document is not None else DesignerDocument.from_config(config or snapshot['config'])
    refs = {}
    def capture(node, selector='root'):
        refs[selector] = node
        for i, child in enumerate(node.children):
            capture(child, f'{selector}/{i}')
    capture(document.root)
    if references is not None:
        refs = {alias: document.find(node_id) for alias, node_id in references.items() if document.find(node_id)}
    else:
        for row in layout_rows(snapshot):
            if row['selector'] in refs and row.get('node_id'):
                node = refs[row['selector']]
                node.node_id = row['node_id']
                refs[row['node_id']] = node
    def target(identifier):
        if identifier in refs:
            node = refs[identifier]
            if document.find(node.node_id) is not None:
                return node
        matches = [n for n in document.root.walk() if identifier in (n.node_id, n.properties.get('name'), n.properties.get('instance'))]
        if len(matches)>1:
            selected = [n for n in matches if n.node_id in snapshot.get('selected_nodes',[]) or refs.get(snapshot.get('selection')) is n]
            if len(selected)==1:
                matches = selected
        if len(matches) != 1:
            raise AssistantError('AMBIGUOUS_TARGET' if matches else 'TARGET_NOT_FOUND', 'Use a stable node ID, original selector, or batch ref for ' + str(identifier))
        return matches[0]
    checked_nodes = []
    removed = []
    for operation in operations:
        operation = copy.deepcopy(operation)
        if operation.get('action') == 'add' and operation.get('node') and not operation.get('ref'):
            operation['ref'] = operation['node']  # Legacy/model add aliases remain batch-local.
        action = operation['action']
        required = {'add':['parent','widget_type'], 'update':['node'], 'move':['node','parent'], 'remove':['node']}.get(action, [])
        if any(key not in operation for key in required):
            raise AssistantError('INVALID_ARGUMENTS', f'{action} requires fields: {required}. For add, parent is the existing container selector and widget_type is the new kind. node is not the parent. Example: '+str({'action':'add','parent':'<selector from get_task_context>','widget_type':'button','properties':{'name':'<label>','callback':'<function name>'}}))
        parent = target(operation.get('parent', 'root')) if action in {'add', 'move'} else None
        node = None if action == 'add' else target(operation['node'])
        kind = operation.get('widget_type') if node is None else node.node_type
        if kind == 'tab' and (operation.get('placement') or set(operation.get('properties',{})) & {'bounds','pos','anchors','dock'}):
            raise AssistantError('STRUCTURAL_PLACEMENT', 'A tab is a structural page of tab_widget, not a positioned widget. Remove placement/bounds/pos from this tab operation, or use propose_tab. Give it a ref and set layout.mode=canvas for exact placement of its children; use the ref as their parent.')
        if kind not in FEATURES:
            raise AssistantError('INVALID_ARGUMENTS', 'Unknown widget type. Use get_layout_schema.')
        properties = copy.deepcopy(operation.get('properties', {}))
        actual_parent = parent or (node.parent if node is not None else None)
        if 'bounds' in properties and actual_parent is not None and actual_parent.get_property('layout.mode', 'canvas' if actual_parent.node_type == 'root' else 'grid') != 'canvas':
            raise AssistantError('LAYOUT_MODE', 'Bounds cannot determine exact placement inside a grid. Use pos for grid placement, or an explicit Designer canvas migration.')
        unknown = set(properties) - set(FEATURES.get(kind, {}))
        if unknown:
            raise AssistantError('INVALID_PROPERTY', f'Unknown {kind} properties: {sorted(unknown)}. Use get_layout_schema; bounds=[x,y,width,height].')
        for key, value in properties.items():
            spec = FEATURES[kind][key]
            if value is None and not spec.get('required'):
                continue
            expected = spec['type']
            valid = True
            if expected == 'combo':
                valid = value in spec.get('options', [])
            elif expected == 'bool':
                valid = type(value) is bool
            elif expected == 'int':
                valid = type(value) is int
            elif expected in {'rect','pos','size','grid'}:
                valid = isinstance(value,list) and len(value) == (4 if expected in {'rect','pos'} else 2) and all(type(n) is int for n in value)
            elif expected == 'anchors':
                valid = isinstance(value,list) and bool(value) and all(isinstance(v,str) and v in {'left','right','top','bottom'} for v in value)
            elif expected in {'text','color','callback','shortcut','file','password'}:
                valid = isinstance(value,str)
            if key == 'type':
                valid = value == kind
            if key == 'layout.mode':
                valid = isinstance(value,str) and value in {'grid','canvas'}
                if node is not None and node.children and node.get_property('layout.mode','grid') != value:
                    raise AssistantError('LAYOUT_MIGRATION_REQUIRED', 'Changing a populated container mode requires an explicit Designer migration, preserving its children.')
            if not valid:
                raise AssistantError('INVALID_PROPERTY', f'{kind}.{key} requires {expected}' + (f" in {spec['options']}" if spec.get('options') else '') + '.')
        if action == 'add':
            node = document.create_node(kind, parent.node_id, None, operation.get('index'))
            # DesignerDocument.create_node returns the node.
            if isinstance(node, str):
                node = document.find(node)
            for key, value in properties.items():
                document.set_property(node.node_id, key, value)
        elif action == 'update':
            for key, value in properties.items():
                document.set_property(node.node_id, key, value)
        elif action == 'move':
            document.reparent(node.node_id, parent.node_id, operation.get('index'))
            for key, value in properties.items():
                document.set_property(node.node_id, key, value)
        elif action == 'remove':
            removed.append(node)
            document.remove_node(node.node_id)
        else:
            raise AssistantError('INVALID_ARGUMENTS', 'Unsupported layout operation.')
        if action != 'remove':
            placement = operation.get('placement')
            if placement:
                apply_placement(node, placement, target)
            checked_nodes.append(node)
            if operation.get('ref'):
                if operation['ref'] in refs and refs[operation['ref']] is not node:
                    raise AssistantError('INVALID_ARGUMENTS', 'Duplicate batch ref.')
                refs[operation['ref']] = node
    checks = []
    def selector(node):
        path = []
        while node.parent:
            path.insert(0, str(node.parent.children.index(node)))
            node = node.parent
        return '/'.join(['root', *path])
    # Regenerate expectations after the whole batch, including preserved nodes.
    for node in document.root.walk():
        if document.find(node.node_id):
            checks.append({'kind': 'layout', 'target': selector(node), 'properties': copy.deepcopy(node.properties),
                           'parent': selector(node.parent) if node.parent else None})
    return document.to_config(), checks, document, {alias:node.node_id for alias,node in refs.items() if document.find(node.node_id)}


def apply_placement(node, placement, target):
    parent = node.parent
    if not parent or parent.get_property('layout.mode', 'canvas' if parent.node_type == 'root' else 'grid') != 'canvas':
        raise AssistantError('LAYOUT_MODE', 'Exact placement requires a canvas parent. Inspect its mode; do not silently convert a populated grid.')
    size = parent.get_property('layout.designSize')
    if not size:
        size = parent.properties.get('bounds', [0, 0, 1200, 800])[2:4]
    width, height = placement['size']
    if width <= 0 or height <= 0:
        raise AssistantError('INVALID_ARGUMENTS', 'Placement size must be positive.')
    mode = placement['mode']
    margin = placement.get('margin', 0)
    x, y = placement.get('x', 0), placement.get('y', 0)
    anchors = ['left', 'top']
    if mode == 'exact':
        if 'x' not in placement or 'y' not in placement:
            raise AssistantError('INVALID_ARGUMENTS', 'Exact placement requires x and y.')
    elif mode in {'top_left', 'top_right', 'bottom_left', 'bottom_right', 'center'}:
        if mode != 'center' and 'margin' not in placement:
            raise AssistantError('INVALID_ARGUMENTS', 'Corner placement requires an explicit margin.')
        x = (size[0] - width) // 2 if mode == 'center' else size[0] - margin - width if 'right' in mode else margin
        y = (size[1] - height) // 2 if mode == 'center' else size[1] - margin - height if 'bottom' in mode else margin
        anchors = ['right' if 'right' in mode else 'left', 'bottom' if 'bottom' in mode else 'top']
    elif mode in {'below', 'right_of'}:
        if 'relative_to' not in placement:
            raise AssistantError('INVALID_ARGUMENTS', 'Relative placement requires relative_to naming a sibling.')
        other = target(placement['relative_to'])
        if other.parent is not parent:
            raise AssistantError('INVALID_ARGUMENTS', 'Relative placement targets must share a parent.')
        ox, oy, ow, oh = other.properties['bounds']
        x, y = (ox, oy+oh+margin) if mode == 'below' else (ox+ow+margin, oy)
    else:
        raise AssistantError('INVALID_ARGUMENTS', 'Unknown placement mode.')
    if x < 0 or y < 0 or x + width > size[0] or y + height > size[1]:
        raise AssistantError('OUTSIDE_PARENT', f'Requested bounds {[x,y,width,height]} exceed parent design size {size}. For edge placement use mode=bottom_right, size=[width,height], margin=distance; the host computes x/y.')
    node.set_property('bounds', [x, y, width, height])
    node.set_property('anchors', placement.get('anchors', anchors))
    node.set_property('dock', 'none')


def normalize_function_code(code):
    """Repair double-escaped separators only outside literals in invalid Python."""
    try:
        ast.parse(code)
        return code
    except SyntaxError:
        pass
    lines = code.splitlines(keepends=True)
    offsets = [0]
    for line in lines:
        offsets.append(offsets[-1]+len(line))
    protected = set()
    fstring_start = None
    depth = 0
    try:
        # Tokenize an equal-width view so invalid separators do not stop the
        # tokenizer before it identifies string literal boundaries.
        lexical = re.sub(r'\\r\\n|\\n|\\t',lambda m: ' '*len(m[0]),code)
        for token in tokenize.generate_tokens(io.StringIO(lexical).readline):
            start = offsets[token.start[0]-1]+token.start[1]
            end = offsets[token.end[0]-1]+token.end[1]
            if token.type in (tokenize.STRING,tokenize.COMMENT):
                protected.update(range(start,end))
            if token.type == getattr(tokenize,'FSTRING_START',-1):
                if depth == 0:
                    fstring_start = start
                depth += 1
            if token.type == getattr(tokenize,'FSTRING_END',-1):
                depth -= 1
                if depth == 0:
                    protected.update(range(fstring_start,end))
    except (tokenize.TokenError,IndentationError):
        return code
    result = re.sub(r'\\r\\n|\\n|\\t',lambda m: m[0] if any(i in protected for i in range(m.start(),m.end())) else {'\\r\\n':'\n','\\n':'\n','\\t':'\t'}[m[0]],code)
    try:
        ast.parse(result)
        return result
    except SyntaxError:
        return code


def validate_button_callback(code, name, output_instance=None):
    """Check known binding prerequisites without running generated code."""
    tree=ast.parse(normalize_function_code(code))
    functions=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    if len(functions)!=1:
        raise AssistantError('INVALID_CALLBACK','Provide one top-level function with the requested name.')
    fn=functions[0]
    if len(fn.args.posonlyargs)+len(fn.args.args)>len(fn.args.defaults) or any(d is None for d in fn.args.kw_defaults):
        raise AssistantError('CALLBACK_SIGNATURE','Buttons call callbacks without arguments. Use def '+name+"(): and global display('output_instance', data, mode='replace'); do not use self.")
    if output_instance is not None:
        bound=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='display' and n.args
                  and isinstance(n.args[0],ast.Constant) and n.args[0].value==output_instance for n in ast.walk(fn))
        if not bound:
            raise AssistantError('OUTPUT_BINDING',f"This page adapter requires a direct global display({output_instance!r}, data, mode='replace') call. Use the literal instance string, not self.display or an undefined variable. For indirect/custom behavior compose layout and callback tools explicitly.")


def callback_candidate(source, name, code, imports=()):
    tree = ast.parse(source)
    code = normalize_function_code(code)
    generated = ast.parse(code)
    definitions = [n for n in generated.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    if len(generated.body) != 1 or len(definitions) != 1 or definitions[0].name != name or not name.isidentifier():
        raise AssistantError('INVALID_CALLBACK', 'Provide exactly one top-level function with the requested name.')
    matches = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
    if len(matches) > 1 or any(isinstance(n, ast.ClassDef) and n.name == name for n in tree.body):
        raise AssistantError('AMBIGUOUS_TARGET', 'The callback name has duplicate definitions.')
    lines = source.splitlines(keepends=True)
    if matches:
        old = matches[0]
        if old.decorator_list and not definitions[0].decorator_list:
            first = min(d.lineno for d in old.decorator_list) - 1
            code = ''.join(lines[first:old.lineno-1]) + code
            definitions = [n for n in ast.parse(code).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
        if ast.dump(old) == ast.dump(definitions[0]):
            candidate = source
        else:
            first = min([old.lineno] + [d.lineno for d in old.decorator_list]) - 1
            lines[first:old.end_lineno] = [code.rstrip() + '\n']
            candidate = ''.join(lines)
    else:
        candidate = source.rstrip() + '\n\n\n' + code.rstrip() + '\n'
    for statement in imports:
        statement = statement.strip()
        if not statement:
            continue
        if re.fullmatch(r'[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*', statement):
            statement = 'import ' + statement
        parsed = ast.parse(statement)
        if len(parsed.body) != 1 or not isinstance(parsed.body[0], (ast.Import, ast.ImportFrom)):
            raise AssistantError('INVALID_ARGUMENTS', 'Imports must contain a single import statement.')
        if isinstance(parsed.body[0], ast.ImportFrom) and parsed.body[0].module == '__future__':
            raise AssistantError('INVALID_ARGUMENTS', 'Future imports require an inspected targeted source edit.')
        needed = {n.id for n in ast.walk(definitions[0]) if isinstance(n,ast.Name)}
        item = parsed.body[0]
        bindings = {a.asname or (a.name.split('.')[0] if isinstance(item,ast.Import) else a.name) for a in item.names}
        # This field declares dependencies of the new function, not module setup.
        if '*' not in bindings and not bindings & needed:
            continue
        def targets(import_node):
            if isinstance(import_node,ast.Import):
                return {a.asname or a.name.split('.')[0]:a.name if a.asname else a.name.split('.')[0] for a in import_node.names}
            if isinstance(import_node,ast.ImportFrom):
                return {a.asname or a.name:'.'*import_node.level+str(import_node.module or '')+'.'+a.name for a in import_node.names if a.name != '*'}
            return {}
        existing_targets={k:v for n in ast.parse(candidate).body for k,v in targets(n).items()}
        new_targets=targets(item)
        if any(k in existing_targets and existing_targets[k] != v for k,v in new_targets.items()):
            raise AssistantError('IMPORT_CONFLICT','A dependency would change an existing import binding. Use an explicit different alias.')
        if not any(ast.dump(n) == ast.dump(parsed.body[0]) for n in ast.parse(candidate).body):
            module = ast.parse(candidate)
            insertion = 0
            for i, node in enumerate(module.body):
                is_doc = i == 0 and isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)
                if is_doc or isinstance(node, ast.ImportFrom) and node.module == '__future__':
                    insertion = node.end_lineno
                else:
                    break
            lines = candidate.splitlines(keepends=True)
            lines.insert(insertion, statement.strip() + '\n')
            candidate = ''.join(lines)
    compile(candidate, 'callbacks/callbacks.py', 'exec')
    return candidate


def concrete_reader_inputs(source):
    """Recognize literal inputs to common readers; dynamic paths remain unresolved."""
    readers = {'read_csv','read_excel','read_json','read_xml','read_table','load_workbook','loadmat'}
    suffixes = ('.csv','.tsv','.xlsx','.xls','.json','.xml','.mat')
    result = {}
    def path_literal(node):
        if isinstance(node,ast.Constant) and isinstance(node.value,str):
            return node.value
        if isinstance(node,ast.Name) and node.id == 'PROJECT_ROOT':
            return ''
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id == 'Path' and len(node.args) == 1:
            return path_literal(node.args[0])
        if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Div):
            left,right=path_literal(node.left),path_literal(node.right)
            if left is not None and right is not None:
                return left.rstrip('/')+'/'+right if left else right
        return None
    try:
        tree = ast.parse(source)
    except (SyntaxError,TypeError):
        return result
    for node in ast.walk(tree):
        if not isinstance(node,ast.Call) or not node.args:
            continue
        name = node.func.attr if isinstance(node.func,ast.Attribute) else node.func.id if isinstance(node.func,ast.Name) else ''
        if name not in readers:
            continue
        path = path_literal(node.args[0])
        if path and path.lower().endswith(suffixes):
            result[ast.dump(node)] = path
    return result
