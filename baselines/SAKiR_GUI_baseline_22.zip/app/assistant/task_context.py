"""Revision-bound projections; no imports or execution of project source."""
from dataclasses import dataclass, field
import re
from .policy import AssistantError, redact
from .retrieval import tokens


@dataclass
class TaskState:
    request: str
    domains: set
    revision: str
    can_edit: bool
    repairs: int = 0
    validated: bool = False
    calls: int = 0
    model_requests: int = 0
    metrics: dict = field(default_factory=dict)

    @classmethod
    def create(cls, request, snapshot, can_edit):
        return cls(request, set(), snapshot['revision'], can_edit)


def layout_rows(snapshot):
    rows = snapshot.get('layout_tree')
    if rows:
        return rows
    from app.config_designer.document import DesignerDocument
    def walk(node, selector='root'):
        return [{'selector': selector, 'node_id': node.node_id, 'type': node.node_type, 'properties': node.properties}] + [
            row for i, child in enumerate(node.children) for row in walk(child, f'{selector}/{i}')]
    return walk(DesignerDocument.from_config(snapshot['config']).root)


def resolve_row(rows, identifier, snapshot):
    if not identifier:
        selected = set(snapshot.get('selected_nodes', []))
        matches = [r for r in rows if r.get('node_id') in selected or r['selector'] == snapshot.get('selection')]
    else:
        matches = [r for r in rows if identifier in (r['selector'], r.get('node_id'), r.get('properties', {}).get('name'), r.get('properties', {}).get('instance'))]
    if len(matches) != 1:
        selected = [r for r in matches if r.get('node_id') in snapshot.get('selected_nodes',[]) or r['selector']==snapshot.get('selection')]
        if len(selected)==1:
            return selected[0]
        raise AssistantError('AMBIGUOUS_TARGET' if matches else 'TARGET_NOT_FOUND',
                             'Choose an exact selector or node_id. Matches: ' + ', '.join(r['selector'] for r in matches[:12]))
    return matches[0]



def session_target(snapshot, request):
    """Resolve an explicitly named session; never substitute another session."""
    words = set(tokens(request))
    tools = words & {'serial','telnet','communication'}
    runtime = snapshot.get('runtime',{})
    names = [s.get('name') for tool in (tools or {'serial','telnet','communication'})
             for s in runtime.get(tool,{}).get('sessions',[]) if isinstance(s.get('name'),str)]
    pattern = r'\b(?:on|to)\s+(?:the\s+)?(?:(?:existing|unknown)\s+)?session\s+(?:`([^`]+)`|"([^"]+)"|\x27([^\x27]+)\x27|([^\s,;]+))'
    found=[]
    for match in re.finditer(pattern,request,re.I):
        quoted = next((v for v in match.groups()[:3] if v),None)
        value = quoted or match.group(4).rstrip('.')
        if not quoted:
            remainder = request[match.start(4):]
            known = [n for n in names if remainder.casefold().startswith(n.casefold()) and (len(remainder)==len(n) or not remainder[len(n)].isalnum())]
            if known:
                value=max(known,key=len)
        found.append(value)
    values = list(dict.fromkeys(found))
    if len(values)!=1:
        return None, tools, names
    requested=values[0]
    exact=[n for n in names if n==requested]
    folded=[n for n in names if n.casefold()==requested.casefold()]
    return (exact[0] if exact else folded[0] if len(set(folded))==1 else requested), tools, names


def project_context(snapshot, domain, target='', offset=0, limit=12):
    data = {'revision': snapshot['revision'], 'runtime_generation': snapshot.get('runtime_generation'), 'domain': domain}
    if domain in {'layout', 'output'}:
        rows = layout_rows(snapshot)
        if target:
            row = resolve_row(rows, target, snapshot)
            prefix = row['selector']
            ancestors = [r for r in rows if prefix.startswith(r['selector'] + '/')]
            data['ancestors'] = [{k:r[k] for k in ('selector','node_id','type') if k in r} | {
                'properties':{k:v for k,v in r.get('properties',{}).items() if k in {'layout','bounds','name','instance'}}} for r in ancestors]
            rows = [row] + [r for r in rows if r['selector'].startswith(prefix + '/')]
        elif domain == 'output':
            rows = [r for r in rows if r['type'] in {'output', 'info'}]
        # Child contents are separate rows; never recursively duplicate the tree.
        projected = []
        for row in rows:
            props = row.get('properties', {})
            projected.append({**{k: row[k] for k in ('selector', 'node_id', 'type') if k in row},
                              'properties': {k: v for k, v in props.items() if k not in {'widgets', 'tabs'}}})
        data.update(nodes=projected[offset:offset+limit], total=len(projected),
                    next_offset=offset+limit if offset+limit < len(projected) else None)
    elif domain == 'data':
        data.update(attachments=snapshot.get('attachments', []), instruction='Inspect files before generating a loader.')
    elif domain == 'sessions':
        data['runtime'] = snapshot.get('runtime', {})
    elif domain == 'messages':
        data.update(message_library_path=snapshot.get('message_library_path'), message_manifest=snapshot.get('message_manifest'))
    elif domain == 'diagnosis':
        data['recent_errors'] = snapshot.get('recent_errors', [])[-3:]
    else:
        data.update(selection=snapshot.get('selection'), hashes=snapshot.get('hashes', {}),
                    instruction='Use get_relationships and read_source/get_symbol for affected definitions; unsaved overlays take precedence.')
    return redact(data)
