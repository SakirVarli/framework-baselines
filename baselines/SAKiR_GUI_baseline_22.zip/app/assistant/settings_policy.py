"""Pure settings resolution shared by the preview, storage and task runner."""
import copy

from .policy import AssistantError


TASK_PRESETS = {
    "quick": {"max_rounds": 8, "max_tool_calls": 20, "task_timeout": 300, "timeout": 120, "file_timeout": 30},
    "standard": {"max_rounds": 20, "max_tool_calls": 60, "task_timeout": 600, "timeout": 180, "file_timeout": 60},
    "extended": {"max_rounds": 32, "max_tool_calls": 100, "task_timeout": 1200, "timeout": 300, "file_timeout": 90},
}
FILE_PRESETS = {"small": (10, 6000), "standard": (50, 20000), "detailed": (100, 40000)}
AUTOMATIC_FIELDS = (
    "max_tokens", "context_chars", "context_margin", "compact_threshold", "tokenizer", "auto_compact",
    "max_rounds", "max_tool_calls", "task_timeout", "timeout", "file_timeout", "preview_rows", "result_chars",
)


def capacity_for(settings):
    if settings.context_tokens:
        return settings.context_tokens
    profile = settings.capability_profile or {}
    if not isinstance(profile, dict):
        return None
    value = profile.get("context_tokens")
    if ((profile.get("base_url"), profile.get("model")) == (settings.base_url, settings.model)
            and type(value) is int and 1024 <= value <= 10000000):
        return value
    return None


def character_budget(settings):
    return settings.context_chars - min(settings.context_chars // 4, max(2000, settings.max_tokens * 4))


def capacity_source(settings):
    if settings.context_tokens:
        return "Manually entered server capacity"
    if capacity_for(settings):
        return "Advertised by the selected server/model"
    return "Unknown — conservative character fallback; enter your server's configured capacity"


def manual_settings(settings):
    """Recover manual controls without changing the saved/effective configuration."""
    result = copy.deepcopy(settings)
    if not isinstance(result.advanced_limits, dict):
        raise AssistantError("SETTINGS_INVALID", "Saved Advanced limits must be an object.")
    if settings.settings_mode == "simplified":
        for key, value in settings.advanced_limits.items():
            if key in AUTOMATIC_FIELDS:
                setattr(result, key, value)
    return result


def resolve_settings(settings):
    result = copy.deepcopy(settings)
    if not isinstance(result.advanced_limits, dict):
        raise AssistantError("SETTINGS_INVALID", "Saved Advanced limits must be an object.")
    if result.settings_mode == "simplified":
        if (not isinstance(result.task_preset, str) or not isinstance(result.file_detail, str)
                or result.task_preset not in TASK_PRESETS or result.file_detail not in FILE_PRESETS):
            raise AssistantError("SETTINGS_INVALID", "Choose a valid task size and file detail preset.")
        if not isinstance(result.output_preset, str) or result.output_preset not in {"standard", "reasoning"}:
            raise AssistantError("SETTINGS_INVALID", "Choose Standard or Large completion allowance output allowance.")
        if not result.advanced_limits:
            result.advanced_limits = {key: getattr(result, key) for key in AUTOMATIC_FIELDS}
        capacity = capacity_for(result)
        if capacity is not None and (type(capacity) is not int or capacity < 1024):
            raise AssistantError("SETTINGS_INVALID", "Enter a server context capacity of at least 1,024 tokens, or use Automatic.")
        ceiling = 8192 if result.output_preset == "standard" else 65536
        if capacity:
            result.context_margin = min(8192, max(512, capacity // 100), capacity // 8)
            fraction = 8 if result.output_preset == "standard" else 4
            result.max_tokens = min(ceiling, max(256, capacity // fraction))
            budget = capacity - result.max_tokens - result.context_margin
            # At most a quarter of the character setting is reserved. 4 * the
            # token input budget therefore leaves >= 3 * that budget in chars,
            # consistent with the runtime's conservative UTF-8 / 3 estimate.
            result.context_chars = min(2000000, max(8000, budget * 4))
        else:
            result.context_margin = 512
            result.max_tokens = 8192 if result.output_preset == "standard" else 32768
            result.context_chars = 96000
        for key, value in TASK_PRESETS[result.task_preset].items():
            setattr(result, key, value)
        result.preview_rows, target_chars = FILE_PRESETS[result.file_detail]
        result.result_chars = min(target_chars, max(1000, character_budget(result) // 8))
        result.compact_threshold = 80
        result.auto_compact = True
        result.tokenizer = "estimate"
    result.validate(connection=False)
    capacity = capacity_for(result)
    if capacity and capacity <= result.max_tokens + result.context_margin:
        raise AssistantError("SETTINGS_INVALID", "Model capacity leaves no input room. Reduce maximum output tokens or correct the server capacity.")
    return result


def budget_summary(settings):
    """Safe, numeric-only preview data; never includes credentials or request text."""
    effective = resolve_settings(settings)
    capacity = capacity_for(effective)
    tokens = capacity - effective.max_tokens - effective.context_margin if capacity else None
    characters = character_budget(effective)
    return effective, {
        "Capacity source": capacity_source(effective),
        "Model capacity (tokens)": capacity,
        "Available input (tokens)": tokens,
        "Usable character guard": characters,
        "Compact at input tokens": int(tokens * effective.compact_threshold / 100) if tokens else None,
        "Compact at characters": int(characters * effective.compact_threshold / 100),
    }
