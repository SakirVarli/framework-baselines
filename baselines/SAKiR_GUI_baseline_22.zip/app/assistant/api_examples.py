"""Static checks for project API examples. Never import or execute project code.

This is a bounded checker for resolvable project imports, facade receivers,
signatures and TypedDict settings. It is not a general Python type checker.
"""
import ast
import inspect
import re
import textwrap
import warnings
import io
import tokenize
from dataclasses import dataclass, replace

from .policy import AssistantError


@dataclass
class Value:
    module: str = ''
    name: str = ''
    instance: bool = False
    literal: object = None
    protocol: str = ''


class SourceDefault:
    def __init__(self, node):
        self.text = ast.unparse(node)[:120]

    def __repr__(self):
        return self.text


def literal_default(node):
    try:
        return ast.literal_eval(node)
    except (ValueError, TypeError):
        return SourceDefault(node)


class ApiExamples:
    def __init__(self, index, internal_tools=(), expected_family=None):
        self.index = index
        self.internal_tools = set(internal_tools)
        self.expected_family = expected_family
        self.trees = {}
        self.bindings = {}
        self.verified = {}
        self.issues = []
        self.references = []
        self.reference_keys = set()
        runtime = self.tree('app.tool_api')
        self.project_methods = {n.name for cls in runtime.body if isinstance(cls, ast.ClassDef)
                                for n in cls.body if isinstance(n, ast.FunctionDef) and not n.name.startswith('_')} if runtime else set()
        for name in ('Tools', 'display', 'GlobalsBase'):
            value = self.public('app.stubs', name)
            if value.module:
                self.bindings[name] = value

    def tree(self, module):
        if module not in self.trees:
            record = self.index.cache.get(module.replace('.', '/') + '.py')
            if record is None:
                record = self.index.cache.get(module.replace('.', '/') + '/__init__.py')
            try:
                self.trees[module] = ast.parse(record['text']) if record else None
            except SyntaxError:
                self.trees[module] = None
        return self.trees[module]

    def public(self, module, name, seen=None):
        seen = set() if seen is None else seen
        if (module, name) in seen:
            return Value()
        seen.add((module, name))
        tree = self.tree(module)
        if tree is None:
            return Value()
        # stubs exposes these runtime objects through the audited resolver.
        if module == 'app.stubs':
            resolver = self.tree('app.utils')
            if resolver:
                for function in resolver.body:
                    if isinstance(function, ast.FunctionDef) and function.name == 'resolve_callback_tool_symbols':
                        for node in ast.walk(function):
                            if isinstance(node, ast.ImportFrom):
                                for alias in node.names:
                                    if (alias.asname or alias.name) == name and node.module:
                                        return self.public(node.module, alias.name, seen)
        for node in tree.body:
            if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
                return Value(module, name)
            if isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    if (alias.asname or alias.name) == name and alias.name != '*':
                        target = self.import_module(module, node)
                        return self.public(target, alias.name, seen)
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name):
                    result = self.public(module, node.value.func.id, seen)
                    result.instance = True
                    return result
                return Value(module, name, instance=True)
            if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == name:
                return Value(module, name, instance=True)
        return Value()

    def import_module(self, module, node):
        if not node.level:
            return node.module or ''
        package = module.split('.') if self.index.cache.get(module.replace('.', '/') + '/__init__.py') else module.split('.')[:-1]
        return '.'.join(package[:len(package)-node.level+1] + ([node.module] if node.module else []))

    def definition(self, value):
        tree = self.tree(value.module)
        if tree:
            return next((n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == value.name), None)

    def method(self, value, name, seen=None):
        seen = set() if seen is None else seen
        key = (value.module, value.name, name)
        if key in seen:
            return None, value
        seen.add(key)
        definition = self.definition(value)
        if not isinstance(definition, ast.ClassDef):
            return None, value
        for node in definition.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
                return node, value
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Name) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
                return self.method(value, node.value.id, seen)
        for base in definition.bases:
            if isinstance(base, ast.Name):
                parent = self.public(value.module, base.id)
                found, owner = self.method(parent, name, seen)
                if found:
                    return found, owner
        return None, value

    def signature(self, function, bound=False):
        args = function.args
        positional = [*args.posonlyargs, *args.args]
        required = len(positional) - len(args.defaults)
        parameters = []
        for i, argument in enumerate(positional):
            if bound and i == 0:
                continue
            kind = inspect.Parameter.POSITIONAL_ONLY if i < len(args.posonlyargs) else inspect.Parameter.POSITIONAL_OR_KEYWORD
            parameters.append(inspect.Parameter(argument.arg, kind, default=inspect.Parameter.empty if i < required else literal_default(args.defaults[i-required])))
        if args.vararg:
            parameters.append(inspect.Parameter(args.vararg.arg, inspect.Parameter.VAR_POSITIONAL))
        for argument, default in zip(args.kwonlyargs, args.kw_defaults):
            parameters.append(inspect.Parameter(argument.arg, inspect.Parameter.KEYWORD_ONLY,
                                                default=inspect.Parameter.empty if default is None else literal_default(default)))
        if args.kwarg:
            parameters.append(inspect.Parameter(args.kwarg.arg, inspect.Parameter.VAR_KEYWORD))
        return inspect.Signature(parameters)

    def proof(self, owner, function=None):
        path = owner.module.replace('.', '/') + '.py'
        if path not in self.index.cache:
            path = owner.module.replace('.', '/') + '/__init__.py'
        record = self.index.cache.get(path, {})
        line = getattr(function or self.definition(owner), 'lineno', 1)
        identifier = owner.module + '.' + owner.name + ('.'+function.name if function else '')
        self.verified[identifier] = {'symbol': identifier, 'path': path, 'line': line,
                                     'content_revision': record.get('content_revision'), 'basis': 'static_api_contract'}
        if function is None and isinstance(self.definition(owner),ast.ClassDef):
            self.verified[identifier]['declared_members'] = self.members(owner)

    def members(self, owner, seen=None):
        seen = set() if seen is None else seen
        key = (owner.module,owner.name)
        if key in seen:
            return []
        seen.add(key)
        cls = self.definition(owner)
        if not isinstance(cls,ast.ClassDef):
            return []
        result = {n.name for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
        for node in cls.body:
            targets = node.targets if isinstance(node,ast.Assign) else [node.target] if isinstance(node,ast.AnnAssign) else []
            result.update(target.id for target in targets if isinstance(target,ast.Name))
        for node in ast.walk(cls):
            if isinstance(node,ast.Assign):
                for target in node.targets:
                    if isinstance(target,ast.Attribute) and isinstance(target.value,ast.Name) and target.value.id=='self':
                        result.add(target.attr)
        for base in cls.bases:
            if isinstance(base,ast.Name):
                result.update(self.members(self.public(owner.module,base.id),seen))
        return sorted(n for n in result if not n.startswith('_'))

    def mention(self, expression):
        if expression in self.reference_keys:
            return
        if len(self.references)>=20:
            self.problem('Too many project API references to review in one answer; simplify the example.')
            return
        self.reference_keys.add(expression)
        try:
            node = ast.parse(expression,mode='eval').body
        except SyntaxError:
            try:
                statements = ast.parse(expression).body
            except SyntaxError:
                return
            if len(statements)==1 and isinstance(statements[0],ast.ImportFrom):
                statement=statements[0]
                if statement.module and statement.module.startswith(('app.','externals.','callbacks.')):
                    self.references.append({'reference':expression,'basis':'project_import',
                        'module_exists':self.tree(statement.module) is not None,
                        'exports_exist':all(self.public(statement.module,a.name).module for a in statement.names)})
            return
        if isinstance(node,ast.Call):
            node=node.func
        if isinstance(node,ast.Name) and node.id in self.internal_tools:
            self.references.append({'reference':expression,'basis':'assistant_rpc_not_runtime_function'})
        elif isinstance(node,ast.Name):
            target=self.bindings.get(node.id) or self.public('app.stubs',node.id)
            if target.module and target.module!='!external':
                self.proof(target)
                self.references.append({'reference':expression,'basis':'project_symbol','symbol':target.name})
        elif isinstance(node,ast.Attribute):
            old_issues = self.issues.copy()
            receiver = self.value(node.value)
            self.issues = old_issues
            if receiver.module.startswith(('app.','callbacks.','externals.')) and receiver.name:
                self.proof(receiver)
                self.references.append({'reference':expression,'owner':receiver.name,
                                        'member':node.attr,'exists':node.attr in self.members(receiver)})

    def problem(self, message):
        if message not in self.issues:
            self.issues.append(message)

    def guidance(self):
        """Build repair hints from the same source contracts we validate."""
        tools = self.public('app.stubs', 'Tools')
        if not tools.module:
            return ''
        original = self.bindings.get('Tools')
        self.bindings['Tools'] = tools
        lines = ['Read the relevant API with get_symbol/read_source before another guess. Verified public entry: from app.stubs import Tools (capital T). Do not import Tools from app or use an unbound tools variable.',
                 'A missing generated package must not be replaced with another guessed import. For a Message Designer tutorial, give the documented UI steps without a runnable import of a future package. No device schema is required to explain those steps. Conditional future examples must identify prerequisites and use verified generator contracts; otherwise omit that code, not the tutorial.']
        if self.expected_family:
            lines.append('The user explicitly named '+('Communication Hub: use Tools.communication, not Tools.serial.' if self.expected_family=='communication' else 'the standalone Serial tool: use Tools.serial, not Tools.communication.'))
        try:
            for attribute in ('communication', 'serial'):
                receiver = self.value(ast.parse('Tools.'+attribute, mode='eval').body)
                function, _ = self.method(receiver, 'session')
                if function:
                    session = self.return_type(receiver, 'session', function)
                    parts = []
                    for method in ('start', 'connect', 'send'):
                        operation, _ = self.method(session, method)
                        if operation:
                            parts.append(method+str(self.signature(operation, True)))
                    for name in ('running','connected'):
                        getter, _ = self.method(session,name)
                        if getter and any(isinstance(d,ast.Name) and d.id=='property' for d in getter.decorator_list):
                            parts.append(name+' (state property)')
                    lines.append('Tools.'+attribute+'.session(configured_name) returns '+session.name+'; operations: '+', '.join(parts)+'.')
        finally:
            if original is None:
                self.bindings.pop('Tools', None)
            else:
                self.bindings['Tools'] = original
        return '\n'.join(lines)

    def return_type(self, receiver, method, function):
        annotation = function.returns
        if annotation is None:
            # The generated public facade supplies annotations the runtime omits.
            tree = self.tree('app.stubs')
            if tree:
                for cls in ast.walk(tree):
                    if isinstance(cls, ast.ClassDef) and cls.name == receiver.name:
                        annotation = next((n.returns for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == method), None)
                        if annotation:
                            break
        if isinstance(annotation, ast.Constant) and isinstance(annotation.value, str):
            try:
                annotation = ast.parse(annotation.value, mode='eval').body
            except SyntaxError:
                return Value()
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name) and annotation.value.id == 'Optional':
            annotation = annotation.slice
        if isinstance(annotation, ast.Name):
            result = self.public(receiver.module, annotation.id)
            if not result.module:
                result = self.public('app.stubs', annotation.id)
            result.instance = True
            return result
        return Value()

    def settings(self, receiver, method, arguments, keywords):
        tree = self.tree('app.stubs')
        if not tree:
            return
        for cls in ast.walk(tree):
            if not isinstance(cls, ast.ClassDef) or cls.name != receiver.name:
                continue
            for function in cls.body:
                if not isinstance(function, ast.FunctionDef) or function.name != method:
                    continue
                for parameter, value in zip(function.args.args[1:], arguments):
                    self.settings_parameter(parameter, value)
                for parameter in function.args.args[1:]:
                    if parameter.arg in keywords:
                        self.settings_parameter(parameter, keywords[parameter.arg])

    def settings_parameter(self, parameter, value):
        annotation = parameter.annotation
        if isinstance(annotation, ast.Subscript) and isinstance(annotation.value, ast.Name) and annotation.value.id == 'Optional':
            annotation = annotation.slice
        if not isinstance(annotation, ast.Name) or not isinstance(value.literal, dict):
            return
        settings = self.definition(self.public('app.stubs', annotation.id))
        if not isinstance(settings, ast.ClassDef) or not any(isinstance(b, ast.Name) and b.id == 'TypedDict' for b in settings.bases):
            return
        fields = {n.target.id for n in settings.body if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)}
        self.proof(self.public('app.stubs', annotation.id))
        unknown = set(value.literal)-fields
        if unknown:
            self.problem(annotation.id+' has unsupported keys '+', '.join(sorted(unknown))+'. Fields: '+', '.join(sorted(fields)))

    def hub_settings(self, config):
        tree = self.tree('app.tools.communication_hub.config')
        if not tree or not isinstance(config, dict):
            return
        function = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'default_session_config'), None)
        if not function:
            return
        defaults = next((n.value for n in ast.walk(function) if isinstance(n, ast.Return) and isinstance(n.value, ast.Dict)), None)
        if not defaults:
            return
        self.proof(Value('app.tools.communication_hub.config', 'default_session_config'))
        fields = {k.value: v for k,v in zip(defaults.keys, defaults.values) if isinstance(k, ast.Constant) and isinstance(k.value, str)}
        unknown = set(config)-set(fields)
        if unknown:
            self.problem('Communication Hub configuration has unsupported fields: '+', '.join(sorted(unknown)))
        transport = fields.get('transport')
        if isinstance(transport, ast.Dict) and isinstance(config.get('transport'), dict):
            known = {k.value for k in transport.keys if isinstance(k, ast.Constant)}
            unknown = set(config['transport'])-known
            if unknown:
                self.problem('Communication Hub transport has unsupported fields '+', '.join(sorted(unknown))+'. Use the installed transport fields (serial_port, baudrate for serial).')

    def value(self, node):
        if node is None:
            return Value()
        if isinstance(node, ast.Name):
            return self.bindings.get(node.id, Value())
        if isinstance(node, (ast.Dict, ast.Constant, ast.List, ast.Tuple)):
            try:
                return Value(literal=ast.literal_eval(node))
            except (ValueError, TypeError):
                for child in ast.iter_child_nodes(node):
                    if isinstance(child,ast.expr):
                        self.value(child)
                return Value()
        if isinstance(node, ast.Attribute):
            parent = self.value(node.value)
            if parent.module == '!external':
                return Value('!external')
            if parent.module and not parent.name:
                return self.public(parent.module, node.attr)
            if parent.instance:
                init, _ = self.method(parent, '__init__')
                if init:
                    for assignment in ast.walk(init):
                        if isinstance(assignment, ast.Assign) and isinstance(assignment.value, ast.Call):
                            if any(isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name) and t.value.id == 'self' and t.attr == node.attr for t in assignment.targets):
                                if isinstance(assignment.value.func, ast.Name):
                                    result = self.public(parent.module, assignment.value.func.id)
                                    result.instance = True
                                    return result
                function, _ = self.method(parent, node.attr)
                if function and any(isinstance(d, ast.Name) and d.id == 'property' for d in function.decorator_list):
                    self.proof(parent,function)
                    return self.return_type(parent, node.attr, function)
                if function:
                    return Value()
                definition = self.definition(parent)
                if isinstance(definition,ast.ClassDef):
                    for member in definition.body:
                        targets = member.targets if isinstance(member,ast.Assign) else [member.target] if isinstance(member,ast.AnnAssign) else []
                        if any(isinstance(t,ast.Name) and t.id==node.attr for t in targets):
                            return Value()
                if init:
                    for assignment in ast.walk(init):
                        if isinstance(assignment,(ast.Assign,ast.AnnAssign)):
                            targets = assignment.targets if isinstance(assignment,ast.Assign) else [assignment.target]
                            if any(isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id=='self' and t.attr==node.attr for t in targets):
                                return Value()
                if definition is not None:
                    self.problem(parent.name+' has no verified attribute '+node.attr+'. Read its source for the real state/property contract.')
            return Value()
        if isinstance(node, ast.Call):
            return self.call(node)
        for child in ast.iter_child_nodes(node):
            if isinstance(child,ast.expr):
                self.value(child)
        return Value()

    def call(self, node):
        arguments = [self.value(n) for n in node.args]
        keywords = {n.arg: self.value(n.value) for n in node.keywords if n.arg}
        if isinstance(node.func, ast.Name):
            if node.func.id in self.internal_tools and node.func.id not in self.bindings:
                self.problem(node.func.id + ' is an assistant RPC tool, not a public function to import or call in callback examples.')
            target = self.value(node.func)
            definition = self.definition(target) if target.module and target.name else None
            if isinstance(definition, ast.ClassDef):
                fields = {n.target.id for n in definition.body if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)}
                if any(isinstance(b, ast.Name) and b.id == 'TypedDict' for b in definition.bases):
                    unknown = set(keywords) - fields
                    if unknown:
                        self.problem(target.name+' has unsupported settings: '+', '.join(sorted(unknown))+'. Fields: '+', '.join(sorted(fields)))
                    self.proof(target)
                    return Value(literal={k: v.literal for k,v in keywords.items()})
                function, owner = self.method(target, '__init__')
                if function:
                    self.check_call(node, function, owner, True)
                    if target.module == 'app.tool_api' and any(a.arg == 'registry' for a in function.args.args[1:]):
                        self.problem('Do not construct '+target.name+' with a new registry in callback examples. Use the application-bound public Tools proxy instead.')
                self.proof(target)
                return Value(target.module, target.name, True)
            if isinstance(definition, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.check_call(node, definition, target, False)
                return self.return_type(target, '', definition)
            return Value('!external') if target.module == '!external' else Value()
        if isinstance(node.func, ast.Attribute):
            receiver = self.value(node.func.value)
            if receiver.module and receiver.name:
                families = {'SerialAPI': 'serial', 'SerialSessionAPI': 'serial',
                            'CommunicationAPI': 'communication', 'CommunicationSessionAPI': 'communication'}
                if self.expected_family and receiver.name in families and families[receiver.name] != self.expected_family:
                    self.problem('This example switches tool families despite the explicit user target. Use Tools.'+self.expected_family+' for the named session family.')
                function, owner = self.method(receiver, node.func.attr)
                if not function:
                    self.problem(receiver.name+' has no verified method '+node.func.attr+'. Inspect '+receiver.module+'; do not mix SerialSessionAPI.connect() with CommunicationSessionAPI.start().')
                    return Value()
                decorators = {d.id for d in function.decorator_list if isinstance(d, ast.Name)}
                bound = (receiver.instance or 'classmethod' in decorators) and 'staticmethod' not in decorators
                self.check_call(node, function, owner, bound)
                self.settings(receiver, node.func.attr, arguments, keywords)
                result = self.return_type(receiver, node.func.attr, function)
                if node.func.attr in {'new_session', 'session', 'selected'}:
                    config = (keywords.get('config') or (arguments[0] if arguments else Value())).literal
                    if isinstance(config, dict):
                        result.protocol = config.get('protocol', '')
                        if receiver.name == 'CommunicationAPI' and node.func.attr == 'new_session':
                            self.hub_settings(config)
                if node.func.attr == 'send' and receiver.protocol and receiver.protocol != 'tcp_server':
                    if keywords.get('target', Value()).literal not in {None, ''}:
                        self.problem('target selects TCP-server clients; it does not broadcast across serial sessions.')
                return result
            unresolved_methods = self.project_methods if self.expected_family else {'new_session','session','start','connect','send'}
            if receiver.module != '!external' and receiver.literal is None and node.func.attr in unresolved_methods:
                self.problem('Cannot verify the receiver of '+ast.unparse(node.func)+'. Show an explicit public Tools lookup or a project API type annotation; do not assume an earlier answer used the correct session type.')
            # Standard/external APIs are outside this checker's proof scope.
            return Value('!external') if receiver.module == '!external' else Value()
        return Value()

    def check_call(self, call, function, owner, bound):
        self.proof(owner, function)
        if any(isinstance(n, ast.Starred) for n in call.args) or any(k.arg is None for k in call.keywords):
            self.problem('Cannot verify expanded arguments for '+owner.name+'.'+function.name+'. Show explicit project API arguments.')
            return
        try:
            self.signature(function, bound).bind(*([None]*len(call.args)), **{k.arg: None for k in call.keywords})
        except TypeError as exc:
            self.problem(owner.name+'.'+function.name+': '+str(exc)+'. Signature: '+str(self.signature(function, bound)))

    def statement(self, node):
        if isinstance(node, ast.ImportFrom) and node.module:
            if node.module.split('.')[0] in {'app', 'callbacks', 'externals'}:
                if self.tree(node.module) is None:
                    self.problem('Project module does not exist: '+node.module)
                    return
                for alias in node.names:
                    value = self.public(node.module, alias.name)
                    if not value.module:
                        self.problem('No static export '+alias.name+' in '+node.module+'. Inspect the actual public API.')
                    self.bindings[alias.asname or alias.name] = value
            else:
                for alias in node.names:
                    self.bindings[alias.asname or alias.name] = Value('!external')
        elif isinstance(node, ast.Import):
            for alias in node.names:
                self.bindings[alias.asname or alias.name] = Value(alias.name) if alias.name.startswith(('app.', 'externals.', 'callbacks.')) else Value('!external')
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            value = self.value(node.value)
            for target in node.targets if isinstance(node, ast.Assign) else [node.target]:
                if isinstance(target, ast.Name):
                    self.bindings[target.id] = value
        elif isinstance(node, ast.Expr):
            self.value(node.value)
        elif isinstance(node,ast.Return):
            self.value(node.value)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            saved = self.bindings.copy()
            for argument in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs]:
                raw = Value('!external') if isinstance(argument.annotation,ast.Name) and argument.annotation.id in {'dict','list','str','bytes','int','float','bool','tuple','set'} else self.value(argument.annotation)
                parameter = replace(raw, instance=bool(raw.module and raw.name))
                self.bindings[argument.arg] = parameter
            for child in node.body:
                self.statement(child)
            self.bindings = saved
        elif isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
            self.value(getattr(node,'test',None))
            self.value(getattr(node,'iter',None))
            for child in node.body:
                self.statement(child)
            for child in getattr(node, 'orelse', []):
                self.statement(child)
            for handler in getattr(node, 'handlers', []):
                for child in handler.body:
                    self.statement(child)

    def validate(self, answer):
        for code in re.findall(r'```(?:python|py)\s*\n(.*?)```', answer, flags=re.I | re.S):
            try:
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter('always',SyntaxWarning)
                    tree = ast.parse(textwrap.dedent(code))
                if any(issubclass(w.category,SyntaxWarning) for w in caught):
                    self.problem('Python example contains an invalid escape or other syntax warning. Correct the byte/string literal; do not silently change the requested wire bytes.')
            except SyntaxError:
                self.problem('Python example is incomplete or has invalid syntax; provide a complete checked example or omit executable-looking code.')
                continue
            for node in tree.body:
                self.statement(node)
            try:
                comments = [token.string for token in tokenize.generate_tokens(io.StringIO(textwrap.dedent(code)).readline) if token.type==tokenize.COMMENT]
            except (tokenize.TokenError,IndentationError):
                comments=[]
            for comment in comments:
                for reference in re.findall(r'\bTools\.[A-Za-z_]\w*\.[A-Za-z_]\w*',comment):
                    self.mention(reference)
        for inline in re.findall(r'(?<!`)`([^`\n]+)`(?!`)',answer):
            self.mention(inline)
        if self.issues:
            raise AssistantError('API_EXAMPLE_INVALID', '\n'.join(self.issues[:8])+'\n'+self.guidance())
        return list(self.verified.values())

    def seed_history(self, messages):
        """Carry types across follow-ups only after revalidating prior examples.

        A prior assistant answer is not authority. Invalid examples and examples
        for a different explicit tool family contribute no receiver bindings.
        """
        for message in messages[-8:]:
            if message.get('role') != 'assistant':
                continue
            candidate = ApiExamples(self.index, self.internal_tools, self.expected_family)
            candidate.bindings.update(self.bindings)
            try:
                proofs = candidate.validate(message.get('content', ''))
            except AssistantError:
                continue
            if proofs:
                self.bindings.update({name: value for name,value in candidate.bindings.items() if value.module})


def named_family(user_messages):
    """Resolve explicitly named product entities, never execution intent.

    Ambiguous 'serial session' alone makes no choice. Assistant claims cannot set
    this binding, and it never grants editing or execution permission.
    """
    for message in reversed(user_messages):
        text = message.casefold()
        hub = 'communication hub' in text or 'tools.communication' in text
        serial = any(name in text for name in ('tools.serial', 'standalone serial', 'tools → serial', 'tools > serial'))
        if hub and serial:
            return None
        if hub:
            return 'communication'
        if serial:
            return 'serial'
    return None
