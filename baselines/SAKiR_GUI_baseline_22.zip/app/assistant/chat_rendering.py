"""Bounded Markdown work and cached formatting for completed chat messages."""
from functools import lru_cache
import html
import re

try:
    import markdown2
except ImportError:
    markdown2 = None


MAX_MARKDOWN_CHARS = 32_000


def message_html(role, content):
    # Streamed Markdown is bounded and painted on the UI batching timer.
    if role == "pending":
        return _format(role, content, markdown=True)
    return _completed_message_html(role, content)


@lru_cache(maxsize=128)
def _completed_message_html(role, content):
    return _format(role, content, markdown=True)


@lru_cache(maxsize=128)
def content_html(content, markdown=True):
    text = "<pre>" + html.escape(content) + "</pre>"
    if markdown and markdown2 is not None and len(content) <= MAX_MARKDOWN_CHARS:
        try:
            text = markdown2.markdown(content, safe_mode="escape", extras=["fenced-code-blocks", "tables"])
            text = re.sub(r"<img\b[^>]*>", "", text, flags=re.I)
        except Exception:
            pass  # A formatting error must not interrupt the GUI's event loop.
    text = re.sub(r"<pre\b[^>]*>.*?</pre>",
                  lambda match: '<table width="100%" cellspacing="0" cellpadding="12" bgcolor="#f3f5f8">'
                  '<tr><td style="padding:12px;">' + match.group() + '</td></tr></table>', text, flags=re.S | re.I)
    return text


@lru_cache(maxsize=128)
def activity_html(content):
    """Interpret Markdown while keeping progress in the live status typography."""
    rendered = content_html(content)
    rendered = re.sub(r"<br\s*/?>|</(?:p|h[1-6]|li|pre|tr|blockquote)>", "\n", rendered, flags=re.I)
    plain = html.unescape(re.sub(r"<[^>]*>", "", rendered))
    plain = re.sub(r"\n[ \t]*\n+", "\n", plain).strip()
    return ('<p style="margin:6px 0; color:#697180; font-size:9pt; font-weight:normal;">'
            + html.escape(plain).replace("\n", "<br>") + '</p>')


def _format(role, content, markdown):
    text = content_html(content, markdown)
    name = {"user": "You", "assistant": "SAKiR", "pending": "SAKiR · response in progress",
            "error": "Something went wrong"}.get(role, role.title())
    if role == "user":
        return ('<table width="100%" cellspacing="0" cellpadding="0"><tr>'
                '<td width="22%"></td><td width="78%" align="right">'
                '<table align="right" cellspacing="0" cellpadding="14" bgcolor="#f2f4f7">'
                '<tr><td style="color:#697180; font-size:9pt;"><b>You</b></td>'
                '<td width="44" align="center" valign="top"><!--USER_COPY--></td></tr>'
                '<tr><td colspan="2">' + text + '</td></tr></table></td></tr></table>'
                "<p style='font-size:6pt;'>&nbsp;</p>")
    background = ' bgcolor="#f2f4f7"' if role == "user" else ""
    color = "#b43c32" if role == "error" else "#697180"
    return ('<table width="100%" cellspacing="0" cellpadding="14"' + background + '><tr><td style="padding:14px;">'
            + '<p style="color:' + color + '; font-size:9pt;"><b>' + html.escape(name) + "</b></p>" + text
            + "</td></tr></table><p style='font-size:6pt;'>&nbsp;</p>")
