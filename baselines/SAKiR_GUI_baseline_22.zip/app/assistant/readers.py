"""Bounded, trusted data readers. Worker processes never evaluate file content."""
import csv
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import threading
import xml.etree.ElementTree as ET

from .policy import AssistantError, digest, redact


_memory_job = None


def limit_worker_memory(limit=2 * 1024**3):
    """Bound parser allocations where the OS supports an enforceable limit."""
    global _memory_job
    try:
        if os.name != "nt":
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
            return True
        import ctypes as c
        from ctypes import wintypes as w
        class Basic(c.Structure):
            _fields_ = [("process_time", c.c_longlong), ("job_time", c.c_longlong), ("flags", w.DWORD),
                        ("min_working_set", c.c_size_t), ("max_working_set", c.c_size_t), ("active_processes", w.DWORD),
                        ("affinity", c.c_size_t), ("priority", w.DWORD), ("scheduling", w.DWORD)]
        class IO(c.Structure):
            _fields_ = [(name, c.c_ulonglong) for name in ("read_ops", "write_ops", "other_ops", "read_bytes", "write_bytes", "other_bytes")]
        class Extended(c.Structure):
            _fields_ = [("basic", Basic), ("io", IO), ("process_memory", c.c_size_t), ("job_memory", c.c_size_t),
                        ("peak_process", c.c_size_t), ("peak_job", c.c_size_t)]
        kernel = c.WinDLL("kernel32", use_last_error=True)
        kernel.CreateJobObjectW.argtypes = [c.c_void_p, w.LPCWSTR]
        kernel.CreateJobObjectW.restype = w.HANDLE
        kernel.GetCurrentProcess.restype = w.HANDLE
        kernel.SetInformationJobObject.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD]
        kernel.AssignProcessToJobObject.argtypes = [w.HANDLE, w.HANDLE]
        kernel.CloseHandle.argtypes = [w.HANDLE]
        job = kernel.CreateJobObjectW(None, None)
        info = Extended()
        info.basic.flags = 0x100  # JOB_OBJECT_LIMIT_PROCESS_MEMORY
        info.process_memory = limit
        if not job or not kernel.SetInformationJobObject(job, 9, c.byref(info), c.sizeof(info)) or not kernel.AssignProcessToJobObject(job, kernel.GetCurrentProcess()):
            if job:
                kernel.CloseHandle(job)
            return False
        _memory_job = job  # retain the job handle for the entire worker lifetime
        return True
    except (ImportError, OSError, ValueError):
        return False


def scalar(value):
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if hasattr(value, "item"):
        try:
            return scalar(value.item())
        except (ValueError, TypeError):
            pass
    return str(value)[:2000]


def frame_result(columns, rows):
    return {"columns": [str(c) for c in columns[:30]],
            "rows": [[scalar(v) for v in row[:30]] for row in rows], "sample": True}


def bounded_preview(result, max_chars=60000):
    """Keep oversized worker responses valid structured evidence, never cut JSON."""
    if len(json.dumps(result, ensure_ascii=False, default=scalar)) <= max_chars:
        return result
    for limit in (20,10,3,1):
        def compact(value, depth=0):
            if depth > 20:
                return '[Nested data omitted]'
            if isinstance(value,dict):
                return {k:compact(v,depth+1) for k,v in list(value.items())[:min(40,limit*2)]}
            if isinstance(value,(list,tuple)):
                return [compact(v,depth+1) for v in value[:limit]]
            if isinstance(value,str):
                return value[:2000]
            return value
        candidate=compact(result)
        candidate['reader_truncated']=True
        candidate['truncation_limits']={'array_items':limit,'object_fields':min(40,limit*2),'string_characters':2000,
                                        'instruction':'Inspect a narrower range/options for omitted data. Samples do not represent all rows or columns.'}
        if len(json.dumps(candidate,ensure_ascii=False,default=scalar)) <= max_chars:
            return candidate
    return {'reader_truncated':True,'format':result.get('format'),
            'message':'Result exceeds bounded preview even after projection. Inspect a narrower range/options.'}


def read_local(filename, options):
    path = Path(filename)
    rows = min(200, max(1, int(options.get("limit", 50))))
    kind = path.suffix.lower()
    if path.stat().st_size > 256 * 1024 * 1024:
        raise AssistantError("FILE_TOO_LARGE", "Inspection limit is 256 MiB; select a smaller file.")
    result = {"filename": path.name, "bytes": path.stat().st_size, "format": kind}
    # Avoid hashing a huge file just to obtain a bounded preview.
    info = path.stat()
    result["revision"] = digest([str(path), info.st_mtime_ns, info.st_size])
    if kind in {".xlsx", ".xlsm"}:
        import openpyxl
        book = openpyxl.load_workbook(path, read_only=True, data_only=True, keep_links=False)
        try:
            result["sheets"] = [{"name": s.title, "rows": s.max_row, "columns": s.max_column} for s in book.worksheets]
            sheet = options.get("sheet") or book.sheetnames[0]
            if sheet not in book.sheetnames:
                raise AssistantError("UNKNOWN_SHEET", f"Unknown sheet: {sheet}")
            table = book[sheet]
            header_row = max(1, int(options.get("header_row", 1)))
            start = max(1, int(options.get("start_row", header_row + 1)))
            end = min(start + rows - 1, int(options.get("end_row", start + rows - 1)))
            column = max(1, int(options.get("start_column", 1)))
            last_column = min(column + 29, int(options.get("end_column", table.max_column or column + 29)))
            if end < start:
                raise AssistantError("INVALID_RANGE", "end_row must be at least start_row.")
            if last_column < column or last_column > 16384 or end > 1048576:
                raise AssistantError("INVALID_RANGE", "Invalid worksheet row/column range.")
            names = next(table.iter_rows(min_row=header_row, max_row=header_row, min_col=column, max_col=last_column, values_only=True), ())
            values = list(table.iter_rows(min_row=start, max_row=end, min_col=column, max_col=last_column, values_only=True))
            result.update(frame_result(names, values))
            result.update({"sheet": sheet, "worksheet_start_row": start, "worksheet_end_row": end,
                           "worksheet_start_column": column, "worksheet_end_column": last_column,
                           "note": "Physical worksheet rows are 1-based. Formula values are cached; formulas are not recalculated."})
        finally:
            book.close()
    elif kind == ".xls":
        import pandas as pd
        with pd.ExcelFile(path) as book:
            result["sheets"] = book.sheet_names
            data = pd.read_excel(book, sheet_name=options.get("sheet") or book.sheet_names[0], nrows=rows)
            result.update(frame_result(list(data.columns), data.values.tolist()))
    elif kind in {".csv", ".tsv", ".txt"}:
        with path.open("r", encoding=options.get("encoding", "utf-8-sig"), newline="") as stream:
            sample = stream.read(8192)
            stream.seek(0)
            delimiter = options.get("delimiter")
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|") if not delimiter else None
            except csv.Error:
                dialect = None
            if delimiter or dialect or kind in {".csv", ".tsv"}:
                reader = csv.reader(stream, dialect=dialect or "excel", **({"delimiter": delimiter or "\t"} if delimiter or kind == ".tsv" else {}))
                header = next(reader, [])
                values = []
                for _, row in zip(range(rows), reader):
                    values.append(row)
                result.update(frame_result(header, values))
            else:
                result["text"] = sample
    elif kind in {".json", ".xml"}:
        if path.stat().st_size > 8 * 1024 * 1024:
            raise AssistantError("FILE_TOO_LARGE", "JSON/XML inspection limit is 8 MiB.")
        text = path.read_text(encoding="utf-8-sig")
        if kind == ".json":
            value = json.loads(text)
            if options.get("key"):
                for key in options["key"].split("."):
                    value = value[int(key)] if isinstance(value, list) else value[key]
            result["data"] = redact(value[:rows] if isinstance(value, list) else value)
        else:
            if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper():
                raise AssistantError("XML_UNSUPPORTED", "DTD/entity declarations are not supported.")
            root = ET.fromstring(text)
            result.update({"root": root.tag, "attributes": dict(root.attrib), "records": [
                {"tag": item.tag, "attributes": dict(item.attrib), "text": (item.text or "").strip()[:1000],
                 "children": [{"tag": c.tag, "text": (c.text or "").strip()[:1000]} for c in list(item)[:30]]}
                for item in list(root)[:rows]]})
    elif kind == ".mat":
        import h5py
        if h5py.is_hdf5(path):
            with h5py.File(path) as book:
                result["variables"] = [{"name": k, "shape": list(v.shape) if hasattr(v, "shape") else None,
                                        "dtype": str(getattr(v, "dtype", "group"))} for k, v in book.items() if k != "#refs#"]
                if options.get("key"):
                    data = book[options["key"]]
                    if not hasattr(data, "shape") or h5py.check_dtype(ref=data.dtype) is not None:
                        result["note"] = "MATLAB group/reference data requires a format-specific adapter; no numeric table inferred."
                    else:
                        result["sample"] = data[tuple(slice(0, min(rows if i == 0 else 10, n)) for i, n in enumerate(data.shape))].tolist()
                        result["note"] = "HDF5 dataset order shown; MATLAB dimensions may use reversed storage order."
        else:
            from scipy.io import loadmat, whosmat
            result["variables"] = [{"name": name, "shape": list(shape), "type": cls} for name, shape, cls in whosmat(path)]
            if options.get("key"):
                value = loadmat(path, variable_names=[options["key"]])[options["key"]]
                result["sample"] = str(value[:rows])[:12000]
    else:
        offset = max(0, int(options.get("offset", 0)))
        with path.open("rb") as stream:
            stream.seek(offset)
            raw = stream.read(min(4096, max(1, int(options.get("length", 4096)))))
        result.update({"offset": offset, "hex": raw.hex(" "),
                       "ascii": "".join(chr(v) if 32 <= v < 127 else "." for v in raw)})
        schema = options.get("binary_schema")
        if schema:
            formats = {"uint8": "B", "int8": "b", "uint16": "H", "int16": "h", "uint32": "I", "int32": "i",
                       "uint64": "Q", "int64": "q", "float32": "f", "float64": "d"}
            fields = schema["fields"]
            if schema.get("byte_order") not in {"little", "big"} or not 1 <= len(fields) <= 30:
                raise AssistantError("INVALID_SCHEMA", "Specify byte_order and 1–30 typed fields.")
            fmt = ("<" if schema["byte_order"] == "little" else ">") + "".join(formats[f["type"]] for f in fields)
            parser = struct.Struct(fmt)
            count = min(rows, len(raw) // parser.size)
            result.update(frame_result([f["name"] for f in fields], [parser.unpack_from(raw, i * parser.size) for i in range(count)]))
            result["note"] = "Decoded packed fixed-length records using the supplied schema, without inferred padding."
    return redact(result)


def inspect_file(policy, filename, options, timeout=30, cancel=None):
    path = policy.path(filename)
    stat_before = path.stat()
    request = json.dumps({"filename": str(path), "options": options})
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    executable = Path(sys.executable)
    if executable.name.lower() == "pythonw.exe" and executable.with_name("python.exe").exists():
        executable = executable.with_name("python.exe")
    process = subprocess.Popen([str(executable), "-B", "-m", "app.assistant.readers"], cwd=policy.root,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, encoding="utf-8", creationflags=flags)
    timer = threading.Timer(timeout, process.kill)
    timer.start()
    stop = threading.Event()
    def cancel_worker():
        while not stop.wait(.1):
            if cancel is not None and cancel.is_set():
                process.kill()
                return
    watcher = threading.Thread(target=cancel_worker, daemon=True)
    watcher.start()
    try:
        out, err = process.communicate(request)
        if cancel is not None and cancel.is_set():
            raise AssistantError("CANCELLED", "File inspection stopped.")
        if process.returncode:
            raise AssistantError("READER_FAILED", (err or out or "Reader timed out or exceeded its resource limit.")[-2000:])
        after = policy.path(filename).stat()
        if (stat_before.st_size, stat_before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise AssistantError("FILE_CHANGED", "File changed during inspection; inspect it again.")
        result = json.loads(out)
        if not result.get("ok"):
            raise AssistantError(result["code"], result["message"])
        return result["data"]
    finally:
        stop.set()
        timer.cancel()
        if process.poll() is None:
            process.kill()
            process.wait()


if __name__ == "__main__":
    try:
        memory_limited = limit_worker_memory()
        request = json.load(sys.stdin)
        result = read_local(request["filename"], request.get("options", {}))
        result["resource_limits"] = {"memory_bytes": 2 * 1024**3 if memory_limited else None}
        result = bounded_preview(result)
        print(json.dumps({"ok": True, "data": result}, ensure_ascii=False, default=scalar))
    except Exception as exc:
        print(json.dumps({"ok": False, "code": getattr(exc, "code", "READER_FAILED"), "message": str(exc) or type(exc).__name__}))
