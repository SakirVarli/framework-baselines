"""Small independent predicates selected during inspection, before authoring.

These establish explicit names/bindings/properties, not arbitrary program behavior.
"""
import ast
import json

from .task_context import layout_rows
from .tools import obj, STRING
from .policy import AssistantError


CHECK = obj({'requirement': STRING,
             'kind': {'type': 'string', 'enum': ['callback_exists', 'callback_binding', 'layout_property']},
             'target': STRING, 'property': STRING, 'expected': STRING, 'user_reference': STRING},
            ['requirement', 'kind', 'target', 'expected', 'user_reference'])


def accept(checks, task, request):
    keys = {r['key'] for r in task['requirements']}
    source = '\n'.join([request, task['source_text'], *[
        q['answer']['text'] for q in task['questions'] if q['status'] == 'answered' and q.get('answer')]])
    for row in checks:
        reference = row['user_reference']
        expected = row['expected']
        if row['kind'] == 'layout_property':
            try:
                parsed = json.loads(expected)
                expected = parsed if isinstance(parsed, str) else expected
            except ValueError as exc:
                raise AssistantError('REQUIREMENT_CHECK', 'Layout expected values must be JSON.') from exc
        elif not expected.isidentifier():
            raise AssistantError('REQUIREMENT_CHECK', 'Callback checks expect a Python function name such as export_data, not a sentence or return value.')
        if (row['requirement'] not in keys or not reference.strip() or reference not in source
                or ''.join(expected.split()) not in ''.join(reference.split())):
            raise AssistantError('REQUIREMENT_CHECK', 'Checks must cite explicit user text containing the expected value.')
        if row['kind'] == 'layout_property':
            if not row.get('property'):
                raise AssistantError('REQUIREMENT_CHECK', 'Layout checks need a property name.')
            try:
                json.loads(row['expected'])
            except ValueError as exc:
                raise AssistantError('REQUIREMENT_CHECK', 'Layout expected values must be JSON.') from exc
    return checks


def verify(checks, proposal, snapshot):
    files = {e.path: e.content for e in proposal.edits}
    source = files.get('callbacks/callbacks.py', snapshot['callbacks']) or ''
    config_text = files.get('app/data/config.json')
    config = json.loads(config_text) if config_text else snapshot['config']
    rows = layout_rows({'config': config})
    functions = [n.name for n in ast.parse(source).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    results = []
    for row in checks:
        matches = [n for n in rows if row['target'] in (n.get('node_id'), n['selector'],
                   n['properties'].get('name'), n['properties'].get('instance'))]
        if row['kind'] == 'callback_exists':
            passed = functions.count(row['expected']) == 1
        elif row['kind'] == 'callback_binding':
            passed = len(matches) == 1 and matches[0]['properties'].get('callback') == row['expected']
        else:
            passed = len(matches) == 1 and matches[0]['properties'].get(row['property']) == json.loads(row['expected'])
        results.append({'requirement': row['requirement'], 'kind': row['kind'], 'ok': passed,
                        'message': ('Verified ' if passed else 'Unmet explicit requirement: ') + row['user_reference']})
    return results
