"""Searchable, non-modal help for both Assistant settings modes."""
import html

from PyQt5 import QtCore, QtWidgets

from .appearance import apply_theme
from .settings_help import SETTING_HELP, SETTING_TITLES, GUIDE_NOTES, HEADER_HELP
from .settings_policy import AUTOMATIC_FIELDS


OVERVIEW = """Choose Simplified settings to calculate coordinated limits, or Advanced settings to edit them manually.

Available input tokens = model capacity − maximum output tokens − safety margin.

Compaction begins when either the token input budget or usable character guard reaches the threshold.

Example with capacity 262,144, Large completion allowance and Simplified's 2,621-token margin:
input budget = 262,144 − 65,536 − 2,621 = 193,987 tokens.
Character setting = 775,948; usable character guard = 581,961.

At 80%, compaction starts at about 155,189 input tokens or 465,568 characters, whichever guard reaches its threshold first.

These are estimates, not a conversion guarantee. Large file results fill context faster; summaries consume model rounds and task time. Capacity is detected only from matching server metadata or entered manually.

When unknown, the guide and preview say Unknown and the conservative character guard remains active.

Save applies settings; Cancel discards edits. Switching modes preserves manual limits."""

TROUBLESHOOTING = """OUTPUT_LIMIT: generation was truncated. Check output allowance, reasoning use and remaining input room.
CONTEXT_LIMIT: required messages or tool schemas do not fit the token or character guard. Check actual server capacity and result sizes.
CONTEXT_COMPACTION_FAILED: a bounded summary could not be produced. Check the summary error, remaining model rounds and server behavior.
TASK_LIMIT: read the message to distinguish overall deadline, model rounds and tool-call count.
Request timeout: check model/server responsiveness and Request timeout. Task deadline is separate.
File-reader timeout: check the file and File-reader timeout. Model timeout is separate.
Unsupported parameter: correct Output limit parameter, streaming or stream-usage compatibility.
Authentication or certificate error: correct the connection credentials or trusted CA bundle.
Repeated identical tool calls: investigate model/tool behavior before increasing budgets."""


class SettingsGuideDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent, QtCore.Qt.Window)
        self.setWindowTitle("Assistant Settings Guide")
        self.setModal(False)
        self.resize(850, 650)
        apply_theme(self)
        outer = QtWidgets.QVBoxLayout(self)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Search settings, units, dependencies or errors…")
        self.search.setAccessibleName("Search settings guide")
        outer.addWidget(self.search)
        splitter = QtWidgets.QSplitter()
        self.topics = QtWidgets.QListWidget()
        self.topics.setWordWrap(True)
        self.topics.setTextElideMode(QtCore.Qt.ElideNone)
        self.topics.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.topics.setMinimumWidth(210)
        self.topics.setAccessibleName("Settings guide topics")
        self.content = QtWidgets.QTextBrowser()
        self.content.setAccessibleName("Settings guide explanation")
        self.content.setOpenExternalLinks(False)
        splitter.addWidget(self.topics)
        splitter.addWidget(self.content)
        splitter.setSizes([270, 580])
        outer.addWidget(splitter, 1)
        self.entries = {"overview": ("How the settings work together", OVERVIEW),
                        "errors": ("Errors and troubleshooting", TROUBLESHOOTING),
                        "usage_headers": ("Usage header mappings", "\n\n".join(HEADER_HELP)
                                          + "\nValues come from HTTP response headers. Missing headers show Not provided. No model calls or calculations infer their units.")}
        for key, help_text in SETTING_HELP.items():
            if key in AUTOMATIC_FIELDS:
                behavior = "Simplified: calculated automatically. Advanced: editable manually."
            elif key in {"task_preset", "output_preset", "file_detail"}:
                behavior = "Simplified: choose a preset. Advanced: individual limits control behavior instead."
            else:
                behavior = "Available in both modes."
            self.entries[key] = (SETTING_TITLES[key], help_text + "\n\n" + behavior + "\n\n" + GUIDE_NOTES[key])
        self.search.textChanged.connect(self.filter_topics)
        self.topics.currentItemChanged.connect(self.show_topic)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        buttons.rejected.connect(self.close)
        outer.addWidget(buttons)
        self.filter_topics()

    def filter_topics(self, text=""):
        current = self.topics.currentItem()
        selected = current.data(QtCore.Qt.UserRole) if current else None
        self.topics.clear()
        for key, (title, body) in self.entries.items():
            if all(word in (key + " " + title + " " + body).casefold() for word in text.casefold().split()):
                item = QtWidgets.QListWidgetItem(title)
                item.setData(QtCore.Qt.UserRole, key)
                self.topics.addItem(item)
                if key == selected:
                    self.topics.setCurrentItem(item)
        if self.topics.currentRow() < 0 and self.topics.count():
            self.topics.setCurrentRow(0)
        if not self.topics.count():
            self.content.setPlainText("No matching settings. Try a setting name, unit or error code.")

    def show_topic(self, current, previous=None):
        if current is None:
            return
        title, body = self.entries[current.data(QtCore.Qt.UserRole)]
        paragraphs = "".join("<p>" + html.escape(part).replace("\n", "<br>") + "</p>" for part in body.split("\n\n"))
        self.content.setHtml("<h2>" + html.escape(title) + "</h2>" + paragraphs)
