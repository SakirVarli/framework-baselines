"""Byte-oriented checksum helpers used by generated message schemas."""

import binascii
from functools import reduce
from operator import xor


def xor8(data):
    """XOR all bytes, starting at zero (also called bytewise BCC)."""
    return reduce(xor, data, 0)


def crc8(data):
    """CRC-8/SMBUS: poly=0x07, init=0, refin/refout=false, xorout=0."""
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ (0x07 if crc & 0x80 else 0)) & 0xff
    return crc


def crc16_modbus(data):
    """CRC-16/MODBUS: poly=0x8005, init=0xffff, reflected, xorout=0."""
    crc = 0xffff
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0xa001 if crc & 1 else 0)
    return crc


def crc16_ccitt_false(data):
    """CRC-16/IBM-3740 (CCITT-FALSE): poly=0x1021, init=0xffff."""
    return binascii.crc_hqx(data, 0xffff)
