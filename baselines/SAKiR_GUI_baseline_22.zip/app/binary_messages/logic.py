"""Runtime value contracts for designer-generated control flow."""
from construct import Construct, Subconstruct, RangeError, evaluate
from construct import Enum as ConstructEnum, MappingError
from construct import ConstructError
from construct import EnumIntegerString
from construct.core import stream_tell
from construct.core import stream_read, stream_write
from io import BytesIO
import math


def wire_truth(value):
    return bool(int(value)) if isinstance(value, EnumIntegerString) else bool(value)


class StrictEnum(ConstructEnum):
    def _decode(self, obj, context, path):
        if obj not in self.decmapping:
            raise MappingError(f'unknown enum value {obj}', path=path)
        return super()._decode(obj, context, path)

    def _encode(self, obj, context, path):
        value = super()._encode(obj, context, path)
        if value not in self.decmapping:
            raise MappingError(f'unknown enum value {value}', path=path)
        return value


class ConditionalIf(Construct):
    def __init__(self, condition, item):
        super().__init__()
        self.condition, self.item = condition, item
        self.flagbuildnone = True

    def _parse(self, stream, context, path):
        return self.item._parsereport(stream, context, path) if evaluate(self.condition, context) else None

    def _build(self, obj, stream, context, path):
        present = bool(evaluate(self.condition, context))
        if present != (obj is not None):
            raise RangeError('conditional presence does not match its controlling value', path=path)
        return self.item._build(obj, stream, context, path) if present else None

    def _sizeof(self, context, path):
        return self.item._sizeof(context, path) if evaluate(self.condition, context) else 0


class _RecordingStream:
    def __init__(self, stream, path):
        self.stream, self.start = stream, stream_tell(stream, path)
        self.data = bytearray()
        self.coverage = []

    def _record(self, position, data):
        offset = position - self.start
        if offset < 0:
            data = data[-offset:]; offset = 0
        if offset + len(data) > len(self.data):
            self.data.extend(bytes(offset + len(data) - len(self.data)))
        self.data[offset:offset + len(data)] = data
        if data:
            span = (offset, offset + len(data))
            if self.coverage and span[0] <= self.coverage[-1][1] and span[1] >= self.coverage[-1][0]:
                self.coverage[-1] = (min(span[0], self.coverage[-1][0]), max(span[1], self.coverage[-1][1]))
            else:
                self.coverage.append(span)

    def captured(self, path):
        end = self.stream.tell(); length = end - self.start
        if length < 0:
            raise RangeError('captured field moved before its start', path=path)
        covered = 0
        for start, stop in sorted(self.coverage):
            if start > covered:
                break
            covered = max(covered, stop)
        if covered >= length:
            return bytes(self.data[:length])
        # Seeking constructs can skip bytes without reading/writing them.
        # Recover actual bytes from readable streams; never invent zero bytes.
        try:
            self.stream.seek(self.start)
            return stream_read(self.stream, length, path)
        except (ConstructError, OSError, AttributeError) as error:
            raise RangeError('captured source skipped bytes unavailable from this stream', path=path) from error
        finally:
            self.stream.seek(end)

    def read(self, count=-1):
        position = self.stream.tell(); data = self.stream.read(count)
        self._record(position, data)
        return data

    def write(self, data):
        position = self.stream.tell(); count = self.stream.write(data)
        self._record(position, data[:count])
        return count

    def __getattr__(self, name):
        return getattr(self.stream, name)


class WireCapture(Subconstruct):
    """Record actual field bytes without changing its Python representation."""
    def __init__(self, item, identity):
        super().__init__(item)
        self.identity = identity

    def _run(self, method, stream, context, path, obj=None):
        from .lengths import MEASURING_LENGTH
        if method == 'build' and MEASURING_LENGTH.get():
            return self.subcon._build(obj, stream, context, path)
        recording = _RecordingStream(stream, path)
        value = (self.subcon._parsereport(recording, context, path) if method == 'parse' else
                 self.subcon._build(obj, recording, context, path))
        context.setdefault('_designer_wire', {})[self.identity] = recording.captured(path)
        return value

    def _parse(self, stream, context, path):
        return self._run('parse', stream, context, path)

    def _build(self, obj, stream, context, path):
        return self._run('build', stream, context, path, obj)


def captured_data(context, identities, *, start=0, end=None):
    data = b''.join(context['_designer_wire'][identity] for identity in identities)
    if type(start) is not int or start < 0 or start > len(data) or end is not None and (
            type(end) is not int or end <= start or end > len(data)):
        raise RangeError('checksum byte range is outside the preceding wire data')
    return data[start:end]


class ScalarLimits(Subconstruct):
    def __init__(self, item, *, minimum=None, maximum=None, finite=False, max_bytes=None):
        super().__init__(item)
        self.minimum, self.maximum, self.finite, self.max_bytes = minimum, maximum, finite, max_bytes

    def _check(self, value, path):
        if self.finite and not math.isfinite(value):
            raise RangeError('value must be finite', path=path)
        if self.minimum is not None and not value >= self.minimum or self.maximum is not None and not value <= self.maximum:
            raise RangeError(f'value is outside protocol range {self.minimum}..{self.maximum}', path=path)
        return value

    def _parse(self, stream, context, path):
        if self.max_bytes is None:
            return self._check(self.subcon._parsereport(stream, context, path), path)
        limit = self.max_bytes
        class LimitedRead:
            def __init__(self):
                self.count = 0
                self.exceeded = False
            def read(self, count=-1):
                if count < 0 or self.count + count > limit:
                    self.exceeded = True
                    raise RangeError(f'integer encoding exceeds {limit} bytes', path=path)
                self.count += count
                return stream.read(count)
            def __getattr__(self, name):
                return getattr(stream, name)
        reader = LimitedRead()
        try:
            return self._check(self.subcon._parsereport(reader, context, path), path)
        except ConstructError as error:
            if reader.exceeded:
                raise RangeError(f'integer encoding exceeds {limit} bytes', path=path) from error
            raise

    def _build(self, obj, stream, context, path):
        self._check(obj, path)
        data = BytesIO()
        value = self.subcon._build(obj, data, context, path)
        payload = data.getvalue()
        if self.max_bytes is not None and len(payload) > self.max_bytes:
            raise RangeError(f'integer encoding exceeds {self.max_bytes} bytes', path=path)
        if self.minimum is not None or self.maximum is not None or self.finite:
            self._check(self.subcon._parsereport(BytesIO(payload), context, path), path)
        stream_write(stream, payload, len(payload), path)
        return value


class PaddingBytes(Construct):
    def __init__(self, length, pattern=b'\0', verify=False):
        super().__init__()
        if not isinstance(pattern, bytes) or len(pattern) != 1:
            raise ValueError('padding requires one fill byte')
        self.length, self.pattern, self.verify = length, pattern, verify
        self.flagbuildnone = True

    def _parse(self, stream, context, path):
        length = evaluate(self.length, context)
        data = stream_read(stream, length, path)
        if self.verify and data != self.pattern * length:
            raise RangeError('received padding does not match the fill byte', path=path)
        return None

    def _build(self, obj, stream, context, path):
        length = evaluate(self.length, context)
        stream_write(stream, self.pattern * length, length, path)
        return None

    def _sizeof(self, context, path):
        return evaluate(self.length, context)


class AlignedValue(Subconstruct):
    def __init__(self, modulus, item, pattern=b'\0', verify=False):
        super().__init__(item)
        self.modulus, self.pattern, self.verify = modulus, pattern, verify

    def _parse(self, stream, context, path):
        start = stream_tell(stream, path)
        value = self.subcon._parsereport(stream, context, path)
        padding = (-(stream_tell(stream, path) - start)) % self.modulus
        PaddingBytes(padding, self.pattern, self.verify)._parsereport(stream, context, path)
        return value

    def _build(self, obj, stream, context, path):
        start = stream_tell(stream, path)
        value = self.subcon._build(obj, stream, context, path)
        padding = (-(stream_tell(stream, path) - start)) % self.modulus
        PaddingBytes(padding, self.pattern, self.verify)._build(None, stream, context, path)
        return value

    def _sizeof(self, context, path):
        size = self.subcon._sizeof(context, path)
        return size + (-size) % self.modulus
