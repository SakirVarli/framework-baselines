"""Strict array boundaries and bounded object initialization for generated schemas."""
from __future__ import annotations

from dataclasses import dataclass, fields, is_dataclass
from contextvars import ContextVar
from typing import Annotated, get_args, get_origin
from io import BytesIO

from construct import Construct, Container, EnumIntegerString, ListContainer, RangeError, SizeofError, evaluate
from construct import Enum as ConstructEnum
from construct.core import stream_read, stream_write, stream_tell
from .fields import field_options


class DefaultBudgetExceeded(ValueError):
    pass


class DefaultInputRequired(ValueError):
    pass


AUTO_ARRAY = object()
_DEFAULT_BUDGET = ContextVar('binary_message_default_budget', default=None)


@dataclass(frozen=True)
class IndexedSwitch:
    types: dict[int, object]

    def __hash__(self):
        return hash(tuple(sorted(self.types.items())))


@dataclass
class BranchDefault:
    value: object
    case_uid: str


@dataclass(frozen=True)
class DynamicSwitch:
    selector: object
    types: dict
    fallback: object = object

    def __hash__(self):
        return hash((id(self.selector), tuple(self.types.items()), self.fallback))


def selected_branch(spec, context):
    selector = evaluate(spec['selector'], context)
    if selector in spec['branches']:
        return spec['branches'][selector]
    for key, branch in spec['branches'].items():
        if isinstance(key, EnumIntegerString) and type(selector) is int and int(key) == selector:
            return branch
    return spec.get('fallback')


class _PayloadBuffer(BytesIO):
    def __init__(self, maximum, path):
        super().__init__()
        self.maximum, self.path = maximum, path
        self.exceeded = False

    def write(self, data):
        if self.maximum is not None and self.tell() + len(data) > self.maximum:
            self.exceeded = True
            raise RangeError(f'array payload exceeds maximum {self.maximum} bytes', path=self.path)
        return super().write(data)


class ArrayCodec(Construct):
    """A repetition codec with explicit boundaries, progress checks, and item limits.

    Unlike GreedyRange, a bounded byte payload cannot hide a truncated final item.
    The surrounding context is preserved, including for prefixed arrays.
    """

    def __init__(self, item, *, mode, count=None, prefix=None, predicate=None,
                 minimum=0, maximum=None, max_bytes=None):
        super().__init__()
        if mode not in {'fixed', 'count_field', 'count_expression', 'prefixed', 'greedy', 'byte_prefixed', 'byte_field', 'byte_expression', 'repeat_until'}:
            raise ValueError('unsupported array mode')
        if type(minimum) is not int or minimum < 0 or maximum is not None and (type(maximum) is not int or maximum < minimum):
            raise ValueError('invalid array item limits')
        if max_bytes is not None and (type(max_bytes) is not int or max_bytes < 0):
            raise ValueError('invalid array byte limit')
        self.item, self.mode, self.count = item, mode, count
        self.prefix, self.predicate = prefix, predicate
        self.minimum, self.maximum = minimum, maximum
        self.max_bytes = max_bytes

    def _check_count(self, count, path):
        if type(count) is not int or count < 0:
            raise RangeError(f"array count/length must be a nonnegative integer, found {count!r}", path=path)
        if self.maximum is not None and count > self.maximum:
            raise RangeError(f"array exceeds maximum {self.maximum} items", path=path)
        if count < self.minimum:
            raise RangeError(f"array requires at least {self.minimum} items", path=path)

    def _parse(self, stream, context, path):
        mode = self.mode
        count = evaluate(self.count, context) if self.count is not None else None
        if mode == "prefixed":
            count = self.prefix._parsereport(stream, context, path)
        if mode in {"byte_prefixed", "byte_field", "byte_expression"}:
            length = self.prefix._parsereport(stream, context, path) if mode == "byte_prefixed" else count
            if type(length) is not int or length < 0:
                raise RangeError("byte length must be a nonnegative integer", path=path)
            if self.max_bytes is not None and length > self.max_bytes:
                raise RangeError(f'array payload exceeds maximum {self.max_bytes} bytes', path=path)
            stream = BytesIO(stream_read(stream, length, path))
            count = None
        if mode in {"fixed", "count_field", "count_expression", "prefixed"}:
            self._check_count(count, path)
        result = ListContainer()
        previous_index = context.get("_index", AUTO_ARRAY)
        try:
            while count is None or len(result) < count:
                if count is None and mode != "repeat_until":
                    position = stream_tell(stream, path)
                    if not stream.read(1):
                        break
                    stream.seek(position)
                if self.maximum is not None and len(result) >= self.maximum:
                    raise RangeError(f"array exceeds maximum {self.maximum} items", path=path)
                context._index = len(result)
                start = stream_tell(stream, path)
                value = self.item._parsereport(stream, context, path + f"[{len(result)}]")
                result.append(value)
                if mode == "repeat_until" and self.predicate(value, result, context):
                    break
                if count is None and stream_tell(stream, path) == start:
                    raise RangeError("repeated item consumed no bytes", path=path)
        finally:
            if previous_index is AUTO_ARRAY:
                context.pop("_index", None)
            else:
                context._index = previous_index
        self._check_count(len(result), path)
        return result

    def _build(self, obj, stream, context, path):
        self._check_count(len(obj), path)
        count = evaluate(self.count, context) if self.count is not None else None
        if self.mode in {'fixed', 'count_field', 'count_expression'}:
            self._check_count(count, path)
        if self.mode in {"fixed", "count_field", "count_expression"} and len(obj) != count:
            raise RangeError(f"expected {count} items, found {len(obj)}", path=path)
        payload = _PayloadBuffer(self.max_bytes, path)
        result = ListContainer()
        previous_index = context.get("_index", AUTO_ARRAY)
        try:
            for index, value in enumerate(obj):
                context._index = index
                start = payload.tell()
                try:
                    built = self.item._build(value, payload, context, path + f"[{index}]")
                except Exception as error:
                    if payload.exceeded:
                        raise RangeError(f'array payload exceeds maximum {self.max_bytes} bytes', path=path) from error
                    raise
                result.append(built)
                if self.mode == "repeat_until" and self.predicate(built, result, context):
                    if index != len(obj) - 1:
                        raise RangeError("items follow the terminating array item", path=path)
                    break
                if self.mode in {'greedy', 'byte_prefixed', 'byte_field', 'byte_expression', 'repeat_until'} and payload.tell() == start:
                    raise RangeError('repeated item produced no bytes', path=path)
            else:
                if self.mode == "repeat_until":
                    raise RangeError("array has no terminating item", path=path)
        finally:
            if previous_index is AUTO_ARRAY:
                context.pop("_index", None)
            else:
                context._index = previous_index
        data = payload.getvalue()
        if self.max_bytes is not None and len(data) > self.max_bytes:
            raise RangeError(f'array payload exceeds maximum {self.max_bytes} bytes', path=path)
        if self.mode == "prefixed":
            self.prefix._build(len(obj), stream, context, path)
        elif self.mode == "byte_prefixed":
            self.prefix._build(len(data), stream, context, path)
        elif self.mode in {"byte_field", "byte_expression"} and len(data) != count:
            raise RangeError(f"expected {count} payload bytes, found {len(data)}", path=path)
        stream_write(stream, data, len(data), path)
        return result

    def _sizeof(self, context, path):
        if self.mode in {"fixed", "count_field", "count_expression"}:
            return evaluate(self.count, context) * self.item._sizeof(context, path)
        if self.mode in {"byte_field", "byte_expression"}:
            return evaluate(self.count, context)
        raise SizeofError("variable array size", path=path)


def _field_context(value, annotation):
    if get_origin(annotation) is Annotated and any(isinstance(meta, ConstructEnum) for meta in get_args(annotation)[1:]):
        from .conversion import value_from_wire
        value = value_from_wire(value, annotation)
    return _context_value(value)


def _context_value(value):
    if is_dataclass(value):
        # Normalize enum inputs in the context without mutating caller objects.
        # Callers can pass a member name or its numeric value to the same field.
        from .conversion import resolved_type_hints
        hints = resolved_type_hints(type(value))
        result = Container()
        for field in fields(value):
            if not field_options(field)[0]:
                continue
            current = getattr(value, field.name)
            annotation = hints.get(field.name)
            result[field.name] = _field_context(current, annotation)
        result._designer_encodings = getattr(type(value), '_FIELD_ENCODINGS', {})
        result._subcons = getattr(getattr(type(value), 'WIRE_SCHEMA', None), '_subcons', {})
        return result
    if isinstance(value, list):
        return [_context_value(item) for item in value]
    if isinstance(value, dict):
        return Container({key: _context_value(item) for key, item in value.items()})
    return value


def initialize_fields(message, *, budget=10000, byte_budget=65536, defer_ancestor=False):
    """Resolve automatic arrays and byte payloads after constructor arguments.

    Only missing values are assigned. Explicit values and caller-supplied counts
    are preserved. Structures get parent scopes; array items share scope.
    """
    inherited = _DEFAULT_BUDGET.get()
    token = None
    if inherited is None:
        remaining = [budget]
        remaining_bytes = [byte_budget]
        token = _DEFAULT_BUDGET.set((budget, byte_budget, remaining, remaining_bytes))
    else:
        budget, byte_budget, remaining, remaining_bytes = inherited

    def data(value, spec, context, path):
        if value is not AUTO_ARRAY:
            return value
        try:
            length = evaluate(spec['length'], context)
        except TypeError:
            from .lengths import unresolved_length
            if unresolved_length(context):
                raise DefaultInputRequired(f'{path}: automatic payload allocation depends on an unresolved Length field; supply the payload explicitly') from None
            raise
        except (KeyError, AttributeError):
            if defer_ancestor:
                return value
            raise
        if isinstance(length, EnumIntegerString):
            length = int(length)
        from .lengths import AUTO_LENGTH
        if length is AUTO_LENGTH:
            raise DefaultInputRequired(f'{path}: automatic payload allocation depends on an unresolved Length field; supply the payload explicitly')
        if type(length) is not int or length < 0:
            raise ValueError(f'{path}: initial byte length must be a nonnegative integer')
        if spec.get('text'):
            if length:
                raise DefaultInputRequired(f'{path}: supply text encoding to exactly {length} bytes')
            return ''
        if length > remaining_bytes[0]:
            raise DefaultBudgetExceeded(f'{path}: automatic initialization exceeds {byte_budget} bytes; supply explicit values')
        remaining_bytes[0] -= length
        return bytes(length)

    def array(value, spec, context, path):
        if value is AUTO_ARRAY:
            try:
                count = evaluate(spec["count"], context)
            except TypeError:
                from .lengths import unresolved_length
                if unresolved_length(context):
                    raise DefaultInputRequired(f'{path}: automatic array allocation depends on an unresolved Length field; supply the array explicitly') from None
                raise
            except (KeyError, AttributeError):
                if defer_ancestor:
                    return value
                raise
            if isinstance(count, EnumIntegerString):
                count = int(count)
            from .lengths import AUTO_LENGTH
            if count is AUTO_LENGTH:
                raise DefaultInputRequired(f'{path}: automatic array allocation depends on an unresolved Length field; supply the array explicitly')
            if type(count) is not int or count < 0:
                raise ValueError(f"{path}: initial item count must be a nonnegative integer")
            if count > remaining[0]:
                raise DefaultBudgetExceeded(f"{path}: automatic initialization exceeds {budget} items; supply explicit values")
            remaining[0] -= count
            value = [spec["factory"]() for _ in range(count)]
            if spec.get("sentinel", AUTO_ARRAY) is not AUTO_ARRAY and count:
                value[-1] = spec["sentinel"]
        if isinstance(value, list) and spec.get('derived_target'):
            context[spec['derived_target']] = len(value)
        if isinstance(value, list):
            for index, item in enumerate(value):
                child_context = Container(context)
                child_context._index = index
                value[index] = visit(item, spec.get("item"), child_context, f"{path}[{index}]")
        return value

    def visit(value, spec, parent, path):
        if spec and spec.get('kind') == 'calculated':
            return visit(value, spec.get('item'), parent, path)
        if spec and spec.get('kind') == 'conditional':
            try:
                present = bool(evaluate(spec['condition'], parent))
            except (KeyError, AttributeError):
                if defer_ancestor:
                    return value
                raise
            if value is AUTO_ARRAY:
                if not present:
                    return None
                if spec.get('factory') is None:
                    raise DefaultInputRequired(f'{path}: the present conditional requires a value')
                value = spec['factory']()
            if present and value is None:
                raise DefaultInputRequired(f'{path}: the condition is true but the value is absent')
            if not present and value is not None:
                raise ValueError(f'{path}: the condition is false but a value was supplied')
            return visit(value, spec.get('item'), parent, path) if present else None
        if spec and spec.get('kind') == 'switch':
            try:
                branch = selected_branch(spec, parent)
            except (KeyError, AttributeError):
                if defer_ancestor:
                    return value
                raise
            if branch is None:
                if spec.get('reject'):
                    raise ValueError(f'{path}: unknown switch selector')
                if value is AUTO_ARRAY:
                    if spec.get('requires_fallback'):
                        raise DefaultInputRequired(f'{path}: supply a value for the advanced fallback')
                    return None
                return value
            if isinstance(value, BranchDefault):
                if value.case_uid != branch['uid']:
                    raise ValueError(f'{path}: guided branch does not match the selector')
                value = value.value
            if value is AUTO_ARRAY:
                if branch.get('factory') is None:
                    raise DefaultInputRequired(f'{path}: selected branch requires a value')
                value = branch['factory']()
            return visit(value, branch.get('item'), parent, path)
        if spec and spec.get("kind") == "array":
            return array(value, spec, parent, path)
        if spec and spec.get('kind') == 'data':
            return data(value, spec, parent, path)
        if is_dataclass(value):
            from .conversion import resolved_type_hints
            hints = resolved_type_hints(type(value))
            context = _context_value(value)
            context._ = parent
            context._root = parent.get("_root", context) if parent else context
            from .lengths import initialize_lengths
            initialize_lengths(value, context, defer_ancestor=defer_ancestor, static_only=True)
            specs = getattr(type(value), '_FIELD_INITIALIZERS', getattr(type(value), '_ARRAY_INITIALIZERS', {}))
            definitions = {field.name: field for field in fields(value) if field_options(field)[0]}
            ordered, active, done = [], set(), set()
            def order(name):
                if name in done or name in active or name not in definitions:
                    return
                active.add(name)
                specification = specs.get(name) or {}
                dependencies = set(specification.get('depends', ()))
                source = specification.get('source', '')
                if source and not source.startswith('_.'):
                    dependencies.add(source.split('.')[0])
                for dependency in sorted(dependencies):
                    order(dependency)
                active.remove(name); done.add(name); ordered.append(name)
            for name in definitions:
                order(name)
            def calculate():
                for name in ordered:
                    specification = specs.get(name) or {}
                    if specification.get('kind') != 'calculated':
                        continue
                    try:
                        source = context
                        for part in specification.get('source', '').split('.'):
                            source = source[part]
                        if source is AUTO_ARRAY:
                            continue
                        context[name] = evaluate(specification['calculate'], context)
                    except (KeyError, AttributeError):
                        # A reusable constructor can await its enclosing context.
                        continue
            calculate()
            for name in ordered:
                field = definitions[name]
                initialize_lengths(value, context, defer_ancestor=defer_ancestor, names=(field.name,))
                current = getattr(value, field.name)
                updated = visit(current, specs.get(field.name), context, f"{path}.{field.name}")
                if updated is not current:
                    setattr(value, field.name, updated)
                context[field.name] = _field_context(updated, hints.get(field.name))
                calculate()
            initialize_lengths(value, context, defer_ancestor=defer_ancestor)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                value[index] = visit(item, None, parent, f"{path}[{index}]")
        return value

    try:
        return visit(message, None, Container(), type(message).__name__)
    finally:
        if token is not None:
            _DEFAULT_BUDGET.reset(token)


# Existing generated libraries continue to use this entry point.
initialize_arrays = initialize_fields
