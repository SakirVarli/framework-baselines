"""Scope-level derived lengths, measured before build and verified after parse."""
from contextvars import ContextVar
from functools import lru_cache

from construct import Checksum, Computed, Const, Container, RangeError, Rebuild, SizeofError, Struct, Subconstruct
from construct.core import stream_tell, stream_write


MEASURING_LENGTH = ContextVar('designer_measuring_length', default=False)
AUTO_LENGTH = object()
cached_length_schema = lru_cache(maxsize=1)


def unresolved_length(context):
    seen = set()
    while isinstance(context, dict) and id(context) not in seen:
        seen.add(id(context))
        if any(value is AUTO_LENGTH for value in context.values()):
            return True
        context = context.get('_')
    return False


class _SizeStream:
    """Discard staging bytes while preserving sequential offsets."""
    def __init__(self):
        self.position = 0

    def tell(self):
        return self.position

    def write(self, data):
        self.position += len(data)
        return len(data)


class LengthBound(Subconstruct):
    """Measure supplied payload contents before their derived boundary is known."""
    def __init__(self, subcon, measurement):
        super().__init__(subcon)
        self.measurement = measurement

    def _build(self, obj, stream, context, path):
        codec = self.measurement if MEASURING_LENGTH.get() else self.subcon
        return codec._build(obj, stream, context, path)


class LengthChecksum(Checksum):
    """Checksum storage can be measured without hashing provisional length bytes."""
    def _build(self, obj, stream, context, path):
        if MEASURING_LENGTH.get():
            size = self.checksumfield._sizeof(context, path)
            stream_write(stream, bytes(size), size, path)
            return obj
        return super()._build(obj, stream, context, path)


class LengthStruct(Struct):
    """A Struct with local sibling-span length sources.

    Metadata is indexed by sibling position, so padding has an identity without
    adding a value to parsed dictionaries. Measurement state is per occurrence.
    """
    def __init__(self, *subcons, lengths):
        super().__init__(*subcons)
        self.lengths = lengths

    def _frame(self, context, stream, obj=None):
        frame = Container(_=context, _params=context._params, _root=None,
                          _parsing=context._parsing, _building=context._building,
                          _sizing=context._sizing, _subcons=self._subcons,
                          _io=stream, _index=context.get('_index'))
        frame._root = context.get('_root', frame)
        if obj is not None:
            frame.update(obj)
        return frame

    def _lengths(self, spans, path, specifications=None):
        result = {}
        for name, spec in (self.lengths if specifications is None else specifications).items():
            size = sum(spans[index] for index in spec['indices'])
            if 'start' in spec:
                start, end = spec['start'], spec['end']
                end = size if end is None else end
                if start > size or end > size:
                    raise RangeError(f'{name}: length byte range is outside the containing structure ({size} bytes)', path=path)
                size = end - start
            result[name] = size
        return result

    def _parse(self, stream, context, path):
        frame = self._frame(context, stream)
        obj, spans = Container(), []
        obj._io = stream
        for sc in self.subcons:
            start = stream_tell(stream, path)
            value = sc._parsereport(stream, frame, path)
            spans.append(stream_tell(stream, path) - start)
            if sc.name:
                obj[sc.name] = frame[sc.name] = value
        for name, expected in self._lengths(spans, path).items():
            if obj[name] != expected:
                raise RangeError(f'{name}: received length {obj[name]} does not match calculated byte length {expected}', path=path)
        return obj

    def static_lengths(self, path):
        # No value expressions, checksum calls, or staging allocation for layouts
        # whose individual field sizes are context independent.
        spans = []
        for sc in self.subcons:
            try:
                spans.append(sc.sizeof())
            except (SizeofError, KeyError, AttributeError, TypeError):
                spans.append(None)
        known = {name: spec for name, spec in self.lengths.items()
                 if all(spans[index] is not None for index in spec['indices'])}
        return self._lengths(spans, path, known)

    def resolve(self, obj, context, path, names=None):
        known = self.static_lengths(path)
        requested = set(self.lengths if names is None else names)
        provisional = dict(obj)
        provisional.update({name: 0 for name in self.lengths if provisional.get(name) is AUTO_LENGTH or name not in provisional})
        provisional.update(known)
        # Generation orders lengths by their value/size dependencies. Resolve one
        # source at a time so an independent payload length can control a later
        # branch contributing to another length, without a fixed-point loop.
        for name, spec in self.lengths.items():
            if name not in requested or name in known:
                continue
            staging = _SizeStream()
            frame = self._frame(context, staging, provisional)
            token = MEASURING_LENGTH.set(True)
            spans = []
            try:
                for index, sc in enumerate(self.subcons):
                    # Unselected fields do not contribute. Still evaluate ordinary
                    # calculated values that later selected fields may reference.
                    leaf = sc
                    while isinstance(leaf, Subconstruct) and not isinstance(leaf, (Rebuild, Const)):
                        leaf = leaf.subcon
                    if index not in spec['indices'] and not isinstance(leaf, (Computed, Rebuild, Const)):
                        spans.append(0)
                        continue
                    start = staging.tell()
                    if sc.name in self.lengths:
                        size = sc._sizeof(frame, path)
                        stream_write(staging, bytes(size), size, path)
                        value = provisional[sc.name]
                    else:
                        value = sc._build(provisional.get(sc.name) if sc.flagbuildnone else provisional[sc.name], staging, frame, path)
                    if sc.name:
                        frame[sc.name] = value
                    spans.append(staging.tell() - start)
            finally:
                MEASURING_LENGTH.reset(token)
            known.update(self._lengths(spans, path, {name: spec}))
            provisional.update(known)
        return {name: known[name] for name in requested}

    def _build(self, obj, stream, context, path):
        effective = dict(obj or {})
        resolved = self.resolve(effective, context, path)
        if not MEASURING_LENGTH.get():
            self.verify(effective, resolved, path, 'supplied')
        effective.update(resolved)
        return super()._build(effective, stream, context, path)

    def verify(self, values, resolved, path, phase):
        for name, expected in resolved.items():
            if self.lengths[name].get('verify'):
                if values[name] != expected:
                    raise RangeError(f'{name}: {phase} length {values[name]!r} does not match calculated byte length {expected}', path=path)
                self._subcons[name]._build(values[name], _SizeStream(), Container(), path)

    # Inherited Struct emitters would bypass resolution/verification when compiled.
    def _emitparse(self, code):
        raise NotImplementedError

    def _emitbuild(self, code):
        raise NotImplementedError


def initialize_lengths(value, context, *, defer_ancestor=False, static_only=False, names=None):
    """Called after ordinary defaults have been resolved for this occurrence."""
    factory = getattr(type(value), '_LENGTH_SCHEMA', None)
    if factory is None:
        return
    schema = factory()
    selected = [name for name, spec in schema.lengths.items() if (names is None or name in names)
                and (getattr(value, name) is AUTO_LENGTH or spec.get('verify'))]
    if not selected:
        return
    missing = {name for name in selected if getattr(value, name) is AUTO_LENGTH}
    if static_only:
        for name, size in schema.static_lengths(type(value).__name__).items():
            if name in selected:
                schema.verify({name: getattr(value, name)}, {name: size}, type(value).__name__, 'initialized')
            if name in missing:
                schema._subcons[name]._build(size, _SizeStream(), Container(), name)
                setattr(value, name, size)
                context[name] = size
        return
    from .arrays import _context_value
    wire = _context_value(value)
    for name in schema._subcons:
        if name in context:
            wire[name] = context[name]
    parent = context.get('_') or Container()
    parent = Container(parent)
    parent.setdefault('_params', Container())
    parent.update(dict(_parsing=False, _building=True, _sizing=False))
    try:
        resolved = schema.resolve(wire, parent, type(value).__name__, names=selected)
    except (KeyError, AttributeError):
        if defer_ancestor:
            return
        raise
    schema.verify({name: getattr(value, name) for name in selected}, resolved, type(value).__name__, 'initialized')
    for name in missing:
        schema._subcons[name]._build(resolved[name], _SizeStream(), Container(), name)
        setattr(value, name, resolved[name])
        context[name] = resolved[name]
