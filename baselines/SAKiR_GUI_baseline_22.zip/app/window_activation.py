"""Windows foreground permission handoff between the app and its launcher."""

import os


def allow_foreground_process(pid):
    """Let one process activate its window, if Windows permits the handoff."""
    if os.name != "nt":
        return False
    try:
        pid = int(pid)
        if pid <= 0:
            return False
        import ctypes
        from ctypes import wintypes

        allow = ctypes.windll.user32.AllowSetForegroundWindow
        allow.argtypes = (wintypes.DWORD,)
        allow.restype = wintypes.BOOL
        return bool(allow(pid))
    except (AttributeError, OSError, TypeError, ValueError):
        return False
