"""Owned, versioned messages on the separate parser's ordered channel."""
from __future__ import annotations

from dataclasses import dataclass

FORMAT_VERSION = 2


@dataclass(frozen=True)
class ParsedBatch:
    version: int
    batch_id: int
    epoch: str
    records: tuple[dict, ...]
    control: bool = False
