"""Estimated decoded object sizes for bounded caches and replay."""
import sys


def owned_size(value, seen=None):
    seen = set() if seen is None else seen
    if id(value) in seen:
        return 0
    seen.add(id(value))
    size = sys.getsizeof(value)
    if isinstance(value, dict):
        return size + sum(owned_size(key, seen) + owned_size(item, seen) for key, item in value.items())
    if isinstance(value, (list, tuple, set)):
        return size + sum(owned_size(item, seen) for item in value)
    return size + int(getattr(value, "nbytes", 0))

