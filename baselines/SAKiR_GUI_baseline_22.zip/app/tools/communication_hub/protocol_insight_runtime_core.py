from __future__ import annotations

"""Retention, recovery, and Excel-output runtime for Protocol Insights."""

import copy
import json
import os
import re
import threading
import time
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

try:
    import xlsxwriter  # noqa: F401 - explicit dependency for runtime/build discovery
except ImportError:  # The tool remains usable; Excel actions report the missing optional dependency.
    xlsxwriter = None

from .framing import decode_numeric
from .insight_engine import ProtocolInsightEngine
from .local_time import local_iso, local_now, local_now_iso, now_ns, timestamp_ns
from .protocol_insight_output import (
    append_formatted_protocol_insight_workbook, write_formatted_protocol_insight_workbook,
)
from .query import QueryEngine, get_path, get_path_tokens, serialize_value


PROTOCOL_INSIGHT_RUNTIME_SCHEMA_VERSION = 2


def default_protocol_insight_runtime_core_config() -> dict[str, Any]:
    return {
        "schema_version": PROTOCOL_INSIGHT_RUNTIME_SCHEMA_VERSION,
        "id": str(uuid.uuid4()),
        "name": "New Protocol Insight",
        "enabled": True,
        "runtime": {"paused": False},
        "source": {"query": {}},
        "series": [],
        "sampling": {"emit_final_on_stop": True},
        "retention": {
            "maximum_samples": 100_000,
            "maximum_age_seconds": 0,
            "policy": "drop_oldest",
        },
        "display": {
            "window_seconds": 60.0,
            "maximum_points": 2000,
            "refresh_ms": 1000,
            "live_refresh": True,
            "show_latest_table": True,
            "show_thresholds": True,
            "subplots": [],
            "series": {},
        },
        "checkpoint": {
            "enabled": False,
            "directory": "app/data/communication_hub/protocol_insights/checkpoints",
            "interval_seconds": 30,
            "restore_on_start": True,
            "save_on_stop": True,
        },
        "excel": {
            "enabled": False,
            "directory": "app/data/communication_hub/protocol_insights/output",
            "periodic_enabled": False,
            "period_seconds": 60,
            "periodic_mode": "rotating_snapshot",
            "keep_files": 20,
            "write_final_on_stop": True,
            "include_configuration": True,
            "layout": "wide_aligned",
            "append_path": "",
            "append_conflict": "reject",
            "schema_policy": "strict",
            "backup_before_rewrite": True,
        },
    }


def _merge_config(default: dict, value: dict) -> dict:
    result = copy.deepcopy(default)
    for key, item in value.items():
        if isinstance(item, dict) and isinstance(result.get(key), dict):
            result[key] = _merge_config(result[key], item)
        else:
            result[key] = copy.deepcopy(item)
    return result


def normalize_protocol_insight_runtime_core_config(value: dict | None, *, existing=True) -> dict[str, Any]:
    """Validate the service-process configuration for one Protocol Insight."""
    if not isinstance(value, dict):
        raise TypeError("Protocol Insight runtime configuration must be a JSON object")
    source = copy.deepcopy(value)
    result = _merge_config(default_protocol_insight_runtime_core_config(), source)
    result["schema_version"] = PROTOCOL_INSIGHT_RUNTIME_SCHEMA_VERSION
    result["id"] = str(result.get("id") or uuid.uuid4())
    result["name"] = str(result.get("name") or "Protocol Insight runtime").strip() or "Protocol Insight runtime"
    result["enabled"] = bool(result.get("enabled", True))
    if not isinstance(result.get("runtime"), dict):
        result["runtime"] = {}
    result["runtime"]["paused"] = bool(result["runtime"].get("paused", False))
    if not isinstance(result.get("source"), dict):
        raise ValueError("Protocol Insight runtime source must be an object")
    if not isinstance(result["source"].get("query", {}), dict):
        raise ValueError("Protocol Insight runtime source query must be an object")
    if not isinstance(result.get("series"), list):
        raise ValueError("Protocol Insight runtime series must be a list")
    names = set()
    supported_extractors = {"parsed_field", "raw_bytes", "binary_field", "header_field", "metadata"}
    supported_types = {"bytes", "hex", "text", "uint", "int", "float32", "float64"}
    for index, series in enumerate(result["series"], 1):
        if not isinstance(series, dict):
            raise ValueError(f"Protocol Insight runtime series {index} must be an object")
        name = str(series.get("name") or f"Value {index}").strip()
        if not name:
            raise ValueError(f"Protocol Insight runtime series {index} requires a name")
        if name in names:
            raise ValueError(f"Protocol Insight runtime series name '{name}' is duplicated")
        names.add(name); series["name"] = name
        series["id"] = str(series.get("id") or uuid.uuid5(
            uuid.NAMESPACE_URL, f"communication-hub:protocol-insight:{result['id']}:{name}"
        ))
        series["enabled"] = bool(series.get("enabled", True))
        series["export_enabled"] = bool(series.get("export_enabled", True))
        if not isinstance(series.get("query", {}), dict):
            raise ValueError(f"Protocol Insight runtime series '{name}' query must be an object")
        if not isinstance(series.get("processor", {}), dict):
            raise ValueError(f"Protocol Insight runtime series '{name}' processor must be an object")
        extractor = series.get("extractor")
        if not isinstance(extractor, dict):
            raise ValueError(f"Protocol Insight runtime series '{name}' extractor must be an object")
        kind = str(extractor.get("type", "parsed_field"))
        if kind not in supported_extractors:
            raise ValueError(f"Protocol Insight runtime series '{name}' has unsupported extractor type '{kind}'")
        extractor["type"] = kind
        if kind in {"parsed_field", "binary_field", "header_field"} and not str(extractor.get("path", "")).strip():
            raise ValueError(f"Protocol Insight runtime series '{name}' requires a field path")
        if kind == "metadata" and not str(extractor.get("field", "")).strip():
            raise ValueError(f"Protocol Insight runtime series '{name}' requires a metadata field")
        if kind in {"raw_bytes", "binary_field"}:
            try:
                length = int(extractor.get("length", 1))
            except (TypeError, ValueError) as error:
                raise ValueError(f"Protocol Insight runtime series '{name}' byte length must be an integer") from error
            if length <= 0:
                raise ValueError(f"Protocol Insight runtime series '{name}' byte length must be positive")
            data_type = str(extractor.get("data_type", "bytes"))
            if data_type not in supported_types:
                raise ValueError(f"Protocol Insight runtime series '{name}' has unsupported byte data type '{data_type}'")
            if extractor.get("endianness", "little") not in {"little", "big"}:
                raise ValueError(f"Protocol Insight runtime series '{name}' endianness must be little or big")
        if not isinstance(series.get("thresholds", {}), dict):
            raise ValueError(f"Protocol Insight runtime series '{name}' thresholds must be an object")

    sampling = result["sampling"]
    sampling.clear()
    sampling["emit_final_on_stop"] = bool(
        source.get("sampling", {}).get("emit_final_on_stop", True)
        if isinstance(source.get("sampling"), dict) else True
    )

    retention = result["retention"]
    for key in ("maximum_samples", "maximum_age_seconds"):
        try:
            retention[key] = max(0, int(retention.get(key, 0) or 0))
        except (TypeError, ValueError) as error:
            raise ValueError(f"Protocol Insight runtime retention {key} must be an integer") from error
    if retention.get("policy") not in {"drop_oldest", "drop_newest", "pause"}:
        raise ValueError("Protocol Insight runtime retention policy must be drop_oldest, drop_newest, or pause")

    display = result["display"]
    try:
        display["window_seconds"] = max(0.0, float(display.get("window_seconds", 60.0)))
        display["maximum_points"] = max(100, min(250_000, int(display.get("maximum_points", 2000))))
        display["refresh_ms"] = max(200, min(60_000, int(display.get("refresh_ms", 1000))))
    except (TypeError, ValueError) as error:
        raise ValueError("Protocol Insight runtime display window, point limit, and refresh must be numeric") from error
    display["live_refresh"] = bool(display.get("live_refresh", True))
    display["show_latest_table"] = bool(display.get("show_latest_table", True))
    display["show_thresholds"] = bool(display.get("show_thresholds", True))
    if not isinstance(display.get("series"), dict):
        raise ValueError("Protocol Insight runtime display series settings must be an object")
    raw_subplots = display.get("subplots", [])
    if not isinstance(raw_subplots, list):
        raise ValueError("Protocol Insight runtime display subplots must be a list")
    subplots = []
    subplot_ids = set()
    subplot_by_title = {}

    def add_subplot(title, unit="", requested_id=""):
        title = str(title or "Subplot").strip() or "Subplot"
        base = str(requested_id or "").strip()
        if not base:
            slug = re.sub(r"[^A-Za-z0-9_.-]+", "-", title).strip("-").lower() or "subplot"
            base = f"subplot-{slug}"
        subplot_id = base
        suffix = 2
        while subplot_id in subplot_ids:
            subplot_id = f"{base}-{suffix}"; suffix += 1
        subplot = {"id": subplot_id, "title": title, "unit": str(unit or "").strip()}
        subplot_ids.add(subplot_id); subplot_by_title.setdefault(title, subplot_id)
        subplots.append(subplot)
        return subplot_id

    for index, subplot in enumerate(raw_subplots, 1):
        if not isinstance(subplot, dict):
            raise ValueError(f"Protocol Insight runtime display subplot {index} must be an object")
        add_subplot(
            subplot.get("title") or f"Subplot {index}",
            subplot.get("unit", ""), subplot.get("id", ""),
        )

    series_settings = display["series"]
    for series_name, options in series_settings.items():
        if not isinstance(options, dict):
            raise ValueError(f"Display settings for '{series_name}' must be an object")
        if options.get("style", "line") not in {"line", "scatter", "step", "state", "hidden"}:
            raise ValueError(f"Display style for '{series_name}' is unsupported")
        fallback_title = str(options.get("subplot") or series_name).strip() or str(series_name)
        subplot_id = str(options.get("subplot_id") or "").strip()
        if subplot_id not in subplot_ids:
            subplot_id = subplot_by_title.get(fallback_title) or add_subplot(fallback_title)
        options["subplot_id"] = subplot_id
        options["subplot"] = next(
            item["title"] for item in subplots if item["id"] == subplot_id
        )
        options["color"] = str(options.get("color") or "")
    for series in result.get("series", []):
        name = str(series.get("name", "")).strip()
        if not name or name in series_settings:
            continue
        subplot_id = subplot_by_title.get(name) or add_subplot(name)
        series_settings[name] = {
            "subplot_id": subplot_id, "subplot": name,
            "style": "line", "color": "",
        }
    display["subplots"] = subplots

    checkpoint = result["checkpoint"]
    try:
        checkpoint["interval_seconds"] = max(1, int(checkpoint.get("interval_seconds", 30) or 30))
    except (TypeError, ValueError) as error:
        raise ValueError("Protocol Insight runtime checkpoint interval must be an integer") from error
    if checkpoint.get("enabled") and not str(checkpoint.get("directory", "")).strip():
        raise ValueError("Enabled Protocol Insight runtime checkpoint requires a directory")
    # A checkpoint is the durable continuation of the insight dataset.  Older
    # configurations exposed a separate restore switch, which made it possible
    # to collect checkpoints that were silently ignored after a crash.
    checkpoint["restore_on_start"] = bool(checkpoint.get("enabled"))

    excel = result["excel"]
    # Periodic workbook writes were intentionally retired.  Keep accepting the
    # legacy fields so existing configurations load, but never schedule them.
    excel["periodic_enabled"] = False
    excel["write_final_on_stop"] = True
    if excel.get("periodic_mode") == "replace_latest":
        excel["periodic_mode"] = "rotating_snapshot"
    if excel.get("periodic_mode") not in {"rotating_snapshot", "replace_latest", "append_formatted"}:
        raise ValueError("Protocol Insight runtime Excel mode is unsupported")
    if excel.get("layout") != "wide_aligned":
        raise ValueError("Protocol Insight runtime Excel output supports aligned timeline only")
    if excel.get("append_conflict") not in {"reject", "skip", "replace", "keep_both"}:
        raise ValueError("Protocol Insight runtime append conflict policy is unsupported")
    if excel.get("schema_policy") not in {"strict", "compatible", "extend"}:
        raise ValueError("Protocol Insight runtime append schema policy is unsupported")
    if (
        excel.get("enabled")
        and excel.get("periodic_mode") == "append_formatted"
        and not str(excel.get("append_path", "")).strip()
    ):
        raise ValueError("Append formatted workbook mode requires an append workbook path")
    return result


def _decode_extracted_bytes(value: Any, extractor: dict) -> Any:
    if isinstance(value, dict) and set(value) == {"$bytes_hex"}:
        try:
            value = bytes.fromhex(str(value["$bytes_hex"]))
        except ValueError:
            return None
    if not isinstance(value, (bytes, bytearray, memoryview)):
        return None
    raw_data = bytes(value)
    offset = int(extractor.get("offset", 0))
    length = int(extractor.get("length", 1))
    if offset < 0:
        offset = len(raw_data) + offset
    raw = raw_data[offset : offset + length]
    if len(raw) != length:
        return None
    data_type = extractor.get("data_type", "bytes")
    if data_type == "bytes":
        decoded: Any = raw
    elif data_type == "hex":
        decoded = raw.hex()
    elif data_type == "text":
        decoded = raw.decode(extractor.get("encoding", "utf-8"), errors=extractor.get("errors", "replace"))
    else:
        decoded = decode_numeric(
            raw, data_type, extractor.get("endianness", "little"),
            bool(extractor.get("signed", False)),
        )
    if isinstance(decoded, (int, float)):
        decoded = (
            decoded * float(extractor.get("scale", 1.0))
            + float(extractor.get("offset_value", 0.0))
        )
    return decoded


def extract_value(data: Any, extractor: dict, record: dict | None = None) -> Any:
    kind = extractor.get("type", "parsed_field")
    if kind == "parsed_field":
        tokens = extractor.get("path_tokens")
        if isinstance(tokens, list):
            return get_path_tokens(data, tokens, None)
        path = str(extractor.get("path", ""))
        if path.startswith("data."): path = path[len("data."):]
        return get_path(data, path, None)
    if kind == "binary_field":
        tokens = extractor.get("path_tokens")
        if isinstance(tokens, list):
            return _decode_extracted_bytes(get_path_tokens(data, tokens, None), extractor)
        path = str(extractor.get("path", ""))
        if path.startswith("data."): path = path[len("data."):]
        return _decode_extracted_bytes(get_path(data, path, None), extractor)
    if kind == "header_field":
        source = (record or {}).get("header_fields", {})
        tokens = extractor.get("path_tokens")
        if isinstance(tokens, list):
            return get_path_tokens(source, tokens, None)
        path = str(extractor.get("path", ""))
        if path.startswith("header_fields."): path = path[len("header_fields."):]
        return get_path(source, path, None)
    if kind == "metadata":
        return (record or {}).get(str(extractor.get("field", "")))
    return _decode_extracted_bytes(data, extractor)


class ProtocolInsightRuntimeCore:
    def __init__(self, config: dict, project_root: str | Path):
        self.config = normalize_protocol_insight_runtime_core_config(config, existing=True)
        self._insights_x_axis = copy.deepcopy(
            self.config.get("insights", {}).get("x_axis", {})
            if isinstance(self.config.get("insights"), dict) else {}
        )
        self._insights_source = copy.deepcopy(
            self.config.get("insights", {}).get("source", {})
            if isinstance(self.config.get("insights"), dict) else {}
        )
        self._protocol_collection = copy.deepcopy(
            self._insights_source.get("collection", {})
            if self._insights_source else {}
        )
        self._protocol_series: dict[str, dict[str, Any]] = {}
        self.project_root = Path(project_root)
        self.query_engine = QueryEngine()
        engine_series = []
        for series in self.config.get("series", []):
            extractor = copy.deepcopy(series.get("extractor", {}))
            extractor_type = extractor.get("type", "parsed_field")
            transform = {"scale": 1.0, "offset": 0.0}
            if extractor_type not in {"raw_bytes", "binary_field"}:
                transform = {
                    "scale": float(extractor.get("scale", 1.0)),
                    "offset": float(extractor.get("offset_value", 0.0)),
                }
            engine_series.append({
                "id": str(series.get("id", "")),
                "label": str(series.get("name", "Value")),
                "enabled": bool(series.get("enabled", True)),
                "source": extractor,
                "transform": transform,
                "processor": copy.deepcopy(series.get("processor", {})),
                "thresholds": copy.deepcopy(series.get("thresholds", {})),
                "query": copy.deepcopy(series.get("query", {})),
            })
            self._protocol_series[str(series.get("id", ""))] = {
                "id": str(series.get("id", "")),
                "name": str(series.get("name", "Value")),
                "stream_identity": copy.deepcopy(series.get("stream_identity", {})),
                "collection": copy.deepcopy(series.get("collection", {})),
            }
        self.insight_engine = ProtocolInsightEngine(
            engine_id=str(self.config.get("id", "")),
            series=engine_series,
            value_reader=self._engine_value_reader,
            x_axis=self._insights_x_axis or {"kind": "timestamp"},
            source_query=self.config.get("source", {}).get("query", {}),
        )
        self.samples: list[dict[str, Any]] = []
        # Kept parallel to ``samples`` so transport cursors never leak into
        # checkpoints or exported workbooks as user-visible columns.
        self._sample_versions: list[int] = []
        self.events: list[dict[str, Any]] = []
        self._event_versions: list[int] = []
        insight_options = self.config.get("insights", {})
        self._retain_events = bool(
            insight_options.get("event_markers")
            or insight_options.get("insight_only_subplots")
        ) if isinstance(insight_options, dict) else False
        self.started = local_now()
        self.last_export_monotonic = time.monotonic()
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="protocol_insight_runtime-excel")
        self._future: Future | None = None
        self._closing = False
        self._closed = False
        self._lock = threading.RLock()
        self.last_error = ""
        self.error_count = 0
        self.dropped_samples = 0
        self.sample_version = 0
        self.event_version = 0
        self.dropped_events = 0
        self.paused = bool(self.config.get("runtime", {}).get("paused", False))
        self._protocol_last_collection_tick = time.monotonic()
        self._protocol_pending: list[tuple] = []
        self._protocol_last_values: dict[tuple, Any] = {}
        self._protocol_candidate_drops = 0
        self._paused_by_backpressure = False
        self._last_checkpoint = time.monotonic()
        self._paused_by_retention = False
        self._append_export_cursor = 0
        self.checkpoint_restored = False
        checkpoint = self.config["checkpoint"]
        if checkpoint.get("enabled"):
            self.checkpoint_restored = self._restore_checkpoint()

    @staticmethod
    def _protocol_identity_value(record: dict, field: str, missing: Any) -> Any:
        if field.startswith("data."):
            return get_path(record.get("data"), field[5:], missing)
        return get_path(record, field, missing)

    def _protocol_stream_key(self, record: dict, series_id: str) -> tuple | None:
        series = self._protocol_series.get(series_id, {})
        identity = series.get("stream_identity", {})
        mode = str(identity.get("mode", "automatic"))
        if mode == "combined":
            return (series_id,)
        automatic_fields = ["session_id", "connection_id", "direction", "name"]
        fields = list(automatic_fields)
        if mode == "custom":
            fields.extend(str(item) for item in identity.get("additional_fields", []) if str(item))
        missing = object()
        values = []
        for field in fields:
            value = self._protocol_identity_value(record, field, missing)
            if value is missing:
                if field in automatic_fields:
                    value = ""
                    values.append(serialize_value(value))
                    continue
                policy = str(identity.get("missing_field_policy", "reject"))
                if policy == "reject":
                    return None
                value = (
                    identity.get("fallback_value", "")
                    if policy == "fallback" else "<missing>"
                )
            values.append(serialize_value(value))
        return (series_id, *values)

    def _protocol_policy(self, series_id: str) -> str:
        mode = str(self._protocol_collection.get("mode", "on_arrival"))
        policy = str(
            self._protocol_series.get(series_id, {}).get("collection", {}).get(
                "policy", "inherit"
            )
        )
        if policy == "inherit":
            policy = str(self._protocol_collection.get("default_policy", "all"))
        valid = (
            {"all", "first", "last", "changed", "last_changed"}
            if mode == "scheduled" else {"all", "changed"}
        )
        return policy if policy in valid else "all"

    def _protocol_point(self, insight_sample, series_id: str, value: Any, stream_key: tuple) -> dict:
        label = str(insight_sample.labels.get(series_id, series_id))
        status = str(insight_sample.statuses.get(series_id, ""))
        point = {
            "sample_time": insight_sample.sample_time,
            "sample_time_ns": insight_sample.sample_time_ns,
            "event_id": insight_sample.event_id,
            "session_id": insight_sample.session_id,
            "protocol": insight_sample.protocol,
            "direction": insight_sample.direction,
            "message": insight_sample.message,
            "connection_id": insight_sample.connection_id,
            "peer": insight_sample.peer,
            "__series_values": {series_id: copy.deepcopy(value)},
            "__series_id": series_id,
            "__stream_key": copy.deepcopy(stream_key),
            "__insights_x": insight_sample.x,
            label: copy.deepcopy(value),
        }
        if status:
            point[f"{label}__status"] = status
        if self.config.get("threshold_details", False):
            point[f"{label}__missing"] = value is None
            point[f"{label}__above_max"] = status == "above_max"
            point[f"{label}__below_min"] = status == "below_min"
        return point

    @staticmethod
    def _protocol_value_changed(previous: Any, value: Any) -> bool:
        return serialize_value(previous) != serialize_value(value)

    def _emit_protocol_candidate(self, key: tuple, point: dict, value: Any) -> dict | None:
        if self._append_sample(point):
            self._protocol_last_values[key] = copy.deepcopy(value)
            return point
        return None

    def _queue_protocol_candidate(self, candidate: tuple) -> bool:
        maximum = int(self._protocol_collection.get("maximum_candidates_per_cycle", 10_000))
        if len(self._protocol_pending) >= maximum:
            policy = str(self._protocol_collection.get("overflow_policy", "drop_oldest"))
            self._protocol_candidate_drops += 1
            if policy == "drop_newest":
                return False
            if policy == "pause":
                self._paused_by_backpressure = True
                return False
            del self._protocol_pending[0]
        self._protocol_pending.append(candidate)
        return True

    def _consume_protocol_insight_record(self, record: dict[str, Any], *, source_matched=False) -> dict[str, Any] | None:
        insight_sample = (self.insight_engine.process_record(record, source_matched=True) if source_matched
                          else self.insight_engine.process_record(record))
        if insight_sample is None:
            return None
        emitted = None
        mode = str(self._protocol_collection.get("mode", "on_arrival"))
        for series_id in insight_sample.matched_series:
            value = insight_sample.values.get(series_id)
            if value is None:
                continue
            key = self._protocol_stream_key(record, series_id)
            if key is None:
                continue
            point = self._protocol_point(insight_sample, series_id, value, key)
            policy = self._protocol_policy(series_id)
            if mode == "scheduled":
                self._queue_protocol_candidate((key, policy, point, copy.deepcopy(value)))
                continue
            previous = self._protocol_last_values.get(key, object())
            if policy == "changed" and not self._protocol_value_changed(previous, value):
                continue
            emitted = self._emit_protocol_candidate(key, point, value) or emitted
        return emitted

    def _flush_protocol_candidates(self) -> list[dict[str, Any]]:
        pending = self._protocol_pending
        self._protocol_pending = []
        if not pending:
            return []
        grouped: dict[tuple, list[tuple]] = {}
        for candidate in pending:
            grouped.setdefault(candidate[0], []).append(candidate)
        emitted = []
        for key, candidates in grouped.items():
            policy = candidates[-1][1]
            if policy == "first":
                selected = candidates[:1]
            elif policy in {"last", "last_changed"}:
                selected = candidates[-1:]
            else:
                selected = candidates
            for _key, _policy, point, value in selected:
                previous = self._protocol_last_values.get(key, object())
                if policy in {"changed", "last_changed"} and not self._protocol_value_changed(previous, value):
                    continue
                appended = self._emit_protocol_candidate(key, point, value)
                if appended is not None:
                    emitted.append(appended)
        return emitted

    @staticmethod
    def _engine_value_reader(record: dict, source: dict):
        extractor = copy.deepcopy(source)
        extractor["type"] = extractor.get("type", extractor.get("kind", "parsed_field"))
        return extract_value(record.get("data"), extractor, record)

    @staticmethod
    def _sample_time_ns(sample):
        try:
            return timestamp_ns(sample.get(
                "sample_time_ns", sample.get("timestamp_ns", sample.get("sample_time", sample.get("timestamp")))
            ))
        except (TypeError, ValueError, OverflowError):
            return None

    def _append_sample(self, sample: dict) -> bool:
        retention = self.config["retention"]
        maximum = int(retention.get("maximum_samples", 0) or 0)
        policy = retention.get("policy", "drop_oldest")
        with self._lock:
            if maximum and len(self.samples) >= maximum:
                if policy == "drop_newest":
                    self.dropped_samples += 1
                    return False
                if policy == "pause":
                    self._paused_by_retention = True
                    self.dropped_samples += 1
                    return False
                overflow = len(self.samples) - maximum + 1
                del self.samples[:overflow]
                del self._sample_versions[:overflow]
                self._append_export_cursor = max(0, self._append_export_cursor - overflow)
                self.dropped_samples += overflow
            self.sample_version += 1
            self.samples.append(sample)
            self._sample_versions.append(self.sample_version)
            maximum_age = int(retention.get("maximum_age_seconds", 0) or 0)
            if maximum_age:
                cutoff_ns = now_ns() - maximum_age * 1_000_000_000
                remove = 0
                for existing in self.samples:
                    value_ns = self._sample_time_ns(existing)
                    if value_ns is None:
                        break
                    if value_ns >= cutoff_ns:
                        break
                    remove += 1
                if remove:
                    del self.samples[:remove]
                    del self._sample_versions[:remove]
                    self._append_export_cursor = max(0, self._append_export_cursor - remove)
                    self.dropped_samples += remove
        return True

    def _append_event(self, record: dict[str, Any]) -> bool:
        """Retain one complete eligible record for event/timeline visualization."""
        if not self._retain_events:
            return False
        retention = self.config["retention"]
        maximum = int(retention.get("maximum_samples", 0) or 0)
        policy = retention.get("policy", "drop_oldest")
        with self._lock:
            if maximum and len(self.events) >= maximum:
                if policy == "drop_newest":
                    self.dropped_events += 1
                    return False
                if policy == "pause":
                    self._paused_by_retention = True
                    self.dropped_events += 1
                    return False
                overflow = len(self.events) - maximum + 1
                del self.events[:overflow]
                del self._event_versions[:overflow]
                self.dropped_events += overflow
            self.event_version += 1
            self.events.append(copy.deepcopy(record))
            self._event_versions.append(self.event_version)
            maximum_age = int(retention.get("maximum_age_seconds", 0) or 0)
            if maximum_age:
                cutoff_ns = now_ns() - maximum_age * 1_000_000_000
                remove = 0
                for existing in self.events:
                    value_ns = self._sample_time_ns(existing)
                    if value_ns is None:
                        break
                    if value_ns >= cutoff_ns:
                        break
                    remove += 1
                if remove:
                    del self.events[:remove]
                    del self._event_versions[:remove]
                    self.dropped_events += remove
        return True

    def consume(self, record: dict[str, Any], *, source_matched=False) -> dict[str, Any] | None:
        if not self.config.get("enabled", True) or self.paused or self._paused_by_retention or self._paused_by_backpressure:
            return None
        if not source_matched and not self.query_engine.matches_record(record, self.config.get("source", {}).get("query")):
            return None
        self._append_event(record)
        return (self._consume_protocol_insight_record(record, source_matched=True) if source_matched
                else self._consume_protocol_insight_record(record))

    def tick(self):
        if self._closing or self._closed:
            return []
        emitted = []
        now_monotonic = time.monotonic()
        if (
            not self.paused
            and self.config.get("enabled", True)
            and self._protocol_collection.get("mode") == "scheduled"
            and now_monotonic - self._protocol_last_collection_tick
            >= float(self._protocol_collection.get("interval_seconds", 1.0))
        ):
            self._protocol_last_collection_tick = now_monotonic
            emitted.extend(self._flush_protocol_candidates())
        checkpoint = self.config["checkpoint"]
        if (
            checkpoint.get("enabled")
            and now_monotonic - self._last_checkpoint
            >= int(checkpoint.get("interval_seconds", 30))
        ):
            self._last_checkpoint = now_monotonic
            self._write_checkpoint()

        return emitted

    def request_export(self, final: bool = False) -> bool:
        if self._closing or self._closed:
            return False
        if not final:
            return False
        excel = self.config.get("excel", {})
        if not excel.get("enabled"):
            return False
        with self._lock:
            append_mode = excel.get("periodic_mode") == "append_formatted"
            start = min(self._append_export_cursor, len(self.samples)) if append_mode else 0
            snapshot = copy.deepcopy(self.samples[start:])
            batch_end = len(self.samples)
        if not snapshot:
            return False
        if self._future and not self._future.done():
            return False
        self._future = self._executor.submit(self._write_excel, snapshot, final)
        self._future._protocol_insight_runtime_append_end = batch_end if append_mode else None
        self._future.add_done_callback(self._export_complete)
        return True

    def export_and_wait(self, final: bool = True) -> dict:
        """Write an explicit workbook and return only after it is durable."""
        if not final:
            raise ValueError("Only final Protocol Insight workbooks are supported")
        if self._closing or self._closed:
            raise RuntimeError("Protocol Insight is stopping")
        excel = self.config.get("excel", {})
        if not excel.get("enabled"):
            raise RuntimeError("Enable Excel output before creating a final workbook")
        pending = self._future
        if pending and not pending.done():
            pending.result()
        with self._lock:
            append_mode = excel.get("periodic_mode") == "append_formatted"
            start = min(self._append_export_cursor, len(self.samples)) if append_mode else 0
            snapshot = copy.deepcopy(self.samples[start:])
            batch_end = len(self.samples)
        if not snapshot:
            raise RuntimeError("No retained Protocol Insight samples are available to export")
        path = self._write_excel(snapshot, final=final)
        if append_mode:
            self._append_export_cursor = max(self._append_export_cursor, batch_end)
        self.last_export_monotonic = time.monotonic()
        return {"path": str(path), "samples": len(snapshot), "final": bool(final)}

    def _export_complete(self, future: Future):
        try:
            future.result()
        except BaseException as error:
            self.last_error = f"{type(error).__name__}: {error}"
            self.error_count += 1
        else:
            append_end = getattr(future, "_protocol_insight_runtime_append_end", None)
            if append_end is not None:
                self._append_export_cursor = max(self._append_export_cursor, int(append_end))

    def _checkpoint_path(self) -> Path:
        configured = Path(self.config["checkpoint"]["directory"])
        directory = configured if configured.is_absolute() else self.project_root / configured
        return directory / f"{self.config['id']}{self._session_file_suffix()}.pkl"

    def checkpoint_info(self, *, inspect_state: bool = True) -> dict[str, Any]:
        """Describe the durable checkpoint without changing runtime state."""
        path = self._checkpoint_path()
        result: dict[str, Any] = {
            "available": path.is_file(), "path": str(path),
            "saved_at": "", "saved_at_ns": 0, "modified_at": "",
            "created_at": "", "samples": 0, "events": 0,
        }
        if not path.is_file():
            return result
        stat = path.stat()
        result["modified_at"] = datetime.fromtimestamp(
            stat.st_mtime
        ).astimezone().isoformat(timespec="seconds")
        result["created_at"] = datetime.fromtimestamp(
            stat.st_ctime
        ).astimezone().isoformat(timespec="seconds")
        if inspect_state:
            state = self._read_checkpoint_state()
            result.update({
                "saved_at": str(state.get("saved_at", "")),
                "saved_at_ns": int(state.get("saved_at_ns", 0) or 0),
                "samples": len(state.get("samples", []))
                if isinstance(state.get("samples", []), list) else 0,
                "events": len(state.get("events", []))
                if isinstance(state.get("events", []), list) else 0,
            })
        return result

    def _read_checkpoint_state(self) -> dict[str, Any]:
        path = self._checkpoint_path()
        if not path.is_file():
            raise FileNotFoundError(f"No checkpoint is available for '{self.config['name']}'")
        state = pd.read_pickle(path)
        checkpoint_id = (
            state.get("protocol_insight_runtime_id")
            if isinstance(state, dict) else None
        )
        if not isinstance(state, dict) or str(checkpoint_id) != self.config["id"]:
            raise ValueError(
                "Protocol Insight checkpoint does not match selected insight "
                f"'{self.config['id']}'"
            )
        if not isinstance(state.get("samples", []), list):
            raise ValueError("Protocol Insight checkpoint samples must be a list")
        if not isinstance(state.get("events", []), list):
            raise ValueError("Protocol Insight checkpoint events must be a list")
        return state

    def _session_file_suffix(self) -> str:
        context = self.config.get("runtime_context", {})
        session_id = str(context.get("session_id", "")).strip() if isinstance(context, dict) else ""
        if not session_id:
            return ""
        safe_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", session_id).strip("_") or "session"
        return f"__{safe_id}"

    def _write_checkpoint(self) -> Path | None:
        checkpoint = self.config["checkpoint"]
        if not checkpoint.get("enabled"):
            return None
        path = self._checkpoint_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".tmp.pkl")
        with self._lock:
            state = {
                "schema_version": PROTOCOL_INSIGHT_RUNTIME_SCHEMA_VERSION,
                "protocol_insight_runtime_id": self.config["id"],
                "samples": copy.deepcopy(self.samples),
                "events": copy.deepcopy(self.events),
                "protocol_last_values": copy.deepcopy(self._protocol_last_values),
                "protocol_pending": copy.deepcopy(self._protocol_pending),
                "protocol_candidate_drops": self._protocol_candidate_drops,
                "append_export_cursor": self._append_export_cursor,
                "dropped_samples": self.dropped_samples,
                "sample_version": self.sample_version,
                "event_version": self.event_version,
                "dropped_events": self.dropped_events,
                "saved_at_ns": now_ns(),
                "saved_at": local_now_iso(),
            }
        pd.to_pickle(state, temporary)
        os.replace(temporary, path)
        return path

    def _restore_checkpoint(self) -> bool:
        path = self._checkpoint_path()
        if not path.is_file():
            return False
        state = self._read_checkpoint_state()
        samples = state.get("samples", [])
        self.samples = copy.deepcopy(samples)
        for sample in self.samples:
            self._normalize_recovered_time(sample, "sample_time")
        events = state.get("events", [])
        self.events = copy.deepcopy(events) if self._retain_events else []
        for event in self.events:
            self._normalize_recovered_time(event, "timestamp")
            self._normalize_recovered_time(event, "first_timestamp")
        self._protocol_last_values = copy.deepcopy(state.get("protocol_last_values", {}))
        self._protocol_pending = copy.deepcopy(state.get("protocol_pending", []))
        self._protocol_candidate_drops = int(state.get("protocol_candidate_drops", 0) or 0)
        self._append_export_cursor = max(
            0, min(len(self.samples), int(state.get("append_export_cursor", 0) or 0))
        )
        self.dropped_samples = int(state.get("dropped_samples", 0) or 0)
        self.sample_version = max(
            len(self.samples), int(state.get("sample_version", len(self.samples)) or 0)
        )
        first_version = max(1, self.sample_version - len(self.samples) + 1)
        self._sample_versions = list(range(first_version, self.sample_version + 1))
        self.dropped_events = int(state.get("dropped_events", 0) or 0)
        self.event_version = max(
            len(self.events), int(state.get("event_version", len(self.events)) or 0)
        )
        first_event_version = max(1, self.event_version - len(self.events) + 1)
        self._event_versions = list(
            range(first_event_version, self.event_version + 1)
        )
        self._apply_retention_after_restore()
        return True

    @staticmethod
    def _normalize_recovered_time(record, field):
        """Upgrade recovered wall-clock values to the shared local-time contract."""
        if not isinstance(record, dict):
            return
        ns_field = f"{field}_ns"
        source = record.get(ns_field, record.get(field))
        if source in {None, ""}:
            return
        try:
            value_ns = timestamp_ns(source)
        except (TypeError, ValueError, OverflowError, OSError):
            return
        record[ns_field] = value_ns
        record[field] = local_iso(value_ns)

    def _apply_retention_after_restore(self):
        retention = self.config["retention"]
        maximum = int(retention.get("maximum_samples", 0) or 0)
        if maximum and len(self.samples) > maximum:
            dropped = len(self.samples) - maximum
            if retention.get("policy") == "drop_newest":
                del self.samples[maximum:]
                del self._sample_versions[maximum:]
                self._append_export_cursor = min(self._append_export_cursor, len(self.samples))
            else:
                del self.samples[:dropped]
                del self._sample_versions[:dropped]
                self._append_export_cursor = max(0, self._append_export_cursor - dropped)
            self.dropped_samples += dropped
        maximum_age = int(retention.get("maximum_age_seconds", 0) or 0)
        if maximum_age:
            cutoff_ns = now_ns() - maximum_age * 1_000_000_000
            retained = []
            retained_versions = []
            for version, sample in zip(self._sample_versions, self.samples):
                value_ns = self._sample_time_ns(sample)
                if value_ns is None:
                    retained.append(sample)
                    retained_versions.append(version)
                    continue
                if value_ns >= cutoff_ns:
                    retained.append(sample)
                    retained_versions.append(version)
            self.dropped_samples += len(self.samples) - len(retained)
            removed = len(self.samples) - len(retained)
            self._append_export_cursor = max(0, self._append_export_cursor - removed)
            self.samples = retained
            self._sample_versions = retained_versions
        if maximum and len(self.events) > maximum:
            dropped = len(self.events) - maximum
            if retention.get("policy") == "drop_newest":
                del self.events[maximum:]
                del self._event_versions[maximum:]
            else:
                del self.events[:dropped]
                del self._event_versions[:dropped]
            self.dropped_events += dropped
        if maximum_age and self.events:
            retained_events = []
            retained_event_versions = []
            for version, event in zip(self._event_versions, self.events):
                value_ns = self._sample_time_ns(event)
                if value_ns is None:
                    retained_events.append(event)
                    retained_event_versions.append(version)
                    continue
                if value_ns >= cutoff_ns:
                    retained_events.append(event)
                    retained_event_versions.append(version)
            self.dropped_events += len(self.events) - len(retained_events)
            self.events = retained_events
            self._event_versions = retained_event_versions

    def metrics(self) -> dict:
        with self._lock:
            samples = len(self.samples)
            events = len(self.events)
        future_running = bool(self._future and not self._future.done())
        return {
            "id": self.config["id"],
            "name": self.config["name"],
            "enabled": bool(self.config.get("enabled", True)),
            "paused": bool(self.paused),
            "samples": samples,
            "sample_version": int(self.sample_version),
            "events": events,
            "event_version": int(self.event_version),
            "dropped_events": self.dropped_events,
            "dropped_samples": self.dropped_samples,
            "paused_by_retention": self._paused_by_retention,
            "collection_mode": self._protocol_collection.get("mode", "on_arrival"),
            "pending_candidates": len(self._protocol_pending),
            "dropped_candidates": self._protocol_candidate_drops,
            "paused_by_backpressure": self._paused_by_backpressure,
            "export_running": future_running,
            "checkpoint_restored": bool(self.checkpoint_restored),
            "checkpoint": self.checkpoint_info(inspect_state=False),
            "last_error": self.last_error,
            "error_count": self.error_count,
        }

    def pause(self) -> dict:
        """Pause collection while retaining the unified insight dataset."""
        self.paused = True
        self.config.setdefault("runtime", {})["paused"] = True
        checkpoint = self.config.get("checkpoint", {})
        if checkpoint.get("enabled"):
            try:
                self._write_checkpoint()
            except BaseException as error:
                self.last_error = f"{type(error).__name__}: {error}"
                self.error_count += 1
        return self.metrics()

    def resume(self) -> dict:
        """Resume collection without rebuilding the insight runtime."""
        self.config["enabled"] = True
        self.paused = False
        self._paused_by_backpressure = False
        self.config.setdefault("runtime", {})["paused"] = False
        self._protocol_last_collection_tick = time.monotonic()
        return self.metrics()

    def _output_directory(self) -> Path:
        configured = Path(self.config.get("excel", {}).get("directory", "app/data/communication_hub/protocol_insights/output"))
        return configured if configured.is_absolute() else self.project_root / configured

    def _write_excel(self, samples: list[dict[str, Any]], final: bool) -> Path:
        if xlsxwriter is None:
            raise RuntimeError("Excel export requires the XlsxWriter package")
        directory = self._output_directory()
        directory.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(self.config.get("name", "protocol_insight_runtime"))).strip("_") or "protocol_insight_runtime"
        safe_name += self._session_file_suffix()
        now = local_now().strftime("%Y%m%d_%H%M%S")
        excel = self.config.get("excel", {})
        export_config, export_samples = self._excel_projection(samples)
        if excel.get("periodic_mode") == "append_formatted":
            configured = str(excel.get("append_path", "")).strip()
            if not configured:
                raise ValueError("Append formatted workbook mode requires append_path")
            path = Path(configured)
            if not path.is_absolute():
                path = self.project_root / path
            append_formatted_protocol_insight_workbook(path, export_config, export_samples)
            return path
        if final:
            filename = f"{safe_name}_{now}_final.xlsx"
        elif excel.get("periodic_mode") == "replace_latest":
            filename = f"{safe_name}_latest.xlsx"
        else:
            filename = f"{safe_name}_{now}.xlsx"
        path = directory / filename
        write_formatted_protocol_insight_workbook(path, export_config, export_samples)
        self._rotate_files(directory, safe_name)
        return path

    def _excel_projection(self, samples: list[dict[str, Any]]) -> tuple[dict, list[dict]]:
        """Project the unified retained dataset onto the Excel-selected series."""
        config = copy.deepcopy(self.config)
        all_series = list(config.get("series", []))
        selected = [item for item in all_series if item.get("export_enabled", True)]
        config["series"] = selected
        selected_names = {str(item.get("name", "")) for item in selected}
        all_names = {str(item.get("name", "")) for item in all_series}
        projected = []
        for sample in samples:
            row = {
                key: copy.deepcopy(value)
                for key, value in sample.items()
                if key not in all_names or key in selected_names
            }
            series_values = row.get("__series_values")
            if isinstance(series_values, dict):
                selected_ids = {str(item.get("id", "")) for item in selected}
                row["__series_values"] = {
                    key: copy.deepcopy(value)
                    for key, value in series_values.items()
                    if str(key) in selected_ids
                }
            projected.append(row)
        display = config.get("display", {})
        if isinstance(display, dict) and isinstance(display.get("series"), dict):
            display["series"] = {
                name: options for name, options in display["series"].items()
                if name in selected_names
            }
        return config, projected

    def _rotate_files(self, directory: Path, safe_name: str):
        keep = int(self.config.get("excel", {}).get("keep_files", 20) or 0)
        if keep <= 0:
            return
        files = sorted(directory.glob(f"{safe_name}_*.xlsx"), key=lambda item: item.stat().st_mtime, reverse=True)
        for path in files[keep:]:
            if not path.name.endswith("_final.xlsx"):
                path.unlink(missing_ok=True)

    def close(self, wait: bool = True, final_outputs: bool = True):
        if self._closed:
            return
        self._closing = True
        if final_outputs and (
            not self.paused
            and self._protocol_collection.get("mode") == "scheduled"
            and self.config.get("sampling", {}).get("emit_final_on_stop", True)
        ):
            self._flush_protocol_candidates()
        checkpoint = self.config["checkpoint"]
        if final_outputs and checkpoint.get("enabled") and checkpoint.get("save_on_stop", True):
            try:
                self._write_checkpoint()
            except BaseException as error:
                self.last_error = f"{type(error).__name__}: {error}"
                self.error_count += 1
        excel = self.config.get("excel", {})
        if final_outputs and excel.get("enabled") and excel.get("write_final_on_stop", True):
            if self._future and wait:
                try:
                    self._future.result(timeout=60)
                except BaseException:
                    pass
            # Allow this one explicitly requested final output while closing.
            self._closing = False
            self.request_export(final=True)
            self._closing = True
        if self._future is not None and not self._future.running():
            self._future.cancel()
        self._executor.shutdown(wait=wait, cancel_futures=not final_outputs)
        self._closed = True
        self.insight_engine.close()
