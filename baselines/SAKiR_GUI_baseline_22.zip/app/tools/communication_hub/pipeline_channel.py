"""Ordered parsed batches, consumption credits and explicit overload outcomes."""
from __future__ import annotations

import pickle
import queue
import threading
import time
from collections import deque
from dataclasses import dataclass

from .parsed_contract import FORMAT_VERSION, ParsedBatch

CONTROL_BYTES = 4096


@dataclass
class _Entry:
    batch_id: int
    packet: bytes
    count: int
    control: bool
    created: float
    state: str = "queued"


class ParsedPublisher:
    def __init__(self, connection, settings, epoch):
        self.connection, self.settings, self.epoch = connection, dict(settings), epoch
        self.condition = threading.Condition()
        self.queue = deque()
        self.outstanding = {}
        self.pending_records = self.pending_bytes = self.batches = 0
        self.queued_records = self.queued_bytes = self.controls = 0
        self.sent_bytes = self.sent_records = self.acknowledged_records = 0
        self.admitted_records = self.admitted_bytes = 0
        self.high_water_records = self.high_water_bytes = 0
        self.dropped_newest_records = self.dropped_newest_bytes = self.dropped_newest_batches = 0
        self.evicted_oldest_records = self.evicted_oldest_bytes = self.evicted_oldest_batches = 0
        self.fallback_count = self.blocked_count = 0
        self.blocked_seconds = 0.
        self._blocked_since = None
        self.last_overload_reason = self.error = ""
        self.closed = False
        self.sender = threading.Thread(target=self._send, daemon=True, name="hub-parsed-publisher")
        self.reader = threading.Thread(target=self._ack, daemon=True, name="hub-parsed-credits")
        self.sender.start()
        self.reader.start()

    def _check(self):
        if self.error or self.closed:
            raise RuntimeError(self.error or "Parsed publisher is closed")

    def _fail(self, error):
        with self.condition:
            self.error = f"{type(error).__name__}: {error}"
            self.condition.notify_all()

    def _fits(self, count, size):
        return (self.pending_records + count <= self.settings["max_pending_records"] and
                self.pending_bytes + size <= self.settings["max_pending_bytes"])

    def _release(self, entry):
        if entry.control:
            self.controls -= 1
        else:
            self.pending_records -= entry.count
            self.pending_bytes -= len(entry.packet)
        del self.outstanding[entry.batch_id]

    def _admit(self, entry, service_control):
        blocked_at = None
        try:
            while True:
                with self.condition:
                    self._check()
                    available = not self.controls if entry.control else self._fits(entry.count, len(entry.packet))
                    if available:
                        self.outstanding[entry.batch_id] = entry
                        self.queue.append(entry)
                        if entry.control:
                            self.controls += 1
                        else:
                            self.pending_records += entry.count
                            self.pending_bytes += len(entry.packet)
                            self.queued_records += entry.count
                            self.queued_bytes += len(entry.packet)
                            self.admitted_records += entry.count
                            self.admitted_bytes += len(entry.packet)
                            self.high_water_records = max(self.high_water_records, self.pending_records)
                            self.high_water_bytes = max(self.high_water_bytes, self.pending_bytes)
                        self.condition.notify_all()
                        return True
                    policy = "block" if entry.control else self.settings.get("overload_policy", "block")
                    if policy == "drop_oldest":
                        # A queued marker pins everything before it against eviction.
                        last_marker = max((i for i, item in enumerate(self.queue) if item.control), default=-1)
                        eligible = next((item for i, item in enumerate(self.queue)
                                         if i > last_marker and not item.control), None)
                        if eligible is not None:
                            self.queue.remove(eligible)
                            self.queued_records -= eligible.count
                            self.queued_bytes -= len(eligible.packet)
                            self._release(eligible)
                            self.evicted_oldest_batches += 1
                            self.evicted_oldest_records += eligible.count
                            self.evicted_oldest_bytes += len(eligible.packet)
                            self.last_overload_reason = "Oldest unsent parsed batch evicted"
                            continue
                        self.fallback_count += 1
                        self.last_overload_reason = "In-flight or barrier-protected work; newest batch dropped"
                    if policy != "block":
                        self.dropped_newest_batches += 1
                        self.dropped_newest_records += entry.count
                        self.dropped_newest_bytes += len(entry.packet)
                        if policy == "drop_newest":
                            self.last_overload_reason = "Newest parsed batch dropped"
                        return False
                    if blocked_at is None:
                        blocked_at = time.monotonic()
                        self.blocked_count += 1
                        self._blocked_since = blocked_at
                    self.last_overload_reason = "Waiting for parsed handoff credits"
                    self.condition.wait(.01)
                if service_control is not None:
                    service_control()
        finally:
            if blocked_at is not None:
                with self.condition:
                    self.blocked_seconds += time.monotonic() - blocked_at
                    self._blocked_since = None

    def publish(self, records, service_control=None):
        if not records:
            return 0
        control = len(records) == 1 and records[0].get("kind") == "barrier"
        if any(item.get("kind") == "barrier" for item in records) and not control:
            raise ValueError("A barrier must occupy its own packet")
        with self.condition:
            self.batches += 1
            batch_id = self.batches
        packet = pickle.dumps(ParsedBatch(FORMAT_VERSION, batch_id, self.epoch, tuple(records), control), protocol=5)
        limit = CONTROL_BYTES if control else self.settings["max_pending_bytes"]
        if len(packet) > limit or (not control and len(records) > self.settings["max_pending_records"]):
            if not control and len(records) > 1:
                middle = len(records) // 2
                return self.publish(records[:middle], service_control) + self.publish(records[middle:], service_control)
            raise ValueError(f"Parsed record/control packet exceeds handoff budget at capture sequence {records[0].get('capture_sequence', 0)}")
        entry = _Entry(batch_id, packet, 0 if control else len(records), control, time.monotonic())
        admitted = self._admit(entry, service_control)
        return len(records) if admitted and not control else 0

    def _send(self):
        try:
            while True:
                with self.condition:
                    self.condition.wait_for(lambda: self.queue or self.closed or self.error)
                    if self.closed or self.error:
                        return
                    entry = self.queue.popleft()
                    entry.state = "sending"
                    if not entry.control:
                        self.queued_records -= entry.count
                        self.queued_bytes -= len(entry.packet)
                self.connection.send_bytes(entry.packet)
                with self.condition:
                    self.sent_bytes += len(entry.packet)
                    self.sent_records += entry.count
                    if entry.batch_id in self.outstanding:
                        entry.state = "awaiting_ack"
                entry = None
        except (OSError, EOFError, ValueError) as error:
            if not self.closed:
                self._fail(error)

    def _ack(self):
        try:
            while True:
                if not self.connection.poll(.05):
                    if self.closed:
                        return
                    continue
                epoch, batch_id = self.connection.recv()
                with self.condition:
                    entry = self.outstanding.get(batch_id)
                    if type(batch_id) is not int or epoch != self.epoch or entry is None or entry.state == "queued":
                        raise ValueError("Invalid, duplicate or stale parsed acknowledgement")
                    self.acknowledged_records += entry.count
                    self._release(entry)
                    self.condition.notify_all()
        except (OSError, EOFError, ValueError, TypeError) as error:
            if not self.closed:
                self._fail(error)

    def drain(self, timeout, service_control=None):
        deadline = time.monotonic() + timeout
        while True:
            with self.condition:
                self._check()
                if not self.outstanding:
                    return
                if time.monotonic() >= deadline:
                    raise TimeoutError("Parsed handoff did not drain")
                self.condition.wait(.01)
            if service_control is not None:
                service_control()

    def status(self):
        with self.condition:
            # O(1) counters: overload must not turn polling into a queue scan.
            result = {name: getattr(self, name) for name in (
                "pending_records", "pending_bytes", "queued_records", "queued_bytes",
                "high_water_records", "high_water_bytes", "admitted_records", "admitted_bytes",
                "sent_records", "sent_bytes", "acknowledged_records", "batches",
                "dropped_newest_records", "dropped_newest_bytes", "dropped_newest_batches",
                "evicted_oldest_records", "evicted_oldest_bytes", "evicted_oldest_batches",
                "fallback_count", "blocked_count", "blocked_seconds", "last_overload_reason")}
            if self._blocked_since is not None:
                result["blocked_seconds"] += time.monotonic() - self._blocked_since
            first = next(iter(self.outstanding.values()), None)
            return {**self.settings, **result, "epoch": self.epoch,
                    "inflight_records": self.pending_records - self.queued_records,
                    "inflight_bytes": self.pending_bytes - self.queued_bytes,
                    "oldest_pending_age_seconds": time.monotonic() - first.created if first else 0.,
                    "last_error": self.error}

    def close(self):
        with self.condition:
            self.closed = True
            self.condition.notify_all()
        self.connection.close()
        self.sender.join(1)
        self.reader.join(1)


class ParsedInbox:
    def __init__(self, connection):
        self.connection = connection
        self.records = deque()
        self.batch = None
        self.epoch = None
        self.eof = False
        self.last_batch_id = 0
        self.received_bytes = self.received_records = 0

    def reset_epoch(self, epoch):
        if self.records or self.batch is not None:
            raise RuntimeError("Cannot replace an undrained parser channel")
        self.epoch = epoch
        self.last_batch_id = 0

    def get_nowait(self):
        if not self.records:
            if self.eof:
                raise queue.Empty
            try:
                if not self.connection.poll():
                    raise queue.Empty
                packet = self.connection.recv_bytes()
            except (OSError, EOFError):
                self.eof = True
                raise queue.Empty
            batch = pickle.loads(packet)
            if not isinstance(batch, ParsedBatch) or batch.version != FORMAT_VERSION or batch.epoch != self.epoch or not batch.records or batch.batch_id <= self.last_batch_id or batch.control != (len(batch.records) == 1 and batch.records[0].get("kind") == "barrier"):
                raise ValueError("Invalid or stale parsed batch")
            self.last_batch_id = batch.batch_id
            self.batch = batch
            self.records.extend(batch.records)
            self.received_bytes += len(packet)
            self.received_records += 0 if batch.control else len(batch.records)
        return self.records.popleft()

    def task_done(self):
        if not self.records and self.batch is not None:
            self.connection.send((self.epoch, self.batch.batch_id))
            self.batch = None

    def qsize(self):
        return len(self.records)

    def close(self):
        self.connection.close()
