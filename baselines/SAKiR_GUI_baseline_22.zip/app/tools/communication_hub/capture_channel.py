"""Frame-count-bounded capture queue with protected ordered markers."""
from __future__ import annotations

import queue


class CaptureQueue:
    def __init__(self, context, capacity):
        self.queue = context.Queue(maxsize=capacity)
        self.markers = context.Value("i", 0)
        self.admission = context.Lock()

    def put(self, envelope, block=True, timeout=None):
        marker = envelope.get("kind") == "barrier"
        with self.admission:
            if marker:
                with self.markers.get_lock():
                    self.markers.value += 1
            try:
                self.queue.put(envelope, block, timeout)
            except BaseException:
                if marker:
                    with self.markers.get_lock():
                        self.markers.value -= 1
                raise

    def put_nowait(self, envelope):
        self.put(envelope, False)

    def get(self, block=True, timeout=None):
        envelope = self.queue.get(block, timeout)
        if envelope.get("kind") == "barrier":
            with self.markers.get_lock():
                self.markers.value -= 1
        return envelope

    def get_nowait(self):
        return self.get(False)

    def replace_oldest(self, envelope):
        """Return (admitted, evicted, protected), without recalling a marker."""
        with self.admission:
            if self.markers.value:
                return False, 0, True
            try:
                self.queue.get_nowait()
            except queue.Empty:
                return False, 0, False
            try:
                self.queue.put_nowait(envelope)
                return True, 1, False
            except queue.Full:
                return False, 1, False

    def qsize(self):
        return self.queue.qsize()

    def empty(self):
        return self.queue.empty()

    def close(self):
        self.queue.close()

    def cancel_join_thread(self):
        self.queue.cancel_join_thread()

    def join_thread(self):
        self.queue.join_thread()
