"""Owner of each session's I/O, parser and retained data processes."""
from __future__ import annotations

import atexit
import multiprocessing
import os
import queue
import threading
import time
import uuid
from pathlib import Path
import pandas as pd

from .config import normalize_session_config, resolve_project_path
from .store import EventStore
from .worker import session_process_entry
from .parser_worker import parser_process_entry
from .data_worker import data_process_entry
from .capture_channel import CaptureQueue

DATA_COMMANDS = {
    "query", "table_state", "delete_preview", "delete", "names",
    "name_summary", "fields", "protocol_insight_publisher", "persist", "message_subscriptions",
}


class SessionController:
    """Public facade for the single, separate-parser session architecture."""

    def __init__(
        self,
        config: dict,
        project_root: str | Path,
        retained_table_state: dict | None = None,
        protocol_insight_ingress=None,
        protocol_insight_publisher_capacity: int = 1024,
        message_stream=None,
    ):
        self.parser_process = self.parser_connection = None
        self._parsed_sender = None
        self._parser_lock = threading.RLock()
        self._barrier_lock = threading.RLock()
        self._parser_cache = {}
        self._data_cache = {}
        self._api_members = []
        self._insight_payload = {"enabled": False}
        self.last_barrier_outcome = {}
        self.config = normalize_session_config(config)
        self.project_root = str(project_root)
        self.process: multiprocessing.Process | None = None
        self.connection = None
        self.processing_process: multiprocessing.Process | None = None
        self.processing_connection = None
        self.capture_queue = None
        self.diagnostic_queue = None
        self._backend_errors: list[dict] = []
        self._shutdown_errors: list[str] = []
        self._stopped_io_status: dict = {}
        self.status_generation = 0
        self._poll_pending: dict = {}
        self._poll_completed: dict = {}
        self._poll_cache: dict = {}
        self._lock = threading.RLock()
        self._processing_lock = threading.RLock()
        self._retained_store: EventStore | None = None
        self.protocol_insight_ingress = protocol_insight_ingress
        self.message_stream = message_stream
        if message_stream is not None:
            message_stream.register_controller(self)
        self.protocol_insight_publisher_capacity = max(
            1, int(protocol_insight_publisher_capacity)
        )
        if retained_table_state is not None:
            self._retain_table(retained_table_state)

        atexit.register(self.close)

    def _retain_table(self, state: dict):
        store = EventStore(self.config["storage"])
        store.restore_state(state)
        self._retained_store = store
        self.status_generation += 1

    def table_snapshot(self, timeout: float = 60.0) -> pd.DataFrame:
        """Return a coherent copy of this session's current or retained message table."""
        if self.running:
            state = self.request("table_state", timeout=timeout)
        else:
            state = self.retained_table_state()
        frame = state.get("frame") if isinstance(state, dict) else None
        if not isinstance(frame, pd.DataFrame):
            raise RuntimeError(f"Session '{self.config['name']}' has no message table available")
        return frame.copy(deep=True)

    def _persistence_directory(self) -> Path:
        persistence = self.config.get("persistence", {})
        return resolve_project_path(self.project_root, persistence.get("directory", "app/data/communication_hub/logs")) / self.config["id"]

    def load_latest_persisted_table(self) -> dict:
        """Restore the newest final or periodic message snapshot without starting transport I/O."""
        if not self.config.get("persistence", {}).get("enabled"):
            return {"loaded": False, "path": ""}
        candidates = [
            path for path in (
                self._persistence_directory() / "messages_latest.pkl",
                self._persistence_directory() / "messages_final.pkl",
            ) if path.is_file()
        ]
        if not candidates:
            return {"loaded": False, "path": ""}
        path = max(candidates, key=lambda item: item.stat().st_mtime_ns)
        frame = pd.read_pickle(path)
        if not isinstance(frame, pd.DataFrame):
            raise TypeError(f"Persisted session snapshot is not a Pandas DataFrame: {path}")
        numeric_ids = pd.to_numeric(frame.get("id", pd.Series(dtype=float)), errors="coerce")
        largest_id = int(numeric_ids.max()) if len(numeric_ids) and pd.notna(numeric_ids.max()) else 0
        updates = pd.to_numeric(frame.get("update_count", pd.Series(dtype=float)), errors="coerce").fillna(1)
        version = max(0, int(updates.sum()))
        self._retain_table({"frame": frame, "next_id": largest_id + 1, "version": version})
        return {"loaded": True, "path": str(path), "rows": len(frame), "version": version}

    def persist_retained_table(self, final: bool = True) -> dict:
        if self._retained_store is None or not self.config.get("persistence", {}).get("enabled"):
            return {"saved": False}
        directory = self._persistence_directory(); directory.mkdir(parents=True, exist_ok=True)
        suffix = "final" if final else "latest"
        frame = self._retained_store.snapshot()
        counts = self._retained_store.name_summary_frame()
        paths = {
            directory / f"messages_{suffix}.pkl": frame,
            directory / f"message_counts_{suffix}.pkl": counts,
        }
        for path, value in paths.items():
            temporary = path.with_suffix(".tmp.pkl")
            value.to_pickle(temporary); os.replace(temporary, path)
        return {"saved": True, "rows": len(frame), "directory": str(directory)}

    def _drain_backend_diagnostics(self):
        if self.diagnostic_queue is None:
            return
        while True:
            try:
                diagnostic = self.diagnostic_queue.get_nowait()
            except queue.Empty:
                break
            except (EOFError, OSError, ValueError):
                break
            if isinstance(diagnostic, dict):
                self._backend_errors.append(diagnostic)
                self._backend_errors = self._backend_errors[-32:]

    def _request_connection(self, connection, lock, command, payload, timeout):
        if connection is None:
            raise RuntimeError(f"Session '{self.config['name']}' backend is not available")
        request_id = str(uuid.uuid4())
        deadline = time.monotonic() + timeout
        if not lock.acquire(timeout=max(0., timeout)):
            raise TimeoutError(f"Session command '{command}' admission timed out")
        try:
            connection.send({"id": request_id, "command": command, "payload": payload})
            while time.monotonic() < deadline:
                if connection.poll(min(0.05, max(0.0, deadline - time.monotonic()))):
                    response = connection.recv()
                    if response.get("id") != request_id:
                        self._accept_poll_response(connection, response)
                        continue
                    if not response.get("ok"):
                        raise RuntimeError(response.get("error", "Worker command failed"))
                    return response.get("result")
            raise TimeoutError(f"Session command '{command}' timed out")
        finally:
            lock.release()

    def _accept_poll_response(self, connection, response):
        """Route a delayed poll reply consumed by another command on this pipe."""
        if self._poll_pending.get(connection) != response.get("id"):
            return
        self._poll_pending.pop(connection, None)
        self._poll_completed[connection] = response.get("result") if response.get("ok") else None

    def _poll_request(self, connection, lock, command, timeout):
        if connection is None:
            return None
        deadline = time.monotonic() + max(0.0, timeout)
        if not lock.acquire(timeout=max(0.0, deadline - time.monotonic())):
            return None
        try:
            if connection in self._poll_completed:
                return self._poll_completed.pop(connection)
            if time.monotonic() >= deadline:
                return None
            if connection not in self._poll_pending:
                request_id = str(uuid.uuid4())
                connection.send({"id": request_id, "command": command, "payload": {}})
                self._poll_pending[connection] = request_id
            # Leave timed-out requests pending. Sending another every tick
            # would build an unbounded command backlog behind a slow parser.
            while time.monotonic() < deadline:
                if connection.poll(min(0.05, max(0.0, deadline - time.monotonic()))):
                    self._accept_poll_response(connection, connection.recv())
                    if connection in self._poll_completed:
                        return self._poll_completed.pop(connection)
            return None
        except (EOFError, OSError, ValueError):
            self._poll_pending.pop(connection, None)
            return None
        finally:
            lock.release()

    def send(self, data: bytes | str, *, encoding: str = "utf-8", target: str = ""):
        """Send exactly the supplied bytes; receive framing does not affect TX."""
        return self.request("send", {
            "data": data, "encoding": encoding, "target": target,
        })

    def query(self, query: dict | None = None, **options):
        payload = {"query": query or {}}
        payload.update(options)
        return self.request("query", payload)

    def query_consistent(self, query=None, *, timeout=30, **options):
        """Query after an acknowledged capture-to-storage frontier."""
        started = time.monotonic()
        self.commit_read_barrier(timeout)
        return self._query_at_barrier({"query": query or {}, **options}, max(.001, timeout - (time.monotonic() - started)))

    def _checkpoint_state(self):
        return self._retained_store.export_state() if self._retained_store is not None else None

    @property
    def running(self):
        return bool(self.process and self.process.is_alive() and self.processing_process and self.processing_process.is_alive()) and bool(self.parser_process and self.parser_process.is_alive())

    @property
    def table_available(self):
        return bool(self.processing_process and self.processing_process.is_alive()) or self._retained_store is not None

    def _data(self, command, payload=None, timeout=30):
        started = time.monotonic()
        if not self._processing_lock.acquire(timeout=max(0., timeout)):
            raise TimeoutError("Combined data request admission timed out")
        try:
            return self._request_connection(self.processing_connection, self._processing_lock, command, payload or {},
                                            max(.001, timeout - (time.monotonic() - started)))
        finally:
            self._processing_lock.release()

    def _ensure_data(self):
        if self.processing_process is not None and self.processing_process.is_alive():
            return
        if self.processing_process is not None:
            if self._retained_store is None:
                raise RuntimeError("Combined data worker exited; unpersisted table is unavailable. Close or restore a checkpoint before restarting")
            self.processing_process.join(1)
            self.processing_connection.close()
        context = multiprocessing.get_context("spawn")
        parent, child = context.Pipe()
        parsed_receiver, parsed_sender = context.Pipe()
        api_receiver, api_sender = context.Pipe(duplex=False)
        if self.diagnostic_queue is not None:
            self._drain_backend_diagnostics()
            self.diagnostic_queue.close()
        self.diagnostic_queue = context.Queue(maxsize=32)
        self.processing_process = context.Process(target=data_process_entry,
            args=(child, parsed_receiver, self.config, self.project_root, self._checkpoint_state(),
                  api_sender, self.protocol_insight_ingress, self.diagnostic_queue),
            name=f"CommunicationData-{self.config['name']}", daemon=True)
        self.processing_connection = parent
        self._parsed_sender = parsed_sender
        try:
            self.processing_process.start()
            child.close()
            parsed_receiver.close()
            api_sender.close()
            if self.message_stream is not None:
                self.message_stream.open_reader(self.config["id"], api_receiver)
            else:
                api_receiver.close()
            self._data("ping", timeout=15)
            self._retained_store = None
            self._data("message_subscriptions", {"members": self._api_members})
            self._data("protocol_insight_publisher", self._insight_payload)
        except BaseException:
            for endpoint in (child, parsed_receiver, parsed_sender, api_sender, api_receiver):
                endpoint.close()
            self._kill_data()
            raise

    def set_message_subscriptions(self, subscriptions):
        self._api_members = [{"id": sub.id, "kind": "api", "target": sub.id, "query": sub._query,
                              "sessions": [sub.session_id] if sub.session_id is not None else None}
                             for sub in subscriptions if sub.session_id is None or sub.session_id == self.config["id"]]
        if self.processing_process is not None and self.processing_process.is_alive():
            return self._data("message_subscriptions", {"members": self._api_members})

    def rebind_insight_ingress(self, ingress):
        self.protocol_insight_ingress = ingress
        if self.processing_process is not None and self.processing_process.is_alive():
            self._data("rebind_insight", {"ingress": ingress})

    def start(self, timeout=15):
        with self._barrier_lock, self._lock:
            if self.running:
                return self.status()
            if self.process is not None or self.parser_process is not None:
                self.stop(timeout)
            self._shutdown_errors = []
            had_data = bool(self.processing_process and self.processing_process.is_alive())
            self._ensure_data()
            context = multiprocessing.get_context("spawn")
            if self._parsed_sender is None:
                receiver, sender = context.Pipe()
                try:
                    self._data("replace_parsed_channel", {"connection": receiver})
                finally:
                    receiver.close()
                self._parsed_sender = sender
            epoch = str(uuid.uuid4())
            self._data("begin_capture", {"epoch": epoch})
            self.capture_queue = CaptureQueue(context, self.config["ipc"]["io_to_parser"]["queue_capacity"])
            parent, child = context.Pipe()
            self.parser_connection = parent
            self.parser_process = context.Process(target=parser_process_entry,
                args=(child, self.capture_queue, self._parsed_sender, self.config, self.project_root, epoch, self.diagnostic_queue),
                name=f"CommunicationParser-{self.config['name']}", daemon=True)
            try:
                self.parser_process.start()
                child.close()
                self._parsed_sender.close()
                self._parsed_sender = None
                self._request_connection(parent, self._parser_lock, "ping", {}, timeout)
                parent, child = context.Pipe()
                self.connection = parent
                self.process = context.Process(target=session_process_entry,
                    args=(child, self.capture_queue, self.config, self.project_root, self.diagnostic_queue),
                    name=f"CommunicationSession-{self.config['name']}", daemon=True)
                self.process.start()
                child.close()
                self.status_generation += 1
                self._poll_pending.clear()
                self._poll_completed.clear()
                self._poll_cache.clear()
                self._parser_cache.clear()
                if self.message_stream is not None:
                    self.set_message_subscriptions(list(self.message_stream._subscriptions.values()))
                return self._request_connection(self.connection, self._lock, "ping", {}, timeout)
            except BaseException:
                child.close()
                try:
                    self.stop(timeout)
                    if not had_data and self.processing_process and self.processing_process.is_alive():
                        self._retain_table(self._data("table_state"))
                finally:
                    if not had_data:
                        self._kill_data()
                        if self.message_stream is not None:
                            self.message_stream.close_reader(self.config["id"], drain=True)
                raise

    def _barrier(self, timeout=30):
        deadline = time.monotonic() + timeout
        if not self._barrier_lock.acquire(timeout=max(0., timeout)):
            raise TimeoutError("Capture barrier admission timed out")
        try:
            if self.running:
                remaining = lambda: max(.001, deadline - time.monotonic())
                marker = self._request_connection(self.connection, self._lock, "capture_barrier", {}, remaining())
                result = self._data("commit_barrier", marker, remaining())
                self.last_barrier_outcome = result["ipc_outcome"]
            return self.last_barrier_outcome
        finally:
            self._barrier_lock.release()

    def commit_read_barrier(self, timeout=30):
        return self._barrier(timeout)

    def _query_at_barrier(self, payload, timeout):
        self._ensure_data()
        return self._data("query", payload, timeout)

    def request(self, command, payload=None, timeout=30):
        payload = payload or {}
        if command == "protocol_insight_publisher":
            # Worker merge semantics preserve other active monitors.
            self._insight_payload = payload
            self._ensure_data()
            return self._data(command, payload, timeout)
        if command in DATA_COMMANDS or command.startswith("replay_"):
            self._ensure_data()
            if command in {"query", "table_state", "delete_preview", "delete", "names", "name_summary", "fields", "persist", "replay_prepare"}:
                self._barrier(timeout)
            return self._data(command, payload, timeout)
        if not self.running:
            raise RuntimeError(f"Session '{self.config['name']}' pipeline is not running")
        return self._request_connection(self.connection, self._lock, command, payload, timeout)

    def retained_table_state(self):
        if self.processing_process is not None and self.processing_process.is_alive():
            return self._data("table_state", timeout=60)
        return self._checkpoint_state()

    def _compose_status(self, io, parser, data):
        failed = (self.process is not None or self.parser_process is not None) and not self.running
        self._drain_backend_diagnostics()
        state = "error" if failed or self._shutdown_errors else (io.get("state", "running") if self.running else "stopped")
        detail = "\n".join(str(item.get("error", "")) for item in self._backend_errors[-2:])
        result = {**data, **io, **parser, "session_id": self.config["id"], "storage_backend": "parser_split",
                  "state": state, "storage_available": self.table_available,
                  "parser_backend_alive": bool(self.parser_process and self.parser_process.is_alive()),
                  "io_backend_alive": bool(self.process and self.process.is_alive()),
                  "processing_backend_alive": bool(self.processing_process and self.processing_process.is_alive()),
                  "backend_errors": list(self._backend_errors), "shutdown_errors": list(self._shutdown_errors),
                  "ipc": {**io.get("ipc", {}), **parser.get("ipc", {})},
                  "last_barrier_outcome": data.get("last_barrier_outcome", self.last_barrier_outcome)}
        if failed or self._shutdown_errors:
            detail = "\n".join([detail, *self._shutdown_errors]).strip()
            result.update(status_message=detail or "Capture stage exited; committed table retained if available",
                          last_error=detail or "Capture pipeline is not running")
        return result

    def status(self):
        io = dict(self._stopped_io_status)
        if self.process is not None and self.process.is_alive():
            io = self._request_connection(self.connection, self._lock, "status", {}, 2)
        if self.processing_process is not None and self.processing_process.is_alive():
            self._data_cache = self._data("data_status", timeout=2)
        if self.parser_process is not None and self.parser_process.is_alive():
            self._parser_cache = self._request_connection(self.parser_connection, self._parser_lock, "status", {}, 2)
        return self._compose_status(io, self._parser_cache, self._data_cache)

    def poll_status(self, timeout=.2):
        generation = self.status_generation
        if self._poll_cache.get("generation", generation) != generation:
            self._poll_cache.clear()
            self._data_cache.clear()
            self._parser_cache.clear()
        self._data_cache = self._poll_cache.get("data", self._data_cache)
        if self.processing_process is None and self._retained_store is not None:
            if self._data_cache.get("table_version") != self._retained_store.version:
                self._data_cache = {**self._retained_store.metrics(), "table_version": self._retained_store.version}
        delayed = {}
        for connection, lock, command, key in ((self.connection, self._lock, "status", "io"),
                (self.parser_connection, self._parser_lock, "status", "parser"),
                (self.processing_connection, self._processing_lock, "poll_data_status", "data")):
            if connection is not None:
                value = self._poll_request(connection, lock, command, timeout / 3)
                if generation != self.status_generation:
                    return None
                if value is not None:
                    self._poll_cache[key] = value
                    if key == "data": self._data_cache = value
                    if key == "parser": self._parser_cache = value
                delayed[f"{key}_refresh_delayed"] = value is None
        self._poll_cache["generation"] = generation
        result = self._compose_status(self._poll_cache.get("io", self._stopped_io_status),
                                      self._parser_cache, self._data_cache)
        result.update(delayed)
        if self.running and "io" not in self._poll_cache:
            result["state"] = "unknown"
        result["connection_refresh_delayed"] = delayed.get("io_refresh_delayed", False)
        result["statistics_refresh_delayed"] = delayed.get("data_refresh_delayed", False)
        result["statistics_available"] = bool(self._data_cache)
        return result

    def stop(self, timeout=15):
        with self._barrier_lock, self._lock:
            deadline = time.monotonic() + timeout
            remaining = lambda: max(.1, deadline - time.monotonic())
            sequence = 0
            if self.process is not None and not self.process.is_alive():
                self._shutdown_errors.append("I/O worker exited before orderly capture shutdown")
            if self.process is not None and self.process.is_alive():
                try:
                    self._stopped_io_status = self._request_connection(self.connection, self._lock, "stop", {}, remaining())
                    sequence = self._stopped_io_status["capture_sequence"]
                except Exception as error:
                    self._shutdown_errors.append(f"I/O drain: {error}")
            if self.processing_process is not None and not self.processing_process.is_alive():
                self._shutdown_errors.append("Combined data worker exited; unpersisted table is unavailable")
            if sequence and not (self.parser_process and self.parser_process.is_alive()):
                self._shutdown_errors.append("Parser exited before the final capture barrier; capture is incomplete")
            if self.processing_process is not None and self.processing_process.is_alive() and sequence and self.parser_process and self.parser_process.is_alive():
                try:
                    outcome = self._data("commit_barrier", {"capture_sequence": sequence}, remaining())
                    self.last_barrier_outcome = outcome["ipc_outcome"]
                except Exception as error:
                    self._shutdown_errors.append(f"Parsed drain: {error}")
            if self.parser_process is not None and self.parser_process.is_alive():
                try:
                    self._parser_cache = self._request_connection(self.parser_connection, self._parser_lock, "status", {}, remaining())
                    self._parser_cache = self._request_connection(self.parser_connection, self._parser_lock, "stop", {"capture_sequence": sequence}, remaining())
                except Exception as error:
                    self._shutdown_errors.append(f"Parser shutdown: {error}")
            for process, connection in ((self.process, self.connection), (self.parser_process, self.parser_connection)):
                if process is not None and getattr(process, "pid", None) is not None:
                    process.join(remaining())
                    if process.is_alive():
                        process.terminate()
                        process.join(3)
                        self._shutdown_errors.append("Pipeline stage required forced termination")
                    elif process.exitcode:
                        self._shutdown_errors.append(f"Pipeline stage exited with code {process.exitcode}")
                if connection is not None:
                    connection.close()
            self.process = self.connection = self.parser_process = self.parser_connection = None
            if self.capture_queue is not None:
                self.capture_queue.close()
                self.capture_queue = None
            self._stopped_io_status["state"] = "stopped"
            if self.processing_process is not None and self.processing_process.is_alive():
                self._data("end_capture")
                try:
                    self._data("drain_delivery", timeout=remaining())
                except Exception as error:
                    self._shutdown_errors.append(f"Delivery drain: {error}")
                self._data_cache = self._data("data_status")
                if self.config["persistence"].get("enabled") and self.config["persistence"].get("save_on_stop", True):
                    self._data("persist", {"final": True}, remaining())
            self.status_generation += 1
            return self.status()

    def _kill_data(self):
        if self.processing_process is not None:
            if getattr(self.processing_process, "pid", None) is not None:
                if self.processing_process.is_alive():
                    self.processing_process.terminate()
                self.processing_process.join(5)
        if self.processing_connection is not None:
            self.processing_connection.close()
        self.processing_process = self.processing_connection = None

    def close(self):
        try:
            self.stop()
            if self.processing_process is not None and self.processing_process.is_alive():
                try:
                    self._data("stop", {}, 15)
                    self.processing_process.join(15)
                finally:
                    self._kill_data()
        finally:
            self._kill_data()
            if getattr(self, "_parsed_sender", None) is not None:
                self._parsed_sender.close()
                self._parsed_sender = None
            if self.diagnostic_queue is not None:
                self._drain_backend_diagnostics()
                self.diagnostic_queue.close()
                self.diagnostic_queue = None
            if self.message_stream is not None:
                self.message_stream.close_reader(self.config["id"], drain=True)
            atexit.unregister(self.close)
