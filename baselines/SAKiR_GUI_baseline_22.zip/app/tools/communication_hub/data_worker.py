"""Local Pandas storage and shared consumer matching behind a separate parser."""
from __future__ import annotations

import asyncio
import copy
import pickle
import time
import traceback
import uuid
from collections import OrderedDict

from .message_stream import MessagePublisher
from .pipeline_channel import ParsedInbox
from pathlib import Path
import multiprocessing
import os
import queue

from .config import normalize_session_config, resolve_project_path
from .store import EventStore
from .protocol_insight_runtime import normalize_protocol_insight_runtime_config
from .query_plan import RecordEvaluation, fingerprint
from .memory_budget import owned_size
from .subscription_registry import SubscriptionRegistry


class InsightDestination:
    def __init__(self, ingress):
        self.ingress = ingress

    def send_bytes(self, packet):
        _, _, record = pickle.loads(packet)
        if self.ingress is None:
            raise RuntimeError("Insight ingress is not available")
        record["targets"] = [(target, token) for kind, target, token in record["targets"] if kind == "insight"]
        self.ingress.put_nowait(record)

    def close(self):
        if self.ingress is not None:
            try:
                self.ingress.flush(timeout=10)
            finally:
                self.ingress.close()


class DataWorker:
    """Parsed input, local table, queries, persistence and grouped delivery."""

    def __init__(self, control, parsed_connection, config, project_root, initial_state, api_output, insight_ingress):
        inbox = ParsedInbox(parsed_connection)
        self.connection = control
        self.capture_queue = inbox
        self.config = normalize_session_config(config)
        self.project_root = Path(project_root)
        self.store = EventStore(self.config["storage"])
        self.store.restore_state(initial_state)
        self.last_barrier_outcome = {}
        self.running = True
        self.last_error = ""
        self.records_processed = 0
        self.parser_duration_ns_total = 0
        self.store_add_ns_total = 0
        self.processing_errors = 0
        self.last_capture_sequence = 0
        self.last_barrier_sequence = 0
        self.sequence_gaps = 0
        self._metrics_cache: dict | None = None
        self._metrics_cache_at = 0.0
        self.last_persist = time.monotonic()
        self._persist_task: asyncio.Task | None = None
        self.persistence_last_error = ""
        self.registry = SubscriptionRegistry()
        self.arrival_sequence = 0
        self.capture_epoch = ""
        self.capture_active = False
        self.monitors = {}
        self.replay = None
        self.read_cache = OrderedDict()
        self.read_cache_version = None
        self.read_cache_bytes = self.read_cache_hits = 0
        self.api_publisher = MessagePublisher(api_output, ("routed",), maximum_bytes=64 * 1024 * 1024)
        self.insight_destination = InsightDestination(insight_ingress)
        self.insight_publisher = MessagePublisher(self.insight_destination, ("routed",), maximum_bytes=64 * 1024 * 1024)

    def _consume(self, envelope: dict):
        sequence = int(envelope.get("capture_sequence", 0) or 0)
        if sequence > self.last_capture_sequence + 1:
            self.sequence_gaps += sequence - self.last_capture_sequence - 1
        self.last_capture_sequence = max(self.last_capture_sequence, sequence)
        if envelope.get("kind") == "barrier":
            self.last_barrier_sequence = sequence
            self.last_barrier_outcome = envelope.get("ipc_outcome", {})
            return
        event, parsed, metadata_error = envelope["event"], envelope["parsed"], envelope.get("header_error", "")
        if metadata_error:
            self.processing_errors += 1
            self.last_error = metadata_error
        before_store = time.perf_counter_ns()
        record = self.store.add(event, parsed)
        self.store_add_ns_total += time.perf_counter_ns() - before_store
        self.parser_duration_ns_total += parsed.duration_ns
        self.records_processed += 1
        if record is not None:
            self._publish(record)

    def _drain_input(self, *, drain_all: bool = False) -> int:
        processing = self.config["processing"]
        maximum = int(processing["batch_records"])
        deadline = time.perf_counter_ns() + int(processing["time_slice_ms"]) * 1_000_000
        drained = 0
        while drain_all or drained < maximum:
            if not drain_all and drained and self.connection.poll():
                break
            if not drain_all and drained and time.perf_counter_ns() >= deadline:
                break
            try:
                envelope = self.capture_queue.get_nowait()
            except queue.Empty:
                break
            drained += 1
            if not isinstance(envelope, dict):
                continue
            try:
                self._consume(envelope)
            except BaseException as error:
                self.processing_errors += 1
                self.last_error = f"{type(error).__name__}: {error}"
            finally:
                self.capture_queue.task_done()
        return drained

    def _table_status(self, *, metrics_max_age: float = 0.0):
        now = time.monotonic()
        if self._metrics_cache is None or now - self._metrics_cache_at >= metrics_max_age:
            self._metrics_cache = self.store.metrics()
            self._metrics_cache_at = now
        result = dict(self._metrics_cache)
        try:
            depth = max(0, int(self.capture_queue.qsize()))
        except (AttributeError, NotImplementedError, OSError):
            depth = -1
        result.update({
            # Table refreshes follow the current version even when expensive
            # counts/memory statistics reuse a recent, coherent snapshot.
            "table_version": self.store.version,
            "statistics_age_seconds": max(0.0, now - self._metrics_cache_at),
            "processing_state": "running" if self.running else "stopping",
            "processing_pid": multiprocessing.current_process().pid,
            "processing_queue_depth": depth,
            "processing_queue_capacity": self.config["ipc"]["parser_to_processor"]["max_pending_records"],
            "processing_records_processed": self.records_processed,
            "parser_duration_ns_total": self.parser_duration_ns_total,
            "store_add_ns_total": self.store_add_ns_total,
            "processing_errors": self.processing_errors,
            "processing_last_error": self.last_error,
            "processing_last_capture_sequence": self.last_capture_sequence,
            "processing_last_barrier_sequence": self.last_barrier_sequence,
            "processing_sequence_gaps": self.sequence_gaps,
            "persistence_inflight": bool(self._persist_task and not self._persist_task.done()),
            "persistence_last_error": self.persistence_last_error,
            "last_barrier_outcome": self.last_barrier_outcome,
        })
        return result

    def _table_command(self, command: str, payload: dict):
        if command in {"ping", "data_status"}:
            return self._status()
        if command == "poll_data_status":
            return self._status(metrics_max_age=5.0)
        if command == "query":
            return self.store.query(
                payload.get("query"), page=payload.get("page", 0),
                page_size=payload.get("page_size", 200),
                sort_by=payload.get("sort_by", "timestamp"),
                descending=payload.get("descending", True),
            )
        if command == "table_state":
            return self.store.export_state()
        if command == "delete_preview":
            result = self.store.query(payload.get("query"), page=0, page_size=10)
            return {"count": result["total"], "version": result["version"], "sample": result["rows"]}
        if command == "delete":
            return self.store.delete(payload.get("query"), payload.get("expected_version"))
        if command == "names":
            return self.store.distinct_names()
        if command == "name_summary":
            return self.store.name_summary()
        if command == "fields":
            return self.store.discover_fields(payload.get("name"))
        if command == "persist":
            return "persist"
        if command == "stop":
            required_sequence = int(payload.get("capture_sequence", 0) or 0)
            if required_sequence and self.last_barrier_sequence < required_sequence:
                raise RuntimeError(
                    f"Capture drain incomplete: expected final marker {required_sequence}, "
                    f"received {self.last_barrier_sequence}"
                )
            self.running = False
            return self.store.export_state() if payload.get("retain_table") else True
        raise ValueError(f"Unknown data-processing command: {command}")

    async def _process_commands(self):
        while self.connection.poll():
            request = self.connection.recv()
            request_id = request.get("id")
            try:
                command = request.get("command")
                if command == "commit_barrier":
                    target = int((request.get("payload") or {}).get("capture_sequence", 0))
                    deadline = time.monotonic() + 25
                    while self.last_barrier_sequence < target:
                        if self.capture_queue.eof:
                            raise RuntimeError("Parser channel ended before the requested capture barrier")
                        if time.monotonic() > deadline:
                            raise TimeoutError("Storage did not reach the requested capture barrier")
                        self._drain_capture()
                        await asyncio.sleep(.001)
                    self.store.flush()
                    self.connection.send({"id": request_id, "ok": True, "result": {"version": self.store.version, "ipc_outcome": self.last_barrier_outcome}})
                    continue
                # A query issued after an I/O send should observe every capture
                # envelope already queued before that query is served.
                if command in {
                    "query", "table_state", "delete_preview", "delete",
                    "names", "name_summary", "fields", "persist", "stop",
                }:
                    self._drain_capture(drain_all=True)
                    self.store.flush()
                result = self._command(command, request.get("payload") or {})
                if result == "persist":
                    await self._await_current_persistence()
                    await self._persist_snapshot(final=bool((request.get("payload") or {}).get("final", False)))
                    result = True
                self.connection.send({"id": request_id, "ok": True, "result": result})
            except BaseException as error:
                self.last_error = traceback.format_exc()
                self.connection.send({
                    "id": request_id, "ok": False,
                    "error": f"{type(error).__name__}: {error}",
                })

    async def _await_current_persistence(self):
        if self._persist_task is None:
            return
        await self._persist_task
        self._persist_task = None

    async def _persist_if_due(self):
        persistence = self.config.get("persistence", {})
        if not persistence.get("enabled"):
            return
        if self._persist_task is not None and self._persist_task.done():
            try:
                await self._persist_task
                self.persistence_last_error = ""
            except BaseException as error:
                self.persistence_last_error = f"{type(error).__name__}: {error}"
            self._persist_task = None
        if (
            self._persist_task is None
            and time.monotonic() - self.last_persist >= float(persistence.get("interval_seconds", 30))
        ):
            self.last_persist = time.monotonic()
            self._persist_task = asyncio.create_task(
                self._persist_snapshot(final=False),
                name=f"data-persistence-{self.config['id']}",
            )

    async def _persist_snapshot(self, final: bool):
        frame = self.store.snapshot()
        counts = self.store.name_summary_frame()
        directory = resolve_project_path(
            self.project_root, self.config["persistence"]["directory"],
        ) / self.config["id"]
        directory.mkdir(parents=True, exist_ok=True)
        suffix = "final" if final else "latest"
        path = directory / f"messages_{suffix}.pkl"
        temporary = path.with_suffix(".tmp.pkl")
        counts_path = directory / f"message_counts_{suffix}.pkl"
        counts_temporary = counts_path.with_suffix(".tmp.pkl")

        def write():
            frame.to_pickle(temporary)
            os.replace(temporary, path)
            counts.to_pickle(counts_temporary)
            os.replace(counts_temporary, counts_path)

        await asyncio.to_thread(write)

    async def run(self):
        while self.running:
            await self._process_commands()
            self._drain_capture()
            self.store.flush_if_due()
            await self._maybe_persist()
            await asyncio.sleep(0.002)
        self._drain_capture(drain_all=True)
        self.store.flush()
        try:
            await self._await_current_persistence()
        except BaseException as error:
            self.persistence_last_error = f"{type(error).__name__}: {error}"
        if self.config.get("persistence", {}).get("enabled") and self.config["persistence"].get("save_on_stop", True):
            await self._persist_snapshot(final=True)
        self._stop_publisher()

    def _replace(self, namespace, members):
        self.registry.replace(namespace, members, {self.config["id"]: {"high_water": self.arrival_sequence}})
        return {**self.registry.status(), "after": self.arrival_sequence}

    def _replace_insights(self, monitors, merge=False, reset_target=None):
        if not merge:
            self.monitors.clear()
        self.monitors.update({str(item["id"]): normalize_protocol_insight_runtime_config(item) for item in monitors})
        members = []
        for monitor in self.monitors.values():
            members.append({"id": f"insight:{self.config['id']}:{monitor['id']}", "kind": "insight",
                            "target": monitor["id"], "sessions": [self.config["id"]],
                            "query": monitor.get("source", {}).get("query", {}), "token": fingerprint(monitor),
                            "_reset_after": monitor["id"] == reset_target})
        return self._replace("insights", members)

    def _publish(self, record):
        self.arrival_sequence += 1
        now = time.time_ns()
        members = self.registry.match(self.config["id"], self.arrival_sequence, record, now)
        if not members:
            return
        encoded = pickle.dumps(record, protocol=5)
        for kind, publisher in (("api", self.api_publisher), ("insight", self.insight_publisher)):
            targets = []
            for member in members:
                if member["kind"] != kind:
                    continue
                target = (kind, member["target"], member.get("token"))
                state = self.replay
                if kind == "insight" and state is not None and member["target"] == state["target"]:
                    if not state["error"]:
                        if len(state["events"]) >= 1024 or state["bytes"] + len(encoded) > 64 * 1024 * 1024:
                            self._fail_replay("Retained replay live buffer overflowed")
                        else:
                            state["events"].append(self._event(encoded, [target]))
                            state["bytes"] += len(encoded)
                    continue
                targets.append(target)
            if targets:
                publisher.publish(self._event(encoded, targets))

    def _event(self, encoded, targets):
        return {"kind": "routed_record", "record_payload": encoded, "targets": targets,
                "source_epoch": self.capture_epoch, "source_sequence": self.arrival_sequence,
                "source": self.config["id"], "registry_revision": self.registry.revision}

    def _fail_replay(self, error):
        state = self.replay
        state.update(error=error, rows=[], events=[])
        self.monitors.pop(state["target"], None)
        for member in list(self.registry.members.values()):
            if member["kind"] == "insight" and member["target"] == state["target"]:
                self.registry.remove(member["id"])

    def _drain_capture(self, **options):
        if self.replay and not self.replay["error"] and time.monotonic() > self.replay["deadline"]:
            self._fail_replay("Retained replay expired")
        return self._drain_input(**options)

    def _status(self, **options):
        api, insights = self.api_publisher.status(), self.insight_publisher.status()
        return {**self._table_status(**options), "storage_backend": "parser_split",
                "message_subscription_publisher": api,
                "protocol_insight_records_published": insights["published"],
                "protocol_insight_records_dropped": insights["dropped"],
                "protocol_insight_publish_errors": insights["errors"],
                "protocol_insight_last_publish_error": insights["last_error"],
                "protocol_insight_publisher_enabled": bool(self.monitors),
                "consumer_service": self.registry.status(), "capture_epoch": self.capture_epoch,
                "arrival_sequence": self.arrival_sequence,
                "capture_active": self.capture_active,
                "read_cache": {"entries": len(self.read_cache), "bytes": self.read_cache_bytes, "hits": self.read_cache_hits},
                "parsed_received_bytes": self.capture_queue.received_bytes,
                "parsed_received_records": self.capture_queue.received_records,
                "routed_delivery": {"api": api, "insights": insights}}

    def _command(self, command, payload):
        if command in {"query", "names", "name_summary", "fields", "delete_preview"}:
            def relative(value):
                if isinstance(value, dict):
                    return str(value.get("operation", "")).lower() == "within_last" or any(relative(item) for item in value.values())
                return isinstance(value, (list, tuple)) and any(relative(item) for item in value)
            if not relative(payload):
                if self.read_cache_version != self.store.version:
                    self.read_cache.clear()
                    self.read_cache_bytes = 0
                    self.read_cache_version = self.store.version
                key = (command, fingerprint(payload))
                if key in self.read_cache:
                    result, size = self.read_cache.pop(key)
                    self.read_cache[key] = (result, size)
                    self.read_cache_hits += 1
                    return result
                result = self._table_command(command, payload)
                size = owned_size(result)
                if size <= 64 * 1024 * 1024:
                    while self.read_cache and (len(self.read_cache) >= 32 or self.read_cache_bytes + size > 64 * 1024 * 1024):
                        _, (_, evicted) = self.read_cache.popitem(last=False)
                        self.read_cache_bytes -= evicted
                    self.read_cache[key] = (result, size)
                    self.read_cache_bytes += size
                return result
        if command == "begin_capture":
            self.capture_queue.reset_epoch(payload["epoch"])
            self.capture_epoch = payload["epoch"]
            self.capture_active = True
            self.last_capture_sequence = self.last_barrier_sequence = 0
            self.sequence_gaps = 0
            return True
        if command == "end_capture":
            self.capture_active = False
            self.store.flush()
            return True
        if command == "drain_delivery":
            for publisher in (self.api_publisher, self.insight_publisher):
                with publisher.queue.all_tasks_done:
                    if not publisher.queue.all_tasks_done.wait_for(lambda: publisher.queue.unfinished_tasks == 0, 10):
                        raise TimeoutError("Routed delivery did not drain")
            if self.insight_destination.ingress is not None:
                self.insight_destination.ingress.flush(timeout=10)
            return True
        if command == "replace_parsed_channel":
            self.capture_queue.close()
            self.capture_queue = ParsedInbox(payload["connection"])
            return True
        if command == "message_subscriptions":
            return self._replace("api", payload.get("members", []))
        if command == "protocol_insight_publisher":
            return self._replace_insights(payload.get("subscriptions", []) if payload.get("enabled") else [],
                                          merge=bool(payload.get("upsert")))
        if command == "rebind_insight":
            old = self.insight_destination.ingress
            self.insight_destination.ingress = payload.get("ingress")
            if old is not None:
                old.close()
            return True
        if command == "replay_prepare":
            if self.replay:
                raise RuntimeError("A retained replay already owns this session")
            monitor = normalize_protocol_insight_runtime_config(payload["monitor"])
            rows, size = [], 0
            self.store.flush()
            for _, row in self.store.frame.iterrows():
                record = copy.deepcopy(row.to_dict())
                size += owned_size(record)
                if size > 64 * 1024 * 1024:
                    raise RuntimeError("Retained replay exceeds its 64 MiB view budget")
                rows.append(record)
            rows.sort(key=lambda row: (row["ingestion_sequence"], row["timestamp_ns"]))
            self._replace_insights([monitor], merge=True, reset_target=monitor["id"])
            self.replay = {"id": str(uuid.uuid4()), "target": monitor["id"], "token": fingerprint(monitor),
                           "query": monitor["source"].get("query", {}), "rows": rows, "position": 0,
                           "now": time.time_ns(), "events": [], "bytes": 0, "error": "",
                           "deadline": time.monotonic() + 120}
            return {"id": self.replay["id"], "token": self.replay["token"]}
        if command in {"replay_page", "replay_finish", "replay_cancel"}:
            state = self.replay
            if state is None or state["id"] != payload["id"]:
                raise RuntimeError("Retained replay is unavailable")
            if command == "replay_cancel":
                self._fail_replay("Retained replay cancelled")
                self.replay = None
                return True
            if state["error"]:
                raise RuntimeError(state["error"])
            if command == "replay_page":
                rows = []
                while state["position"] < len(state["rows"]) and len(rows) < 128:
                    row = state["rows"][state["position"]]
                    state["position"] += 1
                    if RecordEvaluation(row, state["now"]).matches(state["query"]):
                        rows.append(row)
                return {"rows": rows, "done": state["position"] == len(state["rows"])}
            for event in state["events"]:
                before = self.insight_publisher.dropped
                self.insight_publisher.publish(event)
                if before != self.insight_publisher.dropped:
                    self._fail_replay("Replay handoff delivery queue overflowed")
                    raise RuntimeError(self.replay["error"])
            self.replay = None
            return True
        return self._table_command(command, payload)

    def _stop_publisher(self):
        self.api_publisher.close()
        self.insight_publisher.close()

    async def _maybe_persist(self):
        if self.capture_active:
            await self._persist_if_due()


def data_process_entry(control, parsed_connection, config, project_root, initial_state,
                                api_output, insight_ingress, diagnostic):
    try:
        asyncio.run(DataWorker(control, parsed_connection, config, project_root, initial_state,
                                       api_output, insight_ingress).run())
    except BaseException as error:
        diagnostic.put({"backend": "Combined data", "error": f"{type(error).__name__}: {error}",
                        "traceback": traceback.format_exc(), "timestamp_ns": time.time_ns()})
        raise
    finally:
        parsed_connection.close()
        control.close()
