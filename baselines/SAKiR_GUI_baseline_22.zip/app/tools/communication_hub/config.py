from __future__ import annotations

import copy
import re
import uuid
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 2
PROTOCOLS = {"tcp_client", "tcp_server", "serial", "telnet"}


def default_session_config(protocol: str = "tcp_client") -> dict[str, Any]:
    if protocol not in PROTOCOLS:
        raise ValueError(f"Unsupported protocol: {protocol}")
    return {
        "schema_version": SCHEMA_VERSION,
        "id": str(uuid.uuid4()),
        "name": f"New {protocol.replace('_', ' ').title()}",
        "protocol": protocol,
        "protocol_label": "",
        "autostart": False,
        "lifecycle": {
            "scope": "window",
            "restore_last_state": True,
            "last_running_on_close": False,
        },
        "ipc": {
            "io_to_parser": {"queue_capacity": 4096, "overload_policy": "block"},
            "parser_to_processor": {
                "max_pending_records": 4096, "max_pending_bytes": 64 * 1024 * 1024,
                "overload_policy": "block", "batch_records": 128,
                "batch_bytes": 1024 * 1024, "batch_wait_ms": 2,
            },
        },
        "processing": {"batch_records": 512, "time_slice_ms": 8},
        "transport": {
            "host": "127.0.0.1",
            "port": 9000,
            "bind_host": "0.0.0.0",
            "bind_port": 9000,
            "connect_timeout": 5.0,
            "read_chunk_size": 65536,
            "reconnect": False,
            "reconnect_initial_seconds": 1.0,
            "reconnect_max_seconds": 30.0,
            "max_clients": 32,
            "serial_port": "loop://",
            "baudrate": 115200,
            "bytesize": 8,
            "parity": "N",
            "stopbits": 1,
            "read_timeout": 0.05,
            "write_timeout": 1.0,
            "rtscts": False,
            "xonxoff": False,
            "dsrdtr": False,
        },
        "framing": {
            "mode": "raw_chunk",
            "header_size": 0,
            "length_field": {
                "offset": 0,
                "size": 0,
                "endianness": "little",
                "signed": False,
                "meaning": "payload_length",
                "adjustment": 0,
            },
            "header_fields": [],
            "maximum_payload_size": 10 * 1024 * 1024,
            "partial_frame_timeout_ms": 5000,
            "store_partial_frames": True,
        },
        "parser": {
            "enabled": False,
            "source": "python",
            "library_path": "",
            "after_decode": "dict",
            "module": "",
            "use_class": False,
            "class_name": "",
            "function": "",
            "name_key": "Name",
        },
        "storage": {
            "default_conflict_action": "append",
            "conflict_rules": [],
            "ingest_batch_rows": 250,
            "ingest_flush_ms": 50,
            "maximum_rows": 1_000_000,
            "retention": "drop_oldest",
        },
        "persistence": {
            "enabled": False,
            "directory": "app/data/communication_hub/logs",
            "interval_seconds": 30,
            "save_on_stop": True,
        },
    }


def _merge(default: dict, value: dict) -> dict:
    result = copy.deepcopy(default)
    for key, item in value.items():
        if isinstance(item, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], item)
        else:
            result[key] = copy.deepcopy(item)
    return result


def normalize_session_config(value: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("Session configuration must be an object")
    source = copy.deepcopy(value)
    version = source.get("schema_version", 1)
    if type(version) is not int or version not in {1, SCHEMA_VERSION}:
        raise ValueError(f"Unsupported session schema version: {version}")
    for key in ("processing", "storage", "ipc"):
        if key in source and not isinstance(source[key], dict):
            raise ValueError(f"Session {key} settings must be an object")
    processing = source.setdefault("processing", {})
    storage = source.setdefault("storage", {})
    backend = storage.pop("backend", None)
    if backend not in {None, "legacy", "shared_memory", "parser_split"}:
        raise ValueError(f"Unknown retired session backend: {backend}")
    storage.pop("journal_records", None)
    ipc = source.setdefault("ipc", {})
    for key in ("io_to_parser", "parser_to_processor"):
        if key in ipc and not isinstance(ipc[key], dict):
            raise ValueError(f"IPC {key} settings must be an object")
    io = ipc.setdefault("io_to_parser", {})
    for key in ("queue_capacity", "overload_policy"):
        if key in processing:
            io.setdefault(key, processing.pop(key))
    old_stage = processing.pop("parser_stage", {})
    if not isinstance(old_stage, dict):
        raise ValueError("Parser stage settings must be an object")
    stage = ipc.setdefault("parser_to_processor", {})
    for key, item in old_stage.items():
        stage.setdefault(key, item)
    source["schema_version"] = SCHEMA_VERSION
    protocol = str(source.get("protocol", "tcp_client"))
    config = _merge(default_session_config(protocol), source)
    validate_session_config(config)
    return config


def validate_session_config(config: dict[str, Any]) -> None:
    if config.get("protocol") not in PROTOCOLS:
        raise ValueError(f"Unsupported protocol: {config.get('protocol')}")
    if not str(config.get("id", "")).strip():
        raise ValueError("Session id is required")
    if not str(config.get("name", "")).strip():
        raise ValueError("Session name is required")
    lifecycle = config.get("lifecycle", {})
    if not isinstance(lifecycle, dict):
        raise ValueError("Session lifecycle must be an object")
    if lifecycle.get("scope", "window") not in {"window", "application"}:
        raise ValueError("Session lifecycle scope must be window or application")

    def integer(settings, key, minimum=1, maximum=None):
        number = settings[key]
        if type(number) is not int or number < minimum or (maximum is not None and number > maximum):
            raise ValueError(f"{key} must be an integer between {minimum} and {maximum or 'unlimited'}")
    processing = config["processing"]
    integer(processing, "batch_records", maximum=1_000_000)
    integer(processing, "time_slice_ms", maximum=1000)
    ipc = config["ipc"]
    io, stage = ipc["io_to_parser"], ipc["parser_to_processor"]
    integer(io, "queue_capacity", maximum=1_000_000)
    for link in (io, stage):
        if link["overload_policy"] not in {"block", "drop_newest", "drop_oldest"}:
            raise ValueError("IPC overload policy must be block, drop_newest, or drop_oldest")
    for key in ("max_pending_records", "max_pending_bytes", "batch_records", "batch_bytes"):
        integer(stage, key)
    integer(stage, "batch_wait_ms", minimum=0)
    if stage["batch_records"] > stage["max_pending_records"] or stage["batch_bytes"] > stage["max_pending_bytes"]:
        raise ValueError("Parser batch targets must fit pending record/byte limits")

    framing = config["framing"]
    mode = framing.get("mode", "raw_chunk")
    if mode not in {"raw_chunk", "header_length"}:
        raise ValueError("Framing mode must be raw_chunk or header_length")
    maximum = int(framing.get("maximum_payload_size", 0))
    if maximum <= 0:
        raise ValueError("Maximum payload size must be positive")
    if mode == "header_length":
        header_size = int(framing.get("header_size", 0))
        length = framing.get("length_field") or {}
        offset, size = int(length.get("offset", -1)), int(length.get("size", 0))
        if header_size <= 0:
            raise ValueError("Header size must be positive")
        if offset < 0 or size <= 0 or offset + size > header_size:
            raise ValueError("Length field must be fully inside the header")
        if length.get("endianness") not in {"little", "big"}:
            raise ValueError("Length endianness must be little or big")
        if length.get("meaning") not in {"payload_length", "total_frame_length"}:
            raise ValueError("Length meaning is invalid")
        names = set()
        occupied = set()
        for field in framing.get("header_fields", []):
            name = str(field.get("name", "")).strip()
            if not name:
                raise ValueError("Every decoded header field requires a name")
            if name in names:
                raise ValueError(f"Decoded header field name '{name}' is duplicated")
            names.add(name)
            field_offset = int(field.get("offset", -1))
            field_size = int(field.get("size", 0))
            if field_offset < 0 or field_size <= 0 or field_offset + field_size > header_size:
                raise ValueError(f"Header field '{name}' is outside the header")
            region = set(range(field_offset, field_offset + field_size))
            if occupied.intersection(region):
                raise ValueError(f"Header field '{name}' overlaps another decoded header field")
            occupied.update(region)
            field_type = field.get("type", "uint")
            if field_type not in {"uint", "int", "bytes", "text"}:
                raise ValueError(f"Header field '{name}' has unsupported type '{field_type}'")
            if field_type in {"uint", "int"} and field.get("endianness", "little") not in {"little", "big"}:
                raise ValueError(f"Header field '{name}' endianness must be little or big")

    parser = config.get("parser", {})
    source = parser.get("source", "python")
    if source not in {"python", "message_designer"}:
        raise ValueError("Parser source must be python or message_designer")
    if parser.get("after_decode", "dict") not in {"dict", "object", "none"}:
        raise ValueError("Library after_decode must be dict, object, or none")
    if source == "message_designer":
        if not isinstance(parser.get("library_path", ""), str):
            raise ValueError("Library parser folder must be text")
        if parser.get("enabled") and not parser.get("library_path", "").strip():
            raise ValueError("Enabled library parser requires a Message Designer library folder")
    if source == "python" and parser.get("enabled") and not (parser.get("module") and parser.get("function")):
        raise ValueError("Enabled parser requires module and function")
    if not isinstance(parser.get("use_class", False), bool):
        raise ValueError("Parser use_class must be true or false")
    if source == "python" and parser.get("enabled") and parser.get("use_class") and not str(parser.get("class_name", "")).strip():
        raise ValueError("Class-based parser requires a class name")

    storage = config.get("storage", {})
    actions = {"append", "update", "ignore"}
    if storage.get("default_conflict_action", "append") not in actions:
        raise ValueError("Default storage behavior must be append, update, or ignore")
    if int(storage.get("ingest_batch_rows", 0)) <= 0:
        raise ValueError("Storage batch size must be positive")
    if int(storage.get("ingest_flush_ms", 0)) < 0:
        raise ValueError("Storage maximum batch wait cannot be negative")
    if int(storage.get("maximum_rows", 0)) < 0:
        raise ValueError("Maximum retained rows cannot be negative")
    if storage.get("retention", "drop_oldest") not in {"drop_oldest", "drop_newest"}:
        raise ValueError("Storage retention must discard oldest or newest rows")
    rules = storage.get("conflict_rules", [])
    if not isinstance(rules, list):
        raise ValueError("Storage conflict rules must be a list")
    for index, rule in enumerate(rules, 1):
        if not isinstance(rule, dict):
            raise ValueError(f"Storage conflict rule {index} must be an object")
        if rule.get("direction") not in {None, "", "RX", "TX"}:
            raise ValueError(f"Storage conflict rule {index} direction must be RX or TX")
        if "parsed" in rule and not isinstance(rule["parsed"], bool):
            raise ValueError(f"Storage conflict rule {index} parsed condition must be true or false")
        matcher = rule.get("name_match") or {}
        if not isinstance(matcher, dict):
            raise ValueError(f"Storage conflict rule {index} name matcher must be an object")
        match_type = matcher.get("type", "exact")
        if matcher and match_type not in {"exact", "contains", "prefix", "regex"}:
            raise ValueError(f"Storage conflict rule {index} has an unsupported name matcher")
        if matcher and not isinstance(matcher.get("value", ""), str):
            raise ValueError(f"Storage conflict rule {index} name-match value must be text")
        if matcher and match_type == "regex":
            try:
                re.compile(matcher.get("value", ""))
            except re.error as error:
                raise ValueError(f"Storage conflict rule {index} regular expression is invalid: {error}") from error
        action = rule.get("action", "append")
        if action not in actions:
            raise ValueError(f"Storage conflict rule {index} action must be append, update, or ignore")
        if action == "update":
            key = rule.get("key", ["direction", "name"])
            if not isinstance(key, list) or not key or any(not isinstance(field, str) or not field.strip() for field in key):
                raise ValueError(f"Storage conflict rule {index} update identity must contain one or more field names")

    persistence = config.get("persistence", {})
    if persistence.get("enabled") and int(persistence.get("interval_seconds", 0)) <= 0:
        raise ValueError("Persistence interval must be positive")
    if persistence.get("enabled") and not str(persistence.get("directory", "")).strip():
        raise ValueError("Persistence snapshot directory is required")


def resolve_project_path(project_root: str | Path, configured: str) -> Path:
    path = Path(configured)
    return path if path.is_absolute() else Path(project_root) / path
