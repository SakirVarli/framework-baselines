"""Retained replay adapter shared by UI and callback APIs."""
from __future__ import annotations


def replay_retained(hub, monitor, sessions):
    controllers = [(session, hub.controllers.get(str(session["id"]))) for session in sessions]
    available = [(session, controller) for session, controller in controllers if controller and controller.table_available]
    return replay_processor(hub, monitor, available)


def replay_processor(hub, monitor, available):
    import heapq
    tickets = {}
    request = hub._protocol_insight_service_request
    try:
        for session, controller in available:
            tickets[session["id"]] = controller.request("replay_prepare", {"monitor": monitor}, timeout=60)
        def records(session, controller):
            ticket = tickets[session["id"]]
            while True:
                page = controller.request("replay_page", {"id": ticket["id"]}, timeout=60)
                for row in page["rows"]:
                    row.setdefault("session_name", session.get("name", ""))
                    yield row
                if page["done"]:
                    return
        count, batch = 0, []
        for row in heapq.merge(*(records(session, controller) for session, controller in available),
                              key=lambda row: (row["ingestion_sequence"], row["timestamp_ns"])):
            batch.append(row)
            if len(batch) == 128:
                count += request("replay_chunk", {"protocol_insight_id": monitor["id"], "records": batch,
                    "route_token": next(iter(tickets.values()))["token"]}, timeout=120)
                batch = []
        if batch:
            count += request("replay_chunk", {"protocol_insight_id": monitor["id"], "records": batch,
                "route_token": next(iter(tickets.values()))["token"]}, timeout=120)
        request("replay_finish", {"protocol_insight_id": monitor["id"]}, timeout=120)
        for session, controller in available:
            controller.request("replay_finish", {"id": tickets[session["id"]]["id"]})
        return count
    except BaseException:
        for session, controller in available:
            if session["id"] in tickets:
                try:
                    controller.request("replay_cancel", {"id": tickets[session["id"]]["id"]})
                except (RuntimeError, TimeoutError, OSError, EOFError):
                    pass
        raise
