"""Shared pure predicate evaluation with existing Hub query semantics."""
from __future__ import annotations

import copy
import hashlib
import pickle

import pandas as pd

from .query import QueryEngine


ALIASES = {"eq": "equals", "exact": "equals", "ne": "not_equals", "not_null": "exists",
           "is_null": "missing", "greater_than": "gt", "after": "gt", "less_than": "lt",
           "before": "lt", "greater_or_equal": "gte", "less_or_equal": "lte"}


def canonical(value):
    if isinstance(value, dict):
        return ("dict", tuple(sorted((canonical(key), canonical(item)) for key, item in value.items())))
    if isinstance(value, (list, tuple)):
        return (type(value).__name__, tuple(canonical(item) for item in value))
    if isinstance(value, set):
        return ("set", tuple(sorted(canonical(item) for item in value)))
    return (f"{type(value).__module__}.{type(value).__qualname__}", pickle.dumps(value, protocol=5))


def normalize_query(query):
    query = copy.deepcopy(query or {})
    if not query:
        return {}
    if "conditions" in query:
        query["operator"] = str(query.get("operator", "and")).lower()
        query["conditions"] = [normalize_query(item) for item in query["conditions"]]
    else:
        operation = str(query.get("operation", "equals")).lower()
        query["operation"] = ALIASES.get(operation, operation)
    return query


def fingerprint(value):
    return hashlib.sha256(pickle.dumps(canonical(value), protocol=5)).hexdigest()


class RecordEvaluation(QueryEngine):
    def __init__(self, record, now):
        self.frame = pd.DataFrame([record])
        self.now = now
        self.nodes = {}
        self.fields = {}
        self.evaluations = 0

    def _series(self, frame, field):
        if field not in self.fields:
            self.fields[field] = super()._series(frame, field)
        return self.fields[field]

    def _node(self, frame, node, now):
        key = fingerprint(node)
        if key not in self.nodes:
            self.evaluations += 1
            self.nodes[key] = super()._node(frame, node, now)
        return self.nodes[key]

    def matches(self, query):
        if not query:
            return True
        return bool(self._node(self.frame, query, self.now).iloc[0])
