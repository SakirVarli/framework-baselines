"""Consumer-service registry; delivery settings never duplicate matching work."""
from __future__ import annotations

from .query_plan import fingerprint, normalize_query, RecordEvaluation


class SubscriptionRegistry:
    def __init__(self):
        self.members = {}
        self.groups = {}
        self.revision = 0
        self.evaluations = self.records = self.filter_errors = 0
        self.last_error = ""

    def replace(self, namespace, members, sources):
        proposed = {key: value for key, value in self.members.items() if value["namespace"] != namespace}
        for member in members:
            reset_after = member.get("_reset_after", False)
            query = normalize_query(member.get("query"))
            member = dict(member, namespace=namespace, query=query, group=fingerprint(query))
            member["after"] = dict(member.get("after") or {
                source: info["high_water"] for source, info in sources.items()
            })
            previous = self.members.get(member["id"])
            member.pop("_reset_after", None)
            if not reset_after and previous is not None and previous["group"] == member["group"] and previous.get("sessions") == member.get("sessions") and previous.get("token") == member.get("token"):
                member["after"] = previous["after"]
            proposed[member["id"]] = member
        self.members = proposed
        self.groups = {member["group"]: member["query"] for member in proposed.values()}
        self.revision += 1

    def remove(self, member_id):
        self.members.pop(member_id, None)
        self.groups = {member["group"]: member["query"] for member in self.members.values()}
        self.revision += 1

    def match(self, session_id, sequence, record, now):
        relevant = [member for member in self.members.values()
                    if (member.get("sessions") is None or session_id in member["sessions"])
                    and sequence > member["after"].get(session_id, 0)]
        if not relevant:
            return []
        context = RecordEvaluation(record, now)
        results = {}
        for member in relevant:
            key = member["group"]
            if key not in results:
                try:
                    results[key] = context.matches(self.groups[key])
                except Exception as error:
                    self.filter_errors += 1
                    self.last_error = f"{type(error).__name__}: {error}"
                    results[key] = False
        self.records += 1
        self.evaluations += context.evaluations
        return [member for member in relevant if results[member["group"]]]

    def status(self):
        return {"consumers": len(self.members), "groups": len(self.groups), "revision": self.revision,
                "records": self.records, "predicate_evaluations": self.evaluations,
                "filter_errors": self.filter_errors, "last_error": self.last_error}
