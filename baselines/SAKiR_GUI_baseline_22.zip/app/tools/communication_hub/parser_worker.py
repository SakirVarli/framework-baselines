"""Stateful complete-message parser host. No DataFrame or consumer predicates."""
from __future__ import annotations

import copy
import pickle
import queue
import time
import traceback
from dataclasses import replace

from .capture_parser import parse_capture
from .framing import FrameDecoder
from .parser_runtime import ParserRuntime
from .pipeline_channel import ParsedPublisher


def parser_process_entry(control, capture, output, config, project_root, epoch, diagnostic):
    publisher = None
    try:
        parser = ParserRuntime(config["parser"], project_root=project_root)
        decoder = FrameDecoder(config["framing"])
        settings = config["ipc"]["parser_to_processor"]
        publisher = ParsedPublisher(output, settings, epoch)
        records, size, first = [], 0, 0.
        processed = last_sequence = last_barrier = 0
        stop_request = None

        def status():
            handoff = {**publisher.status(), "parsed_records": processed,
                       "last_capture_sequence": last_sequence, "last_barrier_sequence": last_barrier}
            return {"parser_records_processed": processed, "parser_last_capture_sequence": last_sequence,
                    "parser_last_barrier_sequence": last_barrier, "parser_handoff": handoff,
                    "ipc": {"parser_to_processor": handoff}}

        def service_control():
            nonlocal stop_request
            while control.poll():
                request = control.recv()
                command = request["command"]
                if command in {"ping", "status"}:
                    control.send({"id": request["id"], "ok": True, "result": status()})
                elif command == "stop" and stop_request is None:
                    stop_request = request
                else:
                    control.send({"id": request["id"], "ok": False, "error": f"Unsupported/busy parser command: {command}"})

        def flush():
            nonlocal records, size, first
            if records:
                publisher.publish(records, service_control)
                records, size, first = [], 0, 0.

        while True:
            service_control()
            if stop_request is not None:
                request, stop_request = stop_request, None
                try:
                    flush()
                    required = request.get("payload", {}).get("capture_sequence", 0)
                    if required and last_barrier < required:
                        raise RuntimeError("Parser did not observe the required final barrier")
                    publisher.drain(10, service_control)
                    control.send({"id": request["id"], "ok": True, "result": status()})
                    break
                except Exception as error:
                    control.send({"id": request["id"], "ok": False, "error": f"{type(error).__name__}: {error}"})
            publisher._check()
            try:
                envelope = capture.get(timeout=.001)
            except queue.Empty:
                if records and time.monotonic() - first >= settings["batch_wait_ms"] / 1000:
                    flush()
                continue
            last_sequence = int(envelope.get("capture_sequence", 0))
            if envelope.get("kind") == "barrier":
                flush()
                envelope["ipc_outcome"] = {"io_to_parser": envelope.get("ipc_outcome", {}),
                                           "parser_to_processor": status()["parser_handoff"]}
                publisher.publish([envelope], service_control)
                last_barrier = last_sequence
                continue
            event, parsed, error = parse_capture(envelope, config, parser, decoder)
            event = replace(event, message_size=len(event.message), message=b"")
            record = {"kind": "parsed", "event": event, "parsed": copy.deepcopy(parsed),
                      "header_error": error, "capture_sequence": last_sequence}
            record_size = len(pickle.dumps(record, protocol=5))
            if records and (size + record_size > settings["batch_bytes"] or len(records) >= settings["batch_records"]):
                flush()
            if not records:
                first = time.monotonic()
            records.append(record)
            size += record_size
            processed += 1
            if (len(records) >= settings["batch_records"] or size >= settings["batch_bytes"] or
                    time.monotonic() - first >= settings["batch_wait_ms"] / 1000):
                flush()
    except BaseException as error:
        diagnostic.put({"backend": "Parser", "error": f"{type(error).__name__}: {error}",
                        "traceback": traceback.format_exc(), "timestamp_ns": time.time_ns(),
                        "capture_sequence": locals().get("last_sequence", 0)})
        raise
    finally:
        if publisher:
            publisher.close()
        else:
            output.close()
        control.close()
