"""The common complete-message parsing transformation, without storage work."""
from __future__ import annotations

import time

from .parser_runtime import Direction, ParseResult
from .store import EventInput


def parse_capture(envelope, config, parser, tx_header_decoder):
    direction = Direction(str(envelope.get("direction", "RX")))
    message = bytes(envelope.get("message", b""))
    header = bytes(envelope.get("header", b""))
    fields = dict(envelope.get("header_fields", {}))
    metadata_error = ""
    if direction == Direction.TX and envelope.get("kind") != "framing_error" and tx_header_decoder.mode == "header_length":
        header = message[:tx_header_decoder.header_size]
        fields = {}
        try:
            fields = tx_header_decoder.decode_header_fields(header)
        except Exception as error:
            metadata_error = f"TX header decoding failed: {type(error).__name__}: {error}"[:1000]
    if envelope.get("kind") == "framing_error":
        parsed = ParseResult("FramingError", message, False, "error", error=str(envelope.get("error", "Framing error")))
    else:
        parsed = parser.parse(message, direction)
    event = EventInput(
        timestamp_ns=int(envelope.get("timestamp_ns", time.time_ns())),
        completed_timestamp_ns=int(envelope.get("completed_timestamp_ns", envelope.get("timestamp_ns", time.time_ns()))),
        capture_sequence=int(envelope.get("capture_sequence", 0)), direction=direction,
        protocol=config["protocol"], protocol_label=config.get("protocol_label", ""),
        message=message, header=header, header_fields=fields, session_id=config["id"],
        connection_id=str(envelope.get("connection_id", "")), peer=str(envelope.get("peer", "")))
    return event, parsed, metadata_error
