"""Explicit, atomic transfers between routing assignments and constructor defaults.

This module never imports generated libraries or evaluates developer expressions.
Plans are tied to a manifest snapshot so the UI cannot apply a stale preview.
"""
from __future__ import annotations

import ast
import copy
import math
import struct
from collections import Counter
from dataclasses import dataclass, field as dataclass_field, replace

from construct import ConstructError, PaddedString

from app.binary_messages.compiled_routing import Identifier
from .generation import _automatic_object_default
from .object_defaults import guided_errors, guided_expression
from .routing_model import owners_by_uid, parent_owner
from .routing_paths import routing_field_options, routing_messages
from .validation import validate_manifest


TRANSFER_ERRORS = (ValueError, TypeError, KeyError, OverflowError, LookupError, SyntaxError,
                   StopIteration, ConstructError, struct.error)


@dataclass
class DefaultTransferRow:
    key: tuple[str, str]
    assignment: str
    identifier: str
    path: str
    before: str = ''
    after: str = ''
    messages: str = ''
    error: str = ''
    skipped: bool = False


@dataclass
class DefaultTransferPlan:
    base: dict
    selected_uid: str
    direction: str
    rows: list[DefaultTransferRow] = dataclass_field(default_factory=list)
    result: dict | None = None
    errors: list[str] = dataclass_field(default_factory=list)

    def apply(self, manifest):
        if manifest != self.base:
            raise ValueError('The definitions or routing values changed. Open a new transfer preview.')
        if self.result is None or self.errors:
            raise ValueError('\n'.join(self.errors) or 'Select at least one field identifier to transfer.')
        return copy.deepcopy(self.result)


def _objects(manifest):
    return {item['uid']: item for item in [manifest['library'], *manifest.get('groups', []),
                                         *manifest.get('messages', [])]}


def _children(field, manifest):
    if field['kind'] == 'inline_struct':
        return field.get('fields', [])
    if field['kind'] == 'struct':
        return next(item for item in manifest.get('structures', [])
                    if item['uid'] == field.get('struct_uid'))['fields']
    raise ValueError(f"{field['name']} is not a structure")


def _chain(message, path, manifest):
    fields, chain = message.get('fields', []), []
    parts = path.split('.')
    for index, part in enumerate(parts):
        matches = [item for item in fields if item.get('name') == part]
        if len(matches) != 1:
            raise ValueError(f"Field '{path}' is missing or ambiguous in {message['name']}")
        chain.append(matches[0])
        if index < len(parts) - 1:
            fields = _children(matches[0], manifest)
    return chain


def _literal(expression, field, manifest):
    while field.get('kind') in {'const', 'default', 'rebuild'}:
        field = field['item']
    try:
        return ast.literal_eval(expression)
    except (ValueError, SyntaxError):
        tree = ast.parse(expression, mode='eval').body
        if field.get('kind') == 'enum' and isinstance(tree, ast.Attribute) and isinstance(tree.value, ast.Name):
            enum = next(item for item in manifest.get('enums', []) if item['uid'] == field.get('enum_uid'))
            if tree.value.id == enum['name']:
                member = next((item for item in enum['values'] if item['name'] == tree.attr), None)
                if member is not None:
                    return member['value']
        raise ValueError('This Python expression cannot be read safely. Use a Guided default.')


def _from_value(field, value, manifest):
    kind = field['kind']
    if kind in {'const', 'default', 'rebuild'}:
        return {'kind': 'wrapped', 'value': _from_value(field['item'], value, manifest)}
    if kind == 'enum':
        enum = next(item for item in manifest['enums'] if item['uid'] == field['enum_uid'])
        member = next((item for item in enum['values'] if item['value'] == value or item['name'] == value), None)
        if member is None:
            raise ValueError('The expected number has no named enum member for a Guided default.')
        return {'kind': 'enum', 'enum_uid': enum['uid'], 'value_uid': member['uid']}
    if kind == 'bytes':
        if not isinstance(value, bytes):
            raise ValueError('The field default must be bytes.')
        if len(value) > 65536:
            raise ValueError('Guided byte transfers support at most 65,536 bytes.')
        return {'kind': 'bytes', 'hex': value.hex()}
    node_kind = {'uint': 'integer', 'int': 'integer', 'bytes_integer': 'integer',
                 'float': 'float', 'bool': 'bool', 'string': 'string'}.get(kind)
    if node_kind is None:
        raise ValueError(f'Guided routing transfers are unavailable for {kind}.')
    if kind == 'float' and not math.isfinite(float(value)):
        raise ValueError('Non-finite floats cannot be preserved by the Guided Python default.')
    return {'kind': node_kind, 'value': value}


def _value(field, node, manifest):
    errors = guided_errors(field, node, manifest)
    if errors:
        raise ValueError('; '.join(errors))
    kind = field['kind']
    if kind in {'const', 'default', 'rebuild'}:
        return _value(field['item'], node['value'], manifest)
    if kind == 'bytes':
        return bytes.fromhex(node['hex'])
    if kind == 'enum':
        enum = next(item for item in manifest['enums'] if item['uid'] == field['enum_uid'])
        return next(item['value'] for item in enum['values'] if item['uid'] == node['value_uid'])
    value = node['value']
    if kind in {'uint', 'int', 'bytes_integer'} and isinstance(value, str):
        try: value = int(value, 0)
        except ValueError: value = int(value, 10)
    if kind == 'float':
        value = float(value)
        if not math.isfinite(value):
            raise ValueError('Non-finite floats cannot be preserved by the Guided Python default.')
    return value


def _wire_default(field, manifest):
    if field.get('wire_value_mode') == 'guided':
        return _value(field['item'], field.get('wire_value'), manifest)
    return _literal(field.get('value', '0'), field['item'], manifest)


def _default_node(field, manifest):
    mode = field.get('object_default_mode', 'required')
    if mode == 'required':
        raise ValueError(f"{field['name']} is Required and has no constructor default.")
    if mode == 'guided':
        return copy.deepcopy(field.get('object_default_value'))
    if mode == 'custom':
        return _from_value(field, _literal(field.get('object_default', ''), field, manifest), manifest)
    if mode != 'automatic':
        raise ValueError('Unknown constructor default mode.')
    if field['kind'] in {'struct', 'inline_struct'}:
        return _struct_node(field, manifest)
    if field['kind'] in {'const', 'default'}:
        return _from_value(field, _wire_default(field, manifest), manifest)
    if field['kind'] == 'rebuild':
        return {'kind': 'wrapped', 'value': _default_node(field['item'], manifest)}
    if field['kind'] == 'bytes':
        if field.get('mode') != 'fixed':
            raise ValueError('The byte default length is not statically known.')
        # Same fixed-size value as generation's bytes(length), including resolve initialization.
        length = field.get('length', 0)
        if type(length) is not int or not 0 <= length <= 65536:
            raise ValueError('The byte default exceeds the guided transfer limit of 65,536 bytes.')
        return _from_value(field, bytes(length), manifest)
    enums = {item['uid']: item for item in manifest.get('enums', [])}
    structures = {item['uid']: item for item in manifest.get('structures', [])}
    expression, factory = _automatic_object_default(field, 'Owner', enums, structures)
    if factory:
        raise ValueError('The automatic default is not statically readable.')
    return _from_value(field, _literal(expression, field, manifest), manifest)


def _struct_node(field, manifest):
    if field.get('object_default_mode') == 'guided':
        node = copy.deepcopy(field.get('object_default_value'))
        if not isinstance(node, dict) or node.get('kind') != field['kind']:
            raise ValueError(f"{field['name']} has an invalid Guided structure default.")
        return node
    if field.get('object_default_mode') == 'custom':
        raise ValueError(f"{field['name']} has a custom structure expression. Convert it to Guided first.")
    return {'kind': field['kind'], 'fields': [
        {'field_uid': child['uid'], 'source': 'default', 'value': None}
        for child in _children(field, manifest) if child.get('kind') != 'padding']}


def _assignment(node, child):
    if not isinstance(node, dict) or not isinstance(node.get('fields'), list) or any(
            not isinstance(item, dict) for item in node['fields']):
        raise ValueError('The containing Guided structure default has invalid field assignments.')
    matches = [item for item in node['fields'] if item.get('field_uid') == child['uid']]
    if len(matches) != 1:
        raise ValueError(f"{child['name']} is missing or duplicated in the containing Guided default.")
    return matches[0]


def _effective_node(chain, manifest):
    node = _default_node(chain[0], manifest)
    for child in chain[1:]:
        assignment = _assignment(node, child)
        node = (_default_node(child, manifest) if assignment.get('source') == 'default'
                else copy.deepcopy(assignment.get('value')))
    return node


def _set_node(chain, value, manifest):
    root = chain[0]
    if len(chain) == 1:
        node = value
    else:
        node = _struct_node(root, manifest)
        current = node
        for index, child in enumerate(chain[1:], 1):
            assignment = _assignment(current, child)
            if index == len(chain) - 1:
                assignment.update(source='explicit', value=copy.deepcopy(value))
            else:
                nested = (_struct_node(child, manifest) if assignment.get('source') == 'default'
                          else copy.deepcopy(assignment.get('value')))
                if not isinstance(nested, dict):
                    raise ValueError(f"{child['name']} has no valid structure default.")
                assignment.update(source='explicit', value=nested)
                current = nested
    root.update(object_default_mode='guided', object_default_value=node, object_default='')


def _identifier(manifest, message, definition):
    if definition.get('source', 'raw') != 'field':
        raise ValueError('Raw byte identifiers cannot pull or push defaults.')
    if definition.get('mask') is not None or definition.get('shift', 0):
        raise ValueError('Masked or shifted identifiers have no unambiguous default transfer.')
    # Resolve against this concrete message, including excluded draft messages.
    scope = {**manifest, 'messages': [message]}
    options = {item['path']: item for item in routing_field_options(scope)}
    path = definition.get('field_path', '')
    if path not in options:
        raise ValueError(f"{message['name']}.{path or '?'} has no supported static field layout.")
    option = options[path]
    settings = {key: value for key, value in option.items() if key not in {'path', 'width'}}
    return Identifier(uid=definition['uid'], name=definition['name'], **settings)


def _wire(field, node, identifier, manifest):
    value = _value(field, node, manifest)
    current = field
    while current['kind'] in {'const', 'default', 'rebuild'}:
        if current['kind'] == 'const':
            fixed = _from_value(current['item'], _wire_default(current, manifest), manifest)
            if _wire(current['item'], fixed, identifier, manifest) != _wire(current['item'], node['value'], identifier, manifest):
                raise ValueError('The Python default conflicts with the Const wire value.')
        if current['kind'] == 'rebuild':
            computed = _literal(current.get('expression', ''), current['item'], manifest)
            rebuilt = _from_value(current['item'], computed, manifest)
            if _wire(current['item'], rebuilt, identifier, manifest) != _wire(current['item'], node['value'], identifier, manifest):
                raise ValueError('Rebuild replaces the Python default with a different wire value.')
        node, current = node['value'], current['item']
    if current['kind'] == 'string':
        return PaddedString(identifier.length, current.get('encoding', 'utf8')).build(value)
    # Field descriptors use unmasked storage. Never treat a routing key as raw field bits.
    return identifier.encode(value)


def _expected_value(identifier, raw):
    if identifier.type == 'float':
        return {'hex': raw.hex()}
    if identifier.type == 'bytes':
        return raw.hex()
    if identifier.type == 'text':
        value = identifier.decode(raw)
        if identifier.encode(value) != raw:
            raise ValueError('The text default cannot be represented losslessly by this routing identifier.')
        return value
    return identifier.decode(raw)


def _push_value(field, expected, identifier, manifest):
    raw = identifier.encode(expected)
    value = identifier.decode(raw)
    if identifier.type == 'bytes':
        value = raw
    node = _from_value(field, value, manifest)
    if identifier.key_bytes(_wire(field, node, identifier, manifest)) != identifier.key_bytes(raw):
        raise ValueError('The Guided Python default cannot preserve the expected wire value.')
    return node


def _checks(manifest, selected):
    owners = owners_by_uid(manifest)
    seen = set()
    current = selected
    while current['uid'] != manifest['library']['uid']:
        if current['uid'] in seen:
            raise ValueError('Circular routing ancestry.')
        seen.add(current['uid'])
        parent = parent_owner(manifest, current)
        if parent is None or parent['uid'] not in owners:
            raise ValueError('Missing routing parent.')
        for definition in parent.get('identifiers', []):
            yield current, definition
        current = parent


def _messages(manifest, selected):
    if selected['uid'] in {item['uid'] for item in manifest.get('messages', [])}:
        return [selected]
    return routing_messages(manifest, selected)


def _blocking(manifest):
    return Counter((issue.code, issue.uid, issue.message) for issue in validate_manifest(manifest) if issue.blocking)


def _current_description(message, path, manifest):
    chain = _chain(message, path, manifest)
    field = chain[-1]
    mode = chain[0].get('object_default_mode', 'required')
    try:
        enums = {item['uid']: item for item in manifest.get('enums', [])}
        structures = {item['uid']: item for item in manifest.get('structures', [])}
        expression = guided_expression(field, _effective_node(chain, manifest), message['name'], enums, structures)
    except TRANSFER_ERRORS:
        expression = (field.get('object_default', '') if field.get('object_default_mode') == 'custom'
                      else 'no safely readable default')
    return f"{message['name']}.{path}: {mode} ({expression})"


def plan_default_transfer(manifest, selected_uid, direction, selected_keys=None):
    """Preview a selected batch. Any eligible failure leaves the whole batch unapplied.

    Keys are (assignment-owner UID, identifier UID), including inherited checks.
    Raw rows are always reported as skipped and cannot be explicitly selected.
    """
    if direction not in {'pull', 'push'}:
        raise ValueError('Choose pull or push.')
    base = copy.deepcopy(manifest)
    plan = DefaultTransferPlan(base, selected_uid, direction)
    after = copy.deepcopy(manifest)
    objects = _objects(after)
    base_objects = _objects(base)
    if selected_uid not in objects:
        raise ValueError('Select an existing routing group or message.')
    selected = objects[selected_uid]
    selected_keys = None if selected_keys is None else set(selected_keys)
    writes, touched, previews, count = {}, {}, {}, 0
    try:
        checks = list(_checks(after, selected))
    except TRANSFER_ERRORS as error:
        plan.errors.append(str(error))
        return plan
    known_keys = {(item['uid'], definition['uid']) for item, definition in checks}
    if selected_keys is not None and selected_keys - known_keys:
        plan.errors.append('The selected identifiers changed. Open a new transfer preview.')
    for assignment_owner, definition in checks:
        key = (assignment_owner['uid'], definition['uid'])
        row = DefaultTransferRow(key, assignment_owner.get('name', 'Group'), definition.get('name', ''),
                                 definition.get('field_path', ''))
        plan.rows.append(row)
        if definition.get('source', 'raw') != 'field':
            row.skipped = True
            row.error = 'Raw byte identifiers cannot pull or push defaults.'
            if selected_keys is not None and key in selected_keys:
                plan.errors.append(row.error)
            continue
        if selected_keys is not None and key not in selected_keys:
            continue
        count += 1
        messages = _messages(after, assignment_owner if direction == 'pull' else selected)
        row.messages = ', '.join(message['name'] for message in messages)
        expected = (assignment_owner.get('expected_values') or {}).get(definition['uid'])
        row.before = repr(expected) if direction == 'pull' else ''
        try:
            if not messages:
                raise ValueError('There are no descendant messages to transfer.')
            values, layouts, old = [], [], []
            failures = []
            for message in messages:
                try:
                    identifier = _identifier(after, message, definition)
                    layouts.append(replace(identifier, uid='layout', name='layout'))
                    chain = _chain(message, row.path, after)
                    field = chain[-1]
                    if direction == 'pull':
                        node = _effective_node(chain, after)
                        raw = _wire(field, node, identifier, after)
                        value = _expected_value(identifier, raw)
                        values.append((identifier.key_bytes(identifier.encode(value)), value, message['name']))
                    else:
                        if expected is None:
                            raise ValueError('The expected value is unassigned.')
                        node = _push_value(field, expected, identifier, after)
                        destination = (message['uid'], tuple(item['uid'] for item in chain))
                        raw = _wire(field, node, identifier, after)
                        if destination in writes and writes[destination] != raw:
                            raise ValueError('Selected identifiers write incompatible defaults to the same field.')
                        writes[destination] = raw
                        old.append(_current_description(base_objects[message['uid']], row.path, base))
                        _set_node(chain, node, after)
                        touched[(message['uid'], chain[0]['uid'])] = chain[0]
                        previews.setdefault(key, []).append((message['uid'], chain[0]['uid']))
                except TRANSFER_ERRORS as error:
                    failures.append(f"{message['name']}: {error}")
            if failures:
                raise ValueError('\n'.join(failures))
            if any(layout != layouts[0] for layout in layouts[1:]):
                raise ValueError('Descendant fields do not share the same static wire layout.')
            if direction == 'pull':
                if any(value[0] != values[0][0] for value in values[1:]):
                    raise ValueError('Descendant defaults disagree: ' + ', '.join(f'{name}={value!r}' for _, value, name in values))
                value = values[0][1]
                # Keep an existing equivalent spelling (enum names, float literals,
                # hex notation) instead of treating normalization as a value edit.
                if expected is not None:
                    try:
                        if identifier.key_bytes(identifier.encode(expected)) == values[0][0]:
                            value = expected
                    except TRANSFER_ERRORS:
                        pass
                assignment_owner['expected_values'] = {**(assignment_owner.get('expected_values') or {}), definition['uid']: value}
                row.after = repr(value) + (' (assign route)' if base_objects[assignment_owner['uid']].get('expected_values') is None else '')
                if expected != value:
                    assignment_owner.get('expected_value_texts', {}).pop(definition['uid'], None)
            else:
                row.before = '\n'.join(old)
        except TRANSFER_ERRORS as error:
            row.error = str(error)
            plan.errors.append(f'{row.assignment}.{row.identifier}: {error}')
    # Several identifiers can update one containing struct. Show the final merged
    # constructor in every affected row, not intermediate expressions from the loop.
    enums = {item['uid']: item for item in after.get('enums', [])}
    structures = {item['uid']: item for item in after.get('structures', [])}
    for row in plan.rows:
        proposed = []
        for message_uid, field_uid in previews.get(row.key, []):
            message = objects[message_uid]
            field = touched[(message_uid, field_uid)]
            try:
                expression = guided_expression(field, field['object_default_value'], message['name'], enums, structures)
                proposed.append(f"{message['name']}.{field['name']} = {expression}")
            except TRANSFER_ERRORS as error:
                row.error = str(error)
                plan.errors.append(f'{row.assignment}.{row.identifier}: {error}')
        if proposed:
            row.after = '\n'.join(proposed)
    if count and not plan.errors:
        for field in touched.values():
            plan.errors.extend(guided_errors(field, field.get('object_default_value'), after))
        if not plan.errors:
            try:
                new_errors = _blocking(after) - _blocking(base)
                plan.errors.extend(message for (_, _, message), _count in new_errors.items())
            except TRANSFER_ERRORS as error:
                plan.errors.append(str(error))
        if not plan.errors:
            plan.result = after
    return plan
