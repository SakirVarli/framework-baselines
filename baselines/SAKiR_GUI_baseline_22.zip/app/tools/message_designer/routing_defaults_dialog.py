"""Review and select a batch of routing/default transfers before committing it."""
from PyQt5 import QtCore, QtWidgets

from .routing_defaults import plan_default_transfer


class RoutingDefaultsDialog(QtWidgets.QDialog):
    def __init__(self, manifest, selected_uid, direction, parent=None):
        super().__init__(parent)
        self.manifest = manifest
        self.selected_uid = selected_uid
        self.direction = direction
        self.setWindowTitle('Get expected values from defaults' if direction == 'pull'
                            else 'Push expected values to defaults')
        self.resize(1180, 600)
        layout = QtWidgets.QVBoxLayout(self)
        note = QtWidgets.QLabel(
            'Select field identifiers to transfer. Inherited pulls update the named group assignment '
            'and require agreement across all of its descendant messages.' if direction == 'pull' else
            'Select expected values to write as Guided Python defaults in the selected message or '
            'group’s descendant messages. Shared structure definitions keep their existing defaults.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.table = QtWidgets.QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(['Use', 'Assignment owner', 'Identifier', 'Field',
                                              'Affected messages', 'Current', 'Proposed', 'Status'])
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
        for column, width in enumerate((38, 110, 85, 130, 125, 170, 250, 200)):
            self.table.setColumnWidth(column, width)
        self.table.horizontalHeader().setSectionResizeMode(6, QtWidgets.QHeaderView.Stretch)
        self.table.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        layout.addWidget(self.table, 1)
        self.errors = QtWidgets.QPlainTextEdit()
        self.errors.setReadOnly(True)
        self.errors.setMaximumHeight(115)
        self.errors.setAccessibleName('Transfer issues')
        layout.addWidget(self.errors)
        self.buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Apply | QtWidgets.QDialogButtonBox.Cancel)
        self.apply_button = self.buttons.button(QtWidgets.QDialogButtonBox.Apply)
        self.apply_button.setText('Apply transfer')
        self.apply_button.clicked.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        initial = plan_default_transfer(manifest, selected_uid, direction)
        self._keys = [row.key for row in initial.rows]
        self.table.setRowCount(len(initial.rows))
        for index, row in enumerate(initial.rows):
            item = QtWidgets.QTableWidgetItem()
            item.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsUserCheckable if not row.skipped
                          else QtCore.Qt.NoItemFlags)
            item.setCheckState(QtCore.Qt.Unchecked if row.skipped else QtCore.Qt.Checked)
            self.table.setItem(index, 0, item)
        self._render(initial)
        self.table.itemChanged.connect(self._selection_changed)

    def _selection_changed(self, _item):
        keys = [key for index, key in enumerate(self._keys)
                if self.table.item(index, 0).checkState() == QtCore.Qt.Checked]
        self._render(plan_default_transfer(self.manifest, self.selected_uid, self.direction, keys))

    def _render(self, plan):
        self.plan = plan
        blocker = QtCore.QSignalBlocker(self.table)
        for index, row in enumerate(plan.rows):
            selected = self.table.item(index, 0).checkState() == QtCore.Qt.Checked
            status = row.error or ('Ready' if selected else 'Not selected')
            for column, value in enumerate((row.assignment, row.identifier, row.path, row.messages,
                                            row.before, row.after, status), 1):
                item = QtWidgets.QTableWidgetItem(value)
                item.setToolTip(value)
                self.table.setItem(index, column, item)
        del blocker
        self.errors.setPlainText('\n'.join(plan.errors) or (
            'Select at least one field identifier. Raw byte identifiers cannot transfer defaults.'
            if plan.result is None else 'Ready. The selected transfers will apply together in one undoable change.'))
        self.apply_button.setEnabled(plan.result is not None and not plan.errors)
