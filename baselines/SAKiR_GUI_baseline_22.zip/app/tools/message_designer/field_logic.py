"""Structured field expressions and stable switch branch selection."""
from __future__ import annotations

import ast
from .field_references import scope_candidates, context_access

TYPED_VALUE_KINDS = {'uint', 'int', 'bytes_integer', 'varint', 'zigzag', 'float', 'bool', 'enum', 'bytes', 'string'}


def option_errors(field):
    choices = {
        'conditional': {'condition_mode': {'expression', 'field'}, 'comparison': {'truthy', 'falsy', 'eq', 'ne', 'lt', 'le', 'gt', 'ge', 'bit_set', 'bit_clear'}, 'initial_policy': {'legacy', 'resolve'}},
        'switch': {'selector_mode': {'expression', 'field'}, 'default_mode': {'expression', 'pass', 'reject', 'case'}, 'initial_policy': {'legacy', 'resolve'}},
        'computed': {'expression_mode': {'expression', 'guided'}, 'derive_operation': {'copy', 'count', 'byte_length', 'sum'}},
        'rebuild': {'expression_mode': {'expression', 'guided'}, 'derive_operation': {'copy', 'count', 'byte_length', 'sum'}},
        'checksum': {'source_mode': {'expression', 'bytes', 'wire', 'range', 'fields', 'byte_range'}, 'checksum_policy': {'legacy', 'strict'}},
        'length': {'source_mode': {'scope', 'fields', 'range', 'byte_range'}},
        'const': {'wire_value_mode': {'expression', 'guided'}}, 'default': {'wire_value_mode': {'expression', 'guided'}},
    }
    return [f'Unsupported {key}: {field[key]!r}.' for key, allowed in choices.get(field.get('kind'), {}).items()
            if key in field and (not isinstance(field[key], str) or field[key] not in allowed)]


def case_index(field, value):
    identity = value.get('case_uid')
    if identity:
        return next((index for index, case in enumerate(field.get('cases', [])) if case.get('uid') == identity), None)
    index = value.get('case_index', 0)
    return index if type(index) is int and 0 <= index < len(field.get('cases', [])) else None


def effective_expression(field, option, manifest):
    kind = field.get('kind')
    if option == 'condition' and field.get('condition_mode') == 'field':
        source = 'this.' + field.get('condition_field', '')
        definition = dict(scope_candidates(manifest, field.get('uid'))).get(field.get('condition_field'), {})
        definition = definition or manifest.get('reference_fields', {}).get(field.get('condition_field'), {})
        while definition.get('kind') in {'const', 'default', 'rebuild'}:
            definition = definition.get('item', {})
        operation = field.get('comparison', 'truthy')
        if operation == 'truthy':
            return f'lambda ctx: wire_truth({context_access(field.get("condition_field", ""))})'
        if operation == 'falsy':
            return f'lambda ctx: not wire_truth({context_access(field.get("condition_field", ""))})'
        operand = field.get('comparison_value', '0')
        identity = field.get('comparison_value_uid') if not definition or definition.get('kind') == 'enum' else None
        if identity:
            for enum in manifest.get('enums', []):
                member = next((member for member in enum.get('values', []) if member.get('uid') == identity), None)
                if member:
                    operand = f"{enum['name']}.{member['name']}"
                    break
        if operation in {'bit_set', 'bit_clear'}:
            comparison = '!=' if operation == 'bit_set' else '=='
            return f'lambda ctx: (int({context_access(field.get("condition_field", ""))}) & int({operand})) {comparison} 0'
        operator = {'eq': '==', 'ne': '!=', 'lt': '<', 'le': '<=', 'gt': '>', 'ge': '>='}.get(operation)
        if operator:
            if definition.get('kind') == 'enum' or identity:
                return f'lambda ctx: int({context_access(field.get("condition_field", ""))}) {operator} int({operand})'
            return f'({source}) {operator} ({operand})'
        raise ValueError('Choose a supported condition comparison.')
    if option == 'selector' and field.get('selector_mode') == 'field':
        return 'this.' + field.get('selector_field', '')
    if option == 'expression' and field.get('expression_mode') == 'guided':
        path = field.get('source_field', '')
        source = context_access(path)
        operation = field.get('derive_operation', 'copy')
        if operation == 'copy':
            return 'this.' + path
        if operation == 'count':
            return f'lambda ctx: len({source})'
        if operation == 'sum':
            return f'lambda ctx: sum({source})'
        if operation == 'byte_length':
            return f'lambda ctx: source_byte_length(ctx, {path!r})'
        raise ValueError('Choose a supported derived operation.')
    if option == 'source' and kind == 'checksum' and field.get('source_mode') == 'bytes':
        return 'this.' + field.get('source_field', '')
    if option == 'source' and kind == 'checksum' and field.get('source_mode') in {'wire', 'range', 'fields', 'byte_range'}:
        identities = capture_identities(field, manifest)
        if field.get('source_mode') == 'byte_range':
            start, end = field.get('source_byte_start', 0), field.get('source_byte_end')
            if type(start) is not int or start < 0 or end is not None and (type(end) is not int or end <= start):
                raise ValueError('Enter a nonnegative start byte and an exclusive end byte greater than the start, or leave the end blank.')
            return f'lambda ctx: captured_data(ctx, {identities!r}, start={start!r}, end={end!r})'
        return f'lambda ctx: captured_data(ctx, {identities!r})'
    return field.get(option, '')


def fallback_case(field):
    return next((case for case in field.get('cases', []) if case.get('uid') == field.get('default_case_uid')), None)


def fallback_expression(field):
    mode = field.get('default_mode', 'expression')
    if mode == 'pass':
        return 'Pass'
    if mode == 'reject':
        return 'Error'
    return field.get('default') or 'Pass'


def capture_identities(field, manifest):
    candidates = [(path, value) for path, value in scope_candidates(manifest, field.get('uid')) if not path.startswith('_.')]
    if field.get('source_mode') == 'byte_range':
        return tuple(value['uid'] for _, value in candidates)
    if field.get('source_mode') == 'fields':
        selected = field.get('source_field_uids', [])
        available = {value['uid'] for _, value in candidates}
        if not isinstance(selected, list) or not selected or any(not isinstance(uid, str) or uid not in available for uid in selected):
            raise ValueError('Check at least one earlier field in this structure. Remove or repair unavailable selections.')
        return tuple(value['uid'] for _, value in candidates if value['uid'] in selected)
    start = next((index for index, (path, _) in enumerate(candidates) if path == field.get('source_field')), None)
    end = next((index for index, (path, _) in enumerate(candidates) if path == field.get('source_end_field')), None) if field.get('source_mode') == 'range' else start
    if start is None or end is None or end < start:
        raise ValueError('Capture an earlier field, or an ordered range of earlier fields in this structure.')
    return tuple(value['uid'] for _, value in candidates[start:end + 1])


def normalize_enum_cases(field, manifest):
    """Named and aliased enum cases use their numeric wire identity."""
    if field.get('kind') != 'switch' or field.get('initial_policy') != 'resolve' or not str(field.get('selector', '')).startswith('this.'):
        return
    path = field['selector'][5:]
    candidates = dict(scope_candidates(manifest, field.get('uid')))
    definition = candidates.get(path, {})
    if not definition:
        return
    while definition.get('kind') in {'const', 'default', 'rebuild'}:
        definition = definition.get('item', {})
    enum = next((enum for enum in manifest.get('enums', []) if enum['uid'] == definition.get('enum_uid')), None)
    if not enum:
        return
    mapping = {f"{enum['name']}.{member['name']}": member['value'] for member in enum.get('values', [])}
    values = []
    for case in field.get('cases', []):
        text = str(case.get('value', '')).strip()
        if text in mapping:
            values.append(str(mapping[text]))
        else:
            try:
                value = ast.literal_eval(text)
            except (ValueError, SyntaxError):
                return
            if type(value) is not int:
                return
            values.append(str(value))
    for case, value in zip(field.get('cases', []), values):
        case['value'] = value
