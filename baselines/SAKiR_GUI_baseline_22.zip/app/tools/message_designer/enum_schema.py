"""Storage and migration rules for reusable Construct enum definitions (no Qt)."""
from __future__ import annotations

import copy
import uuid
from functools import cache

WIDTHS = (1, 2, 3, 4, 8)
SUBTYPES = tuple(f"{kind}{width * 8}" for width in WIDTHS for kind in ("uint", "int")) + (
    'bits_integer', 'bytes_integer', 'varint', 'zigzag',
)
DEFAULT_STORAGE = {"kind": "uint", "width": 1, "endian": "big"}


def storage(enum):
    value = enum.get("storage")
    if not isinstance(value, dict):
        raise ValueError("Select an enum storage subtype.")
    kind = value.get('kind')
    if kind in {'varint', 'zigzag'}:
        return {'kind': kind}
    if kind in {'bits_uint', 'bits_int', 'bytes_integer'}:
        key = 'length' if kind == 'bytes_integer' else 'bits'
        if type(value.get(key)) is not int or value[key] <= 0:
            raise ValueError(f"Enum {key} must be a positive integer.")
        if kind == 'bytes_integer' and type(value.get('signed')) is not bool:
            raise ValueError('Choose signed or unsigned byte integer storage.')
        if value.get('endian') not in {'big', 'little'}:
            raise ValueError('Enum byte order must be big or little.')
        if kind.startswith('bits_') and value['endian'] == 'little' and value['bits'] % 8:
            raise ValueError('Little-endian bit integers require a multiple of eight bits.')
        result = {'kind': kind, key: value[key], 'endian': value['endian']}
        if kind == 'bytes_integer':
            result['signed'] = value['signed']
        return result
    if kind not in ("uint", "int"):
        raise ValueError("Select a supported enum integer storage subtype.")
    width = value.get("width")
    if type(width) is not int or width not in WIDTHS:
        raise ValueError("Enum width must be 1, 2, 3, 4, or 8 bytes.")
    if value.get("endian") not in ("big", "little"):
        raise ValueError("Enum byte order must be big or little.")
    return {**value, "endian": "big" if width == 1 else value["endian"]}


def subtype_name(enum):
    value = storage(enum)
    if value['kind'] in {'bits_uint', 'bits_int'}:
        return 'bits_integer'
    if value['kind'] not in {'uint', 'int'}:
        return value['kind']
    return f"{value['kind']}{value['width'] * 8}"


def integer_expression(enum, *, qualified=False):
    value = storage(enum)
    prefix = '_construct.' if qualified else ''
    kind = value['kind']
    if kind in {'varint', 'zigzag'}:
        return prefix + ('VarInt' if kind == 'varint' else 'ZigZag')
    if kind in {'bits_uint', 'bits_int', 'bytes_integer'}:
        bits = kind.startswith('bits_')
        return (prefix + ('BitsInteger' if bits else 'BytesInteger') +
                f"({value['bits' if bits else 'length']}, signed={kind == 'bits_int' if bits else value['signed']}, swapped={value['endian'] == 'little'})")
    return prefix + f"Int{value['width'] * 8}{'s' if kind == 'int' else 'u'}{'l' if value['endian'] == 'little' else 'b'}"


def value_range(enum):
    value = storage(enum)
    if value['kind'] in {'varint', 'zigzag'}:
        return (0 if value['kind'] == 'varint' else None, None)
    bits = value['bits'] if value['kind'].startswith('bits_') else value.get('width', value.get('length')) * 8
    signed = value['kind'] in {'int', 'bits_int'} or value['kind'] == 'bytes_integer' and value['signed']
    return (-(1 << (bits - 1)), (1 << (bits - 1)) - 1) if signed else (0, (1 << bits) - 1)


def bit_width(enum):
    value = storage(enum)
    if value['kind'] not in {'bits_uint', 'bits_int'}:
        raise ValueError('Bitfield enum members require a bit integer enum subtype.')
    return value['bits']


def summary(enum):
    value = storage(enum)
    kind = value['kind']
    length = value.get('width', value.get('length'))
    order = f" · {value['endian']} endian" if value.get('endian') and (length or value.get('bits', 0) / 8) > 1 else ""
    size = f"{value['bits']} bits · use in a bitfield group" if kind.startswith('bits_') else f'{length} B' if length else 'variable size'
    if kind in {'bytes_integer', 'bits_uint', 'bits_int'}:
        signed = value['signed'] if kind == 'bytes_integer' else kind == 'bits_int'
        size += ' · ' + ('signed' if signed else 'unsigned')
    aliases = len({member['value'] for member in enum.get('values', [])}) < len(enum.get('values', []))
    policy = enum.get('unknown_policy', 'preserve')
    return (f"{enum.get('name', 'Enum')} · {subtype_name(enum)}{order} · {size} · unknown numeric values: {policy}"
            + (' · aliases decode to their first declared member' if aliases else ''))


def mapping_expression(enum):
    """Put canonical (first) aliases last, matching legacy IntEnum decoding."""
    values = enum.get('values', [])
    seen, canonical, aliases = set(), [], []
    for member in values:
        (aliases if member['value'] in seen else canonical).append(member)
        seen.add(member['value'])
    ordered = aliases + canonical if aliases else values
    return ', '.join(f"{member['name']}={member['value']!r}" for member in ordered)


def definition_expression(enum, *, qualified=False):
    prefix = '_construct.' if qualified else ''
    members = mapping_expression(enum)
    constructor = 'StrictEnum' if enum.get('unknown_policy') == 'reject' else prefix + 'Enum'
    return f"{constructor}({integer_expression(enum, qualified=qualified)}{', ' + members if members else ''})"


@cache
def reserved_members():
    from construct import Enum, Byte
    return frozenset(dir(Enum(Byte))) | {'subcon'}


@cache
def reserved_definition_names():
    # Reserve only names emitted by this generator, not every Construct export.
    # For example, "Renamed" remains a valid user model name.
    return frozenset({
        'Aligned', 'Array', 'BitStruct', 'Bitwise', 'BitsInteger', 'Bytes', 'BytesInteger',
        'Checksum', 'Computed', 'Const', 'CString', 'Default', 'Enum', 'FlagsEnum',
        'Flag', 'GreedyBytes', 'GreedyRange', 'GreedyString', 'If', 'NullTerminated',
        'Padding', 'PaddedString', 'PascalString', 'Prefixed', 'PrefixedArray',
        'Rebuild', 'StringEncoded', 'Struct', 'Switch', 'VarInt', 'ZigZag', 'Pass', 'this',
        '_construct', 'Construct', 'BinaryMessage', 'Direction', 'runtime_field', 'Annotated', 'Any', 'ClassVar',
        'dataclass', 'dataclass_field', 'json', 'hashlib', 'zlib',
        'int', 'str', 'float', 'bool', 'bytes', 'list', 'sum',
        'MESSAGE_TYPES_BY_NAME', 'REGISTRY', 'ROOT_GROUP', 'GROUPS', 'GROUPS_BY_UID',
        'decode_auto', 'identify_group', 'identify_message',
    }) | {f'Int{bits}{sign}{endian}' for bits in (8, 16, 24, 32, 64)
           for sign in ('u', 's') for endian in ('b', 'l')} | {
        f'Float{bits}{endian}' for bits in (16, 32, 64) for endian in ('b', 'l')}


def _stable(uid, label):
    return uuid.uuid5(uuid.NAMESPACE_URL, f"enum:{uid}:{label}").hex


def schema_fields(fields):
    for field in fields:
        yield field
        if isinstance(field.get('item'), dict):
            yield from schema_fields([field['item']])
        yield from schema_fields(field.get('fields', []))
        for case in field.get('cases', []):
            if isinstance(case.get('item'), dict):
                yield from schema_fields([case['item']])


def migrate_enums(manifest, source_version):
    """Mutate a copied legacy manifest, preserving storage bytes and identities."""
    definitions = manifest.get('enums', [])
    fields = [field for owner in [*manifest.get('structures', []), *manifest.get('messages', [])]
              for field in schema_fields(owner.get('fields', []))]
    used_names = {item.get('name', '').casefold() for key in ('enums', 'structures', 'messages')
                  for item in manifest.get(key, [])}
    notes, clones, retargets = [], [], {}
    for enum in definitions:
        references = [field for field in fields if field.get('kind') == 'enum' and field.get('enum_uid') == enum.get('uid')]
        variants = {}
        for field in references:
            value = {'kind': 'uint', 'width': field.get('width', 1), 'endian': field.get('endian', 'big')}
            # Preserve malformed explicit settings for validation rather than guessing.
            if value['width'] == 1 and value['endian'] in ('big', 'little'):
                value['endian'] = 'big'
            key = repr(sorted(value.items()))
            variants.setdefault(key, (value, []))[1].append(field)
        if not variants:
            variants['default'] = (copy.deepcopy(DEFAULT_STORAGE), [])
        for index, (key, (value, users)) in enumerate(sorted(variants.items())):
            target = enum if index == 0 else copy.deepcopy(enum)
            target['storage'] = value
            member_map = {}
            if index:
                target['uid'] = _stable(enum.get('uid', ''), key)
                suffix = f"{value['kind']}{value['width'] * 8 if type(value['width']) is int else 'invalid'}_{'le' if value['endian'] == 'little' else 'be'}"
                base = f"{enum['name']}_{suffix}"
                name, count = base, 2
                while name.casefold() in used_names:
                    name = f"{base}_{count}"; count += 1
                target['name'] = name; used_names.add(name.casefold())
                for member in target.get('values', []):
                    old_uid = member.get('uid', '')
                    member['uid'] = _stable(target['uid'], f"member:{old_uid}")
                    member_map[old_uid] = member['uid']
                clones.append(target)
                notes.append(f"Split {enum['name']} into {target['name']} to preserve a distinct field storage format.")
            for field in users:
                retargets[field.get('uid')] = (target.get('uid'), member_map)
                field['enum_uid'] = target['uid']
                field.pop('width', None); field.pop('endian', None); field.pop('signed', None)
        notes.append(f"Moved field storage into enum definition {enum['name']}.")
    definitions.extend(clones)

    def remap_default(field, value):
        if not isinstance(value, dict):
            return
        if field.get('kind') == 'enum' and field.get('uid') in retargets:
            enum_uid, members = retargets[field.get('uid')]
            value['enum_uid'] = enum_uid
            if value.get('value_uid') in members:
                value['value_uid'] = members[value['value_uid']]
        elif field.get('kind') in {'struct', 'inline_struct'}:
            owner = next((s for s in manifest.get('structures', []) if s['uid'] == field.get('struct_uid')), {}) if field['kind'] == 'struct' else field
            by_uid = {child['uid']: child for child in owner.get('fields', [])}
            for assignment in value.get('fields', []):
                child = by_uid.get(assignment.get('field_uid'))
                if child:
                    remap_default(child, assignment.get('value'))
        elif field.get('kind') == 'array':
            for item in value.get('items', []):
                remap_default(field.get('item', {}), item)
        elif field.get('kind') == 'switch':
            index = value.get('case_index', 0)
            cases = field.get('cases', [])
            if type(index) is int and 0 <= index < len(cases):
                remap_default(cases[index].get('item', {}), value.get('value'))
        elif isinstance(field.get('item'), dict):
            remap_default(field['item'], value.get('value'))

    for field in fields:
        remap_default(field, field.get('object_default_value'))
    manifest['enum_migration'] = {'source_version': source_version, 'pending_regeneration': True, 'notes': notes}

