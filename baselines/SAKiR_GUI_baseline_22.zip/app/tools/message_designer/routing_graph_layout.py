"""Deterministic top-to-bottom routing layout, independent of Qt."""
from __future__ import annotations

NODE_WIDTH = 232
NODE_HEIGHT = 104
COLUMN_GAP = 210
ROW_GAP = 62
LEVEL_GAP = 150
LAYOUT_VERSION = 2


def visible_routes(graph, collapsed=(), query='', focus_uid=''):
    """Keep search matches and their ancestors; search reveals collapsed paths."""
    tokens = query.casefold().split()
    allowed = set(graph.nodes)
    if tokens:
        allowed = set()
        for uid, node in graph.nodes.items():
            text = f'{node.name} {node.kind} {node.direction} {node.condition}'.casefold()
            if all(token in text for token in tokens):
                current = uid
                while current and current not in allowed:
                    allowed.add(current)
                    current = graph.nodes[current].parent_uid
    if focus_uid in graph.nodes:
        scoped, pending = set(), [focus_uid]
        while pending:
            uid = pending.pop()
            if uid not in scoped:
                scoped.add(uid)
                pending.extend(graph.children.get(uid, []))
        allowed &= scoped
        roots = [focus_uid]
    else:
        roots = graph.roots
    visible, pending = set(), list(roots)
    while pending:
        uid = pending.pop()
        if uid not in allowed or uid in visible:
            continue
        visible.add(uid)
        if tokens or uid not in collapsed:
            pending.extend(graph.children.get(uid, []))
    return visible


def layout_routes(graph, visible):
    """Place group subtrees side by side and messages in a right-hand column.

    Reserve the full width of each subtree, including its message column, so
    tall message lists cannot collide with neighboring or deeper branches.
    Both passes are iterative to support deeply nested libraries.
    """
    positions, widths, anchors, offsets = {}, {}, {}, {}
    roots = [uid for uid in graph.nodes if uid in visible and graph.nodes[uid].parent_uid not in visible]
    roots.sort(key=lambda uid: (uid != graph.root_uid, graph.nodes[uid].name.casefold(), uid))
    left = 0
    for root in roots:
        pending = [(root, False)]
        while pending:
            uid, visited = pending.pop()
            children = [child for child in graph.children.get(uid, []) if child in visible]
            if not visited and children:
                pending.append((uid, True))
                pending.extend((child, False) for child in reversed(children))
                continue
            groups = [child for child in children if graph.nodes[child].kind != 'Message']
            messages = [child for child in children if graph.nodes[child].kind == 'Message']
            placements, centers, right = {}, [], 0
            for child in groups:
                x = right + (COLUMN_GAP if placements else 0)
                placements[child] = (x, NODE_HEIGHT + LEVEL_GAP)
                centers.append(x + anchors[child])
                right = x + widths[child]
            if messages:
                x = right + COLUMN_GAP if groups else NODE_WIDTH / 2 + COLUMN_GAP
                centers.append(x - COLUMN_GAP)  # Center over the message bus.
                for index, child in enumerate(messages):
                    placements[child] = (x, NODE_HEIGHT + LEVEL_GAP + index * (NODE_HEIGHT + ROW_GAP))
                right = x + NODE_WIDTH
            anchors[uid] = (centers[0] + centers[-1]) / 2 if centers else NODE_WIDTH / 2
            widths[uid] = max(NODE_WIDTH, right, anchors[uid] + NODE_WIDTH / 2)
            offsets[uid] = placements
        pending = [(root, left, 0)]
        while pending:
            uid, x, y = pending.pop()
            positions[uid] = (x + anchors[uid] - NODE_WIDTH / 2, y)
            for child, (dx, dy) in offsets[uid].items():
                # Messages are terminal cards, positioned directly in their column.
                if graph.nodes[child].kind == 'Message':
                    positions[child] = (x + dx, y + dy)
                else:
                    pending.append((child, x + dx, y + dy))
        left += widths[root] + COLUMN_GAP
    return positions
