"""Scoped, stable sources for encoded byte-length fields (no Qt)."""
from .field_references import scope_candidates


LENGTH_MODES = {
    'scope': 'Whole message / current structure',
    'fields': 'Select fields with checkboxes',
    'range': 'Select a field range',
    'byte_range': 'Select a byte offset range',
}


def length_candidates(manifest, uid):
    return [(path, value) for path, value in scope_candidates(
        manifest, uid, include_later=True, include_self=True) if not path.startswith('_.')]


def contains_advanced(fields, structures, visiting=frozenset()):
    for field in fields:
        if field.get('kind') == 'advanced':
            return True
        if field.get('kind') == 'struct':
            uid = field.get('struct_uid')
            if uid not in visiting and contains_advanced(structures.get(uid, {}).get('fields', []), structures, visiting | {uid}):
                return True
        children = [*field.get('fields', [])]
        if isinstance(field.get('item'), dict):
            children.append(field['item'])
        children.extend(case['item'] for case in field.get('cases', []) if isinstance(case.get('item'), dict))
        if contains_advanced(children, structures, visiting):
            return True
    return False


def length_spec(field, fields):
    """Return runtime metadata with sibling indices, including anonymous padding."""
    mode = field.get('source_mode', 'scope')
    if mode not in LENGTH_MODES:
        raise ValueError('Choose a supported length source.')
    identities = [value.get('uid') for value in fields]
    if mode in {'scope', 'byte_range'}:
        selected = list(range(len(fields)))
    elif mode == 'fields':
        uids = field.get('source_field_uids', [])
        if not isinstance(uids, list) or any(not isinstance(uid, str) or uid not in identities for uid in uids):
            raise ValueError('Length source contains an unavailable field; select sibling fields again.')
        if len(set(uids)) != len(uids):
            raise ValueError('Length source must not contain duplicate fields.')
        selected = [index for index, uid in enumerate(identities) if uid in uids]
    else:
        endpoints = []
        for key in ('source_field', 'source_end_field'):
            uid = field.get(key + '_uid')
            match = next((i for i, value in enumerate(fields) if
                          value.get('uid') == uid), None) if uid else next(
                              (i for i, value in enumerate(fields) if value.get('name') == field.get(key)), None)
            endpoints.append(match)
        start, end = endpoints
        if start is None or end is None or end < start:
            raise ValueError('Select an ordered range of sibling fields for the length source.')
        selected = list(range(start, end + 1))
    spec = {'indices': selected}
    if mode == 'byte_range':
        start, end = field.get('source_byte_start', 0), field.get('source_byte_end')
        if type(start) is not int or start < 0 or end is not None and (type(end) is not int or end < start):
            raise ValueError('Length byte range needs a nonnegative start and an exclusive end at or after it.')
        spec.update(start=start, end=end)
    return spec
