"""Qt-free scope and stable-reference helpers shared by field families."""
from __future__ import annotations

import ast


def context_access(path, root='ctx'):
    """Use mapping paths so fields named items/values cannot shadow methods."""
    return root + ''.join('[' + repr(part) + ']' for part in str(path).split('.'))


def reference_keys(field):
    if field.get("kind") == "array":
        return ("count_field", "length_field")
    if field.get("kind") in {"bytes", "string"}:
        return ("length_field",)
    if field.get('kind') == 'conditional':
        return ('condition_field',)
    if field.get('kind') == 'switch':
        return ('selector_field',)
    if field.get('kind') in {'computed', 'rebuild', 'checksum', 'length'}:
        return ('source_field', 'source_end_field') if field.get('kind') in {'checksum', 'length'} else ('source_field',)
    return ()


def scope_candidates(manifest, target_uid, *, include_later=False, include_self=False):
    """Earlier fields in the actual Struct scope, followed by ancestor scopes."""
    def visit(fields, outer=(), prior=None):
        prior = list(prior or [])
        for field in fields:
            if field.get("uid") == target_uid:
                candidates = prior
                if include_later:
                    candidates = []
                    seen = set()
                    for value in [*prior, *fields]:
                        identity = value.get('uid')
                        if (include_self or identity != target_uid) and identity not in seen:
                            candidates.append(value); seen.add(identity)
                result = [(value.get("name", ""), value) for value in candidates]
                for depth, frame in enumerate(outer, 1):
                    result.extend(("_." * depth + value.get("name", ""), value) for value in frame)
                return result
            if field.get("kind") == "inline_struct":
                found = visit(field.get("fields", []), (prior, *outer))
                if found is not None:
                    return found
            nested = field.get("item")
            if isinstance(nested, dict):
                found = visit([nested], outer, prior)
                if found is not None:
                    return found
            for case in field.get("cases", []):
                if isinstance(case.get("item"), dict):
                    found = visit([case["item"]], outer, prior)
                    if found is not None:
                        return found
            prior.append(field)
        return None

    for owner in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        found = visit(owner.get("fields", []))
        if found is not None:
            return found
    return []


def walk_fields(manifest):
    def visit(fields):
        for field in fields:
            yield field
            yield from visit(field.get("fields", []))
            if isinstance(field.get("item"), dict):
                yield from visit([field["item"]])
            for case in field.get("cases", []):
                if isinstance(case.get("item"), dict):
                    yield from visit([case["item"]])
    for owner in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        yield from visit(owner.get("fields", []))


def bind_field_references(manifest):
    """Keep references attached to stable identities across renames and copies."""
    for field in walk_fields(manifest):
        if not reference_keys(field):
            continue
        candidates = scope_candidates(manifest, field.get("uid"), include_later=field.get('kind') in {'rebuild', 'length'}, include_self=field.get('kind') == 'length')
        for key in reference_keys(field):
            identity = field.get(key + "_uid")
            if identity:
                match = next(((path, value) for path, value in candidates if value.get("uid") == identity), None)
                if match:
                    field[key] = match[0]
            elif field.get(key):
                match = next((value for path, value in candidates if path == field[key]), None)
                if match:
                    field[key + "_uid"] = match["uid"]


def expression_paths(expression, *, roots=('this',)):
    """Extract this.field and this._.field dependencies without executing code."""
    paths = set()
    for node in ast.walk(ast.parse(expression, mode='eval')):
        if not isinstance(node, (ast.Attribute, ast.Subscript)):
            continue
        parts = []
        while isinstance(node, (ast.Attribute, ast.Subscript)):
            if isinstance(node, ast.Attribute):
                parts.append(node.attr)
            elif isinstance(node.slice, ast.Constant) and isinstance(node.slice.value, str):
                parts.append(node.slice.value)
            else:
                break
            node = node.value
        if isinstance(node, ast.Name) and node.id in roots:
            path = '.'.join(reversed(parts))
            if path and not path.endswith('_'):
                paths.add(path)
    return {path for path in paths if not any(other.startswith(path + '.') for other in paths)}


def dependency_available(path, definitions, structures):
    candidates = [key for key in definitions if path == key or path.startswith(key + '.')]
    if not candidates:
        return False
    key = max(candidates, key=len)
    definition = definitions[key]
    remainder = path[len(key):].lstrip('.')
    for part in remainder.split('.') if remainder else ():
        while definition.get('kind') in {'const', 'default', 'rebuild', 'aligned', 'conditional', 'checksum', 'length'}:
            definition = definition.get('item', {})
        kind = definition.get('kind')
        if kind in {'advanced', 'computed', 'switch'}:
            return True  # Dynamic value shapes need runtime verification.
        fields = (structures.get(definition.get('struct_uid'), {}).get('fields', []) if kind == 'struct'
                  else definition.get('fields', []) if kind == 'inline_struct'
                  else definition.get('members', []) if kind == 'bitfield' else [])
        definition = next((field for field in fields if field.get('name') == part), None)
        if definition is None:
            return False
    return True


