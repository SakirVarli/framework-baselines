"""Native routing canvas. Graphics actions never mutate protocol definitions."""
from __future__ import annotations

import html
import math
import weakref

from PyQt5 import QtCore, QtGui, QtWidgets

from .routing_graph_layout import (NODE_WIDTH, NODE_HEIGHT, COLUMN_GAP, LEVEL_GAP,
                                   LAYOUT_VERSION, layout_routes, visible_routes)


def _tooltip(text):
    return '<div style="white-space: pre-wrap">' + html.escape(text) + '</div>'


class GraphInteractionCommand(QtWidgets.QUndoCommand):
    """Local view history; protocol edits keep their existing undo stack."""
    def __init__(self, canvas, before, after, text):
        super().__init__(text)
        self.canvas = weakref.proxy(canvas)
        self.before, self.after = before, after
        self._already_applied = True

    def undo(self):
        self.canvas.restore_state(self.before, from_history=True)
        self.canvas.stateChanged.emit()

    def redo(self):
        if self._already_applied:
            self._already_applied = False
            return
        self.canvas.restore_state(self.after, from_history=True)
        self.canvas.stateChanged.emit()


class RouteCard(QtWidgets.QGraphicsObject):
    def __init__(self, canvas, node):
        super().__init__()
        self.canvas, self.node = weakref.proxy(canvas), node
        self.setFlags(self.ItemIsSelectable | self.ItemIsFocusable | self.ItemSendsGeometryChanges)
        self.setAcceptedMouseButtons(QtCore.Qt.LeftButton)
        self._press_screen = None
        self._dragging = False
        self.setCursor(QtCore.Qt.OpenHandCursor)
        self.refresh_node(node)
        self.setZValue(2)

    def refresh_node(self, node):
        self.node = node
        self.setToolTip(_tooltip(f'{node.name} · {node.kind}\n{node.summary}\n\n{node.details}'))
        self.update()

    def boundingRect(self):
        return QtCore.QRectF(-2, -2, NODE_WIDTH + 4, NODE_HEIGHT + 4)

    def paint(self, painter, option, widget=None):
        node = self.node
        color = {'Library': '#2563eb', 'Group': '#7c3aed', 'Message': '#0f766e'}[node.kind]
        if node.status == 'invalid':
            color = '#b42318'
        elif node.status == 'excluded':
            color = '#667085'
        traced = node.uid in self.canvas.trace_uids
        failed = node.uid == self.canvas.failed_uid
        border = '#b42318' if failed else '#15803d' if traced else '#2563eb' if self.isSelected() else color
        pen = QtGui.QPen(QtGui.QColor(border), 2.5 if self.isSelected() or traced or failed else 1.2)
        if node.status == 'excluded':
            pen.setStyle(QtCore.Qt.DashLine)
        painter.setPen(pen)
        painter.setBrush(QtGui.QColor('#fef3f2' if failed else '#f0fdf4' if traced else '#eff6ff' if self.isSelected() else '#ffffff'))
        painter.drawRoundedRect(QtCore.QRectF(0, 0, NODE_WIDTH, NODE_HEIGHT), 10, 10)
        painter.setPen(QtGui.QColor(color))
        font = QtGui.QFont('Segoe UI', 8)
        font.setWeight(QtGui.QFont.DemiBold)
        painter.setFont(font)
        badge = node.kind.upper() + ('  /  ' + node.direction if node.kind == 'Message' else '')
        children = self.canvas.graph.children.get(node.uid, [])
        if children:
            badge += f'  {"+" if node.uid in self.canvas.collapsed else "−"} {len(children)}'
        painter.drawText(QtCore.QRectF(12, 8, NODE_WIDTH - 24, 17), QtCore.Qt.AlignLeft, badge)
        font.setPointSize(10)
        font.setWeight(QtGui.QFont.DemiBold)
        painter.setFont(font)
        painter.setPen(QtGui.QColor('#101828'))
        painter.drawText(QtCore.QRectF(12, 29, NODE_WIDTH - 24, 22), QtCore.Qt.AlignLeft,
                         painter.fontMetrics().elidedText(node.name, QtCore.Qt.ElideRight, NODE_WIDTH - 24))
        font.setPointSize(8)
        font.setWeight(QtGui.QFont.Normal)
        painter.setFont(font)
        painter.setPen(QtGui.QColor('#475467'))
        painter.drawText(QtCore.QRectF(12, 56, NODE_WIDTH - 24, 18), QtCore.Qt.AlignLeft,
                         painter.fontMetrics().elidedText(node.summary, QtCore.Qt.ElideRight, NODE_WIDTH - 24))
        label = {'included': '● Included', 'excluded': '○ Excluded', 'invalid': '! Invalid'}[node.status]
        if node.draft:
            label += '  ·  * Draft'
        if failed:
            label += '  ·  Trace stopped'
        elif traced:
            label += '  ·  Matched'
        painter.setPen(QtGui.QColor(color))
        painter.drawText(QtCore.QRectF(12, 79, NODE_WIDTH - 24, 18), QtCore.Qt.AlignLeft, label)

    def itemChange(self, change, value):
        if change == self.ItemPositionHasChanged and not self.canvas._updating:
            self.canvas.update_connectors()
        return super().itemChange(change, value)

    def mousePressEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            event.ignore()
            return
        self._press_screen = event.screenPos()
        self._press_position = self.pos()
        self._before_drag = self.canvas.export_state()
        self._dragging = False
        self.canvas.setFocus(QtCore.Qt.MouseFocusReason)
        self.canvas.request_pointer_selection(self.node.uid)
        event.accept()

    def _move_to_pointer(self, event):
        if self._press_screen is None:
            return
        delta = event.screenPos() - self._press_screen
        if not self._dragging:
            if delta.manhattanLength() < QtWidgets.QApplication.startDragDistance():
                return
            self._dragging = True
            self.setCursor(QtCore.Qt.ClosedHandCursor)
        # Use screen displacement, independent of scroll/inspector changes during
        # selection. The threshold stays in pixels even at very small zoom levels.
        inverse, valid = self.canvas.transform().inverted()
        if valid:
            movement = inverse.map(QtCore.QPointF(delta)) - inverse.map(QtCore.QPointF())
            self.setPos(self._press_position + movement)

    def mouseMoveEvent(self, event):
        self._move_to_pointer(event)
        event.accept()

    def mouseReleaseEvent(self, event):
        if self._press_screen is not None:
            self._move_to_pointer(event)
            moved = self._dragging and self.pos() != self._press_position
            self._press_screen = None
            self._dragging = False
            self.setCursor(QtCore.Qt.OpenHandCursor)
            if moved:
                self.canvas.positions[self.node.uid] = [self.x(), self.y()]
                self.canvas._update_bounds()
                self.canvas.record_interaction(self._before_drag, 'Move ' + self.node.name)
                self.canvas.stateChanged.emit()
        event.accept()

    def mouseDoubleClickEvent(self, event):
        self._press_screen = None
        self._dragging = False
        self.setCursor(QtCore.Qt.OpenHandCursor)
        if self.node.kind == 'Message':
            self.canvas.openDefinitionRequested.emit(self.node.uid)
        else:
            self.canvas.toggle_collapse(self.node.uid)
        event.accept()


class RouteConnector(QtWidgets.QGraphicsPathItem):
    def __init__(self, canvas, parent, child):
        super().__init__()
        self.canvas, self.parent_card, self.child_card = weakref.proxy(canvas), parent, child
        self.setZValue(0)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self.setToolTip(_tooltip(child.node.details))
        self.label = QtWidgets.QGraphicsTextItem(self)
        self.label.setFont(QtGui.QFont('Segoe UI', 8))
        self.label.setDefaultTextColor(QtGui.QColor('#344054'))
        self.label.setAcceptedMouseButtons(QtCore.Qt.NoButton)
        self.label.setTextWidth(180)
        self._label_text = None
        self.refresh_label()
        self.update_path()

    def refresh_label(self):
        text = self.child_card.node.condition
        if text != self._label_text:
            self.label.setPlainText(text if len(text) <= 84 else text[:81] + '…')
            self._label_text = text
        self.setToolTip(_tooltip(self.child_card.node.details))
        self.label.setToolTip(self.toolTip())

    def update_path(self):
        start = self.parent_card.pos() + QtCore.QPointF(NODE_WIDTH / 2, NODE_HEIGHT)
        message = self.child_card.node.kind == 'Message'
        end = self.child_card.pos() + (QtCore.QPointF(0, NODE_HEIGHT / 2) if message
                                      else QtCore.QPointF(NODE_WIDTH / 2, 0))
        path = QtGui.QPainterPath(start)
        branch_y = start.y() + LEVEL_GAP / 2
        path.lineTo(start.x(), branch_y)
        if message:
            bus_x = end.x() - COLUMN_GAP
            path.lineTo(bus_x, branch_y)
            path.lineTo(bus_x, end.y())
        else:
            path.lineTo(end.x(), branch_y)
        path.lineTo(end)
        # Groups receive downward arrows; terminal messages branch off their bus.
        path.moveTo(end + (QtCore.QPointF(-8, -4) if message else QtCore.QPointF(-4, -8)))
        path.lineTo(end)
        path.lineTo(end + (QtCore.QPointF(-8, 4) if message else QtCore.QPointF(4, -8)))
        self.setPath(path)
        node = self.child_card.node
        traced = (self.parent_card.node.uid, node.uid) in self.canvas.trace_edges
        color = '#15803d' if traced else '#b42318' if node.status == 'invalid' else '#98a2b3' if node.status == 'excluded' else '#7c8da6'
        self.setPen(QtGui.QPen(QtGui.QColor(color), 2.5 if traced else 1.5,
                              QtCore.Qt.DashLine if node.status == 'excluded' else QtCore.Qt.SolidLine))
        self.label.setPos(end.x() - (COLUMN_GAP - 12 if message else 90),
                          end.y() - self.label.boundingRect().height() - 6)

    def shape(self):
        stroker = QtGui.QPainterPathStroker()
        stroker.setWidth(12)
        return stroker.createStroke(self.path())

    def mousePressEvent(self, event):
        self.canvas.request_pointer_selection(self.child_card.node.uid)
        event.accept()


class RoutingCanvas(QtWidgets.QGraphicsView):
    selectionRequested = QtCore.pyqtSignal(str)
    openDefinitionRequested = QtCore.pyqtSignal(str)
    stateChanged = QtCore.pyqtSignal()
    addGroupRequested = QtCore.pyqtSignal(str)
    addMessageRequested = QtCore.pyqtSignal(str)
    moveRequested = QtCore.pyqtSignal(str, str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setScene(QtWidgets.QGraphicsScene(self))
        self.setRenderHints(QtGui.QPainter.Antialiasing | QtGui.QPainter.TextAntialiasing)
        self.setBackgroundBrush(QtGui.QColor('#f5f7fb'))
        self.setDragMode(self.ScrollHandDrag)
        self.setTransformationAnchor(self.AnchorUnderMouse)
        self.setResizeAnchor(self.AnchorViewCenter)
        self.setMinimumSize(220, 180)
        self.setAccessibleName('Routing graph')
        self.setWhatsThis('Select cards or arrows to inspect routing. Drag cards to arrange, drag the background to pan, '
                         'and use the wheel to zoom. Arrow keys navigate; Enter opens a definition; Space collapses a group.')
        self.graph = None
        self.cards, self.connectors, self.positions = {}, [], {}
        self.collapsed = set()
        self.trace_uids, self.trace_edges, self.failed_uid = set(), set(), ''
        self.query, self.focus_uid, self.selected_uid = '', '', ''
        self._updating = False
        self._needs_fit = True
        self._restore_view = None
        self._pointer_selecting = False
        self.interaction_history = QtWidgets.QUndoStack(self)
        self.scene().selectionChanged.connect(self._selection_changed)
        self.horizontalScrollBar().valueChanged.connect(self._viewport_changed)
        self.verticalScrollBar().valueChanged.connect(self._viewport_changed)

    def set_graph(self, graph, selected_uid=''):
        if self.graph != graph:
            previous = self.graph
            if previous is not None and (previous.root_uid != graph.root_uid or
                                         previous.children != graph.children or
                                         previous.nodes.keys() != graph.nodes.keys()):
                self.interaction_history.clear()
            if self.graph is not None and self.graph.root_uid != graph.root_uid:
                self._needs_fit = True
                self._restore_view = None
            self.graph = graph
            self.positions = {uid: pos for uid, pos in self.positions.items() if uid in graph.nodes}
            self.collapsed.intersection_update(graph.nodes)
            if self.focus_uid not in graph.nodes:
                self.focus_uid = ''
            # Property edits usually change a condition or badge, not topology.
            # Keep existing graphics items and viewport stable while typing.
            same_topology = (previous is not None and previous.children == graph.children
                             and previous.roots == graph.roots and previous.nodes.keys() == graph.nodes.keys()
                             and all(previous.nodes[uid].parent_uid == node.parent_uid for uid, node in graph.nodes.items()))
            if same_topology and visible_routes(graph, self.collapsed, self.query, self.focus_uid) == self.cards.keys():
                for uid, card in self.cards.items():
                    if card.node != graph.nodes[uid]: card.refresh_node(graph.nodes[uid])
                for edge in self.connectors:
                    edge.refresh_label()
                    edge.update_path()
            else:
                self.rebuild()
        self.select_uid(selected_uid)

    def rebuild(self):
        if self.graph is None:
            return
        center = self.mapToScene(self.viewport().rect().center())
        self._updating = True
        self.scene().clear()
        self.cards, self.connectors = {}, []
        visible = visible_routes(self.graph, self.collapsed, self.query, self.focus_uid)
        automatic = layout_routes(self.graph, visible)
        for uid, position in automatic.items():
            card = RouteCard(self, self.graph.nodes[uid])
            self.scene().addItem(card)
            card.setPos(*self.positions.get(uid, position))
            self.cards[uid] = card
        for uid, card in self.cards.items():
            parent = self.cards.get(card.node.parent_uid)
            if parent:
                edge = RouteConnector(self, parent, card)
                self.scene().addItem(edge)
                self.connectors.append(edge)
        if not self.cards:
            label = self.scene().addText('No matching routes', QtGui.QFont('Segoe UI', 12))
            label.setDefaultTextColor(QtGui.QColor('#667085'))
        self._update_bounds()
        self.centerOn(center)
        self._updating = False
        self.select_uid(self.selected_uid, reveal=False)
        if self._restore_view and self.isVisible():
            self._apply_view()
        elif self._needs_fit and self.isVisible():
            self.fit_all()

    def _update_bounds(self):
        self.setSceneRect(self.scene().itemsBoundingRect().adjusted(-80, -80, 80, 80))

    def update_connectors(self):
        for edge in self.connectors:
            edge.update_path()

    def remember_positions(self):
        for uid, card in self.cards.items():
            self.positions[uid] = [card.x(), card.y()]
        self._update_bounds()
        self.stateChanged.emit()

    def record_interaction(self, before, text):
        after = self.export_state()
        if any(before[key] != after[key] for key in ('positions', 'collapsed', 'focus_uid')):
            self.interaction_history.push(GraphInteractionCommand(self, before, after, text))

    def request_pointer_selection(self, uid):
        # Pointer selection already identifies a visible card/edge. Do not pan
        # to it while Qt is processing the press that may become a drag.
        self._pointer_selecting = True
        try:
            self.select_uid(uid)
            self.selectionRequested.emit(uid)
        finally:
            self._pointer_selecting = False

    def _selection_changed(self):
        if self._updating:
            return
        selected = self.scene().selectedItems()
        if selected and isinstance(selected[0], RouteCard):
            self.selected_uid = selected[0].node.uid
            self.selectionRequested.emit(self.selected_uid)

    def select_uid(self, uid, *, reveal=True):
        self.selected_uid = uid
        if reveal and self.graph and uid in self.graph.nodes and uid not in self.cards:
            self.focus_uid = ''
            current = self.graph.nodes[uid].parent_uid
            while current:
                self.collapsed.discard(current)
                current = self.graph.nodes[current].parent_uid
            # Search is a view filter; external navigation should still reveal its target.
            if not self.query:
                self.rebuild()
        self._updating = True
        card = self.cards.get(uid)
        if card is None or not card.isSelected():
            self.scene().clearSelection()
        if card:
            card.setSelected(True)
            if not self._pointer_selecting:
                card.setFocus()
        self._updating = False

    def locate_selection(self):
        if self._pointer_selecting:
            return
        card = self.cards.get(self.selected_uid)
        if card:
            self.ensureVisible(card, 45, 45)

    def set_query(self, text):
        self.query = text
        self.rebuild()
        self.fit_all()

    def toggle_collapse(self, uid=None):
        uid = uid or self.selected_uid
        if not self.graph or not self.graph.children.get(uid):
            return
        before = self.export_state()
        if uid in self.collapsed:
            self.collapsed.remove(uid)
        else:
            self.collapsed.add(uid)
        # Do not auto-reveal the previously selected descendant when collapsing.
        self.selected_uid = uid
        self.rebuild()
        self.select_uid(uid, reveal=False)
        self.selectionRequested.emit(uid)
        self.record_interaction(before, 'Fold/expand group')
        self.stateChanged.emit()

    def focus_selection(self):
        if self.graph and self.selected_uid in self.graph.nodes:
            before = self.export_state()
            self.focus_uid = self.selected_uid
            self.rebuild()
            self.fit_all()
            self.record_interaction(before, 'Focus subtree')
            self.stateChanged.emit()

    def show_all(self):
        before = self.export_state()
        self.focus_uid = ''
        self.rebuild()
        self.fit_all()
        self.record_interaction(before, 'Show all routes')
        self.stateChanged.emit()

    def reset_layout(self):
        before = self.export_state()
        self.positions.clear()
        self.rebuild()
        self.fit_all()
        self.record_interaction(before, 'Reset layout')
        self.stateChanged.emit()

    def fit_all(self):
        if not self.scene().items():
            return
        self._updating = True
        self.fitInView(self.scene().itemsBoundingRect().adjusted(-35, -35, 35, 35), QtCore.Qt.KeepAspectRatio)
        zoom = self.transform().m11()
        if zoom > 1.15:
            self.scale(1.15 / zoom, 1.15 / zoom)
        self._needs_fit = False
        self._updating = False
        self.stateChanged.emit()

    def wheelEvent(self, event):
        zoom = self.transform().m11()
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        target = max(0.08, min(2.5, zoom * factor))
        self.scale(target / zoom, target / zoom)
        self.stateChanged.emit()
        event.accept()

    @staticmethod
    def _history_key(event):
        if event.matches(QtGui.QKeySequence.Undo):
            return 'undo'
        if event.matches(QtGui.QKeySequence.Redo) or (
                event.key() == QtCore.Qt.Key_Z and
                event.modifiers() == (QtCore.Qt.ControlModifier | QtCore.Qt.ShiftModifier)):
            return 'redo'
        return ''

    def available_history_key(self, event):
        key = self._history_key(event)
        if ((key == 'undo' and self.interaction_history.canUndo()) or
                (key == 'redo' and self.interaction_history.canRedo())):
            return key
        return ''

    def event(self, event):
        if event.type() == QtCore.QEvent.ShortcutOverride and self.available_history_key(event):
            event.accept()
            return True
        return super().event(event)

    def keyPressEvent(self, event):
        history_key = self.available_history_key(event)
        if history_key:
            getattr(self.interaction_history, history_key)()
            event.accept()
            return
        key = event.key()
        if key == QtCore.Qt.Key_Space:
            self.toggle_collapse()
        elif key in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            if self.selected_uid:
                self.openDefinitionRequested.emit(self.selected_uid)
        elif key in (QtCore.Qt.Key_Right, QtCore.Qt.Key_Left, QtCore.Qt.Key_Up, QtCore.Qt.Key_Down) and self.graph:
            node = self.graph.nodes.get(self.selected_uid)
            if not node:
                return
            target = ''
            if key == QtCore.Qt.Key_Down and node.kind != 'Message':
                if node.uid in self.collapsed:
                    self.toggle_collapse()
                target = next(iter(self.graph.children.get(node.uid, [])), '')
            elif key == QtCore.Qt.Key_Up and node.kind != 'Message':
                target = node.parent_uid
            else:
                siblings = self.graph.children.get(node.parent_uid, self.graph.roots)
                if key in (QtCore.Qt.Key_Up, QtCore.Qt.Key_Down):
                    siblings = [uid for uid in siblings if self.graph.nodes[uid].kind == 'Message']
                if node.uid in siblings:
                    index = siblings.index(node.uid) + (1 if key in (QtCore.Qt.Key_Down, QtCore.Qt.Key_Right) else -1)
                    if 0 <= index < len(siblings):
                        target = siblings[index]
                    elif key in (QtCore.Qt.Key_Up, QtCore.Qt.Key_Left):
                        target = node.parent_uid
            if target:
                self.selectionRequested.emit(target)
                self.select_uid(target)
                self.locate_selection()
        elif key == QtCore.Qt.Key_F:
            self.fit_all()
        else:
            super().keyPressEvent(event)
            return
        event.accept()

    def contextMenuEvent(self, event):
        if not self.graph:
            return
        item = self.itemAt(event.pos())
        while item is not None and not isinstance(item, RouteCard):
            if isinstance(item, RouteConnector):
                item = item.child_card
                break
            item = item.parentItem()
        uid = item.node.uid if isinstance(item, RouteCard) else self.graph.root_uid
        self.request_pointer_selection(uid)
        node = self.graph.nodes[uid]
        menu = QtWidgets.QMenu(self)
        inspect = menu.addAction('Inspect route')
        definition = menu.addAction('Open in Definitions')
        menu.addSeparator()
        owner_uid = node.parent_uid if node.kind == 'Message' else uid
        owner_uid = owner_uid or self.graph.root_uid
        add_group = menu.addAction('Add child group' if node.kind != 'Message' else 'Add sibling group')
        add_message = menu.addAction('Add message here')
        move = menu.addAction('Change parent…') if node.kind != 'Library' else None
        menu.addSeparator()
        fold = menu.addAction('Expand group' if uid in self.collapsed else 'Collapse group') if self.graph.children.get(uid) else None
        focus = menu.addAction('Focus this subtree')
        selected = menu.exec_(event.globalPos())
        if selected is None or selected is inspect:
            return
        if selected is definition:
            self.openDefinitionRequested.emit(uid)
        elif selected is add_group:
            self.addGroupRequested.emit(owner_uid)
        elif selected is add_message:
            self.addMessageRequested.emit(owner_uid)
        elif selected is move:
            self._choose_parent(uid)
        elif selected is fold:
            self.toggle_collapse(uid)
        elif selected is focus:
            self.focus_selection()

    def _choose_parent(self, uid):
        descendants, pending = {uid}, list(self.graph.children.get(uid, []))
        while pending:
            child = pending.pop()
            if child not in descendants:
                descendants.add(child)
                pending.extend(self.graph.children.get(child, []))
        candidates = [node for node in self.graph.nodes.values() if node.kind != 'Message' and node.uid not in descendants]
        candidates.sort(key=lambda node: (node.uid != self.graph.root_uid, node.name.casefold(), node.uid))
        labels = [f'{node.name} · {node.kind} [{node.uid[:8]}]' for node in candidates]
        node = self.graph.nodes[uid]
        current = next((index for index, parent in enumerate(candidates) if parent.uid == node.parent_uid), 0)
        label, accepted = QtWidgets.QInputDialog.getItem(
            self, 'Change routing parent',
            'New parent for ' + node.name + '\nExpected values will be cleared. Assign values for the new parent in the inspector.',
            labels, current, False)
        if accepted and label in labels:
            self.moveRequested.emit(uid, candidates[labels.index(label)].uid, node.kind)

    def _viewport_changed(self):
        if not self._updating and self.graph and self.isVisible():
            self.stateChanged.emit()

    def export_state(self):
        center = self.mapToScene(self.viewport().rect().center())
        zoom = self.transform().m11()
        if self._restore_view:
            zoom, center_values = self._restore_view
        else:
            center_values = [center.x(), center.y()]
        return {'layout_version': LAYOUT_VERSION, 'positions': dict(self.positions), 'collapsed': sorted(self.collapsed),
                'focus_uid': self.focus_uid, 'zoom': zoom, 'center': center_values}

    def set_trace(self, diagnostic=None):
        self.trace_uids, self.trace_edges, self.failed_uid = set(), set(), ''
        if diagnostic is not None:
            for step in diagnostic.steps:
                self.trace_uids.add(step['group_uid'])
                if step['selected_uid']:
                    self.trace_uids.add(step['selected_uid'])
                    self.trace_edges.add((step['group_uid'], step['selected_uid']))
            if diagnostic.error and diagnostic.steps:
                self.failed_uid = diagnostic.steps[-1]['group_uid']
            # Reveal the complete probe path, including verified ancestors of a scope.
            self.focus_uid = ''
            self.collapsed.difference_update(self.trace_uids)
            self.rebuild()
            if self.isVisible():
                self.fit_all()
            else:
                self._needs_fit = True
        self.update_connectors()
        self.viewport().update()

    def restore_state(self, state, *, from_history=False):
        if not isinstance(state, dict):
            return
        if not from_history:
            self.interaction_history.clear()
        current_layout = state.get('layout_version') == LAYOUT_VERSION
        def point(value):
            return (isinstance(value, (list, tuple)) and len(value) == 2
                    and all(type(number) in (int, float) and math.isfinite(number) and abs(number) < 1e7 for number in value))
        positions = state.get('positions', {}) if current_layout else {}
        self.positions = {uid: list(value) for uid, value in positions.items() if isinstance(uid, str) and point(value)} if isinstance(positions, dict) else {}
        collapsed = state.get('collapsed', [])
        self.collapsed = {uid for uid in collapsed if isinstance(uid, str)} if isinstance(collapsed, list) else set()
        focus = state.get('focus_uid', '')
        self.focus_uid = focus if isinstance(focus, str) else ''
        zoom, center = state.get('zoom'), state.get('center')
        self._restore_view = None
        self._needs_fit = True
        if current_layout and type(zoom) in (int, float) and math.isfinite(zoom) and 0.0001 <= zoom <= 2.5 and point(center):
            self._restore_view = (zoom, center)
            self._needs_fit = False
        if self.graph:
            self.rebuild()

    def _apply_view(self):
        zoom, center = self._restore_view
        self._restore_view = None
        self._updating = True
        self.resetTransform()
        self.scale(zoom, zoom)
        self.centerOn(*center)
        self._updating = False

    def showEvent(self, event):
        super().showEvent(event)
        if self._restore_view:
            self._apply_view()
        elif self._needs_fit:
            self.fit_all()


class RoutingGraphView(QtWidgets.QWidget):
    def event(self, event):
        # Toolbar buttons belong to the graph's shortcut scope as well.
        if event.type() in (QtCore.QEvent.ShortcutOverride, QtCore.QEvent.KeyPress):
            history_key = self.canvas.available_history_key(event)
            if history_key:
                if event.type() == QtCore.QEvent.KeyPress:
                    getattr(self.canvas.interaction_history, history_key)()
                event.accept()
                return True
        return super().event(event)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        toolbar = QtWidgets.QHBoxLayout()
        toolbar.setSpacing(4)
        self.canvas = RoutingCanvas(self)
        actions = [('Fit', 'Fit all visible routes (F)', self.canvas.fit_all),
                   ('Locate', 'Bring the selected route into view', self.canvas.locate_selection),
                   ('Fold', 'Collapse or expand the selected group (Space)', self.canvas.toggle_collapse),
                   ('Focus', 'Show only the selected subtree', self.canvas.focus_selection),
                   ('All routes', 'Leave the focused subtree', self.canvas.show_all),
                   ('Reset', 'Reset card positions to the automatic layout', self.canvas.reset_layout)]
        for label, tooltip, handler in actions:
            button = QtWidgets.QToolButton()
            button.setText(label)
            button.setToolTip(tooltip)
            button.setAccessibleName(tooltip)
            button.clicked.connect(lambda checked=False, callback=handler: callback())
            toolbar.addWidget(button)
        history = self.canvas.interaction_history
        for label, tooltip, handler, enabled, changed in (
                ('Undo layout', 'Undo graph interaction (Ctrl+Z)', history.undo, history.canUndo(), history.canUndoChanged),
                ('Redo layout', 'Redo graph interaction (Ctrl+Y)', history.redo, history.canRedo(), history.canRedoChanged)):
            button = QtWidgets.QToolButton()
            button.setText(label)
            button.setToolTip(tooltip)
            button.setEnabled(enabled)
            changed.connect(button.setEnabled)
            button.clicked.connect(handler)
            toolbar.addWidget(button)
        toolbar.addStretch()
        layout.addLayout(toolbar)
        self.scope_label = QtWidgets.QLabel('All routes · Each packet follows identifier checks')
        self.scope_label.setWordWrap(True)
        self.scope_label.setStyleSheet('color: #667085; font-size: 11px;')
        layout.addWidget(self.scope_label)
        layout.addWidget(self.canvas, 1)
        hint = QtWidgets.QLabel('Drag cards to arrange · Drag background to pan · Wheel to zoom\n'
                               'Ctrl+Z: undo graph interaction · Ctrl+Y: redo · Double-click a group to fold\n'
                               'Dashed: excluded · ! Invalid · * Draft')
        hint.setWordWrap(True)
        hint.setStyleSheet('color: #667085; font-size: 11px;')
        layout.addWidget(hint)
        self.canvas.stateChanged.connect(self._update_scope)

    def _update_scope(self):
        canvas = self.canvas
        if canvas.graph and canvas.focus_uid in canvas.graph.nodes:
            self.scope_label.setText('Focus: ' + canvas.graph.nodes[canvas.focus_uid].name + ' · All routes returns to the library')
        else:
            self.scope_label.setText('All routes · Each packet follows identifier checks')
