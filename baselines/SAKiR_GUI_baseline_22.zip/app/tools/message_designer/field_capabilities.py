"""Initialization capabilities shared by validation and field controls (no Qt)."""
from __future__ import annotations

import ast

from .array_definitions import literal_initial_count
from .object_defaults import guided_supported, guided_errors
from .scalar_definitions import scalar_errors


def _parse_expression(value):
    try:
        ast.parse(value, mode="eval")
        return True
    except (SyntaxError, ValueError, TypeError):
        return False


def automatic_default_available(field, enums, structures, visiting):
    kind = field.get("kind")
    if kind in {'uint', 'int', 'bytes_integer', 'varint', 'zigzag', 'float'}:
        return not scalar_errors(field, 0.0 if kind == 'float' else 0)
    if kind == "length":
        return field.get("item", {}).get("kind") in {"uint", "int", "bytes_integer"}
    if kind == "enum":
        enum = enums.get(field.get("enum_uid"))
        return bool(enum and enum.get("values"))
    if kind == "struct":
        uid = field.get("struct_uid")
        structure = structures.get(uid)
        if structure is None or uid in visiting:
            return False
        return fields_default_constructible(
            structure.get("fields", []), enums, structures, visiting | {uid}
        )
    if kind == "inline_struct":
        return fields_default_constructible(field.get("fields", []), enums, structures, visiting)
    if kind == "array":
        item = field.get("item")
        if not isinstance(item, dict):
            return False
        if field.get('mode') == 'repeat_until':
            return False
        count = literal_initial_count(field) if field.get('initial_policy') == 'resolve' else (field.get('count', 0) if field.get('mode') == 'fixed' else 0)
        if count == 0:
            return True
        mode = item.get("object_default_mode", "required")
        if mode == "custom":
            return _parse_expression(item.get("object_default"))
        if mode == "guided":
            manifest = {"enums": list(enums.values()), "structures": list(structures.values())}
            return guided_supported(item, manifest) and not guided_errors(item, item.get("object_default_value"), manifest)
        return automatic_default_available(item, enums, structures, visiting)
    if kind in {'const', 'default'}:
        if field.get('wire_value_mode') == 'guided':
            manifest = {'enums': list(enums.values()), 'structures': list(structures.values())}
            return not guided_errors(field.get('item', {}), field.get('wire_value'), manifest)
        return _parse_expression(field.get('value', '0'))
    if kind in {"aligned", "rebuild", "checksum"}:
        item = field.get("item")
        if isinstance(item, dict) and item.get('object_default_mode') == 'custom':
            return _parse_expression(item.get('object_default'))
        if isinstance(item, dict) and item.get('object_default_mode') == 'guided':
            return not guided_errors(item, item.get('object_default_value'), {'enums': list(enums.values()), 'structures': list(structures.values())})
        return isinstance(item, dict) and automatic_default_available(item, enums, structures, visiting)
    if kind == 'switch' and field.get('initial_policy') == 'resolve':
        return bool(field.get('cases'))
    if kind in {"switch", "advanced"}:
        return False
    return kind not in {None, "advanced", "switch"}


def fields_default_constructible(fields, enums, structures, visiting):
    derived = {field.get('count_field') for field in fields if field.get('kind') == 'array' and field.get('mode') == 'count_field'
               and field.get('rebuild_count') and field.get('initial_policy') == 'resolve'}
    derived.update(field.get('length_field') for field in fields if field.get('kind') in {'bytes', 'string'}
                   and field.get('mode') == 'count_field' and field.get('rebuild_length'))
    for nested in fields:
        if nested.get("kind") == "padding" or nested.get('name') in derived:
            continue
        mode = nested.get("object_default_mode", "required")
        if mode == "required":
            return False
        if mode == "automatic" and not automatic_default_available(nested, enums, structures, visiting):
            return False
        if mode == "guided" and guided_errors(
            nested, nested.get("object_default_value"),
            {"enums": list(enums.values()), "structures": list(structures.values())},
        ):
            return False
    return True


def automatic_default_reason(field, manifest):
    enums = {item['uid']: item for item in manifest.get('enums', [])}
    structures = {item['uid']: item for item in manifest.get('structures', [])}
    if automatic_default_available(field, enums, structures, set()):
        return ''
    kind = field.get('kind')
    if kind in {'uint', 'int', 'bytes_integer', 'varint', 'zigzag', 'float'}:
        return 'The automatic zero value violates storage or protocol limits. Use Guided or a Python expression.'
    if kind == 'switch':
        return 'A selector cannot infer an unconditional default. Use Guided or supply a value.'
    if kind == 'advanced':
        return 'The Python value of this Construct is unknown. Supply a value or Python factory.'
    if kind == 'array' and field.get('mode') == 'repeat_until':
        return 'A stop condition cannot infer a valid default list. Use Guided or a Python factory.'
    return 'Complete type references and defaults for required nested fields, or supply an explicit value.'
