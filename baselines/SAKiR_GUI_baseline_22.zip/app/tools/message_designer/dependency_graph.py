"""Separate build dependencies from parse order and authoritative payloads."""
from .field_logic import effective_expression
from .field_references import expression_paths
from .length_definitions import length_spec
from .wire_size import WireSizeAnalyzer


def build_dependencies(fields, manifest):
    definitions = {field.get('name'): field for field in fields}
    graph = {name: set() for name in definitions}
    writers = {}
    length_names = {name for name, field in definitions.items() if field.get('kind') == 'length'}
    structures = {value['uid']: value for value in manifest.get('structures', [])}
    def size_controls(field, depth=0, visiting=frozenset()):
        result = set()
        key = {'conditional': 'condition', 'switch': 'selector'}.get(field.get('kind'))
        if key:
            try:
                prefix = '_.' * depth
                for path in expression_paths(effective_expression(field, key, manifest), roots=('this', 'ctx')):
                    if path.startswith(prefix):
                        local = path[len(prefix):].split('.')[0]
                        if local in length_names:
                            result.add(local)
            except (ValueError, SyntaxError, TypeError):
                pass
        for child in field.get('fields', []):
            result.update(size_controls(child, depth + 1, visiting))
        if isinstance(field.get('item'), dict):
            result.update(size_controls(field['item'], depth, visiting))
        for case in field.get('cases', []):
            if isinstance(case.get('item'), dict):
                result.update(size_controls(case['item'], depth, visiting))
        uid = field.get('struct_uid')
        if field.get('kind') == 'struct' and uid not in visiting:
            for child in structures.get(uid, {}).get('fields', []):
                result.update(size_controls(child, depth + 1, visiting | {uid}))
        return result
    for name, field in definitions.items():
        if field.get('mode') == 'count_field':
            if field.get('kind') == 'array' and field.get('rebuild_count'):
                writers[field.get('count_field')] = name
            if field.get('kind') in {'bytes', 'string'} and field.get('rebuild_length'):
                writers[field.get('length_field')] = name
    def expressions(field, key):
        try:
            return {path.split('.')[0] for path in expression_paths(effective_expression(field, key, manifest)) if not path.startswith('_')}
        except (ValueError, SyntaxError, TypeError):
            return set()
    for name, field in definitions.items():
        kind, mode = field.get('kind'), field.get('mode')
        if length_names:
            graph[name].update(size_controls(field))
        if kind == 'length':
            try:
                spec = length_spec(field, fields)
                analyzer = WireSizeAnalyzer(manifest)
                for index in spec['indices']:
                    source = fields[index]
                    if source.get('kind') != 'length' and analyzer.field(source).status != 'exact':
                        graph[name].add(source.get('name'))
            except (ValueError, TypeError, KeyError):
                pass  # Source validation reports incomplete selections.
        if kind in {'computed', 'rebuild'}:
            graph[name].update(expressions(field, 'expression'))
            if field.get('expression_mode') == 'guided':
                graph[name].add(field.get('source_field'))
        if kind in {'conditional', 'switch'}:
            key = 'condition' if kind == 'conditional' else 'selector'
            graph[name].update(expressions(field, key))
            if field.get(key + '_mode') == 'field':
                graph[name].add(field.get(key + '_field'))
        if mode == 'count_field' and kind in {'array', 'bytes', 'string'}:
            reference = field.get('count_field' if kind == 'array' else 'length_field')
            if writers.get(reference) != name and definitions.get(reference, {}).get('kind') != 'length':
                graph[name].add(reference)
        if mode == 'byte_field' and kind == 'array':
            reference = field.get('length_field')
            if definitions.get(reference, {}).get('kind') != 'length':
                graph[name].add(reference)
        if mode in {'count_expression', 'byte_expression'} and kind in {'array', 'bytes', 'string'}:
            dependencies = expressions(field, 'count_expression' if kind == 'array' else 'length_expression')
            graph[name].update(dep for dep in dependencies if definitions.get(dep, {}).get('kind') != 'length')
    for target, source in writers.items():
        if target in graph:
            graph[target].add(source)
    return graph


def build_cycles(fields, manifest):
    graph = build_dependencies(fields, manifest)
    completed, active, found, seen = set(), [], [], set()
    def visit(name):
        if name in active:
            cycle = active[active.index(name):] + [name]
            identity = frozenset(cycle)
            if identity not in seen:
                found.append(cycle); seen.add(identity)
            return
        if name in completed or name not in graph:
            return
        active.append(name)
        for dependency in graph[name]:
            visit(dependency)
        active.pop(); completed.add(name)
    for name in graph:
        visit(name)
    return found
