"""Built-in checksum output contracts and generated callable expressions."""

# name: (integer output bits, generated expression, editor explanation)
# A None width denotes a byte digest rather than integer output.
CHECKSUM_ALGORITHMS = {
    'crc32': (32, 'lambda data: zlib.crc32(data) & 0xffffffff', 'CRC-32/ISO-HDLC.'),
    'sum8': (8, 'lambda data: sum(data) & 0xff', 'Sum of bytes modulo 256.'),
    'xor8': (8, '_checksums.xor8', 'Bytewise XOR (BCC), starting at zero.'),
    'crc8': (8, '_checksums.crc8', 'CRC-8/SMBUS: polynomial 0x07, initial value 0x00.'),
    'sum16': (16, 'lambda data: sum(data) & 0xffff', 'Sum of bytes modulo 65536.'),
    'crc16_modbus': (16, '_checksums.crc16_modbus', 'CRC-16/MODBUS: polynomial 0x8005, initial value 0xFFFF, reflected.'),
    'crc16_ccitt_false': (16, '_checksums.crc16_ccitt_false', 'CRC-16/CCITT-FALSE (IBM-3740): polynomial 0x1021, initial value 0xFFFF, not reflected.'),
    'sum32': (32, 'lambda data: sum(data) & 0xffffffff', 'Sum of bytes modulo 4294967296.'),
    'adler32': (32, 'lambda data: zlib.adler32(data) & 0xffffffff', 'Adler-32, initial value 1.'),
    'sha256': (None, 'lambda data: hashlib.sha256(data).digest()', 'SHA-256 produces a 32-byte digest; use bytes storage.'),
}


def algorithm_note(name):
    spec = CHECKSUM_ALGORITHMS.get(name)
    if spec is None:
        return 'Custom callables must return a value compatible with the child storage.'
    bits, _, description = spec
    if bits is None:
        return description
    return (f'{description} Output: unsigned {bits}-bit integer (0 to {(1 << bits) - 1}); '
            f'use uint{bits} or larger child storage. Child byte order controls the stored checksum bytes.')
