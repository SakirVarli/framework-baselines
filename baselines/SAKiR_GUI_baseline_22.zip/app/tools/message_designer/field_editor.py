from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .generation import construct_expression
from .guided_default_editor import GuidedDefaultEditor
from .model import new_field, new_id
from .object_defaults import guided_supported
from .validation import FIELD_KINDS
from .enum_schema import summary as enum_summary, bit_width
from .array_definitions import PREFIX_FORMATS, scope_candidates, derived_source
from .field_references import reference_keys
from .field_capabilities import automatic_default_reason
from .data_definitions import DATA_MODES
from .field_logic import TYPED_VALUE_KINDS
from .wire_size import WireSizeAnalyzer
from .checksum_algorithms import CHECKSUM_ALGORITHMS, algorithm_note
from .length_definitions import LENGTH_MODES, length_candidates


ARRAY_MODE_LABELS = {
    'fixed': 'Fixed number of items',
    'count_field': 'Item count from another field',
    'prefixed': 'Item count prefix',
    'greedy': 'Until end of data',
    'count_expression': 'Item count from an expression',
    'byte_prefixed': 'Payload byte-length prefix',
    'byte_field': 'Payload byte length from another field',
    'byte_expression': 'Payload byte length from an expression',
    'sentinel': 'Until a terminating item',
    'repeat_until': 'Until a condition matches',
}


class CollapsingFormLayout(QtWidgets.QFormLayout):
    """Remove hidden rows from Qt 5's form layout, including their spacing."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows = []
        self._hidden = set()

    def addRow(self, *args):
        super().addRow(*args)
        row = self.rowCount() - 1
        label = self.itemAt(row, self.LabelRole)
        field = self.itemAt(row, self.FieldRole)
        self._rows.append((label.widget() if label else None, field.widget()))

    def labelForField(self, field):
        return next((label for label, widget in self._rows if widget is field), None)

    def set_field_visible(self, field, visible):
        if visible == (field not in self._hidden):
            return
        label = self.labelForField(field)
        if visible:
            position = next(index for index, (_, widget) in enumerate(self._rows) if widget is field)
            row = sum(widget not in self._hidden for _, widget in self._rows[:position])
            if label is None:
                self.insertRow(row, field)
            else:
                self.insertRow(row, label, field)
            self._hidden.remove(field)
        else:
            self.takeRow(field)
            self._hidden.add(field)
        field.setVisible(visible)
        if label is not None:
            label.setVisible(visible)

    def clear_rows(self):
        for label, field in self._rows:
            if field not in self._hidden:
                self.takeRow(field)
            for widget in (label, field):
                if widget is not None:
                    widget.hide()
                    widget.deleteLater()
        self._rows.clear()
        self._hidden.clear()


class IntegerEdit(QtWidgets.QLineEdit):
    """Unbounded integer input; incomplete text remains a validation draft."""
    _numeric_edit = True
    def __init__(self, value=None, parent=None):
        super().__init__('' if value is None else str(value), parent)
        self.setPlaceholderText('Unset')

    def setValue(self, value):
        self.setText('' if value is None else str(value))

    def value(self):
        text = self.text().strip()
        if not text:
            return None
        try: return int(text, 10)
        except ValueError: return text


class FieldOptionsEditor(QtWidgets.QWidget):
    """Friendly, type-specific editor for every visual wire-field family."""

    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._loading = False
        self._base: dict[str, Any] = new_field("field")
        self._manifest: dict[str, Any] = {}
        self._widgets: dict[str, QtWidgets.QWidget] = {}
        self._case_items: list[dict[str, Any]] = []
        container = QtWidgets.QVBoxLayout(self)
        self._layout = CollapsingFormLayout()
        container.addLayout(self._layout)
        container.addStretch()
        container.setSizeConstraint(QtWidgets.QLayout.SetMinAndMaxSize)
        self._layout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self._layout.setRowWrapPolicy(QtWidgets.QFormLayout.WrapLongRows)
        self.changed.connect(self._refresh_guided_default)
        self.changed.connect(self._update_raw_format)
        self.changed.connect(self._update_controls)

    def load_field(self, field: dict[str, Any], manifest: dict[str, Any]) -> None:
        self._manifest = manifest
        self._base = copy.deepcopy(field)
        self._build(field.get("kind", "uint"), field)

    def refresh_manifest(self, manifest: dict[str, Any]) -> None:
        current = self.value()
        self._manifest = manifest
        # Update available names without rebuilding the form or discarding drafts.
        if self._base.get('kind') == 'bitfield':
            table = self._widgets.get('_members')
            if table is not None:
                blocked = table.blockSignals(True)
                table.setRowCount(0)
                for member in current.get('members', []):
                    self._append_member(table, member)
                table.blockSignals(blocked)
        if self._base.get('kind') in {'checksum', 'length'}:
            self._refresh_checksum_fields(current)
        for key in reference_keys(self._base):
            widget = self._widgets.get(key)
            if isinstance(widget, QtWidgets.QComboBox):
                selected = widget.currentData()
                identity = current.get(key + '_uid')
                candidates = [(path, item) for path, item in scope_candidates(manifest, self._base.get('uid'), include_later=self._base.get('kind') in {'rebuild', 'length'}, include_self=self._base.get('kind') == 'length')
                              if (self._base.get('kind') != 'length' or not path.startswith('_.'))
                              and (not getattr(widget, '_integer_references', True) or _is_integer_reference(item))]
                match = next((path for path, item in candidates if item.get('uid') == identity), None) if identity else None
                if match is not None:
                    selected = match
                previous = widget.blockSignals(True)
                widget.clear()
                noun = 'integer field' if getattr(widget, '_integer_references', True) else 'field'
                widget.addItem(f'— Select an earlier {noun} —', '')
                for path, _ in candidates:
                    widget.addItem(path, path)
                if selected and widget.findData(selected) < 0:
                    widget.addItem(f'⚠ Missing or incompatible: {selected}', selected)
                widget.setCurrentIndex(max(0, widget.findData(selected)))
                widget.blockSignals(previous)
        self._refresh_guided_default()
        wire_value = self._widgets.get('wire_value')
        if isinstance(wire_value, GuidedDefaultEditor):
            wire_value.refresh_context({**current.get('item', {}), 'object_default_mode': 'guided',
                                        'object_default_value': current.get('wire_value')}, manifest)
        self._update_raw_format()
        self._update_controls()
        self._update_raw_format()

    def change_kind(self, kind: str, name: str = "field") -> None:
        if kind not in FIELD_KINDS:
            return
        replacement = new_field(name or "field", kind)
        replacement["uid"] = self._base.get("uid", replacement["uid"])
        self._base = replacement
        self._build(kind, replacement)
        self.changed.emit()

    def value(self) -> dict[str, Any]:
        result = copy.deepcopy(self._base)
        kind = result["kind"]
        for key, widget in self._widgets.items():
            if isinstance(widget, IntegerEdit):
                result[key] = widget.value()
            elif isinstance(widget, QtWidgets.QSpinBox):
                result[key] = widget.value()
            elif isinstance(widget, QtWidgets.QCheckBox):
                result[key] = widget.isChecked()
            elif key == 'source_field_uids':
                result[key] = [widget.item(index).data(QtCore.Qt.UserRole) for index in range(widget.count())
                               if widget.item(index).checkState() == QtCore.Qt.Checked]
            elif isinstance(widget, QtWidgets.QComboBox):
                result[key] = widget.currentData() if widget.currentData() is not None else widget.currentText()
                if key == "width":
                    result[key] = int(result[key])
            elif isinstance(widget, (QtWidgets.QLineEdit, QtWidgets.QPlainTextEdit)):
                result[key] = widget.text() if isinstance(widget, QtWidgets.QLineEdit) else widget.toPlainText()
                if key in {'minimum', 'maximum'} and kind == 'float':
                    text = result[key].strip()
                    try:
                        result[key] = float(text) if text else None
                    except ValueError:
                        pass
        if kind == "bitfield":
            result["members"] = self._read_members()
        elif kind == "switch":
            result["cases"] = self._read_cases()
        guided = self._widgets.get("object_default_value")
        if isinstance(guided, GuidedDefaultEditor) and result.get("object_default_mode") == "guided":
            result["object_default_value"] = guided.value()
        wire_value = self._widgets.get('wire_value')
        if isinstance(wire_value, GuidedDefaultEditor) and result.get('wire_value_mode') == 'guided':
            result['wire_value'] = wire_value.value()
        if reference_keys(result):
            candidates = dict(scope_candidates(self._manifest, result.get('uid'), include_later=kind in {'rebuild', 'length'}, include_self=kind == 'length'))
            for key in reference_keys(result):
                if result.get(key) in candidates:
                    if result.get(key) != self._base.get(key) or not self._base.get(key + '_uid'):
                        result[key + '_uid'] = candidates[result[key]]['uid']
                elif result.get(key) != self._base.get(key):
                    result.pop(key + '_uid', None)
        return result

    def _clear(self) -> None:
        self._edit_source = None
        self._layout.clear_rows()
        self._widgets.clear()

    def _build(self, kind: str, field: dict[str, Any]) -> None:
        self._loading = True
        self._clear()
        wire_heading = QtWidgets.QLabel("Wire format")
        wire_heading.setStyleSheet("font-weight: 600;")
        self._layout.addRow(wire_heading)
        if kind in {"uint", "int"}:
            self._width(field, [1, 2, 3, 4, 8]); self._endian(field)
        elif kind == "bytes_integer":
            self._spin("length", "Byte length", field, 1, 4096); self._check("signed", "Signed", field); self._endian(field)
        elif kind in {"varint", "zigzag", "bool"}:
            self._note("This field has no additional wire settings.")
            if kind == 'bool':
                self._note('One byte: 00 is false; nonzero received bytes are true. Python defaults use True/False.')
        elif kind == "float":
            self._width(field, [2, 4, 8]); self._endian(field)
        elif kind == "enum":
            self._reference("enum_uid", "Enum", self._manifest.get("enums", []), field)
            inherited = QtWidgets.QLabel(); inherited.setWordWrap(True)
            self._widgets['_enum_summary'] = inherited
            self._layout.addRow('Inherited format', inherited)
        elif kind in {"bytes", "string"}:
            self._choice('mode', 'Size mode', DATA_MODES, field)
            self._add('length', 'Fixed length (bytes)', IntegerEdit(field.get('length', 1)))
            self._field_reference("length_field", "Length field", field)
            self._line('length_expression', 'Payload byte-length expression', field)
            self._check('rebuild_length', 'Calculate length from encoded payload', field)
            self._choice('prefix_format', 'Byte-length prefix type', {
                value: ('VarInt (variable length)' if value == 'varint' else f'Unsigned {value[4:]}-bit') for value in PREFIX_FORMATS
            }, field)
            self._combo('prefix_endian', 'Prefix byte order', ['little', 'big'], field)
            self._add('min_bytes', 'Minimum payload bytes', IntegerEdit(field.get('min_bytes', 0)))
            self._add('max_bytes', 'Maximum payload bytes (optional)', IntegerEdit(field.get('max_bytes')))
            self._choice('data_policy', 'Wire validation', {'strict': 'Strict byte boundaries and values', 'legacy': 'Preserve legacy codec behavior'}, field)
            if kind == "string": self._combo("encoding", "Encoding", ["utf8", "ascii", "latin1", "utf16", "utf-16-le", "utf-16-be"], field, editable=True)
            self._data_note = self._note('')
        elif kind == "bitfield":
            self._members_table(field)
        elif kind == "array":
            self._choice('mode', 'Array boundary', ARRAY_MODE_LABELS, field)
            self._array_boundary_note = self._note('')
            self._add('count', 'Fixed count', IntegerEdit(field.get('count', 1)))
            self._field_reference("count_field", "Count field", field)
            self._field_reference('length_field', 'Payload byte-length field', field)
            self._line('count_expression', 'Count / byte-length expression', field)
            self._choice('prefix_format', 'Prefix storage', {
                value: ('VarInt (variable length)' if value == 'varint' else 'Unsigned 8-bit (1 byte)' if value == 'uint8' else
                        f'Unsigned {value[4:]}-bit ({int(value[4:]) // 8} bytes)')
                for value in PREFIX_FORMATS
            }, field)
            self._combo('prefix_endian', 'Prefix byte order', ['little', 'big'], field)
            self._line('sentinel', 'Terminating item (literal)', field)
            self._line('predicate', 'Stop predicate (obj, items, ctx)', field)
            self._add('min_count', 'Minimum items', IntegerEdit(field.get('min_count', 0)))
            self._add('max_count', 'Maximum items (optional)', IntegerEdit(field.get('max_count')))
            self._add('max_bytes', 'Maximum payload bytes (optional)', IntegerEdit(field.get('max_bytes')))
            self._check("rebuild_count", "Calculate count from the list when encoding", field)
            self._note("Select the array's child node to edit the item type and the default for new items.")
        elif kind == "struct":
            self._reference("struct_uid", "Reusable structure", self._manifest.get("structures", []), field)
        elif kind == "inline_struct":
            self._note("Add and edit inline fields using this field's context menu and child nodes.")
        elif kind == "conditional":
            self._choice('condition_mode', 'Condition source', {'expression': 'Advanced expression', 'field': 'Guided field comparison'}, field)
            self._field_reference('condition_field', 'Controlling field', field, integers=False)
            self._choice('comparison', 'Comparison', {'truthy': 'Is true / nonzero', 'falsy': 'Is false / zero',
                         'eq': 'Equals', 'ne': 'Does not equal', 'lt': 'Less than', 'le': 'At most',
                         'gt': 'Greater than', 'ge': 'At least', 'bit_set': 'Any masked bit is set', 'bit_clear': 'Masked bits are clear'}, field)
            self._line('comparison_value', 'Comparison literal / enum member', {**field, 'comparison_value': field.get('comparison_value', '0')})
            self._choice('comparison_value_uid', 'Enum comparison member', {'': 'Use a numeric literal'}, field)
            self._line("condition", "Condition expression", field); self._note("Edit the conditional value using its child node. A true condition requires its value; a false condition uses None.")
        elif kind == "switch":
            self._choice('selector_mode', 'Selector source', {'expression': 'Advanced expression', 'field': 'Guided field selector'}, field)
            self._field_reference('selector_field', 'Selector field', field, integers=False)
            self._line("selector", "Selector expression", field)
            self._choice('default_mode', 'Unknown selector', {'expression': 'Advanced fallback Construct', 'pass': 'No payload (Pass)',
                         'reject': 'Reject unknown selector', 'case': 'Use an edited case field'}, field)
            self._line("default", "Default Construct", field)
            self._choice('default_case_uid', 'Fallback case field', {'': 'Select a fallback case', **{case.get('uid', ''): str(case.get('value', index)) for index, case in enumerate(field.get('cases', []))}}, field)
            self._cases_table(field)
            self._case_summary = self._note('Select a case child node to edit its wire format. Reordering preserves case identities and guided defaults.')
        elif kind in {"const", "default"}:
            self._choice('wire_value_mode', 'Wire value source', {'expression': 'Advanced value expression', 'guided': 'Typed value'}, field)
            self._line("value", "Value expression", field); self._note("Edit the wrapped value using its child node.")
            editor = GuidedDefaultEditor({**field.get('item', {}), 'object_default_mode': 'guided',
                                          'object_default_value': field.get('wire_value')}, self._manifest, deferred=True)
            editor.changed.connect(self._emit_changed); self._widgets['wire_value'] = editor
            self._layout.addRow('Typed wire value', editor)
            self._note('A constant must match its schema value. Construct Default is a build fallback; the Python constructor default is configured separately below.')
        elif kind == "padding":
            self._add('length', 'Padding bytes', IntegerEdit(field.get('length', 1)))
        elif kind == "aligned":
            self._add('modulus', 'Alignment modulus', IntegerEdit(field.get('modulus', 4)))
            self._note('Alignment pads the wrapped region to the modulus, measured from the start of that region. It does not align an absolute message offset. Edit the wrapped value in its child node.')
        elif kind in {"computed", "rebuild"}:
            self._choice('expression_mode', 'Calculation source', {'expression': 'Advanced expression', 'guided': 'Guided calculation'}, field)
            self._field_reference('source_field', 'Authoritative source', field, integers=False)
            self._choice('derive_operation', 'Calculate', {'copy': 'Copy the value', 'count': 'Number of items',
                         'byte_length': 'Encoded byte length', 'sum': 'Sum of numeric items'}, field)
            self._line("expression", "Construct expression", field)
            self._note('Computed values occupy zero bytes. Rebuilt values use the child storage and are calculated when encoding. Constructor placeholders are independent of the effective value.')
            if kind == "rebuild": self._note("Edit the rebuilt value using its child node.")
        elif kind == "length":
            self._choice('source_mode', 'Length source', LENGTH_MODES, field)
            self._field_reference('source_field', 'First included field', field, integers=False)
            self._field_reference('source_end_field', 'Last included field', field, integers=False)
            selected = QtWidgets.QListWidget()
            selected.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
            selected.setMinimumHeight(80); selected.setMaximumHeight(180)
            self._add('source_field_uids', 'Included fields', selected)
            self._refresh_checksum_fields(field)
            selected.itemChanged.connect(self._emit_changed)
            self._add('source_byte_start', 'Start byte (inclusive)', IntegerEdit(field.get('source_byte_start', 0)))
            self._add('source_byte_end', 'End byte (exclusive, optional)', IntegerEdit(field.get('source_byte_end')))
            self._note('Measures encoded bytes, including prefixes and padding. Sources may precede or follow this field, and may include this field itself. Inside a structure, sources belong to that structure.')
            self._note('Edit integer storage and byte order using the child node. Automatic fills an omitted value and recalculates the wire value when encoding. Other initialization modes preserve the initialized value and verify it against the source byte length during construction and encoding. Encoding does not update the object attribute.')
        elif kind == "checksum":
            self._choice('checksum_policy', 'Storage validation', {'strict': 'Check algorithm output against storage', 'legacy': 'Preserve legacy storage policy'}, field)
            self._choice('source_mode', 'Checksum source', {'expression': 'Advanced byte expression', 'bytes': 'Earlier bytes field',
                         'wire': 'Capture an earlier field on the wire', 'range': 'Capture an earlier field range',
                         'fields': 'Select fields with checkboxes', 'byte_range': 'Select a byte offset range'}, field)
            self._field_reference('source_field', 'Bytes source', field, integers=False)
            self._field_reference('source_end_field', 'Last captured field', field, integers=False)
            selected = QtWidgets.QListWidget()
            selected.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
            selected.setMaximumHeight(180)
            selected.setMinimumHeight(80)
            self._add('source_field_uids', 'Included fields', selected)
            self._refresh_checksum_fields(field)
            selected.itemChanged.connect(self._emit_changed)
            self._add('source_byte_start', 'Start byte (inclusive)', IntegerEdit(field.get('source_byte_start', 0)))
            self._add('source_byte_end', 'End byte (exclusive, optional)', IntegerEdit(field.get('source_byte_end')))
            self._checksum_note = self._note('')
            self._combo("algorithm", "Algorithm", [*CHECKSUM_ALGORITHMS, "custom"], field, editable=True)
            self._checksum_algorithm_note = self._note('')
            self._line('custom_algorithm', 'Custom callable expression', field)
            self._line("source", "Source expression", field); self._note("Edit the checksum field using its child node.")
        elif kind == "advanced":
            edit = QtWidgets.QPlainTextEdit(str(field.get("expression", "Int8ub"))); edit.setMinimumHeight(100)
            self._add("expression", "Construct expression", edit)
            self._line('python_type', 'Python type hint (optional)', field)
            self._add('size_hint', 'Declared size hint (bytes, optional)', IntegerEdit(field.get('size_hint')))
            self._line('dependency_hints', 'Dependencies (comma-separated paths)', field)
            self._note('Hints describe developer intent. Size/routing analysis stays conservative; only actual execution verifies defaults.')
            self._note("Trusted developer code. Preview execution is isolated for reliability, not security.")
        if kind in {'uint', 'int', 'bytes_integer', 'varint', 'zigzag', 'float'}:
            if kind == 'float':
                self._line('minimum', 'Protocol minimum (optional)', {**field, 'minimum': '' if field.get('minimum') is None else field['minimum']})
                self._line('maximum', 'Protocol maximum (optional)', {**field, 'maximum': '' if field.get('maximum') is None else field['maximum']})
                self._check('finite_only', 'Require finite values', field)
            else:
                self._add('minimum', 'Protocol minimum (optional)', IntegerEdit(field.get('minimum')))
                self._add('maximum', 'Protocol maximum (optional)', IntegerEdit(field.get('maximum')))
            if kind in {'varint', 'zigzag'}:
                self._add('max_encoded_bytes', 'Maximum encoded bytes (optional)', IntegerEdit(field.get('max_encoded_bytes')))
            self._storage_note = self._note('')
        if kind in {'padding', 'aligned'}:
            self._line('pattern', 'Fill byte (hex)', {**field, 'pattern': field.get('pattern', '00')})
            self._check('verify_padding', 'Validate received fill bytes', field)
        if kind in {'struct', 'inline_struct', 'bitfield'}:
            self._layout_note = self._note('')
        if kind != "padding":
            self._object_default_section(field)
        self._raw_format_section()
        self._loading = False
        self._update_controls()
        self._layout.invalidate()
        self._layout.activate()
        self.updateGeometry()
        QtCore.QTimer.singleShot(0, self._refresh_geometry)

    def _object_default_section(self, field: dict[str, Any]) -> None:
        separator = QtWidgets.QFrame()
        separator.setFrameShape(QtWidgets.QFrame.HLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        self._layout.addRow(separator)
        heading = QtWidgets.QLabel("Python object initialization")
        heading.setStyleSheet("font-weight: 600;")
        self._layout.addRow(heading)
        source = derived_source(self._manifest, field.get('uid'))
        if source is not None and (source.get('kind') in {'bytes', 'string'} or source.get('initial_policy') == 'resolve'):
            self._note(f"Calculated from {source.get('name', 'payload')}. The effective wire count/length has no independent constructor default. Encoding preserves the original Python object.")
            return
        default_mode = QtWidgets.QComboBox()
        default_mode.setToolTip('Pass constructor fields by name. Required fields and fields with defaults can appear in any order; binary field order is preserved.')
        default_mode.addItem("Required", "required")
        default_mode.addItem("Automatic", "automatic")
        default_mode.addItem("Guided value", "guided")
        default_mode.addItem("Python expression", "custom")
        guided_index = default_mode.findData("guided")
        if not guided_supported(field, self._manifest):
            default_mode.model().item(guided_index).setEnabled(False)
            default_mode.setItemData(guided_index, "Complete the field's type references before using guided values.", QtCore.Qt.ToolTipRole)
        selected_mode = default_mode.findData(field.get("object_default_mode", "required"))
        default_mode.setCurrentIndex(max(0, selected_mode))
        self._add("object_default_mode", "When omitted in Python", default_mode)
        self._default_note = self._note('')
        if field.get('kind') == 'array':
            self._choice('initial_policy', 'Automatic list contents', {
                'resolve': 'Use counts and item defaults (recommended)',
                'legacy': 'Keep older empty-list behavior',
            }, field)
            self._add('initial_count', 'Starting number of items', IntegerEdit(field.get('initial_count')))
            self._widgets['initial_count'].setPlaceholderText('Automatic (see explanation above)')
        elif field.get('kind') in {'bytes', 'string'}:
            self._choice('initial_policy', 'Automatic payload contents', {
                'resolve': 'Resolve byte lengths when constructing', 'legacy': 'Preserve older defaults',
            }, field)
        elif field.get('kind') in {'conditional', 'switch'}:
            self._choice('initial_policy', 'Branch initialization', {
                'resolve': 'Follow the condition / selector', 'legacy': 'Preserve older initialization'}, field)
        self._line("object_default", "Python expression", field)

        guided_editor = GuidedDefaultEditor(field, self._manifest, deferred=True)
        self._guided_definitions = copy.deepcopy((self._manifest.get("enums", []), self._manifest.get("structures", [])))
        guided_editor.changed.connect(self._emit_changed)
        self._widgets["object_default_value"] = guided_editor
        self._layout.addRow("Guided default", guided_editor)

        def show_custom_default(mode=None):
            expression_visible = default_mode.currentData() == "custom"
            guided_visible = default_mode.currentData() == "guided"
            if guided_visible:
                guided_editor.activate()
            self._set_row_visible('object_default', expression_visible)
            self._set_row_visible('object_default_value', guided_visible)
            self._refresh_geometry()

        default_mode.currentIndexChanged.connect(show_custom_default)
        show_custom_default()

    def _update_controls(self) -> None:
        if self._loading:
            return
        kind = self._base.get('kind')
        current = self.value()
        if kind in {'uint', 'int', 'bytes_integer', 'varint', 'zigzag', 'float'}:
            if kind in {'varint', 'zigzag'}:
                text = 'VarInt is unsigned; negative values require ZigZag. Encoded size varies with magnitude.'
            elif kind == 'float':
                text = f"IEEE {8 * current.get('width', 4)}-bit storage. Encoding can round values; the default check compares normalized wire precision."
            else:
                width = current.get('length') if kind == 'bytes_integer' else current.get('width')
                bits = width * 8 if type(width) is int and width > 0 else 0
                signed = kind == 'int' or kind == 'bytes_integer' and current.get('signed')
                if 0 < bits <= 64:
                    lower = -(1 << (bits - 1)) if signed else 0
                    upper = (1 << (bits - bool(signed))) - 1
                    text = f'Storage range: {lower} to {upper}. Protocol limits are additional runtime constraints.'
                else:
                    text = f"{'Signed' if signed else 'Unsigned'} {bits}-bit storage. Protocol limits are independent of storage capacity."
            self._storage_note.setText(text)
        if kind == 'bitfield':
            position = 0; cells = []
            for member in current.get('members', []):
                try:
                    bits = bit_width(next(e for e in self._manifest.get('enums', []) if e['uid'] == member.get('enum_uid'))) if member.get('kind') == 'enum' else member.get('bits')
                except (StopIteration, ValueError, TypeError):
                    continue
                if type(bits) is not int or bits < 1:
                    continue
                cells.append(f"{position}..{position + bits - 1}: {member.get('name', '?')} ({member.get('kind')})")
                position += bits
            self._layout_note.setText('Wire bit 0 is the first, most-significant bit. ' + ' | '.join(cells) + f' — total {position} bits ({position / 8:g} bytes).')
        if kind in {'struct', 'inline_struct'}:
            definition = next((item for item in self._manifest.get('structures', []) if item['uid'] == current.get('struct_uid')), {}) if kind == 'struct' else current
            analyzer = WireSizeAnalyzer(self._manifest)
            rows = [f"{child.get('name')}: {child.get('kind')} · {analyzer.field(child).label()} · {child.get('object_default_mode', 'required')}"
                    for child in definition.get('fields', [])]
            self._layout_note.setText('\n'.join(rows) or 'No child fields. Edit the definition or add inline child nodes.')
        if kind in {'const', 'default'}:
            supported = self._base.get('item', {}).get('kind') in TYPED_VALUE_KINDS
            combo = self._widgets['wire_value_mode']; index = combo.findData('guided')
            combo.model().item(index).setEnabled(supported)
            combo.setItemData(index, None if supported else 'Typed wire values require a scalar, enum, bytes, or text child.', QtCore.Qt.ToolTipRole)
            guided = combo.currentData() == 'guided'
            editor = self._widgets['wire_value']
            if guided:
                editor.activate()
            self._set_row_visible('wire_value', guided); self._set_row_visible('value', not guided)
        if kind == 'conditional':
            guided = self._widgets['condition_mode'].currentData() == 'field'
            for key in ('condition_field', 'comparison'):
                self._set_row_visible(key, guided)
            operand = guided and self._widgets['comparison'].currentData() not in {'truthy', 'falsy'}
            enum = self._reference_enum('condition_field', 'condition')
            self._set_row_visible('comparison_value', operand and (not enum or not self._widgets['comparison_value_uid'].currentData()))
            self._set_row_visible('comparison_value_uid', operand and bool(enum))
            if enum and guided and operand:
                combo = self._widgets['comparison_value_uid']; selected = combo.currentData()
                desired = [('Use a numeric literal', ''), *((f"{member['name']} ({member['value']})", member['uid']) for member in enum.get('values', []))]
                if [(combo.itemText(i), combo.itemData(i)) for i in range(combo.count())] != desired:
                    previous = combo.blockSignals(True); combo.clear()
                    for label, identity in desired:
                        combo.addItem(label, identity)
                    if selected and combo.findData(selected) < 0:
                        combo.addItem('⚠ Removed enum member', selected)
                    combo.setCurrentIndex(max(0, combo.findData(selected))); combo.blockSignals(previous)
            self._set_row_visible('condition', not guided)
        if kind == 'switch':
            guided = self._widgets['selector_mode'].currentData() == 'field'
            self._set_row_visible('selector_field', guided); self._set_row_visible('selector', not guided)
            fallback = self._widgets['default_mode'].currentData()
            self._set_row_visible('default', fallback == 'expression')
            self._set_row_visible('default_case_uid', fallback == 'case')
            enum = self._reference_enum('selector_field', 'selector')
            table = self._widgets['_cases']
            for row in range(table.rowCount()):
                control = table.cellWidget(row, 0)
                choices = [(f"{enum['name']}.{member['name']}", member['uid']) for member in enum.get('values', [])] if enum else []
                if control is None and enum:
                    control = QtWidgets.QComboBox(); control.setEditable(True)
                    table.setCellWidget(row, 0, control)
                    for label, identity in choices:
                        control.addItem(label, identity)
                    control.setCurrentText(table.item(row, 0).text())
                    cell = table.item(row, 0)
                    def member_changed(text, combo=control, cell=cell):
                        index = combo.findText(text)
                        previous = table.blockSignals(True)
                        cell.setData(QtCore.Qt.UserRole + 1, combo.itemData(index) if index >= 0 else None)
                        table.blockSignals(previous)
                    control.editTextChanged.connect(member_changed)
                    control.editTextChanged.connect(self._emit_changed)
                elif control is not None:
                    if choices != [(control.itemText(i), control.itemData(i)) for i in range(control.count())]:
                        text = control.currentText(); identity = table.item(row, 0).data(QtCore.Qt.UserRole + 1)
                        previous = control.blockSignals(True); control.clear()
                        for label, identity in choices:
                            control.addItem(label, identity)
                        selected = control.findData(table.item(row, 0).data(QtCore.Qt.UserRole + 1))
                        if selected >= 0:
                            control.setCurrentIndex(selected)
                        else:
                            control.setCurrentText(text)
                        control.blockSignals(previous)
            combo = self._widgets['default_case_uid']
            cases = self._read_cases()
            if enum:
                mapping = {f"{enum['name']}.{member['name']}": member['value'] for member in enum.get('values', [])}
                covered = set()
                import ast
                for case in cases:
                    try:
                        value = ast.literal_eval(case['value'])
                    except (SyntaxError, ValueError):
                        value = mapping.get(case['value'])
                    if type(value) is int:
                        covered.add(value)
                declared = {member['value'] for member in enum.get('values', [])}
                self._case_summary.setText(f'{len(covered & declared)} of {len(declared)} declared enum values have cases. Unknown values follow the selected fallback. Select child nodes to edit branch fields.')
            else:
                self._case_summary.setText('Select a case child node to edit its wire format. Reordering preserves case identities and guided defaults.')
            desired = [('Select a fallback case', ''), *((str(case['value']), case['uid']) for case in cases)]
            if [(combo.itemText(index), combo.itemData(index)) for index in range(combo.count())] != desired and cases:
                selected = combo.currentData(); previous = combo.blockSignals(True); combo.clear()
                for label, identity in desired:
                    combo.addItem(label, identity)
                combo.setCurrentIndex(max(0, combo.findData(selected))); combo.blockSignals(previous)
        if kind in {'computed', 'rebuild'}:
            guided = self._widgets['expression_mode'].currentData() == 'guided'
            for key in ('source_field', 'derive_operation'):
                self._set_row_visible(key, guided)
            self._set_row_visible('expression', not guided)
        if kind in {'uint', 'int', 'bytes_integer'}:
            size_key = 'length' if kind == 'bytes_integer' else 'width'
            self._set_row_visible('endian', self.value().get(size_key) != 1)
        if kind == 'length':
            mode = self._widgets['source_mode'].currentData()
            for key in ('source_field', 'source_end_field'):
                self._set_row_visible(key, mode == 'range')
            self._set_row_visible('source_field_uids', mode == 'fields')
            for key in ('source_byte_start', 'source_byte_end'):
                self._set_row_visible(key, mode == 'byte_range')
        if kind == 'checksum':
            self._checksum_algorithm_note.setText(algorithm_note(self._widgets['algorithm'].currentText()))
            self._set_row_visible('custom_algorithm', self._widgets['algorithm'].currentText() == 'custom')
            mode = self._widgets['source_mode'].currentData()
            guided = mode in {'bytes', 'wire', 'range'}
            self._set_row_visible('source_field', guided); self._set_row_visible('source', mode == 'expression')
            self._set_row_visible('source_end_field', mode == 'range')
            self._set_row_visible('source_field_uids', mode == 'fields')
            self._set_row_visible('source_byte_start', mode == 'byte_range')
            self._set_row_visible('source_byte_end', mode == 'byte_range')
            self._checksum_note.setText({
                'fields': 'Checked fields contribute their actual wire bytes in field order, including prefixes and padding. Only earlier fields in this structure are available.',
                'byte_range': 'Offsets start at 0 at the beginning of this structure. Only bytes before the checksum are available. The end byte is excluded; leave it blank to include all remaining preceding bytes.',
                'range': 'Capture every field from Bytes source through Last captured field, including both endpoints, prefixes and padding.',
                'wire': 'Capture the selected earlier field’s actual wire bytes, including prefixes and padding.',
            }.get(mode, 'Choose the bytes used to calculate and verify the checksum.'))
        mode_widget = self._widgets.get('object_default_mode')
        if mode_widget is None:
            self._refresh_geometry()
            return
        default = mode_widget.currentData()
        notes = {
            'required': 'Supply this value when creating the Python object.',
            'automatic': 'If omitted, create a value from the field type and its defaults. Each object gets its own value.',
            'guided': 'If omitted, use the value edited below. Each object gets its own copy.',
            'custom': 'If omitted, evaluate this Python expression for each new object. '
                      'The generated Python dataclass uses a default factory; the Raw Construct format stays unchanged. '
                      'Explicitly supplied values override this default. Use Check default message in the Hex Sandbox '
                      'to test it; sandbox starter values are supplied explicitly. Expressions are trusted code.',
        }
        note = notes.get(default, '')
        if kind == 'length' and default == 'automatic':
            note = 'If omitted, calculate the selected source byte length after other object values initialize. Encoding recalculates the wire value from current contents.'
        elif kind == 'length':
            note += ' The initialized value must match the selected source byte length. Construction and encoding reject mismatches rather than replace the value.'
        reason = automatic_default_reason(self.value(), self._manifest)
        automatic_index = mode_widget.findData('automatic')
        mode_widget.model().item(automatic_index).setEnabled(not reason)
        mode_widget.setItemData(automatic_index, reason or None, QtCore.Qt.ToolTipRole)
        if default == 'automatic' and reason:
            note = reason
        if kind in {'bytes', 'string'}:
            mode = self._widgets['mode'].currentData()
            visibility = {'length': mode == 'fixed', 'length_field': mode == 'count_field',
                          'rebuild_length': mode == 'count_field', 'length_expression': mode == 'count_expression',
                          'prefix_format': mode == 'prefixed',
                          'prefix_endian': mode == 'prefixed' and self._widgets['prefix_format'].currentData() not in {'uint8', 'varint'},
                          'initial_policy': default == 'automatic'}
            for key, visible in visibility.items():
                self._set_row_visible(key, visible)
            details = {
                'fixed': 'The boundary is bytes. Raw bytes must match it exactly; text is encoded and null padded to capacity.',
                'count_field': 'The selected field gives encoded payload bytes. A derived length is calculated without changing the Python length attribute. Shared payloads must agree.',
                'count_expression': 'Evaluate an expression such as this.size * 2 to get encoded payload bytes.',
                'prefixed': 'Prefix the encoded payload byte length, excluding the prefix itself.',
                'pascal': 'Legacy prefix: unsigned 16-bit little endian, counting encoded payload bytes.',
                'greedy': 'Consume the current input boundary. Use at the end of a message or bounded structure.',
                'null_terminated': 'Stop at a null encoding unit. The terminator is on the wire and excluded from the Python value and byte limits.',
            }
            self._data_note.setText(details.get(mode, 'Unsupported boundary; select a supported mode.'))
            if default == 'automatic':
                note += (' Bytes use a known byte length, within the initialization budget.' if kind == 'bytes' else
                         ' Text starts empty only where valid; an exact nonzero byte length requires supplied text.')
                if self._widgets['initial_policy'].currentData() == 'legacy':
                    note += ' Older initialization is preserved.'
        if kind == 'array':
            mode = self._widgets['mode'].currentData()
            prefixed = mode in {'prefixed', 'byte_prefixed'}
            visibility = {
                'count': mode == 'fixed',
                'count_field': mode == 'count_field',
                'rebuild_count': mode == 'count_field',
                'length_field': mode == 'byte_field',
                'count_expression': mode in {'count_expression', 'byte_expression'},
                'prefix_format': prefixed,
                'prefix_endian': prefixed and self._widgets['prefix_format'].currentData() not in {'uint8', 'varint'},
                'sentinel': mode == 'sentinel',
                'predicate': mode == 'repeat_until',
                'max_bytes': mode in {'byte_prefixed', 'byte_field', 'byte_expression'},
                'initial_policy': default == 'automatic' and mode not in {'fixed', 'repeat_until'},
                'initial_count': default == 'automatic' and mode not in {'fixed', 'repeat_until'}
                                 and self._widgets['initial_policy'].currentData() == 'resolve',
            }
            for key, visible in visibility.items():
                self._set_row_visible(key, visible)
            self._layout.labelForField(self._widgets['count_expression']).setText(
                'Payload byte-length expression' if mode == 'byte_expression' else 'Item count expression')
            self._layout.labelForField(self._widgets['prefix_format']).setText(
                'Byte-length prefix type' if mode == 'byte_prefixed' else 'Item-count prefix type')
            boundaries = {
                'fixed': 'Encode and decode exactly the fixed number of items.',
                'count_field': 'The selected earlier field gives the number of items. Calculating the count from the list updates the encoded count; the original Python count attribute stays unchanged.',
                'prefixed': 'Write the number of items before the list. The prefix is calculated from the list when encoding.',
                'greedy': 'Read items until the current data boundary. Use this at the end of a message or inside a byte-bounded field.',
                'count_expression': 'Evaluate the expression to get the number of items, for example this.count * 2.',
                'byte_prefixed': 'Write the encoded payload size in bytes before the list. Decode items within that byte boundary.',
                'byte_field': 'The selected earlier field gives the payload size in bytes. The encoded list must fit that size exactly.',
                'byte_expression': 'Evaluate the expression to get the payload size in bytes. The encoded list must fit that size exactly.',
                'sentinel': 'Include the terminating item as the final item in the list and on the wire.',
                'repeat_until': 'Stop after an item makes the condition true. That matching item is included in the list.',
            }
            self._array_boundary_note.setText(boundaries.get(mode, 'Unsupported array boundary; select a supported mode.'))
            automatic_index = mode_widget.findData('automatic')
            mode_widget.model().item(automatic_index).setEnabled(not reason)
            mode_widget.setItemData(automatic_index, reason or None, QtCore.Qt.ToolTipRole)
            if default == 'automatic':
                if mode == 'repeat_until':
                    note = 'A stop condition cannot infer a valid default list. Select Required, Guided value, or Python expression.'
                elif mode == 'fixed':
                    note = 'If omitted, create Fixed count items using the child item default, or a type-appropriate value such as 0. For example, count 3 and item default 7 create [7, 7, 7]. Each object gets its own list.'
                elif self._widgets['initial_policy'].currentData() == 'legacy':
                    note = 'If omitted, start with an empty list, preserving older behavior. This can fail encoding when the wire count requires items.'
                else:
                    note = 'If omitted, create a fresh list using the child item default, or a type-appropriate value such as 0. Starting number of items sets its initial length.'
                    if mode == 'count_expression' or (mode == 'count_field' and not self._widgets['rebuild_count'].isChecked()):
                        note += ' Leave blank to use the actual count when the object is created. An explicit starting length must match that count.'
                    elif mode == 'sentinel':
                        note += ' Leave blank to use at least one item (or Minimum items). The last item is always the terminator.'
                    else:
                        note += ' Leave blank to use Minimum items (normally an empty list).'
                    if mode in {'byte_field', 'byte_expression'}:
                        note += ' A byte length cannot determine an item count; choose a starting length that encodes to the required bytes.'
                    note += ' This chooses constructor contents; the array boundary still controls encoding and decoding.'
            elif default == 'guided':
                note = 'If omitted, use the list edited below. Use Add/Remove to choose its length where allowed. New items use the child item default; existing entries keep their edited values.'
        self._default_note.setText(note)
        self._refresh_geometry()

    @staticmethod
    def _guided_schema(field):
        return {key: value for key, value in field.items()
                if key not in {"object_default_mode", "object_default", "object_default_value"}}

    def _refresh_guided_default(self) -> None:
        if self._loading:
            return
        guided = self._widgets.get("object_default_value")
        mode = self._widgets.get("object_default_mode")
        if not isinstance(guided, GuidedDefaultEditor) or mode is None:
            return
        field = self.value()
        supported = guided_supported(field, self._manifest)
        index = mode.findData("guided")
        mode.model().item(index).setEnabled(supported)
        mode.setItemData(index, None if supported else
                         "Complete the field's type references before using guided values.", QtCore.Qt.ToolTipRole)
        definitions = (self._manifest.get("enums", []), self._manifest.get("structures", []))
        if (self._guided_schema(field) != self._guided_schema(guided._field)
                or definitions != self._guided_definitions):
            guided.refresh_context(field, self._manifest)
            self._guided_definitions = copy.deepcopy(definitions)
        else:
            guided._manifest = self._manifest

    def _refresh_geometry(self) -> None:
        self._layout.invalidate()
        self._layout.activate()
        self.updateGeometry()
        parent = self.parentWidget()
        while parent is not None and not isinstance(parent, QtWidgets.QScrollArea):
            parent = parent.parentWidget()
        if parent is not None:
            parent.updateGeometry()
            parent.viewport().updateGeometry()
            parent.viewport().update()

    def _raw_format_section(self) -> None:
        separator = QtWidgets.QFrame()
        separator.setFrameShape(QtWidgets.QFrame.HLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        self._layout.addRow(separator)
        heading = QtWidgets.QLabel("Raw Construct format")
        heading.setStyleSheet("font-weight: 600;")
        self._layout.addRow(heading)
        note = QtWidgets.QLabel(
            "Read-only preview of the Construct expression generated for this field. "
            "Python object initialization defaults are generated in the dataclass, so they do not appear here. "
            "Use its adapter names when looking up Construct documentation."
        )
        note.setWordWrap(True); note.setStyleSheet("color: #52627a;")
        self._layout.addRow(note)
        self.raw_format = QtWidgets.QPlainTextEdit()
        self.raw_format.setReadOnly(True)
        self.raw_format.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.raw_format.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.raw_format.setMinimumHeight(58)
        self.raw_format.setMaximumHeight(92)
        self._layout.addRow("Construct expression", self.raw_format)
        self._update_raw_format()

    def _update_raw_format(self) -> None:
        preview = getattr(self, "raw_format", None)
        if preview is None:
            return
        try:
            expression = construct_expression(self.value(), self._manifest)
        except (KeyError, TypeError, ValueError) as error:
            expression = f"Unavailable until the field settings are complete: {error}"
        preview.setPlainText(expression)
        inherited = self._widgets.get('_enum_summary')
        if inherited is not None:
            enum = next((item for item in self._manifest.get('enums', []) if item.get('uid') == self.value().get('enum_uid')), {})
            try: inherited.setText(enum_summary(enum))
            except (ValueError, TypeError): inherited.setText('Select an enum definition with valid storage settings.')

    def _connect_mode_visibility(self, mode_key: str, visibility: dict[str, set[str]]) -> None:
        mode = self._widgets[mode_key]

        def update_rows(*args):
            selected = str(mode.currentData() if mode.currentData() is not None else mode.currentText())
            for key, visible_modes in visibility.items():
                self._set_row_visible(key, selected in visible_modes)
            self._layout.invalidate()
            self._layout.activate()
            self.updateGeometry()

        mode.currentIndexChanged.connect(update_rows)
        update_rows()

    def _set_row_visible(self, key: str, visible: bool) -> None:
        widget = self._widgets.get(key)
        if widget is None:
            return
        self._layout.set_field_visible(widget, visible)

    def _field_reference(self, key: str, label: str, field: dict[str, Any], *, integers=True) -> None:
        widget = QtWidgets.QComboBox()
        candidates = [(path, candidate) for path, candidate in scope_candidates(self._manifest, field.get('uid'), include_later=field.get('kind') in {'rebuild', 'length'}, include_self=field.get('kind') == 'length')
                      if (field.get('kind') != 'length' or not path.startswith('_.'))
                      and (not integers or _is_integer_reference(candidate))]
        widget._integer_references = integers
        noun = 'integer field' if integers else 'field'
        if candidates:
            widget.addItem(f'— Select a {noun} —' if field.get('kind') == 'length' else f'— Select an earlier {noun} —', '')
            for path, candidate in candidates:
                widget.addItem(path, path)
        else:
            widget.addItem(f'— No earlier {noun}s in this scope —', '')
        selected = str(field.get(key, ""))
        index = widget.findData(selected)
        if selected and index < 0:
            widget.addItem(f"⚠ Missing or incompatible: {selected}", selected)
            index = widget.count() - 1
        widget.setCurrentIndex(max(0, index))
        widget.setToolTip('All sibling fields are available, including this length field.' if field.get('kind') == 'length' else
                          f'Earlier {noun}s are available. Ancestor references use _. prefixes.')
        self._add(key, label, widget)

    def _refresh_checksum_fields(self, field):
        widget = self._widgets.get('source_field_uids')
        if widget is None:
            return
        selected = field.get('source_field_uids', [])
        sources = length_candidates(self._manifest, field.get('uid')) if field.get('kind') == 'length' else scope_candidates(self._manifest, field.get('uid'))
        candidates = [(path, candidate['uid']) for path, candidate in sources if not path.startswith('_.')]
        available = {uid for _, uid in candidates}
        candidates.extend((f'⚠ Unavailable field: {uid}', uid) for uid in selected if uid not in available)
        previous = widget.blockSignals(True)
        widget.clear()
        for path, uid in candidates:
            item = QtWidgets.QListWidgetItem(path, widget)
            item.setData(QtCore.Qt.UserRole, uid)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            item.setCheckState(QtCore.Qt.Checked if uid in selected else QtCore.Qt.Unchecked)
        widget.blockSignals(previous)

    def _add(self, key: str, label: str, widget: QtWidgets.QWidget) -> None:
        self._widgets[key] = widget
        self._layout.addRow(label, widget)
        if isinstance(widget, QtWidgets.QLineEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QPlainTextEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QSpinBox): widget.valueChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QCheckBox): widget.toggled.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QComboBox):
            widget.currentIndexChanged.connect(self._emit_changed)
            if widget.isEditable():
                widget.editTextChanged.connect(self._emit_changed)

    def _emit_changed(self, *args) -> None:
        sender = self.sender()
        self._edit_source = getattr(sender, "_edit_source", sender)
        if not self._loading:
            self.changed.emit()

    def _note(self, text: str) -> QtWidgets.QLabel:
        label = QtWidgets.QLabel(text); label.setWordWrap(True); label.setStyleSheet("color: #52627a;")
        self._layout.addRow(label)
        return label

    def _spin(self, key, label, field, minimum, maximum):
        widget = QtWidgets.QSpinBox(); widget.setRange(minimum, maximum); widget.setValue(int(field.get(key, minimum)))
        self._add(key, label, widget)

    def _check(self, key, label, field):
        widget = QtWidgets.QCheckBox(); widget.setChecked(bool(field.get(key, False))); self._add(key, label, widget)

    def _line(self, key, label, field):
        self._add(key, label, QtWidgets.QLineEdit(str(field.get(key, ""))))

    def _combo(self, key, label, values, field, editable=False):
        widget = QtWidgets.QComboBox(); widget.setEditable(editable); widget.addItems(values); widget.setCurrentText(str(field.get(key, values[0])))
        self._add(key, label, widget)

    def _choice(self, key, label, choices, field):
        widget = QtWidgets.QComboBox()
        widget.setMinimumContentsLength(20)
        widget.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        for value, text in choices.items():
            widget.addItem(text, value)
            widget.setItemData(widget.count() - 1, text, QtCore.Qt.ToolTipRole)
        selected = field.get(key, next(iter(choices)))
        if widget.findData(selected) < 0:
            widget.addItem(f'⚠ Unsupported: {selected}', selected)
        widget.setCurrentIndex(max(0, widget.findData(selected)))
        self._add(key, label, widget)

    def _width(self, field, values): self._combo("width", "Width (bytes)", [str(v) for v in values], {"width": str(field.get("width", values[0]))})
    def _endian(self, field): self._combo("endian", "Byte order", ["big", "little"], field)

    def _reference(self, key, label, values, field):
        widget = QtWidgets.QComboBox(); widget.addItem("— Select —", "")
        for value in values: widget.addItem(value.get("name", "Unnamed"), value.get("uid", ""))
        index = widget.findData(field.get(key, "")); widget.setCurrentIndex(max(0, index)); self._add(key, label, widget)

    def _members_table(self, field):
        table = QtWidgets.QTableWidget(0, 4); table.setHorizontalHeaderLabels(["Name", "Kind", "Bits", "Enum"]); table.horizontalHeader().setStretchLastSection(True)
        for member in field.get("members", []): self._append_member(table, member)
        controls = QtWidgets.QWidget(); row = QtWidgets.QHBoxLayout(controls); row.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton("Add member"); remove = QtWidgets.QPushButton("Remove selected"); row.addWidget(add); row.addWidget(remove); row.addStretch()
        up = QtWidgets.QPushButton('Move up'); down = QtWidgets.QPushButton('Move down'); row.addWidget(up); row.addWidget(down)
        up.clicked.connect(lambda: self._move_member(table, -1)); down.clicked.connect(lambda: self._move_member(table, 1))
        add.clicked.connect(lambda: self._add_member(table))
        remove.clicked.connect(lambda: self._remove_member(table))
        table.itemChanged.connect(self._emit_changed); self._layout.addRow("Bit members", table); self._layout.addRow("", controls); self._widgets["_members"] = table

    def _append_member(self, table, member):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row)
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(member.get("name", "flag"))))
            combo = QtWidgets.QComboBox(); combo.addItems(["flag", "unsigned", "signed", "padding", "enum"]); combo.setCurrentText(member.get("kind", "flag")); table.setCellWidget(row, 1, combo)
            table.setItem(row, 2, QtWidgets.QTableWidgetItem(str(member.get("bits", 1)))); table.item(row, 0).setData(QtCore.Qt.UserRole, member.get("uid", new_id()))
            enums = QtWidgets.QComboBox(); enums.addItem('— Select —', '')
            for enum in self._manifest.get('enums', []):
                if enum.get('storage', {}).get('kind') in {'bits_uint', 'bits_int'}:
                    enums.addItem(enum['name'], enum['uid'])
            enum_uid = member.get('enum_uid', '')
            if enum_uid and enums.findData(enum_uid) < 0:
                enums.addItem('Missing or incompatible enum', enum_uid)
            enums.setCurrentIndex(max(0, enums.findData(enum_uid)))
            table.setCellWidget(row, 3, enums)
            item = table.item(row, 2)
            def update(*args):
                is_enum = combo.currentText() == 'enum'
                enums.setEnabled(is_enum)
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable if is_enum else item.flags() | QtCore.Qt.ItemIsEditable)
                if is_enum:
                    try:
                        enum = next(e for e in self._manifest.get('enums', []) if e['uid'] == enums.currentData())
                        text = str(bit_width(enum))
                    except (StopIteration, ValueError, TypeError): text = '?'
                    blocked = table.blockSignals(True)
                    item.setText(text)
                    table.blockSignals(blocked)
            update()
            combo.currentIndexChanged.connect(update); enums.currentIndexChanged.connect(update)
            combo.currentIndexChanged.connect(self._emit_changed); enums.currentIndexChanged.connect(self._emit_changed)
        finally:
            table.blockSignals(previous)

    def _add_member(self, table):
        self._append_member(table, {"uid": new_id(), "name": "flag", "kind": "flag", "bits": 1})
        self.changed.emit()

    def _remove_member(self, table):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try: table.removeRow(row)
            finally: table.blockSignals(previous)
            self.changed.emit()

    def _read_members(self):
        table = self._widgets["_members"]; result = []
        for row in range(table.rowCount()):
            try: bits = int(table.item(row, 2).text())
            except (AttributeError, ValueError): bits = table.item(row, 2).text() if table.item(row, 2) else ""
            result.append({"uid": table.item(row, 0).data(QtCore.Qt.UserRole) or new_id(), "name": table.item(row, 0).text(), "kind": table.cellWidget(row, 1).currentText(), "bits": bits})
            if result[-1]['kind'] == 'enum':
                result[-1].pop('bits')
                result[-1]['enum_uid'] = table.cellWidget(row, 3).currentData()
        return result

    def _move_member(self, table, delta):
        row = table.currentRow(); target = row + delta
        if row < 0 or not 0 <= target < table.rowCount():
            return
        members = self._read_members(); members[row], members[target] = members[target], members[row]
        previous = table.blockSignals(True); table.setRowCount(0)
        for member in members:
            self._append_member(table, member)
        table.blockSignals(previous); table.setCurrentCell(target, 0)
        self.changed.emit()

    def _cases_table(self, field):
        table = QtWidgets.QTableWidget(0, 2); table.setHorizontalHeaderLabels(["Case value", "Field type"]); table.horizontalHeader().setStretchLastSection(True)
        self._case_items = []
        for case in field.get("cases", []): self._append_case(table, case)
        controls = QtWidgets.QWidget(); row = QtWidgets.QHBoxLayout(controls); row.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton("Add case"); remove = QtWidgets.QPushButton("Remove selected"); row.addWidget(add); row.addWidget(remove)
        up = QtWidgets.QPushButton('Move up'); down = QtWidgets.QPushButton('Move down'); row.addWidget(up); row.addWidget(down); row.addStretch()
        up.clicked.connect(lambda: self._move_case(table, -1)); down.clicked.connect(lambda: self._move_case(table, 1))
        add.clicked.connect(lambda: self._add_case(table))
        remove.clicked.connect(lambda: self._remove_case(table)); table.itemChanged.connect(self._emit_changed)
        self._layout.addRow("Cases", table); self._layout.addRow("", controls); self._widgets["_cases"] = table

    def _append_case(self, table, case):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row); self._case_items.append(copy.deepcopy(case.get("item") or new_field("case")))
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(case.get("value", "0"))))
            table.item(row, 0).setData(QtCore.Qt.UserRole, case.get('uid') or new_id())
            table.item(row, 0).setData(QtCore.Qt.UserRole + 1, case.get('enum_value_uid'))
            table.item(row, 0).setData(QtCore.Qt.UserRole + 2, case.get('class_index'))
            combo = QtWidgets.QComboBox(); combo.addItems(sorted(FIELD_KINDS)); combo.setCurrentText(self._case_items[-1].get("kind", "uint")); combo.currentIndexChanged.connect(self._emit_changed); table.setCellWidget(row, 1, combo)
        finally:
            table.blockSignals(previous)

    def _add_case(self, table):
        self._append_case(table, {"value": "0", "item": new_field("case", "uint")})
        self.changed.emit()

    def _remove_case(self, table):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try:
                table.removeRow(row); self._case_items.pop(row)
            finally:
                table.blockSignals(previous)
            self.changed.emit()

    def _read_cases(self):
        table = self._widgets["_cases"]; result = []
        for row in range(table.rowCount()):
            item = copy.deepcopy(self._case_items[row]); selected = table.cellWidget(row, 1).currentText()
            if item.get("kind") != selected:
                uid = item.get("uid"); item = new_field(item.get("name", "case"), selected); item["uid"] = uid or item["uid"]
            control = table.cellWidget(row, 0)
            text = control.currentText() if control else table.item(row, 0).text()
            case = {"uid": table.item(row, 0).data(QtCore.Qt.UserRole), 'value': text, 'item': item}
            suffix = table.item(row, 0).data(QtCore.Qt.UserRole + 2)
            if suffix is not None:
                case['class_index'] = suffix
            if control and control.findText(text) >= 0:
                case['enum_value_uid'] = control.itemData(control.findText(text))
            elif table.item(row, 0).data(QtCore.Qt.UserRole + 1):
                case['enum_value_uid'] = table.item(row, 0).data(QtCore.Qt.UserRole + 1)
            result.append(case)
        return result

    def _reference_enum(self, key, expression_key):
        widget = self._widgets.get(key)
        path = widget.currentData() if widget else ''
        if not path:
            expression = self._widgets.get(expression_key)
            raw = expression.text() if isinstance(expression, QtWidgets.QLineEdit) else ''
            path = raw.removeprefix('this.') if raw.startswith('this.') else ''
        definition = dict(scope_candidates(self._manifest, self._base.get('uid'))).get(path, {})
        while definition.get('kind') in {'const', 'default', 'rebuild', 'length'}:
            definition = definition.get('item', {})
        return next((enum for enum in self._manifest.get('enums', []) if enum.get('uid') == definition.get('enum_uid')), {})

    def _move_case(self, table, delta):
        row = table.currentRow(); target = row + delta
        if row < 0 or not 0 <= target < table.rowCount():
            return
        cases = self._read_cases(); cases[row], cases[target] = cases[target], cases[row]
        previous = table.blockSignals(True)
        table.setRowCount(0); self._case_items = []
        for case in cases:
            self._append_case(table, case)
        table.blockSignals(previous); table.setCurrentCell(target, 0)
        self.changed.emit()


def _prior_sibling_fields(manifest: dict[str, Any], target_uid: str) -> list[dict[str, Any]]:
    """Find earlier fields in the target's exact Construct Struct scope."""
    for owner in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        found, prior = _find_field_scope(owner.get("fields", []), target_uid)
        if found:
            return prior
    return []


def _find_field_scope(fields: list[dict[str, Any]], target_uid: str):
    prior = []
    for field in fields:
        if field.get("uid") == target_uid:
            return True, prior
        if field.get("kind") == "inline_struct":
            found, nested_prior = _find_field_scope(field.get("fields", []), target_uid)
            if found:
                return True, nested_prior
        nested = field.get("item")
        if isinstance(nested, dict):
            found, nested_prior = _find_field_scope([nested], target_uid)
            if found:
                return True, nested_prior
        for case in field.get("cases", []):
            nested = case.get("item")
            if isinstance(nested, dict):
                found, nested_prior = _find_field_scope([nested], target_uid)
                if found:
                    return True, nested_prior
        prior.append(field)
    return False, []


def _is_integer_reference(field: dict[str, Any]) -> bool:
    kind = field.get("kind")
    if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "enum"}:
        return True
    if kind in {"const", "default", "rebuild", "length"} and isinstance(field.get("item"), dict):
        return _is_integer_reference(field["item"])
    return False
