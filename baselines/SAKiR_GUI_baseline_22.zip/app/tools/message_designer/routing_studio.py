from __future__ import annotations

import copy
import struct
from typing import Any

from PyQt5 import QtCore, QtWidgets

from .routing_editor import IdentifierDefinitionsEditor, AncestorValuesEditor
from .routing_model import ancestor_assignments, owners_by_uid
from .validation import ValidationIssue, validate_manifest
from .editing import merge_edits, read_routing_draft
from .routing_graph import RoutingGraphView
from .routing_graph_model import build_route_graph
from .ui_metrics import BOTTOM_PANEL_HEIGHT


class RoutingHierarchyTree(QtWidgets.QTreeWidget):
    reparentRequested = QtCore.pyqtSignal(str, str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderLabels(["Group / message"])
        self.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        self.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.before_drag = None

    def startDrag(self, supported_actions):
        if self.before_drag is not None: self.before_drag()
        super().startDrag(supported_actions)

    def dropEvent(self, event):
        item = self.currentItem()
        if item is None:
            return
        uid = item.data(0, QtCore.Qt.UserRole) or ""
        kind = item.data(0, QtCore.Qt.UserRole + 1) or ""
        super().dropEvent(event)
        parent = item.parent()
        parent_kind = parent.data(0, QtCore.Qt.UserRole + 1) if parent else ""
        parent_uid = parent.data(0, QtCore.Qt.UserRole) if parent else ""
        valid = (kind == "Group" and parent_kind in {"Library", "Group"}) or (kind == "Message" and parent_kind in {"Library", "Group"})
        cursor = parent
        while valid and cursor is not None:
            if cursor is item: valid = False
            cursor = cursor.parent()
        self.reparentRequested.emit(str(uid), str(parent_uid or ""), str(kind if valid else ""))


class RoutingStudio(QtWidgets.QWidget):
    manifestApplied = QtCore.pyqtSignal(object, str)
    pendingChanged = QtCore.pyqtSignal(bool)
    validationChanged = QtCore.pyqtSignal(object)
    reparentRequested = QtCore.pyqtSignal(str, str, str)
    openDefinitionRequested = QtCore.pyqtSignal(str)
    editRequested = QtCore.pyqtSignal(object)
    flushRequested = QtCore.pyqtSignal()
    draftsChanged = QtCore.pyqtSignal()
    editorsRebuilt = QtCore.pyqtSignal()
    viewStateChanged = QtCore.pyqtSignal()
    addGroupRequested = QtCore.pyqtSignal(str)
    addMessageRequested = QtCore.pyqtSignal(str)
    defaultsTransferRequested = QtCore.pyqtSignal(str, str)

    def minimumSizeHint(self):
        return QtCore.QSize(320, 240)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._manifest = {}; self._selected_uid = ''; self._loading = False; self._editor_dirty = False
        self._drafts = {}; self._editor_base = {}; self.commit_edits = None
        self.validation_timer = QtCore.QTimer(self); self.validation_timer.setSingleShot(True)
        self.validation_timer.setInterval(150); self.validation_timer.timeout.connect(self._refresh_validation)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSizeConstraint(QtWidgets.QLayout.SetNoConstraint)
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        heading = QtWidgets.QLabel('Group identifiers and automatic decoding'); heading.setStyleSheet('font-size: 16px; font-weight: 600;')
        header = QtWidgets.QHBoxLayout(); header.addWidget(heading, 1)
        self.view_mode = QtWidgets.QComboBox(); self.view_mode.addItems(['Tree', 'Graph'])
        self.view_mode.setAccessibleName('Routing view'); self.view_mode.setToolTip('View routing as a tree or an interactive graph')
        header.addWidget(self.view_mode); layout.addLayout(header)
        splitter = self.splitter = QtWidgets.QSplitter(); splitter.setChildrenCollapsible(False); layout.addWidget(splitter, 1)
        left = QtWidgets.QFrame(); left.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding); left_layout = QtWidgets.QVBoxLayout(left)
        self.search = QtWidgets.QLineEdit(); self.search.setPlaceholderText('Search groups and messages…'); self.search.setClearButtonEnabled(True)
        left_layout.addWidget(self.search)
        self.views = QtWidgets.QStackedWidget(); left_layout.addWidget(self.views, 1)
        self.tree = RoutingHierarchyTree(); self.tree.setColumnWidth(0, 220); self.views.addWidget(self.tree)
        self.graph_view = RoutingGraphView(); self.views.addWidget(self.graph_view)
        self.graph = self.graph_view.canvas
        splitter.addWidget(left)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.inspector = QtWidgets.QWidget(); self.form = QtWidgets.QVBoxLayout(self.inspector); self.form.setAlignment(QtCore.Qt.AlignTop)
        left.setFrameStyle(scroll.frameStyle())
        left.setPalette(self.inspector.palette()); left.setBackgroundRole(self.inspector.backgroundRole()); left.setAutoFillBackground(True)
        self.heading = QtWidgets.QLabel(); self.heading.setStyleSheet('font-size: 15px; font-weight: 600;')
        self.path = QtWidgets.QLabel(); self.path.setWordWrap(True)
        self.form.addWidget(self.heading); self.form.addWidget(self.path)
        self.definition_group = QtWidgets.QGroupBox('Identifier definitions for this group'); self.definition_layout = QtWidgets.QVBoxLayout(self.definition_group); self.form.addWidget(self.definition_group)
        self.ancestor_group = QtWidgets.QGroupBox('Expected values for ancestor identifiers'); self.ancestor_layout = QtWidgets.QVBoxLayout(self.ancestor_group); self.form.addWidget(self.ancestor_group)
        transfers = QtWidgets.QHBoxLayout()
        self.pull_defaults = QtWidgets.QPushButton('Get expected values from defaults')
        self.push_defaults = QtWidgets.QPushButton('Push expected values to defaults')
        transfers.addWidget(self.pull_defaults); transfers.addWidget(self.push_defaults)
        self.form.addLayout(transfers)
        self.pull_defaults.clicked.connect(lambda: self.defaultsTransferRequested.emit(self._selected_uid, 'pull'))
        self.push_defaults.clicked.connect(lambda: self.defaultsTransferRequested.emit(self._selected_uid, 'push'))
        footer = QtWidgets.QHBoxLayout(); self.state = QtWidgets.QLabel(); self.state.setWordWrap(True)
        footer.addWidget(self.state, 1)
        self.open_definition = QtWidgets.QPushButton('Open in Definitions')
        self.apply = QtWidgets.QPushButton('Apply now')
        self.revert = QtWidgets.QPushButton('Revert draft'); self.revert.clicked.connect(self.revert_draft)
        footer.addWidget(self.open_definition); footer.addWidget(self.revert); footer.addWidget(self.apply); self.form.addLayout(footer)
        scroll.setWidget(self.inspector); splitter.addWidget(scroll); splitter.setSizes([430, 950])
        self._trace_active = False
        self.issues = QtWidgets.QTreeWidget()
        self.issues.setHeaderLabels(['Severity', 'Validation issue', 'Suggested action'])
        self.issues.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.issues.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.setRootIsDecorated(False)
        self.issues.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.issues.setFixedHeight(BOTTOM_PANEL_HEIGHT); layout.addWidget(self.issues)
        self.tree.currentItemChanged.connect(self._selection_changed); self.tree.reparentRequested.connect(self.reparentRequested)
        self.search.textChanged.connect(self._filter_tree)
        self.search.textChanged.connect(self.graph.set_query)
        self.view_mode.currentIndexChanged.connect(self._view_changed)
        self.graph.selectionRequested.connect(self._select_graph_uid)
        self.graph.openDefinitionRequested.connect(self.openDefinitionRequested)
        self.graph.stateChanged.connect(self.viewStateChanged)
        self.graph.addGroupRequested.connect(self.addGroupRequested)
        self.graph.addMessageRequested.connect(self.addMessageRequested)
        self.graph.moveRequested.connect(self.reparentRequested)
        self.open_definition.clicked.connect(lambda: self.openDefinitionRequested.emit(self._selected_uid))
        self.apply.clicked.connect(self._apply)
        self._set_pending(False)

    def refresh(self, manifest, selected_uid='', *, keep_drafts=False, preserve_editor=False):
        self.validation_timer.stop()
        if not keep_drafts: self._drafts.clear()
        previous_loading = self._loading
        self._loading = True
        self._manifest = copy.deepcopy(manifest)
        self.tree.clear()
        library = self._manifest.get('library', {})
        root = self._item(library, 'Library'); self.tree.addTopLevelItem(root)
        projection = build_route_graph(self._manifest)
        items = {library['uid']: root}
        for kind, owners in [('Group', self._manifest.get('groups', [])), ('Message', self._manifest.get('messages', []))]:
            for owner in owners: items[owner['uid']] = self._item(owner, kind)
        for uid, node in projection.nodes.items():
            if uid == library['uid']: continue
            parent = items.get(node.parent_uid)
            if parent is not None: parent.addChild(items[uid])
            else: self.tree.addTopLevelItem(items[uid])
        target = self._find_item(selected_uid or self._selected_uid) or root
        self.tree.setCurrentItem(target); self.tree.expandAll()
        self._selected_uid = target.data(0, QtCore.Qt.UserRole)
        self._loading = False
        if not preserve_editor:
            self._editor_dirty = False; self._rebuild_editor()
        else:
            if self._selected_uid not in self._drafts:
                self._editor_base = copy.deepcopy(self._object(self._selected_uid) or {})
            self._editor_dirty = self._selected_uid in self._drafts
            self._refresh_validation()
        self._set_pending(bool(self._drafts))
        self._loading = previous_loading
        self._filter_tree(self.search.text())

    def _view_changed(self, index):
        self.views.setCurrentIndex(index)
        self.splitter.setSizes([800, 580] if index else [430, 950])
        self.graph.select_uid(self._selected_uid)
        self.viewStateChanged.emit()

    def _select_graph_uid(self, uid):
        item = self._find_item(uid)
        if item is not None:
            self.tree.setCurrentItem(item)
            self.tree.scrollToItem(item)

    def view_state(self):
        return {'mode': self.view_mode.currentText(), 'graph': self.graph.export_state()}

    def restore_view_state(self, state):
        if not isinstance(state, dict): return
        self.graph.restore_state(state.get('graph', {}))
        self.view_mode.setCurrentIndex(1 if state.get('mode') == 'Graph' else 0)

    def clear_trace(self):
        if not self._trace_active: return
        self._trace_active = False
        self.graph.set_trace()

    def show_trace(self, diagnostic):
        if diagnostic is not None and self.search.text(): self.search.clear()
        self._trace_active = diagnostic is not None
        self.graph.set_trace(diagnostic)

    def _item(self, owner, kind):
        item = QtWidgets.QTreeWidgetItem([owner.get('name') or owner.get('display_name') or 'Library'])
        item.setData(0, QtCore.Qt.UserRole, owner.get('uid')); item.setData(0, QtCore.Qt.UserRole + 1, kind)
        if kind in {'Library', 'Group'}: item.setFlags(item.flags() | QtCore.Qt.ItemIsDropEnabled)
        if kind == 'Library': item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDragEnabled)
        if kind == 'Message': item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDropEnabled)
        return item

    def _find_item(self, uid):
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            if iterator.value().data(0, QtCore.Qt.UserRole) == uid: return iterator.value()
            iterator += 1
        return None

    def _object(self, uid):
        return next((item for item in [self._manifest.get('library', {}), *self._manifest.get('groups', []), *self._manifest.get('messages', [])] if item.get('uid') == uid), None)

    def _selection_changed(self, current, previous):
        if self._loading or current is None: return
        uid = current.data(0, QtCore.Qt.UserRole)
        self.stage_current()
        self._loading = True
        self.flushRequested.emit()
        self._selected_uid = uid
        blocker = QtCore.QSignalBlocker(self.tree); self.tree.setCurrentItem(self._find_item(uid)); del blocker
        self._loading = False
        self._rebuild_editor(); self._set_pending(bool(self._drafts))
        if self.search.text() and uid not in self.graph.cards:
            self.search.clear()
        self.graph.select_uid(uid)
        self.graph.locate_selection()

    def _rebuild_editor(self):
        self._loading = True
        for layout in (self.definition_layout, self.ancestor_layout):
            while layout.count():
                widget = layout.takeAt(0).widget()
                if widget: widget.hide(); widget.deleteLater()
        owner = self._object(self._selected_uid)
        if owner is None: self._loading = False; return
        draft = self._drafts.get(self._selected_uid)
        self._editor_base = copy.deepcopy(draft['base'] if draft else owner)
        self._selected_kind = 'Library' if owner is self._manifest['library'] else 'Group' if 'parent_group_uid' in owner else 'Message'
        self.heading.setText((owner.get('name') or owner.get('display_name') or 'Library') + ' · ' + self._selected_kind)
        self.path.setText('Identifiers use absolute offsets in the complete packet. Group decoding also verifies every ancestor.')
        self.definition_group.setVisible(self._selected_kind != 'Message')
        self.ancestor_group.setVisible(self._selected_kind != 'Library')
        transferable = any(definition.get('source', 'raw') == 'field'
                           for _, definition, _, _ in ancestor_assignments(self._manifest, owner))
        for button in (self.pull_defaults, self.push_defaults):
            button.setVisible(self._selected_kind != 'Library')
            button.setEnabled(transferable)
            button.setToolTip('Preview transfers for field identifiers, including inherited checks.' if transferable else
                              'Choose a Common message field identifier. Raw byte identifiers cannot transfer defaults.')
        if self._selected_kind != 'Message':
            definitions = draft.get('definitions', owner.get('identifiers', [])) if draft else owner.get('identifiers', [])
            self.identifier_editor = IdentifierDefinitionsEditor(definitions, self._manifest, owner)
            if draft and 'raw_layouts' in draft: self.identifier_editor._raw_layouts.update(draft['raw_layouts'])
            self.identifier_editor.changed.connect(self._edited); self.definition_layout.addWidget(self.identifier_editor)
        if self._selected_kind != 'Library':
            self.values_editor = AncestorValuesEditor(self._manifest, owner)
            if draft and 'values' in draft: self.values_editor.restore_draft(draft['values'])
            self.values_editor.changed.connect(self._edited); self.ancestor_layout.addWidget(self.values_editor)
        self._editor_dirty = bool(draft); self._loading = False
        self._refresh_validation()
        self.editorsRebuilt.emit()

    def _edited(self):
        if not self._loading:
            self.clear_trace()
            self._editor_dirty = True
            self.stage_current()
            self._set_pending(True); self.validation_timer.start()
            editor = self.sender()
            self.editRequested.emit(getattr(editor, '_edit_source', None))

    def stage_current(self):
        if not self._editor_dirty or self._loading: return
        draft = self._drafts.get(self._selected_uid, {'base': copy.deepcopy(self._editor_base)})
        if self._selected_kind != 'Message':
            draft['definitions'] = self.identifier_editor.draft_value()
            draft['raw_layouts'] = copy.deepcopy(self.identifier_editor._raw_layouts)
        if self._selected_kind != 'Library':
            state = self.values_editor.draft_state()
            state['texts'] = {**draft.get('values', {}).get('texts', {}), **state['texts']}
            draft['values'] = state
        draft.pop('error', None)
        self._drafts[self._selected_uid] = draft
        self.draftsChanged.emit()

    def apply_drafts(self, manifest):
        owners = {item['uid']: item for item in [manifest['library'], *manifest.get('groups', []), *manifest.get('messages', [])]}
        applied = []
        for uid, draft in list(self._drafts.items()):
            owner = owners.get(uid)
            if owner is None:
                self._drafts.pop(uid, None); continue
            try:
                changes = read_routing_draft(manifest, owner, draft)
                merge_edits(owner, {key: draft['base'].get(key) for key in changes}, changes)
            except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
                draft['error'] = str(error); continue
            applied.append(uid); self._drafts.pop(uid)
            if uid == self._selected_uid:
                self._editor_base = copy.deepcopy(owner); self._editor_dirty = False
        self._set_pending(bool(self._drafts))
        return applied

    def revert_draft(self):
        self._drafts.pop(self._selected_uid, None)
        self._editor_dirty = False
        self._rebuild_editor(); self._set_pending(bool(self._drafts)); self.draftsChanged.emit()

    def _refresh_validation(self):
        if not self._manifest: return
        self.validation_timer.stop()
        manifest = copy.deepcopy(self._manifest)
        input_issues = []
        for uid, draft in self._drafts.items():
            owner = next((item for item in [manifest['library'], *manifest.get('groups', []), *manifest.get('messages', [])]
                          if item['uid'] == uid), None)
            if owner is not None:
                try:
                    changes = read_routing_draft(manifest, owner, draft)
                    merge_edits(owner, {key: draft['base'].get(key) for key in changes}, changes)
                except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
                    draft['error'] = str(error)
                    input_issues.append(ValidationIssue('error', 'routing-input', str(error), uid))
        issues = [*input_issues, *validate_manifest(manifest), *self._decoding_warnings(manifest)]
        self.graph.set_graph(build_route_graph(manifest, issues, self._drafts), self._selected_uid)
        self.validationChanged.emit(issues)

    @staticmethod
    def _decoding_warnings(manifest):
        warnings = []
        owners = owners_by_uid(manifest)
        root = manifest['library']
        for item in [*manifest.get('groups', []), *manifest.get('messages', [])]:
            current = item; seen = set()
            while current is not root and current['uid'] not in seen:
                seen.add(current['uid'])
                parent_uid = current.get('parent_group_uid') if 'parent_group_uid' in current else current.get('group_uid')
                parent = owners.get(parent_uid or root['uid'])
                if parent is None: break
                values = current.get('expected_values')
                if values is None or (isinstance(values, dict) and any(values.get(identifier['uid']) is None for identifier in parent.get('identifiers', []))):
                    inherited = current is not item
                    reason = (f"ancestor group '{current.get('name', 'Group')}' has unassigned expected values" if inherited else
                              'its expected values are unassigned or incomplete')
                    warnings.append(ValidationIssue(
                        'warning', 'routing-ancestor-unassigned' if inherited else 'routing-unassigned',
                        f"{item.get('name', 'Unnamed')} is excluded from automatic decoding because {reason}.", current['uid'],
                    ))
                    break
                current = parent
        return warnings

    def _apply(self):
        return self.apply_pending()

    def pending_manifest(self):
        self.stage_current()
        manifest = copy.deepcopy(self._manifest)
        owners = {item['uid']: item for item in [manifest['library'], *manifest.get('groups', []), *manifest.get('messages', [])]}
        for uid, draft in self._drafts.items():
            owner = owners.get(uid)
            if owner is not None:
                changes = read_routing_draft(manifest, owner, draft)
                merge_edits(owner, {key: draft['base'].get(key) for key in changes}, changes)
        return manifest

    def apply_pending(self):
        if self.commit_edits is not None:
            return self.commit_edits(show_errors=True)
        try: manifest = self.pending_manifest()
        except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
            QtWidgets.QMessageBox.warning(self, 'Invalid routing value', str(error)); return False
        self.manifestApplied.emit(manifest, 'Edit group identifiers and expected values')
        return not self.apply.isEnabled()

    def _set_pending(self, pending):
        changed = self.apply.isEnabled() != pending
        self.apply.setEnabled(pending)
        draft = self._drafts.get(self._selected_uid, {})
        self.state.setText(('Draft: ' + draft['error']) if draft.get('error') else
                           f'{len(self._drafts)} routing draft(s) need attention.' if pending and not draft else
                           'Routing changes are not applied.' if pending else 'All routing changes are applied.')
        self.state.setStyleSheet('color: #b54708; font-weight: 600;' if pending else 'color: #287d3c;')
        self.revert.setEnabled(self._selected_uid in self._drafts)
        if changed: self.pendingChanged.emit(pending)

    def _filter_tree(self, text):
        terms = str(text).casefold().split()
        def visit(item):
            descendants = [visit(item.child(index)) for index in range(item.childCount())]
            visible = not terms or all(term in item.text(0).casefold() for term in terms) or any(descendants)
            item.setHidden(not visible); return visible
        for index in range(self.tree.topLevelItemCount()): visit(self.tree.topLevelItem(index))
