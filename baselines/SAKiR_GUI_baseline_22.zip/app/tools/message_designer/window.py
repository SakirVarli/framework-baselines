from __future__ import annotations

import ast
import copy
import json
import os
import re
import struct
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets, sip

from app.binary_messages.errors import AmbiguousMessageIdentityError

from .commands import ReplaceManifestCommand
from .behavior_identity import resolve_behavior_classes
from .editing import EditorFocusEvents, check_property_input, merge_edits, read_routing_draft
from .generation import compatibility_changes, generate_library, remove_empty_orphans
from .field_editor import FieldOptionsEditor
from .field_moves import can_move_field, move_field
from .group_moves import can_move_group, move_group
from .message_moves import can_move_message, move_message
from .transfers import (
    capture as capture_objects, destination_children, locations as object_locations,
    move_objects, owned_ids, paste_copy, sources as transfer_sources,
)
from .member_editor import DefinitionOptionsEditor
from .model import (
    MessageDesignerDocument,
    new_constant,
    new_enum,
    new_field,
    new_group,
    new_id,
    new_manifest,
    new_message,
    new_method,
    normalize_manifest,
    sync_message_names,
    new_runtime_attribute,
    new_structure,
    walk_fields,
)
from .persistence import (
    ExternalModificationError,
    LoadedLibrary,
    LibraryPersistenceError,
    load_library,
    save_library,
)
from .validation import FIELD_KINDS, ValidationIssue, validate_behavior_methods, validate_manifest
from .session import clear_session, default_session_path, load_session, save_session
from .sandbox_values import (
    SandboxValueError,
    format_object_values,
    parse_object_values,
    sample_message_values,
)
from .wire_size import WireSizeAnalyzer
from .routing_paths import RoutingMatchError, identify_manifest_route
from .routing_studio import RoutingStudio
from .routing_model import compile_manifest_routing
from .routing_defaults import TRANSFER_ERRORS
from .routing_defaults_dialog import RoutingDefaultsDialog
from .result_model import RunResult, OPERATIONS, wire_identity, semantic_values
from .result_view import ResultsPanel
from .ui_metrics import BOTTOM_PANEL_HEIGHT
from app.binary_messages.json_codec import from_json_value


class DesignerStatusBar(QtWidgets.QStatusBar):
    """Use the status widgets for text, while retaining Qt's timed message API."""

    def showMessage(self, message, timeout=0):
        self.message_deadline = time.monotonic() + timeout / 1000 if timeout else None
        super().showMessage(message, timeout)

    def paintEvent(self, event):
        option = QtWidgets.QStyleOption()
        option.initFrom(self)
        painter = QtGui.QPainter(self)
        self.style().drawPrimitive(QtWidgets.QStyle.PE_PanelStatusBar, option, painter, self)


class CutNameDelegate(QtWidgets.QStyledItemDelegate):
    """Keep cut names shaded even while their rows are selected."""

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        if index.data(DefinitionTree.CUT_ROLE):
            color = option.palette.color(QtGui.QPalette.Disabled, QtGui.QPalette.Text)
            option.palette.setColor(QtGui.QPalette.Text, color)
            option.palette.setColor(QtGui.QPalette.HighlightedText, color)


class DefinitionTree(QtWidgets.QTreeWidget):
    orderDropped = QtCore.pyqtSignal(object)
    FIELD_MIME_TYPE = "application/x-sakir-message-field"
    MESSAGE_MIME_TYPE = "application/x-sakir-message-definition"
    GROUP_MIME_TYPE = "application/x-sakir-message-group"
    BATCH_MIME_TYPE = "application/x-sakir-definition-batch"
    CUT_ROLE = QtCore.Qt.UserRole + 24

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setItemDelegateForColumn(0, CutNameDelegate(self))
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.itemSelectionChanged.connect(self._enforce_sibling_selection)
        self.batch_move_allowed = None
        self.move_batch = None
        self.field_move_allowed = None
        self.move_field = None
        self.message_move_allowed = None
        self.move_message = None
        self.group_move_allowed = None
        self.move_group = None
        self.before_drag = None
        self._drag_details = None
        self._drag_point = None
        self._drop_feedback = None
        self._saved_drop_indicator = None
        self._hover_parent = QtCore.QPersistentModelIndex()
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(650)
        self._hover_timer.timeout.connect(self._expand_hover_parent)
        self.model().modelAboutToBeReset.connect(self._clear_drop_feedback)
        self.header().sectionResized.connect(lambda *_: self._refresh_drop_feedback())

    def minimumSizeHint(self):
        return QtCore.QSize(220, 140)

    @staticmethod
    def _same_siblings(first, second):
        a = first.data(0, QtCore.Qt.UserRole) or {}
        b = second.data(0, QtCore.Qt.UserRole) or {}
        return bool(a.get("uid") and b.get("uid") and a.get("kind") == b.get("kind")
                    and first.parent() is second.parent())

    def selectionCommand(self, index, event=None):
        selected = self.selectedItems()
        item = self.itemFromIndex(index)
        if event is not None and event.modifiers() & (QtCore.Qt.ControlModifier | QtCore.Qt.ShiftModifier):
            if selected and item is not None and not self._same_siblings(selected[0], item):
                return QtCore.QItemSelectionModel.NoUpdate
        return super().selectionCommand(index, event)

    def mousePressEvent(self, event):
        item = self.itemAt(event.pos())
        selected = self.selectedItems()
        if (event.button() == QtCore.Qt.LeftButton and event.modifiers() & QtCore.Qt.ControlModifier
                and item is not None and selected and not self._same_siblings(selected[0], item)):
            event.accept()
            return
        super().mousePressEvent(event)

    def _enforce_sibling_selection(self):
        selected = self.selectedItems()
        if len(selected) < 2:
            return
        anchor = self.currentItem()
        if anchor not in selected:
            anchor = selected[0]
        blocker = QtCore.QSignalBlocker(self)
        for item in selected:
            if not self._same_siblings(anchor, item):
                item.setSelected(False)
        del blocker

    def selected_uids(self):
        items = self.selectedItems()
        if not items:
            return []
        parent = items[0].parent()
        if parent is not None:
            items.sort(key=parent.indexOfChild)
        return [(item.data(0, QtCore.Qt.UserRole) or {}).get("uid", "") for item in items]

    def restore_selection(self, uids, current_uid=None):
        wanted = set(uids)
        blocker = QtCore.QSignalBlocker(self)
        self.clearSelection()
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        current = None
        while iterator.value():
            item = iterator.value()
            uid = (item.data(0, QtCore.Qt.UserRole) or {}).get("uid")
            if uid in wanted:
                item.setSelected(True)
                if current is None or uid == current_uid:
                    current = item
            iterator += 1
        if current is not None:
            self.setCurrentItem(current, 0, QtCore.QItemSelectionModel.NoUpdate)
        del blocker

    def startDrag(self, supported_actions):
        if self.before_drag is not None:
            self.before_drag()
        item = self.currentItem()
        info = (item.data(0, QtCore.Qt.UserRole) or {}) if item else {}
        mime_types = {
            "Field": self.FIELD_MIME_TYPE,
            "Message": self.MESSAGE_MIME_TYPE,
            "Group": self.GROUP_MIME_TYPE,
        }
        if info.get("kind") not in COLLECTION_TREE_KINDS:
            super().startDrag(supported_actions)
            return
        items = self.selectedItems() or [item]
        if any(not selected.flags() & QtCore.Qt.ItemIsDragEnabled for selected in items):
            return
        mime = self.mimeData(items)
        uids = self.selected_uids() or [info["uid"]]
        if len(uids) == 1 and info["kind"] in mime_types:
            mime.setData(mime_types[info["kind"]], info["uid"].encode("utf-8"))
        else:
            mime.setData(self.BATCH_MIME_TYPE, json.dumps({"kind": info["kind"], "uids": uids}).encode("utf-8"))
        drag = QtGui.QDrag(self)
        drag.setMimeData(mime)
        # The document owns this move; Qt must not remove rows after the drop.
        try:
            drag.exec_(QtCore.Qt.MoveAction, QtCore.Qt.MoveAction)
        finally:
            self._clear_drop_feedback()
            drag.deleteLater()

    def _definition_drag_details(self, event):
        if event.source() is not self:
            return None
        if event.mimeData().hasFormat(self.BATCH_MIME_TYPE):
            try:
                payload = json.loads(bytes(event.mimeData().data(self.BATCH_MIME_TYPE)))
                if (payload["kind"] in COLLECTION_TREE_KINDS and isinstance(payload["uids"], list)
                        and payload["uids"] and all(isinstance(uid, str) for uid in payload["uids"])):
                    return payload["kind"], payload["uids"], self.batch_move_allowed, self.move_batch
            except (ValueError, KeyError, TypeError):
                pass
            return None
        for kind, mime_type, allowed, move in (
            ("Field", self.FIELD_MIME_TYPE, self.field_move_allowed, self.move_field),
            ("Message", self.MESSAGE_MIME_TYPE, self.message_move_allowed, self.move_message),
            ("Group", self.GROUP_MIME_TYPE, self.group_move_allowed, self.move_group),
        ):
            if event.mimeData().hasFormat(mime_type):
                uid = bytes(event.mimeData().data(mime_type)).decode("utf-8")
                return kind, uid, allowed, move
        return None

    def _row_at(self, point):
        item = self.itemAt(point)
        if item is not None:
            return item
        # The branch gutter and the empty space after the columns are part of a row.
        for column in range(self.columnCount()):
            if self.isColumnHidden(column):
                continue
            left = max(0, self.columnViewportPosition(column))
            right = min(self.viewport().width(), self.columnViewportPosition(column) + self.columnWidth(column))
            if left < right:
                return self.itemAt(QtCore.QPoint((left + right) // 2, point.y()))
        return None

    def _branch_rect(self, item):
        rect = self.visualRect(self.indexFromItem(item, 0))
        if self.layoutDirection() == QtCore.Qt.RightToLeft:
            return QtCore.QRect(rect.right() + 1, rect.top(), self.indentation(), rect.height())
        return QtCore.QRect(rect.left() - self.indentation(), rect.top(), self.indentation(), rect.height())

    def _drop_location(self, point):
        if not self.viewport().rect().contains(point):
            return None, QtWidgets.QAbstractItemView.OnViewport
        target = self._row_at(point)
        if target is None:
            return None, QtWidgets.QAbstractItemView.OnViewport
        # Each indentation slot targets that ancestor, including its disclosure arrow.
        ancestor = target
        while ancestor is not None:
            branch = self._branch_rect(ancestor)
            if branch.left() <= point.x() <= branch.right():
                return ancestor, QtWidgets.QAbstractItemView.OnItem
            ancestor = ancestor.parent()
        rect = self.visualItemRect(target)
        margin = max(2, min(5, rect.height() // 4))
        if point.y() < rect.top() + margin:
            position = QtWidgets.QAbstractItemView.AboveItem
        elif point.y() > rect.bottom() - margin:
            position = QtWidgets.QAbstractItemView.BelowItem
        elif target.flags() & QtCore.Qt.ItemIsDropEnabled:
            position = QtWidgets.QAbstractItemView.OnItem
        else:
            position = (QtWidgets.QAbstractItemView.AboveItem if point.y() < rect.center().y()
                        else QtWidgets.QAbstractItemView.BelowItem)
        return target, position

    def _field_drop_request(self, event):
        uid = bytes(event.mimeData().data(self.FIELD_MIME_TYPE)).decode("utf-8")
        target, position = self._drop_location(event.pos())
        return self._request_at("Field", uid, self.field_move_allowed, target, position)

    def _message_drop_request(self, event):
        return self._hierarchy_drop_request(event, "Message", self.MESSAGE_MIME_TYPE, self.message_move_allowed)

    def _group_drop_request(self, event):
        return self._hierarchy_drop_request(event, "Group", self.GROUP_MIME_TYPE, self.group_move_allowed)

    def _hierarchy_drop_request(self, event, kind, mime_type, allowed):
        uid = bytes(event.mimeData().data(mime_type)).decode("utf-8")
        target, position = self._drop_location(event.pos())
        return self._request_at(kind, uid, allowed, target, position)

    def _request_at(self, kind, uid, allowed, target, position):
        if target is None:
            return None
        info = target.data(0, QtCore.Qt.UserRole) or {}
        if position == QtWidgets.QAbstractItemView.OnItem:
            parent = target
            boundary = parent.childCount()
        elif position in (QtWidgets.QAbstractItemView.AboveItem, QtWidgets.QAbstractItemView.BelowItem):
            if info.get("kind") != kind or target.parent() is None:
                return None
            parent = target.parent()
            boundary = parent.indexOfChild(target) + (position == QtWidgets.QAbstractItemView.BelowItem)
        else:
            return None
        parent_info = parent.data(0, QtCore.Qt.UserRole) or {}
        if kind == "Field":
            if not parent_info.get("field_container"):
                return None
            parent_uid = parent_info["uid"]
        elif kind in {"Group", "Message"} and parent_info.get("kind") == "Group":
            parent_uid = parent_info["uid"]
        elif kind in {"Group", "Message"} and parent_info.get("category") == "messages" and parent.parent() is not None:
            parent_uid = (parent.parent().data(0, QtCore.Qt.UserRole) or {}).get("uid")
        elif kind in {"Enum", "Structure"} and parent_info.get("category") == {"Enum": "enums", "Structure": "structures"}[kind]:
            parent_uid = (parent.parent().data(0, QtCore.Qt.UserRole) or {}).get("uid")
        elif kind in {"Runtime", "Constant", "Method"} and parent_info.get("kind") == "Message":
            parent_uid = parent_info["uid"]
        elif kind in {"Runtime", "Constant", "Method"} and parent_info.get("category") == {"Runtime": "runtime_attributes", "Constant": "constants", "Method": "methods"}[kind]:
            parent_uid = parent_info["owner_uid"]
        else:
            return None
        index = sum(
            (parent.child(row).data(0, QtCore.Qt.UserRole) or {}).get("kind") == kind
            for row in range(boundary)
        )
        if kind in {"Runtime", "Constant", "Method"} and parent_info.get("kind") == "Message":
            index = sum(child.childCount() for child in (parent.child(row) for row in range(parent.childCount()))
                        if (child.data(0, QtCore.Qt.UserRole) or {}).get("category") ==
                        {"Runtime": "runtime_attributes", "Constant": "constants", "Method": "methods"}[kind])
        request = uid, parent_uid, index
        if allowed and allowed(*request):
            return request
        return None

    def _hide_native_drop_indicator(self):
        if self._saved_drop_indicator is None:
            self._saved_drop_indicator = self.showDropIndicator()
            self.setDropIndicatorShown(False)

    def dragEnterEvent(self, event):
        super().dragEnterEvent(event)
        if self._definition_drag_details(event) is not None:
            self._hide_native_drop_indicator()
            event.setDropAction(QtCore.Qt.MoveAction)
            event.accept()

    def dragMoveEvent(self, event):
        details = self._definition_drag_details(event)
        if details is None:
            self._clear_drop_feedback()
            super().dragMoveEvent(event)
            return
        self._hide_native_drop_indicator()
        super().dragMoveEvent(event)
        self._drag_details = details
        self._drag_point = QtCore.QPoint(event.pos())
        self._refresh_drop_feedback()
        if self._drop_feedback is None:
            event.ignore()
        else:
            event.setDropAction(QtCore.Qt.MoveAction)
            event.accept()

    def _refresh_drop_feedback(self):
        if self._drag_details is None or self._drag_point is None:
            return
        kind, uid, allowed, _ = self._drag_details
        target, position = self._drop_location(self._drag_point)
        request = self._request_at(kind, uid, allowed, target, position)
        self._drop_feedback = None
        hover = QtCore.QPersistentModelIndex()
        if request is not None:
            parent = target if position == QtWidgets.QAbstractItemView.OnItem else target.parent()
            self._drop_feedback = {
                "parent": QtCore.QPersistentModelIndex(self.indexFromItem(parent, 0)),
                "target": QtCore.QPersistentModelIndex(self.indexFromItem(target, 0)),
                "position": position, "request": request,
            }
            if position == QtWidgets.QAbstractItemView.OnItem and parent.childCount() and not parent.isExpanded():
                hover = self._drop_feedback["parent"]
        if hover != self._hover_parent:
            self._hover_timer.stop()
            self._hover_parent = hover
            if hover.isValid():
                self._hover_timer.start()
        self.viewport().update()

    def _expand_hover_parent(self):
        feedback = self._drop_feedback
        if (feedback is not None and self._hover_parent.isValid()
                and feedback["parent"] == self._hover_parent
                and feedback["position"] == QtWidgets.QAbstractItemView.OnItem):
            parent = self.itemFromIndex(QtCore.QModelIndex(self._hover_parent))
            parent.setExpanded(True)
            self._refresh_drop_feedback()

    def _clear_drop_feedback(self):
        was_dragging = self._drag_details is not None or self._saved_drop_indicator is not None
        self._hover_timer.stop()
        self._hover_parent = QtCore.QPersistentModelIndex()
        self._drop_feedback = None
        self._drag_details = None
        self._drag_point = None
        if self._saved_drop_indicator is not None:
            self.setDropIndicatorShown(self._saved_drop_indicator)
            self._saved_drop_indicator = None
        if was_dragging:
            self.setState(QtWidgets.QAbstractItemView.NoState)
        self.viewport().update()

    def dragLeaveEvent(self, event):
        self._clear_drop_feedback()
        super().dragLeaveEvent(event)

    def scrollContentsBy(self, dx, dy):
        super().scrollContentsBy(dx, dy)
        self._refresh_drop_feedback()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._refresh_drop_feedback()

    @staticmethod
    def _last_visible_descendant(item):
        while item.isExpanded():
            child = next((item.child(row) for row in range(item.childCount() - 1, -1, -1)
                          if not item.child(row).isHidden()), None)
            if child is None:
                break
            item = child
        return item

    def _parent_highlight_rect(self, parent):
        first = self.visualItemRect(parent)
        last = self.visualItemRect(self._last_visible_descendant(parent))
        branch = self._branch_rect(parent)
        if self.layoutDirection() == QtCore.Qt.RightToLeft:
            rect = QtCore.QRect(0, first.top(), branch.right() + 1, last.bottom() - first.top() + 1)
        else:
            rect = QtCore.QRect(branch.left(), first.top(), self.viewport().width() - branch.left(),
                                last.bottom() - first.top() + 1)
        return rect.intersected(self.viewport().rect())

    def _insertion_line(self, target, position):
        rect = self.visualRect(self.indexFromItem(target, 0))
        y = rect.top() if position == QtWidgets.QAbstractItemView.AboveItem else self.visualItemRect(
            self._last_visible_descendant(target)).bottom() + 1
        y = max(2, min(self.viewport().height() - 3, y))
        if self.layoutDirection() == QtCore.Qt.RightToLeft:
            start = max(8, min(self.viewport().width() - 3, rect.right()))
            return QtCore.QLine(start, y, 3, y)
        start = max(3, min(self.viewport().width() - 9, rect.left()))
        return QtCore.QLine(start, y, self.viewport().width() - 4, y)

    def paintEvent(self, event):
        super().paintEvent(event)
        feedback = self._drop_feedback
        if feedback is None or not feedback["parent"].isValid() or not feedback["target"].isValid():
            return
        parent = self.itemFromIndex(QtCore.QModelIndex(feedback["parent"]))
        target = self.itemFromIndex(QtCore.QModelIndex(feedback["target"]))
        painter = QtGui.QPainter(self.viewport())
        painter.fillRect(self._parent_highlight_rect(parent), QtGui.QColor(180, 180, 180, 48))
        if feedback["position"] != QtWidgets.QAbstractItemView.OnItem:
            line = self._insertion_line(target, feedback["position"])
            color = QtGui.QColor("#8cc8ff" if self.palette().base().color().lightness() < 128 else "#235c96")
            painter.setPen(QtGui.QPen(self.palette().base().color(), 5))
            painter.drawLine(line)
            painter.setPen(QtGui.QPen(color, 3))
            painter.drawLine(line)
            direction = -1 if self.layoutDirection() == QtCore.Qt.RightToLeft else 1
            x, y = line.x1(), line.y1()
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(color)
            painter.drawPolygon(QtGui.QPolygon([
                QtCore.QPoint(x, y - 5), QtCore.QPoint(x + direction * 7, y), QtCore.QPoint(x, y + 5),
            ]))
        painter.end()

    def dropEvent(self, event):
        details = self._definition_drag_details(event)
        if details is not None:
            kind, uid, allowed, move = details
            target, position = self._drop_location(event.pos())
            request = self._request_at(kind, uid, allowed, target, position)
            self._clear_drop_feedback()
            if request is not None and move and move(*request):
                event.setDropAction(QtCore.Qt.MoveAction)
                event.accept()
            else:
                event.ignore()
            return
        self._clear_drop_feedback()
        item = self.currentItem()
        old_parent = item.parent() if item else None
        old_uids = _child_uids(old_parent)
        super().dropEvent(event)
        new_parent = item.parent() if item else None
        if old_parent is not new_parent:
            self.orderDropped.emit(None)
            return
        new_uids = _child_uids(new_parent)
        if old_uids != new_uids:
            self.orderDropped.emit(new_uids)


COLLECTION_TREE_KINDS = {"Field", "Message", "Group", "Enum", "Structure", "Runtime", "Constant", "Method"}


class MessageDesignerWindow(QtWidgets.QMainWindow):
    """Visual editor and generator for Construct-backed message packages."""

    def __init__(self, parent=None, session_path: Path | str | None = None, *, behavior_opener=None):
        super().__init__(parent)
        self.setWindowFlag(QtCore.Qt.Window, True)
        self._behavior_opener = behavior_opener
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        self.setWindowTitle("Message Designer")
        self.resize(1380, 860)
        self._initial_layout_refreshed = False
        self.session_path = Path(session_path) if session_path is not None else default_session_path()
        recovered = load_session(self.session_path)
        self.document = MessageDesignerDocument(recovered["manifest"] if recovered else None)
        if recovered:
            self.document.saved_snapshot = normalize_manifest(recovered["saved_snapshot"])
        self.undo_stack = QtWidgets.QUndoStack(self)
        self.loaded: LoadedLibrary | None = None
        self.package_parent: Path | None = None
        if recovered and recovered.get("package_dir"):
            try:
                self.loaded = load_library(recovered["package_dir"])
                self.package_parent = self.loaded.package_dir.parent
            except LibraryPersistenceError:
                self.loaded = None
        self._selected_uid = (recovered or {}).get("selected_uid") or self.document.data["library"]["uid"]
        self._restored_expanded_keys = set((recovered or {}).get("expanded_tree_keys", [])) if recovered else None
        self._building_tree = False
        self._object_clipboard = None
        self._clipboard_token = new_id()
        self._cut_uids = set()
        self._pending_selection_uids = None
        self._tree_initialized = False
        self._tree_items: list[QtWidgets.QTreeWidgetItem] = []
        self._item_by_uid: dict[str, QtWidgets.QTreeWidgetItem] = {}
        self._category_items: dict[str, QtWidgets.QTreeWidgetItem] = {}
        self._filter_expansion_snapshot: set[str] | None = None
        self._filter_matches: list[QtWidgets.QTreeWidgetItem] = []
        self._problem_uids: set[str] = set()
        self._loading_properties = False
        self._properties_pending = False
        self._property_uid = ""
        self._property_kind = ""
        self._property_base = {}
        self._property_drafts = copy.deepcopy((recovered or {}).get("property_drafts", {}))
        self._auto_applying = False
        self._flushing_edits = False
        self._edit_epoch = 0
        self._edit_control = None
        self._edit_time = 0
        self._auto_merge_key = None
        self.auto_apply_timer = QtCore.QTimer(self)
        self.auto_apply_timer.setSingleShot(True); self.auto_apply_timer.setInterval(400)
        self.auto_apply_timer.timeout.connect(self._flush_auto_edits)
        self._focus_commit_timer = QtCore.QTimer(self)
        self._focus_commit_timer.setSingleShot(True)
        self._focus_commit_timer.timeout.connect(self._flush_before_navigation)
        self._draft_recovery_timer = QtCore.QTimer(self)
        self._draft_recovery_timer.setSingleShot(True); self._draft_recovery_timer.setInterval(150)
        self._draft_recovery_timer.timeout.connect(self._store_session)
        self._compiled_preview_router = None
        self._workspace_activity = {}
        self._activity_workspace = "Definitions"
        self._restoring_activity = False
        self._sandbox_running = False
        self._updating_result_inputs = False
        self._definition_revision = 0
        self._build_actions()
        self._build_ui()
        self._default_behavior_watcher = QtCore.QFileSystemWatcher(self)
        self._default_behavior_watcher.fileChanged.connect(self._default_behavior_changed)
        self._default_behavior_watcher.directoryChanged.connect(self._default_behavior_changed)
        self.routing_studio._drafts = copy.deepcopy((recovered or {}).get("routing_drafts", {}))
        self.routing_studio._selected_uid = (recovered or {}).get("routing_selected_uid", "")
        self.routing_studio.restore_view_state((recovered or {}).get("routing_view_state", {}))
        self.routing_studio.commit_edits = self._apply_now
        for signal in (self.preview_hex.textChanged, self.preview_group_scope.currentIndexChanged,
                       self.preview_direction.currentIndexChanged, self.preview_message.currentIndexChanged):
            signal.connect(self._invalidate_sandbox_result)
        self.preview_values.textChanged.connect(self._sandbox_values_changed)
        self.results_panel.openRoutingRequested.connect(self._open_result_routing)
        self.results_panel.openDefinitionRequested.connect(self._open_result_definition)
        state = (recovered or {}).get('results_view_state', {})
        self.results_panel.restore_view_state(state)
        self.routing_studio.editRequested.connect(lambda source: self._schedule_auto_apply("routing", source))
        self.routing_studio.flushRequested.connect(self._flush_before_navigation)
        self.routing_studio.tree.before_drag = self._flush_before_navigation
        self.routing_studio.draftsChanged.connect(lambda: self._draft_recovery_timer.start())
        self.routing_studio.viewStateChanged.connect(lambda: self._draft_recovery_timer.start())
        self.results_panel.viewStateChanged.connect(lambda: self._draft_recovery_timer.start())
        self._edit_focus_events = EditorFocusEvents(self)
        self._edit_events_active = True
        self._watch_editor_inputs()
        self.routing_studio.editorsRebuilt.connect(self._watch_editor_inputs)
        self.document.on_change(self._document_changed)
        self._refresh_all()
        self._update_routing_notice()
        if recovered and (self.document.is_dirty or self._property_drafts or self.routing_studio._drafts):
            self.statusBar().showMessage("Recovered unsaved changes from the previous Message Designer session.", 12000)

    def _build_actions(self):
        self.new_action = QtWidgets.QAction("New", self)
        self.open_action = QtWidgets.QAction("Open…", self)
        self.save_action = QtWidgets.QAction("Save", self)
        self.save_as_action = QtWidgets.QAction("Save As…", self)
        self.open_code_action = QtWidgets.QAction("Open behaviors.py", self)
        self.cleanup_code_action = QtWidgets.QAction("Clean Empty Orphans", self)
        self.collapse_all_action = QtWidgets.QAction("Collapse All", self)
        self.focus_tree_search_action = QtWidgets.QAction("Find definition", self)
        self.focus_tree_search_action.setShortcut(QtGui.QKeySequence.Find)
        self.next_tree_match_action = QtWidgets.QAction("Next navigator match", self)
        self.next_tree_match_action.setShortcut(QtGui.QKeySequence("F3"))
        self.previous_tree_match_action = QtWidgets.QAction("Previous navigator match", self)
        self.previous_tree_match_action.setShortcut(QtGui.QKeySequence("Shift+F3"))
        self.clear_tree_filters_action = QtWidgets.QAction("Cancel cut or clear navigator filters", self)
        self.clear_tree_filters_action.setShortcut(QtGui.QKeySequence("Escape"))
        self.addActions([
            self.focus_tree_search_action, self.next_tree_match_action,
            self.previous_tree_match_action, self.clear_tree_filters_action,
        ])
        self.new_action.setShortcut(QtGui.QKeySequence.New)
        self.open_action.setShortcut(QtGui.QKeySequence.Open)
        self.save_action.setShortcut(QtGui.QKeySequence.Save)
        self.new_action.triggered.connect(self.new_library)
        self.open_action.triggered.connect(self.open_library)
        self.save_action.triggered.connect(self.save_library)
        self.save_as_action.triggered.connect(lambda: self.save_library(save_as=True))
        self.open_code_action.triggered.connect(self.open_behavior_code)
        self.cleanup_code_action.triggered.connect(self.cleanup_empty_orphans)
        self.collapse_all_action.triggered.connect(self._collapse_all_tree)
        self.focus_tree_search_action.triggered.connect(self._focus_tree_search)
        self.next_tree_match_action.triggered.connect(lambda: self._navigate_tree_match(1))
        self.previous_tree_match_action.triggered.connect(lambda: self._navigate_tree_match(-1))
        self.clear_tree_filters_action.triggered.connect(self._handle_escape)

    def _build_ui(self):
        file_menu = self.menuBar().addMenu("&File")
        file_menu.addActions([self.new_action, self.open_action, self.save_action, self.save_as_action])
        file_menu.addSeparator()
        file_menu.addAction("Close", self.close)
        edit_menu = self.menuBar().addMenu("&Edit")
        self.undo_action = edit_menu.addAction("Undo", self._undo_edits, QtGui.QKeySequence.Undo)
        self.redo_action = edit_menu.addAction("Redo", self._redo_edits, QtGui.QKeySequence.Redo)
        self.undo_stack.canUndoChanged.connect(self.undo_action.setEnabled)
        self.undo_stack.canRedoChanged.connect(self.redo_action.setEnabled)
        self.undo_action.setEnabled(False); self.redo_action.setEnabled(False)
        code_menu = self.menuBar().addMenu("&Code")
        code_menu.addAction(self.open_code_action)
        code_menu.addAction(self.cleanup_code_action)

        toolbar = self.addToolBar("Message Designer")
        toolbar.setMovable(False)
        toolbar.addActions([self.new_action, self.open_action, self.save_action])
        toolbar.addSeparator()
        self.reorder_actions = []
        self._single_object_actions = []
        for label, callback in (
            ("+ Enum", self.add_enum), ("+ Struct", self.add_structure),
            ("+ Message", self.add_message), ("+ Field", self.add_field),
            ("+ Runtime", self.add_runtime), ("+ Constant", self.add_constant),
            ("+ Method", self.add_method), ("Duplicate", self.duplicate_selected),
            ("Delete", self.delete_selected), ("Up", lambda: self.move_selected(-1)),
            ("Down", lambda: self.move_selected(1)),
        ):
            action = toolbar.addAction(label)
            action.triggered.connect(callback)
            if label in {"Up", "Down"}:
                self.reorder_actions.append(action)
            if label == "Delete":
                self.delete_objects_action = action
            if label in {"Duplicate", "Up", "Down"}:
                self._single_object_actions.append(action)
        toolbar.addSeparator()
        toolbar.addAction(self.open_code_action)
        toolbar.addSeparator()
        toolbar.addAction(self.collapse_all_action)

        self.tabs = QtWidgets.QTabWidget()
        self.setStatusBar(DesignerStatusBar(self))
        self.status_contents = QtWidgets.QWidget()
        self.status_contents.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        status_layout = QtWidgets.QHBoxLayout(self.status_contents)
        status_layout.setContentsMargins(2, 0, 2, 0)
        status_layout.setSpacing(12)
        self.save_state_label = QtWidgets.QLabel()
        self.save_state_label.setObjectName("messageDesignerSaveState")
        self.save_state_label.setMinimumWidth(0)
        self.save_state_label.setToolTip("Library save and draft status")
        self.activity_state_label = QtWidgets.QLabel("Ready to edit")
        self.activity_state_label.setFont(self.statusBar().font())
        self.activity_state_label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.activity_state_label.setToolTip("The editor is ready for input. Save and draft status is shown separately.")
        status_layout.addWidget(self.activity_state_label, 1)
        self.routing_notice = QtWidgets.QLabel('Routing: current configuration')
        self.routing_notice.setMaximumWidth(240)
        self.routing_notice.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        self.routing_notice.setAccessibleName('Routing result status')
        self.routing_notice_button = QtWidgets.QToolButton(); self.routing_notice_button.setText('Open Routing')
        self.routing_notice.hide()
        self.routing_notice_button.hide()
        self.routing_notice_button.clicked.connect(lambda: self._open_result_routing(''))
        status_layout.addWidget(self.routing_notice)
        status_layout.addWidget(self.routing_notice_button)
        status_layout.addWidget(self.save_state_label)
        self.statusBar().addPermanentWidget(self.status_contents, 1)
        self.statusBar().messageChanged.connect(self._show_activity_message)
        # Inactive tabs can have large, not-yet-laid-out size hints. They must
        # not force the top-level window beyond the available desktop.
        self.tabs.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Ignored)
        self.setCentralWidget(self.tabs)
        self.definitions_page = self._definitions_page()
        edit_menu.addSeparator()
        edit_menu.addActions([self.cut_objects_action, self.copy_objects_action, self.paste_objects_action])
        self.tabs.addTab(self.definitions_page, "Definitions")
        self.sandbox_page = self._sandbox_page()
        self.tabs.addTab(self.sandbox_page, "Sandbox")
        self.tabs.addTab(self._code_page(), "Generated Code")
        self.routing_studio = RoutingStudio()
        self.routing_studio.pendingChanged.connect(lambda _: self._refresh_all_title_only())
        self.routing_studio.pendingChanged.connect(lambda _: self._update_transfer_actions())
        self.routing_studio.validationChanged.connect(self._refresh_routing_validation)
        self.routing_studio.issues.itemActivated.connect(self._activate_issue)
        self.routing_studio.issues.customContextMenuRequested.connect(
            lambda position: self._show_issue_context_menu(position, self.routing_studio.issues)
        )
        self.routing_studio.reparentRequested.connect(self._reparent_routing_item)
        self.routing_studio.addGroupRequested.connect(self._add_routing_group)
        self.routing_studio.addMessageRequested.connect(self._add_routing_message)
        self.routing_studio.defaultsTransferRequested.connect(self._transfer_routing_defaults)
        self.routing_studio.openDefinitionRequested.connect(self._open_routing_definition)
        self.tabs.insertTab(1, self.routing_studio, "Routing")
        self.tabs.currentChanged.connect(self._workspace_changed)

    def _definitions_page(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setSizeConstraint(QtWidgets.QLayout.SetNoConstraint)
        self.definitions_heading = QtWidgets.QLabel("Message library definitions")
        self.definitions_heading.setStyleSheet("font-size: 16px; font-weight: 600;")
        layout.addWidget(self.definitions_heading)
        splitter = QtWidgets.QSplitter()
        self.definition_splitter = splitter
        splitter.setChildrenCollapsible(False)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, 1)

        navigator = QtWidgets.QFrame()
        navigator.setFrameStyle(QtWidgets.QFrame.StyledPanel | QtWidgets.QFrame.Sunken)
        navigator.setAutoFillBackground(True)
        navigator.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        navigator_layout = QtWidgets.QVBoxLayout(navigator)
        navigator_layout.setSpacing(5)
        search_row = QtWidgets.QHBoxLayout()
        self.tree_search = QtWidgets.QLineEdit()
        self.tree_search.setPlaceholderText("Search names, types, sizes, or directions…")
        self.tree_search.setClearButtonEnabled(True)
        self.tree_scope = QtWidgets.QComboBox()
        self.tree_scope.addItems(["All", "Definitions", "Fields", "Class members", "Problems"])
        search_row.addWidget(self.tree_search, 1); search_row.addWidget(self.tree_scope)
        navigator_layout.addLayout(search_row)
        filter_row = QtWidgets.QHBoxLayout()
        self.tree_clear_filters = QtWidgets.QToolButton(); self.tree_clear_filters.setText("Clear filters")
        self.tree_expand_matches = QtWidgets.QToolButton(); self.tree_expand_matches.setText("Expand matches")
        self.tree_collapse_all = QtWidgets.QToolButton(); self.tree_collapse_all.setText("Collapse all")
        filter_row.addWidget(self.tree_clear_filters); filter_row.addStretch()
        filter_row.addWidget(self.tree_expand_matches); filter_row.addWidget(self.tree_collapse_all)
        navigator_layout.addLayout(filter_row)
        self.tree_result_label = QtWidgets.QLabel("All definitions")
        self.tree_result_label.setStyleSheet("color: palette(mid);")
        navigator_layout.addWidget(self.tree_result_label)

        self.tree = DefinitionTree()
        self.tree.batch_move_allowed = self._can_move_tree_batch
        self.tree.move_batch = self._move_tree_batch
        self.tree.field_move_allowed = self._can_move_tree_field
        self.tree.move_field = self._move_tree_field
        self.tree.message_move_allowed = self._can_move_tree_message
        self.tree.move_message = self._move_tree_message
        self.tree.group_move_allowed = self._can_move_tree_group
        self.tree.move_group = self._move_tree_group
        self.tree.before_drag = self._flush_before_navigation
        self.tree.setHeaderLabels(["Library definition", "Type", "Size", "Direction"])
        self.tree.setSortingEnabled(False)
        self.tree.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        self.tree.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setMinimumSectionSize(44)
        for column in range(self.tree.columnCount()):
            self.tree.header().setSectionResizeMode(column, QtWidgets.QHeaderView.Interactive)
        self.tree.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.tree.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollPerPixel)
        self.tree.setTextElideMode(QtCore.Qt.ElideNone)
        self.tree.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.tree.currentItemChanged.connect(self._selection_changed)
        self.tree.orderDropped.connect(self._tree_order_dropped)
        self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_tree_context_menu)
        self.tree.itemSelectionChanged.connect(self._update_transfer_actions)
        self.cut_objects_action = QtWidgets.QAction("Cut", self.tree)
        self.copy_objects_action = QtWidgets.QAction("Copy", self.tree)
        self.paste_objects_action = QtWidgets.QAction("Paste", self.tree)
        self.delete_objects_action.setShortcut(QtGui.QKeySequence(QtCore.Qt.Key_Delete))
        self.delete_objects_action.setShortcutContext(QtCore.Qt.WidgetShortcut)
        self.delete_objects_action.setToolTip("Delete selected definitions (Delete); undo with Ctrl+Z")
        self.tree.addAction(self.delete_objects_action)
        for action, shortcut, callback in (
            (self.cut_objects_action, QtGui.QKeySequence.Cut, self.cut_objects),
            (self.copy_objects_action, QtGui.QKeySequence.Copy, self.copy_objects),
            (self.paste_objects_action, QtGui.QKeySequence.Paste, self.paste_objects),
        ):
            action.setShortcut(shortcut)
            action.setShortcutContext(QtCore.Qt.WidgetShortcut)
            action.triggered.connect(callback)
            self.tree.addAction(action)
        QtWidgets.QApplication.clipboard().dataChanged.connect(self._update_transfer_actions)
        self.tree.itemExpanded.connect(self._tree_expansion_changed)
        self.tree.itemCollapsed.connect(self._tree_expansion_changed)
        navigator_layout.addWidget(self.tree, 1)
        splitter.addWidget(navigator)
        self.tree_filter_timer = QtCore.QTimer(self); self.tree_filter_timer.setSingleShot(True)
        self.tree_filter_timer.setInterval(150); self.tree_filter_timer.timeout.connect(self._apply_tree_filter)
        self.tree_search.textChanged.connect(lambda: self.tree_filter_timer.start())
        self.tree_scope.currentTextChanged.connect(self._apply_tree_filter)
        self.tree_clear_filters.clicked.connect(self._clear_tree_filters)
        self.tree_expand_matches.clicked.connect(self._expand_tree_matches)
        self.tree_collapse_all.clicked.connect(self._collapse_all_tree)
        self.tree_session_timer = QtCore.QTimer(self); self.tree_session_timer.setSingleShot(True)
        self.tree_session_timer.setInterval(200); self.tree_session_timer.timeout.connect(self._store_session)

        editor = self.definition_editor = QtWidgets.QFrame()
        editor.setFrameStyle(QtWidgets.QFrame.StyledPanel | QtWidgets.QFrame.Sunken)
        editor.setAutoFillBackground(True)
        editor.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        editor_layout = QtWidgets.QVBoxLayout(editor)
        self.editor_title = QtWidgets.QLabel("Selection")
        self.editor_title.setStyleSheet("font-size: 17px; font-weight: 600;")
        editor_layout.addWidget(self.editor_title)
        self.category_info = QtWidgets.QFrame()
        self.category_info.setFrameShape(QtWidgets.QFrame.StyledPanel)
        category_info_layout = QtWidgets.QVBoxLayout(self.category_info)
        self.category_info_title = QtWidgets.QLabel()
        self.category_info_title.setStyleSheet("font-size: 16px; font-weight: 600;")
        self.category_info_text = QtWidgets.QLabel()
        self.category_info_text.setWordWrap(True)
        self.category_info_text.setStyleSheet("color: #52627a; line-height: 1.35;")
        category_info_layout.addWidget(self.category_info_title)
        category_info_layout.addWidget(self.category_info_text)
        category_info_layout.addStretch()
        self.category_info.setVisible(False)
        editor_layout.addWidget(self.category_info, 1)
        self.common_properties_widget = QtWidgets.QWidget()
        form = QtWidgets.QFormLayout(self.common_properties_widget)
        self.name_edit = QtWidgets.QLineEdit()
        self.name_edit.textChanged.connect(self._properties_edited)
        self.kind_combo = QtWidgets.QComboBox()
        self.kind_combo.addItems(sorted(FIELD_KINDS))
        self.kind_combo.currentTextChanged.connect(self._field_kind_changed)
        form.addRow("Name", self.name_edit)
        form.addRow("Field type", self.kind_combo)
        self.kind_label = form.labelForField(self.kind_combo)
        editor_layout.addWidget(self.common_properties_widget)
        self.field_options_group = QtWidgets.QGroupBox("Field settings")
        field_options_layout = QtWidgets.QVBoxLayout(self.field_options_group)
        self.field_options = FieldOptionsEditor()
        self.field_options.changed.connect(self._properties_edited)
        self.field_scroll = QtWidgets.QScrollArea()
        self.field_scroll.setWidgetResizable(True)
        self.field_scroll.setMinimumHeight(120)
        self.field_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.field_scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.field_scroll.setWidget(self.field_options)
        field_options_layout.addWidget(self.field_scroll)
        editor_layout.addWidget(self.field_options_group, 1)
        self.definition_options_group = QtWidgets.QGroupBox("Definition settings")
        definition_options_layout = QtWidgets.QVBoxLayout(self.definition_options_group)
        self.definition_options = DefinitionOptionsEditor()
        self.definition_options.changed.connect(self._properties_edited)
        definition_scroll = QtWidgets.QScrollArea()
        definition_scroll.setWidgetResizable(True)
        definition_scroll.setMinimumHeight(120)
        definition_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        definition_scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        definition_scroll.setWidget(self.definition_options)
        definition_options_layout.addWidget(definition_scroll)
        editor_layout.addWidget(self.definition_options_group, 1)
        self.json_label = QtWidgets.QLabel("Definition properties (JSON)")
        editor_layout.addWidget(self.json_label)
        self.details_edit = QtWidgets.QPlainTextEdit()
        self.details_edit.setTabStopDistance(24)
        self.details_edit.textChanged.connect(self._properties_edited)
        editor_layout.addWidget(self.details_edit, 1)
        self.reference_label = QtWidgets.QLabel()
        self.reference_label.setWordWrap(True)
        self.reference_label.setStyleSheet("color: #52627a;")
        editor_layout.addWidget(self.reference_label)
        self.dependencies = QtWidgets.QTreeWidget()
        self.dependencies.setHeaderLabels(["Dependency", "Target"])
        self.dependencies.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.dependencies.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.dependencies.setMaximumHeight(130)
        self.dependencies.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.dependencies.customContextMenuRequested.connect(self._show_dependency_context_menu)
        editor_layout.addWidget(self.dependencies)
        self.property_actions_widget = QtWidgets.QWidget()
        property_actions_layout = QtWidgets.QHBoxLayout(self.property_actions_widget)
        property_actions_layout.setContentsMargins(0, 0, 0, 0)
        self.property_state_label = QtWidgets.QLabel("All property changes are applied.")
        self.property_state_label.setWordWrap(True)
        property_actions_layout.addWidget(self.property_state_label, 1)
        self.open_routing_button = QtWidgets.QPushButton("Open in Routing")
        self.open_routing_button.clicked.connect(self._open_selected_routing)
        self.open_routing_button.setVisible(False)
        property_actions_layout.addWidget(self.open_routing_button)
        self.revert_properties_button = QtWidgets.QPushButton("Revert draft")
        self.revert_properties_button.clicked.connect(self._revert_property_draft)
        property_actions_layout.addWidget(self.revert_properties_button)
        self.apply_button = QtWidgets.QPushButton("Apply now")
        self.apply_button.clicked.connect(self.apply_properties)
        property_actions_layout.addWidget(self.apply_button)
        editor_layout.addWidget(self.property_actions_widget)
        self.definition_editor_scroll = QtWidgets.QScrollArea()
        self.definition_editor_scroll.setWidgetResizable(True)
        self.definition_editor_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.definition_editor_scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.definition_editor_scroll.setWidget(editor)
        splitter.addWidget(self.definition_editor_scroll)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        self.issues = QtWidgets.QTreeWidget()
        self.issues.setHeaderLabels(["Severity", "Validation issue", "Suggested action"])
        self.issues.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.issues.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.itemActivated.connect(self._activate_issue)
        self.issues.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.issues.customContextMenuRequested.connect(self._show_issue_context_menu)
        self.issues.setFixedHeight(BOTTOM_PANEL_HEIGHT)
        layout.addWidget(self.issues)
        return page

    def showEvent(self, event):
        super().showEvent(event)
        if not self._initial_layout_refreshed:
            self._initial_layout_refreshed = True
            self._fit_initial_window_to_screen()
            QtCore.QTimer.singleShot(0, self._finish_initial_layout)

    def _available_screen_geometry(self):
        parent = self.parentWidget()
        screen = parent.screen() if parent is not None else self.screen()
        return screen.availableGeometry() if screen is not None else QtCore.QRect()

    def _fit_initial_window_to_screen(self):
        if self.isMaximized() or self.isFullScreen(): return
        available = self._available_screen_geometry()
        if not available.isValid(): return
        available = available.adjusted(12, 12, -12, -12)
        frame = self.frameGeometry()
        border_width = max(0, frame.width() - self.width())
        border_height = max(0, frame.height() - self.height())
        self.resize(min(self.width(), max(1, available.width() - border_width)),
                    min(self.height(), max(1, available.height() - border_height)))
        frame = self.frameGeometry()
        left = max(available.left(), min(frame.left(), available.right() - frame.width() + 1))
        top = max(available.top(), min(frame.top(), available.bottom() - frame.height() + 1))
        self.move(left, top)

    def _finish_initial_layout(self):
        self._refresh_initial_layout()
        self._fit_initial_window_to_screen()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._initial_layout_refreshed:
            QtCore.QTimer.singleShot(0, self._refresh_initial_layout)

    def _refresh_initial_layout(self):
        total_width = self.definition_splitter.width()
        if total_width > 0:
            scrollbar_width = self.tree.style().pixelMetric(
                QtWidgets.QStyle.PM_ScrollBarExtent, None, self.tree
            )
            tree_width = (
                self.tree.header().length()
                + self.tree.frameWidth() * 2
                + scrollbar_width
                + 8
            )
            navigator = self.definition_splitter.widget(0)
            margins = navigator.layout().contentsMargins()
            tree_width += margins.left() + margins.right() + navigator.frameWidth() * 2
            desired_navigator_width = max(380, tree_width)
            editor_minimum_width = 305
            available_navigator_width = max(260, total_width - editor_minimum_width)
            if not hasattr(self, "_preferred_navigator_width"):
                self._preferred_navigator_width = min(desired_navigator_width, available_navigator_width)
            navigator_width = min(self._preferred_navigator_width, available_navigator_width)
            self.definition_splitter.setSizes(
                [navigator_width, max(1, total_width - navigator_width)]
            )
        current_page = self.tabs.currentWidget()
        if current_page is not None and current_page.layout() is not None:
            current_page.layout().invalidate()
            current_page.layout().activate()
        self.field_options._refresh_geometry()
        self.field_scroll.updateGeometry()
        self.field_scroll.viewport().updateGeometry()

    def _sandbox_page(self):
        page = QtWidgets.QWidget()
        page.setObjectName("messageDesignerSandbox")
        layout = QtWidgets.QVBoxLayout(page)
        reference_layout = self.definitions_page.layout()
        layout.setSizeConstraint(reference_layout.sizeConstraint())
        layout.setContentsMargins(reference_layout.contentsMargins())
        layout.setSpacing(reference_layout.spacing())
        reference_panel_layout = self.definition_editor.layout()
        panel_margins = reference_panel_layout.contentsMargins()
        panel_spacing = reference_panel_layout.spacing()

        heading = QtWidgets.QLabel("Build, inspect, and verify a message")
        heading.setStyleSheet(self.definitions_heading.styleSheet())
        content = QtWidgets.QWidget()
        content_layout = QtWidgets.QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(layout.spacing())
        content_layout.addWidget(heading)
        controls = QtWidgets.QFrame()
        controls.setObjectName("sandboxControls")
        controls.setAccessibleName("Message class and scope")
        controls.setFrameShape(QtWidgets.QFrame.StyledPanel)
        controls_layout = QtWidgets.QGridLayout(controls)
        controls_layout.setContentsMargins(panel_margins)
        controls_layout.setSpacing(panel_spacing)
        controls_layout.setColumnStretch(0, 1)
        message_label = QtWidgets.QLabel("Message class and scope")
        message_label.setStyleSheet(self.tree_result_label.styleSheet())
        self.preview_message = QtWidgets.QComboBox()
        self.preview_message.setMinimumWidth(250)
        self.preview_message.setMinimumHeight(34)
        self.preview_message.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
        self.preview_message.setToolTip("Generated message class used for this sandbox operation")
        controls_layout.addWidget(message_label, 0, 0, 1, 3)
        controls_layout.addWidget(self.preview_message, 1, 0)
        self.preview_build_button = QtWidgets.QToolButton()
        self.preview_build_button.setText("Encode")
        self.preview_build_button.setObjectName("sandboxPrimaryAction")
        self.preview_build_button.setToolTip("Encode\nConvert Message initialization on the left into Wire bytes on the right.")
        self.preview_parse_button = QtWidgets.QToolButton()
        self.preview_parse_button.setText("Decode")
        self.preview_parse_button.setToolTip("Decode\nRead Wire bytes on the right and populate Message initialization on the left.")
        self.preview_round_trip_button = QtWidgets.QToolButton()
        self.preview_round_trip_button.setText("Verify round trip")
        self.preview_round_trip_button.setToolTip("Verify round trip\nDecode the wire bytes, encode the decoded message again, and compare the result byte for byte.")
        self.preview_auto_button = QtWidgets.QPushButton("Decode auto")
        self.preview_auto_button.setToolTip("Decode wire bytes using the routing rules. The matching message class is selected automatically.")
        self.preview_action_buttons = (
            self.preview_build_button, self.preview_parse_button, self.preview_round_trip_button,
            self.preview_auto_button,
        )
        for button, action in zip(self.preview_action_buttons[:3], ("build", "parse", "round_trip")):
            button.setIcon(_sandbox_action_icon(action, self.palette()))
            button.setIconSize(QtCore.QSize(24, 24))
            button.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)
            button.setFixedSize(44, 44)
            button.setAccessibleName(button.text())
            button.setAccessibleDescription(button.toolTip().split('\n', 1)[1])
            button.setCursor(QtCore.Qt.PointingHandCursor)
            button.clicked.connect(lambda checked=False, selected=action: self.run_sandbox(selected))
        content_layout.addWidget(controls)
        self.preview_auto_button.setMinimumHeight(34)
        self.preview_auto_button.clicked.connect(lambda checked=False: self.run_sandbox("auto_parse"))
        self.preview_default_button = QtWidgets.QPushButton('Check default message')
        self.preview_default_button.setMinimumHeight(34)
        self.preview_default_button.setToolTip('Instantiate the actual generated constructor, encode, decode completely, and re-encode')
        self.preview_default_button.clicked.connect(lambda checked=False: self.run_sandbox('check_default'))
        controls_layout.addWidget(self.preview_default_button, 1, 1, 1, 2)
        self.preview_group_scope = QtWidgets.QComboBox()
        self.preview_group_scope.setToolTip("Routing scope used to identify the message class when using Decode auto.")
        self.preview_direction = QtWidgets.QComboBox()
        self.preview_direction.addItem('ANY', 'ANY')
        self.preview_direction.addItem('TX', 'TX'); self.preview_direction.addItem('RX', 'RX')
        for combo in (self.preview_group_scope, self.preview_direction):
            combo.setMinimumHeight(34)
            combo.setMinimumContentsLength(8)
            combo.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.preview_group_scope.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.preview_direction.setSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Preferred)
        self.preview_direction.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToContents)
        controls_layout.addWidget(self.preview_group_scope, 2, 0)
        controls_layout.addWidget(self.preview_direction, 2, 1)
        controls_layout.addWidget(self.preview_auto_button, 2, 2)

        editors = QtWidgets.QWidget()
        self.preview_editors = editors
        editors_layout = QtWidgets.QGridLayout(editors)
        editors_layout.setContentsMargins(0, 0, 0, 0)
        editors_layout.setHorizontalSpacing(self.definition_splitter.handleWidth())
        editors_layout.setColumnStretch(0, 1)
        editors_layout.setColumnStretch(2, 1)
        values_group = QtWidgets.QFrame()
        values_group.setObjectName("sandboxValuesPanel")
        values_group.setAccessibleName("Message initialization")
        values_group.setFrameShape(QtWidgets.QFrame.StyledPanel)
        values_group.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        values_layout = QtWidgets.QVBoxLayout(values_group)
        values_layout.setContentsMargins(panel_margins)
        values_layout.setSpacing(panel_spacing)
        values_label = QtWidgets.QLabel("Message initialization")
        values_label.setStyleSheet(self.tree_result_label.styleSheet())
        values_layout.addWidget(values_label)
        self.preview_values_hint = QtWidgets.QLabel()
        self.preview_values_hint.setWordWrap(True)
        self.preview_values_hint.setStyleSheet("color: palette(mid);")
        self.preview_values_hint.setText(
            "Starter example for Encode, independent of constructor defaults. Check default message verifies the real constructor. "
            "Edit Python-style named attributes, structures, enums, bytes, and arrays."
        )
        values_layout.addWidget(self.preview_values_hint)
        self._preview_rendered_message = ""
        self._preview_value_drafts = {}
        self._preview_sample_values = {}
        self.preview_values = QtWidgets.QPlainTextEdit()
        self.preview_values.setObjectName("sandboxValuesEditor")
        self.preview_values.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.preview_values.setTabStopDistance(24)
        self.preview_values.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.preview_values.setPlaceholderText("MessageName(\n    field_name=0,\n)")
        values_layout.addWidget(self.preview_values)
        values_footer = QtWidgets.QHBoxLayout()
        values_footer.addStretch()
        self.preview_format_object_button = QtWidgets.QPushButton("Format object")
        self.preview_format_object_button.clicked.connect(self._format_preview_object)
        values_footer.addWidget(self.preview_format_object_button)
        values_layout.addLayout(values_footer)
        editors_layout.addWidget(values_group, 0, 0)

        actions = QtWidgets.QWidget()
        actions.setObjectName("sandboxArrowActions")
        actions.setFixedWidth(64)
        actions_layout = QtWidgets.QVBoxLayout(actions)
        actions_layout.setContentsMargins(8, 0, 8, 0)
        actions_layout.setSpacing(8)
        actions_layout.addStretch()
        for button in self.preview_action_buttons[:3]:
            actions_layout.addWidget(button, 0, QtCore.Qt.AlignHCenter)
        actions_layout.addStretch()
        editors_layout.addWidget(actions, 0, 1)

        hex_group = QtWidgets.QFrame()
        hex_group.setObjectName("sandboxHexPanel")
        hex_group.setAccessibleName("Wire bytes")
        hex_group.setFrameShape(QtWidgets.QFrame.StyledPanel)
        hex_group.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        hex_layout = QtWidgets.QVBoxLayout(hex_group)
        hex_layout.setContentsMargins(panel_margins)
        hex_layout.setSpacing(panel_spacing)
        hex_label = QtWidgets.QLabel("Wire bytes")
        hex_label.setStyleSheet(self.tree_result_label.styleSheet())
        hex_layout.addWidget(hex_label)
        hex_hint = QtWidgets.QLabel(
            "Encode writes bytes here. Decode and Verify round trip read these bytes. Whitespace is ignored."
        )
        hex_hint.setWordWrap(True)
        hex_hint.setStyleSheet("color: palette(mid);")
        hex_layout.addWidget(hex_hint)
        self.preview_hex = QtWidgets.QPlainTextEdit()
        self.preview_hex.setObjectName("sandboxHexEditor")
        self.preview_hex.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.preview_hex.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.preview_hex.setPlaceholderText("00 01 ff …")
        self.preview_hex.textChanged.connect(self._update_preview_byte_count)
        hex_layout.addWidget(self.preview_hex)
        hex_footer = QtWidgets.QHBoxLayout()
        self.preview_byte_count = QtWidgets.QLabel("0 bytes")
        self.preview_byte_count.setStyleSheet("color: palette(mid);")
        hex_footer.addWidget(self.preview_byte_count)
        hex_footer.addStretch()
        self.preview_normalize_hex_button = QtWidgets.QPushButton("Normalize hex")
        self.preview_normalize_hex_button.clicked.connect(self._normalize_preview_hex)
        hex_footer.addWidget(self.preview_normalize_hex_button)
        hex_layout.addLayout(hex_footer)
        editors_layout.addWidget(hex_group, 0, 2)
        content_layout.addWidget(editors, 1)
        self.sandbox_content_scroll = QtWidgets.QScrollArea()
        self.sandbox_content_scroll.setWidgetResizable(True)
        self.sandbox_content_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.sandbox_content_scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.sandbox_content_scroll.setWidget(content)
        layout.addWidget(self.sandbox_content_scroll, 1)
        self.results_panel = ResultsPanel()
        self.preview_result = self.results_panel.fields
        layout.addWidget(self.results_panel)

        for panel in (controls, values_group, hex_group):
            panel.setBackgroundRole(QtGui.QPalette.Window)
            panel.setAutoFillBackground(True)

        self._set_preview_status("Select a message and choose an operation when you are ready.", "info")
        self.preview_message.currentTextChanged.connect(self._preview_message_changed)
        return page

    def _code_page(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        self.code_tabs = QtWidgets.QTabWidget()
        self.code_editors = {}
        for name in ("models.py", "registry.py", "behaviors.py", "__init__.py"):
            editor = QtWidgets.QPlainTextEdit()
            editor.setReadOnly(True)
            editor.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
            self.code_tabs.addTab(editor, name)
            self.code_editors[name] = editor
        layout.addWidget(self.code_tabs)
        return page

    def _document_changed(self, reason="changed"):
        self._definition_revision += 1
        self._invalidate_sandbox_result(force=True)
        if hasattr(self, 'activity_state_label'):
            self._set_preview_status('Default message unverified: definition changed. Run Check default message again.', 'info')
        if not self._auto_applying:
            self.auto_apply_timer.stop(); self._focus_commit_timer.stop()
            self._end_edit_group()
        if reason in {"new", "opened"}:
            self._discard_edit_drafts()
        uids = {value.get("uid") for value in self.document.all_objects()}
        self._property_drafts = {uid: value for uid, value in self._property_drafts.items() if uid in uids}
        self.routing_studio._drafts = {uid: value for uid, value in self.routing_studio._drafts.items() if uid in uids}
        self._compiled_preview_router = None
        self.routing_studio.clear_trace()
        self._store_session()
        self._refresh_all()

    def _refresh_all(self):
        routing_uid = self.routing_studio._selected_uid or self._selected_uid
        self._rebuild_tree(preserve_properties=self._auto_applying)
        self._refresh_validation()
        self._refresh_preview_messages()
        self._refresh_code()
        self.routing_studio.refresh(self.document.data, routing_uid, keep_drafts=True, preserve_editor=self._auto_applying)
        if self._auto_applying:
            if self._property_kind == "Field":
                self.field_options.refresh_manifest(self.document.data)
            self._refresh_property_references()
        self._refresh_all_title_only()

    def _workspace_changed(self, index):
        sandbox_active = self.tabs.widget(index) is self.sandbox_page
        self.routing_notice.setVisible(sandbox_active)
        self.routing_notice_button.setVisible(sandbox_active)
        if self.statusBar().currentMessage():
            self._show_activity_message(self.statusBar().currentMessage())
        self._flush_before_navigation()
        if self.tabs.widget(index) is self.routing_studio and not self.routing_studio.apply.isEnabled():
            self.routing_studio.refresh(self.document.data, self._selected_uid, keep_drafts=True)
        self._activity_workspace = self.tabs.tabText(index)
        self._restore_workspace_activity()

    def _add_routing_group(self, parent_uid=""):
        def operation(data):
            parent = next((item for item in data.get("groups", []) if item.get("uid") == parent_uid), None)
            group = new_group(_unique_name(data, "NewGroup"), parent_uid if parent else "")
            data.setdefault("groups", []).append(group)
            return group["uid"]
        self._mutate("Add routing group", operation)
        self.routing_studio._select_graph_uid(self._selected_uid)

    def _add_routing_message(self, group_uid=""):
        def operation(data):
            groups = data.get("groups", [])
            selected_group = group_uid if group_uid in {data['library']['uid'], *(group['uid'] for group in groups)} else data['library']['uid']
            message = new_message(_unique_name(data, "NewMessage"))
            message["group_uid"] = selected_group
            data.setdefault("messages", []).append(message)
            return message["uid"]
        self._mutate("Add routing message", operation)
        self.routing_studio._select_graph_uid(self._selected_uid)

    def _reparent_routing_item(self, uid, parent_uid, kind):
        if kind not in {"Group", "Message"}:
            self.routing_studio.refresh(self.document.data, uid)
            return
        groups = self.document.data.get("groups", [])
        if kind == "Group":
            current = next((item for item in groups if item.get("uid") == uid), None)
            parent = next((item for item in groups if item.get("uid") == parent_uid), None)
            seen = set()
            cursor = parent
            while cursor and cursor.get("uid") not in seen:
                if cursor.get("uid") == uid:
                    self.routing_studio.refresh(self.document.data, uid)
                    return
                seen.add(cursor.get("uid"))
                cursor = next(
                    (item for item in groups if item.get("uid") == cursor.get("parent_group_uid")),
                    None,
                )
            resolved_parent_uid = parent_uid if parent else ""
            if current is None or current.get("parent_group_uid", "") == resolved_parent_uid:
                self.routing_studio.refresh(self.document.data, uid)
                return
        else:
            current = next((item for item in self.document.data.get("messages", []) if item.get("uid") == uid), None)
            parent = next((item for item in groups if item.get("uid") == parent_uid), None)
            if current is None or (parent is None and parent_uid != self.document.data["library"]["uid"]) or current.get("group_uid", "") == parent_uid:
                self.routing_studio.refresh(self.document.data, uid)
                return

        def operation(data):
            groups = data.get("groups", [])
            if kind == "Group":
                group = next((item for item in groups if item.get("uid") == uid), None)
                if group is None or parent_uid == uid:
                    return uid
                descendants = set()
                pending = [uid]
                while pending:
                    current = pending.pop()
                    for child in groups:
                        if child.get("parent_group_uid") == current and child.get("uid") not in descendants:
                            descendants.add(child.get("uid")); pending.append(child.get("uid"))
                if parent_uid in descendants:
                    return uid
                parent = next((item for item in groups if item.get("uid") == parent_uid), None)
                group["parent_group_uid"] = parent_uid if parent else ""
                group["expected_values"] = None
                group.pop('expected_value_texts', None)
                return uid
            message = next((item for item in data.get("messages", []) if item.get("uid") == uid), None)
            parent = next((item for item in groups if item.get("uid") == parent_uid), None)
            if message is None or (parent is None and parent_uid != data["library"]["uid"]):
                return uid
            message["group_uid"] = parent_uid
            message["expected_values"] = None
            message.pop('expected_value_texts', None)
            return uid

        self._mutate("Move routing item", operation)

    def _open_routing_definition(self, uid):
        item = self._item_by_uid.get(uid)
        if item is None:
            return
        self.tabs.setCurrentWidget(self.definitions_page)
        self.tree.setCurrentItem(item)
        self.tree.scrollToItem(item)

    def _open_selected_routing(self):
        item = self.tree.currentItem()
        info = (item.data(0, QtCore.Qt.UserRole) or {}) if item is not None else {}
        if info.get("kind") not in {"Group", "Message"}:
            return
        uid = info.get("uid")
        self.tabs.setCurrentWidget(self.routing_studio)
        target = self.routing_studio._find_item(uid)
        if target is None:
            return
        if target.isHidden():
            self.routing_studio.search.clear()
        self.routing_studio.tree.setCurrentItem(target)
        if self.routing_studio.tree.currentItem() is not target:
            return
        parent = target.parent()
        while parent:
            parent.setExpanded(True); parent = parent.parent()
        self.routing_studio.tree.scrollToItem(target)

    def _rebuild_tree(self, *, preserve_properties=False):
        selected_uids = self._pending_selection_uids
        if selected_uids is None:
            selected_uids = self.tree.selected_uids()
        self._pending_selection_uids = None
        first_build = not self._tree_initialized
        if self._tree_initialized:
            expanded_keys = (
                set(self._filter_expansion_snapshot)
                if self._filters_active() and self._filter_expansion_snapshot is not None
                else self._expanded_tree_keys()
            )
        else:
            expanded_keys = self._restored_expanded_keys
        self._building_tree = True
        self.tree.clear()
        self._tree_items = []; self._item_by_uid = {}; self._category_items = {}
        self._wire_size_analyzer = WireSizeAnalyzer(self.document.data)
        root_data = self.document.data["library"]
        root = self._tree_item(root_data, "Library")
        self.tree.addTopLevelItem(root)
        categories = (
            ("Enums", self.document.data.get("enums", []), "Enum"),
            ("Structures", self.document.data.get("structures", []), "Structure"),
            ("Messages", self.document.data.get("groups", []), "Group"),
        )
        for title, values, kind in categories:
            category = QtWidgets.QTreeWidgetItem([f"{title} ({len(values)})", "", "", ""])
            category.setData(0, QtCore.Qt.UserRole, {"category": title.lower(), "base_title": title, "total": len(values)})
            self._tree_items.append(category); self._category_items[title.lower()] = category
            if kind == "Group":
                total_messages = len(self.document.data.get("messages", []))
                category.setText(0, f"Messages ({total_messages})")
                category.setData(0, QtCore.Qt.UserRole, {
                    "category": "messages", "base_title": "Messages", "total": total_messages,
                })
            root.addChild(category)
            visible_values = (
                [value for value in values if (value.get("parent_group_uid") or root_data["uid"]) == root_data["uid"]]
                if kind == "Group" else values
            )
            for value in visible_values:
                if kind == "Group":
                    self._append_group_tree_item(category, value)
                    continue
                item = self._tree_item(value, kind)
                category.addChild(item)
                if kind in {"Structure", "Message"}:
                    self._append_field_items(item, value.get("fields", []), value["uid"])
                if kind == "Message":
                    for key, label in (("runtime_attributes", "Runtime"), ("constants", "Constant"), ("methods", "Method")):
                        if not value.get(key):
                            continue
                        group = QtWidgets.QTreeWidgetItem([label + "s", "", "", ""])
                        group.setData(0, QtCore.Qt.UserRole, {"category": key, "owner_uid": value["uid"]})
                        self._tree_items.append(group)
                        item.addChild(group)
                        for member in value.get(key, []):
                            group.addChild(self._tree_item(member, label, value["uid"]))
        category = self._category_items['messages']
        for message in self.document.data.get('messages', []):
            if _message_group_uid(self.document.data, message) == root_data['uid']:
                self._append_message_tree_item(category, message)
        if expanded_keys is None:
            root.setExpanded(True)
            for index in range(root.childCount()):
                root.child(index).setExpanded(True)
        else:
            iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
            while iterator.value():
                item = iterator.value()
                item.setExpanded(self._tree_expansion_key(item) in expanded_keys)
                iterator += 1
        selected = self._find_tree_item(self._selected_uid)
        selected = selected or root
        self.tree.setCurrentItem(selected)
        if self._selected_uid in selected_uids:
            self.tree.restore_selection(selected_uids, self._selected_uid)
        if first_build:
            for column in range(1, self.tree.columnCount()):
                self.tree.resizeColumnToContents(column)
        self._ensure_definition_column_fits()
        self._building_tree = False
        self._tree_initialized = True
        if not preserve_properties:
            self._selection_changed(selected, None)
        self._apply_tree_filter()
        self._update_transfer_actions()

    def _append_group_tree_item(self, parent, group):
        item = self._tree_item(group, "Group")
        parent.addChild(item)
        child_groups = [
            child for child in self.document.data.get("groups", [])
            if child.get("parent_group_uid") == group.get("uid")
        ]
        messages = [
            message for message in self.document.data.get("messages", [])
            if _message_group_uid(self.document.data, message) == group.get("uid")
        ]
        item.setText(0, f"{group.get('name', 'Group')} ({len(child_groups) + len(messages)})")
        for child in child_groups:
            self._append_group_tree_item(item, child)
        for message in messages:
            self._append_message_tree_item(item, message)

    def _append_message_tree_item(self, parent, message):
        message_item = self._tree_item(message, "Message")
        parent.addChild(message_item)
        self._append_field_items(message_item, message.get("fields", []), message["uid"])
        for key, label in (("runtime_attributes", "Runtime"), ("constants", "Constant"), ("methods", "Method")):
            if not message.get(key):
                continue
            member_group = QtWidgets.QTreeWidgetItem([label + "s", "", "", ""])
            member_group.setData(0, QtCore.Qt.UserRole, {"category": key, "owner_uid": message["uid"]})
            self._tree_items.append(member_group); message_item.addChild(member_group)
            for member in message.get(key, []):
                member_group.addChild(self._tree_item(member, label, message["uid"]))

    def _ensure_definition_column_fits(self):
        """Grow the hierarchy column for its deepest label without overriding wider user sizing."""
        required = self.tree.fontMetrics().horizontalAdvance(self.tree.headerItem().text(0)) + 28
        indentation = self.tree.indentation()
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            depth = 0
            parent = item.parent()
            while parent is not None:
                depth += 1
                parent = parent.parent()
            metrics = QtGui.QFontMetrics(item.font(0))
            item_width = metrics.horizontalAdvance(item.text(0)) + indentation * (depth + 1) + 18
            required = max(required, item_width)
            iterator += 1
        if required > self.tree.columnWidth(0):
            self.tree.setColumnWidth(0, required)

    def _tree_expansion_key(self, item):
        info = item.data(0, QtCore.Qt.UserRole) or {}
        if info.get("uid"):
            return "uid:" + info["uid"]
        if info.get("category"):
            return f"category:{info.get('owner_uid', '')}:{info['category']}"
        return "label:" + item.text(0)

    def _expanded_tree_keys(self):
        keys = set()
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            if item.isExpanded():
                keys.add(self._tree_expansion_key(item))
            iterator += 1
        return keys

    def _collapse_all_tree(self):
        self.tree.collapseAll()

    def _filters_active(self):
        if not hasattr(self, "tree_search"):
            return False
        return bool(
            self.tree_search.text().strip()
            or self.tree_scope.currentText() != "All"
        )

    def _focus_tree_search(self):
        if hasattr(self, "tree_search"):
            self.tree_search.setFocus(); self.tree_search.selectAll()

    def _tree_expansion_changed(self, item):
        if not self._building_tree and not self._filters_active() and hasattr(self, "tree_session_timer"):
            self.tree_session_timer.start()

    def _clear_tree_filters(self):
        if not hasattr(self, "tree_search"):
            return
        self.tree_filter_timer.stop()
        previous = self.tree_search.blockSignals(True); self.tree_search.clear(); self.tree_search.blockSignals(previous)
        previous = self.tree_scope.blockSignals(True); self.tree_scope.setCurrentText("All"); self.tree_scope.blockSignals(previous)
        self._apply_tree_filter()

    def _apply_tree_filter(self, *args):
        if not hasattr(self, "tree") or self._building_tree:
            return
        active = self._filters_active()
        if active and self._filter_expansion_snapshot is None:
            self._filter_expansion_snapshot = self._expanded_tree_keys()
        if not active:
            for item in self._tree_items:
                item.setHidden(False)
            if self._filter_expansion_snapshot is not None:
                snapshot = self._filter_expansion_snapshot
                for item in self._tree_items:
                    item.setExpanded(self._tree_expansion_key(item) in snapshot)
                self._filter_expansion_snapshot = None
            self._filter_matches = []
            self.tree_result_label.setText("All definitions")
            self._update_category_counts(False)
            self._set_reordering_enabled(True)
            return

        terms = [part.casefold() for part in self.tree_search.text().split() if part.strip()]
        scope = self.tree_scope.currentText()
        direct_matches = []
        for item in self._tree_items:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            kind, uid = info.get("kind"), info.get("uid")
            if not uid:
                haystack = " ".join(
                    [item.text(column) for column in range(self.tree.columnCount())]
                    + [str(info.get("category", ""))]
                ).casefold()
                if scope == "All" and terms and all(term in haystack for term in terms):
                    direct_matches.append(item)
                continue
            if scope == "Definitions" and kind not in {"Enum", "Structure", "Group", "Message"}:
                continue
            if scope == "Fields" and kind != "Field":
                continue
            if scope == "Class members" and kind not in {"Runtime", "Constant", "Method"}:
                continue
            if scope == "Problems" and uid not in self._problem_uids:
                continue
            haystack = " ".join(
                [item.text(column) for column in range(self.tree.columnCount())]
                + [str(kind or "")]
            ).casefold()
            if terms and not all(term in haystack for term in terms):
                continue
            direct_matches.append(item)

        visible_ids = {id(item) for item in direct_matches}
        for item in list(direct_matches):
            parent = item.parent()
            while parent:
                visible_ids.add(id(parent)); parent = parent.parent()
        root = self.tree.topLevelItem(0)
        if root:
            visible_ids.add(id(root))
        selected = self._item_by_uid.get(self._selected_uid)
        pinned = selected is not None and id(selected) not in visible_ids
        if pinned:
            visible_ids.add(id(selected)); parent = selected.parent()
            while parent:
                visible_ids.add(id(parent)); parent = parent.parent()
        for item in self._tree_items:
            item.setHidden(id(item) not in visible_ids)
        for item in direct_matches:
            parent = item.parent()
            while parent:
                parent.setExpanded(True); parent = parent.parent()
        self._filter_matches = direct_matches
        suffix = " · current selection kept visible" if pinned else ""
        self.tree_result_label.setText(f"{len(direct_matches)} match{'es' if len(direct_matches) != 1 else ''}{suffix}")
        self._update_category_counts(True)
        self._set_reordering_enabled(False)

    def _update_category_counts(self, filtered):
        for category in self._category_items.values():
            info = category.data(0, QtCore.Qt.UserRole) or {}
            total = int(info.get("total", category.childCount()))
            if info.get("category") == "messages":
                def visible_messages(parent):
                    total = 0
                    for index in range(parent.childCount()):
                        child = parent.child(index)
                        info = child.data(0, QtCore.Qt.UserRole) or {}
                        if info.get('kind') == 'Message': total += int(not child.isHidden())
                        elif info.get('kind') == 'Group': total += visible_messages(child)
                    return total
                visible = visible_messages(category)
            else:
                visible = sum(not category.child(index).isHidden() for index in range(category.childCount()))
            count = f"{visible}/{total}" if filtered else str(total)
            category.setText(0, f"{info.get('base_title', category.text(0))} ({count})")

    def _set_reordering_enabled(self, enabled):
        if not enabled:
            self.tree._clear_drop_feedback()
        self.tree.setDragDropMode(
            QtWidgets.QAbstractItemView.InternalMove if enabled else QtWidgets.QAbstractItemView.NoDragDrop
        )
        for action in getattr(self, "reorder_actions", []):
            action.setEnabled(enabled and len(self.tree.selectedItems()) <= 1)
        self._update_transfer_actions()

    def _expand_tree_matches(self):
        if not self._filters_active():
            self.tree.expandAll()
            return
        for item in self._tree_items:
            if not item.isHidden() and any(not item.child(index).isHidden() for index in range(item.childCount())):
                item.setExpanded(True)

    def _navigate_tree_match(self, delta):
        if self.tree_filter_timer.isActive():
            self.tree_filter_timer.stop(); self._apply_tree_filter()
        if not self._filter_matches:
            return
        current = self.tree.currentItem()
        try:
            index = self._filter_matches.index(current)
        except ValueError:
            index = -1 if delta > 0 else 0
        target = self._filter_matches[(index + delta) % len(self._filter_matches)]
        parent = target.parent()
        while parent:
            parent.setExpanded(True); parent = parent.parent()
        self.tree.setCurrentItem(target); self.tree.scrollToItem(target)

    def _append_field_items(self, parent, fields, owner_uid):
        for field in fields:
            item = self._tree_item(field, "Field", owner_uid)
            if not (parent.data(0, QtCore.Qt.UserRole) or {}).get("field_container"):
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDragEnabled)
            parent.addChild(item)
            nested = field.get("item")
            if isinstance(nested, dict):
                self._append_field_items(item, [nested], owner_uid)
            self._append_field_items(item, field.get("fields", []), owner_uid)
            for case in field.get("cases", []):
                nested = case.get("item")
                if isinstance(nested, dict):
                    self._append_field_items(item, [nested], owner_uid)

    def _tree_item(self, value, kind, owner_uid=""):
        label = value.get("name") or value.get("display_name") or "Library"
        if kind == "Field":
            type_label = self._field_type_label(value)
        elif kind == "Message":
            type_label = "BinaryMessage"
        elif kind == "Group":
            type_label = "MessageGroup"
        elif kind == "Library":
            type_label = ""
        elif kind == "Enum":
            type_label = "Enum"
        elif kind == "Structure":
            type_label = "dataclass"
        elif kind == "Runtime":
            type_label = value.get("annotation") or "Any"
        elif kind == "Constant":
            type_label = value.get("annotation") or "Any"
        elif kind == "Method":
            type_label = {
                "instance": "method", "class": "classmethod",
                "static": "staticmethod", "async": "async method", "property": "property",
            }.get(value.get("kind", "instance"), "method")
        else:
            type_label = kind
        size_label = ""
        if kind == "Field":
            size_label = self._wire_size_analyzer.field(value).label()
        elif kind in {"Structure", "Enum"}:
            size_label = self._wire_size_analyzer.definition(value).label()
        elif kind == "Message":
            size_label = self._wire_size_analyzer.fields(
                value.get("fields", [])
            ).label()
        direction = str(value.get("direction", "ANY")).upper() if kind == "Message" else ""
        item = QtWidgets.QTreeWidgetItem(
            [str(label), str(type_label), size_label, direction]
        )
        item.setTextAlignment(2, QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        item.setTextAlignment(3, QtCore.Qt.AlignCenter)
        field_container = kind in {"Message", "Structure"} or (
            kind == "Field" and value.get("kind") == "inline_struct"
        )
        item.setData(0, QtCore.Qt.UserRole, {
            "uid": value.get("uid", ""), "kind": kind, "owner_uid": owner_uid,
            "field_container": field_container,
        })
        if kind == "Field" and value.get("kind") != "inline_struct":
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDropEnabled)
        self._tree_items.append(item)
        if value.get("uid"):
            self._item_by_uid[value["uid"]] = item
        return item

    def _field_type_label(self, field):
        kind = field.get("kind", "unknown")
        if kind in {"uint", "int"}:
            return f"{kind}{int(field.get('width', 1)) * 8}"
        if kind == "bytes_integer":
            prefix = "int" if field.get("signed") else "uint"
            return f"{prefix}{int(field.get('length', 1)) * 8}"
        if kind == "float": return f"float{int(field.get('width', 4)) * 8}"
        if kind == "enum":
            target = self.document.find(field.get("enum_uid", "")); return target.get("name", "Missing enum") if target else "Missing enum"
        if kind == "struct":
            target = self.document.find(field.get("struct_uid", "")); return target.get("name", "Missing struct") if target else "Missing struct"
        if kind == "array": return f"array[{self._field_type_label(field.get('item', {}))}]"
        if kind == "conditional": return f"{self._field_type_label(field.get('item', {}))}?"
        if kind in {"const", "default", "aligned", "rebuild", "checksum", "length"} and isinstance(field.get("item"), dict):
            return f"{kind}[{self._field_type_label(field['item'])}]"
        if kind == "inline_struct": return "inline struct"
        if kind == "bitfield": return "bits"
        if kind == "string": return f"string[{field.get('encoding', 'utf8')}]"
        if kind == "bytes" and field.get("mode") == "fixed": return f"bytes[{field.get('length', 0)}]"
        if kind == "advanced": return str(field.get("expression", "Construct"))
        return kind

    def _find_tree_item(self, uid):
        return self._item_by_uid.get(uid)

    def _selection_changed(self, current, previous):
        if self._building_tree or current is None:
            return
        info = current.data(0, QtCore.Qt.UserRole) or {}
        key = self._tree_expansion_key(current)
        if previous is not None:
            selected_uids = self.tree.selected_uids()
            self._flush_before_navigation()
            current = self._find_tree_item(info.get("uid")) or next(
                (item for item in self._tree_items if self._tree_expansion_key(item) == key), None)
            if current is None: return
            blocker = QtCore.QSignalBlocker(self.tree)
            self.tree.setCurrentItem(current, 0, QtCore.QItemSelectionModel.NoUpdate)
            del blocker
            if info.get("uid") in selected_uids:
                self.tree.restore_selection(selected_uids, info.get("uid"))
        self._loading_properties = True
        self._properties_pending = False
        self.open_routing_button.setVisible(info.get("kind") in {"Group", "Message"})
        uid = info.get("uid")
        if not uid:
            self._property_uid = ""; self._property_kind = ""; self._property_base = {}
            self.editor_title.setText(current.text(0))
            title, description = self._category_description(info.get("category", ""))
            self.category_info_title.setText(title)
            self.category_info_text.setText(description)
            self.category_info.setVisible(True)
            self.common_properties_widget.setVisible(False)
            self.property_actions_widget.setVisible(False)
            self.name_edit.clear()
            self.details_edit.clear()
            self.name_edit.setEnabled(False)
            self.details_edit.setEnabled(False)
            self.kind_combo.setVisible(False)
            self.field_options_group.setVisible(False)
            self.definition_options_group.setVisible(False)
            self.json_label.setVisible(False)
            self.details_edit.setVisible(False)
            self.reference_label.setVisible(False)
            self.dependencies.setVisible(False)
            self._loading_properties = False
            self._update_property_state()
            return
        self._selected_uid = uid
        self._store_session()
        value = self.document.find(uid)
        if value is None:
            return
        kind = info.get("kind", "Definition")
        self._property_uid = uid; self._property_kind = kind
        draft = self._property_drafts.get(uid)
        migration_draft = bool(draft and draft.get('migration_error'))
        self._property_base = copy.deepcopy(draft["base"] if draft else value)
        if draft and draft.get("value") is not None and not migration_draft:
            value = copy.deepcopy(draft["value"])
        self.editor_title.setText(kind)
        self.category_info.setVisible(False)
        self.common_properties_widget.setVisible(True)
        self.property_actions_widget.setVisible(True)
        self.name_edit.setEnabled(True)
        self.details_edit.setEnabled(True)
        self.name_edit.setEnabled(not migration_draft)
        self.details_edit.setReadOnly(migration_draft)
        self.field_options.setEnabled(not migration_draft)
        self.definition_options.setEnabled(not migration_draft)
        self.name_edit.setText(str(value.get("name") or value.get("display_name") or ""))
        is_field = kind == "Field"
        is_typed_definition = kind in DefinitionOptionsEditor.SUPPORTED
        self.kind_combo.setVisible(is_field)
        self.kind_label.setVisible(is_field)
        self.field_options_group.setVisible(is_field)
        self.definition_options_group.setVisible(is_typed_definition)
        self.json_label.setVisible(not is_field and not is_typed_definition)
        self.details_edit.setVisible(migration_draft or (not is_field and not is_typed_definition))
        self.json_label.setVisible(migration_draft or (not is_field and not is_typed_definition))
        if is_field:
            self.kind_combo.setCurrentText(value.get("kind", "uint"))
            self.field_options.load_field(value, self.document.data)
        elif is_typed_definition:
            self.definition_options.load_definition(value, kind, self.document.data)
        details = {key: val for key, val in value.items() if key not in {"uid", "name", "kind"}}
        self.details_edit.setPlainText(json.dumps(details, indent=2, ensure_ascii=False))
        if draft:
            self.name_edit.setText(draft.get("name", self.name_edit.text()))
            if migration_draft:
                retained = draft.get('value')
                self.details_edit.setPlainText(json.dumps(retained, indent=2, ensure_ascii=False) if retained is not None else draft.get('details', ''))
            else:
                self.details_edit.setPlainText(draft.get("details", self.details_edit.toPlainText()))
            self._properties_pending = True
        self._refresh_property_references(value)
        self._loading_properties = False
        self._update_property_state()

    def _category_description(self, category):
        descriptions = {
            "enums": (
                "Shared enumerations",
                "Enums give meaningful names to numeric wire values and generate reusable Construct Enum schemas. "
                "Select signed or unsigned storage and byte order here, define members, then select this definition from an enum field.",
            ),
            "structures": (
                "Reusable structures",
                "Structures are reusable binary layouts and generate slotted dataclasses plus Construct schemas. "
                "Use a struct field to embed one in messages or other structures.",
            ),
            "messages": (
                "Message classes",
                "Messages are complete BinaryMessage dataclasses with Direction, wire fields, "
                "runtime state, constants, and custom behavior methods. They can be encoded, decoded, and dispatched through the registry.",
            ),
            "groups": (
                "Message groups",
                "Groups organize message routing. Configure their hierarchy and identities in the Routing tab.",
            ),
            "runtime_attributes": (
                "Runtime attributes",
                "Runtime attributes exist on Python message instances but are never encoded into the wire bytes.",
            ),
            "constants": (
                "Class constants",
                "Constants are ClassVar values shared by every instance and are not serialized.",
            ),
            "methods": (
                "Behavior methods",
                "Method declarations generate kind-specific stubs in behaviors.py. Implement their bodies in VS Code.",
            ),
        }
        return descriptions.get(category, ("Library definitions", "Select or create a definition from this group."))

    def _refresh_property_references(self, value=None):
        if value is None:
            value = (self._property_drafts.get(self._property_uid, {}).get("value")
                     or self.document.find(self._property_uid))
        if value is None:
            return
        self.reference_label.setText(self._reference_summary(value))
        self.reference_label.setVisible(bool(self.reference_label.text()))
        self.dependencies.setVisible(self._refresh_dependencies(value))

    def _refresh_dependencies(self, value):
        self.dependencies.clear()
        uid = value.get("uid", "")
        for key, label in (("enum_uid", "Uses enum"), ("struct_uid", "Uses structure")):
            if value.get(key):
                target = self.document.find(value[key])
                row = QtWidgets.QTreeWidgetItem([label, target.get("name", "missing") if target else "missing"])
                row.setData(0, QtCore.Qt.UserRole, {'uid': value[key], 'relation': 'uses'})
                self.dependencies.addTopLevelItem(row)
        for owner in [*self.document.data.get("structures", []), *self.document.data.get("messages", [])]:
            for field in walk_fields(owner.get("fields", [])):
                if field.get("enum_uid") == uid or field.get("struct_uid") == uid:
                    row = QtWidgets.QTreeWidgetItem(["Used by", f"{owner['name']}.{field.get('name', '?')}"])
                    row.setData(0, QtCore.Qt.UserRole, {'uid': field.get('uid'), 'relation': 'used_by'})
                    self.dependencies.addTopLevelItem(row)
        return self.dependencies.topLevelItemCount() > 0

    def _dependency_context_menu(self, item):
        if item is None:
            return None
        info = item.data(0, QtCore.Qt.UserRole) or {}
        if info.get('relation') not in {'uses', 'used_by'}:
            return None
        uid = info.get('uid')
        menu = QtWidgets.QMenu(self.dependencies)
        action = menu.addAction('Edit used field' if info['relation'] == 'used_by' else 'Edit referenced definition')
        action.setData(uid)
        action.setEnabled(bool(uid and self.document.find(uid) and self._find_tree_item(uid)))
        action.triggered.connect(lambda checked=False: self._edit_dependency_target(uid))
        return menu

    def _show_dependency_context_menu(self, position):
        item = self.dependencies.itemAt(position)
        menu = self._dependency_context_menu(item)
        if menu is not None:
            self.dependencies.setCurrentItem(item)
            menu.exec_(self.dependencies.viewport().mapToGlobal(position))
            menu.deleteLater()

    def _edit_dependency_target(self, uid):
        # Applying edits can rebuild the navigator; resolve rows only afterward.
        self._flush_before_navigation()
        if uid and self.document.find(uid) is not None and self._find_tree_item(uid) is not None:
            self._reveal_tree_uid(uid)
            self.tabs.setCurrentWidget(self.definitions_page)

    def _field_kind_changed(self, kind):
        value = self.document.find(self._selected_uid)
        if value is not None and not self._loading_properties and kind != self.field_options._base.get("kind"):
            self.field_options.change_kind(kind, self.name_edit.text().strip() or value.get("name", "field"))
        self._properties_edited()

    def _capture_property_draft(self):
        if self._property_drafts.get(self._property_uid, {}).get('migration_error'):
            return
        uid = self._property_uid
        if self._loading_properties or not uid or self.document.find(uid) is None:
            return
        base = copy.deepcopy(self._property_drafts.get(uid, {}).get("base", self._property_base))
        draft = {"base": base, "kind": self._property_kind, "name": self.name_edit.text(),
                 "details": self.details_edit.toPlainText(), "value": None}
        try:
            value = self._property_candidate(base)
            draft["value"] = value
            check_property_input(value, self._property_kind, self.document.data)
            if value == base:
                self._property_drafts.pop(uid, None)
                self._properties_pending = False
                return
        except (ValueError, TypeError, OverflowError, LookupError, SyntaxError, struct.error) as error:
            draft["error"] = str(error)
        self._property_drafts[uid] = draft
        self._properties_pending = True

    def _watch_editor_inputs(self):
        for root in (self.common_properties_widget, self.field_options, self.definition_options,
                     self.details_edit, self.routing_studio.inspector):
            self._edit_focus_events.watch(root)

    def _end_edit_group(self):
        self._edit_epoch += 1
        self._edit_control = None
        self._auto_merge_key = None

    def _schedule_auto_apply(self, surface, source):
        if self._auto_applying or self._loading_properties:
            return
        self._invalidate_sandbox_result(force=True)
        # Editor rebuilds and row removal can delete the previous signal source.
        if isinstance(source, QtCore.QObject) and sip.isdeleted(source):
            source = None
        self._watch_editor_inputs()
        uid = self._property_uid if surface == "properties" else self.routing_studio._selected_uid
        control = (surface, uid, id(source))
        now = time.monotonic()
        if control != self._edit_control or now - self._edit_time > 1.5:
            self._end_edit_group()
            self._edit_control = control
        self._edit_time = now
        self._auto_merge_key = (*control, self._edit_epoch)
        self._draft_recovery_timer.start()
        if isinstance(source, (QtWidgets.QLineEdit, QtWidgets.QAbstractSpinBox)) and not getattr(source, "_auto_finish_wired", False):
            source._auto_finish_wired = True
            source.editingFinished.connect(lambda: self._focus_commit_timer.start(0))
        if isinstance(source, QtWidgets.QAbstractSpinBox) or getattr(source, '_numeric_edit', False):
            self.auto_apply_timer.stop()
            if not source.hasFocus(): self.auto_apply_timer.start(0)
        else:
            immediate = isinstance(source, QtWidgets.QCheckBox) or (
                isinstance(source, QtWidgets.QComboBox) and not source.isEditable())
            self.auto_apply_timer.start(0 if immediate else 400)
        self._update_property_state()
        self._refresh_all_title_only()

    def _flush_before_navigation(self):
        result = self._flush_auto_edits()
        self._end_edit_group()
        return result

    def _apply_now(self, *, show_errors=True):
        result = self._flush_auto_edits(show_errors=show_errors)
        self._end_edit_group()
        return result

    def _undo_edits(self):
        self._flush_before_navigation()
        self.undo_stack.undo()

    def _redo_edits(self):
        self._flush_before_navigation()
        self.undo_stack.redo()

    def _flush_auto_edits(self, *, show_errors=False):
        if self._flushing_edits:
            return not self._property_drafts and not self.routing_studio._drafts
        self._flushing_edits = True
        self.auto_apply_timer.stop()
        self._focus_commit_timer.stop()
        try:
            if self._properties_pending:
                self._capture_property_draft()
            self.routing_studio.stage_current()
            if not self._property_drafts and not self.routing_studio._drafts:
                return True
            before = self.document.snapshot()
            after = self.document.snapshot()
            applied = []
            for uid, draft in list(self._property_drafts.items()):
                if _find_in_data(after, uid) is None:
                    self._property_drafts.pop(uid, None)
                    continue
                try:
                    if draft.get('migration_error'):
                        raise ValueError(draft['migration_error'])
                    trial = copy.deepcopy(after)
                    target = _find_in_data(trial, uid)
                    value = draft["value"]
                    if value is None:
                        details = json.loads(draft["details"] or "{}")
                        if not isinstance(details, dict): raise ValueError("Properties must be a JSON object")
                        value = {"name": draft["name"].strip(), **details, "uid": uid}
                    check_property_input(value, draft["kind"], trial)
                    previous = copy.deepcopy(target)
                    merge_edits(target, draft["base"], value)
                    if draft["kind"] == "Structure" and previous.get("name") != target.get("name"):
                        _sync_linked_message_name(trial, previous, target)
                    # Schema issues may remain visible while editing, but malformed
                    # JSON shapes must not reach Qt's model or editor rebuilds.
                    validate_manifest(trial)
                except (ValueError, TypeError, OverflowError, LookupError, SyntaxError, struct.error) as error:
                    draft["error"] = str(error)
                    continue
                after = trial
                applied.append(("properties", uid))
                self._property_drafts.pop(uid)
            applied += [("routing", uid) for uid in self.routing_studio.apply_drafts(after)]
            self._properties_pending = self._property_uid in self._property_drafts
            if before != after:
                key = self._auto_merge_key
                if len(applied) != 1 or key is None or key[:2] != applied[0]: key = None
                self._auto_applying = True
                try:
                    self.undo_stack.push(ReplaceManifestCommand(
                        self.document, before, after, "Edit properties and routing" if len(applied) > 1
                        else "Edit properties" if applied and applied[0][0] == "properties" else "Edit routing", merge_key=key,
                    ))
                finally:
                    self._auto_applying = False
            current = self.document.find(self._property_uid)
            if current is not None and self._property_uid not in self._property_drafts:
                self._property_base = copy.deepcopy(current)
                editor = self.field_options if self._property_kind == "Field" else self.definition_options
                editor._base = copy.deepcopy(current)
                if self._property_kind == "Field": self.field_options.refresh_manifest(self.document.data)
            self._refresh_property_references()
            self._update_property_state()
            self.routing_studio._set_pending(bool(self.routing_studio._drafts))
            self.routing_studio._refresh_validation()
            self._refresh_all_title_only()
            self._store_session()
            complete = not self._property_drafts and not self.routing_studio._drafts
            if not complete and show_errors:
                self._show_unfinished_draft()
            return complete
        finally:
            self._flushing_edits = False

    def _show_unfinished_draft(self):
        if self._property_drafts:
            uid, draft = next(iter(self._property_drafts.items()))
            self.tabs.setCurrentWidget(self.definitions_page)
            item = self._find_tree_item(uid)
            if item is not None: self.tree.setCurrentItem(item)
        else:
            uid, draft = next(iter(self.routing_studio._drafts.items()))
            self.tabs.setCurrentWidget(self.routing_studio)
            self.routing_studio.tree.setCurrentItem(self.routing_studio._find_item(uid))
        QtWidgets.QMessageBox.warning(self, "Unfinished edits", draft.get("error", "Finish or revert the highlighted draft before saving."))

    def _routing_defaults_snapshot(self):
        """Merge drafts without committing them or consuming their recovery state."""
        if self._properties_pending:
            self._capture_property_draft()
        self.routing_studio.stage_current()
        candidate = self.document.snapshot()
        for uid, draft in self._property_drafts.items():
            target = _find_in_data(candidate, uid)
            if target is None:
                continue
            if draft.get('migration_error'):
                raise ValueError(draft['migration_error'])
            value = draft['value']
            if value is None:
                details = json.loads(draft['details'] or '{}')
                if not isinstance(details, dict):
                    raise ValueError('Properties must be a JSON object.')
                value = {'name': draft['name'].strip(), **details, 'uid': uid}
            check_property_input(value, draft['kind'], candidate)
            previous = copy.deepcopy(target)
            merge_edits(target, draft['base'], value)
            if draft['kind'] == 'Structure' and previous.get('name') != target.get('name'):
                _sync_linked_message_name(candidate, previous, target)
        owners = {item['uid']: item for item in [candidate['library'], *candidate.get('groups', []),
                                                *candidate.get('messages', [])]}
        for uid, draft in self.routing_studio._drafts.items():
            target = owners.get(uid)
            if target is not None:
                changes = read_routing_draft(candidate, target, draft)
                merge_edits(target, {key: draft['base'].get(key) for key in changes}, changes)
        return candidate

    def _commit_routing_defaults(self, plan):
        # Re-read live drafts: the preview may have been open while external code edited the document.
        after = plan.apply(self._routing_defaults_snapshot())
        before = self.document.snapshot()
        self._discard_edit_drafts()
        self._end_edit_group()
        if before != after:
            self.undo_stack.push(ReplaceManifestCommand(
                self.document, before, after, 'Get routing expected values from defaults' if plan.direction == 'pull'
                else 'Push routing expected values to defaults'))
        else:
            self._refresh_all()
        self._store_session()

    def _transfer_routing_defaults(self, uid, direction):
        if self._flushing_edits:
            return
        # A modal preview must not trigger focus/auto-apply commits beneath it.
        resume_auto_apply = self.auto_apply_timer.isActive() or self._focus_commit_timer.isActive()
        self.auto_apply_timer.stop(); self._focus_commit_timer.stop()
        self._flushing_edits = True
        applied = False
        try:
            snapshot = self._routing_defaults_snapshot()
            dialog = RoutingDefaultsDialog(snapshot, uid, direction, self)
            try:
                if dialog.exec_() == QtWidgets.QDialog.Accepted:
                    self._commit_routing_defaults(dialog.plan)
                    applied = True
            finally:
                dialog.deleteLater()
        except TRANSFER_ERRORS as error:
            QtWidgets.QMessageBox.warning(self, 'Cannot transfer routing defaults', str(error))
        finally:
            self._flushing_edits = False
            self.auto_apply_timer.stop(); self._focus_commit_timer.stop()
            if resume_auto_apply and not applied:
                self.auto_apply_timer.start(400)

    def _revert_property_draft(self):
        self.auto_apply_timer.stop()
        self._property_drafts.pop(self._property_uid, None)
        self._properties_pending = False
        self._selection_changed(self.tree.currentItem(), None)
        self._flush_auto_edits()
        self._end_edit_group(); self._store_session()

    def _discard_edit_drafts(self):
        self.auto_apply_timer.stop(); self._focus_commit_timer.stop(); self._draft_recovery_timer.stop()
        self._property_drafts.clear(); self._properties_pending = False
        self.routing_studio._drafts.clear(); self.routing_studio._editor_dirty = False

    def _properties_edited(self, *args):
        if self._loading_properties:
            return
        value = self.document.find(self._property_uid)
        if value is None:
            return
        if self._property_kind == "Method":
            self.definition_options.set_display_name(self.name_edit.text().strip())
        elif self._property_kind == "Message":
            self.definition_options.set_message_name(self.name_edit.text().strip())
        self._capture_property_draft()
        self._refresh_property_references()
        sender = self.sender()
        source = getattr(sender, "_edit_source", sender)
        self._schedule_auto_apply("properties", source)
        self._update_property_state()
        self._refresh_all_title_only()

    def _property_candidate(self, value):
        kind = self._property_kind
        if kind == "Field":
            updated = self.field_options.value()
            updated["uid"] = value["uid"]
            updated["name"] = self.name_edit.text().strip()
            return updated
        if kind in DefinitionOptionsEditor.SUPPORTED:
            updated = self.definition_options.value()
            updated["uid"] = value["uid"]
            if "name" in value:
                updated["name"] = self.name_edit.text().strip()
            else:
                updated["display_name"] = self.name_edit.text().strip()
            if kind == "Message":
                sync_message_names(updated)
            return updated
        details = json.loads(self.details_edit.toPlainText() or "{}")
        if not isinstance(details, dict):
            raise ValueError("Properties must be a JSON object")
        updated = {"uid": value["uid"]}
        if "name" in value: updated["name"] = self.name_edit.text().strip()
        elif "display_name" in value: updated["display_name"] = self.name_edit.text().strip()
        if kind == "Message": details["behavior_class"] = value.get("behavior_class")
        updated.update(details)
        updated["uid"] = value["uid"]
        return updated

    def _update_property_state(self):
        self.undo_action.setEnabled(self.undo_stack.canUndo() or bool(self._property_drafts) or bool(self.routing_studio._drafts))
        self.revert_properties_button.setEnabled(self._property_uid in self._property_drafts)
        if self._properties_pending:
            error = self._property_drafts.get(self._property_uid, {}).get("error")
            self.property_state_label.setText("Draft: " + error if error else
                                            "These property changes are not applied to the message definition.")
            self.property_state_label.setStyleSheet("color: #b54708; font-weight: 600;")
            self.apply_button.setStyleSheet("font-weight: 600;")
        else:
            other_drafts = len(self._property_drafts)
            self.property_state_label.setText("All property changes are applied." + (
                f" {other_drafts} unfinished draft(s) elsewhere." if other_drafts else ""))
            self.property_state_label.setStyleSheet("color: #b54708; font-weight: 600;" if other_drafts else "color: #287d3c;")
            self.apply_button.setStyleSheet("")
        self._update_transfer_actions()

    def _show_activity_message(self, message):
        if self._restoring_activity:
            return
        if message:
            self._workspace_activity[self._activity_workspace] = (
                message, None, getattr(self.statusBar(), 'message_deadline', None),
            )
        else:
            self._workspace_activity.pop(self._activity_workspace, None)
        self._render_activity_message(message)

    def _restore_workspace_activity(self):
        entry = self._workspace_activity.get(self._activity_workspace)
        if entry and entry[2] is not None and entry[2] <= time.monotonic():
            self._workspace_activity.pop(self._activity_workspace, None)
            entry = None
        message, state, deadline = entry or ("", None, None)
        self._restoring_activity = True
        try:
            self.statusBar().clearMessage()
            if deadline is not None:
                remaining = max(1, int((deadline - time.monotonic()) * 1000) + 1)
                self.statusBar().showMessage(message, remaining)
        finally:
            self._restoring_activity = False
        self._render_activity_message(message, state)

    def _render_activity_message(self, message, state=None):
        defaults = {
            'Definitions': 'Ready to edit',
            'Routing': 'Ready to edit routing',
            'Hex Sandbox': 'Select a message and choose an operation when you are ready.',
            'Generated Code': 'Generated code preview',
        }
        text = message or defaults.get(self._activity_workspace, 'Ready to edit')
        colors = {'info': '#365f91', 'warning': '#9a6700', 'working': '#6b5b00',
                  'success': '#287d3c', 'error': '#b42318'}
        self.activity_state_label.setText(text)
        self.activity_state_label.setToolTip(text)
        self.activity_state_label.setFont(self.statusBar().font())
        self.activity_state_label.setProperty('statusState', state or 'info')
        palette = self.status_contents.palette()
        if state in colors:
            palette.setColor(QtGui.QPalette.WindowText, QtGui.QColor(colors[state]))
        self.activity_state_label.setPalette(palette)

    def _refresh_all_title_only(self):
        package = self.document.data.get("library", {}).get("package_name", "message library")
        self.setWindowTitle(f"Message Designer — {package}")
        if self.loaded is None:
            text, color = "Not saved", "#9a6700"
            tooltip = "This library has not been saved to a folder yet."
        elif self.document.is_dirty:
            text, color = "Changes not saved", "#b54708"
            tooltip = f"Applied changes have not been saved. Target: {self.loaded.package_dir}"
        else:
            text, color = "Saved", "#287d3c"
            tooltip = f"Saved library: {self.loaded.package_dir}"
        states, explanations = [text], [tooltip]
        if self._property_drafts:
            states.append(f"Property drafts pending ({len(self._property_drafts)})")
            explanations.append("Unfinished property edits have not been applied to the definition.")
        if self.routing_studio.apply.isEnabled():
            states.append("Routing changes not applied")
            explanations.append("Unfinished routing edits have not been applied.")
        if len(states) > 1:
            color = "#b54708"
        self.save_state_label.setText(" · ".join(states))
        self.save_state_label.setToolTip("\n".join(explanations))
        self.save_state_label.setStyleSheet(f"padding: 4px 6px; border-radius: 3px; color: {color}; background: rgba(128,128,128,0.10);")

    def _reference_summary(self, value):
        references = []
        if value.get("enum_uid"):
            target = self.document.find(value["enum_uid"])
            references.append("Enum: " + (target.get("name") if target else "missing"))
        if value.get("struct_uid"):
            target = self.document.find(value["struct_uid"])
            references.append("Structure: " + (target.get("name") if target else "missing"))
        return " • ".join(references)

    def apply_properties(self):
        return self._apply_now()

    def _mutate(self, text, operation):
        self._flush_before_navigation()
        before = self.document.snapshot()
        after = self.document.snapshot()
        selected = operation(after)
        if after != before:
            self._selected_uid = selected or self._selected_uid
            self.undo_stack.push(ReplaceManifestCommand(self.document, before, after, text))

    def add_enum(self):
        self._mutate("Add enum", lambda data: _append(data["enums"], new_enum(_unique_name(data, "NewEnum"))))

    def add_structure(self):
        def operation(data):
            structure = new_structure(_unique_name(data, "NewStruct"))
            data["structures"].append(structure)
            return structure["uid"]
        self._mutate("Add structure", operation)

    def add_group(self):
        current = self.tree.currentItem()
        info = current.data(0, QtCore.Qt.UserRole) if current is not None else {}
        selected_parent = info.get("uid", "") if info.get("kind") == "Group" else ""
        def operation(data):
            group = new_group(_unique_name(data, "NewGroup"), selected_parent)
            parent = next((item for item in data.get("groups", []) if item.get("uid") == selected_parent), None)
            data.setdefault("groups", []).append(group)
            return group["uid"]
        self._mutate("Add message group", operation)

    def add_message(self):
        current = self.tree.currentItem()
        info = current.data(0, QtCore.Qt.UserRole) if current is not None else {}
        preferred_group = info.get("uid", "") if info.get("kind") == "Group" else ""
        if info.get("kind") == "Message":
            preferred_group = _selected_group_uid_from_data(self.document.data, info.get("uid", ""))
        def operation(data):
            selected_group = preferred_group
            selected_group = selected_group or data["library"]["uid"]
            message = new_message(_unique_name(data, "NewMessage")); message["group_uid"] = selected_group
            return _append(data["messages"], message)
        self._mutate("Add message", operation)

    def add_field(self):
        owner_uid = self._selected_owner_uid()
        if not owner_uid:
            QtWidgets.QMessageBox.information(self, "Select a type", "Select a message or reusable structure first.")
            return
        def operation(data):
            owner = _find_in_data(data, owner_uid)
            existing = {field.get("name") for field in owner.get("fields", [])}
            index = 1
            name = "field"
            while name in existing:
                index += 1
                name = f"field_{index}"
            return _append(owner.setdefault("fields", []), new_field(name))
        self._mutate("Add field", operation)

    def add_inline_field(self):
        parent_uid = self._selected_uid
        parent = self.document.find(parent_uid)
        if not parent or parent.get("kind") != "inline_struct":
            return
        def operation(data):
            target = _find_in_data(data, parent_uid)
            existing = {field.get("name") for field in target.get("fields", [])}
            name, index = "field", 1
            while name in existing:
                index += 1; name = f"field_{index}"
            return _append(target.setdefault("fields", []), new_field(name))
        self._mutate("Add inline field", operation)

    def add_runtime(self):
        self._add_message_member("runtime_attributes", new_runtime_attribute, "Add runtime attribute")

    def add_constant(self):
        self._add_message_member("constants", new_constant, "Add constant")

    def add_method(self):
        owner_uid = self._selected_message_uid()
        if not owner_uid:
            QtWidgets.QMessageBox.information(self, "Select a message", "Select a message first.")
            return
        method_kind, accepted = QtWidgets.QInputDialog.getItem(
            self, "Add custom method", "Method kind:",
            ["instance", "class", "static", "async", "property"], 0, False,
        )
        if not accepted:
            return
        def operation(data):
            owner = _find_in_data(data, owner_uid)
            used = {method.get("name") for method in owner.get("methods", [])}
            name, index = "custom_method", 1
            while name in used:
                index += 1; name = f"custom_method_{index}"
            method = new_method(name)
            method["kind"] = method_kind
            return _append(owner.setdefault("methods", []), method)
        self._mutate("Add method", operation)

    def _add_message_member(self, collection, factory, text):
        owner_uid = self._selected_message_uid()
        if not owner_uid:
            QtWidgets.QMessageBox.information(self, "Select a message", "Select a message first.")
            return
        self._mutate(text, lambda data: _append(_find_in_data(data, owner_uid).setdefault(collection, []), factory()))

    def _selected_owner_uid(self):
        item = self.tree.currentItem()
        while item:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            if info.get("kind") in {"Message", "Structure"}:
                return info.get("uid")
            item = item.parent()
        return ""

    def _selected_message_uid(self):
        item = self.tree.currentItem()
        while item:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            if info.get("kind") == "Message":
                return info.get("uid")
            item = item.parent()
        return ""

    def duplicate_selected(self):
        if len(self.tree.selectedItems()) > 1:
            return
        uid = self._selected_uid
        def operation(data):
            collection, index = _find_collection(data, uid)
            if collection is None:
                return ""
            duplicate = copy.deepcopy(collection[index])
            _refresh_ids(duplicate)
            if duplicate.get("name"):
                duplicate["name"] += "Copy"
            if collection is data.get("messages"):
                duplicate.pop("generated_from_struct_uid", None)
                duplicate.pop("generated_struct_field_uid", None)
                duplicate["behavior_class"] = duplicate["name"] + "Behavior"
                duplicate.pop("behavior_class_history", None)
            collection.insert(index + 1, duplicate)
            return duplicate["uid"]
        self._mutate("Duplicate definition", operation)

    def delete_selected(self):
        self._flush_before_navigation()
        uids = self.tree.selected_uids()
        before = self.document.snapshot()
        if not uids or any(_find_collection(before, uid)[0] is None for uid in uids):
            return
        after = self.document.snapshot()
        for uid in uids:
            group = next((item for item in after.get("groups", []) if item.get("uid") == uid), None)
            if group is not None:
                assigned = [message for message in after.get("messages", []) if _message_group_uid(after, message) == uid]
                child_groups = [item for item in after.get("groups", []) if item.get("parent_group_uid") == uid]
                if assigned or child_groups:
                    QtWidgets.QMessageBox.warning(self, "Group is not empty", "Move or delete the group's child groups and messages before deleting the group.")
                    return
            structure = next((item for item in after.get("structures", []) if item.get("uid") == uid), None)
            if structure is not None:
                if not self._remove_structure(after, structure, set(uids)):
                    return
            else:
                collection, index = _find_collection(after, uid)
                collection.pop(index)
        self._selected_uid = self._selection_after_deletion(after, uids)
        text = "Delete definition" if len(uids) == 1 else f"Delete {len(uids)} definitions"
        self.undo_stack.push(ReplaceManifestCommand(self.document, before, after, text))

    def _selection_after_deletion(self, data, deleted_uids):
        remaining = set(object_locations(data)) | {data["library"]["uid"]}
        item = self.tree.currentItem()
        if item is None or (item.data(0, QtCore.Qt.UserRole) or {}).get("uid") not in deleted_uids:
            item = self._find_tree_item(deleted_uids[-1])
        while item is not None:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            if info.get("uid") in remaining:
                return info["uid"]
            parent = item.parent()
            if parent is not None and info.get("kind"):
                index = parent.indexOfChild(item)
                # Prefer the following row when both neighbours are equally close.
                positions = sorted(range(parent.childCount()), key=lambda pos: (abs(pos - index), pos < index))
                for position in positions:
                    sibling = parent.child(position)
                    sibling_info = sibling.data(0, QtCore.Qt.UserRole) or {}
                    if (not sibling.isHidden() and sibling_info.get("kind") == info["kind"]
                            and sibling_info.get("uid") in remaining):
                        return sibling_info["uid"]
            item = parent
        return data["library"]["uid"]

    def _remove_structure(self, data, structure, deleting_uids):
        """Prepare a structure removal; the caller commits the entire selection."""
        struct_uid = structure["uid"]
        linked = [
            message for message in data.get("messages", [])
            if message.get("generated_from_struct_uid") == struct_uid
        ]
        linked_field_uids = {message.get("generated_struct_field_uid") for message in linked}
        other_references = []
        for owner in [*data.get("structures", []), *data.get("messages", [])]:
            if owner.get("uid") in deleting_uids:
                continue
            for field in walk_fields(owner.get("fields", [])):
                if field.get("struct_uid") == struct_uid and field.get("uid") not in linked_field_uids:
                    other_references.append(f"{owner.get('name', 'Unnamed')}.{field.get('name', 'field')}")
        if other_references:
            QtWidgets.QMessageBox.warning(
                self, "Structure is still referenced",
                f"{structure['name']} cannot be removed until these fields are changed or removed:\n\n" +
                "\n".join("• " + reference for reference in other_references),
            )
            return False
        choice = QtWidgets.QMessageBox.Yes
        if linked:
            names = ", ".join(message["name"] for message in linked)
            choice = QtWidgets.QMessageBox.question(
                self, "Remove linked message?",
                f"{structure['name']} created the linked message {names}.\n\n"
                "Yes: remove the structure and linked message.\n"
                "No: keep the message by converting its structure field to an inline copy.\n"
                "Cancel: make no changes.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No | QtWidgets.QMessageBox.Cancel,
                QtWidgets.QMessageBox.Yes,
            )
        if choice == QtWidgets.QMessageBox.Cancel:
            return False
        data["structures"][:] = [item for item in data["structures"] if item.get("uid") != struct_uid]
        if choice == QtWidgets.QMessageBox.Yes:
            data["messages"][:] = [message for message in data["messages"] if message.get("generated_from_struct_uid") != struct_uid]
        else:
            for message in data["messages"]:
                if message.get("generated_from_struct_uid") != struct_uid:
                    continue
                field_uid = message.pop("generated_struct_field_uid", "")
                message.pop("generated_from_struct_uid", None)
                field = next((item for item in message.get("fields", []) if item.get("uid") == field_uid), None)
                if field:
                    field.pop("struct_uid", None)
                    field["kind"] = "inline_struct"
                    field["fields"] = copy.deepcopy(structure.get("fields", []))
        return True

    def move_selected(self, delta):
        if len(self.tree.selectedItems()) > 1:
            return
        if self._filters_active():
            self.statusBar().showMessage("Clear navigator filters before reordering definitions.", 5000)
            return
        uid = self._selected_uid
        def operation(data):
            collection, index = _find_collection(data, uid)
            if collection is None:
                return uid
            item = collection[index]
            scope_key = "parent_group_uid" if collection is data.get("groups") else (
                "group_uid" if collection is data.get("messages") else ""
            )
            if scope_key:
                sibling_indices = [
                    position for position, candidate in enumerate(collection)
                    if candidate.get(scope_key, "") == item.get(scope_key, "")
                ]
                sibling_position = sibling_indices.index(index)
                target_position = max(0, min(len(sibling_indices) - 1, sibling_position + delta))
                target = sibling_indices[target_position]
                if target != index:
                    collection[index], collection[target] = collection[target], collection[index]
                return uid
            target = max(0, min(len(collection) - 1, index + delta))
            if target != index:
                collection.insert(target, collection.pop(index))
            return uid
        self._mutate("Reorder definition", operation)

    OBJECT_CLIPBOARD_MIME = "application/x-sakir-definition-clipboard"

    @staticmethod
    def _payload_uids(value):
        return set(owned_ids(value))

    def _source_payload(self):
        uids = self.tree.selected_uids()
        payload = capture_objects(self.document.data, uids)
        if payload is None:
            return None
        owned = self._payload_uids(payload)
        drafts = set(self._property_drafts)
        if hasattr(self, "routing_studio"):
            drafts.update(self.routing_studio._drafts)
        return None if owned & drafts else payload

    def _read_object_clipboard(self):
        saved = self._object_clipboard
        mime = QtWidgets.QApplication.clipboard().mimeData()
        if (saved is None or mime is None or not mime.hasFormat(self.OBJECT_CLIPBOARD_MIME)
                or bytes(mime.data(self.OBJECT_CLIPBOARD_MIME)).decode("utf-8", "replace") != self._clipboard_token
                or saved["library_uid"] != self.document.data["library"]["uid"]):
            self._cut_uids.clear()
            return None
        if saved["mode"] == "cut":
            selected = transfer_sources(self.document.data, saved["uids"], moving=True)
            if not selected or selected[0].parent_uid != saved["payload"]["parent_uid"]:
                self._cut_uids.clear()
                return None
        return saved

    def _paste_target(self, kind):
        item = self.tree.currentItem()
        info = (item.data(0, QtCore.Qt.UserRole) or {}) if item else {}
        category = info.get("category")
        if category in {"enums", "structures", "messages"}:
            expected = {"enums": {"Enum"}, "structures": {"Structure"}, "messages": {"Group", "Message"}}
            return self.document.data["library"]["uid"] if kind in expected[category] else None
        if category in {"runtime_attributes", "constants", "methods"}:
            expected = {"runtime_attributes": "Runtime", "constants": "Constant", "methods": "Method"}
            return info.get("owner_uid") if kind == expected[category] else None
        return info.get("uid")

    def _paste_available(self):
        saved = self._read_object_clipboard()
        if saved is None:
            return False
        parent_uid = self._paste_target(saved["payload"]["kind"])
        siblings = destination_children(self.document.data, saved["payload"]["kind"], parent_uid)
        if siblings is None:
            return False
        if saved["mode"] == "cut":
            if not self._can_move_tree_batch(saved["uids"], parent_uid, len(siblings)):
                return False
            fresh = capture_objects(self.document.data, saved["uids"])
            if self._payload_uids(fresh) & (set(self._property_drafts) | set(self.routing_studio._drafts)):
                return False
        return True

    def _update_transfer_actions(self):
        if self._building_tree or not hasattr(self, "paste_objects_action"):
            return
        payload = self._source_payload()
        self.copy_objects_action.setEnabled(payload is not None)
        self.cut_objects_action.setEnabled(payload is not None and not self._filters_active()
                                           and bool(transfer_sources(self.document.data, self.tree.selected_uids(), moving=True)))
        self.paste_objects_action.setEnabled(self._paste_available())
        multiple = len(self.tree.selectedItems()) > 1
        uids = self.tree.selected_uids()
        self.delete_objects_action.setEnabled(bool(uids) and all(
            _find_collection(self.document.data, uid)[0] is not None for uid in uids))
        for action in getattr(self, "_single_object_actions", []):
            action.setEnabled(not multiple and (action not in self.reorder_actions or not self._filters_active()))
        for uid, item in self._item_by_uid.items():
            cut = uid in self._cut_uids
            item.setData(0, self.tree.CUT_ROLE, cut)
            item.setData(0, QtCore.Qt.ForegroundRole,
                         QtGui.QBrush(self.tree.palette().color(QtGui.QPalette.Disabled, QtGui.QPalette.Text)) if cut else None)
            item.setToolTip(0, "Cut — paste into a compatible parent to move, or press Escape to cancel." if cut else "")

    def _handle_escape(self):
        saved = self._read_object_clipboard()
        if saved is not None and saved["mode"] == "cut":
            self._object_clipboard = None
            self._cut_uids.clear()
            QtWidgets.QApplication.clipboard().clear()
            self._update_transfer_actions()
            return
        self._clear_tree_filters()

    def _capture_clipboard(self, mode):
        self._flush_before_navigation()
        self._update_transfer_actions()
        action = self.cut_objects_action if mode == "cut" else self.copy_objects_action
        if not action.isEnabled():
            return False
        payload = self._source_payload()
        uids = self.tree.selected_uids()
        self._object_clipboard = {"mode": mode, "payload": payload, "uids": uids,
                                  "library_uid": self.document.data["library"]["uid"]}
        self._cut_uids = set(uids) if mode == "cut" else set()
        mime = QtCore.QMimeData()
        mime.setData(self.OBJECT_CLIPBOARD_MIME, self._clipboard_token.encode("utf-8"))
        QtWidgets.QApplication.clipboard().setMimeData(mime)
        self._update_transfer_actions()
        return True

    def copy_objects(self):
        return self._capture_clipboard("copy")

    def cut_objects(self):
        return self._capture_clipboard("cut")

    def paste_objects(self):
        self._flush_before_navigation()
        if not self._paste_available():
            self._update_transfer_actions()
            return False
        saved = self._read_object_clipboard()
        kind = saved["payload"]["kind"]
        parent_uid = self._paste_target(kind)
        before = self.document.snapshot()
        after = self.document.snapshot()
        if saved["mode"] == "cut":
            siblings = destination_children(after, kind, parent_uid)
            if not move_objects(after, saved["uids"], parent_uid, len(siblings)):
                return False
            uids = saved["uids"]
            self._object_clipboard = None
            self._cut_uids.clear()
        else:
            try:
                uids = paste_copy(after, saved["payload"], parent_uid)
            except ValueError as error:
                self.statusBar().showMessage(str(error), 12000)
                return False
            if not uids:
                return False
        self._commit_transfer(before, after, uids, "Paste " + kind.lower() + ("s" if len(uids) > 1 else ""))
        return True

    def _commit_transfer(self, before, after, uids, text):
        self._selected_uid = uids[-1]
        self._pending_selection_uids = list(uids)
        self.undo_stack.push(ReplaceManifestCommand(self.document, before, after, text))
        for uid in uids:
            item = self._find_tree_item(uid)
            if item is not None:
                parent = item.parent()
                while parent is not None:
                    parent.setExpanded(True)
                    parent = parent.parent()
        current = self.tree.currentItem()
        if current is not None:
            self.tree.scrollToItem(current)
        self._update_transfer_actions()
        previous = object_locations(before)
        current_objects = object_locations(after)
        if any(uid in previous and current_objects[uid].kind in {"Group", "Message"}
               and previous[uid].parent_uid != current_objects[uid].parent_uid for uid in uids):
            self.statusBar().showMessage("Definitions moved. Set expected routing values for their new parent in Routing.", 8000)

    def _can_move_tree_batch(self, uids, parent_uid, index):
        if self._filters_active():
            return False
        payload = capture_objects(self.document.data, uids)
        if payload is None or self._payload_uids(payload) & (set(self._property_drafts) | set(self.routing_studio._drafts)):
            return False
        return move_objects(self.document.snapshot(), uids, parent_uid, index)

    def _move_tree_batch(self, uids, parent_uid, index):
        self._flush_before_navigation()
        if not self._can_move_tree_batch(uids, parent_uid, index):
            return False
        before, after = self.document.snapshot(), self.document.snapshot()
        if not move_objects(after, uids, parent_uid, index):
            return False
        self._commit_transfer(before, after, uids, "Move definitions")
        return True

    def _can_move_tree_field(self, uid, parent_uid, index):
        return not self._filters_active() and can_move_field(self.document.data, uid, parent_uid, index)

    def _move_tree_field(self, uid, parent_uid, index):
        if not self._can_move_tree_field(uid, parent_uid, index):
            return False
        return self._commit_tree_move(uid, "Move field", lambda data: move_field(data, uid, parent_uid, index))

    def _can_move_tree_message(self, uid, parent_uid, index):
        return not self._filters_active() and can_move_message(self.document.data, uid, parent_uid, index)

    def _move_tree_message(self, uid, parent_uid, index):
        if not self._can_move_tree_message(uid, parent_uid, index):
            return False
        old_parent_uid = _message_group_uid(self.document.data, self.document.find(uid))
        moved = self._commit_tree_move(uid, "Move message", lambda data: move_message(data, uid, parent_uid, index))
        if moved and old_parent_uid != parent_uid:
            self.statusBar().showMessage("Message moved. Set expected routing values for its new group in Routing.", 8000)
        return moved

    def _can_move_tree_group(self, uid, parent_uid, index):
        return not self._filters_active() and can_move_group(self.document.data, uid, parent_uid, index)

    def _move_tree_group(self, uid, parent_uid, index):
        if not self._can_move_tree_group(uid, parent_uid, index):
            return False
        root_uid = self.document.data["library"]["uid"]
        old_parent_uid = self.document.find(uid).get("parent_group_uid") or root_uid
        moved = self._commit_tree_move(uid, "Move group", lambda data: move_group(data, uid, parent_uid, index))
        if moved and old_parent_uid != (parent_uid or root_uid):
            self.statusBar().showMessage("Group moved. Set expected routing values for its new parent in Routing.", 8000)
        return moved

    def _commit_tree_move(self, uid, text, move):
        moved = False

        def operation(data):
            nonlocal moved
            moved = move(data)
            return uid if moved else self._selected_uid

        self._mutate(text, operation)
        if moved:
            item = self._find_tree_item(uid)
            if item is not None:
                parent = item.parent()
                while parent is not None:
                    parent.setExpanded(True)
                    parent = parent.parent()
                self.tree.scrollToItem(item)
        return moved

    def _tree_order_dropped(self, ordered_uids):
        if self._filters_active():
            self._rebuild_tree()
            return
        if not ordered_uids:
            self._rebuild_tree()
            return
        def operation(data):
            collection, _ = _find_collection(data, ordered_uids[0])
            if collection is None or {item.get("uid") for item in collection} != set(ordered_uids):
                return self._selected_uid
            by_uid = {item["uid"]: item for item in collection}
            collection[:] = [by_uid[uid] for uid in ordered_uids]
            return self._selected_uid
        self._mutate("Reorder definitions", operation)

    def _show_tree_context_menu(self, position):
        item = self.tree.itemAt(position)
        if item is None:
            return
        if item.isSelected():
            self.tree.setCurrentItem(item, 0, QtCore.QItemSelectionModel.NoUpdate)
        else:
            self.tree.setCurrentItem(item)
        info = item.data(0, QtCore.Qt.UserRole) or {}
        menu = QtWidgets.QMenu(self.tree)

        def add(label, callback):
            action = menu.addAction(label); action.triggered.connect(callback)

        category, kind = info.get("category"), info.get("kind")
        if kind == "Library":
            add("Add enum", self.add_enum); add("Add reusable structure", self.add_structure); add("Add group", self.add_group); add("Add message", self.add_message)
            menu.addSeparator(); menu.addAction(self.collapse_all_action)
            menu.addSeparator(); add("Save", self.save_library); add("Save As…", lambda: self.save_library(save_as=True))
        elif category == "enums": add("Add enum", self.add_enum)
        elif category == "structures": add("Add reusable structure", self.add_structure)
        elif category == "messages": add("Add message", self.add_message); add("Add message group", self.add_group)
        elif category == "runtime_attributes": add("Add runtime attribute", self.add_runtime)
        elif category == "constants": add("Add class constant", self.add_constant)
        elif category == "methods": add("Add method", self.add_method)
        elif kind in {"Message", "Structure"}:
            add("Add field", self.add_field)
            if kind == "Message":
                add("Add runtime attribute", self.add_runtime); add("Add class constant", self.add_constant); add("Add method", self.add_method)
            menu.addSeparator(); self._add_common_context_actions(menu)
            if kind == "Message": menu.addSeparator(); add("Open behavior in VS Code", self.open_behavior_code)
        elif kind == "Group":
            add("Add child group", self.add_group); add("Add message", self.add_message); menu.addSeparator(); self._add_common_context_actions(menu)
        elif kind == "Field":
            field = self.document.find(info.get("uid", ""))
            if field and field.get("kind") == "inline_struct": add("Add child field", self.add_inline_field); menu.addSeparator()
            self._add_common_context_actions(menu)
        elif kind in {"Enum", "Runtime", "Constant", "Method"}:
            self._add_common_context_actions(menu)
            if kind == "Method": menu.addSeparator(); add("Open method in VS Code", self.open_behavior_code)
        self._update_transfer_actions()
        if not menu.isEmpty():
            menu.addSeparator()
        menu.addActions([self.cut_objects_action, self.copy_objects_action, self.paste_objects_action])
        menu.exec_(self.tree.viewport().mapToGlobal(position))

    def _add_common_context_actions(self, menu):
        for label, callback in (
            ("Duplicate", self.duplicate_selected), ("Move up", lambda: self.move_selected(-1)),
            ("Move down", lambda: self.move_selected(1)),
        ):
            action = menu.addAction(label); action.triggered.connect(callback)
            if len(self.tree.selectedItems()) > 1 or label in {"Move up", "Move down"} and self._filters_active():
                action.setEnabled(False)
        menu.addAction(self.delete_objects_action)

    def _refresh_validation(self):
        current_issues = [*validate_manifest(self.document.data), *self._behavior_method_issues()]
        library_uid = self.document.data.get("library", {}).get("uid", "")
        self._problem_uids = {
            issue.uid if issue.uid in self._item_by_uid else library_uid
            for issue in current_issues
        }
        self._problem_uids.discard("")
        self._populate_validation_issues(self.issues, current_issues)
        self._apply_tree_filter()

    def _refresh_routing_validation(self, issues):
        self._populate_validation_issues(self.routing_studio.issues, [*issues, *self._behavior_method_issues()])

    def _populate_validation_issues(self, view, current_issues):
        view.clear()
        for issue in current_issues:
            action_label = self._issue_action_label(issue)
            item = QtWidgets.QTreeWidgetItem([issue.severity.title(), issue.message, ""])
            item.setData(0, QtCore.Qt.UserRole, issue.uid)
            item.setData(0, QtCore.Qt.UserRole + 1, issue.code)
            item.setData(0, QtCore.Qt.UserRole + 2, action_label)
            color = "#c0392b" if issue.blocking else "#b9770e"
            item.setForeground(0, QtGui.QBrush(QtGui.QColor(color)))
            item.setToolTip(1, f'{issue.path}: {issue.phase}' + (f' / {issue.option}' if issue.option else '') + f'\n{issue.code}'
                            if issue.path else issue.code)
            view.addTopLevelItem(item)
            if action_label != "Review":
                action_button = QtWidgets.QPushButton(action_label, view)
                action_button.setToolTip(f"Resolve: {issue.message}")
                action_button.clicked.connect(lambda checked=False, target=item: self._activate_issue(target, 2))
                view.setItemWidget(item, 2, action_button)
            else:
                item.setText(2, action_label)

    def _behavior_method_issues(self):
        source = self._behavior_source() if self.loaded else None
        return validate_behavior_methods(source, self.document.data.get("messages", []))

    def _issue_action_label(self, issue):
        if issue.code == "routing-unassigned":
            return "Assign expected values"
        if issue.code == "routing-ancestor-unassigned":
            return "Assign ancestor values"
        if self._is_routing_issue(issue.code):
            return "Go to routing"
        if issue.code in {"empty-method", "reserved-behavior-method"}:
            return "Open in VS Code" if self.loaded else "Save and open in VS Code"
        if issue.code in {"missing-method", "missing-behavior-class"}:
            return "Save to recreate"
        if issue.code in {"method-kind-drift", "method-signature-drift"}:
            return "Save to restore signature"
        if issue.code in {"behavior-syntax", "behavior-identity"}:
            return "Open behaviors.py in VS Code"
        return "Go to definition" if issue.uid else "Review"

    @staticmethod
    def _is_routing_issue(code):
        return str(code).startswith("routing-") or code in {
            "group-router", "message-router", "duplicate-group-route", "duplicate-message-route",
        }

    def _activate_issue(self, item, column=0):
        uid = item.data(0, QtCore.Qt.UserRole)
        code = item.data(0, QtCore.Qt.UserRole + 1)
        self._reveal_tree_uid(uid)
        if self._is_routing_issue(code):
            if code == "duplicate-group-route":
                group = self.document.find(uid) or {}
                uid = group.get("parent_group_uid") or self.document.data["library"]["uid"]
            self.tabs.setCurrentWidget(self.routing_studio)
            target = self.routing_studio._find_item(uid)
            if target is not None:
                self.routing_studio.tree.setCurrentItem(target)
        elif code in {"empty-method", "reserved-behavior-method"}:
            if self.loaded or self.save_library():
                self.open_behavior_code()
        elif code in {"missing-method", "missing-behavior-class", "method-kind-drift", "method-signature-drift"}:
            self.save_library()
        elif code == "behavior-syntax":
            self.open_behavior_code()
        else:
            self.tabs.setCurrentWidget(self.definitions_page)

    def _show_issue_context_menu(self, position, view=None):
        view = view if view is not None else self.issues
        item = view.itemAt(position)
        if item is None:
            return
        menu = QtWidgets.QMenu(view)
        uid = item.data(0, QtCore.Qt.UserRole)
        if uid:
            focus = menu.addAction("Go to definition")
            focus.triggered.connect(lambda: self._focus_issue_definition(item))
        action_text = item.data(0, QtCore.Qt.UserRole + 2) or item.text(2)
        if action_text not in {"Go to definition", "Review"}:
            action = menu.addAction(action_text)
            action.triggered.connect(lambda: self._activate_issue(item, 2))
        if not menu.isEmpty():
            menu.exec_(view.viewport().mapToGlobal(position))

    def _focus_issue_definition(self, item):
        uid = item.data(0, QtCore.Qt.UserRole)
        self._reveal_tree_uid(uid)
        self.tabs.setCurrentWidget(self.definitions_page)

    def _reveal_tree_uid(self, uid):
        if not uid:
            return
        self._selected_uid = uid
        self._apply_tree_filter()
        target = self._find_tree_item(uid)
        if target:
            self.tree.setCurrentItem(target)
            parent = target.parent()
            while parent:
                parent.setExpanded(True); parent = parent.parent()
            self.tree.scrollToItem(target)

    def _refresh_preview_messages(self):
        selected_scope = self.preview_group_scope.currentData()
        scope_blocker = QtCore.QSignalBlocker(self.preview_group_scope)
        self.preview_group_scope.clear()
        self.preview_group_scope.addItem('Library (main group)', self.document.data['library']['uid'])
        by_uid = {group['uid']: group for group in self.document.data.get('groups', [])}
        for group in by_uid.values():
            path = []; current_group = group; seen = set()
            while current_group and current_group['uid'] not in seen:
                seen.add(current_group['uid']); path.append(current_group.get('name', 'Group'))
                current_group = by_uid.get(current_group.get('parent_group_uid'))
            self.preview_group_scope.addItem('/'.join(reversed(path)), group['uid'])
        self.preview_group_scope.setCurrentIndex(max(0, self.preview_group_scope.findData(selected_scope)))
        del scope_blocker
        current = self.preview_message.currentText() if hasattr(self, "preview_message") else ""
        blocker = QtCore.QSignalBlocker(self.preview_message)
        self.preview_message.clear()
        self.preview_message.addItems(message["name"] for message in self.document.data.get("messages", []))
        if current and self.preview_message.findText(current) >= 0:
            self.preview_message.setCurrentText(current)
        del blocker
        available = self.preview_message.count() > 0
        for button in getattr(self, "preview_action_buttons", ()):
            button.setEnabled(available)
        if not available and hasattr(self, "activity_state_label"):
            self._set_preview_status("Add a message definition before using the Hex Sandbox.", "info")
            self._preview_rendered_message = ""
            self.preview_values.clear()
        elif self.preview_message.currentText() != self._preview_rendered_message:
            self._preview_message_changed(self.preview_message.currentText())
        else:
            message_name = self.preview_message.currentText()
            try:
                current_values = self._read_preview_values(message_name)
            except SandboxValueError:
                current_values = None
            prior_sample = self._preview_sample_values.get(message_name)
            fresh_sample = sample_message_values(self.document.data, message_name)
            if current_values is not None and current_values == prior_sample and fresh_sample != prior_sample:
                self._preview_value_drafts[message_name] = copy.deepcopy(fresh_sample)
                self._preview_sample_values[message_name] = copy.deepcopy(fresh_sample)
                self._write_preview_values(fresh_sample, message_name)

    def _set_preview_status(self, message, state="info"):
        self._workspace_activity['Hex Sandbox'] = (message, state, None)
        if self._activity_workspace == 'Hex Sandbox':
            self._restore_workspace_activity()

    def _format_preview_object(self):
        try:
            values = self._read_preview_values()
            self._write_preview_values(values)
        except SandboxValueError as error:
            self._set_preview_status(f"Message initialization is invalid: {error}", "error")
            return
        self._set_preview_status("Message values formatted as object initialization.", "success")

    def _preview_message_changed(self, message_name):
        self._set_preview_status('Select an operation for the selected message.', 'info')
        if not message_name:
            return
        if self._preview_rendered_message:
            try:
                previous_values = self._read_preview_values(self._preview_rendered_message)
                self._preview_value_drafts[self._preview_rendered_message] = copy.deepcopy(previous_values)
            except SandboxValueError:
                pass
        values = copy.deepcopy(self._preview_value_drafts.get(message_name))
        if values is None:
            values = sample_message_values(self.document.data, message_name)
            self._preview_value_drafts[message_name] = copy.deepcopy(values)
            self._preview_sample_values[message_name] = copy.deepcopy(values)
        self._preview_rendered_message = message_name
        try:
            self._write_preview_values(values, message_name)
        except SandboxValueError:
            values = {}
            self._preview_value_drafts[message_name] = {}
            self._write_preview_values(values, message_name)

    def _read_preview_values(self, message_name=None):
        message_name = message_name or self._preview_rendered_message or self.preview_message.currentText()
        text = self.preview_values.toPlainText()
        if not message_name:
            if not text.strip():
                return {}
            raise SandboxValueError("Select a message class first.")
        return parse_object_values(text, self.document.data, message_name)

    def _write_preview_values(self, values, message_name=None):
        message_name = message_name or self.preview_message.currentText()
        if message_name:
            text = format_object_values(values, self.document.data, message_name)
        else:
            text = ""
        self.preview_values.setPlainText(text)

    def _normalize_preview_hex(self):
        try:
            raw = bytes.fromhex(self.preview_hex.toPlainText())
        except ValueError as error:
            self._set_preview_status(f"Wire bytes contain invalid hexadecimal text: {error}", "error")
            return
        self.preview_hex.setPlainText(raw.hex(" "))
        self._set_preview_status(f"Normalized {len(raw)} wire bytes.", "success")

    def _update_preview_byte_count(self):
        try:
            count = len(bytes.fromhex(self.preview_hex.toPlainText()))
        except ValueError:
            self.preview_byte_count.setText("Invalid hex")
            self.preview_byte_count.setStyleSheet("color: #b42318; font-weight: 600;")
            return
        self.preview_byte_count.setText(f"{count} byte{'s' if count != 1 else ''}")
        self.preview_byte_count.setStyleSheet("color: palette(mid);")

    def _refresh_code(self):
        if not hasattr(self, "code_editors"):
            return
        behavior = self._behavior_source()
        try:
            generated = generate_library(self.document.data, behavior)
        except Exception as error:
            for editor in self.code_editors.values():
                editor.setPlainText(f"Generation unavailable:\n{error}")
            return
        for name, editor in self.code_editors.items():
            editor.setPlainText(generated.files[name])

    def _behavior_source(self):
        path = self.loaded.package_dir / "behaviors.py" if self.loaded else None
        return path.read_text(encoding="utf-8") if path and path.is_file() else ""

    def _default_behavior_changed(self, _path=None):
        self._definition_revision += 1
        self._invalidate_sandbox_result(force=True)
        self._set_preview_status('Default message unverified: behavior source changed. Run Check default message again.', 'info')

    def _watch_default_behavior(self):
        watcher = self._default_behavior_watcher
        paths = watcher.files() + watcher.directories()
        if paths:
            watcher.removePaths(paths)
        if self.loaded:
            path = self.loaded.package_dir / 'behaviors.py'
            if path.is_file():
                watcher.addPath(str(path))
            if path.parent.is_dir():
                watcher.addPath(str(path.parent))

    def _sandbox_identity(self, operation):
        values = ''
        if operation == 'build':
            try:
                values = json.dumps(self._read_preview_values(), sort_keys=True)
            except (ValueError, TypeError):
                values = self.preview_values.toPlainText()
        return (wire_identity(self.preview_hex.toPlainText()), self.preview_group_scope.currentData(),
                self.preview_direction.currentText(), self._definition_revision,
                self.preview_message.currentText() if operation != 'auto_parse' else '', values)

    def _sandbox_values_changed(self):
        result = self.results_panel.result
        if result and result.operation == 'build': self._invalidate_sandbox_result()

    def _invalidate_sandbox_result(self, *args, force=False):
        if self._sandbox_running or self._updating_result_inputs: return
        result = self.results_panel.result
        if result and (force or result.input_identity != self._sandbox_identity(result.operation)):
            self.results_panel.mark_stale()
            self.routing_studio.clear_trace()
            self._update_routing_notice()

    def _update_routing_notice(self):
        result = self.results_panel.result
        if result and result.operation == 'auto_parse':
            if result.stale:
                text = 'Routing: result out of date'
                explanation = 'Routing result is out of date. Run Decode auto to refresh.'
            else:
                if result.routing is not None:
                    text = 'Routing: latest Decode auto result'
                    explanation = 'Routing view shows the latest Decode auto result. Open Routing to inspect.'
                else:
                    text = 'Routing: no packet path available'
                    explanation = 'Decode auto has not produced a routing path. Open Routing shows the current configuration.'
            color = '#9a6700'
        else:
            text = 'Routing: current configuration'
            explanation = 'Routing shows the current configuration. Run Decode auto to inspect a packet route.'
            color = '#365f91'
        self.routing_notice.setText(text)
        self.routing_notice.setToolTip(explanation)
        self.routing_notice.setStyleSheet('color: ' + color + ';')
        self.routing_notice_button.setToolTip(explanation)

    def _open_result_routing(self, uid=''):
        result = self.results_panel.result
        diagnostic = result.routing if result and not result.stale else None
        if not uid and diagnostic and diagnostic.steps:
            last = diagnostic.steps[-1]
            uid = last['selected_uid'] or last['group_uid']
        uid = uid if self.document.find(uid) else self.document.data['library']['uid']
        self.tabs.setCurrentWidget(self.routing_studio)
        self.routing_studio.view_mode.setCurrentText('Graph')
        self.routing_studio.search.clear()
        self.routing_studio._select_graph_uid(uid)
        self.routing_studio.graph.locate_selection()

    def _open_result_definition(self, uid):
        result = self.results_panel.result
        if result is None or result.stale or self.document.find(uid) is None: return
        self.tabs.setCurrentWidget(self.definitions_page)
        self._reveal_tree_uid(uid)

    def _publish_result(self, result):
        identity = self._sandbox_identity(result.operation)
        if not result.input_identity: result.input_identity = identity
        elif result.input_identity != identity: result.stale = True
        self.results_panel.set_result(result)
        if result.operation == 'auto_parse' and not result.stale: self.routing_studio.show_trace(result.routing)
        else: self.routing_studio.clear_trace()
        self._update_routing_notice()

    def _result_error(self, result, message, payload='Not decoded', state='error'):
        message = str(message)
        result.error, result.payload_state = message, payload
        self._publish_result(result)
        self._set_preview_status(message, state)

    def run_sandbox(self, action):
        if self._sandbox_running: return
        self._sandbox_running = True
        message = self.preview_message.currentText()
        owner = next((item for item in self.document.data.get('messages', []) if item['name'] == message), {})
        result = RunResult(action, owner.get('uid', ''), '' if action == 'auto_parse' else message,
                           self.preview_direction.currentText(), self.preview_group_scope.currentData(),
                           manifest=copy.deepcopy(self.document.data), definition_revision=self._definition_revision)
        self._publish_result(result)
        try:
            self._run_sandbox_operation(result)
        finally:
            self._sandbox_running = False

    def _run_sandbox_operation(self, result):
        action = result.operation
        if not self._flush_auto_edits(show_errors=False):
            self._result_error(result, 'Finish pending property and routing edits before running the operation.', 'Blocked')
            return
        result.manifest = copy.deepcopy(self.document.data)
        result.definition_revision = self._definition_revision
        result.input_identity = self._sandbox_identity(result.operation)
        result.stale = False
        result.direction, result.scope_uid = self.preview_direction.currentText(), self.preview_group_scope.currentData()
        if action == 'check_default': self._watch_default_behavior()
        if action in {'parse', 'auto_parse', 'round_trip'}:
            try:
                raw = bytes.fromhex(self.preview_hex.toPlainText())
                result.byte_count = len(raw)
            except ValueError as error:
                self._result_error(result, f'Wire bytes contain invalid hexadecimal text: {error}', 'Invalid input')
                return
        message = self.preview_message.currentText()
        if action == 'auto_parse':
            try:
                if self._compiled_preview_router is None:
                    self._compiled_preview_router = compile_manifest_routing(self.document.data)
                result.routing = self._compiled_preview_router.diagnose(raw, group_uid=result.scope_uid, direction=result.direction)
            except (ValueError, LookupError, RoutingMatchError) as error:
                result.routing_state = 'Failed'
                self._result_error(result, 'Automatic routing failed: ' + str(error))
                return
            if result.routing.error:
                result.routing_state = 'Failed'
                error = result.routing.error
                if isinstance(error, AmbiguousMessageIdentityError):
                    self._result_error(result, f'Automatic routing is ambiguous: {error}', state='warning')
                else:
                    self._result_error(result, f'Automatic routing failed: {error}')
                return
            result.routing_state = 'Matched'
            owner = self.document.find(result.routing.message_uid)
            result.message_uid, result.message_name = owner['uid'], owner['name']
            message = owner['name']
            self.preview_message.setCurrentText(message)
            action = 'parse'
            self._publish_result(result)
        else:
            owner = next((item for item in self.document.data.get('messages', []) if item['name'] == message), {})
            result.message_uid, result.message_name = owner.get('uid', ''), message
        if not message:
            self._result_error(result, 'Add or select a message before running the sandbox.', 'Blocked')
            return
        values = {}
        if action == 'build':
            try: values = self._read_preview_values()
            except SandboxValueError as error:
                self._result_error(result, f'Message initialization is invalid: {error}', 'Invalid input')
                return
        self._set_preview_status(f'{OPERATIONS[result.operation]} for {message}…', 'working')
        QtWidgets.QApplication.processEvents(QtCore.QEventLoop.ExcludeUserInputEvents)
        source_bytes = result.input_identity[0]
        request = {'manifest': result.manifest, 'behaviors': self._behavior_source(), 'message': message,
                   'action': action, 'values': values,
                   'hex': source_bytes.hex(' ') if isinstance(source_bytes, bytes) else self.preview_hex.toPlainText()}
        try:
            process = subprocess.run([sys.executable, '-m', 'app.tools.message_designer.sandbox'],
                                     input=json.dumps(request), capture_output=True, text=True,
                                     cwd=str(Path(__file__).resolve().parents[3]), timeout=8)
        except subprocess.TimeoutExpired:
            self._result_error(result, 'Preview timed out after 8 seconds.', 'Timed out')
            return
        except OSError as error:
            self._result_error(result, 'Preview process could not start: ' + str(error), 'Execution failed')
            return
        try:
            response = json.loads(process.stdout)
            if not isinstance(response, dict): raise ValueError('Expected an object response')
        except (ValueError, TypeError):
            self._result_error(result, process.stderr or 'Preview process returned invalid output.', 'Execution failed')
            return
        if not response.get('ok'):
            self._result_error(result, response.get('error', 'Preview failed'), 'Failed')
            return
        if type(process.returncode) is int and process.returncode != 0:
            self._result_error(result, process.stderr or 'Preview process exited unsuccessfully.', 'Execution failed')
            return
        try:
            result.values = semantic_values(response) if 'values' in response else None
            result.initialized = from_json_value(response['initialized_values']) if 'initialized_values' in response else None
            if any(value is not None and not isinstance(value, dict) for value in (result.values, result.initialized)):
                raise ValueError('Expected message field objects in the preview response')
        except (ValueError, TypeError) as error:
            result.values, result.initialized = None, None
            self._result_error(result, 'Invalid preview values: ' + str(error), 'Execution failed')
            return
        if action == 'check_default':
            status = str(response.get('default_status', 'Unverified'))
            if status != 'Verified':
                self._result_error(result, status + ': ' + response.get('error', ''), status,
                                   'error' if status == 'Invalid' else 'info')
                return
        round_trip = response.get('round_trip')
        if result.input_identity != self._sandbox_identity(result.operation): result.stale = True
        if not result.stale:
            self._updating_result_inputs = True
            try:
                if round_trip is not False:
                    self.preview_hex.setPlainText(response.get('rebuilt_hex') or response.get('hex', ''))
                self._preview_rendered_message = message
                response_values = response.get('values', {})
                self._preview_value_drafts[message] = copy.deepcopy(response_values)
                self._write_preview_values(response_values, message)
            finally:
                self._updating_result_inputs = False
            result.input_identity = self._sandbox_identity(result.operation)
        if result.byte_count is None:
            try: result.byte_count = len(bytes.fromhex(self.preview_hex.toPlainText()))
            except ValueError: pass
        result.payload_state = {'build': 'Encoded', 'parse': 'Decoded', 'round_trip': 'Round trip matched',
                                'check_default': 'Verified'}[action]
        if round_trip is False:
            self._result_error(result, 'Round trip differs: rebuilt bytes do not match the input.', 'Round trip differs', 'warning')
            return
        if round_trip is True:
            status = ('Default message verified: constructor → encode → decode → encode matched exactly.'
                      + (' Constructor and effective wire values are shown separately; derived fields or scalar precision differ.'
                         if response.get('normalized') else '')) if action == 'check_default' else 'Round trip matched exactly; rebuilt bytes are identical to the input.'
        elif action == 'build': status = 'Message built successfully from the structured values.'
        else: status = 'Wire bytes parsed successfully.'
        self._publish_result(result)
        self._set_preview_status(status, 'success')

    def new_library(self):
        if not self._resolve_unsaved_changes():
            return
        name, accepted = QtWidgets.QInputDialog.getText(self, "New message library", "Python package name:", text="protocol_messages")
        if not accepted:
            return
        self.loaded = None
        self.package_parent = None
        self._clear_tree_filters()
        self._restored_expanded_keys = None
        self._filter_expansion_snapshot = None
        manifest = new_manifest(name.strip())
        self.document.data = copy.deepcopy(manifest)
        self.document.saved_snapshot = copy.deepcopy(manifest)
        self._selected_uid = manifest["library"]["uid"]
        self._properties_pending = False
        self._tree_initialized = False
        self.undo_stack.clear()
        self.document.notify("new")

    def open_library(self):
        if not self._resolve_unsaved_changes():
            return
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Open generated message package")
        if not folder:
            return
        try:
            loaded = load_library(folder)
        except LibraryPersistenceError as error:
            QtWidgets.QMessageBox.critical(self, "Cannot open library", str(error))
            return
        self.loaded = loaded
        self.package_parent = loaded.package_dir.parent
        self._clear_tree_filters()
        self._restored_expanded_keys = None
        self._filter_expansion_snapshot = None
        self._tree_initialized = False
        self.document.replace(loaded.manifest, reason="opened")
        self.document.mark_saved()
        self.undo_stack.clear()
        if self.document.pending_upgrade:
            notes = self.document.data.get('enum_migration', {}).get('notes', [])
            self.statusBar().showMessage('Legacy library migrated in memory. Save to regenerate Construct enums. ' + ' '.join(notes), 20000)
        behavior_issues = self._behavior_method_issues()
        if behavior_issues:
            QtWidgets.QMessageBox.warning(
                self, "Behavior method warnings",
                "The loaded behaviors.py differs from the method declarations:\n\n" +
                "\n".join("• " + issue.message for issue in behavior_issues),
            )

    def save_library(self, save_as=False):
        if not self._flush_auto_edits(show_errors=True):
            return False
        self._end_edit_group()
        issues = [
            issue
            for issue in [
                *validate_manifest(self.document.data),
                *self._behavior_method_issues(),
            ]
            if issue.blocking
        ]
        if issues:
            QtWidgets.QMessageBox.critical(self, "Cannot save", "Resolve blocking validation errors first.")
            return False
        if save_as or self.package_parent is None:
            folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select parent folder for generated package")
            if not folder:
                return False
            parent = Path(folder)
            previous = None
        else:
            parent = self.package_parent
            previous = self.loaded
            target = parent / self.document.data["library"]["package_name"]
            if previous and target.resolve() != previous.package_dir.resolve():
                previous = None
        changes = compatibility_changes(self.document.saved_snapshot, self.document.data)
        if changes["breaking"]:
            detail = "\n".join("• " + item for item in changes["breaking"])
            answer = QtWidgets.QMessageBox.warning(
                self, "Breaking library changes", "The following changes can break existing data or code:\n\n" + detail + "\n\nContinue?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return False
        try:
            outcome = save_library(parent, self.document.data, previous=previous, source_library=self.loaded)
        except ExternalModificationError as error:
            answer = QtWidgets.QMessageBox.warning(
                self, "Generated files changed externally",
                str(error) + "\n\nOverwrite the generated files? behaviors.py will still be merged and preserved.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return False
            try:
                outcome = save_library(parent, self.document.data, previous=None, source_library=self.loaded, overwrite_modified=True)
            except Exception as retry_error:
                QtWidgets.QMessageBox.critical(self, "Save failed", str(retry_error))
                return False
        except Exception as error:
            QtWidgets.QMessageBox.critical(self, "Save failed", str(error))
            return False
        self.loaded = load_library(outcome.package_dir)
        self.package_parent = outcome.package_dir.parent
        self.document.mark_saved(outcome.manifest)
        message = f"Saved {outcome.package_dir}"
        if outcome.backup_dir:
            message += f"; backup: {outcome.backup_dir}"
        self.statusBar().showMessage(message, 10000)
        if outcome.warnings:
            QtWidgets.QMessageBox.information(self, "Preserved custom code", "\n".join(outcome.warnings))
        return True

    def open_behavior_code(self):
        if not self.loaded:
            QtWidgets.QMessageBox.information(self, "Save first", "Save the library before opening behaviors.py.")
            return
        path = self.loaded.package_dir / "behaviors.py"
        line = 1
        value = self.document.find(self._selected_uid)
        owner_uid = self._selected_message_uid()
        owner = self.document.find(owner_uid) if owner_uid else None
        try:
            source = path.read_text(encoding="utf-8")
            tree, _, resolved = resolve_behavior_classes(source, self.document.data.get("messages", []))
            class_name = owner.get("behavior_class") if owner else None
            if resolved.get(class_name) is not None:
                class_name = resolved[class_name].name
            method_name = value.get("name") if value and value in (owner or {}).get("methods", []) else None
            for node in tree.body:
                if isinstance(node, ast.ClassDef) and node.name == class_name:
                    line = node.lineno
                    if method_name:
                        method = next((item for item in node.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == method_name), None)
                        if method:
                            line = method.lineno
                    break
        except (OSError, SyntaxError, ValueError):
            pass
        opener = self._behavior_opener or getattr(self.parent(), "_open_message_behavior_in_vscode", None)
        if callable(opener):
            opener(path, line)
        else:
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(path)))

    def cleanup_empty_orphans(self):
        if not self.loaded:
            QtWidgets.QMessageBox.information(self, "Save first", "Save the library before cleaning behavior stubs.")
            return
        path = self.loaded.package_dir / "behaviors.py"
        try:
            source = path.read_text(encoding="utf-8")
            cleaned, removed = remove_empty_orphans(source, self.document.data.get("messages", []))
        except (OSError, SyntaxError, ValueError) as error:
            QtWidgets.QMessageBox.critical(self, "Cannot inspect behaviors.py", str(error))
            return
        if not removed:
            QtWidgets.QMessageBox.information(self, "No empty orphans", "No removable empty behavior methods or mixins were found.")
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Remove empty orphan stubs",
            "Remove these empty stubs? Non-empty custom code is never selected.\n\n" + "\n".join(removed),
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        )
        if answer != QtWidgets.QMessageBox.Yes:
            return
        backup = path.with_suffix(".py.message-designer.bak")
        backup.write_text(source, encoding="utf-8")
        temporary = path.with_suffix(".py.message-designer.tmp")
        temporary.write_text(cleaned, encoding="utf-8")
        os.replace(temporary, path)
        self._refresh_code()
        self.statusBar().showMessage(f"Removed {len(removed)} empty orphan stubs; backup: {backup}", 10000)

    def _store_session(self):
        if not getattr(self, "session_path", None):
            return
        try:
            save_session(
                self.session_path, self.document.data, self.document.saved_snapshot,
                package_dir=self.loaded.package_dir if self.loaded else None,
                selected_uid=self._selected_uid,
                expanded_tree_keys=list(
                    self._filter_expansion_snapshot
                    if self._filters_active() and self._filter_expansion_snapshot is not None
                    else (self._expanded_tree_keys() if hasattr(self, "tree") else set())
                ),
                property_drafts=self._property_drafts,
                routing_drafts=self.routing_studio._drafts,
                routing_selected_uid=self.routing_studio._selected_uid,
                routing_view_state=self.routing_studio.view_state(),
                results_view_state=self.results_panel.view_state(),
            )
        except OSError as error:
            if hasattr(self, "statusBar"):
                self.statusBar().showMessage(f"Could not store Message Designer recovery session: {error}", 8000)

    def _resolve_unsaved_changes(self):
        self._flush_before_navigation()
        routing_pending = self.routing_studio.apply.isEnabled()
        if self.loaded is not None and not self.document.is_dirty and not self._property_drafts and not routing_pending:
            return True
        descriptions = []
        if self._property_drafts: descriptions.append("Some property drafts have not been completed.")
        if routing_pending: descriptions.append("Some routing edits have not been applied.")
        if self.document.is_dirty: descriptions.append("The message library has changes that have not been saved.")
        elif self.loaded is None: descriptions.append("This new message library has not been saved to a folder.")
        answer = QtWidgets.QMessageBox.warning(
            self, "Unsaved Message Designer changes", "\n".join(descriptions) + "\n\nSave before continuing?",
            QtWidgets.QMessageBox.Save | QtWidgets.QMessageBox.Discard | QtWidgets.QMessageBox.Cancel,
            QtWidgets.QMessageBox.Save,
        )
        if answer == QtWidgets.QMessageBox.Save:
            return self.save_library()
        if answer == QtWidgets.QMessageBox.Discard:
            self._discard_edit_drafts()
            if self.loaded is not None: self.document.restore_saved()
            self.routing_studio.refresh(self.document.data, self._selected_uid, keep_drafts=True)
            return True
        return False

    def closeEvent(self, event):
        was_dirty = self.loaded is None or self.document.is_dirty or bool(self._property_drafts) or self.routing_studio.apply.isEnabled()
        had_target = self.loaded is not None
        if not self._resolve_unsaved_changes():
            event.ignore()
            return
        if was_dirty and not self.document.is_dirty and not self._properties_pending:
            # The Save branch already stored the clean session.
            self._store_session()
        elif was_dirty:
            # Explicit Discard must not recover the discarded draft next time.
            if had_target:
                self.document.restore_saved()
                self._store_session()
            else:
                clear_session(self.session_path)
        else:
            self._store_session()
        self._edit_events_active = False
        self.auto_apply_timer.stop(); self._focus_commit_timer.stop(); self._draft_recovery_timer.stop()
        event.accept()


def _sandbox_action_icon(action, palette):
    icon = QtGui.QIcon()
    for mode, group in ((QtGui.QIcon.Normal, QtGui.QPalette.Active),
                        (QtGui.QIcon.Active, QtGui.QPalette.Active),
                        (QtGui.QIcon.Disabled, QtGui.QPalette.Disabled)):
        pixmap = QtGui.QPixmap(48, 48)
        pixmap.setDevicePixelRatio(2)
        pixmap.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtGui.QPen(palette.color(group, QtGui.QPalette.ButtonText), 1.8,
                                 QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
        path = QtGui.QPainterPath()
        if action == 'round_trip':
            circle = QtCore.QRectF(4, 4, 16, 16)
            path.arcMoveTo(circle, 0)
            path.arcTo(circle, 0, -315)
            path.moveTo(12.5, 6.5)
            path.lineTo(17.5, 6.5)
            path.lineTo(17.5, 1.5)
        else:
            if action == 'parse':
                painter.translate(24, 0)
                painter.scale(-1, 1)
            path.moveTo(4, 12)
            path.lineTo(20, 12)
            path.moveTo(14, 6)
            path.lineTo(20, 12)
            path.lineTo(14, 18)
        painter.drawPath(path)
        painter.end()
        icon.addPixmap(pixmap, mode)
    return icon


def _append(collection, value):
    collection.append(value)
    return value["uid"]


def _unique_name(data, base):
    used = {item.get("name") for key in ("enums", "structures", "groups", "messages") for item in data.get(key, [])}
    name, index = base, 1
    while name in used:
        index += 1
        name = f"{base}{index}"
    return name


def _sync_linked_message_name(data, old_structure, new_structure):
    old_message_name = old_structure.get("name", "") + "Msg"
    requested_name = new_structure.get("name", "") + "Msg"
    old_field_name = re.sub(r"(?<!^)(?=[A-Z])", "_", old_structure.get("name", "")).lower()
    new_field_name = re.sub(r"(?<!^)(?=[A-Z])", "_", new_structure.get("name", "")).lower()
    for message in data.get("messages", []):
        if message.get("generated_from_struct_uid") != new_structure.get("uid"):
            continue
        if message.get("name") == old_message_name:
            used = {
                item.get("name")
                for category in ("enums", "structures", "messages")
                for item in data.get(category, [])
                if item.get("uid") != message.get("uid")
            }
            name, index = requested_name, 1
            while name in used:
                index += 1; name = f"{requested_name}{index}"
            message["name"] = name
            sync_message_names(message)
        field = next((
            item for item in message.get("fields", [])
            if item.get("uid") == message.get("generated_struct_field_uid")
        ), None)
        if field and field.get("name") == old_field_name:
            field["name"] = new_field_name


def _find_in_data(data, uid):
    if data.get("library", {}).get("uid") == uid:
        return data["library"]
    collection, index = _find_collection(data, uid)
    return collection[index] if collection is not None else None


def _find_collection(data, uid):
    for key in ("enums", "structures", "groups", "messages"):
        collection = data.get(key, [])
        for index, item in enumerate(collection):
            if item.get("uid") == uid:
                return collection, index
            for nested_key in ("fields", "runtime_attributes", "constants", "methods"):
                result = _find_nested_collection(item.get(nested_key, []), uid)
                if result[0] is not None:
                    return result
    return None, -1


def _message_group_uid(data, message):
    groups = data.get("groups", [])
    return message.get("group_uid") or data["library"]["uid"]


def _selected_group_uid_from_data(data, uid):
    group = next((item for item in data.get("groups", []) if item.get("uid") == uid), None)
    if group:
        return group.get("uid", "")
    message = next((item for item in data.get("messages", []) if item.get("uid") == uid), None)
    return _message_group_uid(data, message) if message else ""


def _find_nested_collection(collection, uid):
    for index, item in enumerate(collection):
        if item.get("uid") == uid:
            return collection, index
        if isinstance(item.get("item"), dict):
            result = _find_nested_collection([item["item"]], uid)
            if result[0] is not None:
                return result
        result = _find_nested_collection(item.get("fields", []), uid)
        if result[0] is not None:
            return result
        for case in item.get("cases", []):
            if isinstance(case.get("item"), dict):
                result = _find_nested_collection([case["item"]], uid)
                if result[0] is not None:
                    return result
    return None, -1


def _refresh_ids(value):
    if isinstance(value, dict):
        if "uid" in value:
            value["uid"] = new_id()
        for item in value.values():
            _refresh_ids(item)
    elif isinstance(value, list):
        for item in value:
            _refresh_ids(item)



def _child_uids(parent):
    if parent is None:
        return []
    values = []
    for index in range(parent.childCount()):
        info = parent.child(index).data(0, QtCore.Qt.UserRole) or {}
        if info.get("uid"):
            values.append(info["uid"])
    return values
