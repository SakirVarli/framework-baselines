from __future__ import annotations

import ast
import json
from typing import Any

from .object_defaults import array_item_owner


_TAG = "__binary_message_type__"


class SandboxValueError(ValueError):
    """Raised when sandbox values cannot be converted safely."""


def parse_json_values(text: str) -> dict[str, Any]:
    try:
        value = json.loads(
            text or "{}",
            parse_constant=lambda token: (_ for _ in ()).throw(
                ValueError(f"Use a tagged JSON value instead of {token}")
            ),
        )
    except (json.JSONDecodeError, ValueError) as error:
        raise SandboxValueError(f"Invalid JSON: {error}") from error
    if not isinstance(value, dict):
        raise SandboxValueError("The top-level JSON value must be an object.")
    return value


def format_json_values(values: dict[str, Any]) -> str:
    try:
        return json.dumps(values, indent=2, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as error:
        raise SandboxValueError(f"Values cannot be represented as JSON: {error}") from error


def sample_message_values(manifest: dict[str, Any], message_name: str) -> dict[str, Any]:
    """Return the designer's safe starter values in JSON-compatible form."""
    try:
        from .generation import _designer_samples

        sample = _designer_samples(manifest).get(message_name)
        return _to_json_safe(sample) if isinstance(sample, dict) else {}
    except (KeyError, TypeError, ValueError):
        return {}


def parse_object_values(
    text: str,
    manifest: dict[str, Any],
    message_name: str,
) -> dict[str, Any]:
    if not text.strip():
        return {}
    try:
        expression = ast.parse(text, mode="eval").body
    except SyntaxError as error:
        raise SandboxValueError(f"Invalid object initialization: {error.msg}") from error
    if not isinstance(expression, ast.Call) or _node_name(expression.func) != message_name:
        raise SandboxValueError(
            f"Object initialization must start with {message_name}(...)"
        )
    message = _message(manifest, message_name)
    return _parse_constructor(expression, message.get("fields", []), message_name, manifest)


def format_object_values(
    values: dict[str, Any],
    manifest: dict[str, Any],
    message_name: str,
) -> str:
    message = _message(manifest, message_name)
    return _format_constructor(
        message_name,
        values,
        message.get("fields", []),
        message_name,
        manifest,
        0,
    )


def _message(manifest: dict[str, Any], message_name: str) -> dict[str, Any]:
    message = next(
        (item for item in manifest.get("messages", []) if item.get("name") == message_name),
        None,
    )
    if message is None:
        raise SandboxValueError(f"Message class {message_name!r} is not defined.")
    return message


def _parse_constructor(call, fields, owner, manifest):
    if call.args:
        raise SandboxValueError("Use named attributes only; positional arguments are not supported.")
    field_map = {field.get("name"): field for field in fields}
    result: dict[str, Any] = {}
    for keyword in call.keywords:
        if keyword.arg is None:
            raise SandboxValueError("Expanded **attributes are not supported.")
        if keyword.arg in result:
            raise SandboxValueError(f"Attribute {keyword.arg!r} is repeated.")
        result[keyword.arg] = _parse_node(
            keyword.value, field_map.get(keyword.arg), owner, manifest
        )
    return result


def _parse_node(node, field, owner, manifest):
    effective = _effective_field(field)
    kind = effective.get("kind") if effective else None
    if kind == "enum" and isinstance(node, ast.Attribute):
        enum = _enum_for_field(effective, manifest)
        if isinstance(node.value, ast.Name) and node.value.id == enum.get("name"):
            member = next(
                (item for item in enum.get("values", []) if item.get("name") == node.attr),
                None,
            )
            if member is not None:
                return member.get("value")
        raise SandboxValueError("Select a member from the enum used by this field.")
    if kind in {"struct", "inline_struct", "bitfield"}:
        expected_name, nested_fields = _nested_definition(effective, owner, manifest)
        if not isinstance(node, ast.Call) or _node_name(node.func) != expected_name:
            raise SandboxValueError(f"Expected {expected_name}(...) for {effective.get('name')}.")
        return _parse_constructor(node, nested_fields, expected_name, manifest)
    if kind == "array":
        if not isinstance(node, (ast.List, ast.Tuple)):
            raise SandboxValueError(f"Attribute {effective.get('name')} must be a list.")
        return [
            _parse_node(item, effective.get("item"), array_item_owner(owner, effective), manifest)
            for item in node.elts
        ]
    if kind == "conditional" and isinstance(node, ast.Constant) and node.value is None:
        return None
    return _parse_literal(node)


def _parse_literal(node):
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "float"
        and len(node.args) == 1
        and not node.keywords
        and isinstance(node.args[0], ast.Constant)
        and node.args[0].value in {"nan", "inf", "-inf"}
    ):
        return {_TAG: "float", "value": node.args[0].value}
    try:
        value = ast.literal_eval(node)
    except (ValueError, TypeError) as error:
        raise SandboxValueError(
            "Only literals, generated constructors, enum members, and float('nan'/'inf'/'-inf') are supported."
        ) from error
    return _to_json_safe(value)


def _to_json_safe(value):
    if isinstance(value, bytes):
        return {_TAG: "bytes", "hex": value.hex()}
    if isinstance(value, tuple):
        return [_to_json_safe(item) for item in value]
    if isinstance(value, list):
        return [_to_json_safe(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _to_json_safe(item) for key, item in value.items()}
    return value


def _format_constructor(name, values, fields, owner, manifest, level):
    pad = "    " * level
    child_pad = "    " * (level + 1)
    field_map = {field.get("name"): field for field in fields}
    lines = [f"{name}("]
    for key, value in values.items():
        if not isinstance(key, str) or not key.isidentifier():
            raise SandboxValueError(
                f"JSON key {key!r} cannot be represented as a Python attribute name."
            )
        rendered = _format_value(value, field_map.get(key), owner, manifest, level + 1)
        lines.append(f"{child_pad}{key}={rendered},")
    lines.append(f"{pad})")
    return "\n".join(lines)


def _format_value(value, field, owner, manifest, level):
    effective = _effective_field(field)
    kind = effective.get("kind") if effective else None
    if kind == "enum":
        enum = _enum_for_field(effective, manifest)
        member = next(
            (item for item in enum.get("values", []) if item.get("value") == value),
            None,
        )
        if member is not None:
            return f"{enum['name']}.{member['name']}"
    if kind in {"struct", "inline_struct", "bitfield"} and isinstance(value, dict):
        nested_name, nested_fields = _nested_definition(effective, owner, manifest)
        return _format_constructor(
            nested_name, value, nested_fields, nested_name, manifest, level
        )
    if kind == "array" and isinstance(value, list):
        if not value:
            return "[]"
        pad = "    " * level
        child_pad = "    " * (level + 1)
        parts = ["["]
        for item in value:
            rendered = _format_value(
                item, effective.get("item"), array_item_owner(owner, effective), manifest, level + 1
            )
            parts.append(f"{child_pad}{rendered},")
        parts.append(f"{pad}]")
        return "\n".join(parts)
    if isinstance(value, dict) and value.get(_TAG) == "bytes" and set(value) == {_TAG, "hex"}:
        try:
            return repr(bytes.fromhex(value["hex"]))
        except (TypeError, ValueError):
            pass
    if isinstance(value, dict) and value.get(_TAG) == "float" and set(value) == {_TAG, "value"}:
        return f"float({value['value']!r})"
    return repr(value)


def _effective_field(field):
    current = field
    while isinstance(current, dict) and current.get("kind") in {
        "conditional", "const", "default", "aligned", "rebuild", "checksum", "length",
    }:
        current = current.get("item")
    return current if isinstance(current, dict) else None


def _enum_for_field(field, manifest):
    return next(
        (item for item in manifest.get("enums", []) if item.get("uid") == field.get("enum_uid")),
        {},
    )


def _nested_definition(field, owner, manifest):
    kind = field.get("kind")
    if kind == "struct":
        structure = next(
            (item for item in manifest.get("structures", []) if item.get("uid") == field.get("struct_uid")),
            {},
        )
        return structure.get("name", "UnknownStruct"), structure.get("fields", [])
    suffix = "Bits" if kind == "bitfield" else "Struct"
    name = owner + "".join(part.capitalize() for part in field.get("name", "value").split("_")) + suffix
    fields = field.get("fields", [])
    if kind == "bitfield":
        fields = [
            item if item.get('kind') == 'enum' else {"name": item.get("name"), "kind": "bool" if item.get("kind") == "flag" else "uint"}
            for item in field.get("members", []) if item.get("kind") != "padding"
        ]
    return name, fields


def _node_name(node):
    return node.id if isinstance(node, ast.Name) else None
