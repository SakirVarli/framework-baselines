"""Dependency-free lexical retrieval over redacted, bounded evidence chunks."""
from collections import Counter, defaultdict
import math
import re
import unicodedata
from functools import lru_cache


ALIASES = {
    "dugme": "button callback", "buton": "button callback", "tablo": "table display output",
    "grafik": "plot", "yenile": "reload", "kuresel": "globals", "baglanti": "connection session",
    "spreadsheet": "excel workbook", "button": "callback", "table": "display output",
}
STOP = set("a an the how do does i we is are of for to in on with and or my this that can when what which it its from use using me please bir nasil icin ve bu".split())


def normalize(text):
    text = re.sub(r"([a-z\d])([A-Z])", r"\1 \2", str(text))
    text = unicodedata.normalize("NFKD", text.casefold().replace("ı", "i"))
    return "".join(c for c in text if not unicodedata.combining(c))


def tokens(text):
    text = str(text)
    return list(_tokens(text) if len(text) <= 4096 else _tokens.__wrapped__(text))


@lru_cache(maxsize=2048)
def _tokens(text):
    # Pure text processing, never permission, task state or retrieval clearance.
    return tuple(t for t in re.findall(r"[^\W_]+", normalize(text), re.UNICODE) if t not in STOP)


class LexicalIndex:
    def __init__(self, records, base=None):
        self.records = records
        self.postings = defaultdict(list, {k: list(v) for k, v in base.postings.items()} if base else {})
        self.lengths = list(base.lengths) if base else []
        offset = len(base.records) if base else 0
        for i, record in enumerate(records[offset:], offset):
            counts = Counter(tokens(record.get("text", "")))
            for field, weight in (("name", 5), ("qualified_name", 3), ("title", 6),
                                  ("path", 1), ("signature", 2), ("summary", 2)):
                for term, count in Counter(tokens(record.get(field, ""))).items():
                    counts[term] += weight * count
            self.lengths.append(sum(counts.values()))
            for term, count in counts.items():
                self.postings[term].append((i, count))
        self.average = sum(self.lengths) / max(1, len(records))

    def search(self, query, limit=20):
        query_tokens = tokens(str(query)[:2000])
        terms = set(query_tokens)
        query_phrase = " " + " ".join(query_tokens) + " "
        expanded = terms | {t for term in terms for t in tokens(ALIASES.get(term, ""))}
        scores = defaultdict(float)
        total = len(self.records)
        for term in expanded:
            postings = self.postings.get(term, ())
            idf = math.log(1 + (total - len(postings) + .5) / (len(postings) + .5))
            for i, frequency in postings:
                denominator = frequency + 1.2 * (.25 + .75 * self.lengths[i] / max(1, self.average))
                scores[i] += idf * frequency * 2.2 / denominator * (1 if term in terms else .35)
        exact = str(query).strip().casefold()
        for i in scores:
            record = self.records[i]
            if exact and exact in {str(record.get(k, "")).casefold() for k in ("qualified_name", "name", "section_id")}:
                scores[i] += 100
            # Procedures have explicit titles; reward matching the whole requested topic.
            title_tokens = tokens(record.get("title", ""))
            title_terms = set(title_tokens)
            if title_terms:
                scores[i] += 4 * len(terms & title_terms) / max(1, len(terms))
            if record.get("source_kind") == "handbook":
                if len(title_tokens) > 1 and " " + " ".join(title_tokens) + " " in query_phrase:
                    scores[i] += 12
                scores[i] *= 1.15
            elif record.get("source_kind") == "test":
                scores[i] *= .55
        results, seen = [], set()
        for i in sorted(scores, key=lambda n: (-scores[n], self.records[n].get("id", ""))):
            record = self.records[i]
            key = record.get("definition_id", record.get("id"))
            if key in seen:
                continue
            seen.add(key)
            item = {k: v for k, v in record.items() if k != "text"}
            text = record.get("text", "")
            # Show the relevant passage, including hits far into a long chunk.
            lines = text.splitlines()
            match = next((j for j, line in enumerate(lines) if set(tokens(line)) & terms), 0)
            item["excerpt"] = "\n".join(lines[max(0, match-2):match+12])[:1400]
            item["excerpt_truncated"] = len(item["excerpt"]) < len(text)
            item["score"] = round(scores[i], 3)
            results.append(item)
            if len(results) >= max(1, min(40, int(limit))):
                break
        return results
