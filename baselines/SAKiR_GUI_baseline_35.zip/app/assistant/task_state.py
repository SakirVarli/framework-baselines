"""Versioned semantic tasks and clarification records. No natural-language routing."""
import copy
import uuid

from .policy import AssistantError, digest, redact


WORK = ('explain', 'prepare_changes', 'prepare_action')
RELATIONS = ('new', 'resume', 'amend', 'cancel')
REASONS = ('missing_input', 'ambiguous_target', 'consequential_choice',
           'conflicting_requirements', 'scope', 'explanation_preference')
PROCESS_CHECKS = ('not_applied', 'answer_before_changes')


def text(value, limit=2000):
    if not isinstance(value,str) or not value.strip() or len(value)>limit:
        raise AssistantError('TASK_PROTOCOL','Expected nonempty text within the permitted length.')
    return value.strip()


class TaskLedger:
    """Only host methods can set status, answers, receipts, or artifact pointers."""
    def __init__(self, data=None):
        self.data = {'version':2,'active_task_id':None,'tasks':[], 'event_sequence': 0}
        self.turn = None
        if data is not None:
            self._load(data)

    def _load(self, data):
        if not isinstance(data,dict) or type(data.get('version')) is not int or data.get('version') not in {1,2}:
            raise AssistantError('TASK_VERSION','Unsupported saved task protocol. Saved data was retained.')
        tasks=data.get('tasks',[])
        if not isinstance(tasks,list) or len(tasks)>20:
            raise AssistantError('TASK_PROTOCOL','Invalid saved task records.')
        allowed={'id','revision','summary','work','domains','requirements','constraints','delegated_choices',
                 'status','source_message_id','source_text','questions','receipts','drafts','artifact_id',
                 'snapshot_revision','last_failure','versions','completion','operation_requirements','intent_status','requirement_epochs','requirement_first_mutations'}
        clean=[]
        for task in tasks:
            if not isinstance(task,dict) or set(task)-allowed:
                raise AssistantError('TASK_PROTOCOL','Invalid saved task fields.')
            if not isinstance(task.get('id'),str) or type(task.get('revision')) is not int or task['revision']<1:
                raise AssistantError('TASK_PROTOCOL','Invalid saved task identity.')
            if not isinstance(task.get('questions'),list) or len(task['questions'])>20:
                raise AssistantError('TASK_PROTOCOL','Invalid saved questions.')
            if not isinstance(task.get('requirements'),list) or len(task['requirements'])>20:
                raise AssistantError('TASK_PROTOCOL','Invalid saved requirements.')
            if not isinstance(task.get('work'),list) or not task['work'] or any(not isinstance(v,str) or v not in WORK for v in task['work']):
                raise AssistantError('TASK_PROTOCOL','Invalid saved task work.')
            try:
                for key in ('summary','source_message_id','source_text','status','snapshot_revision'):
                    if not isinstance(task[key],str):
                        raise ValueError(key)
                for key in ('constraints','delegated_choices','domains','drafts'):
                    if not isinstance(task[key],list) or any(not isinstance(v,str) for v in task[key]):
                        raise ValueError(key)
                operations = task.get('operation_requirements', [])
                fields = {'id','kind','tab_name','button_label','output_instance','callback_name','output_kind'}
                if not isinstance(operations, list) or len(operations) > 20:
                    raise ValueError('operation_requirements')
                for operation in operations:
                    if (not isinstance(operation, dict) or set(operation) != fields or operation['kind'] != 'composite_page'
                            or any(not isinstance(v, str) or not v or len(v)>1000 for v in operation.values())):
                        raise ValueError('operation_requirements')
                if len({operation['id'] for operation in operations}) != len(operations):
                    raise ValueError('operation_requirements')
                requirement_keys=set()
                for requirement in task['requirements']:
                    key=text(requirement['key'],60)
                    text(requirement['text'],2000)
                    if requirement.get('process_check') not in (None, *PROCESS_CHECKS):
                        raise ValueError('process_check')
                    if 'process_source' in requirement:
                        text(requirement['process_source'],2000)
                        if not requirement.get('process_check'):
                            raise ValueError('process_source')
                    if key in requirement_keys:
                        raise ValueError('duplicate requirement')
                    requirement_keys.add(key)
                question_ids=set()
                for q in task['questions']:
                    text(q['id'],80)
                    text(q['question'],1000)
                    if q['id'] in question_ids or q['task_id']!=task['id']:
                        raise ValueError('question identity')
                    question_ids.add(q['id'])
                    if type(q['task_revision']) is not int or not 1<=q['task_revision']<=task['revision']:
                        raise ValueError('question revision')
                    if q['reason'] not in REASONS or q['status'] not in {'pending','answered','superseded','cancelled'}:
                        raise ValueError('question state')
                    if any(type(q[key]) is not bool for key in ('required','allow_delegate')):
                        raise ValueError('question flags')
                    if any(not isinstance(q[key],str) for key in ('impact','created_message_id','snapshot_revision')):
                        raise ValueError('question metadata')
                    if not isinstance(q['options'],list) or len(q['options'])>4:
                        raise ValueError('question choices')
                    option_ids=set()
                    for option in q['options']:
                        identifier=text(option['id'],80)
                        text(option['label'],160)
                        if identifier in option_ids or not isinstance(option.get('description',''),str):
                            raise ValueError('question choice')
                        option_ids.add(identifier)
                    if q['answer'] is not None:
                        answer=q['answer']
                        if answer['kind'] not in {'text','choice','delegated'} or not isinstance(answer['text'],str):
                            raise ValueError('question answer')
                    if q['status']=='answered' and q['answer'] is None:
                        raise ValueError('missing answer')
                if not isinstance(task['receipts'],list) or len(task['receipts'])>30:
                    raise ValueError('receipts')
                for receipt in task['receipts']:
                    if not isinstance(receipt['operation'],str) or not isinstance(receipt['artifact_id'],str) or type(receipt['validated']) is not bool:
                        raise ValueError('receipt')
                if not isinstance(task.get('completion',{}),dict) or not isinstance(task['versions'],list):
                    raise ValueError('completion')
            except (KeyError,TypeError,ValueError) as exc:
                raise AssistantError('TASK_PROTOCOL','Invalid saved task details. Saved data was retained.') from exc
            if len(str(task))>500000:
                raise AssistantError('TASK_PROTOCOL','Saved task exceeds its size limit.')
            clean.append(copy.deepcopy(task))
        if len({t['id'] for t in clean})!=len(clean):
            raise AssistantError('TASK_PROTOCOL','Duplicate saved task identity.')
        active=data.get('active_task_id')
        if active is not None and active not in {t['id'] for t in clean}:
            raise AssistantError('TASK_PROTOCOL','Missing active task.')
        sequences = [0]
        for task in clean:
            status = task.get('intent_status')
            if status is None:
                if data['version'] == 2:
                    raise AssistantError('TASK_PROTOCOL', 'Saved v2 task is missing its intent status.')
                status = ('unresolved' if task['work'] == ['explain'] and any(q['required'] for q in task['questions'])
                          and not task['receipts'] and not task.get('completion', {}).get('applied')
                          and not task.get('completion', {}).get('dispatched') else 'declared')
            if status not in {'declared', 'unresolved'}:
                raise AssistantError('TASK_PROTOCOL', 'Invalid saved intent status.')
            if status == 'unresolved' and task['receipts']:
                raise AssistantError('TASK_PROTOCOL', 'Unresolved saved intent cannot have mutation receipts.')
            task['intent_status'] = status
            epochs = task.get('requirement_epochs', {})
            if not isinstance(epochs, dict) or not set(epochs) <= {r['key'] for r in task['requirements']}:
                raise AssistantError('TASK_PROTOCOL', 'Invalid saved requirement epochs.')
            for epoch in epochs.values():
                if type(epoch) is not int or epoch < 1:
                    raise AssistantError('TASK_PROTOCOL', 'Invalid saved requirement epoch.')
                sequences.append(epoch)
            first_mutations = task.get('requirement_first_mutations', {})
            if not isinstance(first_mutations, dict) or not set(first_mutations) <= set(epochs):
                raise AssistantError('TASK_PROTOCOL', 'Invalid saved first mutations.')
            for key, sequence in first_mutations.items():
                if type(sequence) is not int or sequence < epochs[key]:
                    raise AssistantError('TASK_PROTOCOL', 'Invalid saved first mutation sequence.')
                sequences.append(sequence)
            for item in [*task['receipts'], *task['questions'], *[q['answer'] for q in task['questions'] if q.get('answer')]]:
                for field in ('sequence', 'asked_sequence'):
                    if field in item:
                        if type(item[field]) is not int or item[field] < 1:
                            raise AssistantError('TASK_PROTOCOL', 'Invalid saved event sequence.')
                        sequences.append(item[field])
        sequence = data.get('event_sequence', max(sequences))
        if type(sequence) is not int or sequence < max(sequences):
            raise AssistantError('TASK_PROTOCOL', 'Invalid saved event sequence.')
        self.data={'version':2,'active_task_id':active,'tasks':clean,'event_sequence':sequence}
        for task in clean:
            if task['status'] == 'completed' or (task['status'] == 'ready_for_review' and task.get('completion', {}).get('host_validation')):
                self.recovered(task)

    def export(self):
        return copy.deepcopy(redact(self.data))

    def tick(self):
        self.data['event_sequence'] += 1
        return self.data['event_sequence']

    def find(self, task_id=None):
        task_id=task_id or self.data['active_task_id']
        return next((t for t in self.data['tasks'] if t['id']==task_id),None)

    def begin_turn(self, request, history, snapshot_revision, envelope=None):
        self.turn={'request':request,'message_id':digest([len(history),'user',request]),
                   'snapshot_revision':snapshot_revision,'task_id':None,'selected':False}
        if envelope is not None:
            self.turn['origin'] = envelope.origin
            if envelope.user_message_id:
                self.turn['message_id'] = envelope.user_message_id

    @property
    def selected(self):
        return self.find(self.turn.get('task_id')) if self.turn and self.turn.get('selected') else None

    def update(self, summary, work, relation='new', task_id='', domains=None,
               requirements=None, constraints=None, delegated_choices=None):
        if not self.turn:
            raise AssistantError('TASK_PROTOCOL','No active user turn.')
        summary=text(summary,500)
        if relation not in RELATIONS or not work or not set(work)<=set(WORK):
            raise AssistantError('TASK_PROTOCOL','Invalid task relationship or work type.')
        prior=self.find(task_id) if task_id else self.find()
        if relation == 'resume' and prior and prior.get('intent_status') != 'unresolved' and requirements is not None and requirements != prior['requirements']:
            raise AssistantError('TASK_AMEND_REQUIRED', 'Resume preserves requirements. Use amend only for a user-requested change. Current revision: '+str(prior['revision'])+'. Valid requirement IDs: '+', '.join(r['key'] for r in prior['requirements']))
        if requirements is None:
            requirements=copy.deepcopy(prior['requirements']) if relation!='new' and prior else [{'key':'request','text':self.turn['request'][:2000]}]
        keys=[]
        for requirement in requirements:
            if not isinstance(requirement,dict) or set(requirement)-{'key','text','process_check','process_source'}:
                raise AssistantError('TASK_PROTOCOL','Requirements contain key, text and optional process_check/process_source.')
            if requirement.get('process_check') not in (None, *PROCESS_CHECKS):
                raise AssistantError('TASK_PROTOCOL', 'Unknown process check.')
            # Legacy persisted declarations remain readable. New interpretations
            # must attribute a separate process obligation to the actual request.
            if requirement.get('process_check') and (relation == 'new' or not prior or requirement not in prior['requirements']):
                if not isinstance(requirement.get('process_source'),str) or not requirement['process_source'].strip():
                    raise AssistantError('TASK_PROTOCOL','Process-only requirement '+str(requirement.get('key'))+' needs process_source quoting the user instruction. Keep content claims separate without process_check.')
                source = text(requirement.get('process_source'),2000)
                if source not in self.turn['request'] and source not in (prior or {}).get('source_text',''):
                    raise AssistantError('TASK_PROTOCOL','process_source must quote the original or current user request. Keep content requirements separate and omit process_check for them.')
            elif requirement.get('process_source') and not requirement.get('process_check'):
                raise AssistantError('TASK_PROTOCOL','process_source requires a separate process_check obligation.')
            key=text(requirement.get('key'),60)
            text(requirement.get('text'),2000)
            if key in keys:
                raise AssistantError('TASK_PROTOCOL','Requirement keys must be unique.')
            keys.append(key)
        if len(requirements)>20 or len(constraints or [])>20 or len(delegated_choices or [])>20:
            raise AssistantError('TASK_PROTOCOL','Too many task requirements or choices.')
        for value in [*(constraints or []),*(delegated_choices or [])]:
            text(value,1000)
        current=self.selected
        target=self.find(task_id) if task_id else self.find()
        if current and (relation=='new' or target is not current):
            # Repeated task declarations in one response cannot create tasks or
            # escape a blocking question established earlier in that turn.
            if relation=='new' and summary==current['summary'] and work==current['work']:
                return current
            raise AssistantError('TASK_ALREADY_SELECTED','This turn already has a task. Use a later user turn to switch tasks.')
        if relation=='new':
            task={'id':uuid.uuid4().hex,'revision':1,'summary':summary,'work':list(work),'domains':list(domains or []),
                  'requirements':copy.deepcopy(requirements),'constraints':list(constraints or []),
                  'delegated_choices':list(delegated_choices or []),'status':'interpreting',
                  'source_message_id':self.turn['message_id'],'source_text':self.turn['request'][:12000], 'intent_status':'declared',
                  'questions':[],'receipts':[],'drafts':[],'artifact_id':None,
                  'snapshot_revision':self.turn['snapshot_revision'],'last_failure':None,'versions':[], 'operation_requirements':[]}
            epoch = self.tick()
            task['requirement_epochs'] = {r['key']:epoch for r in requirements}
            task['requirement_first_mutations'] = {}
            if len(self.data['tasks'])>=20:
                removable=next((t for t in self.data['tasks'] if t['status'] in {'completed','cancelled'} and not t['artifact_id']),None)
                if removable is None:
                    raise AssistantError('TASK_LIMIT','There are 20 retained tasks. Start another conversation; no drafts were discarded.')
                self.data['tasks'].remove(removable)
            self.data['tasks'].append(task)
        else:
            if target is None:
                raise AssistantError('TASK_NOT_FOUND','Choose an existing task ID from task context.')
            task=target
            if task.get('intent_status') == 'unresolved' and relation in {'resume', 'amend'}:
                if task['receipts']:
                    raise AssistantError('TASK_PROTOCOL', 'Unresolved intent cannot have mutation receipts.')
                if relation == 'resume':
                    old_keys = {r['key'] for r in task['requirements']}
                    old_epochs = task.get('requirement_epochs', {})
                    epoch = min(old_epochs.values()) if old_epochs else self.tick()
                    task['requirements'] = copy.deepcopy(requirements)
                    task['requirement_epochs'] = {r['key']:old_epochs.get(r['key'],epoch) for r in requirements}
                    task['requirement_first_mutations'] = {}
                    task['summary'] = summary
                    task['constraints'] = list(task['constraints'] if constraints is None else constraints)
                    task['delegated_choices'] = list(task['delegated_choices'] if delegated_choices is None else delegated_choices)
                    task['revision'] += 1
                    for question in task['questions']:
                        # The original unclassified question belonged to the whole
                        # retained request. Refining its structure must not discard the answer.
                        if set(question.get('requirement_keys', [])) <= old_keys:
                            question['requirement_keys'] = [r['key'] for r in requirements]
                        if question['status'] == 'pending':
                            question['task_revision'] = task['revision']
                task['work'] = list(work)
                task['intent_status'] = 'declared'
            if relation=='amend':
                old_requirements={r['key']:r['text'] for r in task['requirements']}
                # Preserve identity when the model restates an unchanged requirement
                # under a new key. No fuzzy matching of requirement meaning.
                requirements=copy.deepcopy(requirements)
                for requirement in requirements:
                    same=[key for key,value in old_requirements.items() if value==requirement['text']]
                    if requirement['key'] not in old_requirements and len(same)==1 and same[0] not in keys:
                        requirement['key']=same[0]
                if len({r['key'] for r in requirements}) != len(requirements):
                    raise AssistantError('TASK_PROTOCOL', 'Amendment contains duplicate requirement identities.')
                new_requirements={r['key']:r['text'] for r in requirements}
                changed={key for key in old_requirements.keys()|new_requirements.keys() if old_requirements.get(key)!=new_requirements.get(key)}
                previous_checks = {r['key']: r.get('process_check') for r in task['requirements']}
                retained_process = {r['key'] for r in requirements if r.get('process_check')
                                    and previous_checks.get(r['key']) == r['process_check']}
                changed |= {r['key'] for r in requirements if previous_checks.get(r['key']) != r.get('process_check')}
                if constraints is not None and list(constraints)!=task['constraints']:
                    changed |= set(old_requirements)
                if changed and any(q['required'] and q['status']=='pending' and q['created_message_id']==self.turn['message_id'] for q in task['questions']):
                    raise AssistantError('USER_ANSWER_REQUIRED','A required decision cannot be bypassed by rewriting requirements in the same user turn.')
                changed_work=list(work)!=task['work']
                changed_delegation=delegated_choices is not None and list(delegated_choices)!=task['delegated_choices']
                task['versions']=[*task['versions'][-4:],{k:copy.deepcopy(task.get(k)) for k in ('revision','summary','requirements','constraints','delegated_choices','artifact_id','completion','requirement_epochs','requirement_first_mutations')}]
                task['versions'][-1]['requirement_changes']={'retained':sorted((old_requirements.keys() & new_requirements.keys()) - changed),
                    'changed':sorted(old_requirements.keys() & new_requirements.keys() & changed),
                    'removed':sorted(old_requirements.keys()-new_requirements.keys()), 'added':sorted(new_requirements.keys()-old_requirements.keys())}
                task.update(summary=summary,work=list(work),domains=list(domains or task['domains']),
                            requirements=copy.deepcopy(requirements),constraints=list(task['constraints'] if constraints is None else constraints),
                            delegated_choices=list(task['delegated_choices'] if delegated_choices is None else delegated_choices),revision=task['revision']+1)
                epochs = task.setdefault('requirement_epochs', {})
                for key in list(epochs):
                    if key not in new_requirements:
                        epochs.pop(key)
                for key in new_requirements:
                    if (key in changed and key not in retained_process) or key not in epochs:
                        epochs[key] = self.tick()
                first_mutations = task.setdefault('requirement_first_mutations', {})
                for key in list(first_mutations):
                    if (key in changed and key not in retained_process) or key not in new_requirements:
                        first_mutations.pop(key)
                if changed or changed_work or changed_delegation:
                    task['completion']={}
                    task['operation_requirements']=[]
                for q in task['questions']:
                    affected=set(q.get('requirement_keys',old_requirements)) & (changed - retained_process)
                    if affected and q['status'] in {'pending','answered'}:
                        q['status']='superseded'
                    elif q['status']=='pending':
                        q['task_revision']=task['revision']
            if relation=='cancel':
                task['status']='cancelled'
                task['revision']+=1
                for q in task['questions']:
                    if q['status']=='pending':
                        q['status']='cancelled'
            if relation=='resume' and domains:
                task['domains']=list(dict.fromkeys([*task['domains'],*domains]))
        self.turn.update(task_id=task['id'],selected=True)
        self.data['active_task_id']=task['id']
        if relation!='cancel' and task['status'] not in {'awaiting_clarification','awaiting_mode_change'}:
            task['status']='gathering_evidence'
        return task

    def ensure_task(self, work='explain'):
        return self.selected or self.update(self.turn['request'][:500],[work])

    def recovered(self, task=None):
        task = task or self.selected
        if task and task.get('last_failure'):
            completion = task.setdefault('completion', {})
            completion['failure_history'] = [*completion.get('failure_history', [])[-4:],
                                             {**task['last_failure'], 'recovered': True}]
            task['last_failure'] = None

    def pending(self, task=None, required_only=False):
        task=task or self.selected
        return [q for q in (task or {}).get('questions',[]) if q['status']=='pending' and (not required_only or q['required'])]

    def ask(self, question, reason='missing_input', options=None, required=True, impact='', allow_delegate=False, decision_key='', requirement_keys=None):
        undeclared = self.selected is None
        task=self.ensure_task()
        if undeclared and reason != 'explanation_preference':
            task['intent_status'] = 'unresolved'
        question=text(question,1000)
        if reason not in REASONS:
            raise AssistantError('TASK_PROTOCOL','Unknown clarification reason.')
        if reason=='explanation_preference':
            required=False
        options=copy.deepcopy(options or [])
        if len(options)>4:
            raise AssistantError('TASK_PROTOCOL','Use at most four concise choices and free text.')
        ids=[]
        for option in options:
            if not isinstance(option,dict) or set(option)-{'id','label','description'}:
                raise AssistantError('TASK_PROTOCOL','Choices contain id, label and optional description.')
            identifier=text(option.get('id'),80)
            text(option.get('label'),160)
            if identifier in ids:
                raise AssistantError('TASK_PROTOCOL','Choice IDs must be unique.')
            ids.append(identifier)
        if decision_key:
            decision_key=text(decision_key,80)
            if required and decision_key in task['delegated_choices']:
                raise AssistantError('DECISION_DELEGATED', 'The user delegated this recorded decision. Choose a suitable value and continue; do not ask a blocking question for '+decision_key+'.')
        requirement_keys=requirement_keys if requirement_keys is not None else [r['key'] for r in task['requirements']]
        if not set(requirement_keys)<={r['key'] for r in task['requirements']}:
            raise AssistantError('TASK_PROTOCOL','A question references an unknown requirement.')
        old=next((q for q in task['questions'] if (q['question']==question or decision_key and q.get('decision_key')==decision_key) and q['status'] in {'pending','answered'}),None)
        if old:
            return old
        if len(self.pending(task))>=3:
            raise AssistantError('QUESTION_LIMIT','At most three pending questions per task; answer or supersede them before asking more.')
        if len(task['questions'])>=20:
            raise AssistantError('QUESTION_LIMIT','This task already retains 20 questions. Its answers were preserved; use a new related task rather than dropping them.')
        q={'id':uuid.uuid4().hex,'task_id':task['id'],'task_revision':task['revision'],
           'question':question,'reason':reason,'options':options,'required':bool(required),'impact':text(impact,1000) if impact else '',
           'allow_delegate':bool(allow_delegate),'status':'pending','answer':None,
           'created_message_id':self.turn['message_id'],'snapshot_revision':self.turn['snapshot_revision'],
           'decision_key':decision_key,'requirement_keys':list(requirement_keys), 'asked_sequence':self.tick()}
        task['questions'].append(q)
        if required:
            task['status']='awaiting_clarification'
        return q

    def answer(self, task_id, question_id, revision, value='', option_id='', delegate=False, snapshot_revision=None, message_id=None):
        task=self.find(task_id)
        q=next((q for q in (task or {}).get('questions',[]) if q['id']==question_id),None)
        if not task or not q or q['status']!='pending' or revision!=task['revision'] or q['task_revision']!=revision:
            raise AssistantError('STALE_QUESTION','This question or task changed. Refresh its card before answering.')
        if q['reason']=='ambiguous_target' and snapshot_revision and q['snapshot_revision']!=snapshot_revision:
            raise AssistantError('STALE_QUESTION','The project changed; re-evaluate these target choices before answering.')
        if message_id and message_id==q['created_message_id']:
            raise AssistantError('USER_ANSWER_REQUIRED','A question cannot be answered by the model in the turn that asked it.')
        if delegate:
            if not q['allow_delegate']:
                raise AssistantError('INVALID_ANSWER','This question does not allow delegation.')
            if option_id or value:
                raise AssistantError('INVALID_ANSWER','Delegation is separate from a choice or text answer.')
            answer={'kind':'delegated','text':'The user delegated this choice.'}
        elif option_id:
            option=next((o for o in q['options'] if o['id']==option_id),None)
            if option is None or value:
                raise AssistantError('INVALID_ANSWER','Choose a current option or supply free text, not both.')
            answer={'kind':'choice','option_id':option_id,'text':option['label']}
        else:
            answer={'kind':'text','text':text(value,2000)}
        q.update(status='answered',answer={**answer,'message_id':message_id,'sequence':self.tick()})
        task['revision']+=1
        for pending in self.pending(task):
            pending['task_revision']=task['revision']
        task['status']='awaiting_clarification' if self.pending(task,True) else 'gathering_evidence'
        return q

    def answer_from_turn(self, question_id, task_id=''):
        task=self.find(task_id) if task_id else self.selected or self.find()
        if task is None:
            raise AssistantError('TASK_NOT_FOUND','Choose the task containing this question.')
        if self.selected and self.selected['id']!=task['id']:
            raise AssistantError('TASK_ALREADY_SELECTED','This turn already selected a different task; do not bind its message to this question.')
        result=self.answer(task['id'],question_id,task['revision'],value=self.turn['request'],
                           snapshot_revision=self.turn['snapshot_revision'],message_id=self.turn['message_id'])
        self.turn.update(task_id=task['id'],selected=True)
        self.data['active_task_id']=task['id']
        return result

    def blocked(self, kind, message):
        task=self.ensure_task('prepare_changes' if kind=='mode' else 'explain')
        task['status']='awaiting_mode_change' if kind=='mode' else 'incomplete'
        task['last_failure']={'kind':kind,'message':message[:1000]}

    def receipt(self, operation, artifact_id, validated, requirement_ids=None, operation_key=None):
        task=self.selected
        if not task:
            return
        if task['artifact_id'] and task['artifact_id']!=artifact_id:
            task['drafts']=[*task['drafts'][-9:],task['artifact_id']]
        task['artifact_id']=artifact_id
        task['snapshot_revision']=self.turn['snapshot_revision']
        task['status']='ready_for_review' if validated else 'incomplete'
        sequence = self.tick()
        for key, epoch in task.get('requirement_epochs', {}).items():
            if sequence >= epoch:
                task.setdefault('requirement_first_mutations', {}).setdefault(key, sequence)
        task['receipts']=[*task['receipts'][-29:],{'operation':operation,'artifact_id':artifact_id,
            'validated':bool(validated),'requirement_ids':list(requirement_ids or []),'operation_key':operation_key,
            'task_revision':task['revision'],'sequence':sequence}]

    def projection(self):
        active=self.find()
        projected=None
        if active:
            projected={k:copy.deepcopy(active[k]) for k in ('id','revision','summary','work','domains','requirements','constraints','delegated_choices','status','artifact_id','snapshot_revision','last_failure')}
            projected['questions']=[copy.deepcopy(q) for q in active['questions'] if q['status']=='pending']+[
                copy.deepcopy(q) for q in active['questions'] if q['status']=='answered'][-8:]
            projected['receipts']=copy.deepcopy(active['receipts'][-8:])
            projected['original_user_request']=active['source_text'][:2000]
            projected['intent_status'] = active.get('intent_status', 'declared')
            projected['original_request_truncated']=len(active['source_text'])>2000
            projected['completion']=copy.deepcopy(active.get('completion',{}))
            projected['operation_requirements']=copy.deepcopy(active.get('operation_requirements',[]))
        return {'version':1,'active_task':projected,
                'other_tasks':[{'id':t['id'],'summary':t['summary'],'status':t['status']} for t in self.data['tasks'] if t is not active],
                'current_message_id':(self.turn or {}).get('message_id'),
                'selected_task_id':(self.selected or {}).get('id')}
