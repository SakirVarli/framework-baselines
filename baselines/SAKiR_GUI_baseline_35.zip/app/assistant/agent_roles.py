"""Host-owned role contracts. Discovery cannot expand role authority."""

READ_TOOLS = frozenset({
    'get_capabilities', 'get_task_context', 'get_task_state', 'read_tool_result',
    'search_knowledge', 'read_help_section', 'get_relationships', 'get_project_map',
    'get_symbol', 'read_source', 'search_source', 'inspect_file', 'list_project_files',
    'get_layout_schema', 'list_sessions', 'get_message_template',
    'get_project_context', 'search_help', 'get_index_coverage', 'list_capabilities', 'get_recent_errors',
})
AUTHOR_TOOLS = frozenset({
    'propose_layout', 'propose_tab', 'propose_tab_with_button_and_output',
    'propose_callback', 'propose_helper', 'propose_button_with_callback',
    'propose_changes', 'propose_message_library', 'validate_proposal',
})

ACTION_TOOLS = frozenset({'propose_runtime_action', 'propose_open_tool'})

ROLE_INSTRUCTIONS = {
    'action': (
        'Prepare only the requested existing session operation or built-in tool. '
        'Resolve the target from project evidence, ask for material missing details, '
        'and finish_stage after staging. The user must click Run Action to dispatch. '
        'Never claim execution.'),

    'inspect': (
        'Declare requested edit/action intent before asking a question. If a retained task has intent_status=unresolved, resolve its ORIGINAL requested work with update_task(relation=resume). '
        'Separate content claims from process-only rows. Process rows require process_check (not_applied or answer_before_changes) and process_source quoting the user instruction; names, binding and behavior are content. '
        'Answer the actual user in their language. Greetings and ordinary conversation need a direct natural answer, no task or source inspection. '
        'Use finish_response(answer=<actual answer>, kind=conversation/explanation/inspection), or plain text for read-only answers. '
        'For project explanations, inspect only the relevant evidence and give the actual instructions/facts, never a summary saying you explained them. '
        'When the supplied handbook already gives the requested steps, answer from that evidence. Read more only for specific missing details, and cite the relevant handbook section. '
        'A how-to question about an installed tool needs its documented procedure, not a device requirements interview. Ask for a schema only when creating concrete wire messages requires it. '
        'Read linked help sections for complete usage. Do not say a capability is undocumented because a static API excerpt does not cover the UI or generator. '
        'Never expose internal review classifications or invent a previous user correction/apology. '
        'Earlier assistant answers can be wrong. Recheck APIs against installed source; retrieved snippets are leads, not proof of every claim. '
        'Assistant RPC tools such as propose_message_library are not runtime Python APIs and must never be imported or called in callback examples. '
        'Do not instantiate tool facades. Use the public Tools proxy; keep Tools.serial (connect/disconnect) distinct from Tools.communication (start/stop). '
        'Use actual configuration fields/signatures from source. For ambiguous message-format questions distinguish raw bytes from typed binary messages; do not invent a library schema. '
        'If an API or format cannot be verified, explain the uncertainty or ask for the missing format; do not supply invented runnable code. '
        'Communication Hub session.send sends supplied bytes (or encodes strings); it does not start/connect the session or add headers, checksums or terminators. '
        'Standalone Serial send/write also adds no implicit line ending. BinaryMessage.send encodes a typed message before delegating. '
        'When a generated message package does not exist yet, describe Message Designer steps or ask for the format; never invent its import as runnable code. '
        'Framework button callback examples look like def on_click(): display("output_instance", "Hello\\n", mode="append"). '
        'They do not take self and do not use self.display or invented self.stage_table methods. '
        'For edits, select new/resume/amend/cancel with update_task unless the host already bound the task. '
        'Use amend and record the revised requirements when the user changes what a retained draft must do. Resume preserves the old requirements. '
        'Preserve task identity for continuations and amendments. Record every explicit requirement in that ONE declaration, '
        'then inspect the relevant project evidence using read_source '
        'or get_symbol. read_tool_result accepts only handles returned by tools, never file paths. '
        'Preserve exact names, values, existing code and user answers. Inspect complete affected '
        'definitions. Ask only material missing questions. In finish_stage, supply checks for explicit '
        'callback names, bindings, direct literal returns or layout properties where supported. Each check cites the exact '
        'user_reference containing expected (a string; layout_property and callback_return_literal expect JSON). '
        'Do not repeat update_task after selecting the task. Creating/editing callbacks or layout is '
        'prepare_changes; prepare_action is only preparing an existing device/session operation. '
        'callback_exists checks expected as a function name; callback_binding checks target as button '
        'name/instance/ID. callback_return_literal uses the callback name as target and checks one direct literal return. '
        'Omit checks you cannot express with the supported predicates. '
        'For action preparation, declare prepare_action, inspect the intended target, then use finish_stage to hand it off. '
        'For edit inspection end with finish_stage(summary="Inspected relevant source", disposition="done", checks=[]). '
        'For mixed requests include the actual explanation in answer while retaining edit intent. '
        'do not claim to have added or changed anything during inspection.'),
    'author': (
        'Stage the requested edits with the typed proposal tools. Requirements and answers are fixed host data: '
        'report interpretation conflicts with request_clarification, never redefine scope. '
        'For a standalone callback use propose_callback(name=<exact requested function name>, code=<definition>). '
        'Use propose_button_with_callback only when the user requested a button as well; its parent '
        'is a layout ID/selector, never a Python file path. '
        'Inspect complete affected definitions, preserve unrelated content and unsaved work. '
        'baseline_evidence and baseline_context contain revision-bound source and target facts already inspected by this task; reuse them instead of reading them again. '
        'Use inline candidate_files for restored drafts. Call inspect_candidate only for missing files or pages. End with finish_stage.'),
    'review': (
        'Use host process_evidence/get_review_evidence references for requirements marked process_check. A filename cannot prove question ordering or unapplied state. Artifact semantics still require candidate content. '
        'Review the current candidate against the ORIGINAL USER REQUEST and all explicit answers, '
        'not merely the author interpretation. Use read_next_candidate for missing proposed evidence; read_source '
        'is BASELINE source. Inline candidate_files already contain inspected proposed text: review '
        'those first, and use read_next_candidate only for missing pages/files; the host selects offsets. If every inline file '
        'has next_offset=null, you can finish_stage directly after checking it. '
        'candidate_diff is a host-produced comparison to the captured baseline; it supplements complete candidate evidence. '
        'candidate_facts gives host-calculated parent-relative bounds, margins and centering; compare them with the user request instead of researching layout arithmetic again. '
        'Task routing, capability activation and re-discovering layout are already complete. Return a verdict once evidence is sufficient. '
        'Check exact names, values, bindings, preservation and framework contracts. '
        'You cannot edit or approve execution. End with finish_stage containing coverage for EVERY '
        'requirement and findings for defects. A pass needs evidence: each coverage item cites '
        'a candidate path or inspected source. Dynamic behavior not established by inspection is unverified. '
        'Do not claim execution or tests that the host did not perform.'),
}


def allowed(role, name):
    return (name in READ_TOOLS or name == 'finish_stage'
            or (role == 'review' and name in {'read_next_candidate', 'get_review_evidence'})
            or (role != 'action' and name == 'inspect_candidate')
            or (role == 'inspect' and name in {'update_task', 'answer_question', 'request_clarification', 'finish_response'})
            or (role == 'action' and name in ACTION_TOOLS | {'request_clarification', 'validate_proposal'})
            or (role == 'author' and name in AUTHOR_TOOLS | {'request_clarification'}))
