"""Independent benchmark fixtures and assertions; never model context."""
import ast
import copy
import json
import re
import struct
from app.assistant.policy import digest, file_hash
from app.assistant.task_context import layout_rows
from app.assistant.workflow_protocol import completion_checks
from app.starter_project import starter_project_files
from .behavior_probe import greeting_probe


def adjudicate_greeting(tools):
    """Auxiliary diagnostics only; never modifies legacy checks or pass/fail."""
    files = {e.path:e.content for e in tools.proposal.edits} if tools.proposal else {}
    if 'callbacks/callbacks.py' not in files or 'app/data/config.json' not in files:
        return {'version':1,'status':'unsupported','reason':'candidate files unavailable'}
    rows = layout_rows({'config':json.loads(files['app/data/config.json'])})
    original = {r['properties'].get('name') for r in layout_rows(tools.snapshot) if r['type']=='tab'}
    added = [r for r in rows if r['type']=='tab' and r['properties'].get('name') not in original]
    if len(added) != 1:
        return {'version':1,'status':'unsupported','reason':'unique new tab unavailable'}
    children = [r for r in rows if r['selector'].startswith(added[0]['selector']+'/')]
    outputs = {r['properties'].get('instance') for r in children if r['type']=='output'}
    buttons = [r for r in children if r['type']=='button']
    if len(buttons) != 1:
        return {'version':1,'status':'unsupported','reason':'unique button unavailable'}
    return greeting_probe(files['callbacks/callbacks.py'],buttons[0]['properties'].get('callback'),outputs)


def fixture(root, setup=''):
    for relative, content in starter_project_files(phase='development').items():
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding='utf-8')
    path = root / 'app/data/config.json'
    config = json.loads(path.read_text(encoding='utf-8'))
    config.update(layout={'mode':'canvas','designSize':[800,600],'resizeMode':'anchors','snap':1}, widgets=[{
        'type':'group','name':'Controls','bounds':[40,40,400,300],
        'layout':{'mode':'grid' if setup == 'grid' else 'canvas','designSize':[400,300],'resizeMode':'anchors','snap':1},
        'widgets':[{'type':'button','name':'Seed','callback':'seed_callback','bounds':[20,20,100,36],'pos':[0,0,1,1]},
                   {'type':'output','instance':'status','output_kind':'text','bounds':[20,180,300,80],'pos':[1,0,1,1]}]}])
    if setup == 'duplicate':
        config['widgets'].append({'type':'group','name':'Controls','bounds':[450,40,300,300],'widgets':[]})
    if setup == 'greeting_tab':
        from app.config_designer.schema import default_properties
        home=default_properties('tab')
        home.update(name='Home',widgets=config['widgets'])
        home['layout']['mode']='canvas'
        tabs=default_properties('tab_widget')
        tabs.update(instance='main_tabs',tabs=[home],bounds=[0,0,800,600])
        config['widgets']=[tabs]
    path.write_text(json.dumps(config),encoding='utf-8')
    callback_path = root / 'callbacks/callbacks.py'
    callbacks = callback_path.read_text(encoding='utf-8') + '\n\ndef seed_callback():\n    return 42\n\ndef untouched():\n    return "preserve me"\n'
    callback_path.write_text(callbacks,encoding='utf-8')
    for name, content in {'readings.csv':'time,voltage\n1,3.5\n2,4.5\n', 'readings.json':'{"unit":"volts","samples":[3.5,4.5]}',
                          'readings.xml':'<readings unit="volts"><sample>3.5</sample></readings>', 'notes.txt':'Sample frequency: 25 Hz'}.items():
        (root / 'externals' / name).write_text(content,encoding='utf-8')
    (root / 'externals/sample.bin').write_bytes(struct.pack('<H',513))
    snapshot = {'config':config,'callbacks':callbacks.replace('return 42','return 77') if setup == 'unsaved' else callbacks,
                'hashes':{p:file_hash(root / p) for p in ('app/data/config.json','callbacks/callbacks.py')},
                'runtime_generation':1,'selection':'','selected_nodes':[],
                'runtime':{tool:{'open':True,'sessions':[{'name':'Device','connected':False}]} for tool in ('serial','telnet','communication')},
                'recent_errors':[{'generation':1,'details':"Output instance 'missing_output' not found"}]}
    snapshot['revision']=digest([config,snapshot['callbacks']])
    snapshot['layout_tree']=layout_rows(snapshot)
    return snapshot


def score(case, tools, answer, calls):
    expected = case['expected']
    files = {e.path:e.content for e in tools.proposal.edits} if tools.proposal else {}
    config = json.loads(files.get('app/data/config.json') or json.dumps(tools.snapshot['config']))
    rows = layout_rows({'config':config})
    checks = {}
    if expected.get('greeting_ui'):
        original_tabs={r['properties'].get('name') for r in layout_rows(tools.snapshot) if r['type']=='tab'}
        added=[r for r in rows if r['type']=='tab' and r['properties'].get('name') not in original_tabs]
        checks['new_tab']=len(added)==1
        checks['greeting_binding']=False
        if len(added)==1:
            children=[r for r in rows if r['selector'].startswith(added[0]['selector']+'/')]
            outputs={r['properties'].get('instance') for r in children if r['type']=='output'}
            buttons=[r for r in children if r['type']=='button']
            source=files.get('callbacks/callbacks.py','')
            for button in buttons:
                functions=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==button['properties'].get('callback')]
                for f in functions:
                    constants={}
                    for statement in f.body:
                        if isinstance(statement,ast.Assign):
                            for target in statement.targets:
                                if isinstance(target,ast.Name):
                                    try:
                                        constants[target.id]=ast.literal_eval(statement.value)
                                    except (ValueError,TypeError):
                                        constants.pop(target.id,None)
                        n=statement.value if isinstance(statement,ast.Expr) else None
                        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='display' and len(n.args)>=2:
                            try:
                                target=constants[n.args[0].id] if isinstance(n.args[0],ast.Name) else ast.literal_eval(n.args[0])
                                text=constants[n.args[1].id] if isinstance(n.args[1],ast.Name) else ast.literal_eval(n.args[1])
                                checks['greeting_binding'] |= target in outputs and isinstance(text,str) and bool(text.strip())
                            except (ValueError,TypeError,KeyError):
                                pass
    if 'node' in expected:
        def matches(row):
            return all(row['properties'].get(k) == v if k != 'anchors' else set(row['properties'].get(k,[])) == set(v)
                       for k,v in expected['node'].items())
        matches_found = [r for r in rows if matches(r)]
        checks['requested_node'] = len(matches_found) == 1
        if expected.get('parent') and matches_found:
            parent = matches_found[0]['selector'].rsplit('/',1)[0]
            checks['requested_parent'] = any(r['selector'] == parent and r['properties'].get('name') == expected['parent'] for r in rows)
    if expected.get('preserve_seed'):
        checks['preserve_seed']=any(r['properties'].get('name') == 'Seed' and r['properties'].get('callback') == 'seed_callback' for r in rows)
    if 'absent_name' in expected:
        checks['removed']=not any(r['properties'].get('name') == expected['absent_name'] for r in rows)
    if 'function' in expected:
        spec=expected['function']
        try:
            definitions=[n for n in ast.parse(files.get(spec['path'],'')).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name == spec['name']]
            body = definitions[0].body[:] if len(definitions)==1 else []
            if body and isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):
                body.pop(0)  # A harmless function docstring does not change its return.
            actual = ast.literal_eval(body[0].value) if len(body)==1 and isinstance(body[0],ast.Return) else object()
            checks['function_return']=type(actual) is type(spec['returns']) and actual==spec['returns']
        except (ValueError,TypeError,SyntaxError):
            checks['function_return']=False
    if 'manifest' in expected:
        spec=expected['manifest']
        try:
            checks['manifest']=json.loads(files.get(spec['path'],'{}')).get('library',{}).get('package_name')==spec['package_name']
        except ValueError:
            checks['manifest']=False
    if 'action' in expected:
        checks['action']=bool(tools.action and all(tools.action.get(k)==v for k,v in expected['action'].items()))
    if 'answer_all' in expected:
        checks['answer_facts']=all(word.casefold() in answer.casefold() for word in expected['answer_all'])
    if expected.get('calls'):
        checks['required_inspection']=all(name in [c['tool'] for c in calls if c.get('ok')] for name in expected['calls'])
    if expected.get('any_calls'):
        checks['required_inspection']=any(c['tool'] in expected['any_calls'] and c.get('ok') for c in calls)
    if expected.get('no_proposal'):
        checks['no_proposal']=tools.proposal is None
    if expected.get('no_action'):
        checks['no_action']=tools.action is None
    if expected.get('clarification'):
        asks = '?' in answer or any(phrase in answer.casefold() for phrase in ('please specify','please provide','please attach','which group','which file'))
        checks['clarification']=tools.proposal is None and (asks or any(c['tool']=='request_clarification' and c.get('ok') for c in calls))
    if tools.proposal:
        checks['structural_validation']=tools.validate()['ok']
        candidate=files.get('callbacks/callbacks.py',tools.snapshot['callbacks'])
        checks['unrelated_callback_preserved']=any(isinstance(n,ast.FunctionDef) and n.name=='untouched' and ast.literal_eval(n.body[0].value)=='preserve me' for n in ast.parse(candidate).body)
    if case['edit'] and not any(expected.get(k) for k in ('no_proposal','no_action','clarification','action')):
        checks['proposal_exists']=tools.proposal is not None
    return checks
