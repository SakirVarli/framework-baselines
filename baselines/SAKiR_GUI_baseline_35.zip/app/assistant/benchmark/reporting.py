"""Sanitize before persistence; portable, reviewable benchmark artifacts."""
import base64
from collections import Counter, OrderedDict
from contextlib import contextmanager
from dataclasses import asdict, fields
from datetime import datetime, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import platform
import re
import math
import statistics
import time
import threading
from urllib.parse import quote
import zipfile
import zlib

from ..policy import AssistantError
from ..storage import atomic_json, Settings
from ..changes import Edit, Proposal

SCHEMA_VERSION = 1
STREAM_KINDS = frozenset({'provider_chunk', 'provider_reasoning_delta', 'reasoning_delta',
                          'provider_text_delta', 'text_delta'})


def event_rows(lines):
    """Read legacy JSONL and bounded, versioned lossless stream blocks."""
    for line in lines:
        row = json.loads(line)
        if row.get('kind') != 'stream_block':
            yield row
            continue
        if row.get('stream_schema') != 2:
            raise ValueError('Unsupported stream block version.')
        if not isinstance(row.get('payload'),str) or len(row['payload']) > 2*1024*1024:
            raise ValueError('Oversized stream block encoding.')
        data = base64.b64decode(row['payload'], validate=True)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(data, 1024*1024+1)
        if len(raw) > 1024*1024 or not decoder.eof or decoder.unused_data:
            raise ValueError('Invalid or oversized stream block.')
        values = json.loads(raw)
        if not isinstance(values,list) or not 1 <= len(values) <= 64:
            raise ValueError('Invalid stream block rows.')
        previous = None
        for value in values:
            if (not isinstance(value,dict) or value.get('kind') not in STREAM_KINDS
                    or type(value.get('sequence')) is not int
                    or previous is not None and value['sequence'] != previous+1):
                raise ValueError('Invalid stream block sequence.')
            previous = value['sequence']
            yield value
        if previous != row.get('sequence'):
            raise ValueError('Stream block endpoint mismatch.')


def stream_block(rows):
    raw = json.dumps(rows, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return {'kind':'stream_block', 'stream_schema':2, 'sequence':rows[-1]['sequence'],
            'payload':base64.b64encode(zlib.compress(raw, 1)).decode('ascii')}
def sanitize_stream_rows(rows, sanitizer):
    # Check reconstructed fields, not just isolated fragments. A trailing
    # credential prefix is masked too, since it may cross a block boundary.
    groups = {}
    def collect(parent, key, path, channel):
        value = parent[key]
        if isinstance(value,str):
            if not path or path[-1] in ('content','reasoning','reasoning_content','arguments'):
                groups.setdefault((channel,path),[]).append((parent,key,value))
        elif isinstance(value,dict):
            for child in value:
                collect(value,child,(*path,child),channel)
        elif isinstance(value,list):
            for child in range(len(value)):
                collect(value,child,(*path,child),channel)
    for row in rows:
        collect(row,'payload',(),(row['kind'],row.get('request_id')))
    for fragments in groups.values():
        joined = ''.join(value for _,_,value in fragments)
        partial = max((n for secret in (*sanitizer.secrets, *sanitizer.replacements)
                       for n in range(1,min(len(secret),len(joined)+1))
                       if joined.endswith(secret[:n])), default=0)
        if sanitizer.clean(joined) != joined:
            for parent,key,_ in fragments:
                parent[key] = '<redacted-stream>'
        elif partial:
            remaining = partial
            for parent,key,value in reversed(fragments):
                remove = min(len(value),remaining)
                if remove:
                    parent[key] = value[:-remove]+'<redacted-stream>'
                    remaining -= remove
                if not remaining:
                    break
    return rows


PRIVATE_FIELDS = {'key_env', 'credential_ref', 'ca_bundle', 'model_profiles', 'agent_models',
                  'capability_profile', 'usage_headers', 'base_url'}
SETTING_FIELDS = tuple(f.name for f in fields(Settings) if f.name not in PRIVATE_FIELDS)
SECRET_FIELD = re.compile(r'(?i)^(?:.*[_-])?(?:api[_-]?key|password|passwd|secret|token|access[_-]?token|refresh[_-]?token|authorization|cookie|set-cookie|credential[_-]?ref|key_env|ca_bundle)$')


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def exception_details(exc):
    """Keep a JSON-safe original cause; SDK exception codes may be null or numeric."""
    code = getattr(exc, 'code', None)
    result = {'code': str(code) if isinstance(code, (str, int)) and str(code) else type(exc).__name__,
              'message': str(exc), 'exception_type': type(exc).__name__}
    causes, seen = [], {id(exc)}
    cause = exc.__cause__ or (None if exc.__suppress_context__ else exc.__context__)
    while cause is not None and id(cause) not in seen and len(causes) < 4:
        seen.add(id(cause))
        causes.append({'exception_type': type(cause).__name__, 'message': str(cause)})
        cause = cause.__cause__ or (None if cause.__suppress_context__ else cause.__context__)
    if causes:
        result['causes'] = causes
    return result


def safe_settings(settings):
    return {name: getattr(settings, name) for name in SETTING_FIELDS}


class Sanitizer:
    def __init__(self, secrets=(), paths=(), endpoint=''):
        self.secrets = set()
        for value in secrets:
            if value and value != 'no-key-required':
                self.secrets.update((value, quote(value, safe=''), base64.b64encode(value.encode()).decode()))
        self.replacements = {str(p): f'<path-{i}>' for i, p in enumerate(paths) if p}
        if endpoint:
            self.replacements[endpoint.rstrip('/')] = '<endpoint-1>'
            from urllib.parse import urlsplit
            host = urlsplit(endpoint).netloc
            if host:
                self.replacements[host] = '<server-1>'
        self.counts = Counter()
        self.text_cache = OrderedDict()
        self.text_cache_bytes = 0
        self.cache_signature = None
        self.cache_lock = threading.RLock()

    def clean(self, value):
        if isinstance(value, Proposal):
            return self.clean({**asdict(value), 'fingerprint': value.fingerprint})
        if isinstance(value, Edit):
            return self.clean(asdict(value))
        if isinstance(value, Path):
            return self.clean(str(value))
        if isinstance(value, dict):
            result = {}
            for key, child in value.items():
                if SECRET_FIELD.fullmatch(str(key)):
                    result[self.clean(str(key))] = '<redacted>'
                    self.counts['secret_fields'] += 1
                else:
                    result[self.clean(str(key))] = self.clean(child)
            return result
        if isinstance(value, (list, tuple)):
            return [self.clean(child) for child in value]
        if not isinstance(value, str):
            return value
        return self.clean_text(value)

    def clean_text(self, value):
        # Bounded, sanitizer-local memoization. A changed credential/path policy
        # invalidates everything, including strings sanitized before fixture setup.
        with self.cache_lock:
            signature = (frozenset(self.secrets), tuple(self.replacements.items()))
            if signature != self.cache_signature:
                self.text_cache.clear()
                self.text_cache_bytes = 0
                self.cache_signature = signature
            cached = self.text_cache.get(value)
            if cached is not None:
                self.text_cache.move_to_end(value)
                self.counts.update(cached[1])
                return cached[0]
            before = self.counts.copy()
            result = self._clean_text(value)
            size = len(value.encode('utf-8')) + len(result.encode('utf-8'))
            if size <= 128*1024:
                while self.text_cache and (self.text_cache_bytes+size > 4*1024*1024 or len(self.text_cache) >= 4096):
                    _, (_, _, old_size) = self.text_cache.popitem(last=False)
                    self.text_cache_bytes -= old_size
                self.text_cache[value] = (result, self.counts-before, size)
                self.text_cache_bytes += size
            return result

    def _clean_text(self, value):
        for secret in sorted(self.secrets, key=len, reverse=True):
            if secret in value:
                self.counts['known_credentials'] += value.count(secret)
                value = value.replace(secret, '<redacted>')
        value = re.sub(r'(?i)\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+', 'Bearer <redacted>', value)
        # Embedded JSON, code assignments, bearer headers and URLs occur in tool text.
        value, n = re.subn(r'''(?i)((?:api[_-]?key|password|passwd|secret|token|access[_-]?token|refresh[_-]?token|authorization|cookie)["']?\s*[:=]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s,;}]+)''',
                           r'\1"<redacted>"', value)
        self.counts['credential_patterns'] += n
        value = re.sub(r'\bsk-[A-Za-z0-9_-]{12,}', '<redacted>', value)
        value = re.sub(r'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----.*?-----END (?:[A-Z ]+ )?PRIVATE KEY-----',
                       '<redacted-private-key>', value, flags=re.S)
        value = re.sub(r'(https?://)[^/\s:@]+:[^/\s@]+@', r'\1<redacted>@', value)
        value = re.sub(r'(?i)([?&](?:key|api_key|token|password|secret)=)[^&#\s]+', r'\1<redacted>', value)
        for path, replacement in sorted(self.replacements.items(), key=lambda row: len(row[0]), reverse=True):
            value = value.replace(path, replacement).replace(path.replace('\\', '/'), replacement)
        value = re.sub(r'(?i)[A-Z]:[\\/]Users[\\/][^\\/\s"<>]+', '<user-home>', value)
        value = re.sub(r'/(?:home|Users)/[^/\s"<>]+', '<user-home>', value)
        return value

    def verify(self, content):
        if any(secret.encode() in content for secret in self.secrets):
            raise AssistantError('BENCHMARK_SECRET', 'Export blocked: a known credential remains.')


def environment():
    from importlib.metadata import version, PackageNotFoundError
    packages = {}
    for package in ('openai', 'PyQt5', 'openpyxl', 'tiktoken', 'psutil'):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = None
    return {'os': platform.system(), 'os_release': platform.release(), 'architecture': platform.machine(),
            'python': platform.python_version(), 'logical_cpus': os.cpu_count(), 'dependencies': packages,
            'scope': 'application host; remote inference hardware unknown',
            'gpu': {'available': False, 'reason': 'No GPU collector configured'}}


def resources():
    result = {'process_cpu_seconds': time.process_time(), 'rss_bytes': None, 'available_ram_bytes': None}
    try:
        import psutil
        result.update(rss_bytes=psutil.Process().memory_info().rss,
                      available_ram_bytes=psutil.virtual_memory().available, collector='psutil')
    except (ImportError, OSError):
        result['collector'] = 'stdlib; RSS and RAM unavailable'
        if os.name == 'nt':
            import ctypes
            from ctypes import wintypes
            class MemoryStatus(ctypes.Structure):
                _fields_ = [('length', wintypes.DWORD), ('load', wintypes.DWORD),
                            *[(name, ctypes.c_ulonglong) for name in ('total', 'available', 'total_page', 'available_page', 'total_virtual', 'available_virtual', 'extended')]]
            class ProcessMemory(ctypes.Structure):
                _fields_ = [('cb', wintypes.DWORD), ('faults', wintypes.DWORD),
                            *[(name, ctypes.c_size_t) for name in ('peak_rss', 'rss', 'peak_paged', 'paged', 'peak_nonpaged', 'nonpaged', 'pagefile', 'peak_pagefile')]]
            try:
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                psapi = ctypes.WinDLL('psapi', use_last_error=True)
                kernel.GetCurrentProcess.restype = wintypes.HANDLE
                psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessMemory), wintypes.DWORD]
                memory, process = MemoryStatus(), ProcessMemory()
                memory.length = ctypes.sizeof(memory)
                process.cb = ctypes.sizeof(process)
                if kernel.GlobalMemoryStatusEx(ctypes.byref(memory)):
                    result.update(available_ram_bytes=memory.available, total_ram_bytes=memory.total)
                if psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(process), process.cb):
                    result.update(rss_bytes=process.rss, peak_rss_bytes=process.peak_rss)
                result['collector'] = 'Windows memory APIs'
            except (OSError, AttributeError):
                pass
    return result


class Recorder:
    def __init__(self, folder, sanitizer, max_bytes, persistent=False, compact_stream=False):
        self.folder, self.sanitizer = Path(folder), sanitizer
        self.folder.mkdir(parents=True, exist_ok=False)
        self.max_bytes, self.bytes, self.sequence = max_bytes, 0, 0
        self.started = time.monotonic()
        self.scope = {}
        self.last_resource = 0
        self.lock = threading.RLock()
        self.metrics = Counter()
        self.persistent, self.stream = persistent, None
        self.writer_closed = False
        self.profile, self.span_totals = Counter(), {}
        self.span_state = threading.local()
        self.pending_requests = {}
        self.request_counts = Counter()
        self.request_purposes = {}
        self.usage_requests = set()
        self.recording_seconds = 0.0
        self.recording_error = None
        self.compact_stream = compact_stream
        self.stream_rows, self.stream_size = [], 0
        self.trace_limit_recorded = False

    def event(self, kind, payload):
        with self.lock:
            started = time.monotonic()
            try:
                self._event(kind, payload)
            except AssistantError as exc:
                self.recording_error = self.recording_error or exc.code
                raise
            except Exception as exc:
                self.recording_error = self.recording_error or 'BENCHMARK_RECORDING_FAILED'
                message = self.sanitizer.clean(f'Could not record event {kind}: {type(exc).__name__}: {exc}')
                raise AssistantError('BENCHMARK_RECORDING_FAILED', message) from exc
            finally:
                self.recording_seconds += time.monotonic()-started

    def _event(self, kind, payload):
        if self.writer_closed:
            raise OSError('Benchmark event writer is closed.')
        self.sequence += 1
        row = {'sequence': self.sequence, 'utc': utc_now(), 'elapsed_seconds': time.monotonic()-self.started,
               **self.scope, 'kind': kind, 'payload': payload}
        started = time.monotonic()
        cleaned = self.sanitizer.clean(row)
        self.profile['sanitize_seconds'] += time.monotonic()-started
        started = time.monotonic()
        content = (json.dumps(cleaned, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')
        self.profile['serialize_seconds'] += time.monotonic()-started
        self.sanitizer.verify(content)
        if self.compact_stream and kind in STREAM_KINDS and len(content) < 64*1024:
            if self.stream_size+len(content) > 256*1024:
                self.flush_stream()
            self.stream_rows.append(cleaned)
            self.stream_size += len(content)
            if len(self.stream_rows) >= 64:
                self.flush_stream()
        else:
            self.flush_stream()
            self.persist(content)
        request_id = self.scope.get('request_id')
        if kind == 'provider_request':
            purpose = payload.get('purpose', 'unknown')
            self.pending_requests[request_id] = purpose
            self.request_counts['started'] += 1
            self.request_purposes.setdefault(purpose, Counter())['started'] += 1
        elif kind in {'provider_response', 'provider_error'}:
            purpose = self.pending_requests.pop(request_id, None)
            if purpose is not None:
                outcome = 'succeeded' if kind == 'provider_response' else 'failed'
                self.request_counts[outcome] += 1
                group = self.request_purposes[purpose]
                group[outcome] += 1
                group['seconds'] += payload.get('seconds', 0)
        elif kind == 'provider_usage' and request_id is not None:
            self.usage_requests.add(request_id)
        if kind == 'provider_usage':
            self.metrics['responses_with_usage'] += 1
            for field in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
                if type(payload.get(field)) is int:
                    self.metrics[field] += payload[field]
        elif kind == 'tool_result':
            self.metrics['tool_returns'] += 1
            result = payload.get('result', {})
            self.metrics['tool_skipped'] += int(result.get('executed') is False)
            self.metrics['tool_failures'] += int(not result.get('ok') and result.get('executed') is not False)
        elif kind == 'provider_reasoning_delta':
            self.metrics['exposed_reasoning_characters'] += len(payload)
        elif kind == 'tool_completed':
            self.metrics['host_tool_seconds'] += payload.get('duration_ms', 0)/1000
        elif kind == 'host_validation':
            self.metrics['host_validation_seconds'] += payload.get('seconds', 0)
        elif kind == 'host_span':
            total = self.span_totals.setdefault(payload['name'], Counter())
            total['count'] += 1
            for key in ('seconds', 'exclusive_seconds', 'process_cpu_seconds'):
                total[key] += payload[key]

    def persist(self, content):
        reserve = min(4096, self.max_bytes//20) if self.compact_stream else 0
        if self.bytes+len(content) > self.max_bytes-reserve:
            if reserve and not self.trace_limit_recorded:
                marker = {'sequence': self.sequence, 'kind':'trace_limited',
                          'payload':{'trace_complete':False, 'pending_requests':len(self.pending_requests)}}
                raw = (json.dumps(marker)+'\n').encode('utf-8')
                if self.bytes+len(raw) <= self.max_bytes:
                    self._write_bytes(raw)
                    self.bytes += len(raw)
                self.trace_limit_recorded = True
            raise AssistantError('BENCHMARK_TRACE_LIMIT', 'Trace size limit reached; evidence is incomplete.')
        started = time.monotonic()
        self._write_bytes(content)
        self.profile['write_seconds'] += time.monotonic()-started
        self.bytes += len(content)

    def flush_stream(self):
        if not self.stream_rows:
            return
        rows, self.stream_rows = self.stream_rows, []
        self.stream_size = 0
        sanitize_stream_rows(rows, self.sanitizer)
        self.persist((json.dumps(stream_block(rows), separators=(',', ':'))+'\n').encode('utf-8'))

    def _write_bytes(self, content):
        if self.writer_closed:
            raise OSError('Benchmark event writer is closed.')
        if not self.persistent:
            with (self.folder/'events.jsonl').open('ab') as stream:
                stream.write(content)
            return
        if self.stream is None:
            # Unbuffered: keep the file open without introducing a new process-crash loss window.
            self.stream = (self.folder/'events.jsonl').open('ab', buffering=0)
        remaining = memoryview(content)
        while remaining:
            count = self.stream.write(remaining)
            if not count:
                raise OSError('Benchmark event write did not make progress.')
            remaining = remaining[count:]

    def close(self):
        with self.lock:
            try:
                if self.recording_error is None:
                    self.flush_stream()
            except Exception as exc:
                self.recording_error = self.recording_error or getattr(exc,'code','BENCHMARK_RECORDING_FAILED')
                raise
            finally:
                self._close_writer()

    def _close_writer(self):
        self.writer_closed = True
        if self.stream is not None:
            try:
                self.stream.close()
            finally:
                self.stream = None

    @contextmanager
    def span(self, name):
        stack = getattr(self.span_state, 'stack', None)
        if stack is None:
            stack = self.span_state.stack = []
        row = {'name':name, 'span_id':str(self.sequence)+':'+str(time.monotonic_ns()),
               'parent_span_id':stack[-1]['span_id'] if stack else None, 'children':0.0}
        started, cpu, failure = time.monotonic(), time.process_time(), None
        stack.append(row)
        try:
            yield
        except BaseException as exc:
            failure = exc
            raise
        finally:
            seconds = time.monotonic()-started
            stack.pop()
            if stack:
                stack[-1]['children'] += seconds
            row.update(seconds=seconds, exclusive_seconds=max(0, seconds-row.pop('children')),
                       process_cpu_seconds=max(0,time.process_time()-cpu), status='failed' if failure else 'completed')
            try:
                self.event('host_span', row)
            except Exception:
                if failure is None:
                    raise

    def diagnostics(self, attempted, status):
        """Additive schema-1 fields; old exports remain readable without these fields."""
        with self.lock:
            started = self.request_counts['started']
            integrity = ('truncated' if self.recording_error == 'BENCHMARK_TRACE_LIMIT' else
                         'recording_failed' if self.recording_error else 'intact')
            return {
                'provider_requests': {
                    'attempted': attempted, 'recorded_started': started,
                    'succeeded': self.request_counts['succeeded'], 'failed': self.request_counts['failed'],
                    'incomplete': len(self.pending_requests), 'unrecorded': max(0, attempted-started),
                    'reconciled': attempted == started and not self.pending_requests and integrity == 'intact',
                    'by_purpose': {key: dict(value) for key, value in self.request_purposes.items()},
                    'timing_scope': 'Provider-call elapsed time includes transport, server work and in-call recording; no server-only timing inferred.'},
                'trace_status': {'run_complete': status == 'completed', 'event_stream': integrity,
                                 'pending_requests': len(self.pending_requests),
                                 'stream_schema': 2 if self.compact_stream else 1,
                                 'buffer_loss_window': 'At most 64 stream events / 256 KiB until the next nonstream event or close.' if self.compact_stream else None},
                'usage_availability': {'requests_with_usage': len(self.usage_requests),
                                       'requests_attempted': attempted,
                                       'status': 'unavailable' if not self.usage_requests else
                                                 'complete' if len(self.usage_requests) == attempted else 'partial'},
                'host_timing': {'event_recording_seconds': self.recording_seconds,
                                'recorder_phases': dict(self.profile),
                                'spans': {name:dict(value) for name,value in self.span_totals.items()},
                                'writer': 'persistent_unbuffered' if self.persistent else 'open_per_event',
                                'tool_seconds': self.metrics['host_tool_seconds'],
                                'validation_seconds': self.metrics['host_validation_seconds'],
                                'note': 'Observed spans can overlap provider/stage time; do not sum these fields into run duration. Process CPU samples can include other threads; exclusive span wall times subtract nested spans.'}}

    def write(self, name, value):
        cleaned = self.sanitizer.clean(value)
        self.sanitizer.verify(json.dumps(cleaned, ensure_ascii=False).encode())
        atomic_json(self.folder / name, cleaned)

    def sample(self):
        with self.lock:
            if time.monotonic()-self.last_resource >= 1:
                self.last_resource = time.monotonic()
                self.event('host_resources', resources())


def summarize(manifest, cases, status, error=None):
    outcomes = Counter(case.get('status', 'passed' if case.get('passed') else 'failed') for case in cases)
    def pair_key(row):
        return (row.get('case', row.get('id')), row.get('repetition', 0), row.get('candidate'))
    scheduled_pairs, completed_pairs = {}, {}
    for row in manifest['matrix']:
        if isinstance(row, dict):
            scheduled_pairs.setdefault(pair_key(row), set()).add(row.get('mode'))
    for row in cases:
        if row.get('status') not in {'unsupported', 'interrupted'}:
            completed_pairs.setdefault(pair_key(row), set()).add(row.get('mode'))
    paired = {key for key, modes in scheduled_pairs.items() if {'single', 'multi'} <= modes}
    groups = {}
    for case in cases:
        key = case['mode']
        group = groups.setdefault(key, {'executed': 0, 'passed': 0, 'seconds': 0, 'actual_models': [], 'multi_model_exercised': False})
        group['executed'] += 1
        group['passed'] += int(case.get('passed', False))
        group['seconds'] += case.get('seconds', 0)
        group['actual_models'] = sorted(set(group['actual_models']) | set(case.get('actual_models', [])))
        group['multi_model_exercised'] = len(group['actual_models']) >= 2
    candidates = {}
    for case in cases:
        if case.get('candidate'):
            candidate_key = case['mode']+':'+case['candidate']
            group = candidates.setdefault(candidate_key, {'calibration_passed': 0, 'calibration_total': 0,
                'validation_passed': 0, 'validation_total': 0, 'seconds': 0, 'settings': case.get('candidate_settings', {}), 'mode': case['mode']})
            prefix = case['partition']
            group[prefix+'_passed'] += int(case.get('passed', False))
            group[prefix+'_total'] += 1
            group['seconds'] += case.get('seconds', 0)
    recommendations = {'status': 'insufficient_evidence', 'message': 'Inspect failed checks and traces. No saved settings were changed.'}
    if status == 'completed' and candidates:
        recommendations = {'status': 'candidate_for_review', 'selected_using': 'calibration only; validation shown separately',
                           'by_mode': {}, 'message': 'Small synthetic sample; inspect tradeoffs before changing settings.'}
        for mode in {group['mode'] for group in candidates.values()}:
            ranked = sorted((name for name in candidates if candidates[name]['mode'] == mode),
                key=lambda name: (-candidates[name]['calibration_passed']/max(1, candidates[name]['calibration_total']), candidates[name]['seconds']))
            best = ranked[0]
            evidence = candidates[best]
            recommendations['by_mode'][mode] = {'candidate': best, 'settings': evidence['settings'],
                'validation_passed': evidence['validation_passed'], 'validation_total': evidence['validation_total'],
                'validated': evidence['validation_total'] > 0 and evidence['validation_total'] == evidence['validation_passed']}
    domain_groups = {}
    for case in cases:
        group = domain_groups.setdefault(case['mode']+'/'+case.get('domain', 'unknown'), [])
        group.append(case)
    domains = {}
    for name, rows in domain_groups.items():
        durations = sorted(row.get('seconds', 0) for row in rows)
        domains[name] = {'executed': len(rows), 'passed': sum(bool(row.get('passed')) for row in rows),
                         'p50_seconds': statistics.median(durations),
                         'p95_seconds': durations[math.ceil(len(durations)*.95)-1]}
    return {'schema_version': SCHEMA_VERSION, 'run_id': manifest['run_id'], 'status': status,
            'updated_utc': utc_now(), 'scheduled': len(manifest['matrix']), 'executed': len(cases),
            'passed': sum(bool(c.get('passed')) for c in cases),
            'not_executed': len(manifest['matrix'])-len(cases), 'by_mode': groups, 'error': error,
            'case_outcomes': {key: outcomes[key] for key in ('passed', 'failed', 'interrupted', 'unsupported')},
            'comparison_coverage': {'scheduled_pairs': len(paired),
                                    'completed_pairs': sum({'single', 'multi'} <= completed_pairs.get(key, set()) for key in paired),
                                    'note': 'Paired completion does not establish matching settings or genuine multi-model participation.'},
            'by_mode_domain': domains,
            'interpretation': 'Development measurements. Failures do not alone establish hardware insufficiency.',
            'limits_candidates': candidates, 'recommendations': recommendations}


def interrupted_summary(summary):
    """An abrupt worker exit leaves only a snapshot, not final accounting."""
    value = dict(summary, status='interrupted', trace_complete=False,
                 error={'code': 'WORKER_INTERRUPTED', 'message': 'Worker stopped before finalization. Active case evidence may be incomplete.'})
    value['trace_status'] = {**summary.get('trace_status', {}), 'run_complete': False,
                             'event_stream': 'unknown', 'accounting_final': False}
    if 'provider_requests' in summary:
        value['provider_requests'] = {**summary['provider_requests'], 'reconciled': False,
                                      'availability': 'partial_snapshot'}
    if 'usage_availability' in summary:
        value['usage_availability'] = {**summary['usage_availability'], 'status': 'unknown_after_interruption'}
    return value


def recover_event_tail(folder):
    """Repair only an interrupted final JSONL write; never hide interior corruption."""
    path = Path(folder)/'events.jsonl'
    if not path.is_file() or path.is_symlink():
        return
    offset, last_sequence = 0, 0
    with path.open('rb') as stream:
        for line in stream:
            try:
                value = json.loads(line)
                last_sequence = value.get('sequence', last_sequence)
            except (ValueError, UnicodeError):
                if stream.read(1):
                    raise ValueError('Report contains interior event corruption.')
                dropped = path.stat().st_size-offset
                break
            offset += len(line)
        else:
            return
    marker = {'sequence': last_sequence+1, 'utc': utc_now(), 'kind': 'recording_interrupted',
              'payload': {'dropped_incomplete_tail_bytes': dropped, 'trace_complete': False}}
    with path.open('r+b') as stream:
        stream.truncate(offset)
        stream.seek(offset)
        stream.write((json.dumps(marker)+'\n').encode())


def render_report(folder):
    folder = Path(folder)
    summary = json.loads((folder / 'summary.json').read_text(encoding='utf-8'))
    rows = json.loads((folder / 'cases.json').read_text(encoding='utf-8'))
    body = '<h1>Assistant benchmark</h1><pre>' + html.escape(json.dumps(summary, indent=2)) + '</pre>'
    body += '<table><tr><th>Case</th><th>Mode</th><th>Result</th><th>Seconds</th></tr>'
    for row in rows:
        values = (row['id'], row['mode'], row.get('status', 'passed' if row.get('passed') else 'failed'), round(row.get('seconds', 0), 2))
        body += '<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in values)+'</tr>'
    body += '</table><h2>Case evidence</h2><pre>'+html.escape(json.dumps(rows, ensure_ascii=False, indent=2))+'</pre>'
    chats = folder/'chats.json'
    if chats.is_file():
        body += '<h2>User-selected chats (diagnostics; excluded from scores)</h2><pre>'
        body += html.escape(json.dumps(json.loads(chats.read_text(encoding='utf-8')), ensure_ascii=False, indent=2))+'</pre>'
    content = '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>Assistant benchmark</title><style>body{font:15px system-ui;margin:32px}pre{white-space:pre-wrap;overflow-wrap:anywhere}td,th{padding:8px;border:1px solid #ccc}table{border-collapse:collapse}</style>'+body
    (folder / 'report.html').write_text(content, encoding='utf-8')


EXPORT_FILES = ('manifest.json', 'summary.json', 'cases.json', 'events.jsonl', 'chats.json', 'report.html')


def export_bundle(folder, destination, sanitizer=None):
    """Only export known artifacts. Never recursively zip a user-selected directory."""
    folder, destination = Path(folder), Path(destination)
    if any(destination.resolve() == (folder / name).resolve() for name in EXPORT_FILES):
        raise AssistantError('BENCHMARK_EXPORT', 'Choose a ZIP path outside the report artifacts.')
    sanitizer = sanitizer or Sanitizer()
    content = {}
    for name in EXPORT_FILES:
        path = folder / name
        if path.is_file() and not path.is_symlink():
            raw = path.read_bytes()
            if name.endswith('.json'):
                raw = json.dumps(sanitizer.clean(json.loads(raw)), ensure_ascii=False, indent=2).encode()
            elif name.endswith('.jsonl'):
                output = []
                for line in raw.splitlines():
                    if not line.strip():
                        continue
                    value = json.loads(line)
                    if value.get('kind') == 'stream_block':
                        value = stream_block(sanitize_stream_rows([sanitizer.clean(r) for r in event_rows([line])], sanitizer))
                    else:
                        value = sanitizer.clean(value)
                    output.append(json.dumps(value, ensure_ascii=False, separators=(',', ':')))
                raw = ('\n'.join(output)+'\n').encode()
            else:
                raw = sanitizer.clean(raw.decode('utf-8')).encode()
            sanitizer.verify(raw)
            content[name] = raw
    if not {'manifest.json', 'summary.json', 'cases.json'} <= content.keys():
        raise AssistantError('BENCHMARK_EXPORT', 'This report is missing its manifest, summary or cases.')
    inventory = {name: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name, raw in content.items()}
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in content.items():
            archive.writestr(name, raw)
        archive.writestr('inventory.json', json.dumps(inventory, indent=2))
