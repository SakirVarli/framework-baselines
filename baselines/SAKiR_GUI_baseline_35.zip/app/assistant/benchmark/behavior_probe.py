"""Bounded AST interpretation for auxiliary greeting adjudication, never execution.

This deliberately supports a small language. Unsupported code is inconclusive,
not passed. No imports, eval, exec, callback invocation or external I/O occur.
Historical scoring remains independent of this diagnostic.
"""
import ast


class Unsupported(ValueError):
    pass


def greeting_probe(source, callback, outputs):
    try:
        if len(source) > 100000:
            raise Unsupported('source budget')
        tree = ast.parse(source)
        functions = [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name == callback]
        if (len(functions) != 1 or functions[0].args.args or functions[0].args.posonlyargs
                or functions[0].args.kwonlyargs or functions[0].args.vararg or functions[0].args.kwarg
                or functions[0].decorator_list):
            raise Unsupported('callback shape')
        seen_function = False
        for node in tree.body:
            if isinstance(node,ast.FunctionDef):
                seen_function = True
                if node.name in ('display','datetime'):
                    raise Unsupported('shadowed import')
            elif isinstance(node,ast.ImportFrom):
                if (seen_function or node.level or node.module not in ('datetime','app.stubs','app.branding')
                        or any(a.asname for a in node.names)
                        or node.module != 'app.stubs' and any(a.name=='*' for a in node.names)):
                    raise Unsupported('import')
                if node.module != 'app.stubs' and any(a.name == 'display' for a in node.names):
                    raise Unsupported('display import')
                if node.module != 'datetime' and any(a.name == 'datetime' for a in node.names):
                    raise Unsupported('datetime import')
            elif isinstance(node,ast.ClassDef):
                # Framework state declarations do not enter the callback's local
                # environment. Accept only the inert declaration shape here;
                # initialization and lifecycle behavior remain outside this probe.
                if (node.name in ('display','datetime',callback) or node.decorator_list or node.keywords
                        or any(not isinstance(b,ast.Name) or b.id!='GlobalsBase' for b in node.bases)):
                    raise Unsupported('class declaration')
                for child in node.body:
                    if isinstance(child,ast.FunctionDef) and not child.decorator_list and not child.args.defaults and not child.args.kw_defaults:
                        continue
                    if isinstance(child,ast.Assign) and all(isinstance(t,ast.Name) for t in child.targets):
                        ast.literal_eval(child.value)
                        continue
                    if isinstance(child,ast.Expr) and isinstance(child.value,ast.Constant) and isinstance(child.value.value,str):
                        continue
                    raise Unsupported('class body')
            elif not (isinstance(node,ast.Expr) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str)):
                raise Unsupported('module statement')
        imports = {(n.module,a.name) for n in tree.body if isinstance(n,ast.ImportFrom) for a in n.names if a.asname is None}
        if ('app.stubs','display') not in imports and ('app.stubs','*') not in imports:
            raise Unsupported('display binding')
        results = []
        for hour in (0,8,12,17,18,23):
            env, calls = {}, []
            budget = [500]
            def value(node):
                budget[0] -= 1
                if budget[0] < 0:
                    raise Unsupported('step budget')
                if isinstance(node,ast.Constant) and isinstance(node.value,(str,int,bool,type(None))):
                    return node.value
                if isinstance(node,ast.Name) and node.id in env:
                    return env[node.id]
                if isinstance(node,ast.JoinedStr):
                    parts = []
                    for part in node.values:
                        if isinstance(part,ast.FormattedValue):
                            if part.format_spec or part.conversion not in (-1,115):
                                raise Unsupported('format specifier')
                            parts.append(str(value(part.value)))
                        else:
                            parts.append(value(part))
                    return ''.join(parts)
                if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):
                    left,right = value(node.left),value(node.right)
                    if isinstance(left,str) and isinstance(right,str) and len(left)+len(right) <= 10000:
                        return left+right
                if isinstance(node,ast.Compare) and len(node.ops)==1:
                    left,right = value(node.left),value(node.comparators[0])
                    if type(left) is not int or type(right) is not int:
                        raise Unsupported('comparison type')
                    op = node.ops[0]
                    if isinstance(op,ast.Lt): return left < right
                    if isinstance(op,ast.LtE): return left <= right
                    if isinstance(op,ast.Gt): return left > right
                    if isinstance(op,ast.GtE): return left >= right
                    if isinstance(op,ast.Eq): return left == right
                if (isinstance(node,ast.Attribute) and node.attr=='hour' and isinstance(node.value,ast.Call)
                        and not node.value.args and not node.value.keywords
                        and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='now'
                        and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='datetime'
                        and ('datetime','datetime') in imports and 'datetime' not in env):
                    return hour
                raise Unsupported('expression '+type(node).__name__)
            def statements(nodes):
                for node in nodes:
                    budget[0] -= 1
                    if budget[0] < 0: raise Unsupported('step budget')
                    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
                        env[node.targets[0].id] = value(node.value)
                    elif isinstance(node,ast.If):
                        result = value(node.test)
                        if type(result) is not bool: raise Unsupported('condition type')
                        statements(node.body if result else node.orelse)
                    elif isinstance(node,ast.Expr) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str):
                        continue
                    elif isinstance(node,ast.Expr) and isinstance(node.value,ast.Call):
                        call = node.value
                        if (not isinstance(call.func,ast.Name) or call.func.id!='display' or 'display' in env
                                or len(call.args)!=2 or any(k.arg != 'mode' for k in call.keywords)):
                            raise Unsupported('call')
                        target,text = (value(v) for v in call.args)
                        mode = next((value(k.value) for k in call.keywords),'append')
                        calls.append(target in outputs and isinstance(text,str) and bool(text.strip())
                                     and mode in ('append','replace'))
                    else:
                        raise Unsupported('statement '+type(node).__name__)
            statements(functions[0].body)
            results.append(bool(calls) and all(calls))
        return {'version':1,'status':'supported' if all(results) else 'contradicted',
                'hours':[0,8,12,17,18,23], 'basis':'bounded_ast_interpretation_not_runtime_execution'}
    except (Unsupported,SyntaxError,ValueError,TypeError,RecursionError) as exc:
        return {'version':1,'status':'unsupported','reason':str(exc)[:160],
                'basis':'bounded_ast_interpretation_not_runtime_execution'}
