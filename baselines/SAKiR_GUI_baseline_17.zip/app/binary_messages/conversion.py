from __future__ import annotations

import types
from collections.abc import Mapping as MappingABC
from dataclasses import fields, is_dataclass
from enum import Enum
from construct import Enum as ConstructEnum, EnumInteger, EnumIntegerString
from functools import lru_cache
from typing import Annotated, Any, Mapping, Union, get_args, get_origin, get_type_hints

from .fields import field_options


@lru_cache(maxsize=None)
def resolved_type_hints(model_type: type) -> dict[str, Any]:
    try:
        return get_type_hints(model_type, include_extras=True)
    except (NameError, TypeError):
        return dict(getattr(model_type, "__annotations__", {}))


def dataclass_from_mapping(model_type: type, value: Mapping[str, Any]):
    if not isinstance(value, Mapping):
        raise TypeError(
            f"Expected a mapping for {model_type.__name__}, got {type(value).__name__}"
        )

    hints = resolved_type_hints(model_type)
    kwargs: dict[str, Any] = {}

    for model_field in fields(model_type):
        serialized, wire_name = field_options(model_field)
        if not serialized or not model_field.init or wire_name not in value:
            continue
        annotation = hints.get(model_field.name, model_field.type)
        kwargs[model_field.name] = value_from_wire(value[wire_name], annotation)

    return model_type(**kwargs)


def dataclass_to_mapping(value: Any, *, include_runtime: bool = False,
                         preserve_construct_enums: bool = False) -> dict[str, Any]:
    result: dict[str, Any] = {}
    hints = resolved_type_hints(type(value)) if preserve_construct_enums else {}
    for model_field in fields(value):
        serialized, wire_name = field_options(model_field)
        if not serialized and not include_runtime:
            continue
        output_name = wire_name if serialized else model_field.name
        field_value = getattr(value, model_field.name)
        annotation = hints.get(model_field.name)
        if preserve_construct_enums and _has_construct_enum(annotation):
            field_value = value_from_wire(field_value, annotation)
        result[output_name] = value_to_wire(
            field_value,
            include_runtime=include_runtime,
            preserve_construct_enums=preserve_construct_enums,
        )
    return result


def value_from_wire(value: Any, annotation: Any) -> Any:
    if annotation in (Any, object, None):
        return value

    origin = get_origin(annotation)
    args = get_args(annotation)

    if origin is Annotated:
        for metadata in args[1:]:
            if isinstance(metadata, ConstructEnum):
                if isinstance(value, str) and value in metadata.encmapping:
                    return metadata.decmapping[metadata.encmapping[value]]
                if isinstance(value, int):
                    return metadata.decmapping.get(int(value), EnumInteger(int(value)))
        return value_from_wire(value, args[0])

    if origin in (Union, types.UnionType):
        if value is None and type(None) in args:
            return None
        last_error: Exception | None = None
        for candidate in args:
            if candidate is type(None):
                continue
            try:
                return value_from_wire(value, candidate)
            except (TypeError, ValueError) as error:
                last_error = error
        if last_error is not None:
            raise last_error
        return value

    if origin is list:
        item_type = args[0] if args else Any
        return [value_from_wire(item, item_type) for item in value]

    if origin is tuple:
        if len(args) == 2 and args[1] is Ellipsis:
            return tuple(value_from_wire(item, args[0]) for item in value)
        return tuple(
            value_from_wire(item, item_type)
            for item, item_type in zip(value, args, strict=True)
        )

    if origin is set:
        item_type = args[0] if args else Any
        return {value_from_wire(item, item_type) for item in value}

    if origin in (dict, Mapping, MappingABC):
        key_type, item_type = args if len(args) == 2 else (Any, Any)
        return {
            value_from_wire(key, key_type): value_from_wire(item, item_type)
            for key, item in value.items()
        }

    if isinstance(annotation, type) and issubclass(annotation, Enum):
        if isinstance(value, annotation):
            return value
        try:
            return annotation(value)
        except ValueError:
            return annotation[str(value)]

    if isinstance(annotation, type) and is_dataclass(annotation):
        from_wire = getattr(annotation, "from_wire", None)
        if callable(from_wire):
            return from_wire(value)
        return dataclass_from_mapping(annotation, value)

    if annotation is bytes and isinstance(value, (bytearray, memoryview)):
        return bytes(value)

    return value


def _has_construct_enum(annotation):
    return any(isinstance(arg, ConstructEnum) or _has_construct_enum(arg)
               for arg in get_args(annotation))


def value_to_wire(value: Any, *, include_runtime: bool = False,
                  preserve_construct_enums: bool = False) -> Any:
    if isinstance(value, (EnumInteger, EnumIntegerString)):
        return value if preserve_construct_enums else int(value)
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value) and not isinstance(value, type):
        to_wire = getattr(value, "to_wire", None)
        if callable(to_wire):
            if not preserve_construct_enums:
                return to_wire()
            from .base import BinaryMessage
            if getattr(type(value), 'to_wire', None) is not BinaryMessage.to_wire:
                return to_wire()
        return dataclass_to_mapping(value, include_runtime=include_runtime,
                                    preserve_construct_enums=preserve_construct_enums)
    def convert(item):
        return value_to_wire(item, include_runtime=include_runtime,
                             preserve_construct_enums=preserve_construct_enums)
    if isinstance(value, Mapping):
        return {
            key: convert(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [convert(item) for item in value]
    if isinstance(value, tuple):
        return tuple(convert(item) for item in value)
    if isinstance(value, set):
        return [convert(item) for item in value]
    return value
