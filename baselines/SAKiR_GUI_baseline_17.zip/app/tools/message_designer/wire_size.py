from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from .enum_schema import storage as enum_storage


@dataclass(frozen=True)
class WireSize:
    """A conservative compile-time wire-size result."""

    status: str
    bytes: int | None = None

    @classmethod
    def exact(cls, size: int) -> "WireSize":
        return cls("exact", size)

    @classmethod
    def variable(cls) -> "WireSize":
        return cls("variable")

    @classmethod
    def unknown(cls) -> "WireSize":
        return cls("unknown")

    def label(self) -> str:
        if self.status == "exact":
            return f"{self.bytes} B"
        return self.status.title()


class WireSizeAnalyzer:
    """Determine sizes without evaluating trusted Construct expressions."""

    def __init__(self, manifest: dict[str, Any]):
        self.enums = {value.get("uid"): value for value in manifest.get("enums", [])}
        self.structures = {value.get("uid"): value for value in manifest.get("structures", [])}
        self._structure_cache: dict[str, WireSize] = {}
        self._visiting: set[str] = set()

    def definition(self, value: dict[str, Any]) -> WireSize:
        uid = value.get("uid")
        if uid in self.enums:
            try: return WireSize.exact(enum_storage(value)['width'])
            except (ValueError, TypeError): return WireSize.unknown()
        if uid in self.structures:
            return self._structure(uid)
        return self.fields(value.get("fields", []))

    def fields(self, fields: list[dict[str, Any]]) -> WireSize:
        return self._sum(self.field(field) for field in fields)

    def field(self, field: dict[str, Any]) -> WireSize:
        kind = field.get("kind")
        if kind in {"uint", "int", "float"}:
            return self._exact_integer(field.get("width"))
        if kind == "bytes_integer":
            return self._exact_integer(field.get("length"))
        if kind in {"varint", "zigzag"}:
            return WireSize.variable()
        if kind == "bool":
            return WireSize.exact(1)
        if kind == "enum":
            if field.get("enum_uid") not in self.enums:
                return WireSize.unknown()
            try: return WireSize.exact(enum_storage(self.enums[field['enum_uid']])['width'])
            except (ValueError, TypeError): return WireSize.unknown()
        if kind in {"bytes", "string"}:
            if field.get("mode") == "fixed":
                return self._exact_integer(field.get("length"), allow_zero=True)
            return WireSize.variable()
        if kind == "bitfield":
            total = 0
            for member in field.get("members", []):
                bits = self._integer(member.get("bits"))
                if bits is None or bits <= 0:
                    return WireSize.unknown()
                total += bits
            if total % 8:
                return WireSize.unknown()
            return WireSize.exact(total // 8)
        if kind == "array":
            item = field.get("item")
            if not isinstance(item, dict):
                return WireSize.unknown()
            if field.get("mode") != "fixed":
                return WireSize.unknown() if self.field(item).status == "unknown" else WireSize.variable()
            count = self._integer(field.get("count"))
            if count is None or count < 0:
                return WireSize.unknown()
            if count == 0:
                return WireSize.exact(0)
            item_size = self.field(item)
            if item_size.status == "exact":
                return WireSize.exact(count * int(item_size.bytes))
            return item_size
        if kind == "struct":
            uid = field.get("struct_uid")
            if uid not in self.structures:
                return WireSize.unknown()
            return self._structure(uid)
        if kind == "inline_struct":
            return self.fields(field.get("fields", []))
        if kind == "conditional":
            item = field.get("item")
            if not isinstance(item, dict) or self.field(item).status == "unknown":
                return WireSize.unknown()
            return WireSize.variable()
        if kind == "switch":
            sizes = []
            for case in field.get("cases", []):
                item = case.get("item")
                if not isinstance(item, dict):
                    return WireSize.unknown()
                sizes.append(self.field(item))
            default = str(field.get("default") or "Pass").strip()
            if default == "Pass":
                sizes.append(WireSize.exact(0))
            else:
                return WireSize.unknown()
            if any(size.status == "unknown" for size in sizes):
                return WireSize.unknown()
            if any(size.status == "variable" for size in sizes):
                return WireSize.variable()
            exact_sizes = {size.bytes for size in sizes}
            return WireSize.exact(int(exact_sizes.pop())) if len(exact_sizes) == 1 else WireSize.variable()
        if kind in {"const", "default", "rebuild", "checksum"}:
            item = field.get("item")
            return self.field(item) if isinstance(item, dict) else WireSize.unknown()
        if kind == "padding":
            return self._exact_integer(field.get("length"), allow_zero=True)
        if kind == "aligned":
            item = field.get("item")
            modulus = self._integer(field.get("modulus"))
            if not isinstance(item, dict) or modulus is None or modulus <= 0:
                return WireSize.unknown()
            item_size = self.field(item)
            if item_size.status != "exact":
                return item_size
            size = int(item_size.bytes)
            return WireSize.exact(((size + modulus - 1) // modulus) * modulus)
        if kind == "computed":
            return WireSize.exact(0)
        if kind == "advanced":
            return WireSize.unknown()
        return WireSize.unknown()

    def _structure(self, uid: str) -> WireSize:
        if uid in self._structure_cache:
            return self._structure_cache[uid]
        if uid in self._visiting:
            return WireSize.unknown()
        structure = self.structures.get(uid)
        if structure is None:
            return WireSize.unknown()
        self._visiting.add(uid)
        try:
            result = self.fields(structure.get("fields", []))
        finally:
            self._visiting.remove(uid)
        self._structure_cache[uid] = result
        return result

    @staticmethod
    def _sum(sizes) -> WireSize:
        total = 0
        saw_variable = False
        for size in sizes:
            if size.status == "unknown":
                return WireSize.unknown()
            if size.status == "variable":
                saw_variable = True
            else:
                total += int(size.bytes)
        return WireSize.variable() if saw_variable else WireSize.exact(total)

    @classmethod
    def _exact_integer(cls, value, *, allow_zero: bool = False) -> WireSize:
        parsed = cls._integer(value)
        minimum = 0 if allow_zero else 1
        if parsed is None or parsed < minimum:
            return WireSize.unknown()
        return WireSize.exact(parsed)

    @staticmethod
    def _integer(value) -> int | None:
        try:
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return None
