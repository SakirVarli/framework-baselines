"""OpenAI-compatible Chat Completions transport with optional streaming."""
import json
import threading

from .policy import AssistantError


class ChatProvider:
    def __init__(self, settings, api_key, client=None):
        settings.validate()
        self.settings = settings
        self._key = api_key
        self._stream = None
        self._lock = threading.Lock()
        if client is not None:
            self.client = client
        else:
            try:
                # Lazy at runtime, visible to the supervisor's AST dependency scan.
                import openai as sdk
            except ImportError:
                raise AssistantError("DEPENDENCY_MISSING", "Install assistant dependencies: python -m pip install -r app/assistant/requirements.txt") from None
            options = {"base_url": settings.base_url.rstrip("/"), "api_key": api_key,
                       "timeout": settings.timeout, "max_retries": 0}
            if settings.ca_bundle:
                import ssl
                options["http_client"] = sdk.DefaultHttpxClient(verify=ssl.create_default_context(cafile=settings.ca_bundle))
            self.client = sdk.OpenAI(**options)

    def close(self):
        with self._lock:
            stream = self._stream
        if stream:
            stream.close()

    def dispose(self):
        try:
            self.close()
        finally:
            self.client.close()

    def models(self):
        return [model.id for model in self.client.models.list().data]

    def complete(self, messages, tools, cancel, emit=lambda *args: None):
        if cancel.is_set():
            raise AssistantError("CANCELLED", "Stopped.")
        kwargs = {"model": self.settings.model, "messages": messages, "stream": self.settings.streaming,
                  self.settings.token_parameter: self.settings.max_tokens}
        if tools:
            kwargs.update(tools=tools, tool_choice="auto")
        response = self.client.chat.completions.create(**kwargs)
        if not self.settings.streaming:
            if cancel.is_set():
                raise AssistantError("CANCELLED", "Stopped.")
            if not response.choices:
                raise AssistantError("MODEL_ERROR", "Server returned no completion choices.")
            choice = response.choices[0]
            if choice.finish_reason == "length":
                raise AssistantError("OUTPUT_LIMIT", "Model output was truncated; increase the output limit.")
            message = choice.message.model_dump(exclude_none=True)
            message = {k: v for k, v in message.items() if k in {"role", "content", "tool_calls"}}
            emit("text_delta", message.get("content") or "")
            if response.usage:
                emit("usage", response.usage.model_dump())
            return message
        with self._lock:
            self._stream = response
        content, calls, finish = [], {}, None
        try:
            for chunk in response:
                if cancel.is_set():
                    raise AssistantError("CANCELLED", "Stopped.")
                if not chunk.choices:
                    continue
                choice = chunk.choices[0]
                finish = choice.finish_reason or finish
                delta = choice.delta
                if delta.content:
                    content.append(delta.content)
                    emit("text_delta", delta.content)
                for tool in delta.tool_calls or []:
                    call = calls.setdefault(tool.index, {"id": "", "type": "function", "function": {"name": "", "arguments": ""}})
                    if tool.id:
                        call["id"] += tool.id
                    if tool.function:
                        call["function"]["name"] += tool.function.name or ""
                        call["function"]["arguments"] += tool.function.arguments or ""
            if cancel.is_set():
                raise AssistantError("CANCELLED", "Stopped.")
            if finish == "length":
                raise AssistantError("OUTPUT_LIMIT", "Output was truncated; no tool calls were executed.")
            if finish is None:
                raise AssistantError("STREAM_INTERRUPTED", "Stream ended without a completion marker; no calls executed.")
            return {"role": "assistant", "content": "".join(content) or None,
                    **({"tool_calls": [calls[i] for i in sorted(calls)]} if calls else {})}
        finally:
            response.close()
            with self._lock:
                self._stream = None

    def probe(self, cancel, emit=lambda *args: None):
        tool = {"type": "function", "function": {"name": "connection_echo", "description": "Return the requested test value.",
                "parameters": {"type": "object", "properties": {"value": {"type": "string"}}, "required": ["value"], "additionalProperties": False}}}
        messages = [{"role": "user", "content": "Call connection_echo with value SAKIR_CONNECTION_OK. Do not answer without calling it."}]
        reply = self.complete(messages, [tool], cancel, emit)
        calls = reply.get("tool_calls") or []
        if len(calls) != 1 or calls[0]["function"]["name"] != "connection_echo" or not calls[0].get("id"):
            raise AssistantError("TOOLS_UNSUPPORTED", "Model/server did not return a structured test tool call.")
        if json.loads(calls[0]["function"]["arguments"]) != {"value": "SAKIR_CONNECTION_OK"}:
            raise AssistantError("TOOLS_UNSUPPORTED", "Test tool arguments were incorrect.")
        messages.extend([reply, {"role": "tool", "tool_call_id": calls[0]["id"], "content": '{"result":"SAKIR_CONNECTION_OK"}'}])
        messages.append({"role": "user", "content": "Report the result of the tool in your final answer; do not call it again."})
        final = self.complete(messages, [], cancel, emit)
        if "SAKIR_CONNECTION_OK" not in (final.get("content") or ""):
            raise AssistantError("TOOLS_UNSUPPORTED", "Model did not consume the tool result correctly.")
        return {"base_url": self.settings.base_url, "model": self.settings.model,
                "tool_round_trip": True, "streaming": self.settings.streaming}
