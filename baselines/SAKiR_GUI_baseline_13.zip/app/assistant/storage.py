"""Application-local Assistant settings, history, proposals, and recovery state."""
from dataclasses import asdict, dataclass, fields
import json
import os
from pathlib import Path
import tempfile
from urllib.parse import urlsplit

from .policy import AssistantError


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".assistant-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@dataclass
class Settings:
    base_url: str = ""
    model: str = ""
    auth_mode: str = "none"
    key_env: str = "SAKIR_ASSISTANT_API_KEY"
    credential_ref: str = ""
    timeout: int = 60
    streaming: bool = True
    max_tokens: int = 4096
    token_parameter: str = "max_tokens"
    context_chars: int = 96000
    max_rounds: int = 20
    max_tool_calls: int = 40
    task_timeout: int = 600
    file_timeout: int = 30
    preview_rows: int = 50
    result_chars: int = 60000
    save_history: bool = True
    history_sessions: int = 20
    ca_bundle: str = ""
    capability_profile: dict = None

    def validate(self, connection=True):
        for key in ("base_url", "model", "auth_mode", "key_env", "credential_ref", "ca_bundle"):
            if not isinstance(getattr(self, key), str):
                raise AssistantError("SETTINGS_INVALID", f"{key} must be text.")
        if type(self.streaming) is not bool or type(self.save_history) is not bool:
            raise AssistantError("SETTINGS_INVALID", "Streaming/history preferences must be booleans.")
        if self.capability_profile is not None and not isinstance(self.capability_profile, dict):
            raise AssistantError("SETTINGS_INVALID", "Compatibility profile must be an object or null.")
        url = urlsplit(self.base_url)
        if connection and (url.scheme not in {"http", "https"} or not url.hostname or not self.model.strip()):
            raise AssistantError("SETTINGS_INVALID", "Enter a server base URL and model ID.")
        if url.username or url.password or url.query or url.fragment:
            raise AssistantError("SETTINGS_INVALID", "Do not embed credentials, queries or fragments in the server URL.")
        if self.auth_mode not in {"none", "session", "environment", "windows"}:
            raise AssistantError("SETTINGS_INVALID", "Unknown authentication mode.")
        if self.token_parameter not in {"max_tokens", "max_completion_tokens"}:
            raise AssistantError("SETTINGS_INVALID", "Unsupported token limit parameter.")
        for key, low, high in (("timeout", 5, 600), ("max_tokens", 256, 65536), ("context_chars", 8000, 2000000),
                               ("max_rounds", 1, 40), ("max_tool_calls", 1, 100), ("task_timeout", 30, 3600),
                               ("file_timeout", 1, 120), ("preview_rows", 1, 200), ("result_chars", 1000, 64000),
                               ("history_sessions", 1, 100)):
            if type(getattr(self, key)) is not int or not low <= getattr(self, key) <= high:
                raise AssistantError("SETTINGS_INVALID", f"Invalid {key}.")


class Store:
    def __init__(self, root):
        root = Path(root).resolve()
        self.private = root / "app" / "data" / "assistant"
        self.settings_path = self.private / "assistant.json"

    def load_settings(self):
        try:
            data = json.loads(self.settings_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return Settings()
        except (ValueError, OSError) as exc:
            raise AssistantError("SETTINGS_INVALID", f"Cannot read assistant.json: {exc}") from exc
        if not isinstance(data, dict):
            raise AssistantError("SETTINGS_INVALID", "assistant.json must contain an object.")
        settings = Settings(**{f.name: data[f.name] for f in fields(Settings) if f.name in data})
        settings.validate(connection=False)
        return settings

    def save_settings(self, settings):
        settings.validate(connection=False)
        atomic_json(self.settings_path, asdict(settings))

    def save_session(self, session_id, messages, settings):
        if settings.save_history:
            atomic_json(self.private / "history" / f"{session_id}.json", messages)
            paths = sorted((self.private / "history").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for path in paths[settings.history_sessions:]:
                path.unlink()

    def sessions(self):
        paths = sorted((self.private / "history").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        result = []
        for path in paths:
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(value, list) and all(isinstance(m, dict) and m.get("role") in {"user", "assistant"} and isinstance(m.get("content"), str) for m in value):
                    result.append((path.stem, value))
            except (ValueError, OSError):
                continue
        return result

    def clear_history(self):
        for path in (self.private / "history").glob("*.json"):
            path.unlink()


class Credentials:
    """Credential Manager or session-only secrets. Never serialized into JSON."""
    def __init__(self):
        self.session = ""

    def key(self, settings):
        if settings.auth_mode == "none":
            return "local-no-auth"
        if settings.auth_mode == "session":
            value = self.session
        elif settings.auth_mode == "environment":
            value = os.environ.get(settings.key_env, "")
        else:
            value = self._windows(settings.credential_ref)
        if not value:
            raise AssistantError("AUTH_REQUIRED", "Enter a session key or configure a credential in Settings.")
        return value

    @staticmethod
    def _windows(target, secret=None):
        if os.name != "nt":
            raise AssistantError("AUTH_REQUIRED", "Windows Credential Manager is unavailable.")
        import ctypes
        from ctypes import wintypes as w
        class Credential(ctypes.Structure):
            _fields_ = [("Flags", w.DWORD), ("Type", w.DWORD), ("TargetName", w.LPWSTR),
                        ("Comment", w.LPWSTR), ("LastWritten", w.FILETIME), ("CredentialBlobSize", w.DWORD),
                        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)), ("Persist", w.DWORD),
                        ("AttributeCount", w.DWORD), ("Attributes", ctypes.c_void_p),
                        ("TargetAlias", w.LPWSTR), ("UserName", w.LPWSTR)]
        api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
        api.CredReadW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.POINTER(ctypes.POINTER(Credential))]
        api.CredWriteW.argtypes = [ctypes.POINTER(Credential), w.DWORD]
        api.CredFree.argtypes = [ctypes.c_void_p]
        if secret is not None:
            blob = (ctypes.c_ubyte * len(secret.encode("utf-16-le"))).from_buffer_copy(secret.encode("utf-16-le"))
            entry = Credential(Type=1, TargetName=target, CredentialBlobSize=len(blob), CredentialBlob=blob,
                               Persist=2, UserName="SAKiR Assistant")
            if not api.CredWriteW(ctypes.byref(entry), 0):
                raise ctypes.WinError(ctypes.get_last_error())
            return secret
        pointer = ctypes.POINTER(Credential)()
        if not api.CredReadW(target, 1, 0, ctypes.byref(pointer)):
            return ""
        try:
            return ctypes.string_at(pointer.contents.CredentialBlob, pointer.contents.CredentialBlobSize).decode("utf-16-le")
        finally:
            api.CredFree(pointer)
