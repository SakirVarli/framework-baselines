"""Static, revision-aware source retrieval; indexing never imports project code."""
import ast
import json
from pathlib import Path
import re

from .policy import AssistantError, digest, redact


class SourceIndex:
    def __init__(self, policy):
        self.policy = policy
        self.cache = {}

    def files(self):
        paths = [self.policy.root / "README.md"] if (self.policy.root / "README.md").is_file() else []
        for directory in ("app", "callbacks", "externals", "examples", "tests"):
            for path in (self.policy.root / directory).rglob("*"):
                if path.suffix.lower() in {".py", ".md", ".json"}:
                    try:
                        self.policy.path(path.relative_to(self.policy.root))
                        if path.stat().st_size <= 2_000_000:
                            paths.append(path)
                    except (AssistantError, OSError):
                        pass
        return paths

    def read(self, path, start=1, count=160):
        target = self.policy.path(path)
        if target.stat().st_size > 2_000_000:
            raise AssistantError("FILE_TOO_LARGE", "Use a bounded data reader for this file.")
        raw = target.read_bytes()
        source = raw.decode("utf-8-sig")
        if target.suffix.lower() == ".json":
            source = json.dumps(redact(json.loads(source)), ensure_ascii=False, indent=2)
        else:
            source = redact(source)
        lines = source.splitlines()
        start, count = max(1, int(start)), min(250, max(1, int(count)))
        return {"path": str(path), "sha256": digest(raw), "start_line": start, "total_lines": len(lines),
                "text": "\n".join(f"{i+1}: {line}" for i, line in enumerate(lines) if start <= i+1 < start+count),
                "truncated": len(lines) >= start+count}

    def symbols(self):
        result = []
        current = set()
        for path in self.files():
            if path.suffix != ".py":
                continue
            relative = path.relative_to(self.policy.root).as_posix()
            current.add(relative)
            raw = path.read_bytes()
            stamp = digest(raw)
            if relative not in self.cache or self.cache[relative][0] != stamp:
                entries = []
                try:
                    tree = ast.parse(raw.decode("utf-8-sig"))
                    for node in ast.walk(tree):
                        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                            entries.append({"name": node.name, "path": relative, "line": node.lineno,
                                            "signature": ast.unparse(node.args) if hasattr(node, "args") else "",
                                            "summary": redact(ast.get_docstring(node) or "")[:500]})
                except (SyntaxError, UnicodeError):
                    pass
                self.cache[relative] = (stamp, entries)
            result.extend(self.cache[relative][1])
        self.cache = {k: v for k, v in self.cache.items() if k in current}
        return result

    def search(self, query, limit=20):
        terms = re.findall(r"[a-z0-9_]+", query.lower())
        hits = []
        for item in self.symbols():
            haystack = " ".join(map(str, item.values())).lower()
            score = sum((5 if t in item["name"].lower() else 1) for t in terms if t in haystack)
            if score:
                hits.append((score, item))
        return [item for _, item in sorted(hits, key=lambda p: -p[0])[:min(40, limit)]]

    def catalog(self):
        from app.config_designer.schema import FEATURES
        groups = {
            "Layout and widgets": "app/config_designer/", "Callback APIs and inputs": "app/stubs.py",
            "Outputs and tables": "app/output_widgets.py", "Globals": "app/globals_api.py",
            "Lifecycle": "app/lifecycle.py", "Connection tools": "app/tool_api.py",
            "Communication and Protocol Insights": "app/tools/communication_hub/",
            "Binary messages": "app/binary_messages/", "Message Designer": "app/tools/message_designer/",
            "Reload": "app/source_reload.py", "Build": "app/builder.py", "VS Code": "app/vscode_integration.py",
            "Upgrade": "app/upgrade_manager.py"}
        return {"widgets": redact(FEATURES), "groups": groups,
                "symbols": [s for s in self.symbols() if not s["name"].startswith("_")]}
