"""Native PyQt assistant, connection settings, capability browser and review."""
import copy
from dataclasses import asdict
import html
import json
from pathlib import Path
import threading

from PyQt5 import QtCore, QtGui, QtWidgets

from . import changes
from .policy import AssistantError, digest, redact
from .provider import ChatProvider
from .storage import Settings


def show_error(parent, exc):
    QtWidgets.QMessageBox.warning(parent, "Assistant", str(exc))


class SettingsDialog(QtWidgets.QDialog):
    probe_finished = QtCore.pyqtSignal(object)

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Assistant Settings")
        self.resize(690, 650)
        self.widgets = {}
        self.profile = copy.deepcopy(controller.settings.capability_profile)
        self.cancel = threading.Event()
        self.provider = None
        outer = QtWidgets.QVBoxLayout(self)
        notice = QtWidgets.QLabel("Configuration: app/data/assistant/assistant.json\nAssistant files stay inside this framework folder.")
        notice.setWordWrap(True)
        outer.addWidget(notice)
        tabs = QtWidgets.QTabWidget()
        outer.addWidget(tabs)
        connection, limits, privacy = [QtWidgets.QWidget() for _ in range(3)]
        tabs.addTab(connection, "Connection")
        tabs.addTab(limits, "Limits && Compatibility")
        tabs.addTab(privacy, "History && Permissions")
        conn = QtWidgets.QFormLayout(connection)
        self.text(conn, "base_url", "Server base URL", "http://server:8000/v1")
        self.text(conn, "model", "Model ID", "Exact ID returned by your server")
        self.combo(conn, "auth_mode", "Authentication", [("No authentication", "none"), ("Session key", "session"),
                   ("Environment variable", "environment"), ("Windows Credential Manager", "windows")])
        self.key = QtWidgets.QLineEdit(controller.credentials.session)
        self.key.setEchoMode(QtWidgets.QLineEdit.Password)
        self.key.setPlaceholderText("Enter a key; never written to assistant.json")
        conn.addRow("API key", self.key)
        self.text(conn, "key_env", "Key environment variable")
        self.text(conn, "credential_ref", "Windows credential reference", "Auto-generated when a key is saved")
        self.text(conn, "ca_bundle", "Custom CA certificate", "Optional path to a trusted CA PEM file")
        self.check(conn, "streaming", "Stream responses")
        probe_row = QtWidgets.QWidget()
        buttons = QtWidgets.QHBoxLayout(probe_row)
        self.list_button = QtWidgets.QPushButton("List models")
        self.probe_button = QtWidgets.QPushButton("Test tools && streaming")
        buttons.addWidget(self.list_button)
        buttons.addWidget(self.probe_button)
        conn.addRow(probe_row)
        self.models = QtWidgets.QComboBox()
        self.models.setPlaceholderText("Models returned by the server")
        self.models.activated.connect(lambda i: self.widgets["model"].setText(self.models.itemText(i)))
        conn.addRow("Discovered models", self.models)
        self.probe_status = QtWidgets.QPlainTextEdit()
        self.probe_status.setReadOnly(True)
        self.probe_status.setMaximumHeight(140)
        self.probe_status.setPlainText(json.dumps(self.profile, indent=2) if self.profile else "Connection not tested yet. Model IDs can also be entered manually.")
        conn.addRow("Compatibility", self.probe_status)
        form = QtWidgets.QFormLayout(limits)
        self.combo(form, "token_parameter", "Output limit parameter", [("max_tokens", "max_tokens"), ("max_completion_tokens", "max_completion_tokens")])
        for key, label, low, high in (("timeout", "Request timeout (seconds)", 5, 600), ("max_tokens", "Maximum output tokens", 256, 65536),
                                    ("context_chars", "Context budget (characters)", 8000, 2000000), ("max_rounds", "Maximum model rounds", 1, 40),
                                    ("max_tool_calls", "Maximum tool calls", 1, 100), ("task_timeout", "Task deadline (seconds)", 30, 3600),
                                    ("file_timeout", "File-reader timeout (seconds)", 1, 120), ("preview_rows", "Preview rows", 1, 200),
                                    ("result_chars", "Tool-result character limit", 1000, 64000)):
            spin = QtWidgets.QSpinBox()
            spin.setRange(low, high)
            spin.setValue(getattr(controller.settings, key))
            self.widgets[key] = spin
            form.addRow(label, spin)
        hint = QtWidgets.QLabel("Context is measured conservatively in characters. Server token limits still apply.\nDisable streaming if your server supports tools only in complete responses.")
        hint.setWordWrap(True)
        form.addRow(hint)
        form = QtWidgets.QFormLayout(privacy)
        self.check(form, "save_history", "Save visible conversation history locally")
        spin = QtWidgets.QSpinBox()
        spin.setRange(1, 100)
        spin.setValue(controller.settings.history_sessions)
        self.widgets["history_sessions"] = spin
        form.addRow("Retained sessions", spin)
        private = QtWidgets.QLabel(str(controller.store.private))
        private.setWordWrap(True)
        private.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        form.addRow("Assistant data folder", private)
        clear = QtWidgets.QPushButton("Delete conversation history")
        clear.clicked.connect(self.clear_history)
        form.addRow(clear)
        policy = QtWidgets.QLabel("Framework Python: read only\nCallbacks and externals: previewed project edits\nConfiguration JSON: validated edits\nGenerated stubs: maintained by the framework\nNo shell or arbitrary code execution tool\nApply & Reload executes reviewed project Python.\nAssistant data is excluded from baseline exports.\nOnly attached external files can be inspected outside the project.")
        policy.setWordWrap(True)
        form.addRow("Permissions", policy)
        self.buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.save)
        self.buttons.rejected.connect(self.reject)
        outer.addWidget(self.buttons)
        self.list_button.clicked.connect(lambda: self.test("models"))
        self.probe_button.clicked.connect(lambda: self.test("probe"))
        self.probe_finished.connect(self.test_finished)
        self.finished.connect(self.stop_probe)
        self.widgets["auth_mode"].currentIndexChanged.connect(self.update_auth)
        self.update_auth()

    def update_auth(self, *_):
        mode = self.widgets["auth_mode"].currentData()
        self.key.setEnabled(mode in {"session", "windows"})
        self.widgets["key_env"].setEnabled(mode == "environment")
        self.widgets["credential_ref"].setEnabled(mode == "windows")

    def text(self, form, key, label, placeholder=""):
        widget = QtWidgets.QLineEdit(getattr(self.controller.settings, key))
        widget.setPlaceholderText(placeholder)
        self.widgets[key] = widget
        form.addRow(label, widget)

    def combo(self, form, key, label, items):
        widget = QtWidgets.QComboBox()
        for title, value in items:
            widget.addItem(title, value)
        widget.setCurrentIndex(max(0, widget.findData(getattr(self.controller.settings, key))))
        self.widgets[key] = widget
        form.addRow(label, widget)

    def check(self, form, key, label):
        widget = QtWidgets.QCheckBox(label)
        widget.setChecked(getattr(self.controller.settings, key))
        self.widgets[key] = widget
        form.addRow(widget)

    def collect(self):
        data = asdict(self.controller.settings)
        for key, widget in self.widgets.items():
            data[key] = widget.currentData() if isinstance(widget, QtWidgets.QComboBox) else widget.isChecked() if isinstance(widget, QtWidgets.QCheckBox) else widget.value() if isinstance(widget, QtWidgets.QSpinBox) else widget.text().strip()
        data["capability_profile"] = self.profile
        return Settings(**data)

    def key_for(self, settings, save=False):
        if settings.auth_mode == "session":
            self.controller.credentials.session = self.key.text()
        elif settings.auth_mode == "windows" and self.key.text():
            if not save:
                return self.key.text()
            settings.credential_ref = settings.credential_ref or "SAKiR-Assistant-" + digest(settings.base_url.encode())[:24]
            self.controller.credentials._windows(settings.credential_ref, self.key.text())
        return self.controller.credentials.key(settings)

    def save(self):
        try:
            settings = self.collect()
            settings.validate(connection=bool(settings.base_url or settings.model))
            if settings.auth_mode in {"session", "windows"}:
                self.key_for(settings, save=True)
            profile = settings.capability_profile
            if profile and (profile.get("model"), profile.get("base_url"), profile.get("streaming")) != (settings.model, settings.base_url, settings.streaming):
                settings.capability_profile = None
            self.controller.store.save_settings(settings)
            self.controller.settings = settings
            self.controller.settings_error = ""
            self.controller.event.emit("settings", settings.model)
            self.accept()
        except Exception as exc:
            show_error(self, exc)

    def test(self, kind):
        try:
            settings = self.collect()
            if kind == "models" and not settings.model:
                settings.model = "discovery"
            settings.validate()
            key = self.key_for(settings)
        except Exception as exc:
            show_error(self, exc)
            return
        self.cancel = threading.Event()
        self.list_button.setEnabled(False)
        self.probe_button.setEnabled(False)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(False)
        self.probe_status.setPlainText("Checking the configured server…")
        def worker():
            try:
                self.provider = ChatProvider(settings, key)
                data = self.provider.models() if kind == "models" else self.provider.probe(self.cancel)
                result = {"kind": kind, "data": data}
            except Exception as exc:
                result = {"error": str(exc).replace(key, "<redacted>"), "code": getattr(exc, "code", "CONNECTION_ERROR"),
                          "profile": {"base_url": settings.base_url, "model": settings.model,
                                      "streaming": settings.streaming, "tool_round_trip": False}}
            finally:
                if self.provider:
                    try:
                        self.provider.dispose()
                    except Exception:
                        pass
                self.provider = None
            try:
                self.probe_finished.emit(result)
            except RuntimeError:
                pass
        threading.Thread(target=worker, daemon=True, name="assistant-connection-test").start()

    def test_finished(self, result):
        self.list_button.setEnabled(True)
        self.probe_button.setEnabled(True)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(True)
        self.probe_status.setPlainText(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("kind") == "models":
            self.models.clear()
            self.models.addItems(result["data"])
        elif result.get("kind") == "probe":
            self.profile = result["data"]
        elif result.get("code") == "TOOLS_UNSUPPORTED":
            self.profile = result["profile"]

    def stop_probe(self, *_):
        self.cancel.set()
        if self.provider:
            threading.Thread(target=self.provider.close, daemon=True).start()

    def clear_history(self):
        self.controller.store.clear_history()
        self.controller.new_session()
        self.probe_status.setPlainText("Conversation history deleted. Recovery journals retained.")


class Composer(QtWidgets.QPlainTextEdit):
    send_requested = QtCore.pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter) and not event.modifiers() & QtCore.Qt.ShiftModifier:
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


class ReviewDialog(QtWidgets.QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.proposal = controller.proposal
        self.setWindowTitle("Review Assistant Changes")
        self.resize(1050, 750)
        outer = QtWidgets.QVBoxLayout(self)
        report, diff = controller.review()
        tabs = QtWidgets.QTabWidget()
        outer.addWidget(tabs)
        summary = QtWidgets.QPlainTextEdit()
        summary.setReadOnly(True)
        summary.setPlainText(self.proposal.summary + "\n\nAffected files:\n" + "\n".join(e.path for e in self.proposal.edits)
                             + "\n\nThe diff includes any existing unsaved designer work.\nApply & Reload saves these files and reloads project Python.")
        tabs.addTab(summary, "Summary")
        code = QtWidgets.QPlainTextEdit()
        code.setReadOnly(True)
        code.setFont(QtGui.QFont("Consolas", 10))
        code.setPlainText(diff)
        tabs.addTab(code, "Code && Configuration Diff")
        validation = QtWidgets.QPlainTextEdit()
        validation.setReadOnly(True)
        validation.setPlainText("Checks:\n" + "\n".join(report["checks"]) + "\n\n" + ("No blocking errors." if report["ok"] else "Apply blocked.")
                                + "\n" + "\n".join(i["severity"].upper() + ": " + i["message"] for i in report["issues"]))
        tabs.addTab(validation, "Validation")
        row = QtWidgets.QHBoxLayout()
        preview = QtWidgets.QPushButton("Layout Preview")
        preview.clicked.connect(self.preview)
        row.addWidget(preview)
        row.addStretch()
        for label, reload in (("Save Only", False), ("Apply && Reload", True)):
            button = QtWidgets.QPushButton(label)
            button.setEnabled(report["ok"] and not controller.busy)
            button.clicked.connect(lambda _, reload=reload: self.apply(reload))
            row.addWidget(button)
        close = QtWidgets.QPushButton("Close")
        close.clicked.connect(self.reject)
        row.addWidget(close)
        outer.addLayout(row)

    def preview(self):
        from app.config_designer.document import DesignerDocument
        from app.config_designer.window import PreviewDialog
        config = self.controller.snapshot()["config"]
        for edit in self.proposal.edits:
            if edit.path == "app/data/config.json":
                config = json.loads(edit.content)
        PreviewDialog(DesignerDocument.from_config(config), self).exec_()

    def apply(self, reload):
        try:
            if self.controller.proposal is not self.proposal:
                raise AssistantError("STALE_PROPOSAL", "A new proposal replaced this review.")
            self.controller.apply(self.proposal.fingerprint, reload)
            self.accept()
        except Exception as exc:
            show_error(self, exc)


class AssistantWindow(QtWidgets.QMainWindow):
    def __init__(self, controller):
        # A QWidget parent creates a native owner on Windows, which excludes
        # the window from normal task switching. The controller owns lifetime.
        super().__init__(None, QtCore.Qt.Window)
        self.setWindowTitle("SAKiR Assistant")
        self.setObjectName("sakirAssistantWindow")
        self.setWindowIcon(controller.window.windowIcon())
        self.setAttribute(QtCore.Qt.WA_QuitOnClose, False)
        self.controller = controller
        self.resize(900, 760)
        self.setMinimumSize(680, 500)
        self.visible_messages = copy.deepcopy(controller.history)
        self.streaming_text = ""
        self.data_preview = None
        content = QtWidgets.QWidget()
        self.setCentralWidget(content)
        outer = QtWidgets.QVBoxLayout(content)
        head = QtWidgets.QHBoxLayout()
        self.model = QtWidgets.QLabel(controller.settings.model or "Configure a local model")
        self.model.setTextFormat(QtCore.Qt.PlainText)
        head.addWidget(self.model, 1)
        settings = QtWidgets.QPushButton("Settings")
        settings.clicked.connect(self.settings)
        head.addWidget(settings)
        outer.addLayout(head)
        actions = QtWidgets.QHBoxLayout()
        for label, method in (("New", self.new), ("History", self.history), ("Drafts", self.drafts), ("Capabilities", self.capabilities)):
            button = QtWidgets.QPushButton(label)
            button.clicked.connect(method)
            actions.addWidget(button)
        outer.addLayout(actions)
        self.conversation = QtWidgets.QTextBrowser()
        self.conversation.setAccessibleName("Assistant conversation")
        self.conversation.setOpenExternalLinks(False)
        self.conversation.setOpenLinks(False)
        self.conversation.anchorClicked.connect(self.open_source)
        outer.addWidget(self.conversation, 1)
        self.status = QtWidgets.QLabel(("Settings need repair: " + controller.settings_error) if controller.settings_error else "Ready")
        self.status.setTextFormat(QtCore.Qt.PlainText)
        self.status.setWordWrap(True)
        outer.addWidget(self.status)
        self.context_label = QtWidgets.QLabel(controller.selection or "Context: current project")
        self.context_label.setTextFormat(QtCore.Qt.PlainText)
        self.context_label.setWordWrap(True)
        outer.addWidget(self.context_label)
        review_row = QtWidgets.QHBoxLayout()
        self.review_button = QtWidgets.QPushButton("Review Changes")
        self.review_button.setEnabled(controller.proposal is not None)
        self.review_button.clicked.connect(self.review)
        self.action_button = QtWidgets.QPushButton("Review Action")
        self.action_button.setEnabled(controller.action is not None)
        self.action_button.clicked.connect(self.review_action)
        restore = QtWidgets.QPushButton("Restore Previous")
        restore.clicked.connect(self.restore)
        data = QtWidgets.QPushButton("Data Preview")
        data.clicked.connect(self.preview_data)
        for button in (self.review_button, self.action_button, restore, data):
            review_row.addWidget(button)
        outer.addLayout(review_row)
        self.attachments = QtWidgets.QListWidget()
        self.attachments.setMaximumHeight(65)
        self.attachments.setToolTip("Double-click to remove an attachment.")
        self.attachments.itemDoubleClicked.connect(self.remove_attachment)
        outer.addWidget(self.attachments)
        self.sync_attachments(sorted(map(str, controller.policy.attachments)))
        self.input = Composer()
        self.input.setAccessibleName("Assistant request")
        self.input.setPlaceholderText("Ask about the framework or describe a change…\nEnter sends · Shift+Enter adds a line")
        self.input.setMaximumHeight(110)
        self.input.send_requested.connect(self.send)
        outer.addWidget(self.input)
        footer = QtWidgets.QHBoxLayout()
        attach = QtWidgets.QPushButton("Attach Files")
        attach.clicked.connect(self.attach)
        footer.addWidget(attach)
        self.intent = QtWidgets.QComboBox()
        self.intent.addItems(["Explain / Inspect", "Create Changes"])
        footer.addWidget(self.intent)
        self.send_button = QtWidgets.QPushButton("Send")
        self.send_button.clicked.connect(self.send)
        self.stop_button = QtWidgets.QPushButton("Stop")
        self.stop_button.clicked.connect(controller.stop)
        self.stop_button.setEnabled(controller.busy)
        footer.addWidget(self.send_button)
        footer.addWidget(self.stop_button)
        outer.addLayout(footer)
        controller.event.connect(self.on_event)
        controller.busy_changed.connect(self.busy)
        controller.proposal_changed.connect(lambda p: self.review_button.setEnabled(p is not None and not controller.busy))
        controller.action_changed.connect(lambda a: self.action_button.setEnabled(a is not None and not controller.busy))
        controller.attachments_changed.connect(self.sync_attachments)
        self.busy(controller.busy)
        self.paint_timer = QtCore.QTimer(self)
        self.paint_timer.setInterval(80)
        self.paint_timer.timeout.connect(self.render)
        self.paint_timer.start()
        self._rendered = None
        self.render()

    def showEvent(self, event):
        super().showEvent(event)
        self.paint_timer.start()
        self.render()

    def hideEvent(self, event):
        self.paint_timer.stop()
        super().hideEvent(event)

    def render(self):
        fingerprint = repr(self.visible_messages) + self.streaming_text
        if fingerprint == self._rendered:
            return
        self._rendered = fingerprint
        parts = []
        for message in self.visible_messages + ([{"role": "assistant", "content": self.streaming_text}] if self.streaming_text else []):
            text = html.escape(message["content"])
            try:
                import markdown2
                # Escaped raw HTML prevents model-generated active HTML/resources.
                text = markdown2.markdown(text, extras=["fenced-code-blocks", "tables"])
                import re
                text = re.sub(r"<img\b[^>]*>", "", text, flags=re.I)
            except ImportError:
                text = "<pre>" + text + "</pre>"
            parts.append("<p><b>" + html.escape(message["role"].title()) + "</b></p>" + text)
        self.conversation.setHtml("<html><body>" + "<hr>".join(parts) + "</body></html>")
        bar = self.conversation.verticalScrollBar()
        bar.setValue(bar.maximum())

    def open_source(self, url):
        if url.scheme() != "sakir-source":
            return
        try:
            start = int(url.fragment().lstrip("L") or "1")
            data = self.controller.index.read(url.path(), start, 120)
            dialog = QtWidgets.QDialog(self)
            dialog.setWindowTitle(data["path"] + ":" + str(start))
            dialog.resize(950, 650)
            layout = QtWidgets.QVBoxLayout(dialog)
            source = QtWidgets.QPlainTextEdit()
            source.setReadOnly(True)
            source.setFont(QtGui.QFont("Consolas", 10))
            source.setPlainText(data["text"])
            layout.addWidget(source)
            dialog.exec_()
        except Exception as exc:
            show_error(self, exc)

    def on_event(self, kind, value):
        if kind == "user":
            self.visible_messages.append({"role": "user", "content": value})
            self.streaming_text = ""
        elif kind == "text_delta":
            self.streaming_text += value
        elif kind == "finished":
            if self.streaming_text:
                self.visible_messages.append({"role": "assistant", "content": self.streaming_text})
            self.streaming_text = ""
        elif kind in {"status", "error"}:
            self.status.setText(value)
            if kind == "error":
                if self.streaming_text:
                    self.visible_messages.append({"role": "assistant", "content": self.streaming_text})
                    self.streaming_text = ""
                self.visible_messages.append({"role": "error", "content": value})
        elif kind == "tool_result" and value["tool"] == "inspect_file" and value["result"].get("ok"):
            self.data_preview = value["result"]["data"]
        elif kind == "session":
            self.visible_messages = value
            self.streaming_text = ""
        elif kind == "selection":
            self.context_label.setText(value or "Context: current project")
        elif kind == "settings":
            self.model.setText(value or "Configure a local model")
            self.status.setText("Ready")
        self.render()

    def busy(self, value):
        self.send_button.setEnabled(not value)
        self.stop_button.setEnabled(value)
        self.review_button.setEnabled(not value and self.controller.proposal is not None)
        self.action_button.setEnabled(not value and self.controller.action is not None)

    def send(self):
        text = self.input.toPlainText().strip()
        if not text:
            return
        try:
            self.controller.submit(text, self.intent.currentIndex() == 1)
            self.input.clear()
        except Exception as exc:
            show_error(self, exc)

    def settings(self):
        if self.controller.busy:
            show_error(self, "Stop the active task before changing the connection.")
            return
        SettingsDialog(self.controller, self).exec_()
        self.model.setText(self.controller.settings.model or "Configure a local model")

    def new(self):
        try:
            self.controller.new_session()
        except Exception as exc:
            show_error(self, exc)

    def history(self):
        try:
            sessions = self.controller.store.sessions()
            labels = [str(i+1) + ". " + (messages[0].get("content", "Empty")[:70] if messages else "Empty") for i, (_, messages) in enumerate(sessions)]
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Conversation History", "Session", labels, 0, False)
            if ok:
                key, messages = sessions[labels.index(choice)]
                self.controller.new_session(messages, key)
        except Exception as exc:
            show_error(self, exc)

    def drafts(self):
        try:
            drafts = self.controller.drafts()
            labels = [str(i+1) + ". " + p.summary[:90] for i, p in enumerate(drafts)]
            if not labels:
                show_error(self, "No saved proposal drafts yet.")
                return
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Saved Proposal Drafts", "Draft (revalidated against the current project)", labels, 0, False)
            if ok:
                self.controller.load_draft(drafts[labels.index(choice)])
                self.review()
        except Exception as exc:
            show_error(self, exc)

    def attach(self):
        files, _ = QtWidgets.QFileDialog.getOpenFileNames(self, "Attach Data or Source", str(self.controller.policy.root / "externals"))
        for filename in files:
            try:
                path = self.controller.policy.attach(filename)
                if not self.attachments.findItems(path, QtCore.Qt.MatchExactly):
                    self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))
            except Exception as exc:
                show_error(self, exc)

    def remove_attachment(self, item):
        self.controller.policy.attachments.discard(Path(item.text()).resolve())
        self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))

    def sync_attachments(self, paths):
        self.attachments.clear()
        self.attachments.addItems(paths)
        self.attachments.setVisible(bool(paths))

    def capabilities(self):
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Framework Capabilities — Local Source")
        dialog.resize(950, 700)
        outer = QtWidgets.QVBoxLayout(dialog)
        search = QtWidgets.QLineEdit()
        search.setPlaceholderText("Filter symbols, properties and source paths…")
        outer.addWidget(search)
        splitter = QtWidgets.QSplitter()
        tree = QtWidgets.QTreeWidget()
        tree.setHeaderLabels(["Capability", "Source"])
        source = QtWidgets.QPlainTextEdit()
        source.setReadOnly(True)
        source.setFont(QtGui.QFont("Consolas", 10))
        splitter.addWidget(tree)
        splitter.addWidget(source)
        outer.addWidget(splitter)
        catalog = self.controller.index.catalog()
        for name, path in catalog["groups"].items():
            top = QtWidgets.QTreeWidgetItem(tree, [name, path])
            for entry in catalog["symbols"]:
                if entry["path"].startswith(path):
                    item = QtWidgets.QTreeWidgetItem(top, [entry["name"] + "(" + entry["signature"] + ")", entry["path"] + ":" + str(entry["line"])])
                    item.setData(0, QtCore.Qt.UserRole, entry)
        def selected(item):
            entry = item.data(0, QtCore.Qt.UserRole)
            if entry:
                source.setPlainText(self.controller.index.read(entry["path"], entry["line"], 100)["text"])
        tree.itemClicked.connect(lambda item, _: selected(item))
        def filter_items(text):
            for i in range(tree.topLevelItemCount()):
                top = tree.topLevelItem(i)
                visible = False
                for j in range(top.childCount()):
                    item = top.child(j)
                    match = text.lower() in (item.text(0) + item.text(1)).lower()
                    item.setHidden(not match)
                    visible |= match
                top.setHidden(not visible and text.lower() not in top.text(0).lower())
                top.setExpanded(bool(text))
        search.textChanged.connect(filter_items)
        dialog.exec_()

    def review(self):
        try:
            ReviewDialog(self.controller, self).exec_()
        except Exception as exc:
            show_error(self, exc)

    def restore(self):
        try:
            self.controller.restore()
            self.review()
        except Exception as exc:
            show_error(self, exc)

    def review_action(self):
        action = copy.deepcopy(self.controller.action)
        if not action:
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Review Session Action")
        dialog.resize(600, 420)
        layout = QtWidgets.QVBoxLayout(dialog)
        text = QtWidgets.QPlainTextEdit()
        text.setReadOnly(True)
        text.setPlainText(json.dumps({k: v for k, v in action.items() if k not in {"runtime_revision", "generation"}}, ensure_ascii=False, indent=2)
                          + "\n\nThis action affects the existing connection/device. File restore cannot undo a transmission.")
        layout.addWidget(text)
        run_button = QtWidgets.QPushButton("Run Action")
        def run_action():
            try:
                self.controller.run_action(digest(action))
                dialog.accept()
            except Exception as exc:
                show_error(dialog, exc)
        run_button.clicked.connect(run_action)
        layout.addWidget(run_button)
        dialog.exec_()

    def preview_data(self):
        if self.data_preview is None:
            show_error(self, "Ask the assistant to inspect a file first.")
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Inspected Data Preview")
        dialog.resize(850, 600)
        layout = QtWidgets.QVBoxLayout(dialog)
        if "rows" in self.data_preview and "columns" in self.data_preview:
            columns, rows = self.data_preview["columns"], self.data_preview["rows"]
            table = QtWidgets.QTableWidget(len(rows), len(columns))
            table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            table.setHorizontalHeaderLabels(columns)
            for i, row in enumerate(rows):
                for j, value in enumerate(row[:len(columns)]):
                    table.setItem(i, j, QtWidgets.QTableWidgetItem(str(value)))
            layout.addWidget(table)
        else:
            text = QtWidgets.QPlainTextEdit()
            text.setReadOnly(True)
            text.setPlainText(json.dumps(self.data_preview, ensure_ascii=False, indent=2))
            layout.addWidget(text)
        dialog.exec_()
