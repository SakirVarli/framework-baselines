"""Host-enforced file permissions; these are independent of model instructions."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat


class AssistantError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def digest(value):
    if not isinstance(value, bytes):
        value = json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def file_hash(path):
    return digest(path.read_bytes()) if path.is_file() else None


SECRET = re.compile(r"password|passwd|api[_-]?key|secret|token|credential", re.I)
PROTECTED = {"phase", "version", "build", "baseline", "baseline_number", "admin_password",
             "app_version_release_notes", "baseline_release_notes"}
CONFIGS = {"config.json", "serial.json", "telnet.json", "communication_hub.json",
           "ftp_client.json", "ftp_server.json"}


def redact(value):
    if isinstance(value, dict):
        return {k: "<redacted>" if SECRET.search(str(k)) else redact(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact(v) for v in value]
    if isinstance(value, str):
        return re.sub(r"(?i)((?:[a-z_]*password|passwd|api_key|secret|access_token)['\"]?\s*[:=]\s*)['\"][^'\"\n]*['\"]",
                      r'\1"<redacted>"', value)
    return value


def protected_values(value, path=()):
    found = {}
    if isinstance(value, dict):
        for key, item in value.items():
            location = path + (str(key),)
            if SECRET.search(str(key)):
                if item not in (None, "", [], {}):
                    found[location] = item
            elif path == ("window",) and key in PROTECTED:
                found[location] = item
            else:
                found.update(protected_values(item, location))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            identity = (item.get("id") or item.get("instance") or item.get("name") or str(i)) if isinstance(item, dict) else str(i)
            found.update(protected_values(item, path + (str(identity),)))
    return found


class ProjectPolicy:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.attachments = set()

    def attach(self, filename):
        path = Path(filename).resolve(strict=True)
        if not path.is_file():
            raise AssistantError("PATH_DENIED", "Attach a regular file.")
        self.attachments.add(path)
        return str(path)

    def path(self, name, write=False):
        name = str(name)
        # Reject Windows aliases on every platform, making policy tests portable.
        parts = name.replace("\\", "/").split("/")
        if any(re.match(r"(?i)^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", p) for p in parts):
            raise AssistantError("PATH_DENIED", "Reserved device paths are not allowed.")
        if any(p in {".."} or p.endswith((".", " ")) or ":" in p for p in parts if p):
            if not (not write and Path(name).is_absolute() and Path(name).resolve() in self.attachments):
                raise AssistantError("PATH_DENIED", "Traversal and aliased paths are not allowed.")
        path = Path(name) if Path(name).is_absolute() else self.root / name
        path = Path(os.path.abspath(path))
        for item in (path, *path.parents):
            if item == self.root.parent:
                break
            if item.exists() or item.is_symlink():
                info = item.lstat()
                if item.is_symlink() or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 1024):
                    raise AssistantError("PATH_DENIED", "Links and junctions are not supported.")
        path = path.resolve()
        if not write and path in self.attachments:
            return path
        try:
            rel = path.relative_to(self.root)
        except ValueError:
            raise AssistantError("PATH_DENIED", "Path is outside the project.") from None
        if not rel.parts or any(p.startswith(".") or p in {"__pycache__", "designer", "baselines", "dist", "build"} for p in rel.parts):
            raise AssistantError("PATH_DENIED", "Private or generated path.")
        if write:
            allowed = (rel.parts[0].lower() in {"callbacks", "externals"}
                       and path.suffix.lower() in {".py", ".json", ".txt", ".xml", ".csv", ".md"})
            allowed |= len(rel.parts) == 3 and tuple(p.lower() for p in rel.parts[:2]) == ("app", "data") and rel.name.lower() in CONFIGS
            if not allowed:
                raise AssistantError("PATH_DENIED", "Only callbacks, externals and approved configuration JSON can be edited.")
        else:
            if rel.parts[0].lower() not in {"app", "callbacks", "externals", "examples", "tests", "readme.md"}:
                raise AssistantError("PATH_DENIED", "Not part of the framework/project context.")
            if tuple(p.lower() for p in rel.parts[:2]) == ("app", "data") and (len(rel.parts) != 3 or rel.name.lower() not in CONFIGS):
                raise AssistantError("PATH_DENIED", "Private application metadata is excluded.")
            if path.suffix.lower() in {".zip", ".exe", ".vsix", ".pyc", ".log"}:
                raise AssistantError("PATH_DENIED", "Build artifacts and logs are excluded.")
        return path

    def validate_config(self, path, candidate, before):
        if not isinstance(candidate, dict):
            raise AssistantError("VALIDATION_FAILED", "Configuration must be an object.")
        if protected_values(candidate) != protected_values(before):
            raise AssistantError("PATH_DENIED", "Credentials and release/identity settings must remain unchanged.")
        if path.name == "communication_hub.json":
            from app.tools.communication_hub.config import validate_session_config
            for session in candidate.get("sessions", []):
                validate_session_config(session)
        if path.name in {"serial.json", "telnet.json"}:
            if not isinstance(candidate.get("sessions", []), list):
                raise AssistantError("VALIDATION_FAILED", "sessions must be a list.")
        return copy.deepcopy(candidate)
