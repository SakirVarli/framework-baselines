# Binary messages

`app.binary_messages` combines normal Python dataclasses with declarative
Construct schemas. Construct owns the binary layout; message classes own typed
state, validation, custom methods, properties, and runtime-only attributes.

## Define a message

```python
from dataclasses import dataclass
from typing import ClassVar

from construct import Bytes, Int8ub, Int16ul, Rebuild, Struct, len_, this

from app.binary_messages import BinaryMessage, runtime_field


@dataclass(slots=True)
class DataMessage(BinaryMessage):
    version: int
    payload: bytes
    source: str | None = runtime_field(default=None)

    WIRE_SCHEMA: ClassVar = Struct(
        "version" / Int8ub,
        "payload_length" / Rebuild(Int16ul, len_(this.payload)),
        "payload" / Bytes(this.payload_length),
    )

    def validate(self) -> None:
        if self.version != 1:
            raise ValueError("Unsupported version")
```

```python
message = DataMessage(version=1, payload=b"hello")
encoded = message.to_bytes()
decoded = DataMessage.from_bytes(encoded)
```

Nested dataclasses, enums, lists, tuples, sets, optional values, and renamed
wire fields are converted automatically. Override `from_wire()` or `to_wire()`
when a protocol needs a transformation that annotations cannot express.

## Runtime-only and renamed fields

Use `runtime_field()` for application state that must never be encoded. Use
`wire_field(name="wireName")` when the Python attribute and Construct field have
different names.

## Streams and files

`read_from()` and `write_to()` operate at the current position of an open
binary stream. `read_file()` and `write_file()` provide path-based helpers.
`decode()` rejects trailing data by default; pass `allow_trailing=True` only
when the caller intentionally owns framing.

## Message registries

`MessageRegistry` indexes `BinaryMessage` subclasses by their composite
`(MESSAGE_ID, DIRECTION)` identity and logical `MESSAGE_NAME`. TX and RX classes may
share an ID; an `ANY` class remains compatible with ID-only protocols. ID-only
lookup works when one class owns the ID and raises `AmbiguousMessageIdError`
when both directions exist. Pass `direction="TX"` or `direction="RX"` to explicit or
automatic decoding in that case. It provides explicit dispatch and,
when configured with `FixedIdExtractor`, automatic extraction from a shared
fixed header using offset, width, byte order, mask, and shift settings. Unknown
identities and missing extractor configuration raise dedicated exceptions.

## JSON

`to_json()`, `from_json()`, `write_json()`, and `read_json()` use an explicit
tag for bytes and non-finite floats. Ordinary strings such as `"dead"` remain
strings instead of being guessed to be hexadecimal bytes. Runtime-only fields
are excluded.

See `examples/binary_messages_demo.py` for signed and unsigned integers, bits,
an enum, a dynamic array of nested dataclasses, raw bytes, validation, and a
custom property in one message.

Run it from the repository root with:

```powershell
python -m examples.binary_messages_demo
```
