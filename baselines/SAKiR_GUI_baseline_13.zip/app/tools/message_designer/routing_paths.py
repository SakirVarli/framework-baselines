from __future__ import annotations

import copy
from typing import Any

from .wire_size import WireSizeAnalyzer


class RoutingPathError(ValueError):
    pass


class RoutingMatchError(ValueError):
    pass


def routing_messages(manifest, group=None, *, active_only=False):
    """Return descendants of one routing scope, optionally excluding drafts."""
    root_uid = manifest['library']['uid']
    scoped_uids = None
    if group is not None and group.get('uid') != root_uid:
        children = {}
        for candidate in manifest.get('groups', []):
            children.setdefault(candidate.get('parent_group_uid') or root_uid, []).append(candidate['uid'])
        scoped_uids = set()
        pending = [group['uid']]
        while pending:
            uid = pending.pop()
            if uid not in scoped_uids:
                scoped_uids.add(uid)
                pending.extend(children.get(uid, []))
    messages = [message for message in manifest.get("messages", [])
                if scoped_uids is None or (message.get("group_uid") or root_uid) in scoped_uids]
    if active_only:
        from .routing_model import participating_message_uids
        active = participating_message_uids(manifest)
        messages = [message for message in messages if message['uid'] in active]
    return messages


def routing_field_options(manifest: dict[str, Any], group: dict[str, Any] | None = None, *, active_only=False):
    """Offer fields with the same static location in every candidate message."""
    structures = {item.get("uid"): item for item in manifest.get("structures", [])}
    enums = manifest.get("enums", [])
    messages = routing_messages(manifest, group, active_only=active_only)
    common = None
    for message in messages:
        options = {item["path"]: item for item in _structure_paths("", message, structures, enums)}
        common = options if common is None else {
            path: item for path, item in common.items() if options.get(path) == item
        }
    return list((common or {}).values())


def resolve_routing_component(component, manifest, group=None):
    resolved = copy.deepcopy(component)
    if component.get("source", "raw") == "field":
        options = {item["path"]: item for item in routing_field_options(manifest, group)}
        path = str(component.get("field_path", "")).strip()
        if path not in options:
            raise RoutingPathError(f"Routing field '{path}' is missing or has no common static layout")
        resolved.update({key: value for key, value in options[path].items() if key != "path"})
    resolved.setdefault("length", resolved.get("width", 1))
    resolved.setdefault("type", "uint")
    return resolved


def identify_manifest_route(manifest, data, group_uid=None, direction=None):
    """One-shot preview helper; stream callers should reuse compile_manifest_routing."""
    from .routing_model import compile_manifest_routing
    from .model import normalize_manifest
    manifest = normalize_manifest(manifest)
    registry = compile_manifest_routing(manifest)
    match = registry.identify_message(data, group_uid=group_uid, direction=direction)
    messages = {message['uid']: message for message in manifest.get('messages', [])}
    owners = {owner['uid']: owner for owner in [manifest['library'], *manifest.get('groups', [])]}
    return {'message': messages[match.message_uid], 'group': owners[match.group.uid],
            'group_path': [owners[group.uid] for group in match.group_path],
            'group_values': match.group_values, 'group_value_path': match.group_value_path,
            'message_values': match.message_values, 'identifiers': match.identifiers}


def _structure_paths(prefix, structure, structures, enums, base_offset=0, visiting=frozenset()):
    analyzer = WireSizeAnalyzer({"structures": list(structures.values()), "enums": enums})
    result, offset = [], base_offset
    for field in structure.get("fields", []):
        kind = field.get("kind")
        path = ".".join(part for part in (prefix, field.get("name", "field")) if part)
        if kind == "struct" and field.get("struct_uid") in structures:
            uid = field["struct_uid"]
            if uid not in visiting:
                result.extend(_structure_paths(path, structures[uid], structures, enums, offset, visiting | {uid}))
        elif kind == "inline_struct":
            result.extend(_structure_paths(path, field, structures, enums, offset, visiting))
        else:
            descriptor = _routing_descriptor(field, enums)
            if descriptor is not None:
                result.append({"path": path, "offset": offset, **descriptor})
        size = analyzer.field(field)
        if size.status != "exact":
            break
        offset += int(size.bytes)
    return result


def _routing_descriptor(field, enums):
    kind = field.get("kind")
    descriptor = {"byteorder": field.get("endian", "big"), "mask": None, "shift": 0}
    if kind in {"uint", "int", "enum", "float"}:
        descriptor.update(type=kind, length=int(field.get("width", 1)))
        if kind == "enum":
            enum = next((item for item in enums if item.get("uid") == field.get("enum_uid")), {})
            descriptor['enum_values'] = tuple((item['name'], item['value']) for item in enum.get('values', []))
    elif kind == "bytes_integer":
        descriptor.update(type="int" if field.get("signed") else "uint", length=int(field.get("length", 1)))
    elif kind == "bool":
        descriptor.update(type="bool", length=1)
    elif kind in {"bytes", "string"} and field.get("mode") == "fixed":
        descriptor.update(type="text" if kind == "string" else "bytes", length=int(field.get("length", 1)))
        if kind == "string":
            descriptor.update(encoding=field.get('encoding', 'utf-8'), padding='00')
    elif kind in {"const", "default", "rebuild"} and isinstance(field.get("item"), dict):
        return _routing_descriptor(field["item"], enums)
    else:
        return None
    descriptor['width'] = descriptor['length']
    return descriptor


def _group_chain(manifest, group):
    by_uid = {item.get("uid"): item for item in manifest.get("groups", [])}
    chain = []; seen = set(); current = group
    while current and current.get("uid") not in seen:
        seen.add(current.get("uid")); chain.append(current)
        current = by_uid.get(current.get("parent_group_uid"))
    return list(reversed(chain))
