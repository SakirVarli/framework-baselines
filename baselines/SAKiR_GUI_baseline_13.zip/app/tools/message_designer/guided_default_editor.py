from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .object_defaults import create_guided_value, guided_expression, guided_supported


class GuidedDefaultEditor(QtWidgets.QWidget):
    """Type-aware editor for a serialized field's Python initialization value."""

    changed = QtCore.pyqtSignal()

    def __init__(self, field: dict[str, Any], manifest: dict[str, Any], parent=None):
        super().__init__(parent)
        self._field = copy.deepcopy(field)
        self._manifest = manifest
        self._loading = False
        self._value = create_guided_value(field, manifest, field.get("object_default_value"))

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["Path", "Type", "Value", "Source"])
        self.tree.setRootIsDecorated(True)
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.setMinimumHeight(190)
        self.tree.currentItemChanged.connect(lambda *_: self._update_controls())
        layout.addWidget(self.tree)

        controls = QtWidgets.QHBoxLayout()
        self.add_item_button = QtWidgets.QPushButton("Add array item")
        self.remove_item_button = QtWidgets.QPushButton("Remove selected item")
        self.remove_stale_button = QtWidgets.QPushButton("Remove stale values")
        controls.addWidget(self.add_item_button)
        controls.addWidget(self.remove_item_button)
        controls.addWidget(self.remove_stale_button)
        controls.addStretch()
        layout.addLayout(controls)
        self.add_item_button.clicked.connect(self._add_array_item)
        self.remove_item_button.clicked.connect(self._remove_array_item)
        self.remove_stale_button.clicked.connect(self._remove_stale_values)

        preview_heading = QtWidgets.QLabel("Generated Python default")
        preview_heading.setStyleSheet("font-weight: 600;")
        layout.addWidget(preview_heading)
        self.preview = QtWidgets.QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.preview.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.preview.setMaximumHeight(86)
        layout.addWidget(self.preview)
        self._rebuild()

    def value(self) -> dict[str, Any]:
        return copy.deepcopy(self._value)

    def _rebuild(self) -> None:
        self._loading = True
        self.tree.clear()
        root = QtWidgets.QTreeWidgetItem([self._field.get("name", "field"), _type_label(self._field, self._manifest), "", ""])
        self.tree.addTopLevelItem(root)
        self._render(root, self._field, self._value, self._field.get("name", "field"))
        root.setExpanded(True)
        self.tree.expandAll()
        self._loading = False
        self._update_controls()
        self._update_preview()

    def _render(self, item, field, value, path) -> None:
        kind = field.get("kind")
        item.setData(0, QtCore.Qt.UserRole, {"field": field, "value": value})
        if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "computed"}:
            self._line_value(item, value, "value", str(value.get("value", 0)))
        elif kind == "float":
            self._line_value(item, value, "value", str(value.get("value", 0.0)))
        elif kind == "string":
            self._line_value(item, value, "value", str(value.get("value", "")))
        elif kind == "bytes":
            self._line_value(item, value, "hex", str(value.get("hex", "")), "Hex bytes, for example: AA 10 FF")
        elif kind == "bool":
            combo = QtWidgets.QComboBox(); combo.addItem("False", False); combo.addItem("True", True)
            combo.setCurrentIndex(1 if value.get("value") else 0)
            combo.currentIndexChanged.connect(lambda _=0, n=value, w=combo: self._set(n, "value", bool(w.currentData())))
            self.tree.setItemWidget(item, 2, combo)
        elif kind == "enum":
            combo = QtWidgets.QComboBox()
            enum = _by_uid(self._manifest.get("enums", []), field.get("enum_uid")) or {}
            for member in enum.get("values", []):
                combo.addItem(f"{member.get('name')} ({member.get('value')})", member.get("uid"))
            index = combo.findData(value.get("value_uid"))
            if value.get("value_uid") and index < 0:
                combo.addItem(f"Missing value: {value.get('value_uid')}", value.get("value_uid")); index = combo.count() - 1
            combo.setCurrentIndex(max(0, index))
            combo.currentIndexChanged.connect(lambda _=0, n=value, w=combo: self._set(n, "value_uid", w.currentData()))
            self.tree.setItemWidget(item, 2, combo)
        elif kind == "bitfield":
            assignments = {entry.get("member_uid"): entry for entry in value.get("members", [])}
            for member in field.get("members", []):
                if member.get("kind") == "padding": continue
                entry = assignments.get(member.get("uid")); nested = entry.get("value", {}) if entry else {}
                child = QtWidgets.QTreeWidgetItem([f"{path}.{member.get('name')}", f"{member.get('kind')}[{member.get('bits')}]", "", "Explicit"])
                item.addChild(child)
                pseudo = {"kind": "bool" if member.get("kind") == "flag" else "int"}
                self._render(child, pseudo, nested, child.text(0))
        elif kind in {"struct", "inline_struct"}:
            fields = (_by_uid(self._manifest.get("structures", []), field.get("struct_uid")) or {}).get("fields", []) if kind == "struct" else field.get("fields", [])
            definitions = {nested.get("uid"): nested for nested in fields}
            for assignment in value.get("fields", []):
                nested = definitions.get(assignment.get("field_uid"))
                if not nested:
                    child = QtWidgets.QTreeWidgetItem([
                        f"{path}.<removed:{assignment.get('field_uid', '?')}>", "Missing field", "", "Stale",
                    ])
                    child.setForeground(0, QtGui.QBrush(QtGui.QColor("#b42318")))
                    item.addChild(child)
                    continue
                child_path = f"{path}.{nested.get('name')}"
                child = QtWidgets.QTreeWidgetItem([child_path, _type_label(nested, self._manifest), "", ""])
                item.addChild(child)
                source = QtWidgets.QComboBox(); source.addItem("Explicit value", "explicit"); source.addItem("Use nested default", "default")
                source.setCurrentIndex(max(0, source.findData(assignment.get("source", "explicit"))))
                source.currentIndexChanged.connect(lambda _=0, a=assignment, w=source: self._set(a, "source", w.currentData()))
                self.tree.setItemWidget(child, 3, source)
                self._render(child, nested, assignment.get("value", {}), child_path)
        elif kind == "array":
            item.setData(0, QtCore.Qt.UserRole + 1, {"node": value, "field": field})
            for index, nested_value in enumerate(value.get("items", [])):
                child_path = f"{path}[{index}]"
                child = QtWidgets.QTreeWidgetItem([child_path, _type_label(field.get("item", {}), self._manifest), "", ""])
                child.setData(0, QtCore.Qt.UserRole + 2, index)
                item.addChild(child)
                self._render(child, field["item"], nested_value, child_path)
        elif kind == "conditional":
            combo = QtWidgets.QComboBox(); combo.addItem("None", False); combo.addItem("Present", True)
            combo.setCurrentIndex(1 if value.get("present") else 0)
            combo.currentIndexChanged.connect(lambda _=0, n=value, w=combo: self._conditional_changed(n, w.currentData()))
            self.tree.setItemWidget(item, 2, combo)
            child = QtWidgets.QTreeWidgetItem([path, _type_label(field.get("item", {}), self._manifest), "", ""])
            item.addChild(child); self._render(child, field["item"], value.get("value", {}), path)
            child.setHidden(not value.get("present"))
        elif kind == "switch":
            combo = QtWidgets.QComboBox()
            for index, case in enumerate(field.get("cases", [])): combo.addItem(str(case.get("value", index)), index)
            combo.setCurrentIndex(min(int(value.get("case_index", 0)), max(0, combo.count() - 1)))
            combo.currentIndexChanged.connect(lambda _=0, n=value, f=field, w=combo: self._switch_changed(n, f, int(w.currentData() or 0)))
            self.tree.setItemWidget(item, 2, combo)
            cases = field.get("cases", [])
            if cases:
                selected = min(int(value.get("case_index", 0)), len(cases) - 1)
                child = QtWidgets.QTreeWidgetItem([path, _type_label(cases[selected]["item"], self._manifest), "", ""])
                item.addChild(child)
                self._render(child, cases[selected]["item"], value.get("value", {}), path)
        elif kind in {"const", "default", "aligned", "rebuild", "checksum"}:
            self._render(item, field.get("item", {}), value.get("value", {}), path)
        else:
            item.setText(2, "Guided editing unavailable")

    def _line_value(self, item, node, key, text, tooltip=""):
        edit = QtWidgets.QLineEdit(text); edit.setToolTip(tooltip)
        edit.textChanged.connect(lambda current, n=node, k=key: self._set(n, k, current))
        self.tree.setItemWidget(item, 2, edit)

    def _set(self, node, key, value):
        node[key] = value
        if not self._loading:
            self._update_preview(); self.changed.emit()

    def _conditional_changed(self, node, present):
        node["present"] = bool(present); self._rebuild(); self.changed.emit()

    def _switch_changed(self, node, field, index):
        node["case_index"] = index
        cases = field.get("cases", [])
        if cases: node["value"] = create_guided_value(cases[index]["item"], self._manifest)
        self._rebuild(); self.changed.emit()

    def _selected_array(self):
        item = self.tree.currentItem()
        while item is not None:
            metadata = item.data(0, QtCore.Qt.UserRole + 1)
            if metadata: return item, metadata
            item = item.parent()
        return None, None

    def _update_controls(self):
        item, metadata = self._selected_array()
        dynamic = bool(metadata and metadata["field"].get("mode") != "fixed")
        self.add_item_button.setEnabled(dynamic)
        selected = self.tree.currentItem()
        self.remove_item_button.setEnabled(dynamic and selected is not None and selected.parent() is item)

    def _add_array_item(self):
        _, metadata = self._selected_array()
        if not metadata or metadata["field"].get("mode") == "fixed": return
        metadata["node"].setdefault("items", []).append(create_guided_value(metadata["field"]["item"], self._manifest))
        self._rebuild(); self.changed.emit()

    def _remove_array_item(self):
        array_item, metadata = self._selected_array(); selected = self.tree.currentItem()
        if not metadata or selected is None or selected.parent() is not array_item: return
        index = selected.data(0, QtCore.Qt.UserRole + 2)
        if isinstance(index, int): metadata["node"]["items"].pop(index); self._rebuild(); self.changed.emit()

    def _remove_stale_values(self):
        _purge_stale(self._field, self._value, self._manifest)
        self._rebuild(); self.changed.emit()

    def _update_preview(self):
        if not guided_supported(self._field, self._manifest):
            self.preview.setPlainText("Unavailable until type references are complete."); return
        enums = {item.get("uid"): item for item in self._manifest.get("enums", [])}
        structures = {item.get("uid"): item for item in self._manifest.get("structures", [])}
        owner = _owner_for_field(self._manifest, self._field.get("uid")) or "Owner"
        try: expression = guided_expression(self._field, self._value, owner, enums, structures)
        except (KeyError, ValueError, TypeError, StopIteration) as error: expression = f"Incomplete guided value: {error}"
        self.preview.setPlainText(expression)


def _type_label(field, manifest):
    kind = field.get("kind", "unknown")
    if kind == "enum": return (_by_uid(manifest.get("enums", []), field.get("enum_uid")) or {}).get("name", "enum")
    if kind == "struct": return (_by_uid(manifest.get("structures", []), field.get("struct_uid")) or {}).get("name", "struct")
    if kind == "array": return f"array[{_type_label(field.get('item', {}), manifest)}]"
    return kind


def _by_uid(items, uid):
    return next((item for item in items if item.get("uid") == uid), None)


def _inline_name(owner, name):
    return owner + "".join(part.capitalize() for part in name.split("_")) + "Struct"


def _owner_for_field(manifest, target_uid):
    def visit(fields, owner):
        for field in fields:
            if field.get("uid") == target_uid: return owner
            if field.get("kind") == "inline_struct":
                found = visit(field.get("fields", []), _inline_name(owner, field.get("name", "field")))
                if found: return found
            nested = field.get("item")
            if isinstance(nested, dict):
                found = visit([nested], owner)
                if found: return found
            for case in field.get("cases", []):
                nested = case.get("item")
                if isinstance(nested, dict):
                    found = visit([nested], owner)
                    if found: return found
        return None
    for definition in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        found = visit(definition.get("fields", []), definition.get("name", "Owner"))
        if found: return found
    return None


def _purge_stale(field, value, manifest):
    kind = field.get("kind")
    if kind in {"struct", "inline_struct"}:
        fields = (_by_uid(manifest.get("structures", []), field.get("struct_uid")) or {}).get("fields", []) if kind == "struct" else field.get("fields", [])
        definitions = {item.get("uid"): item for item in fields if item.get("kind") != "padding"}
        value["fields"] = [item for item in value.get("fields", []) if item.get("field_uid") in definitions]
        for assignment in value["fields"]:
            _purge_stale(definitions[assignment["field_uid"]], assignment.get("value", {}), manifest)
    elif kind == "array":
        for item in value.get("items", []): _purge_stale(field.get("item", {}), item, manifest)
    elif kind == "conditional":
        _purge_stale(field.get("item", {}), value.get("value", {}), manifest)
    elif kind == "switch":
        index = value.get("case_index", 0); cases = field.get("cases", [])
        if isinstance(index, int) and 0 <= index < len(cases): _purge_stale(cases[index].get("item", {}), value.get("value", {}), manifest)
    elif kind in {"const", "default", "aligned", "rebuild", "checksum"}:
        _purge_stale(field.get("item", {}), value.get("value", {}), manifest)
