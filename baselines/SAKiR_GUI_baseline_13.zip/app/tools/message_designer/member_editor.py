from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtWidgets

from .model import new_id


class DefinitionOptionsEditor(QtWidgets.QWidget):
    """Typed editors for enums and non-wire class members."""

    changed = QtCore.pyqtSignal()
    SUPPORTED = {"Library", "Group", "Message", "Enum", "Runtime", "Constant", "Method"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._kind = ""
        self._base: dict[str, Any] = {}
        self._loading = False
        self._widgets: dict[str, QtWidgets.QWidget] = {}
        self._value_uids: list[str] = []
        self._display_name = "custom_method"
        self._layout = QtWidgets.QFormLayout(self)
        self._layout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)

    def load_definition(self, value: dict[str, Any], kind: str, manifest: dict[str, Any] | None = None) -> None:
        self._loading = True
        self._kind = kind
        self._base = copy.deepcopy(value)
        self._clear()
        if kind == "Library":
            self._library_settings(value)
        elif kind == "Group":
            self._line("description", "Description", value)
        elif kind == "Message":
            self._combo("direction", "Direction", ["ANY", "TX", "RX"], {"direction": str(value.get("direction", "ANY")).upper()})
            self._line("display_name", "Registry display name", value)
            behavior = QtWidgets.QLabel(str(value.get("behavior_class", ""))); behavior.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._layout.addRow("Behavior mixin", behavior)
        elif kind == "Enum":
            self._enum_values(value)
        elif kind == "Runtime":
            self._line("annotation", "Type annotation", value)
            self._line("default", "Default expression", value)
            self._check("repr", "Include in repr", value)
        elif kind == "Constant":
            self._line("annotation", "Type annotation", value)
            self._line("value", "Value expression", value)
        elif kind == "Method":
            self._display_name = value.get("name", "custom_method")
            self._combo("kind", "Method kind", ["instance", "class", "static", "async", "property"], value)
            self._signature_label = QtWidgets.QLabel()
            self._signature_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._signature_label.setStyleSheet("font-family: Consolas, monospace; padding: 6px;")
            self._layout.addRow("Generated signature", self._signature_label)
            self._widgets["kind"].currentTextChanged.connect(self._update_signature)
            self._update_signature()
        self._loading = False

    def value(self) -> dict[str, Any]:
        result = copy.deepcopy(self._base)
        if self._kind == "Library":
            result["package_name"] = self._widgets["package_name"].text().strip()
            return result
        if self._kind == "Group":
            result["description"] = self._widgets["description"].text()
            return result
        for key, widget in self._widgets.items():
            if isinstance(widget, QtWidgets.QLineEdit): result[key] = widget.text()
            elif isinstance(widget, QtWidgets.QPlainTextEdit): result[key] = widget.toPlainText()
            elif isinstance(widget, QtWidgets.QCheckBox): result[key] = widget.isChecked()
            elif isinstance(widget, QtWidgets.QComboBox): result[key] = widget.currentText()
            elif isinstance(widget, QtWidgets.QSpinBox): result[key] = widget.value()
        if self._kind == "Enum": result["values"] = self._read_enum_values()
        elif self._kind == "Method":
            result.pop("parameters", None)
            result.pop("return_annotation", None)
            result.pop("docstring", None)
        return result

    def set_display_name(self, name: str) -> None:
        self._display_name = name or "custom_method"
        if self._kind == "Method": self._update_signature()

    def _update_signature(self, *args) -> None:
        kind = self._widgets.get("kind").currentText() if self._widgets.get("kind") else "instance"
        decorators = {"class": "@classmethod\n", "static": "@staticmethod\n", "property": "@property\n"}
        first = "cls" if kind == "class" else ("" if kind == "static" else "self")
        async_prefix = "async " if kind == "async" else ""
        self._signature_label.setText(f"{decorators.get(kind, '')}{async_prefix}def {self._display_name}({first}):")

    def _clear(self):
        while self._layout.rowCount(): self._layout.removeRow(0)
        self._widgets.clear()

    def _emit_changed(self, *args):
        if not self._loading: self.changed.emit()

    def _add(self, key, label, widget):
        self._widgets[key] = widget; self._layout.addRow(label, widget)
        if isinstance(widget, QtWidgets.QLineEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QPlainTextEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QCheckBox): widget.toggled.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QComboBox): widget.currentIndexChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QSpinBox): widget.valueChanged.connect(self._emit_changed)

    def _line(self, key, label, value): self._add(key, label, QtWidgets.QLineEdit(str(value.get(key, ""))))

    def _check(self, key, label, value):
        widget = QtWidgets.QCheckBox(); widget.setChecked(bool(value.get(key, True))); self._add(key, label, widget)

    def _combo(self, key, label, values, value):
        widget = QtWidgets.QComboBox(); widget.addItems(values); widget.setCurrentText(str(value.get(key, values[0]))); self._add(key, label, widget)

    def _library_settings(self, value):
        self._line("package_name", "Python package name", value)

    def _table_controls(self, table, add_text, add_callback, remove_callback):
        controls = QtWidgets.QWidget(); layout = QtWidgets.QHBoxLayout(controls); layout.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton(add_text); remove = QtWidgets.QPushButton("Remove selected")
        add.clicked.connect(add_callback); remove.clicked.connect(remove_callback)
        layout.addWidget(add); layout.addWidget(remove); layout.addStretch(); return controls

    def _enum_values(self, value):
        table = QtWidgets.QTableWidget(0, 2); table.setHorizontalHeaderLabels(["Member name", "Integer value"])
        table.horizontalHeader().setStretchLastSection(True); self._value_uids = []
        for member in value.get("values", []): self._append_enum_value(table, member)
        controls = self._table_controls(
            table, "Add enum value",
            lambda: self._add_enum_value(table),
            lambda: self._remove_row(table, self._value_uids),
        )
        table.itemChanged.connect(self._emit_changed)
        self._layout.addRow("Enum values", table); self._layout.addRow("", controls); self._widgets["_enum_values"] = table

    def _append_enum_value(self, table, member):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row); self._value_uids.append(member.get("uid", new_id()))
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(member.get("name", "VALUE"))))
            table.setItem(row, 1, QtWidgets.QTableWidgetItem(str(member.get("value", 0))))
        finally:
            table.blockSignals(previous)

    def _add_enum_value(self, table):
        self._append_enum_value(table, {"uid": new_id(), "name": "VALUE", "value": 0})
        self.changed.emit()

    def _read_enum_values(self):
        table = self._widgets["_enum_values"]; result = []
        for row in range(table.rowCount()):
            text = table.item(row, 1).text().strip()
            try: number = int(text, 0)
            except ValueError: number = text
            result.append({"uid": self._value_uids[row], "name": table.item(row, 0).text(), "value": number})
        return result

    def _remove_row(self, table, uid_list):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try:
                table.removeRow(row); uid_list.pop(row)
            finally:
                table.blockSignals(previous)
            self.changed.emit()
