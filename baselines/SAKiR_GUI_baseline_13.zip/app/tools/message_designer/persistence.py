from __future__ import annotations

import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .generation import (
    compatibility_changes,
    content_hash,
    generate_library,
    managed_hashes,
)
from .model import FORMAT_NAME, SCHEMA_VERSION, normalize_manifest
from .validation import blocking_issues


MANIFEST_NAME = "message_library.json"
MANAGED_FILES = {"models.py", "registry.py", "__init__.py", "README.md"}


class LibraryPersistenceError(RuntimeError):
    pass


class ExternalModificationError(LibraryPersistenceError):
    def __init__(self, files: list[str]):
        self.files = tuple(files)
        super().__init__("Externally modified generated files: " + ", ".join(files))


@dataclass(frozen=True, slots=True)
class LoadedLibrary:
    package_dir: Path
    manifest: dict[str, Any]
    manifest_hash: str
    behavior_hash: str


@dataclass(frozen=True, slots=True)
class SaveOutcome:
    package_dir: Path
    backup_dir: Path | None
    warnings: tuple[str, ...]
    compatibility: dict[str, list[str]]
    manifest: dict[str, Any]


def load_library(package_dir: str | Path) -> LoadedLibrary:
    package_dir = Path(package_dir).resolve()
    manifest_path = package_dir / MANIFEST_NAME
    if not manifest_path.is_file():
        raise LibraryPersistenceError(f"Designer manifest not found: {manifest_path}")
    raw = manifest_path.read_bytes()
    try:
        manifest = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise LibraryPersistenceError(f"Invalid designer manifest: {error}") from error
    if manifest.get("format") != FORMAT_NAME or manifest.get("schema_version") not in {1, 2, 3, 4, 5, 6, 7, SCHEMA_VERSION}:
        raise LibraryPersistenceError("The folder is not a supported Message Designer library")
    manifest = normalize_manifest(manifest)
    behavior_path = package_dir / "behaviors.py"
    behavior_hash = content_hash(behavior_path.read_bytes()) if behavior_path.exists() else ""
    return LoadedLibrary(package_dir, manifest, content_hash(raw), behavior_hash)


def externally_modified_files(package_dir: Path, manifest: dict[str, Any]) -> list[str]:
    changed = []
    expected = manifest.get("generated_hashes", {})
    for name, digest in expected.items():
        path = package_dir / name
        actual = content_hash(path.read_bytes()) if path.is_file() else ""
        if actual != digest:
            changed.append(name)
    return sorted(changed)


def save_library(
    parent_dir: str | Path,
    manifest: dict[str, Any],
    *,
    previous: LoadedLibrary | None = None,
    overwrite_modified: bool = False,
    timeout_seconds: float = 8.0,
) -> SaveOutcome:
    if manifest.get("schema_version") in {1, 2, 3, 4, 5, 6, 7, SCHEMA_VERSION}:
        manifest = normalize_manifest(manifest)
    errors = blocking_issues(manifest)
    if errors:
        raise LibraryPersistenceError("Validation failed: " + "; ".join(issue.message for issue in errors))
    package_name = manifest["library"]["package_name"]
    parent_dir = Path(parent_dir).resolve()
    package_dir = parent_dir / package_name
    parent_dir.mkdir(parents=True, exist_ok=True)

    old_manifest: dict[str, Any] = {}
    if package_dir.exists():
        loaded_now = load_library(package_dir)
        old_manifest = loaded_now.manifest
        if previous and loaded_now.manifest_hash != previous.manifest_hash:
            raise ExternalModificationError([MANIFEST_NAME])
        modified = externally_modified_files(package_dir, loaded_now.manifest)
        if modified and not overwrite_modified:
            raise ExternalModificationError(modified)
    elif previous:
        raise ExternalModificationError(["library folder was removed"])

    behavior_path = package_dir / "behaviors.py"
    behavior_source = behavior_path.read_text(encoding="utf-8") if behavior_path.is_file() else ""
    generated = generate_library(manifest, behavior_source)
    compatibility = compatibility_changes(old_manifest, manifest) if old_manifest else {"breaking": [], "non_breaking": []}

    saved_manifest = copy.deepcopy(manifest)
    if old_manifest and (compatibility["breaking"] or compatibility["non_breaking"]):
        saved_manifest.setdefault("compatibility_history", []).append({
            "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "breaking": compatibility["breaking"],
            "non_breaking": compatibility["non_breaking"],
        })
    saved_manifest["generated_hashes"] = managed_hashes(generated.files)
    saved_manifest["behavior_hash"] = content_hash(generated.files["behaviors.py"])
    manifest_text = json.dumps(saved_manifest, indent=2, ensure_ascii=False) + "\n"

    stage_root = Path(tempfile.mkdtemp(prefix=f".{package_name}.stage-", dir=str(parent_dir)))
    staged_package = stage_root / package_name
    staged_package.mkdir()
    try:
        for name, content in generated.files.items():
            (staged_package / name).write_text(content, encoding="utf-8", newline="\n")
        (staged_package / MANIFEST_NAME).write_text(manifest_text, encoding="utf-8", newline="\n")
        _validate_staged_package(stage_root, package_name, timeout_seconds)
        backup = _commit_staged(package_dir, staged_package)
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)
    return SaveOutcome(package_dir, backup, generated.warnings, compatibility, saved_manifest)


def _validate_staged_package(stage_root: Path, package_name: str, timeout_seconds: float) -> None:
    for path in (stage_root / package_name).glob("*.py"):
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    project_root = Path(__file__).resolve().parents[3]
    script = (
        "import importlib\n"
        f"package = importlib.import_module({package_name!r})\n"
        "for message_type in package.MESSAGE_TYPES_BY_NAME.values():\n"
        "    message_type.codec()\n"
        f"registry = importlib.import_module({(package_name + '.registry')!r})\n"
        "for name, values in registry.DESIGNER_SAMPLE_WIRE_VALUES.items():\n"
        "    if values is not None:\n"
        "        message_type = getattr(package, name)\n"
        "        encoded = message_type.from_wire(values).encode()\n"
        "        message_type.decode(encoded)\n"
    )
    environment = os.environ.copy()
    environment["PYTHONPATH"] = os.pathsep.join(
        [str(stage_root), str(project_root), environment.get("PYTHONPATH", "")]
    )
    try:
        result = subprocess.run(
            [sys.executable, "-c", script],
            cwd=str(stage_root),
            env=environment,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired as error:
        raise LibraryPersistenceError("Generated library import timed out") from error
    if result.returncode:
        detail = (result.stderr or result.stdout).strip()
        raise LibraryPersistenceError(f"Generated library failed its import check:\n{detail}")


def _commit_staged(package_dir: Path, staged_package: Path) -> Path | None:
    existed = package_dir.exists()
    backup_dir: Path | None = None
    if existed:
        backup_root = package_dir / ".message_designer_backups"
        backup_root.mkdir(exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup_dir = backup_root / f"{package_dir.name}-{stamp}"
        suffix = 1
        while backup_dir.exists():
            backup_dir = backup_root / f"{package_dir.name}-{stamp}-{suffix}"
            suffix += 1
        shutil.copytree(
            package_dir,
            backup_dir,
            ignore=shutil.ignore_patterns(".message_designer_backups"),
        )
    else:
        package_dir.mkdir()

    targets = [*MANAGED_FILES, "behaviors.py", MANIFEST_NAME]
    try:
        for name in targets:
            source = staged_package / name
            temporary = package_dir / f".{name}.message-designer.tmp"
            shutil.copy2(source, temporary)
            os.replace(temporary, package_dir / name)
    except Exception:
        if backup_dir:
            for name in targets:
                target = package_dir / name
                backup_file = backup_dir / name
                if backup_file.exists():
                    shutil.copy2(backup_file, target)
                else:
                    target.unlink(missing_ok=True)
        elif not existed:
            shutil.rmtree(package_dir, ignore_errors=True)
        raise
    return backup_dir
