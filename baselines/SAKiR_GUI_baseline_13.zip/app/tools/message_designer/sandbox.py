from __future__ import annotations

import importlib
import contextlib
import io
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any

from app.binary_messages.json_codec import from_json_value, to_json_value

from .generation import generate_library


def execute(request: dict[str, Any]) -> dict[str, Any]:
    manifest = request["manifest"]
    package_name = manifest["library"]["package_name"]
    root = Path(tempfile.mkdtemp(prefix="sakir-message-preview-"))
    package_dir = root / package_name
    package_dir.mkdir()
    try:
        generated = generate_library(manifest, request.get("behaviors", ""))
        for name, content in generated.files.items():
            (package_dir / name).write_text(content, encoding="utf-8")
        sys.path.insert(0, str(root))
        package = importlib.import_module(package_name)
        message_type = getattr(package, request["message"])
        action = request["action"]
        if action == "build":
            values = from_json_value(request.get("values", {}))
            message = message_type.from_wire(values)
            encoded = message.encode()
            return {"ok": True, "hex": encoded.hex(" "), "values": to_json_value(message.to_dict())}
        raw = bytes.fromhex(request.get("hex", ""))
        message = message_type.decode(raw)
        result = {"ok": True, "hex": raw.hex(" "), "values": to_json_value(message.to_dict())}
        if action == "round_trip":
            rebuilt = message.encode()
            result["round_trip"] = rebuilt == raw
            result["rebuilt_hex"] = rebuilt.hex(" ")
        return result
    finally:
        if str(root) in sys.path:
            sys.path.remove(str(root))
        for name in list(sys.modules):
            if name == package_name or name.startswith(package_name + "."):
                sys.modules.pop(name, None)
        shutil.rmtree(root, ignore_errors=True)


def main() -> int:
    output = io.StringIO()
    try:
        request = json.loads(sys.stdin.read())
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            result = execute(request)
    except BaseException as error:
        result = {"ok": False, "error": f"{type(error).__name__}: {error}"}
    if output.getvalue():
        result["log"] = output.getvalue()[-4000:]
    sys.stdout.write(json.dumps(result, ensure_ascii=False))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
