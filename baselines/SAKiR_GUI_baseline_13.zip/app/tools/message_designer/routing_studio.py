from __future__ import annotations

import copy
import struct
from typing import Any

from PyQt5 import QtCore, QtWidgets

from .routing_editor import IdentifierDefinitionsEditor, AncestorValuesEditor
from .routing_model import owners_by_uid
from .validation import ValidationIssue, validate_manifest


class RoutingHierarchyTree(QtWidgets.QTreeWidget):
    reparentRequested = QtCore.pyqtSignal(str, str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderLabels(["Group / message"])
        self.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        self.setDefaultDropAction(QtCore.Qt.MoveAction)

    def dropEvent(self, event):
        item = self.currentItem()
        if item is None:
            return
        uid = item.data(0, QtCore.Qt.UserRole) or ""
        kind = item.data(0, QtCore.Qt.UserRole + 1) or ""
        super().dropEvent(event)
        parent = item.parent()
        parent_kind = parent.data(0, QtCore.Qt.UserRole + 1) if parent else ""
        parent_uid = parent.data(0, QtCore.Qt.UserRole) if parent else ""
        valid = (kind == "Group" and parent_kind in {"Library", "Group"}) or (kind == "Message" and parent_kind in {"Library", "Group"})
        cursor = parent
        while valid and cursor is not None:
            if cursor is item: valid = False
            cursor = cursor.parent()
        self.reparentRequested.emit(str(uid), str(parent_uid or ""), str(kind if valid else ""))


class RoutingStudio(QtWidgets.QWidget):
    manifestApplied = QtCore.pyqtSignal(object, str)
    pendingChanged = QtCore.pyqtSignal(bool)
    validationChanged = QtCore.pyqtSignal(object)
    reparentRequested = QtCore.pyqtSignal(str, str, str)
    openDefinitionRequested = QtCore.pyqtSignal(str)

    def minimumSizeHint(self):
        return QtCore.QSize(320, 240)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._manifest = {}; self._selected_uid = ''; self._loading = False; self._editor_dirty = False
        self.validation_timer = QtCore.QTimer(self); self.validation_timer.setSingleShot(True)
        self.validation_timer.setInterval(150); self.validation_timer.timeout.connect(self._refresh_validation)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSizeConstraint(QtWidgets.QLayout.SetNoConstraint)
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        heading = QtWidgets.QLabel('Group identifiers and automatic decoding'); heading.setStyleSheet('font-size: 16px; font-weight: 600;')
        layout.addWidget(heading)
        splitter = QtWidgets.QSplitter(); splitter.setChildrenCollapsible(False); layout.addWidget(splitter, 1)
        left = QtWidgets.QFrame(); left.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding); left_layout = QtWidgets.QVBoxLayout(left)
        self.search = QtWidgets.QLineEdit(); self.search.setPlaceholderText('Search groups and messages…'); self.search.setClearButtonEnabled(True)
        left_layout.addWidget(self.search)
        self.tree = RoutingHierarchyTree(); self.tree.setColumnWidth(0, 220); left_layout.addWidget(self.tree)
        splitter.addWidget(left)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.inspector = QtWidgets.QWidget(); self.form = QtWidgets.QVBoxLayout(self.inspector); self.form.setAlignment(QtCore.Qt.AlignTop)
        left.setFrameStyle(scroll.frameStyle())
        left.setPalette(self.inspector.palette()); left.setBackgroundRole(self.inspector.backgroundRole()); left.setAutoFillBackground(True)
        self.heading = QtWidgets.QLabel(); self.heading.setStyleSheet('font-size: 15px; font-weight: 600;')
        self.path = QtWidgets.QLabel(); self.path.setWordWrap(True)
        self.form.addWidget(self.heading); self.form.addWidget(self.path)
        self.definition_group = QtWidgets.QGroupBox('Identifier definitions for this group'); self.definition_layout = QtWidgets.QVBoxLayout(self.definition_group); self.form.addWidget(self.definition_group)
        self.ancestor_group = QtWidgets.QGroupBox('Expected values for ancestor identifiers'); self.ancestor_layout = QtWidgets.QVBoxLayout(self.ancestor_group); self.form.addWidget(self.ancestor_group)
        footer = QtWidgets.QHBoxLayout(); self.state = QtWidgets.QLabel(); self.open_definition = QtWidgets.QPushButton('Open in Definitions')
        self.apply = QtWidgets.QPushButton('Apply routing')
        footer.addWidget(self.state, 1); footer.addWidget(self.open_definition); footer.addWidget(self.apply); self.form.addLayout(footer)
        scroll.setWidget(self.inspector); splitter.addWidget(scroll); splitter.setSizes([430, 950])
        self.issues = QtWidgets.QTreeWidget()
        self.issues.setHeaderLabels(['Severity', 'Validation issue', 'Suggested action'])
        self.issues.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.issues.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.setRootIsDecorated(False)
        self.issues.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.issues.setMaximumHeight(190); layout.addWidget(self.issues)
        self.tree.currentItemChanged.connect(self._selection_changed); self.tree.reparentRequested.connect(self.reparentRequested)
        self.search.textChanged.connect(self._filter_tree)
        self.open_definition.clicked.connect(lambda: self.openDefinitionRequested.emit(self._selected_uid))
        self.apply.clicked.connect(self._apply)
        self._set_pending(False)

    def refresh(self, manifest, selected_uid=''):
        self.validation_timer.stop()
        self._loading = True
        self._manifest = copy.deepcopy(manifest)
        self.tree.clear()
        library = self._manifest.get('library', {})
        root = self._item(library, 'Library'); self.tree.addTopLevelItem(root)
        groups = self._manifest.get('groups', [])
        children = {}
        for group in groups: children.setdefault(group.get('parent_group_uid') or library.get('uid'), []).append((group, 'Group'))
        for message in self._manifest.get('messages', []): children.setdefault(message.get('group_uid') or library.get('uid'), []).append((message, 'Message'))
        seen = set()
        def append(parent, uid):
            if uid in seen: return
            seen.add(uid)
            for owner, kind in children.get(uid, []):
                item = self._item(owner, kind); parent.addChild(item)
                if kind == 'Group': append(item, owner['uid'])
        append(root, library.get('uid'))
        target = self._find_item(selected_uid or self._selected_uid) or root
        self.tree.setCurrentItem(target); self.tree.expandAll()
        self._selected_uid = target.data(0, QtCore.Qt.UserRole)
        self._loading = False; self._editor_dirty = False; self._rebuild_editor(); self._set_pending(False)
        self._filter_tree(self.search.text())

    def _item(self, owner, kind):
        item = QtWidgets.QTreeWidgetItem([owner.get('name') or owner.get('display_name') or 'Library'])
        item.setData(0, QtCore.Qt.UserRole, owner.get('uid')); item.setData(0, QtCore.Qt.UserRole + 1, kind)
        if kind in {'Library', 'Group'}: item.setFlags(item.flags() | QtCore.Qt.ItemIsDropEnabled)
        if kind == 'Library': item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDragEnabled)
        if kind == 'Message': item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDropEnabled)
        return item

    def _find_item(self, uid):
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            if iterator.value().data(0, QtCore.Qt.UserRole) == uid: return iterator.value()
            iterator += 1
        return None

    def _object(self, uid):
        return next((item for item in [self._manifest.get('library', {}), *self._manifest.get('groups', []), *self._manifest.get('messages', [])] if item.get('uid') == uid), None)

    def _capture(self):
        if not self._editor_dirty: return
        owner = self._object(self._selected_uid)
        if owner is None: return
        if self.definition_group.isVisible() or self._selected_kind != 'Message':
            owner['identifiers'] = self.identifier_editor.value()
            owner.pop('legacy_routing', None)
        if self._selected_kind != 'Library':
            owner['expected_values'] = self.values_editor.value()
            owner.pop('legacy_signatures', None)
        self._editor_dirty = False

    def _selection_changed(self, current, previous):
        if self._loading or current is None: return
        try: self._capture()
        except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
            QtWidgets.QMessageBox.warning(self, 'Invalid routing value', str(error))
            blocker = QtCore.QSignalBlocker(self.tree); self.tree.setCurrentItem(previous); del blocker
            return
        self._selected_uid = current.data(0, QtCore.Qt.UserRole); self._rebuild_editor()

    def _rebuild_editor(self):
        self._loading = True
        for layout in (self.definition_layout, self.ancestor_layout):
            while layout.count():
                widget = layout.takeAt(0).widget()
                if widget: widget.hide(); widget.deleteLater()
        owner = self._object(self._selected_uid)
        if owner is None: self._loading = False; return
        self._selected_kind = 'Library' if owner is self._manifest['library'] else 'Group' if 'parent_group_uid' in owner else 'Message'
        self.heading.setText((owner.get('name') or owner.get('display_name') or 'Library') + ' · ' + self._selected_kind)
        self.path.setText('Identifiers use absolute offsets in the complete packet. Group decoding also verifies every ancestor.')
        self.definition_group.setVisible(self._selected_kind != 'Message')
        self.ancestor_group.setVisible(self._selected_kind != 'Library')
        if self._selected_kind != 'Message':
            self.identifier_editor = IdentifierDefinitionsEditor(owner.get('identifiers', []), self._manifest, owner)
            self.identifier_editor.changed.connect(self._edited); self.definition_layout.addWidget(self.identifier_editor)
        if self._selected_kind != 'Library':
            self.values_editor = AncestorValuesEditor(self._manifest, owner)
            self.values_editor.changed.connect(self._edited); self.ancestor_layout.addWidget(self.values_editor)
        self._editor_dirty = False; self._loading = False
        self._refresh_validation()

    def _edited(self):
        if not self._loading:
            self._editor_dirty = True; self._set_pending(True); self.validation_timer.start()

    def _refresh_validation(self):
        if not self._manifest: return
        self.validation_timer.stop()
        manifest = copy.deepcopy(self._manifest)
        input_issues = []
        if self._editor_dirty:
            owner = next((item for item in [manifest['library'], *manifest.get('groups', []), *manifest.get('messages', [])]
                          if item['uid'] == self._selected_uid), None)
            if owner is not None:
                try:
                    if self._selected_kind != 'Message':
                        owner['identifiers'] = self.identifier_editor.value(); owner.pop('legacy_routing', None)
                    if self._selected_kind != 'Library':
                        owner['expected_values'] = self.values_editor.value(); owner.pop('legacy_signatures', None)
                except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
                    input_issues.append(ValidationIssue('error', 'routing-input', str(error), self._selected_uid))
        self.validationChanged.emit([*input_issues, *validate_manifest(manifest), *self._decoding_warnings(manifest)])

    @staticmethod
    def _decoding_warnings(manifest):
        warnings = []
        owners = owners_by_uid(manifest)
        root = manifest['library']
        for item in [*manifest.get('groups', []), *manifest.get('messages', [])]:
            current = item; seen = set()
            while current is not root and current['uid'] not in seen:
                seen.add(current['uid'])
                parent_uid = current.get('parent_group_uid') if 'parent_group_uid' in current else current.get('group_uid')
                parent = owners.get(parent_uid or root['uid'])
                if parent is None: break
                values = current.get('expected_values')
                if values is None or (isinstance(values, dict) and any(values.get(identifier['uid']) is None for identifier in parent.get('identifiers', []))):
                    inherited = current is not item
                    reason = (f"ancestor group '{current.get('name', 'Group')}' has unassigned expected values" if inherited else
                              'its expected values are unassigned or incomplete')
                    warnings.append(ValidationIssue(
                        'warning', 'routing-ancestor-unassigned' if inherited else 'routing-unassigned',
                        f"{item.get('name', 'Unnamed')} is excluded from automatic decoding because {reason}.", current['uid'],
                    ))
                    break
                current = parent
        return warnings

    def _apply(self):
        return self.apply_pending()

    def pending_manifest(self):
        self._capture()
        return copy.deepcopy(self._manifest)

    def apply_pending(self):
        try: self._capture()
        except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
            QtWidgets.QMessageBox.warning(self, 'Invalid routing value', str(error)); return False
        self.manifestApplied.emit(copy.deepcopy(self._manifest), 'Edit group identifiers and expected values')
        return not self.apply.isEnabled()

    def _set_pending(self, pending):
        changed = self.apply.isEnabled() != pending
        self.apply.setEnabled(pending)
        self.state.setText('Routing changes are not applied.' if pending else 'All routing changes are applied.')
        self.state.setStyleSheet('color: #b54708; font-weight: 600;' if pending else 'color: #287d3c;')
        if changed: self.pendingChanged.emit(pending)

    def _filter_tree(self, text):
        terms = str(text).casefold().split()
        def visit(item):
            descendants = [visit(item.child(index)) for index in range(item.childCount())]
            visible = not terms or all(term in item.text(0).casefold() for term in terms) or any(descendants)
            item.setHidden(not visible); return visible
        for index in range(self.tree.topLevelItemCount()): visit(self.tree.topLevelItem(index))
