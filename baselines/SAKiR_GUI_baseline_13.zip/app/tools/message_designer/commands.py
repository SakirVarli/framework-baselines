from __future__ import annotations

import copy

from PyQt5 import QtWidgets


class ReplaceManifestCommand(QtWidgets.QUndoCommand):
    def __init__(self, document, before, after, text="Edit message library"):
        super().__init__(text)
        self.document = document
        self.before = copy.deepcopy(before)
        self.after = copy.deepcopy(after)

    def redo(self):
        self.document.replace(self.after)

    def undo(self):
        self.document.replace(self.before)
