from __future__ import annotations

import copy
import json
import struct
from dataclasses import dataclass, replace
from PyQt5 import QtCore, QtGui, QtWidgets
from app.binary_messages.compiled_routing import Identifier
from .model import new_id
from .routing_paths import routing_field_options, routing_messages
from .routing_model import ancestor_assignments, resolve_definitions


def _integer(text):
    try:
        return int(str(text).strip(), 0)
    except ValueError:
        return int(str(text).strip(), 10)


def _expected_hex_bytes(text):
    text = text.strip()
    if not text.lower().startswith('0x'):
        raise ValueError('Hex values must start with 0x')
    raw = bytes.fromhex(text[2:])
    if not raw: raise ValueError('Enter hex bytes after 0x')
    return raw


class IdentifierDefinitionsEditor(QtWidgets.QWidget):
    changed = QtCore.pyqtSignal()

    def __init__(self, definitions, manifest, owner, parent=None):
        super().__init__(parent)
        self._loading = True
        self._uids = []; self._definitions = {}; self._raw_layouts = {}; self._sources = {}
        scope = None if owner['uid'] == manifest['library']['uid'] else owner
        self.options = {item['path']: item for item in routing_field_options(manifest, scope)}
        has_assigned_descendants = bool(routing_messages(manifest, scope, active_only=True))
        linked_paths = {item.get('field_path') for item in definitions if item.get('source') == 'field'}
        self._linked_options = {item['path']: item for item in routing_field_options(manifest, scope, active_only=True)
                                if item['path'] in linked_paths}
        self._has_assigned_descendants = has_assigned_descendants
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        note = QtWidgets.QLabel('Offsets and lengths are in bytes. Common message fields fill their layout automatically and include messages in all descendant groups.')
        note.setWordWrap(True); layout.addWidget(note)
        self.table = QtWidgets.QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['Name', 'Source', 'Offset', 'Length', 'Common message field'])
        self.table.setMinimumHeight(180)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)
        layout.addWidget(self.table)
        actions = QtWidgets.QHBoxLayout()
        self.add = QtWidgets.QPushButton('Add identifier')
        self.remove = QtWidgets.QPushButton('Remove selected')
        self.remove.setToolTip('Remove selected identifier'); self.remove.setAccessibleName('Remove selected identifier')
        actions.addWidget(self.add); actions.addWidget(self.remove); actions.addStretch(); layout.addLayout(actions)
        self.add.clicked.connect(self._add); self.remove.clicked.connect(self._remove)
        for definition in definitions: self._append(definition)
        self.table.itemChanged.connect(self._changed)
        self.table.currentCellChanged.connect(self._update_remove)
        self._loading = False; self._update_remove()

    def _combo(self, row, column, items, selected, uid):
        combo = QtWidgets.QComboBox()
        combo.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        combo.setMinimumContentsLength(20 if column == 1 else 16)
        combo.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        for label, value in items: combo.addItem(label, value)
        combo.setCurrentIndex(max(0, combo.findData(selected)))
        self.table.setCellWidget(row, column, combo)
        combo.currentIndexChanged.connect(lambda _=0: self._source_changed(uid))
        combo.activated.connect(lambda _=0: self.table.setCurrentCell(self._uids.index(uid), column))
        return combo

    def _append(self, definition):
        row = self.table.rowCount(); self.table.insertRow(row)
        uid = definition.get('uid') or new_id(); self._uids.append(uid)
        self._definitions[uid] = copy.deepcopy(definition)
        self._raw_layouts[uid] = (str(definition.get('offset', 0)), str(definition.get('length', 1)))
        source = definition.get('source', 'raw'); self._sources[uid] = source
        for column, value in ((0, definition.get('name', 'identifier')), (2, definition.get('offset', 0)), (3, definition.get('length', 1))):
            self.table.setItem(row, column, QtWidgets.QTableWidgetItem(str(value)))
        self._combo(row, 1, [('Raw bytes', 'raw'), ('Common message field', 'field')], source, uid)
        paths = [('— Select common field —', '')] + [(path, path) for path in self.options]
        selected = definition.get('field_path', '')
        if selected and selected not in self.options:
            state = ('assigned messages' if selected in self._linked_options else
                     'unresolved' if self._has_assigned_descendants else 'stored layout')
            paths.append((selected + ' (' + state + ')', selected))
        self._combo(row, 4, paths, selected, uid)
        self._source_changed(uid)
        return row

    def _source_changed(self, uid):
        row = self._uids.index(uid)
        source = self.table.cellWidget(row, 1).currentData()
        field = self.table.cellWidget(row, 4); path = field.currentData()
        raw = source == 'raw'
        blocker = QtCore.QSignalBlocker(self.table)
        if self._sources[uid] == 'raw' and not raw:
            self._raw_layouts[uid] = (self.table.item(row, 2).text(), self.table.item(row, 3).text())
        if raw and self._sources[uid] != 'raw':
            for column, value in zip((2, 3), self._raw_layouts[uid]): self.table.item(row, column).setText(value)
        if not raw:
            option = self.options.get(path) or self._linked_options.get(path)
            for column, key in ((2, 'offset'), (3, 'length')):
                value = option[key] if option else self._definitions[uid].get(key, 0 if key == 'offset' else 1) if path else ''
                self.table.item(row, column).setText(str(value))
            if option and self.table.item(row, 0).text().startswith('identifier'):
                self.table.item(row, 0).setText(path.split('.')[-1])
        field.setEnabled(not raw)
        for column in (2, 3):
            item = self.table.item(row, column)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable if raw else item.flags() & ~QtCore.Qt.ItemIsEditable)
            group = QtGui.QPalette.Active if raw else QtGui.QPalette.Disabled
            item.setForeground(self.table.palette().brush(group, QtGui.QPalette.Text))
        self._sources[uid] = source
        del blocker
        self._changed()

    def _changed(self, *args):
        if not self._loading: self.changed.emit()

    def _update_remove(self, *args):
        self.remove.setEnabled(self.table.currentRow() >= 0)

    def _add(self):
        self._loading = True
        used = {self.table.item(row, 0).text().strip() for row in range(self.table.rowCount())}
        index = self.table.rowCount() + 1
        while f'identifier_{index}' in used: index += 1
        row = self._append({'name': f'identifier_{index}'})
        self.table.setCurrentCell(row, 0); self.table.scrollToItem(self.table.item(row, 0))
        self._loading = False; self._update_remove(); self.changed.emit()
        self.table.editItem(self.table.item(row, 0))

    def _remove(self):
        row = self.table.currentRow()
        if row < 0: return
        self._loading = True
        uid = self._uids.pop(row)
        for values in (self._definitions, self._raw_layouts, self._sources): values.pop(uid)
        self.table.removeRow(row)
        self._loading = False; self._update_remove(); self.changed.emit()

    def value(self):
        result = []
        for row, uid in enumerate(self._uids):
            definition = copy.deepcopy(self._definitions[uid])
            definition.update(uid=uid, name=self.table.item(row, 0).text().strip(),
                              source=self.table.cellWidget(row, 1).currentData(),
                              field_path=self.table.cellWidget(row, 4).currentData() or '')
            if definition['source'] == 'field':
                option = self.options.get(definition['field_path']) or self._linked_options.get(definition['field_path'], {})
                definition.update({key: value for key, value in option.items() if key not in {'path', 'width'}})
            else:
                definition.setdefault('type', 'bytes')
                definition.update(offset=_integer(self.table.item(row, 2).text()), length=_integer(self.table.item(row, 3).text()))
            result.append(definition)
        return result


@dataclass
class _ExpectedValueRow:
    row: int
    uid: str
    identifier: Identifier | None
    input_identifier: Identifier | None
    editable: bool
    editor: QtWidgets.QWidget
    inherited: object


class AncestorValuesEditor(QtWidgets.QWidget):
    changed = QtCore.pyqtSignal()

    def __init__(self, manifest, item, parent=None):
        super().__init__(parent)
        self._loading = True
        self._rows = []
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.enabled = QtWidgets.QCheckBox('Include in automatic decoding when all ancestor values are assigned')
        self.enabled.setChecked(item.get('expected_values') is not None)
        layout.addWidget(self.enabled)
        note = QtWidgets.QLabel('Leave an expected value blank to keep it unassigned. Earlier ancestor values are inherited. Hex input requires 0x, for example 0xcafe. Common fields also accept decimal numbers or their field type. For empty text, enter "".')
        note.setWordWrap(True); layout.addWidget(note)
        self.table = QtWidgets.QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['Defined by', 'Identifier', 'Type', 'Expected value', 'Expected bytes (hex)'])
        self.table.horizontalHeader().setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeToContents)
        self.table.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        self.table.setMinimumHeight(155); layout.addWidget(self.table)
        resolved_owners = {}
        for owner, definition, value, editable in ancestor_assignments(manifest, item):
            row = self.table.rowCount(); self.table.insertRow(row)
            try:
                if owner['uid'] not in resolved_owners:
                    try: resolved_owners[owner['uid']] = {d['uid']: d for d in resolve_definitions(manifest, owner)}
                    except (ValueError, TypeError, KeyError): resolved_owners[owner['uid']] = {}
                resolved = resolved_owners[owner['uid']].get(definition['uid'])
                if resolved is None: resolved = resolve_definitions(manifest, {**owner, 'identifiers': [definition]})[0]
                identifier = Identifier(**resolved)
                input_identifier = (identifier if definition.get('source', 'raw') == 'field' else
                                    replace(identifier, type='bytes', mask=None, shift=0))
            except (ValueError, TypeError, KeyError): identifier = input_identifier = None
            kind = input_identifier.type if input_identifier else 'bytes' if definition.get('source', 'raw') == 'raw' else 'unresolved'
            for column, text in ((0, owner.get('name') or 'Library'), (1, definition.get('name', '')), (2, kind + ('' if editable else ' (inherited)')), (4, '')):
                cell = QtWidgets.QTableWidgetItem(text); cell.setFlags(cell.flags() & ~QtCore.Qt.ItemIsEditable); self.table.setItem(row, column, cell)
            if input_identifier and kind in {'bool', 'enum'}:
                editor = QtWidgets.QComboBox(); editor.setEditable(kind == 'enum')
                if kind == 'bool':
                    editor.addItem('— Unassigned —', None); editor.addItem('False', False); editor.addItem('True', True)
                    editor.setCurrentIndex(0 if value is None else 2 if value else 1)
                else:
                    editor.addItem('', None)
                    for name, number in input_identifier.enum_values: editor.addItem(name, name)
                    selected = next((name for name, number in input_identifier.enum_values if number == value), value)
                    editor.setCurrentText(str(selected) if selected is not None else '')
                    editor.lineEdit().setPlaceholderText('Enum member, decimal, or 0xad')
                editor.currentTextChanged.connect(self._changed)
            else:
                text = str(value) if value is not None else ''
                if value is not None and identifier:
                    try:
                        if kind == 'bytes' or (kind == 'float' and (isinstance(value, dict) or str(value).startswith('bits:'))):
                            text = '0x' + identifier.encode(value).hex()
                        elif kind == 'text' and (not text.strip() or text.startswith('"')): text = json.dumps(text, ensure_ascii=False)
                    except (ValueError, TypeError, OverflowError, LookupError, struct.error): pass
                editor = QtWidgets.QLineEdit(text)
                editor.setPlaceholderText({'bytes': 'Hex bytes, e.g. 0xcafe', 'float': 'Decimal or 0x… (wire bytes)',
                                           'text': 'Text; "" for empty'}.get(kind, 'Decimal or 0xad'))
                editor.textChanged.connect(self._changed)
            self.table.setCellWidget(row, 3, editor)
            self._rows.append(_ExpectedValueRow(row, definition['uid'], identifier, input_identifier, editable, editor, value))
        self.enabled.toggled.connect(self._changed)
        self._loading = False; self._update_preview()

    def _read(self, row):
        identifier, editor = row.input_identifier, row.editor
        if isinstance(editor, QtWidgets.QComboBox) and identifier and identifier.type == 'bool': return editor.currentData()
        text = editor.currentText() if isinstance(editor, QtWidgets.QComboBox) else editor.text()
        if not text.strip(): return None
        if identifier and identifier.type == 'bytes': return _expected_hex_bytes(text).hex()
        if identifier and identifier.type in {'uint', 'int'}: return _integer(text)
        if identifier and identifier.type == 'enum':
            return text if text in dict(identifier.enum_values) else _integer(text)
        if identifier and identifier.type == 'float':
            if text.strip().lower().startswith('0x'): return {'hex': _expected_hex_bytes(text).hex()}
            if text.strip().startswith('bits:'): return {'hex': _expected_hex_bytes(text.strip()[5:]).hex()}
        if identifier and identifier.type == 'text' and text.startswith('"'):
            value = json.loads(text)
            if not isinstance(value, str): raise ValueError('Expected quoted text')
            return value
        return text

    def _update_preview(self):
        for row in self._rows:
            row.editor.setEnabled(row.editable and self.enabled.isChecked())
            cell = self.table.item(row.row, 4); cell.setToolTip('')
            try:
                value = self._read(row) if row.editable else row.inherited
                if value is None: cell.setText('Unassigned'); continue
                if row.identifier is None: raise ValueError('Unresolved definition')
                identifier = row.input_identifier if row.editable else row.identifier
                raw = identifier.encode(value)
                cell.setText('0x' + raw.hex())
                decoded = '0x' + raw.hex() if identifier.type == 'bytes' else identifier.decode(raw)
                cell.setToolTip(f'Encoded value: {decoded!r}' + ('; unmasked bits are ignored' if identifier.mask is not None else ''))
            except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
                cell.setText('Invalid: ' + str(error)); cell.setToolTip(str(error))

    def _changed(self, *args):
        if not self._loading:
            self._update_preview(); self.changed.emit()

    def value(self):
        if not self.enabled.isChecked(): return None
        result = {}
        for row in self._rows:
            if not row.editable: continue
            value = self._read(row)
            if value is None: continue
            if row.identifier is None: raise ValueError('Unresolved definition')
            raw = row.input_identifier.encode(value)
            if row.input_identifier.type == 'bytes':
                # Preserve older typed routing definitions while editing their wire bytes.
                value = ({'hex': raw.hex()} if row.identifier.type == 'float' else row.identifier.decode(raw))
                if row.identifier.encode(value) != raw:
                    raise ValueError('Expected bytes cannot be represented by the stored identifier layout')
            result[row.uid] = value
        return result
