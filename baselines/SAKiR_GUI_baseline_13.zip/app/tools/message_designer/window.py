from __future__ import annotations

import ast
import copy
import json
import os
import re
import struct
import subprocess
import sys
from pathlib import Path
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .commands import ReplaceManifestCommand
from .generation import compatibility_changes, generate_library, remove_empty_orphans
from .field_editor import FieldOptionsEditor
from .member_editor import DefinitionOptionsEditor
from .model import (
    MessageDesignerDocument,
    new_constant,
    new_enum,
    new_field,
    new_group,
    new_id,
    new_manifest,
    new_message,
    new_method,
    normalize_manifest,
    new_runtime_attribute,
    new_structure,
    walk_fields,
)
from .persistence import (
    ExternalModificationError,
    LoadedLibrary,
    LibraryPersistenceError,
    load_library,
    save_library,
)
from .validation import FIELD_KINDS, ValidationIssue, validate_behavior_methods, validate_manifest
from .session import clear_session, default_session_path, load_session, save_session
from .sandbox_values import (
    SandboxValueError,
    format_json_values,
    format_object_values,
    parse_json_values,
    parse_object_values,
    sample_message_values,
)
from .wire_size import WireSizeAnalyzer
from .routing_paths import RoutingMatchError, identify_manifest_route
from .routing_studio import RoutingStudio
from .routing_model import compile_manifest_routing


class DefinitionTree(QtWidgets.QTreeWidget):
    orderDropped = QtCore.pyqtSignal(object)

    def minimumSizeHint(self):
        return QtCore.QSize(220, 140)

    def dropEvent(self, event):
        item = self.currentItem()
        old_parent = item.parent() if item else None
        old_uids = _child_uids(old_parent)
        super().dropEvent(event)
        new_parent = item.parent() if item else None
        if old_parent is not new_parent:
            self.orderDropped.emit(None)
            return
        new_uids = _child_uids(new_parent)
        if old_uids != new_uids:
            self.orderDropped.emit(new_uids)


class MessageDesignerWindow(QtWidgets.QMainWindow):
    """Visual editor and generator for Construct-backed message packages."""

    def __init__(self, parent=None, session_path: Path | str | None = None, *, behavior_opener=None):
        super().__init__(parent)
        self.setWindowFlag(QtCore.Qt.Window, True)
        self._behavior_opener = behavior_opener
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        self.setWindowTitle("Message Designer")
        self.resize(1380, 860)
        self._initial_layout_refreshed = False
        self.session_path = Path(session_path) if session_path is not None else default_session_path()
        recovered = load_session(self.session_path)
        self.document = MessageDesignerDocument(recovered["manifest"] if recovered else None)
        if recovered:
            self.document.saved_snapshot = normalize_manifest(recovered["saved_snapshot"])
        self.undo_stack = QtWidgets.QUndoStack(self)
        self.loaded: LoadedLibrary | None = None
        self.package_parent: Path | None = None
        if recovered and recovered.get("package_dir"):
            try:
                self.loaded = load_library(recovered["package_dir"])
                self.package_parent = self.loaded.package_dir.parent
            except LibraryPersistenceError:
                self.loaded = None
        self._selected_uid = (recovered or {}).get("selected_uid") or self.document.data["library"]["uid"]
        self._restored_expanded_keys = set((recovered or {}).get("expanded_tree_keys", [])) if recovered else None
        self._building_tree = False
        self._tree_initialized = False
        self._tree_items: list[QtWidgets.QTreeWidgetItem] = []
        self._item_by_uid: dict[str, QtWidgets.QTreeWidgetItem] = {}
        self._category_items: dict[str, QtWidgets.QTreeWidgetItem] = {}
        self._filter_expansion_snapshot: set[str] | None = None
        self._filter_matches: list[QtWidgets.QTreeWidgetItem] = []
        self._problem_uids: set[str] = set()
        self._loading_properties = False
        self._properties_pending = False
        self._compiled_preview_router = None
        self._build_actions()
        self._build_ui()
        self.document.on_change(self._document_changed)
        self._refresh_all()
        if recovered and self.document.is_dirty:
            self.statusBar().showMessage("Recovered unsaved changes from the previous Message Designer session.", 12000)

    def _build_actions(self):
        self.new_action = QtWidgets.QAction("New", self)
        self.open_action = QtWidgets.QAction("Open…", self)
        self.save_action = QtWidgets.QAction("Save", self)
        self.save_as_action = QtWidgets.QAction("Save As…", self)
        self.open_code_action = QtWidgets.QAction("Open behaviors.py", self)
        self.cleanup_code_action = QtWidgets.QAction("Clean Empty Orphans", self)
        self.collapse_all_action = QtWidgets.QAction("Collapse All", self)
        self.focus_tree_search_action = QtWidgets.QAction("Find definition", self)
        self.focus_tree_search_action.setShortcut(QtGui.QKeySequence.Find)
        self.next_tree_match_action = QtWidgets.QAction("Next navigator match", self)
        self.next_tree_match_action.setShortcut(QtGui.QKeySequence("F3"))
        self.previous_tree_match_action = QtWidgets.QAction("Previous navigator match", self)
        self.previous_tree_match_action.setShortcut(QtGui.QKeySequence("Shift+F3"))
        self.clear_tree_filters_action = QtWidgets.QAction("Clear navigator filters", self)
        self.clear_tree_filters_action.setShortcut(QtGui.QKeySequence("Escape"))
        self.addActions([
            self.focus_tree_search_action, self.next_tree_match_action,
            self.previous_tree_match_action, self.clear_tree_filters_action,
        ])
        self.new_action.setShortcut(QtGui.QKeySequence.New)
        self.open_action.setShortcut(QtGui.QKeySequence.Open)
        self.save_action.setShortcut(QtGui.QKeySequence.Save)
        self.new_action.triggered.connect(self.new_library)
        self.open_action.triggered.connect(self.open_library)
        self.save_action.triggered.connect(self.save_library)
        self.save_as_action.triggered.connect(lambda: self.save_library(save_as=True))
        self.open_code_action.triggered.connect(self.open_behavior_code)
        self.cleanup_code_action.triggered.connect(self.cleanup_empty_orphans)
        self.collapse_all_action.triggered.connect(self._collapse_all_tree)
        self.focus_tree_search_action.triggered.connect(self._focus_tree_search)
        self.next_tree_match_action.triggered.connect(lambda: self._navigate_tree_match(1))
        self.previous_tree_match_action.triggered.connect(lambda: self._navigate_tree_match(-1))
        self.clear_tree_filters_action.triggered.connect(self._clear_tree_filters)

    def _build_ui(self):
        file_menu = self.menuBar().addMenu("&File")
        file_menu.addActions([self.new_action, self.open_action, self.save_action, self.save_as_action])
        file_menu.addSeparator()
        file_menu.addAction("Close", self.close)
        edit_menu = self.menuBar().addMenu("&Edit")
        edit_menu.addAction(self.undo_stack.createUndoAction(self, "Undo"))
        edit_menu.addAction(self.undo_stack.createRedoAction(self, "Redo"))
        code_menu = self.menuBar().addMenu("&Code")
        code_menu.addAction(self.open_code_action)
        code_menu.addAction(self.cleanup_code_action)

        toolbar = self.addToolBar("Message Designer")
        toolbar.setMovable(False)
        toolbar.addActions([self.new_action, self.open_action, self.save_action])
        toolbar.addSeparator()
        self.reorder_actions = []
        for label, callback in (
            ("+ Enum", self.add_enum), ("+ Struct", self.add_structure),
            ("+ Message", self.add_message), ("+ Field", self.add_field),
            ("+ Runtime", self.add_runtime), ("+ Constant", self.add_constant),
            ("+ Method", self.add_method), ("Duplicate", self.duplicate_selected),
            ("Delete", self.delete_selected), ("Up", lambda: self.move_selected(-1)),
            ("Down", lambda: self.move_selected(1)),
        ):
            action = toolbar.addAction(label)
            action.triggered.connect(callback)
            if label in {"Up", "Down"}:
                self.reorder_actions.append(action)
        toolbar.addSeparator()
        toolbar.addAction(self.open_code_action)
        toolbar.addSeparator()
        toolbar.addAction(self.collapse_all_action)

        self.tabs = QtWidgets.QTabWidget()
        self.save_state_label = QtWidgets.QLabel()
        self.save_state_label.setObjectName("messageDesignerSaveState")
        self.save_state_label.setMaximumWidth(600)
        self.tabs.setCornerWidget(self.save_state_label, QtCore.Qt.TopRightCorner)
        self.setCentralWidget(self.tabs)
        self.definitions_page = self._definitions_page()
        self.tabs.addTab(self.definitions_page, "Definitions")
        self.tabs.addTab(self._sandbox_page(), "Hex Sandbox")
        self.tabs.addTab(self._code_page(), "Generated Code")
        self.routing_studio = RoutingStudio()
        self.routing_studio.manifestApplied.connect(self._apply_routing_manifest)
        self.routing_studio.pendingChanged.connect(lambda _: self._refresh_all_title_only())
        self.routing_studio.validationChanged.connect(self._refresh_routing_validation)
        self.routing_studio.issues.itemActivated.connect(self._activate_issue)
        self.routing_studio.issues.customContextMenuRequested.connect(
            lambda position: self._show_issue_context_menu(position, self.routing_studio.issues)
        )
        self.routing_studio.reparentRequested.connect(self._reparent_routing_item)
        self.routing_studio.openDefinitionRequested.connect(self._open_routing_definition)
        self.tabs.insertTab(1, self.routing_studio, "Routing")
        self.tabs.currentChanged.connect(self._workspace_changed)
        self.statusBar().showMessage("Ready")

    def _definitions_page(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setSizeConstraint(QtWidgets.QLayout.SetNoConstraint)
        self.definitions_heading = QtWidgets.QLabel("Message library definitions")
        self.definitions_heading.setStyleSheet("font-size: 16px; font-weight: 600;")
        layout.addWidget(self.definitions_heading)
        splitter = QtWidgets.QSplitter()
        self.definition_splitter = splitter
        splitter.setChildrenCollapsible(False)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, 1)

        navigator = QtWidgets.QFrame()
        navigator.setFrameStyle(QtWidgets.QFrame.StyledPanel | QtWidgets.QFrame.Sunken)
        navigator.setAutoFillBackground(True)
        navigator.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        navigator_layout = QtWidgets.QVBoxLayout(navigator)
        navigator_layout.setSpacing(5)
        search_row = QtWidgets.QHBoxLayout()
        self.tree_search = QtWidgets.QLineEdit()
        self.tree_search.setPlaceholderText("Search names, types, sizes, or directions…")
        self.tree_search.setClearButtonEnabled(True)
        self.tree_scope = QtWidgets.QComboBox()
        self.tree_scope.addItems(["All", "Definitions", "Fields", "Class members", "Problems"])
        search_row.addWidget(self.tree_search, 1); search_row.addWidget(self.tree_scope)
        navigator_layout.addLayout(search_row)
        filter_row = QtWidgets.QHBoxLayout()
        self.tree_clear_filters = QtWidgets.QToolButton(); self.tree_clear_filters.setText("Clear filters")
        self.tree_expand_matches = QtWidgets.QToolButton(); self.tree_expand_matches.setText("Expand matches")
        self.tree_collapse_all = QtWidgets.QToolButton(); self.tree_collapse_all.setText("Collapse all")
        filter_row.addWidget(self.tree_clear_filters); filter_row.addStretch()
        filter_row.addWidget(self.tree_expand_matches); filter_row.addWidget(self.tree_collapse_all)
        navigator_layout.addLayout(filter_row)
        self.tree_result_label = QtWidgets.QLabel("All definitions")
        self.tree_result_label.setStyleSheet("color: palette(mid);")
        navigator_layout.addWidget(self.tree_result_label)

        self.tree = DefinitionTree()
        self.tree.setHeaderLabels(["Library definition", "Type", "Size", "Direction"])
        self.tree.setSortingEnabled(False)
        self.tree.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        self.tree.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setMinimumSectionSize(44)
        for column in range(self.tree.columnCount()):
            self.tree.header().setSectionResizeMode(column, QtWidgets.QHeaderView.Interactive)
        self.tree.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.tree.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollPerPixel)
        self.tree.setTextElideMode(QtCore.Qt.ElideNone)
        self.tree.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.tree.currentItemChanged.connect(self._selection_changed)
        self.tree.orderDropped.connect(self._tree_order_dropped)
        self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_tree_context_menu)
        self.tree.itemExpanded.connect(self._tree_expansion_changed)
        self.tree.itemCollapsed.connect(self._tree_expansion_changed)
        navigator_layout.addWidget(self.tree, 1)
        splitter.addWidget(navigator)
        self.tree_filter_timer = QtCore.QTimer(self); self.tree_filter_timer.setSingleShot(True)
        self.tree_filter_timer.setInterval(150); self.tree_filter_timer.timeout.connect(self._apply_tree_filter)
        self.tree_search.textChanged.connect(lambda: self.tree_filter_timer.start())
        self.tree_scope.currentTextChanged.connect(self._apply_tree_filter)
        self.tree_clear_filters.clicked.connect(self._clear_tree_filters)
        self.tree_expand_matches.clicked.connect(self._expand_tree_matches)
        self.tree_collapse_all.clicked.connect(self._collapse_all_tree)
        self.tree_session_timer = QtCore.QTimer(self); self.tree_session_timer.setSingleShot(True)
        self.tree_session_timer.setInterval(200); self.tree_session_timer.timeout.connect(self._store_session)

        editor = QtWidgets.QFrame()
        editor.setFrameStyle(QtWidgets.QFrame.StyledPanel | QtWidgets.QFrame.Sunken)
        editor.setAutoFillBackground(True)
        editor.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        editor_layout = QtWidgets.QVBoxLayout(editor)
        self.editor_title = QtWidgets.QLabel("Selection")
        self.editor_title.setStyleSheet("font-size: 17px; font-weight: 600;")
        editor_layout.addWidget(self.editor_title)
        self.category_info = QtWidgets.QFrame()
        self.category_info.setFrameShape(QtWidgets.QFrame.StyledPanel)
        category_info_layout = QtWidgets.QVBoxLayout(self.category_info)
        self.category_info_title = QtWidgets.QLabel()
        self.category_info_title.setStyleSheet("font-size: 16px; font-weight: 600;")
        self.category_info_text = QtWidgets.QLabel()
        self.category_info_text.setWordWrap(True)
        self.category_info_text.setStyleSheet("color: #52627a; line-height: 1.35;")
        category_info_layout.addWidget(self.category_info_title)
        category_info_layout.addWidget(self.category_info_text)
        category_info_layout.addStretch()
        self.category_info.setVisible(False)
        editor_layout.addWidget(self.category_info, 1)
        self.common_properties_widget = QtWidgets.QWidget()
        form = QtWidgets.QFormLayout(self.common_properties_widget)
        self.name_edit = QtWidgets.QLineEdit()
        self.name_edit.textChanged.connect(self._properties_edited)
        self.kind_combo = QtWidgets.QComboBox()
        self.kind_combo.addItems(sorted(FIELD_KINDS))
        self.kind_combo.currentTextChanged.connect(self._field_kind_changed)
        form.addRow("Name", self.name_edit)
        form.addRow("Field type", self.kind_combo)
        self.kind_label = form.labelForField(self.kind_combo)
        editor_layout.addWidget(self.common_properties_widget)
        self.field_options_group = QtWidgets.QGroupBox("Field settings")
        field_options_layout = QtWidgets.QVBoxLayout(self.field_options_group)
        self.field_options = FieldOptionsEditor()
        self.field_options.changed.connect(self._properties_edited)
        self.field_scroll = QtWidgets.QScrollArea()
        self.field_scroll.setWidgetResizable(True)
        self.field_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.field_scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.field_scroll.setWidget(self.field_options)
        field_options_layout.addWidget(self.field_scroll)
        editor_layout.addWidget(self.field_options_group, 1)
        self.definition_options_group = QtWidgets.QGroupBox("Definition settings")
        definition_options_layout = QtWidgets.QVBoxLayout(self.definition_options_group)
        self.definition_options = DefinitionOptionsEditor()
        self.definition_options.changed.connect(self._properties_edited)
        definition_scroll = QtWidgets.QScrollArea()
        definition_scroll.setWidgetResizable(True)
        definition_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        definition_scroll.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        definition_scroll.setWidget(self.definition_options)
        definition_options_layout.addWidget(definition_scroll)
        editor_layout.addWidget(self.definition_options_group, 1)
        self.json_label = QtWidgets.QLabel("Definition properties (JSON)")
        editor_layout.addWidget(self.json_label)
        self.details_edit = QtWidgets.QPlainTextEdit()
        self.details_edit.setTabStopDistance(24)
        self.details_edit.textChanged.connect(self._properties_edited)
        editor_layout.addWidget(self.details_edit, 1)
        self.reference_label = QtWidgets.QLabel()
        self.reference_label.setWordWrap(True)
        self.reference_label.setStyleSheet("color: #52627a;")
        editor_layout.addWidget(self.reference_label)
        self.dependencies = QtWidgets.QTreeWidget()
        self.dependencies.setHeaderLabels(["Dependency", "Target"])
        self.dependencies.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.dependencies.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.dependencies.setMaximumHeight(130)
        editor_layout.addWidget(self.dependencies)
        self.property_actions_widget = QtWidgets.QWidget()
        property_actions_layout = QtWidgets.QHBoxLayout(self.property_actions_widget)
        property_actions_layout.setContentsMargins(0, 0, 0, 0)
        self.property_state_label = QtWidgets.QLabel("All property changes are applied.")
        self.property_state_label.setWordWrap(True)
        property_actions_layout.addWidget(self.property_state_label, 1)
        self.open_routing_button = QtWidgets.QPushButton("Open in Routing")
        self.open_routing_button.clicked.connect(self._open_selected_routing)
        self.open_routing_button.setVisible(False)
        property_actions_layout.addWidget(self.open_routing_button)
        self.apply_button = QtWidgets.QPushButton("Apply Properties")
        self.apply_button.clicked.connect(self.apply_properties)
        property_actions_layout.addWidget(self.apply_button)
        editor_layout.addWidget(self.property_actions_widget)
        splitter.addWidget(editor)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        self.issues = QtWidgets.QTreeWidget()
        self.issues.setHeaderLabels(["Severity", "Validation issue", "Suggested action"])
        self.issues.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.issues.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.issues.itemActivated.connect(self._activate_issue)
        self.issues.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.issues.customContextMenuRequested.connect(self._show_issue_context_menu)
        self.issues.setMaximumHeight(190)
        layout.addWidget(self.issues)
        return page

    def showEvent(self, event):
        super().showEvent(event)
        if not self._initial_layout_refreshed:
            self._initial_layout_refreshed = True
            QtCore.QTimer.singleShot(0, self._refresh_initial_layout)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._initial_layout_refreshed:
            QtCore.QTimer.singleShot(0, self._refresh_initial_layout)

    def _refresh_initial_layout(self):
        total_width = self.definition_splitter.width()
        if total_width > 0:
            scrollbar_width = self.tree.style().pixelMetric(
                QtWidgets.QStyle.PM_ScrollBarExtent, None, self.tree
            )
            tree_width = (
                self.tree.header().length()
                + self.tree.frameWidth() * 2
                + scrollbar_width
                + 8
            )
            navigator = self.definition_splitter.widget(0)
            margins = navigator.layout().contentsMargins()
            tree_width += margins.left() + margins.right() + navigator.frameWidth() * 2
            desired_navigator_width = max(380, tree_width)
            editor_minimum_width = 305
            available_navigator_width = max(260, total_width - editor_minimum_width)
            if not hasattr(self, "_preferred_navigator_width"):
                self._preferred_navigator_width = min(desired_navigator_width, available_navigator_width)
            navigator_width = min(self._preferred_navigator_width, available_navigator_width)
            self.definition_splitter.setSizes(
                [navigator_width, max(1, total_width - navigator_width)]
            )
        current_page = self.tabs.currentWidget()
        if current_page is not None and current_page.layout() is not None:
            current_page.layout().invalidate()
            current_page.layout().activate()
        self.field_options._refresh_geometry()
        self.field_scroll.updateGeometry()
        self.field_scroll.viewport().updateGeometry()

    def _sandbox_page(self):
        page = QtWidgets.QWidget()
        page.setObjectName("messageDesignerSandbox")
        layout = QtWidgets.QVBoxLayout(page)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        heading = QtWidgets.QLabel("Build, inspect, and verify a message")
        heading.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(heading)
        introduction = QtWidgets.QLabel(
            "Choose a message class, then build bytes from structured values or parse existing wire bytes. "
            "All generated code runs in a separate local subprocess."
        )
        introduction.setWordWrap(True)
        introduction.setStyleSheet("color: palette(mid);")
        layout.addWidget(introduction)

        controls = QtWidgets.QFrame()
        controls.setObjectName("sandboxControls")
        controls.setFrameShape(QtWidgets.QFrame.StyledPanel)
        controls_layout = QtWidgets.QHBoxLayout(controls)
        controls_layout.setContentsMargins(12, 10, 12, 10)
        message_block = QtWidgets.QVBoxLayout()
        message_label = QtWidgets.QLabel("MESSAGE CLASS")
        message_label.setStyleSheet("font-size: 10px; font-weight: 600; color: palette(mid);")
        self.preview_message = QtWidgets.QComboBox()
        self.preview_message.setMinimumWidth(250)
        self.preview_message.setToolTip("Generated message class used for this sandbox operation")
        message_block.addWidget(message_label)
        message_block.addWidget(self.preview_message)
        controls_layout.addLayout(message_block, 1)
        controls_layout.addSpacing(12)

        self.preview_build_button = QtWidgets.QPushButton("Build bytes")
        self.preview_build_button.setObjectName("sandboxPrimaryAction")
        self.preview_build_button.setToolTip("Encode the structured values on the left into wire bytes")
        self.preview_parse_button = QtWidgets.QPushButton("Parse bytes")
        self.preview_parse_button.setToolTip("Decode the wire bytes on the right into structured values")
        self.preview_round_trip_button = QtWidgets.QPushButton("Verify round trip")
        self.preview_round_trip_button.setToolTip("Parse the wire bytes, rebuild them, and compare the result byte for byte")
        self.preview_auto_button = QtWidgets.QPushButton("Auto parse")
        self.preview_auto_button.setToolTip("Route by group and composite message identity, then parse with the selected class")
        self.preview_action_buttons = (
            self.preview_build_button, self.preview_parse_button, self.preview_round_trip_button,
            self.preview_auto_button,
        )
        for button, action in zip(self.preview_action_buttons[:3], ("build", "parse", "round_trip")):
            button.setMinimumHeight(34)
            button.clicked.connect(lambda checked=False, selected=action: self.run_sandbox(selected))
            controls_layout.addWidget(button)
        layout.addWidget(controls)
        self.preview_auto_button.setMinimumHeight(34)
        self.preview_auto_button.clicked.connect(lambda checked=False: self.run_sandbox("auto_parse"))
        routing_row = QtWidgets.QHBoxLayout()
        routing_row.addWidget(QtWidgets.QLabel('Decode scope'))
        self.preview_group_scope = QtWidgets.QComboBox(); routing_row.addWidget(self.preview_group_scope, 1)
        self.preview_direction = QtWidgets.QComboBox()
        self.preview_direction.addItem('Direction: unspecified', None)
        self.preview_direction.addItem('TX', 'TX'); self.preview_direction.addItem('RX', 'RX')
        for combo in (self.preview_group_scope, self.preview_direction):
            combo.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            combo.setMinimumContentsLength(8)
            combo.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon)
        routing_row.addWidget(self.preview_direction); routing_row.addWidget(self.preview_auto_button)
        layout.addLayout(routing_row)

        editors = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        editors.setChildrenCollapsible(False)
        self.preview_editors_splitter = editors
        values_group = QtWidgets.QGroupBox("Message initialization")
        values_layout = QtWidgets.QVBoxLayout(values_group)
        values_header = QtWidgets.QHBoxLayout()
        self.preview_values_hint = QtWidgets.QLabel()
        self.preview_values_hint.setWordWrap(True)
        self.preview_values_hint.setStyleSheet("color: palette(mid);")
        values_header.addWidget(self.preview_values_hint, 1)
        format_label = QtWidgets.QLabel("VIEW AS")
        format_label.setStyleSheet("font-size: 10px; font-weight: 600; color: palette(mid);")
        values_header.addWidget(format_label)
        self.preview_value_format = QtWidgets.QComboBox()
        self.preview_value_format.addItem("Object initialization", "object")
        self.preview_value_format.addItem("JSON", "json")
        self.preview_value_format.setToolTip(
            "Switch representations. The current values are converted automatically."
        )
        values_header.addWidget(self.preview_value_format)
        values_layout.addLayout(values_header)
        self._preview_value_mode = "object"
        self._preview_rendered_message = ""
        self._preview_value_drafts = {}
        self._preview_sample_values = {}
        self.preview_values = QtWidgets.QPlainTextEdit()
        self.preview_values.setObjectName("sandboxValuesEditor")
        self.preview_values.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.preview_values.setTabStopDistance(24)
        self.preview_values.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.preview_values.setPlaceholderText("MessageName(\n    field_name=0,\n)")
        values_layout.addWidget(self.preview_values)
        values_footer = QtWidgets.QHBoxLayout()
        values_footer.addStretch()
        self.preview_format_json_button = QtWidgets.QPushButton("Format object")
        self.preview_format_json_button.clicked.connect(self._format_preview_json)
        values_footer.addWidget(self.preview_format_json_button)
        values_layout.addLayout(values_footer)
        editors.addWidget(values_group)

        hex_group = QtWidgets.QGroupBox("Wire bytes")
        hex_layout = QtWidgets.QVBoxLayout(hex_group)
        hex_hint = QtWidgets.QLabel(
            "Output from Build bytes, or input for Parse bytes and Verify round trip. Whitespace is ignored."
        )
        hex_hint.setWordWrap(True)
        hex_hint.setStyleSheet("color: palette(mid);")
        hex_layout.addWidget(hex_hint)
        self.preview_hex = QtWidgets.QPlainTextEdit()
        self.preview_hex.setObjectName("sandboxHexEditor")
        self.preview_hex.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.preview_hex.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.preview_hex.setPlaceholderText("00 01 ff …")
        self.preview_hex.textChanged.connect(self._update_preview_byte_count)
        hex_layout.addWidget(self.preview_hex)
        hex_footer = QtWidgets.QHBoxLayout()
        self.preview_byte_count = QtWidgets.QLabel("0 bytes")
        self.preview_byte_count.setStyleSheet("color: palette(mid);")
        hex_footer.addWidget(self.preview_byte_count)
        hex_footer.addStretch()
        self.preview_normalize_hex_button = QtWidgets.QPushButton("Normalize hex")
        self.preview_normalize_hex_button.clicked.connect(self._normalize_preview_hex)
        hex_footer.addWidget(self.preview_normalize_hex_button)
        hex_layout.addLayout(hex_footer)
        editors.addWidget(hex_group)
        editors.setSizes([620, 620])
        layout.addWidget(editors, 3)

        result_group = QtWidgets.QGroupBox("Decoded result")
        result_layout = QtWidgets.QVBoxLayout(result_group)
        result_hint = QtWidgets.QLabel("Nested values are shown by path after a successful operation.")
        result_hint.setStyleSheet("color: palette(mid);")
        result_layout.addWidget(result_hint)
        self.preview_result = QtWidgets.QTreeWidget()
        self.preview_result.setHeaderLabels(["Path", "Type", "Value"])
        self.preview_result.setAlternatingRowColors(True)
        self.preview_result.setRootIsDecorated(True)
        self.preview_result.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.preview_result.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.preview_result.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        result_layout.addWidget(self.preview_result)
        layout.addWidget(result_group, 2)

        self.preview_status = QtWidgets.QLabel()
        self.preview_status.setObjectName("sandboxStatus")
        self.preview_status.setWordWrap(True)
        self.preview_status.setMinimumHeight(38)
        layout.addWidget(self.preview_status)
        self._set_preview_status("Select a message and choose an operation when you are ready.", "info")
        self.preview_value_format.currentIndexChanged.connect(self._preview_value_format_changed)
        self.preview_message.currentTextChanged.connect(self._preview_message_changed)
        self._update_preview_value_controls()
        return page

    def _code_page(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        self.code_tabs = QtWidgets.QTabWidget()
        self.code_editors = {}
        for name in ("models.py", "registry.py", "behaviors.py", "__init__.py"):
            editor = QtWidgets.QPlainTextEdit()
            editor.setReadOnly(True)
            editor.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
            self.code_tabs.addTab(editor, name)
            self.code_editors[name] = editor
        layout.addWidget(self.code_tabs)
        return page

    def _document_changed(self, reason="changed"):
        self._compiled_preview_router = None
        self._store_session()
        self._refresh_all()

    def _refresh_all(self):
        routing_uid = self.routing_studio._selected_uid or self._selected_uid
        self._rebuild_tree()
        self._refresh_validation()
        self._refresh_preview_messages()
        self._refresh_code()
        self.routing_studio.refresh(self.document.data, routing_uid)
        package = self.document.data.get("library", {}).get("package_name", "message library")
        states = []
        if self.loaded is None:
            states.append("Not saved")
        elif self.document.is_dirty:
            states.append("Changes not saved")
        if self._properties_pending:
            states.append("Property changes not applied")
        if self.routing_studio.apply.isEnabled():
            states.append("Routing changes not applied")
        suffix = " — " + " · ".join(states) if states else ""
        self.setWindowTitle(f"Message Designer — {package}{suffix}")
        if self.loaded is None:
            text, color = "Not saved", "#9a6700"
            tooltip = "This library has not been saved to a folder yet."
        elif self.document.is_dirty:
            text, color = "Unsaved changes", "#b54708"
            tooltip = f"Unsaved changes. Target: {self.loaded.package_dir}"
        else:
            text, color = "Saved", "#287d3c"
            tooltip = f"Saved library: {self.loaded.package_dir}"
        self.save_state_label.setText(text)
        self.save_state_label.setToolTip(tooltip)
        self.save_state_label.setStyleSheet(f"padding: 6px; border-radius: 3px; color: {color}; background: rgba(128,128,128,0.10);")

    def _apply_routing_manifest(self, after, text):
        before = self.document.snapshot()
        if self._properties_pending:
            try:
                self._merge_property_edits(after)
            except (json.JSONDecodeError, ValueError, TypeError) as error:
                QtWidgets.QMessageBox.warning(self, "Invalid properties", str(error))
                return False
        self._properties_pending = False
        if before != after:
            self.undo_stack.push(ReplaceManifestCommand(self.document, before, after, text or "Edit routing"))
        else:
            self.routing_studio.refresh(self.document.data)
            self._update_property_state()
            self._refresh_all_title_only()
        return True

    def _workspace_changed(self, index):
        if self.tabs.widget(index) is self.routing_studio and not self.routing_studio.apply.isEnabled():
            self.routing_studio.refresh(self.document.data, self._selected_uid)

    def _add_routing_group(self, parent_uid=""):
        def operation(data):
            parent = next((item for item in data.get("groups", []) if item.get("uid") == parent_uid), None)
            group = new_group(_unique_name(data, "NewGroup"), parent_uid if parent else "")
            data.setdefault("groups", []).append(group)
            return group["uid"]
        self._mutate("Add routing group", operation)

    def _add_routing_message(self, group_uid=""):
        def operation(data):
            groups = data.get("groups", [])
            selected_group = group_uid if group_uid in {data['library']['uid'], *(group['uid'] for group in groups)} else data['library']['uid']
            message = new_message(_unique_name(data, "NewMessage"))
            message["group_uid"] = selected_group
            data.setdefault("messages", []).append(message)
            return message["uid"]
        self._mutate("Add routing message", operation)

    def _reparent_routing_item(self, uid, parent_uid, kind):
        if kind not in {"Group", "Message"}:
            self.routing_studio.refresh(self.document.data, uid)
            return
        groups = self.document.data.get("groups", [])
        if kind == "Group":
            current = next((item for item in groups if item.get("uid") == uid), None)
            parent = next((item for item in groups if item.get("uid") == parent_uid), None)
            seen = set()
            cursor = parent
            while cursor and cursor.get("uid") not in seen:
                if cursor.get("uid") == uid:
                    self.routing_studio.refresh(self.document.data, uid)
                    return
                seen.add(cursor.get("uid"))
                cursor = next(
                    (item for item in groups if item.get("uid") == cursor.get("parent_group_uid")),
                    None,
                )
            resolved_parent_uid = parent_uid if parent else ""
            if current is None or current.get("parent_group_uid", "") == resolved_parent_uid:
                self.routing_studio.refresh(self.document.data, uid)
                return
        else:
            current = next((item for item in self.document.data.get("messages", []) if item.get("uid") == uid), None)
            parent = next((item for item in groups if item.get("uid") == parent_uid), None)
            if current is None or (parent is None and parent_uid != self.document.data["library"]["uid"]) or current.get("group_uid", "") == parent_uid:
                self.routing_studio.refresh(self.document.data, uid)
                return

        def operation(data):
            groups = data.get("groups", [])
            if kind == "Group":
                group = next((item for item in groups if item.get("uid") == uid), None)
                if group is None or parent_uid == uid:
                    return uid
                descendants = set()
                pending = [uid]
                while pending:
                    current = pending.pop()
                    for child in groups:
                        if child.get("parent_group_uid") == current and child.get("uid") not in descendants:
                            descendants.add(child.get("uid")); pending.append(child.get("uid"))
                if parent_uid in descendants:
                    return uid
                parent = next((item for item in groups if item.get("uid") == parent_uid), None)
                group["parent_group_uid"] = parent_uid if parent else ""
                group["expected_values"] = None
                return uid
            message = next((item for item in data.get("messages", []) if item.get("uid") == uid), None)
            parent = next((item for item in groups if item.get("uid") == parent_uid), None)
            if message is None or (parent is None and parent_uid != data["library"]["uid"]):
                return uid
            message["group_uid"] = parent_uid
            message["expected_values"] = None
            return uid

        self._mutate("Move routing item", operation)

    def _open_routing_definition(self, uid):
        item = self._item_by_uid.get(uid)
        if item is None:
            return
        self.tabs.setCurrentWidget(self.definitions_page)
        self.tree.setCurrentItem(item)
        self.tree.scrollToItem(item)

    def _open_selected_routing(self):
        item = self.tree.currentItem()
        info = (item.data(0, QtCore.Qt.UserRole) or {}) if item is not None else {}
        if info.get("kind") not in {"Group", "Message"}:
            return
        uid = info.get("uid")
        self.tabs.setCurrentWidget(self.routing_studio)
        target = self.routing_studio._find_item(uid)
        if target is None:
            return
        if target.isHidden():
            self.routing_studio.search.clear()
        self.routing_studio.tree.setCurrentItem(target)
        if self.routing_studio.tree.currentItem() is not target:
            return
        parent = target.parent()
        while parent:
            parent.setExpanded(True); parent = parent.parent()
        self.routing_studio.tree.scrollToItem(target)

    def _rebuild_tree(self):
        first_build = not self._tree_initialized
        if self._tree_initialized:
            expanded_keys = (
                set(self._filter_expansion_snapshot)
                if self._filters_active() and self._filter_expansion_snapshot is not None
                else self._expanded_tree_keys()
            )
        else:
            expanded_keys = self._restored_expanded_keys
        self._building_tree = True
        self.tree.clear()
        self._tree_items = []; self._item_by_uid = {}; self._category_items = {}
        self._wire_size_analyzer = WireSizeAnalyzer(self.document.data)
        root_data = self.document.data["library"]
        root = self._tree_item(root_data, "Library")
        self.tree.addTopLevelItem(root)
        categories = (
            ("Enums", self.document.data.get("enums", []), "Enum"),
            ("Structures", self.document.data.get("structures", []), "Structure"),
            ("Messages", self.document.data.get("groups", []), "Group"),
        )
        for title, values, kind in categories:
            category = QtWidgets.QTreeWidgetItem([f"{title} ({len(values)})", "", "", ""])
            category.setData(0, QtCore.Qt.UserRole, {"category": title.lower(), "base_title": title, "total": len(values)})
            self._tree_items.append(category); self._category_items[title.lower()] = category
            if kind == "Group":
                total_messages = len(self.document.data.get("messages", []))
                category.setText(0, f"Messages ({total_messages})")
                category.setData(0, QtCore.Qt.UserRole, {
                    "category": "messages", "base_title": "Messages", "total": total_messages,
                })
            root.addChild(category)
            visible_values = (
                [value for value in values if not value.get("parent_group_uid")]
                if kind == "Group" else values
            )
            for value in visible_values:
                if kind == "Group":
                    self._append_group_tree_item(category, value)
                    continue
                item = self._tree_item(value, kind)
                category.addChild(item)
                if kind in {"Structure", "Message"}:
                    self._append_field_items(item, value.get("fields", []), value["uid"])
                if kind == "Message":
                    for key, label in (("runtime_attributes", "Runtime"), ("constants", "Constant"), ("methods", "Method")):
                        if not value.get(key):
                            continue
                        group = QtWidgets.QTreeWidgetItem([label + "s", "", "", ""])
                        group.setData(0, QtCore.Qt.UserRole, {"category": key, "owner_uid": value["uid"]})
                        self._tree_items.append(group)
                        item.addChild(group)
                        for member in value.get(key, []):
                            group.addChild(self._tree_item(member, label, value["uid"]))
        category = self._category_items['messages']
        for message in self.document.data.get('messages', []):
            if _message_group_uid(self.document.data, message) == root_data['uid']:
                self._append_message_tree_item(category, message)
        if expanded_keys is None:
            root.setExpanded(True)
            for index in range(root.childCount()):
                root.child(index).setExpanded(True)
        else:
            iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
            while iterator.value():
                item = iterator.value()
                item.setExpanded(self._tree_expansion_key(item) in expanded_keys)
                iterator += 1
        selected = self._find_tree_item(self._selected_uid)
        selected = selected or root
        self.tree.setCurrentItem(selected)
        if first_build:
            for column in range(1, self.tree.columnCount()):
                self.tree.resizeColumnToContents(column)
        self._ensure_definition_column_fits()
        self._building_tree = False
        self._tree_initialized = True
        self._selection_changed(selected, None)
        self._apply_tree_filter()

    def _append_group_tree_item(self, parent, group):
        item = self._tree_item(group, "Group")
        parent.addChild(item)
        child_groups = [
            child for child in self.document.data.get("groups", [])
            if child.get("parent_group_uid") == group.get("uid")
        ]
        messages = [
            message for message in self.document.data.get("messages", [])
            if _message_group_uid(self.document.data, message) == group.get("uid")
        ]
        item.setText(0, f"{group.get('name', 'Group')} ({len(child_groups) + len(messages)})")
        for child in child_groups:
            self._append_group_tree_item(item, child)
        for message in messages:
            self._append_message_tree_item(item, message)

    def _append_message_tree_item(self, parent, message):
        message_item = self._tree_item(message, "Message")
        parent.addChild(message_item)
        self._append_field_items(message_item, message.get("fields", []), message["uid"])
        for key, label in (("runtime_attributes", "Runtime"), ("constants", "Constant"), ("methods", "Method")):
            if not message.get(key):
                continue
            member_group = QtWidgets.QTreeWidgetItem([label + "s", "", "", ""])
            member_group.setData(0, QtCore.Qt.UserRole, {"category": key, "owner_uid": message["uid"]})
            self._tree_items.append(member_group); message_item.addChild(member_group)
            for member in message.get(key, []):
                member_group.addChild(self._tree_item(member, label, message["uid"]))

    def _ensure_definition_column_fits(self):
        """Grow the hierarchy column for its deepest label without overriding wider user sizing."""
        required = self.tree.fontMetrics().horizontalAdvance(self.tree.headerItem().text(0)) + 28
        indentation = self.tree.indentation()
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            depth = 0
            parent = item.parent()
            while parent is not None:
                depth += 1
                parent = parent.parent()
            metrics = QtGui.QFontMetrics(item.font(0))
            item_width = metrics.horizontalAdvance(item.text(0)) + indentation * (depth + 1) + 18
            required = max(required, item_width)
            iterator += 1
        if required > self.tree.columnWidth(0):
            self.tree.setColumnWidth(0, required)

    def _tree_expansion_key(self, item):
        info = item.data(0, QtCore.Qt.UserRole) or {}
        if info.get("uid"):
            return "uid:" + info["uid"]
        if info.get("category"):
            return f"category:{info.get('owner_uid', '')}:{info['category']}"
        return "label:" + item.text(0)

    def _expanded_tree_keys(self):
        keys = set()
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            if item.isExpanded():
                keys.add(self._tree_expansion_key(item))
            iterator += 1
        return keys

    def _collapse_all_tree(self):
        self.tree.collapseAll()

    def _filters_active(self):
        if not hasattr(self, "tree_search"):
            return False
        return bool(
            self.tree_search.text().strip()
            or self.tree_scope.currentText() != "All"
        )

    def _focus_tree_search(self):
        if hasattr(self, "tree_search"):
            self.tree_search.setFocus(); self.tree_search.selectAll()

    def _tree_expansion_changed(self, item):
        if not self._building_tree and not self._filters_active() and hasattr(self, "tree_session_timer"):
            self.tree_session_timer.start()

    def _clear_tree_filters(self):
        if not hasattr(self, "tree_search"):
            return
        self.tree_filter_timer.stop()
        previous = self.tree_search.blockSignals(True); self.tree_search.clear(); self.tree_search.blockSignals(previous)
        previous = self.tree_scope.blockSignals(True); self.tree_scope.setCurrentText("All"); self.tree_scope.blockSignals(previous)
        self._apply_tree_filter()

    def _apply_tree_filter(self, *args):
        if not hasattr(self, "tree") or self._building_tree:
            return
        active = self._filters_active()
        if active and self._filter_expansion_snapshot is None:
            self._filter_expansion_snapshot = self._expanded_tree_keys()
        if not active:
            for item in self._tree_items:
                item.setHidden(False)
            if self._filter_expansion_snapshot is not None:
                snapshot = self._filter_expansion_snapshot
                for item in self._tree_items:
                    item.setExpanded(self._tree_expansion_key(item) in snapshot)
                self._filter_expansion_snapshot = None
            self._filter_matches = []
            self.tree_result_label.setText("All definitions")
            self._update_category_counts(False)
            self._set_reordering_enabled(True)
            return

        terms = [part.casefold() for part in self.tree_search.text().split() if part.strip()]
        scope = self.tree_scope.currentText()
        direct_matches = []
        for item in self._tree_items:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            kind, uid = info.get("kind"), info.get("uid")
            if not uid:
                haystack = " ".join(
                    [item.text(column) for column in range(self.tree.columnCount())]
                    + [str(info.get("category", ""))]
                ).casefold()
                if scope == "All" and terms and all(term in haystack for term in terms):
                    direct_matches.append(item)
                continue
            if scope == "Definitions" and kind not in {"Enum", "Structure", "Group", "Message"}:
                continue
            if scope == "Fields" and kind != "Field":
                continue
            if scope == "Class members" and kind not in {"Runtime", "Constant", "Method"}:
                continue
            if scope == "Problems" and uid not in self._problem_uids:
                continue
            haystack = " ".join(
                [item.text(column) for column in range(self.tree.columnCount())]
                + [str(kind or "")]
            ).casefold()
            if terms and not all(term in haystack for term in terms):
                continue
            direct_matches.append(item)

        visible_ids = {id(item) for item in direct_matches}
        for item in list(direct_matches):
            parent = item.parent()
            while parent:
                visible_ids.add(id(parent)); parent = parent.parent()
        root = self.tree.topLevelItem(0)
        if root:
            visible_ids.add(id(root))
        selected = self._item_by_uid.get(self._selected_uid)
        pinned = selected is not None and id(selected) not in visible_ids
        if pinned:
            visible_ids.add(id(selected)); parent = selected.parent()
            while parent:
                visible_ids.add(id(parent)); parent = parent.parent()
        for item in self._tree_items:
            item.setHidden(id(item) not in visible_ids)
        for item in direct_matches:
            parent = item.parent()
            while parent:
                parent.setExpanded(True); parent = parent.parent()
        self._filter_matches = direct_matches
        suffix = " · current selection kept visible" if pinned else ""
        self.tree_result_label.setText(f"{len(direct_matches)} match{'es' if len(direct_matches) != 1 else ''}{suffix}")
        self._update_category_counts(True)
        self._set_reordering_enabled(False)

    def _update_category_counts(self, filtered):
        for category in self._category_items.values():
            info = category.data(0, QtCore.Qt.UserRole) or {}
            total = int(info.get("total", category.childCount()))
            if info.get("category") == "messages":
                def visible_messages(parent):
                    total = 0
                    for index in range(parent.childCount()):
                        child = parent.child(index)
                        info = child.data(0, QtCore.Qt.UserRole) or {}
                        if info.get('kind') == 'Message': total += int(not child.isHidden())
                        elif info.get('kind') == 'Group': total += visible_messages(child)
                    return total
                visible = visible_messages(category)
            else:
                visible = sum(not category.child(index).isHidden() for index in range(category.childCount()))
            count = f"{visible}/{total}" if filtered else str(total)
            category.setText(0, f"{info.get('base_title', category.text(0))} ({count})")

    def _set_reordering_enabled(self, enabled):
        self.tree.setDragDropMode(
            QtWidgets.QAbstractItemView.InternalMove if enabled else QtWidgets.QAbstractItemView.NoDragDrop
        )
        for action in getattr(self, "reorder_actions", []):
            action.setEnabled(enabled)

    def _expand_tree_matches(self):
        if not self._filters_active():
            self.tree.expandAll()
            return
        for item in self._tree_items:
            if not item.isHidden() and any(not item.child(index).isHidden() for index in range(item.childCount())):
                item.setExpanded(True)

    def _navigate_tree_match(self, delta):
        if self.tree_filter_timer.isActive():
            self.tree_filter_timer.stop(); self._apply_tree_filter()
        if not self._filter_matches:
            return
        current = self.tree.currentItem()
        try:
            index = self._filter_matches.index(current)
        except ValueError:
            index = -1 if delta > 0 else 0
        target = self._filter_matches[(index + delta) % len(self._filter_matches)]
        parent = target.parent()
        while parent:
            parent.setExpanded(True); parent = parent.parent()
        self.tree.setCurrentItem(target); self.tree.scrollToItem(target)

    def _append_field_items(self, parent, fields, owner_uid):
        for field in fields:
            item = self._tree_item(field, "Field", owner_uid)
            parent.addChild(item)
            nested = field.get("item")
            if isinstance(nested, dict):
                self._append_field_items(item, [nested], owner_uid)
            self._append_field_items(item, field.get("fields", []), owner_uid)
            for case in field.get("cases", []):
                nested = case.get("item")
                if isinstance(nested, dict):
                    self._append_field_items(item, [nested], owner_uid)

    def _tree_item(self, value, kind, owner_uid=""):
        label = value.get("name") or value.get("display_name") or "Library"
        if kind == "Field":
            type_label = self._field_type_label(value)
        elif kind == "Message":
            type_label = "BinaryMessage"
        elif kind == "Group":
            type_label = "MessageGroup"
        elif kind == "Library":
            type_label = ""
        elif kind == "Enum":
            type_label = "IntEnum"
        elif kind == "Structure":
            type_label = "dataclass"
        elif kind == "Runtime":
            type_label = value.get("annotation") or "Any"
        elif kind == "Constant":
            type_label = value.get("annotation") or "Any"
        elif kind == "Method":
            type_label = {
                "instance": "method", "class": "classmethod",
                "static": "staticmethod", "async": "async method", "property": "property",
            }.get(value.get("kind", "instance"), "method")
        else:
            type_label = kind
        size_label = ""
        if kind == "Field":
            size_label = self._wire_size_analyzer.field(value).label()
        elif kind == "Structure":
            size_label = self._wire_size_analyzer.definition(value).label()
        elif kind == "Message":
            size_label = self._wire_size_analyzer.fields(
                value.get("fields", [])
            ).label()
        direction = str(value.get("direction", "ANY")).upper() if kind == "Message" else ""
        item = QtWidgets.QTreeWidgetItem(
            [str(label), str(type_label), size_label, direction]
        )
        item.setTextAlignment(2, QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        item.setTextAlignment(3, QtCore.Qt.AlignCenter)
        item.setData(0, QtCore.Qt.UserRole, {
            "uid": value.get("uid", ""), "kind": kind, "owner_uid": owner_uid,
        })
        self._tree_items.append(item)
        if value.get("uid"):
            self._item_by_uid[value["uid"]] = item
        return item

    def _field_type_label(self, field):
        kind = field.get("kind", "unknown")
        if kind in {"uint", "int"}:
            return f"{kind}{int(field.get('width', 1)) * 8}"
        if kind == "bytes_integer":
            prefix = "int" if field.get("signed") else "uint"
            return f"{prefix}{int(field.get('length', 1)) * 8}"
        if kind == "float": return f"float{int(field.get('width', 4)) * 8}"
        if kind == "enum":
            target = self.document.find(field.get("enum_uid", "")); return target.get("name", "Missing enum") if target else "Missing enum"
        if kind == "struct":
            target = self.document.find(field.get("struct_uid", "")); return target.get("name", "Missing struct") if target else "Missing struct"
        if kind == "array": return f"array[{self._field_type_label(field.get('item', {}))}]"
        if kind == "conditional": return f"{self._field_type_label(field.get('item', {}))}?"
        if kind in {"const", "default", "aligned", "rebuild", "checksum"} and isinstance(field.get("item"), dict):
            return f"{kind}[{self._field_type_label(field['item'])}]"
        if kind == "inline_struct": return "inline struct"
        if kind == "bitfield": return "bits"
        if kind == "string": return f"string[{field.get('encoding', 'utf8')}]"
        if kind == "bytes" and field.get("mode") == "fixed": return f"bytes[{field.get('length', 0)}]"
        if kind == "advanced": return str(field.get("expression", "Construct"))
        return kind

    def _find_tree_item(self, uid):
        return self._item_by_uid.get(uid)

    def _selection_changed(self, current, previous):
        if self._building_tree or current is None:
            return
        self._loading_properties = True
        self._properties_pending = False
        info = current.data(0, QtCore.Qt.UserRole) or {}
        self.open_routing_button.setVisible(info.get("kind") in {"Group", "Message"})
        uid = info.get("uid")
        if not uid:
            self.editor_title.setText(current.text(0))
            title, description = self._category_description(info.get("category", ""))
            self.category_info_title.setText(title)
            self.category_info_text.setText(description)
            self.category_info.setVisible(True)
            self.common_properties_widget.setVisible(False)
            self.property_actions_widget.setVisible(False)
            self.name_edit.clear()
            self.details_edit.clear()
            self.name_edit.setEnabled(False)
            self.details_edit.setEnabled(False)
            self.kind_combo.setVisible(False)
            self.field_options_group.setVisible(False)
            self.definition_options_group.setVisible(False)
            self.json_label.setVisible(False)
            self.details_edit.setVisible(False)
            self.reference_label.setVisible(False)
            self.dependencies.setVisible(False)
            self._loading_properties = False
            self._update_property_state()
            return
        self._selected_uid = uid
        self._store_session()
        value = self.document.find(uid)
        if value is None:
            return
        kind = info.get("kind", "Definition")
        self.editor_title.setText(kind)
        self.category_info.setVisible(False)
        self.common_properties_widget.setVisible(True)
        self.property_actions_widget.setVisible(True)
        self.name_edit.setEnabled(True)
        self.details_edit.setEnabled(True)
        self.name_edit.setText(str(value.get("name") or value.get("display_name") or ""))
        is_field = kind == "Field"
        is_typed_definition = kind in DefinitionOptionsEditor.SUPPORTED
        self.kind_combo.setVisible(is_field)
        self.kind_label.setVisible(is_field)
        self.field_options_group.setVisible(is_field)
        self.definition_options_group.setVisible(is_typed_definition)
        self.json_label.setVisible(not is_field and not is_typed_definition)
        self.details_edit.setVisible(not is_field and not is_typed_definition)
        if is_field:
            self.kind_combo.setCurrentText(value.get("kind", "uint"))
            self.field_options.load_field(value, self.document.data)
        elif is_typed_definition:
            self.definition_options.load_definition(value, kind, self.document.data)
        details = {key: val for key, val in value.items() if key not in {"uid", "name", "kind"}}
        self.details_edit.setPlainText(json.dumps(details, indent=2, ensure_ascii=False))
        self.reference_label.setText(self._reference_summary(value))
        has_dependencies = self._refresh_dependencies(value)
        self.reference_label.setVisible(bool(self.reference_label.text()))
        self.dependencies.setVisible(has_dependencies)
        self._loading_properties = False
        self._update_property_state()

    def _category_description(self, category):
        descriptions = {
            "enums": (
                "Shared enumerations",
                "Enums give meaningful names to numeric wire values and generate Python IntEnum classes. "
                "Create an enum here, define its member names and numbers, then select it from an enum field.",
            ),
            "structures": (
                "Reusable structures",
                "Structures are reusable binary layouts and generate slotted dataclasses plus Construct schemas. "
                "Use a struct field to embed one in messages or other structures.",
            ),
            "messages": (
                "Message classes",
                "Messages are complete BinaryMessage dataclasses with Direction, wire fields, "
                "runtime state, constants, and custom behavior methods. They can be encoded, decoded, and dispatched through the registry.",
            ),
            "groups": (
                "Message groups",
                "Groups organize message routing. Configure their hierarchy and identities in the Routing tab.",
            ),
            "runtime_attributes": (
                "Runtime attributes",
                "Runtime attributes exist on Python message instances but are never encoded into the wire bytes.",
            ),
            "constants": (
                "Class constants",
                "Constants are ClassVar values shared by every instance and are not serialized.",
            ),
            "methods": (
                "Behavior methods",
                "Method declarations generate kind-specific stubs in behaviors.py. Implement their bodies in VS Code.",
            ),
        }
        return descriptions.get(category, ("Library definitions", "Select or create a definition from this group."))

    def _refresh_dependencies(self, value):
        self.dependencies.clear()
        uid = value.get("uid", "")
        for key, label in (("enum_uid", "Uses enum"), ("struct_uid", "Uses structure")):
            if value.get(key):
                target = self.document.find(value[key])
                self.dependencies.addTopLevelItem(QtWidgets.QTreeWidgetItem([label, target.get("name", "missing") if target else "missing"]))
        for owner in [*self.document.data.get("structures", []), *self.document.data.get("messages", [])]:
            for field in walk_fields(owner.get("fields", [])):
                if field.get("enum_uid") == uid or field.get("struct_uid") == uid:
                    self.dependencies.addTopLevelItem(QtWidgets.QTreeWidgetItem(["Used by", f"{owner['name']}.{field.get('name', '?')}"]))
        return self.dependencies.topLevelItemCount() > 0

    def _field_kind_changed(self, kind):
        value = self.document.find(self._selected_uid)
        if value is not None and not self._loading_properties and kind != value.get("kind"):
            self.field_options.change_kind(kind, self.name_edit.text().strip() or value.get("name", "field"))
        self._properties_edited()

    def _properties_edited(self, *args):
        if self._loading_properties:
            return
        value = self.document.find(self._selected_uid)
        if value is None:
            return
        info = (self.tree.currentItem().data(0, QtCore.Qt.UserRole) or {}) if self.tree.currentItem() else {}
        if info.get("kind") == "Method":
            self.definition_options.set_display_name(self.name_edit.text().strip())
        try:
            self._properties_pending = self._property_candidate(value) != value
        except (ValueError, TypeError, json.JSONDecodeError):
            self._properties_pending = True
        self._update_property_state()
        self._refresh_all_title_only()

    def _property_candidate(self, value):
        info = (self.tree.currentItem().data(0, QtCore.Qt.UserRole) or {}) if self.tree.currentItem() else {}
        if info.get("kind") == "Field":
            updated = self.field_options.value()
            updated["uid"] = value["uid"]
            updated["name"] = self.name_edit.text().strip()
            return updated
        if info.get("kind") in DefinitionOptionsEditor.SUPPORTED:
            updated = self.definition_options.value()
            updated["uid"] = value["uid"]
            if "name" in value:
                updated["name"] = self.name_edit.text().strip()
            else:
                updated["display_name"] = self.name_edit.text().strip()
            return updated
        details = json.loads(self.details_edit.toPlainText() or "{}")
        if not isinstance(details, dict):
            raise ValueError("Properties must be a JSON object")
        updated = {"uid": value["uid"]}
        if "name" in value: updated["name"] = self.name_edit.text().strip()
        elif "display_name" in value: updated["display_name"] = self.name_edit.text().strip()
        if info.get("kind") == "Message": details["behavior_class"] = value.get("behavior_class")
        updated.update(details)
        return updated

    def _update_property_state(self):
        if self._properties_pending:
            self.property_state_label.setText("These property changes are not applied to the message definition.")
            self.property_state_label.setStyleSheet("color: #b54708; font-weight: 600;")
            self.apply_button.setStyleSheet("font-weight: 600;")
        else:
            self.property_state_label.setText("All property changes are applied.")
            self.property_state_label.setStyleSheet("color: #287d3c;")
            self.apply_button.setStyleSheet("")

    def _refresh_all_title_only(self):
        package = self.document.data.get("library", {}).get("package_name", "message library")
        states = []
        if self.loaded is None: states.append("Not saved")
        elif self.document.is_dirty: states.append("Changes not saved")
        if self._properties_pending: states.append("Property changes not applied")
        if self.routing_studio.apply.isEnabled(): states.append("Routing changes not applied")
        suffix = " — " + " · ".join(states) if states else ""
        self.setWindowTitle(f"Message Designer — {package}{suffix}")

    def _reference_summary(self, value):
        references = []
        if value.get("enum_uid"):
            target = self.document.find(value["enum_uid"])
            references.append("Enum: " + (target.get("name") if target else "missing"))
        if value.get("struct_uid"):
            target = self.document.find(value["struct_uid"])
            references.append("Structure: " + (target.get("name") if target else "missing"))
        return " • ".join(references)

    def _merge_property_edits(self, after):
        value = self.document.find(self._selected_uid)
        if value is None:
            return
        updated = self._property_candidate(value)
        info = (self.tree.currentItem().data(0, QtCore.Qt.UserRole) or {}) if self.tree.currentItem() else {}
        target = _find_in_data(after, value['uid'])
        if target is None:
            return
        # Preserve staged routing keys carried by the definition editor's older base.
        missing = object()
        for key in value.keys() | updated.keys():
            if value.get(key, missing) != updated.get(key, missing):
                if key in updated: target[key] = copy.deepcopy(updated[key])
                else: target.pop(key, None)
        if info.get("kind") == "Structure" and value.get("name") != updated.get("name"):
            _sync_linked_message_name(after, value, updated, rename_behavior=self.loaded is None)

    def apply_properties(self):
        if self.document.find(self._selected_uid) is None:
            return False
        try:
            after = self.routing_studio.pending_manifest() if self.routing_studio.apply.isEnabled() else self.document.snapshot()
            self._merge_property_edits(after)
        except (json.JSONDecodeError, ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
            QtWidgets.QMessageBox.warning(self, "Invalid properties", str(error))
            return False
        before = self.document.snapshot()
        self._properties_pending = False
        if before != after:
            self.undo_stack.push(ReplaceManifestCommand(self.document, before, after, "Edit properties"))
        else:
            self.routing_studio.refresh(self.document.data, self._selected_uid)
        self._update_property_state()
        return True

    def _mutate(self, text, operation):
        if self.routing_studio.apply.isEnabled() and not self.routing_studio.apply_pending():
            return
        before = self.document.snapshot()
        after = self.document.snapshot()
        selected = operation(after)
        if after != before:
            self._selected_uid = selected or self._selected_uid
            self.undo_stack.push(ReplaceManifestCommand(self.document, before, after, text))

    def add_enum(self):
        self._mutate("Add enum", lambda data: _append(data["enums"], new_enum(_unique_name(data, "NewEnum"))))

    def add_structure(self):
        def operation(data):
            structure = new_structure(_unique_name(data, "NewStruct"))
            data["structures"].append(structure)
            return structure["uid"]
        self._mutate("Add structure", operation)

    def add_group(self):
        current = self.tree.currentItem()
        info = current.data(0, QtCore.Qt.UserRole) if current is not None else {}
        selected_parent = info.get("uid", "") if info.get("kind") == "Group" else ""
        def operation(data):
            group = new_group(_unique_name(data, "NewGroup"), selected_parent)
            parent = next((item for item in data.get("groups", []) if item.get("uid") == selected_parent), None)
            data.setdefault("groups", []).append(group)
            return group["uid"]
        self._mutate("Add message group", operation)

    def add_message(self):
        current = self.tree.currentItem()
        info = current.data(0, QtCore.Qt.UserRole) if current is not None else {}
        preferred_group = info.get("uid", "") if info.get("kind") == "Group" else ""
        if info.get("kind") == "Message":
            preferred_group = _selected_group_uid_from_data(self.document.data, info.get("uid", ""))
        def operation(data):
            selected_group = preferred_group
            selected_group = selected_group or data["library"]["uid"]
            message = new_message(_unique_name(data, "NewMessage")); message["group_uid"] = selected_group
            return _append(data["messages"], message)
        self._mutate("Add message", operation)

    def add_field(self):
        owner_uid = self._selected_owner_uid()
        if not owner_uid:
            QtWidgets.QMessageBox.information(self, "Select a type", "Select a message or reusable structure first.")
            return
        def operation(data):
            owner = _find_in_data(data, owner_uid)
            existing = {field.get("name") for field in owner.get("fields", [])}
            index = 1
            name = "field"
            while name in existing:
                index += 1
                name = f"field_{index}"
            return _append(owner.setdefault("fields", []), new_field(name))
        self._mutate("Add field", operation)

    def add_inline_field(self):
        parent_uid = self._selected_uid
        parent = self.document.find(parent_uid)
        if not parent or parent.get("kind") != "inline_struct":
            return
        def operation(data):
            target = _find_in_data(data, parent_uid)
            existing = {field.get("name") for field in target.get("fields", [])}
            name, index = "field", 1
            while name in existing:
                index += 1; name = f"field_{index}"
            return _append(target.setdefault("fields", []), new_field(name))
        self._mutate("Add inline field", operation)

    def add_runtime(self):
        self._add_message_member("runtime_attributes", new_runtime_attribute, "Add runtime attribute")

    def add_constant(self):
        self._add_message_member("constants", new_constant, "Add constant")

    def add_method(self):
        owner_uid = self._selected_message_uid()
        if not owner_uid:
            QtWidgets.QMessageBox.information(self, "Select a message", "Select a message first.")
            return
        method_kind, accepted = QtWidgets.QInputDialog.getItem(
            self, "Add custom method", "Method kind:",
            ["instance", "class", "static", "async", "property"], 0, False,
        )
        if not accepted:
            return
        def operation(data):
            owner = _find_in_data(data, owner_uid)
            used = {method.get("name") for method in owner.get("methods", [])}
            name, index = "custom_method", 1
            while name in used:
                index += 1; name = f"custom_method_{index}"
            method = new_method(name)
            method["kind"] = method_kind
            return _append(owner.setdefault("methods", []), method)
        self._mutate("Add method", operation)

    def _add_message_member(self, collection, factory, text):
        owner_uid = self._selected_message_uid()
        if not owner_uid:
            QtWidgets.QMessageBox.information(self, "Select a message", "Select a message first.")
            return
        self._mutate(text, lambda data: _append(_find_in_data(data, owner_uid).setdefault(collection, []), factory()))

    def _selected_owner_uid(self):
        item = self.tree.currentItem()
        while item:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            if info.get("kind") in {"Message", "Structure"}:
                return info.get("uid")
            item = item.parent()
        return ""

    def _selected_message_uid(self):
        item = self.tree.currentItem()
        while item:
            info = item.data(0, QtCore.Qt.UserRole) or {}
            if info.get("kind") == "Message":
                return info.get("uid")
            item = item.parent()
        return ""

    def duplicate_selected(self):
        uid = self._selected_uid
        def operation(data):
            collection, index = _find_collection(data, uid)
            if collection is None:
                return ""
            duplicate = copy.deepcopy(collection[index])
            _refresh_ids(duplicate)
            if duplicate.get("name"):
                duplicate["name"] += "Copy"
            if collection is data.get("messages"):
                duplicate.pop("generated_from_struct_uid", None)
                duplicate.pop("generated_struct_field_uid", None)
                duplicate["behavior_class"] = duplicate["name"] + "Behavior"
            collection.insert(index + 1, duplicate)
            return duplicate["uid"]
        self._mutate("Duplicate definition", operation)

    def delete_selected(self):
        uid = self._selected_uid
        if uid == self.document.data["library"]["uid"]:
            return
        structure = next((item for item in self.document.data.get("structures", []) if item.get("uid") == uid), None)
        if structure is not None:
            self._delete_structure(structure)
            return
        group = next((item for item in self.document.data.get("groups", []) if item.get("uid") == uid), None)
        if group is not None:
            assigned = [message for message in self.document.data.get("messages", []) if _message_group_uid(self.document.data, message) == uid]
            child_groups = [item for item in self.document.data.get("groups", []) if item.get("parent_group_uid") == uid]
            if assigned or child_groups:
                QtWidgets.QMessageBox.warning(self, "Group is not empty", "Move or delete the group's child groups and messages before deleting the group."); return
        def operation(data):
            collection, index = _find_collection(data, uid)
            if collection is not None:
                collection.pop(index)
            return data["library"]["uid"]
        self._mutate("Delete definition", operation)

    def _delete_structure(self, structure):
        struct_uid = structure["uid"]
        linked = [
            message for message in self.document.data.get("messages", [])
            if message.get("generated_from_struct_uid") == struct_uid
        ]
        linked_field_uids = {message.get("generated_struct_field_uid") for message in linked}
        other_references = []
        for owner in [*self.document.data.get("structures", []), *self.document.data.get("messages", [])]:
            for field in walk_fields(owner.get("fields", [])):
                if field.get("struct_uid") == struct_uid and field.get("uid") not in linked_field_uids:
                    other_references.append(f"{owner.get('name', 'Unnamed')}.{field.get('name', 'field')}")
        if other_references:
            QtWidgets.QMessageBox.warning(
                self, "Structure is still referenced",
                f"{structure['name']} cannot be removed until these fields are changed or removed:\n\n" +
                "\n".join("• " + reference for reference in other_references),
            )
            return
        choice = QtWidgets.QMessageBox.Yes
        if linked:
            names = ", ".join(message["name"] for message in linked)
            choice = QtWidgets.QMessageBox.question(
                self, "Remove linked message?",
                f"{structure['name']} created the linked message {names}.\n\n"
                "Yes: remove the structure and linked message.\n"
                "No: keep the message by converting its structure field to an inline copy.\n"
                "Cancel: make no changes.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No | QtWidgets.QMessageBox.Cancel,
                QtWidgets.QMessageBox.Yes,
            )
        if choice == QtWidgets.QMessageBox.Cancel:
            return
        def operation(data):
            data["structures"][:] = [item for item in data["structures"] if item.get("uid") != struct_uid]
            if choice == QtWidgets.QMessageBox.Yes:
                data["messages"][:] = [message for message in data["messages"] if message.get("generated_from_struct_uid") != struct_uid]
            else:
                for message in data["messages"]:
                    if message.get("generated_from_struct_uid") != struct_uid:
                        continue
                    field_uid = message.pop("generated_struct_field_uid", "")
                    message.pop("generated_from_struct_uid", None)
                    field = next((item for item in message.get("fields", []) if item.get("uid") == field_uid), None)
                    if field:
                        field.pop("struct_uid", None)
                        field["kind"] = "inline_struct"
                        field["fields"] = copy.deepcopy(structure.get("fields", []))
            return data["library"]["uid"]
        self._mutate("Remove structure", operation)

    def move_selected(self, delta):
        if self._filters_active():
            self.statusBar().showMessage("Clear navigator filters before reordering definitions.", 5000)
            return
        uid = self._selected_uid
        def operation(data):
            collection, index = _find_collection(data, uid)
            if collection is None:
                return uid
            item = collection[index]
            scope_key = "parent_group_uid" if collection is data.get("groups") else (
                "group_uid" if collection is data.get("messages") else ""
            )
            if scope_key:
                sibling_indices = [
                    position for position, candidate in enumerate(collection)
                    if candidate.get(scope_key, "") == item.get(scope_key, "")
                ]
                sibling_position = sibling_indices.index(index)
                target_position = max(0, min(len(sibling_indices) - 1, sibling_position + delta))
                target = sibling_indices[target_position]
                if target != index:
                    collection[index], collection[target] = collection[target], collection[index]
                return uid
            target = max(0, min(len(collection) - 1, index + delta))
            if target != index:
                collection.insert(target, collection.pop(index))
            return uid
        self._mutate("Reorder definition", operation)

    def _tree_order_dropped(self, ordered_uids):
        if self._filters_active():
            self._rebuild_tree()
            return
        if not ordered_uids:
            self._rebuild_tree()
            return
        def operation(data):
            collection, _ = _find_collection(data, ordered_uids[0])
            if collection is None or {item.get("uid") for item in collection} != set(ordered_uids):
                return self._selected_uid
            by_uid = {item["uid"]: item for item in collection}
            collection[:] = [by_uid[uid] for uid in ordered_uids]
            return self._selected_uid
        self._mutate("Reorder definitions", operation)

    def _show_tree_context_menu(self, position):
        item = self.tree.itemAt(position)
        if item is None:
            return
        self.tree.setCurrentItem(item)
        info = item.data(0, QtCore.Qt.UserRole) or {}
        menu = QtWidgets.QMenu(self.tree)

        def add(label, callback):
            action = menu.addAction(label); action.triggered.connect(callback)

        category, kind = info.get("category"), info.get("kind")
        if kind == "Library":
            add("Add enum", self.add_enum); add("Add reusable structure", self.add_structure); add("Add group", self.add_group); add("Add message", self.add_message)
            menu.addSeparator(); menu.addAction(self.collapse_all_action)
            menu.addSeparator(); add("Save", self.save_library); add("Save As…", lambda: self.save_library(save_as=True))
        elif category == "enums": add("Add enum", self.add_enum)
        elif category == "structures": add("Add reusable structure", self.add_structure)
        elif category == "messages": add("Add message", self.add_message); add("Add message group", self.add_group)
        elif category == "runtime_attributes": add("Add runtime attribute", self.add_runtime)
        elif category == "constants": add("Add class constant", self.add_constant)
        elif category == "methods": add("Add method", self.add_method)
        elif kind in {"Message", "Structure"}:
            add("Add field", self.add_field)
            if kind == "Message":
                add("Add runtime attribute", self.add_runtime); add("Add class constant", self.add_constant); add("Add method", self.add_method)
            menu.addSeparator(); self._add_common_context_actions(menu)
            if kind == "Message": menu.addSeparator(); add("Open behavior in VS Code", self.open_behavior_code)
        elif kind == "Group":
            add("Add child group", self.add_group); add("Add message", self.add_message); menu.addSeparator(); self._add_common_context_actions(menu)
        elif kind == "Field":
            field = self.document.find(info.get("uid", ""))
            if field and field.get("kind") == "inline_struct": add("Add child field", self.add_inline_field); menu.addSeparator()
            self._add_common_context_actions(menu)
        elif kind in {"Enum", "Runtime", "Constant", "Method"}:
            self._add_common_context_actions(menu)
            if kind == "Method": menu.addSeparator(); add("Open method in VS Code", self.open_behavior_code)
        if not menu.isEmpty():
            menu.exec_(self.tree.viewport().mapToGlobal(position))

    def _add_common_context_actions(self, menu):
        for label, callback in (
            ("Duplicate", self.duplicate_selected), ("Move up", lambda: self.move_selected(-1)),
            ("Move down", lambda: self.move_selected(1)), ("Delete", self.delete_selected),
        ):
            action = menu.addAction(label); action.triggered.connect(callback)
            if label in {"Move up", "Move down"} and self._filters_active():
                action.setEnabled(False)

    def _refresh_validation(self):
        current_issues = [*validate_manifest(self.document.data), *self._behavior_method_issues()]
        library_uid = self.document.data.get("library", {}).get("uid", "")
        self._problem_uids = {
            issue.uid if issue.uid in self._item_by_uid else library_uid
            for issue in current_issues
        }
        self._problem_uids.discard("")
        self._populate_validation_issues(self.issues, current_issues)
        self._apply_tree_filter()

    def _refresh_routing_validation(self, issues):
        self._populate_validation_issues(self.routing_studio.issues, [*issues, *self._behavior_method_issues()])

    def _populate_validation_issues(self, view, current_issues):
        view.clear()
        for issue in current_issues:
            action_label = self._issue_action_label(issue)
            item = QtWidgets.QTreeWidgetItem([issue.severity.title(), issue.message, ""])
            item.setData(0, QtCore.Qt.UserRole, issue.uid)
            item.setData(0, QtCore.Qt.UserRole + 1, issue.code)
            item.setData(0, QtCore.Qt.UserRole + 2, action_label)
            color = "#c0392b" if issue.blocking else "#b9770e"
            item.setForeground(0, QtGui.QBrush(QtGui.QColor(color)))
            item.setToolTip(1, issue.code)
            view.addTopLevelItem(item)
            if action_label != "Review":
                action_button = QtWidgets.QPushButton(action_label, view)
                action_button.setToolTip(f"Resolve: {issue.message}")
                action_button.clicked.connect(lambda checked=False, target=item: self._activate_issue(target, 2))
                view.setItemWidget(item, 2, action_button)
            else:
                item.setText(2, action_label)

    def _behavior_method_issues(self):
        source = self._behavior_source() if self.loaded else None
        return validate_behavior_methods(source, self.document.data.get("messages", []))

    def _issue_action_label(self, issue):
        if issue.code == "routing-unassigned":
            return "Assign expected values"
        if issue.code == "routing-ancestor-unassigned":
            return "Assign ancestor values"
        if self._is_routing_issue(issue.code):
            return "Go to routing"
        if issue.code in {"empty-method", "reserved-behavior-method"}:
            return "Open in VS Code" if self.loaded else "Save and open in VS Code"
        if issue.code in {"missing-method", "missing-behavior-class"}:
            return "Save to recreate"
        if issue.code in {"method-kind-drift", "method-signature-drift"}:
            return "Save to restore signature"
        if issue.code == "behavior-syntax":
            return "Open behaviors.py in VS Code"
        return "Go to definition" if issue.uid else "Review"

    @staticmethod
    def _is_routing_issue(code):
        return str(code).startswith("routing-") or code in {
            "group-router", "message-router", "duplicate-group-route", "duplicate-message-route",
        }

    def _activate_issue(self, item, column=0):
        uid = item.data(0, QtCore.Qt.UserRole)
        self._reveal_tree_uid(uid)
        code = item.data(0, QtCore.Qt.UserRole + 1)
        if self._is_routing_issue(code):
            if code == "duplicate-group-route":
                group = self.document.find(uid) or {}
                uid = group.get("parent_group_uid") or self.document.data["library"]["uid"]
            self.tabs.setCurrentWidget(self.routing_studio)
            target = self.routing_studio._find_item(uid)
            if target is not None:
                self.routing_studio.tree.setCurrentItem(target)
        elif code in {"empty-method", "reserved-behavior-method"}:
            if self.loaded or self.save_library():
                self.open_behavior_code()
        elif code in {"missing-method", "missing-behavior-class", "method-kind-drift", "method-signature-drift"}:
            self.save_library()
        elif code == "behavior-syntax":
            self.open_behavior_code()
        else:
            self.tabs.setCurrentWidget(self.definitions_page)

    def _show_issue_context_menu(self, position, view=None):
        view = view if view is not None else self.issues
        item = view.itemAt(position)
        if item is None:
            return
        menu = QtWidgets.QMenu(view)
        uid = item.data(0, QtCore.Qt.UserRole)
        if uid:
            focus = menu.addAction("Go to definition")
            focus.triggered.connect(lambda: self._focus_issue_definition(item))
        action_text = item.data(0, QtCore.Qt.UserRole + 2) or item.text(2)
        if action_text not in {"Go to definition", "Review"}:
            action = menu.addAction(action_text)
            action.triggered.connect(lambda: self._activate_issue(item, 2))
        if not menu.isEmpty():
            menu.exec_(view.viewport().mapToGlobal(position))

    def _focus_issue_definition(self, item):
        uid = item.data(0, QtCore.Qt.UserRole)
        self._reveal_tree_uid(uid)
        self.tabs.setCurrentWidget(self.definitions_page)

    def _reveal_tree_uid(self, uid):
        if not uid:
            return
        self._selected_uid = uid
        self._apply_tree_filter()
        target = self._find_tree_item(uid)
        if target:
            self.tree.setCurrentItem(target)
            parent = target.parent()
            while parent:
                parent.setExpanded(True); parent = parent.parent()
            self.tree.scrollToItem(target)

    def _refresh_preview_messages(self):
        selected_scope = self.preview_group_scope.currentData()
        scope_blocker = QtCore.QSignalBlocker(self.preview_group_scope)
        self.preview_group_scope.clear()
        self.preview_group_scope.addItem('Library (main group)', self.document.data['library']['uid'])
        by_uid = {group['uid']: group for group in self.document.data.get('groups', [])}
        for group in by_uid.values():
            path = []; current_group = group; seen = set()
            while current_group and current_group['uid'] not in seen:
                seen.add(current_group['uid']); path.append(current_group.get('name', 'Group'))
                current_group = by_uid.get(current_group.get('parent_group_uid'))
            self.preview_group_scope.addItem('/'.join(reversed(path)), group['uid'])
        self.preview_group_scope.setCurrentIndex(max(0, self.preview_group_scope.findData(selected_scope)))
        del scope_blocker
        current = self.preview_message.currentText() if hasattr(self, "preview_message") else ""
        blocker = QtCore.QSignalBlocker(self.preview_message)
        self.preview_message.clear()
        self.preview_message.addItems(message["name"] for message in self.document.data.get("messages", []))
        if current and self.preview_message.findText(current) >= 0:
            self.preview_message.setCurrentText(current)
        del blocker
        available = self.preview_message.count() > 0
        for button in getattr(self, "preview_action_buttons", ()):
            button.setEnabled(available)
        if not available and hasattr(self, "preview_status"):
            self._set_preview_status("Add a message definition before using the Hex Sandbox.", "info")
            self._preview_rendered_message = ""
            self.preview_values.clear()
        elif self.preview_message.currentText() != self._preview_rendered_message:
            self._preview_message_changed(self.preview_message.currentText())
        else:
            message_name = self.preview_message.currentText()
            try:
                current_values = self._read_preview_values(message_name)
            except SandboxValueError:
                current_values = None
            prior_sample = self._preview_sample_values.get(message_name)
            fresh_sample = sample_message_values(self.document.data, message_name)
            if current_values is not None and current_values == prior_sample and fresh_sample != prior_sample:
                self._preview_value_drafts[message_name] = copy.deepcopy(fresh_sample)
                self._preview_sample_values[message_name] = copy.deepcopy(fresh_sample)
                self._write_preview_values(fresh_sample, message_name)

    def _set_preview_status(self, message, state="info"):
        styles = {
            "info": ("#365f91", "rgba(54, 95, 145, 0.10)", "ℹ"),
            "working": ("#6b5b00", "rgba(177, 142, 0, 0.12)", "…"),
            "success": ("#287d3c", "rgba(40, 125, 60, 0.11)", "✓"),
            "error": ("#b42318", "rgba(180, 35, 24, 0.10)", "!"),
        }
        color, background, marker = styles.get(state, styles["info"])
        self.preview_status.setText(f"{marker}  {message}")
        self.preview_status.setProperty("statusState", state)
        self.preview_status.setStyleSheet(
            f"padding: 8px 10px; border-radius: 4px; font-weight: 600; "
            f"color: {color}; background: {background};"
        )

    def _format_preview_json(self):
        try:
            values = self._read_preview_values()
            self._write_preview_values(values)
        except SandboxValueError as error:
            self._set_preview_status(f"Message initialization is invalid: {error}", "error")
            return
        label = "object initialization" if self._preview_value_mode == "object" else "JSON"
        self._set_preview_status(f"Message values formatted as {label}.", "success")

    def _preview_value_format_changed(self, _index=None):
        selected = self.preview_value_format.currentData()
        if not selected or selected == self._preview_value_mode:
            return
        previous_mode = self._preview_value_mode
        try:
            values = self._read_preview_values()
            self._preview_value_mode = selected
            self._write_preview_values(values)
        except SandboxValueError as error:
            self._preview_value_mode = previous_mode
            blocker = QtCore.QSignalBlocker(self.preview_value_format)
            old_index = self.preview_value_format.findData(previous_mode)
            self.preview_value_format.setCurrentIndex(max(0, old_index))
            del blocker
            self._set_preview_status(
                f"Cannot switch value view until the current text is valid: {error}", "error"
            )
            return
        message_name = self.preview_message.currentText()
        if message_name:
            self._preview_value_drafts[message_name] = copy.deepcopy(values)
        self._update_preview_value_controls()
        self._set_preview_status(
            "Message values converted to "
            + ("object initialization." if selected == "object" else "JSON."),
            "success",
        )

    def _preview_message_changed(self, message_name):
        if not message_name:
            return
        if self._preview_rendered_message:
            try:
                previous_values = self._read_preview_values(self._preview_rendered_message)
                self._preview_value_drafts[self._preview_rendered_message] = copy.deepcopy(previous_values)
            except SandboxValueError:
                pass
        values = copy.deepcopy(self._preview_value_drafts.get(message_name))
        if values is None:
            values = sample_message_values(self.document.data, message_name)
            self._preview_value_drafts[message_name] = copy.deepcopy(values)
            self._preview_sample_values[message_name] = copy.deepcopy(values)
        self._preview_rendered_message = message_name
        try:
            self._write_preview_values(values, message_name)
        except SandboxValueError:
            values = {}
            self._preview_value_drafts[message_name] = {}
            self._write_preview_values(values, message_name)
        self._update_preview_value_controls()

    def _read_preview_values(self, message_name=None):
        message_name = message_name or self._preview_rendered_message or self.preview_message.currentText()
        text = self.preview_values.toPlainText()
        if self._preview_value_mode == "json":
            return parse_json_values(text)
        if not message_name:
            if not text.strip():
                return {}
            raise SandboxValueError("Select a message class first.")
        return parse_object_values(text, self.document.data, message_name)

    def _write_preview_values(self, values, message_name=None):
        message_name = message_name or self.preview_message.currentText()
        if self._preview_value_mode == "json":
            text = format_json_values(values)
        elif message_name:
            text = format_object_values(values, self.document.data, message_name)
        else:
            text = ""
        self.preview_values.setPlainText(text)

    def _update_preview_value_controls(self):
        is_json = self._preview_value_mode == "json"
        self.preview_format_json_button.setText("Format JSON" if is_json else "Format object")
        self.preview_values.setPlaceholderText(
            '{\n  "field_name": 0\n}' if is_json
            else "MessageName(\n    field_name=0,\n)"
        )
        self.preview_values_hint.setText(
            "Input for Build bytes. Edit JSON, including tagged bytes and special floats."
            if is_json else
            "Input for Build bytes. Edit Python-style named attributes; nested structures, enums, bytes, and arrays are shown naturally."
        )

    def _normalize_preview_hex(self):
        try:
            raw = bytes.fromhex(self.preview_hex.toPlainText())
        except ValueError as error:
            self._set_preview_status(f"Wire bytes contain invalid hexadecimal text: {error}", "error")
            return
        self.preview_hex.setPlainText(raw.hex(" "))
        self._set_preview_status(f"Normalized {len(raw)} wire bytes.", "success")

    def _update_preview_byte_count(self):
        try:
            count = len(bytes.fromhex(self.preview_hex.toPlainText()))
        except ValueError:
            self.preview_byte_count.setText("Invalid hex")
            self.preview_byte_count.setStyleSheet("color: #b42318; font-weight: 600;")
            return
        self.preview_byte_count.setText(f"{count} byte{'s' if count != 1 else ''}")
        self.preview_byte_count.setStyleSheet("color: palette(mid);")

    def _refresh_code(self):
        if not hasattr(self, "code_editors"):
            return
        behavior = self._behavior_source()
        try:
            generated = generate_library(self.document.data, behavior)
        except Exception as error:
            for editor in self.code_editors.values():
                editor.setPlainText(f"Generation unavailable:\n{error}")
            return
        for name, editor in self.code_editors.items():
            editor.setPlainText(generated.files[name])

    def _behavior_source(self):
        path = self.loaded.package_dir / "behaviors.py" if self.loaded else None
        return path.read_text(encoding="utf-8") if path and path.is_file() else ""

    def run_sandbox(self, action):
        message = self.preview_message.currentText()
        routing_trace = None
        if action == "auto_parse":
            try:
                raw = bytes.fromhex(self.preview_hex.toPlainText())
                if self._compiled_preview_router is None:
                    self._compiled_preview_router = compile_manifest_routing(self.document.data)
                match = self._compiled_preview_router.identify_message(raw, group_uid=self.preview_group_scope.currentData(), direction=self.preview_direction.currentData())
                message_data = self.document.find(match.message_uid)
                routing_trace = {'message': message_data, 'identifiers': match.identifiers}
                message = routing_trace["message"]["name"]
                self.preview_message.setCurrentText(message)
                action = "parse"
            except (ValueError, LookupError, RoutingMatchError) as error:
                self._set_preview_status(f"Automatic routing failed: {error}", "error")
                return
        if not message:
            self._set_preview_status("Add or select a message before running the sandbox.", "error")
            return
        values = {}
        if action == "build":
            try:
                values = self._read_preview_values()
            except SandboxValueError as error:
                self._set_preview_status(f"Message initialization is invalid: {error}", "error")
                return
        action_names = {
            "build": "Building wire bytes",
            "parse": "Parsing wire bytes",
            "round_trip": "Verifying the byte-for-byte round trip",
        }
        self._set_preview_status(f"{action_names.get(action, 'Running preview')} for {message}…", "working")
        QtWidgets.QApplication.processEvents(QtCore.QEventLoop.ExcludeUserInputEvents)
        request = {
            "manifest": self.document.data,
            "behaviors": self._behavior_source(),
            "message": message,
            "action": action,
            "values": values,
            "hex": self.preview_hex.toPlainText(),
        }
        try:
            result = subprocess.run(
                [sys.executable, "-m", "app.tools.message_designer.sandbox"],
                input=json.dumps(request), capture_output=True, text=True,
                cwd=str(Path(__file__).resolve().parents[3]), timeout=8,
            )
        except subprocess.TimeoutExpired:
            self._set_preview_status("Preview timed out after 8 seconds.", "error")
            return
        try:
            response = json.loads(result.stdout)
        except json.JSONDecodeError:
            response = {"ok": False, "error": result.stderr or "Preview process returned invalid output"}
        if not response.get("ok"):
            self._set_preview_status(response.get("error", "Preview failed"), "error")
            return
        self.preview_hex.setPlainText(response.get("rebuilt_hex") or response.get("hex", ""))
        self._preview_rendered_message = message
        response_values = response.get("values", {})
        self._preview_value_drafts[message] = copy.deepcopy(response_values)
        self._write_preview_values(response_values, message)
        self.preview_result.clear()
        if routing_trace:
            route_root = QtWidgets.QTreeWidgetItem(["Routing", "route", routing_trace["message"]["name"]])
            for identifier in routing_trace['identifiers']:
                route_root.addChild(QtWidgets.QTreeWidgetItem([
                    f"{identifier['group']}.{identifier['name']}", identifier['type'],
                    f"{identifier['value']!r} · {identifier['hex']}",
                ]))
            self.preview_result.addTopLevelItem(route_root)
            route_root.setExpanded(True)
        _append_result_tree(self.preview_result, response.get("values", {}))
        self.preview_result.expandToDepth(1)
        round_trip = response.get("round_trip")
        if round_trip is True:
            status = "Round trip matched exactly; rebuilt bytes are identical to the input."
        elif action == "build":
            status = "Message built successfully from the structured values."
        else:
            status = "Wire bytes parsed successfully."
        self._set_preview_status(status, "success")

    def new_library(self):
        if not self._resolve_unsaved_changes():
            return
        name, accepted = QtWidgets.QInputDialog.getText(self, "New message library", "Python package name:", text="protocol_messages")
        if not accepted:
            return
        self.loaded = None
        self.package_parent = None
        self._clear_tree_filters()
        self._restored_expanded_keys = None
        self._filter_expansion_snapshot = None
        manifest = new_manifest(name.strip())
        self.document.data = copy.deepcopy(manifest)
        self.document.saved_snapshot = copy.deepcopy(manifest)
        self._selected_uid = manifest["library"]["uid"]
        self._properties_pending = False
        self._tree_initialized = False
        self.undo_stack.clear()
        self.document.notify("new")

    def open_library(self):
        if not self._resolve_unsaved_changes():
            return
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Open generated message package")
        if not folder:
            return
        try:
            loaded = load_library(folder)
        except LibraryPersistenceError as error:
            QtWidgets.QMessageBox.critical(self, "Cannot open library", str(error))
            return
        self.loaded = loaded
        self.package_parent = loaded.package_dir.parent
        self._clear_tree_filters()
        self._restored_expanded_keys = None
        self._filter_expansion_snapshot = None
        self._tree_initialized = False
        self.document.replace(loaded.manifest, reason="opened")
        self.document.mark_saved()
        self.undo_stack.clear()
        behavior_issues = self._behavior_method_issues()
        if behavior_issues:
            QtWidgets.QMessageBox.warning(
                self, "Behavior method warnings",
                "The loaded behaviors.py differs from the method declarations:\n\n" +
                "\n".join("• " + issue.message for issue in behavior_issues),
            )

    def save_library(self, save_as=False):
        if self.routing_studio.apply.isEnabled() and not self.routing_studio.apply_pending():
            return False
        if self._properties_pending and not self.apply_properties():
            return False
        issues = [
            issue
            for issue in [
                *validate_manifest(self.document.data),
                *self._behavior_method_issues(),
            ]
            if issue.blocking
        ]
        if issues:
            QtWidgets.QMessageBox.critical(self, "Cannot save", "Resolve blocking validation errors first.")
            return False
        if save_as or self.package_parent is None:
            folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select parent folder for generated package")
            if not folder:
                return False
            parent = Path(folder)
            previous = None
        else:
            parent = self.package_parent
            previous = self.loaded
            target = parent / self.document.data["library"]["package_name"]
            if previous and target.resolve() != previous.package_dir.resolve():
                previous = None
        changes = compatibility_changes(self.document.saved_snapshot, self.document.data)
        if changes["breaking"]:
            detail = "\n".join("• " + item for item in changes["breaking"])
            answer = QtWidgets.QMessageBox.warning(
                self, "Breaking library changes", "The following changes can break existing data or code:\n\n" + detail + "\n\nContinue?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return False
        try:
            outcome = save_library(parent, self.document.data, previous=previous)
        except ExternalModificationError as error:
            answer = QtWidgets.QMessageBox.warning(
                self, "Generated files changed externally",
                str(error) + "\n\nOverwrite the generated files? behaviors.py will still be merged and preserved.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return False
            try:
                outcome = save_library(parent, self.document.data, previous=None, overwrite_modified=True)
            except Exception as retry_error:
                QtWidgets.QMessageBox.critical(self, "Save failed", str(retry_error))
                return False
        except Exception as error:
            QtWidgets.QMessageBox.critical(self, "Save failed", str(error))
            return False
        self.loaded = load_library(outcome.package_dir)
        self.package_parent = outcome.package_dir.parent
        self.document.mark_saved(outcome.manifest)
        message = f"Saved {outcome.package_dir}"
        if outcome.backup_dir:
            message += f"; backup: {outcome.backup_dir}"
        self.statusBar().showMessage(message, 10000)
        if outcome.warnings:
            QtWidgets.QMessageBox.information(self, "Preserved custom code", "\n".join(outcome.warnings))
        return True

    def open_behavior_code(self):
        if not self.loaded:
            QtWidgets.QMessageBox.information(self, "Save first", "Save the library before opening behaviors.py.")
            return
        path = self.loaded.package_dir / "behaviors.py"
        line = 1
        value = self.document.find(self._selected_uid)
        owner_uid = self._selected_message_uid()
        owner = self.document.find(owner_uid) if owner_uid else None
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
            class_name = owner.get("behavior_class") if owner else None
            method_name = value.get("name") if value and value in (owner or {}).get("methods", []) else None
            for node in tree.body:
                if isinstance(node, ast.ClassDef) and node.name == class_name:
                    line = node.lineno
                    if method_name:
                        method = next((item for item in node.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == method_name), None)
                        if method:
                            line = method.lineno
                    break
        except (OSError, SyntaxError):
            pass
        opener = self._behavior_opener or getattr(self.parent(), "_open_message_behavior_in_vscode", None)
        if callable(opener):
            opener(path, line)
        else:
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(path)))

    def cleanup_empty_orphans(self):
        if not self.loaded:
            QtWidgets.QMessageBox.information(self, "Save first", "Save the library before cleaning behavior stubs.")
            return
        path = self.loaded.package_dir / "behaviors.py"
        try:
            source = path.read_text(encoding="utf-8")
            cleaned, removed = remove_empty_orphans(source, self.document.data.get("messages", []))
        except (OSError, SyntaxError) as error:
            QtWidgets.QMessageBox.critical(self, "Cannot inspect behaviors.py", str(error))
            return
        if not removed:
            QtWidgets.QMessageBox.information(self, "No empty orphans", "No removable empty behavior methods or mixins were found.")
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Remove empty orphan stubs",
            "Remove these empty stubs? Non-empty custom code is never selected.\n\n" + "\n".join(removed),
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
        )
        if answer != QtWidgets.QMessageBox.Yes:
            return
        backup = path.with_suffix(".py.message-designer.bak")
        backup.write_text(source, encoding="utf-8")
        temporary = path.with_suffix(".py.message-designer.tmp")
        temporary.write_text(cleaned, encoding="utf-8")
        os.replace(temporary, path)
        self._refresh_code()
        self.statusBar().showMessage(f"Removed {len(removed)} empty orphan stubs; backup: {backup}", 10000)

    def _store_session(self):
        if not getattr(self, "session_path", None):
            return
        try:
            save_session(
                self.session_path, self.document.data, self.document.saved_snapshot,
                package_dir=self.loaded.package_dir if self.loaded else None,
                selected_uid=self._selected_uid,
                expanded_tree_keys=list(
                    self._filter_expansion_snapshot
                    if self._filters_active() and self._filter_expansion_snapshot is not None
                    else (self._expanded_tree_keys() if hasattr(self, "tree") else set())
                ),
            )
        except OSError as error:
            if hasattr(self, "statusBar"):
                self.statusBar().showMessage(f"Could not store Message Designer recovery session: {error}", 8000)

    def _resolve_unsaved_changes(self):
        routing_pending = self.routing_studio.apply.isEnabled()
        if self.loaded is not None and not self.document.is_dirty and not self._properties_pending and not routing_pending:
            return True
        descriptions = []
        if self._properties_pending: descriptions.append("Some property edits have not been applied.")
        if routing_pending: descriptions.append("Some routing edits have not been applied.")
        if self.document.is_dirty: descriptions.append("The message library has changes that have not been saved.")
        elif self.loaded is None: descriptions.append("This new message library has not been saved to a folder.")
        answer = QtWidgets.QMessageBox.warning(
            self, "Unsaved Message Designer changes", "\n".join(descriptions) + "\n\nSave before continuing?",
            QtWidgets.QMessageBox.Save | QtWidgets.QMessageBox.Discard | QtWidgets.QMessageBox.Cancel,
            QtWidgets.QMessageBox.Save,
        )
        if answer == QtWidgets.QMessageBox.Save:
            return self.save_library()
        if answer == QtWidgets.QMessageBox.Discard:
            self._properties_pending = False
            self.routing_studio.refresh(self.document.data, self._selected_uid)
            return True
        return False

    def closeEvent(self, event):
        was_dirty = self.loaded is None or self.document.is_dirty or self._properties_pending or self.routing_studio.apply.isEnabled()
        had_target = self.loaded is not None
        if not self._resolve_unsaved_changes():
            event.ignore()
            return
        if was_dirty and not self.document.is_dirty and not self._properties_pending:
            # The Save branch already stored the clean session.
            self._store_session()
        elif was_dirty:
            # Explicit Discard must not recover the discarded draft next time.
            if had_target:
                self.document.restore_saved()
                self._store_session()
            else:
                clear_session(self.session_path)
        else:
            self._store_session()
        event.accept()


def _append(collection, value):
    collection.append(value)
    return value["uid"]


def _unique_name(data, base):
    used = {item.get("name") for key in ("enums", "structures", "groups", "messages") for item in data.get(key, [])}
    name, index = base, 1
    while name in used:
        index += 1
        name = f"{base}{index}"
    return name


def _sync_linked_message_name(data, old_structure, new_structure, *, rename_behavior):
    old_message_name = old_structure.get("name", "") + "Msg"
    requested_name = new_structure.get("name", "") + "Msg"
    old_field_name = re.sub(r"(?<!^)(?=[A-Z])", "_", old_structure.get("name", "")).lower()
    new_field_name = re.sub(r"(?<!^)(?=[A-Z])", "_", new_structure.get("name", "")).lower()
    for message in data.get("messages", []):
        if message.get("generated_from_struct_uid") != new_structure.get("uid"):
            continue
        if message.get("name") == old_message_name:
            used = {
                item.get("name")
                for category in ("enums", "structures", "messages")
                for item in data.get(category, [])
                if item.get("uid") != message.get("uid")
            }
            name, index = requested_name, 1
            while name in used:
                index += 1; name = f"{requested_name}{index}"
            previous_name = message["name"]
            message["name"] = name
            if message.get("display_name") == previous_name:
                message["display_name"] = name
            if rename_behavior and message.get("behavior_class") == previous_name + "Behavior":
                message["behavior_class"] = name + "Behavior"
        field = next((
            item for item in message.get("fields", [])
            if item.get("uid") == message.get("generated_struct_field_uid")
        ), None)
        if field and field.get("name") == old_field_name:
            field["name"] = new_field_name


def _find_in_data(data, uid):
    if data.get("library", {}).get("uid") == uid:
        return data["library"]
    collection, index = _find_collection(data, uid)
    return collection[index] if collection is not None else None


def _find_collection(data, uid):
    for key in ("enums", "structures", "groups", "messages"):
        collection = data.get(key, [])
        for index, item in enumerate(collection):
            if item.get("uid") == uid:
                return collection, index
            for nested_key in ("fields", "runtime_attributes", "constants", "methods"):
                result = _find_nested_collection(item.get(nested_key, []), uid)
                if result[0] is not None:
                    return result
    return None, -1


def _message_group_uid(data, message):
    groups = data.get("groups", [])
    return message.get("group_uid") or data["library"]["uid"]


def _selected_group_uid_from_data(data, uid):
    group = next((item for item in data.get("groups", []) if item.get("uid") == uid), None)
    if group:
        return group.get("uid", "")
    message = next((item for item in data.get("messages", []) if item.get("uid") == uid), None)
    return _message_group_uid(data, message) if message else ""


def _find_nested_collection(collection, uid):
    for index, item in enumerate(collection):
        if item.get("uid") == uid:
            return collection, index
        if isinstance(item.get("item"), dict):
            result = _find_nested_collection([item["item"]], uid)
            if result[0] is not None:
                return result
        result = _find_nested_collection(item.get("fields", []), uid)
        if result[0] is not None:
            return result
        for case in item.get("cases", []):
            if isinstance(case.get("item"), dict):
                result = _find_nested_collection([case["item"]], uid)
                if result[0] is not None:
                    return result
    return None, -1


def _refresh_ids(value):
    if isinstance(value, dict):
        if "uid" in value:
            value["uid"] = new_id()
        for item in value.values():
            _refresh_ids(item)
    elif isinstance(value, list):
        for item in value:
            _refresh_ids(item)


def _append_result_tree(tree, value, parent=None, path="root"):
    if isinstance(value, dict):
        item = QtWidgets.QTreeWidgetItem([path, "dict", f"{len(value)} fields"])
        (parent.addChild if parent else tree.addTopLevelItem)(item)
        for key, nested in value.items():
            _append_result_tree(tree, nested, item, str(key))
        item.setExpanded(True)
    elif isinstance(value, list):
        item = QtWidgets.QTreeWidgetItem([path, "list", f"{len(value)} items"])
        (parent.addChild if parent else tree.addTopLevelItem)(item)
        for index, nested in enumerate(value):
            _append_result_tree(tree, nested, item, f"[{index}]")
        item.setExpanded(True)
    else:
        item = QtWidgets.QTreeWidgetItem([path, type(value).__name__, repr(value)])
        (parent.addChild if parent else tree.addTopLevelItem)(item)


def _child_uids(parent):
    if parent is None:
        return []
    values = []
    for index in range(parent.childCount()):
        info = parent.child(index).data(0, QtCore.Qt.UserRole) or {}
        if info.get("uid"):
            values.append(info["uid"])
    return values
