import sys, ast, traceback, json, subprocess
import multiprocessing
import threading
from PyQt5 import QtWidgets, QtGui, QtCore
import warnings, os, shutil
from pathlib import Path
from app.branding import FULL_NAME, SHORT_NAME, environment_name
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

SUPERVISED_ENV_VAR = environment_name("DESIGNER_SUPERVISED")
SUPERVISOR_PID_ENV_VAR = environment_name("DESIGNER_SUPERVISOR_PID")
SHUTDOWN_TIMEOUT_ENV_VAR = environment_name("DESIGNER_SHUTDOWN_TIMEOUT")
GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS = float(
    os.environ.get(SHUTDOWN_TIMEOUT_ENV_VAR, "40")
)
APP_RESTART_EXIT_CODE_VAR = environment_name("DESIGNER_RESTART_EXIT_CODE")
APP_RESTART_MARKER = environment_name("DESIGNER_RESTART_REQUESTED")
APP_UPGRADE_EXIT_CODE_VAR = environment_name("DESIGNER_UPGRADE_EXIT_CODE")
APP_UPGRADE_MARKER = environment_name("DESIGNER_UPGRADE_REQUESTED") + ":"
APP_RESTART_EXIT_CODE = int(os.environ.get(APP_RESTART_EXIT_CODE_VAR, "42"))
APP_UPGRADE_EXIT_CODE = int(os.environ.get(APP_UPGRADE_EXIT_CODE_VAR, "43"))


def process_is_running(pid):
    """Return whether a PID represents a live process, not a retained handle."""
    if pid <= 0:
        return False
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.argtypes = (
            wintypes.DWORD, wintypes.BOOL, wintypes.DWORD,
        )
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.GetExitCodeProcess.argtypes = (
            wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD),
        )
        kernel32.GetExitCodeProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        handle = kernel32.OpenProcess(0x1000, False, int(pid))
        if not handle:
            return False
        try:
            exit_code = wintypes.DWORD()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return False
            return exit_code.value == 259  # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return False


def configure_hidden_multiprocessing():
    """Use the environment's console interpreter for reliable Windows IPC.

    The Designer supervisor already starts the application with
    CREATE_NO_WINDOW. Replacing the multiprocessing executable with
    pythonw.exe is therefore unnecessary, and on Python 3.14 it can make
    spawned workers close their control pipes shortly after startup.
    """
    if os.name != "nt" or is_frozen():
        return
    executable = Path(sys.executable)
    python = executable.with_name("python.exe")
    multiprocessing.set_executable(str(python if python.is_file() else executable))


def gui_python_executable():
    """Return a console-free interpreter for GUI restarts when available."""
    executable = Path(sys.executable)
    if os.name == "nt" and not is_frozen():
        pythonw = executable.with_name("pythonw.exe")
        if pythonw.is_file():
            return str(pythonw)
    return str(executable)


from app.startup import (
    LifecycleLoaderSession,
    apply_app_icon,
    set_windows_app_id,
)
from app.ui_builder import ConfigDrivenWindow
from app.config_designer.api import ConfigDesignerWindow
from app.tools.message_designer.api import MessageDesignerWindow
from app.builder import BuildAppDialog
from app.upgrade_dialogs import AppVersionDialog, BaselineExportWizard, UpgradeWizard
from app.upgrade_manager import (
    INSTALLED_MANIFEST,
    PACKAGE_FILENAME,
    STATE_DIRNAME,
    hide_windows_path,
)
from app.tool_api import Tools
from app.help_system import HelpWindow
from app.project_recovery import ensure_project_files
from app.utils import (
    PROJECT_ROOT, CALLBACKS_PATH, HELP_PATH,
    set_widow_feature, is_frozen
)
from app.vscode_integration import (
    MINIMUM_VSCODE_VERSION_TEXT,
    VSCodeCapability,
    capability_from_environment,
    discover_vscode,
    open_vscode,
    vscode_editor_issue,
)


class _VSCodeCapabilitySignals(QtCore.QObject):
    finished = QtCore.pyqtSignal(object)


class _VSCodeCapabilityTask(QtCore.QRunnable):
    """Run the VS Code CLI probes without blocking the GUI thread."""

    def __init__(self, configured_executable):
        super().__init__()
        self.configured_executable = configured_executable
        self.signals = _VSCodeCapabilitySignals()

    def run(self):
        try:
            capability = discover_vscode(self.configured_executable)
        except Exception as exc:
            capability = VSCodeCapability(error=f"VS Code validation failed: {exc}")
        self.signals.finished.emit(capability)

class MainApp(ConfigDrivenWindow):
    closing = QtCore.pyqtSignal(str)
    closed = QtCore.pyqtSignal(str)
    soft_restarting = QtCore.pyqtSignal(int)
    soft_restart_finished = QtCore.pyqtSignal(int, bool)
    supervisor_lost = QtCore.pyqtSignal()

    def __init__(self, *, degraded_startup=False):
        super().__init__(degraded_startup=degraded_startup)
        self._lifecycle_loader = LifecycleLoaderSession()
        self._shutdown_operation = ""
        self._shutdown_feedback_started = False
        self._shutdown_feedback_finished = False
        self._shutdown_watchdog_started = False
        self._soft_restart_generation = None
        self._source_reload_loader_active = False
        self._soft_restart_error = ""
        self._soft_restart_result_serial = 0
        self._restarting = False
        self._supervisor_shutdown_reason = ""
        self._process_exit_complete = threading.Event()
        self.closing.connect(self._show_shutdown_loader)
        self.closed.connect(self._finish_shutdown_loader)
        self.soft_restarting.connect(self._show_soft_restart_loader)
        self.soft_restart_finished.connect(self._finish_soft_restart_loader)
        self.source_reload_started.connect(self._show_source_reload_loader)
        self.source_reload_finished.connect(self._finish_source_reload_loader)
        self.supervisor_lost.connect(self._handle_supervisor_lost)
        self.global_runtime.reload_finished.connect(
            self._on_explicit_soft_restart_finished
        )
        if self.phase == "development":
            for hidden_path in (
                Path(PROJECT_ROOT) / "app",
                Path(PROJECT_ROOT) / STATE_DIRNAME,
                Path(PROJECT_ROOT) / PACKAGE_FILENAME,
            ):
                hide_windows_path(hidden_path)
        self._make_menubar()
        self._supervisor_control_token = ""
        self._supervisor_control_timer = QtCore.QTimer(self)
        self._supervisor_control_timer.setInterval(250)
        self._supervisor_control_timer.timeout.connect(self._check_supervisor_control)
        self._supervisor_control_timer.start()
        self._start_supervisor_parent_watcher()
        QtCore.QTimer.singleShot(0, self._show_upgrade_result)

    def _check_supervisor_control(self):
        if self._consume_supervisor_shutdown_request():
            self.close()

    def _consume_supervisor_shutdown_request(self):
        path = Path(PROJECT_ROOT) / "designer" / "app-control.json"
        try:
            request = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        token = str(request.get("token") or "")
        try:
            target_pid = int(request.get("target_pid") or 0)
        except (TypeError, ValueError):
            return False
        if (
            not token
            or target_pid != os.getpid()
            or request.get("command") != "close"
        ):
            return False
        if token == self._supervisor_control_token:
            return bool(getattr(self, "_supervisor_shutdown_requested", False))
        self._supervisor_control_token = token
        self._supervisor_shutdown_requested = True
        self._supervisor_shutdown_reason = str(request.get("reason") or "")
        request["state"] = "acknowledged"
        try:
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(json.dumps(request, indent=2) + "\n", encoding="utf-8")
            temporary.replace(path)
        except OSError:
            pass
        return True

    def _start_hard_shutdown_watchdog(self):
        if getattr(self, "_shutdown_watchdog_started", False):
            return
        self._shutdown_watchdog_started = True
        completion = self._process_exit_complete

        def enforce_deadline():
            if completion.wait(GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS):
                return
            print(
                "Lifecycle cleanup exceeded its "
                f"{GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS:g}-second limit; "
                "forcing process exit.",
                flush=True,
            )
            os._exit(1)

        threading.Thread(
            target=enforce_deadline,
            name="designer-shutdown-watchdog",
            daemon=True,
        ).start()

    @staticmethod
    def _pid_is_running(pid):
        return process_is_running(pid)

    def _start_supervisor_parent_watcher(self):
        try:
            supervisor_pid = int(os.environ.get(SUPERVISOR_PID_ENV_VAR, "0"))
        except (TypeError, ValueError):
            supervisor_pid = 0
        if supervisor_pid <= 0:
            return

        completion = self._process_exit_complete

        def watch_parent():
            while not completion.wait(0.5):
                if self._pid_is_running(supervisor_pid):
                    continue
                self.supervisor_lost.emit()
                # This deadline remains effective even when the Qt thread is
                # blocked in synchronous cleanup.
                if not completion.wait(
                    GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS + 5.0
                ):
                    os._exit(1)
                return

        threading.Thread(
            target=watch_parent,
            name="designer-supervisor-watcher",
            daemon=True,
        ).start()

    def _handle_supervisor_lost(self):
        if getattr(self, "_global_shutdown_complete", False):
            return
        self._supervisor_shutdown_requested = True
        if not self._supervisor_shutdown_reason:
            self._supervisor_shutdown_reason = "supervisor-exit"
        self.close()

    # ---------------- Menus ----------------
    def _make_menubar(self):
        mb = self.menuBar()

        file_menu = mb.addMenu('&File')
        act_open_designer = file_menu.addAction('Config Designer…')
        file_menu.addSeparator()

        if self.phase == "baseline" and not is_frozen():
            act_export_baseline = file_menu.addAction('Export Baseline…')
        act_upgrade = file_menu.addAction('Upgrade…')
        file_menu.addSeparator()

        act_soft_restart = file_menu.addAction('Soft Restart')
        self._soft_restart_action = act_soft_restart
        act_restart = file_menu.addAction('Restart')
        file_menu.addSeparator()

        act_exit = file_menu.addAction('Exit')

        settings_menu = mb.addMenu('&Settings')
        act_set_admin = settings_menu.addAction('Set Admin Password…')
        act_set_title = settings_menu.addAction('Set Window Title…')
        act_set_icon = settings_menu.addAction('Set Window Icon…')
        
        if not is_frozen():
            build_menu = mb.addMenu('&Build') 
            act_build = build_menu.addAction('Build Application')

        version_menu = mb.addMenu('&Version')

        if not is_frozen():
            act_set_version = version_menu.addAction('Set App Version…')
        act_version = version_menu.addAction(f'Version: {self.version}.{self.build}')
        act_version.setEnabled(False)  # makes it informational only
        act_baseline = version_menu.addAction(f'Baseline: {self.baseline_number}')
        act_baseline.setEnabled(False)
        version_menu.addSeparator()
        act_app_release_notes = version_menu.addAction('App Version Release Notes…')
        act_baseline_release_notes = version_menu.addAction('Baseline Release Notes…')

        # -------- Tools Menu --------
        tools_menu = mb.addMenu('&Tools')
        act_open_variable_explorer = tools_menu.addAction('Variable Explorer')
        act_open_ftp_server = tools_menu.addAction('FTP Server')
        act_open_ftp_client  = tools_menu.addAction('FTP Client')
        act_open_serial = tools_menu.addAction('Serial')
        act_open_telnet  = tools_menu.addAction('Telnet')
        act_open_communication = tools_menu.addAction('Communication Hub')
        act_open_message_designer = tools_menu.addAction('Message Designer')

        self._vscode_capability = capability_from_environment()
        self._vscode_validation_task = None
        self._vscode_validation_callback = None
        self._vscode_validation_closing = False
        self._vscode_menu = mb.addMenu('&VS Code')
        self._vscode_menu.setToolTipsVisible(True)
        self._vscode_project_action = self._vscode_menu.addAction('Open Project')
        self._vscode_callbacks_action = self._vscode_menu.addAction('Open callbacks.py')
        self._vscode_menu.addSeparator()
        self._vscode_status_action = self._vscode_menu.addAction('Integration Status')
        self._update_vscode_actions()

        if not is_frozen() and self.phase in {"baseline", "development"}:
            assistant_menu = mb.addMenu('&Assistant')
            act_assistant = assistant_menu.addAction('Open Assistant')
            act_assistant.triggered.connect(self._open_assistant)

        help_menu = mb.addMenu('&Help')
        act_help_contents = help_menu.addAction('Help Contents')
        act_help_contents.triggered.connect(self._open_help)
        

        # Wire
        act_open_designer.triggered.connect(self._open_designer) #Sorting
        if self.phase == "baseline" and not is_frozen():
            act_export_baseline.triggered.connect(self._export_baseline)
        act_upgrade.triggered.connect(self._upgrade)
        act_soft_restart.triggered.connect(self._soft_restart)
        act_restart.triggered.connect(self._restart)
        act_exit.triggered.connect(self.close)

        act_set_admin.triggered.connect(self._set_admin_password)
        act_set_title.triggered.connect(self._set_title)
        act_set_icon.triggered.connect(self._set_icon)
        
        if not is_frozen():
            act_set_version.triggered.connect(self._set_version)
            act_build.triggered.connect(self._build_app)

        version_menu.aboutToShow.connect(
            lambda: (
                act_version.setText(f'Version: {self.version}.{self.build}'),
                act_baseline.setText(f'Baseline: {self.baseline_number}')
            )
        )

        act_open_variable_explorer.triggered.connect(self._open_variable_explorer)
        act_open_ftp_server.triggered.connect(self._open_ftp_server)
        act_open_ftp_client.triggered.connect(self._open_ftp_client)
        act_open_serial.triggered.connect(self._open_serial)
        act_open_telnet.triggered.connect(self._open_telnet)
        act_open_communication.triggered.connect(self._open_communication_hub)
        act_open_message_designer.triggered.connect(self._open_message_designer)
        self._vscode_project_action.triggered.connect(self._open_project_in_vscode)
        self._vscode_callbacks_action.triggered.connect(self._open_callbacks_in_vscode)
        self._vscode_status_action.triggered.connect(self._show_vscode_status)
        act_app_release_notes.triggered.connect(self._show_app_version_release_notes)
        act_baseline_release_notes.triggered.connect(self._show_baseline_release_notes)

    # -------- Admin gate for sensitive actions --------
    def _admin_ok(self) -> bool:
        # No password set → always allowed
        if not self.admin_pasword:
            return True

        txt, ok = QtWidgets.QInputDialog.getText(
            self,
            "Admin Password",
            "Enter admin password:",
            QtWidgets.QLineEdit.Password
        )

        if not ok:
            return False  # user cancelled

        if txt != self.admin_pasword:
            QtWidgets.QMessageBox.warning(
                self,
                "Access Denied",
                "Incorrect admin password."
            )
            return False

        return True
    
    # -------- Menu handlers --------
    def _open_designer(self):
        if not self._admin_ok():
            return
        try:
            designer = getattr(self, "_config_designer", None)
            if designer is None:
                designer = ConfigDesignerWindow(self)
                self._config_designer = designer
                designer.applied.connect(self._reload_layout)
                designer.saved.connect(self._reload_layout)
                designer.restoreRequested.connect(self._reload_layout)
                if not is_frozen() and self.phase in {"baseline", "development"}:
                    action = designer.menuBar().addMenu("Assistant").addAction("Open Assistant")
                    action.triggered.connect(lambda: self._open_assistant(host=designer))
            designer.show()
            designer.raise_()
            designer.activateWindow()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Designer Error", f"Failed to launch Configuration Designer:\n{e}")

    def _export_baseline(self):
        if not self._admin_ok():
            return
        wizard = BaselineExportWizard(self, self.baseline_number, self.version, self.build)
        if wizard.exec_() != QtWidgets.QDialog.Accepted or not wizard.export_result:
            return
        released_baseline = wizard.baseline.value()
        self.baseline_number = released_baseline + 1
        set_widow_feature("baseline_number", self.baseline_number)
        outputs = "\n".join(wizard.export_result.values())
        QtWidgets.QMessageBox.information(
            self, "Baseline Exported",
            f"Baseline {released_baseline} was exported and verified successfully:\n\n{outputs}"
        )

    def _upgrade(self):
        if not self._admin_ok():
            return
        wizard = UpgradeWizard(self, self.baseline_number)
        if wizard.exec_() != QtWidgets.QDialog.Accepted or not wizard.plan_path:
            return
        self._upgrade_plan_path = str(wizard.plan_path)
        QtCore.QTimer.singleShot(0, self._request_upgrade_shutdown)

    def _request_upgrade_shutdown(self):
        if os.environ.get(SUPERVISED_ENV_VAR) != "1":
            restart = [sys.executable, "-m", "app.main"]
            command = [
                sys.executable, "-m", "app.upgrade_helper", self._upgrade_plan_path,
                "--wait-pid", str(os.getpid()), "--restart-json", json.dumps(restart),
            ]
            creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            subprocess.Popen(
                command, cwd=PROJECT_ROOT, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=creationflags,
            )
        self.close()

    def _show_upgrade_result(self):
        result_path = Path(PROJECT_ROOT) / STATE_DIRNAME / "last-result.json"
        if not result_path.is_file():
            return
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
            result_path.unlink()
        except Exception:
            return
        if result.get("success"):
            release = result.get("release", {})
            notes = release.get("notes") or "No detailed release notes were supplied."
            baseline_label = f"Baseline {release.get('baseline_number')}"
            release_title = str(release.get("title") or "").strip()
            release_heading = baseline_label
            if release_title and release_title.casefold() != baseline_label.casefold():
                release_heading = f"{release_title}\n{baseline_label}"
            restart_note = ""
            if result.get("restart_error"):
                restart_note = f"\n\nAutomatic restart failed: {result['restart_error']}"
            QtWidgets.QMessageBox.information(
                self, "Upgrade Successful — Release Notes",
                f"{release_heading}\n\n"
                f"Changed files: {len(result.get('changed', []))}\n"
                f"Preserved files: {len(result.get('preserved', []))}\n\nRelease notes:\n{notes}"
                f"{restart_note}"
            )
        else:
            QtWidgets.QMessageBox.critical(
                self, "Upgrade Failed and Was Rolled Back",
                f"The upgrade could not be completed. Existing files were restored.\n\n"
                f"{result.get('error', 'Unknown upgrade error')}\n\nBackup: {result.get('backup', '')}"
            )

    def _show_baseline_release_notes(self):
        state_path = Path(PROJECT_ROOT) / STATE_DIRNAME
        try:
            manifest = json.loads(
                (state_path / INSTALLED_MANIFEST).read_text(encoding="utf-8")
            )
            release = manifest["release"]
            if not isinstance(release, dict):
                raise ValueError("Installed baseline release metadata is invalid.")
        except Exception:
            try:
                history = json.loads(
                    (state_path / "history.json").read_text(encoding="utf-8")
                )
                release = history[-1]["release"]
                if not isinstance(release, dict):
                    raise ValueError("Baseline release history is invalid.")
            except Exception:
                QtWidgets.QMessageBox.information(
                    self, "Baseline Release Notes",
                    "No installed baseline release notes are available."
                )
                return
        baseline_label = f"Baseline {release.get('baseline_number')}"
        release_title = str(release.get("title") or "").strip()
        release_heading = baseline_label
        if release_title and release_title.casefold() != baseline_label.casefold():
            release_heading = f"{release_title}\n{baseline_label}"
        QtWidgets.QMessageBox.information(
            self, "Baseline Release Notes",
            f"{release_heading}\n\n"
            f"{release.get('summary', '')}\n\n{release.get('notes', '') or 'No detailed release notes were supplied.'}"
        )

    def _show_app_version_release_notes(self):
        notes = self.app_version_release_notes.strip()
        QtWidgets.QMessageBox.information(
            self, "App Version Release Notes",
            f"Application version {self.version}\n\n"
            f"{notes or 'No release notes were supplied for this application version.'}"
        )

    def _show_shutdown_loader(self, operation):
        phase = {
            "restart": "restarting",
            "upgrade": "upgrade",
        }.get(operation, "closing")
        center = self._loader_center()
        self.setEnabled(False)
        self._lifecycle_loader.show(phase, center=center)
        # The independent loader owns shutdown feedback.  Leaving the disabled
        # application window visible makes a graceful close look like it failed.
        self.hide()

    def _finish_shutdown_loader(self, operation):
        text = {
            "restart": "Restarting application...",
            "upgrade": "Continuing application upgrade...",
        }.get(operation, "Application closed.")
        self._lifecycle_loader.finish(text)

    def _show_soft_restart_loader(self, generation):
        if self._shutdown_feedback_started:
            return
        self.setEnabled(False)
        self._lifecycle_loader.show(
            "soft_restarting", center=self._loader_center()
        )

    def _loader_center(self):
        center = self.frameGeometry().center()
        return center.x(), center.y()

    def _show_source_reload_loader(self):
        if self._shutdown_feedback_started or self._soft_restart_generation is not None:
            return
        self._source_reload_loader_active = True
        self.setEnabled(False)
        self._lifecycle_loader.show("source_reloading", center=self._loader_center())

    def _finish_source_reload_loader(self, succeeded):
        if not getattr(self, "_source_reload_loader_active", False):
            return
        self._source_reload_loader_active = False
        if self._shutdown_feedback_started:
            return
        self._lifecycle_loader.finish(
            "Source reload complete." if succeeded
            else "Source reload failed; restoring the application..."
        )
        self.setEnabled(True)
        self.raise_()
        self.activateWindow()

    def _finish_soft_restart_loader(self, generation, succeeded):
        if generation != self._soft_restart_generation:
            return
        if self._shutdown_feedback_started:
            return
        text = (
            "Soft restart complete."
            if succeeded else "Soft restart failed; restoring the application..."
        )
        self._lifecycle_loader.finish(text)
        self.setEnabled(True)
        self.raise_()
        self.activateWindow()

    def _soft_restart(self):
        """Start an explicit in-process runtime reload with lifecycle feedback."""
        if (
            self._soft_restart_generation is not None
            or self._shutdown_feedback_started
            or getattr(self, "_source_reload_in_progress", False)
        ):
            return
        expected_generation = self.global_runtime.generation + 1
        self._soft_restart_generation = expected_generation
        self._soft_restart_error = ""
        self._soft_restart_result_serial += 1
        self.soft_restarting.emit(expected_generation)
        QtCore.QTimer.singleShot(
            0,
            lambda generation=expected_generation: self._begin_explicit_soft_restart(
                generation
            ),
        )

    def _begin_explicit_soft_restart(self, expected_generation):
        if (
            self._soft_restart_generation != expected_generation
            or self._shutdown_feedback_started
        ):
            return
        try:
            generation = self._reload_runtime()
        except Exception:
            self._soft_restart_error = (
                f"'Runtime Reload' crashed:\n\n{traceback.format_exc()}"
            )
            self._complete_explicit_soft_restart(expected_generation, False)
            return
        if generation != expected_generation:
            self._soft_restart_generation = generation

    def _on_explicit_soft_restart_finished(self, generation, succeeded):
        if generation != self._soft_restart_generation:
            return
        self._complete_explicit_soft_restart(generation, succeeded)

    def _complete_explicit_soft_restart(self, generation, succeeded):
        if generation != self._soft_restart_generation:
            return
        result_serial = self._soft_restart_result_serial
        error = self._soft_restart_error
        self.soft_restart_finished.emit(generation, bool(succeeded))
        self._soft_restart_generation = None
        self._soft_restart_error = ""

        def show_result():
            if (
                result_serial != self._soft_restart_result_serial
                or self._shutdown_feedback_started
            ):
                return
            if not succeeded:
                self._show_error_traceback(
                    error or "Runtime reload failed; the last working runtime remains active."
                )

        # Let the loader's existing fade finish before displaying the result.
        QtCore.QTimer.singleShot(500, show_result)

    def _on_global_runtime_failed(self, generation, details):
        """Defer explicit soft-restart errors until its loader has faded."""
        if generation != getattr(self, "_soft_restart_generation", None):
            super()._on_global_runtime_failed(generation, details)
            return
        if self.global_runtime.current_callbacks is not None:
            self.callbacks = self.global_runtime.current_callbacks
            self._globals_obj = self.global_runtime.current_globals_object
        self._soft_restart_error = (
            f"Globals generation {generation} failed:\n\n{details}"
        )
        self.initialization_failed.emit(generation, details)

    def _restart(self):
        """Trigger a restart request — confirmation handled in closeEvent."""
        self._restarting = True
        self.close()  # closeEvent will handle confirmation and restart

    def _set_admin_password(self):
        if not self._admin_ok():
            return
        txt, ok = QtWidgets.QInputDialog.getText(self, 'Set Admin Password', 'New admin password (leave empty to clear):', QtWidgets.QLineEdit.Password)
        if ok:
            self.admin_pasword = (txt or None)
            set_widow_feature("admin_password", self.admin_pasword)

    def _set_title(self):
        if not self._admin_ok():
            return
        txt, ok = QtWidgets.QInputDialog.getText(self, 'Set Window Title', 'Title:', text=self.title)
        if ok:
            self.title = txt
            self.setWindowTitle(self.title)
            set_widow_feature("title", self.title)

    def _set_icon(self):
        if not self._admin_ok():
            return

        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Pick icon",
            PROJECT_ROOT,
            "Icon Files (*.ico)"
        )
        if not path:
            return

        src = Path(path)

        # Only accept .ico files
        if src.suffix.lower() != ".ico":
            QtWidgets.QMessageBox.warning(self, "Invalid Icon", "Please select a .ico file.")
            return

        # Target location inside project
        target_dir = Path(PROJECT_ROOT) / "app" / "favicon"
        target_dir.mkdir(parents=True, exist_ok=True)

        target_icon_path = target_dir / "app.ico"

        try:
            shutil.copy2(src, target_icon_path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Copy Failed", str(e))
            return

        # Apply icon from internal project path
        self.icon = str(target_icon_path)
        self.setWindowIcon(QtGui.QIcon(self.icon))

        # Save relative path in config (portable)
        rel_path = os.path.relpath(target_icon_path, PROJECT_ROOT).replace("\\", "/")
        set_widow_feature("icon", rel_path)

    def _set_version(self):
        if not self._admin_ok():
            return
        dialog = AppVersionDialog(
            self, self.version, self.app_version_release_notes
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        self.version = dialog.version.text().strip()
        self.app_version_release_notes = dialog.notes.toPlainText().strip()
        set_widow_feature("version", self.version)
        set_widow_feature("app_version_release_notes", self.app_version_release_notes)
        QtWidgets.QMessageBox.information(
            self, "Version Updated",
            f"Application version {self.version} and its release notes were saved."
        )

    def _build_app(self):
        if not self._admin_ok():
            return
        try:
            dlg = BuildAppDialog(self)
            dlg.exec_()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Build Error", f"Failed to launch Build Dialog:\n{e}")
    
    def _open_singleton(self, attr_name: str, cls, *args, **kwargs):
        """
        Opens a singleton window:
        - If the window exists and is visible → bring to front
        - If minimized → restore
        - If closed → create a new one
        """
        # If exists & visible → bring forward
        win = getattr(self, attr_name, None)
        if win:
            try:
                if hasattr(win, "reattach_ui") and not getattr(win, "_ui_attached", True):
                    win.reattach_ui()
                win.show()
                win.raise_()
                win.activateWindow()
                win.showNormal()
                return win
            except RuntimeError:
                setattr(self, attr_name, None)

        # Otherwise create new instance
        win = cls(*args, **kwargs)
        win.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)

        # Remove stored reference when destroyed
        def _clear():
            setattr(self, attr_name, None)

        win.destroyed.connect(_clear)

        setattr(self, attr_name, win)
        win.show()
        apply_app_icon(win)
        return win

    def _open_variable_explorer(self):
        if not self._admin_ok():
            return
        from app.tools.variable_explorer_process import VariableExplorerController
        controller = getattr(self, "_variable_explorer_controller", None)
        if controller is None:
            controller = VariableExplorerController(
                runtime=self.global_runtime, parent=self
            )
            self._variable_explorer_controller = controller
        controller.open()
        return controller
    
    def _vscode_is_available(self):
        if getattr(self, "_vscode_validation_task", None) is not None:
            return False
        capability = getattr(self, "_vscode_capability", None)
        return bool(capability and not vscode_editor_issue(capability))

    def _vscode_disabled_reason(self):
        if getattr(self, "_vscode_validation_task", None) is not None:
            return "Checking VS Code availability…"
        capability = getattr(self, "_vscode_capability", None)
        if capability is None:
            return f"Install VS Code {MINIMUM_VSCODE_VERSION_TEXT} or newer to use this feature."
        return vscode_editor_issue(capability)

    def _update_vscode_actions(self):
        reason = self._vscode_disabled_reason()
        enabled = not reason
        for action in (
            getattr(self, "_vscode_project_action", None),
            getattr(self, "_vscode_callbacks_action", None),
        ):
            if action is None:
                continue
            action.setEnabled(enabled)
            explanation = "Open with the configured VS Code project workspace." if enabled else reason
            action.setToolTip(explanation)
            action.setStatusTip(explanation)
        menu = getattr(self, "_vscode_menu", None)
        if menu is not None:
            menu.menuAction().setVisible(True)
            menu.menuAction().setToolTip(reason or "VS Code project integration is ready.")
        status_action = getattr(self, "_vscode_status_action", None)
        if status_action is not None:
            checking = getattr(self, "_vscode_validation_task", None) is not None
            status_action.setEnabled(not checking)
            status_action.setToolTip(
                "Checking VS Code availability…"
                if checking else "Refresh and show VS Code integration status."
            )

    def _configured_vscode_executable(self):
        settings_path = Path(PROJECT_ROOT) / "designer" / "settings.json"
        try:
            payload = json.loads(settings_path.read_text(encoding="utf-8"))
            return str(payload.get("vscode_executable") or "")
        except (OSError, json.JSONDecodeError, AttributeError):
            return ""

    def _request_vscode_validation(self, callback):
        if getattr(self, "_vscode_validation_task", None) is not None:
            self.statusBar().showMessage("A VS Code capability check is already running.", 3000)
            return False
        task = _VSCodeCapabilityTask(self._configured_vscode_executable())
        self._vscode_validation_task = task
        self._vscode_validation_callback = callback
        task.signals.finished.connect(self._complete_vscode_validation)
        self._update_vscode_actions()
        self.statusBar().showMessage("Checking VS Code…")
        QtCore.QThreadPool.globalInstance().start(task)
        return True

    @QtCore.pyqtSlot(object)
    def _complete_vscode_validation(self, capability):
        callback = getattr(self, "_vscode_validation_callback", None)
        self._vscode_validation_callback = None
        self._vscode_validation_task = None
        if getattr(self, "_vscode_validation_closing", False):
            return
        self._vscode_capability = capability
        self._update_vscode_actions()
        self.statusBar().showMessage("VS Code capability check complete.", 3000)
        if callback is not None:
            callback(capability)

    def _run_vscode_operation(self, operation):
        def after_validation(capability):
            issue = vscode_editor_issue(capability)
            if issue:
                QtWidgets.QMessageBox.warning(self, "VS Code Unavailable", issue)
                return
            try:
                operation(capability)
            except Exception as exc:
                QtWidgets.QMessageBox.warning(self, "VS Code", str(exc))

        self._request_vscode_validation(after_validation)

    def _open_project_in_vscode(self):
        if not self._admin_ok():
            return
        def open_project(capability):
            root = Path(PROJECT_ROOT)
            open_vscode(capability, root)
        self._run_vscode_operation(open_project)

    def _open_callbacks_in_vscode(self):
        if not self._admin_ok():
            return
        def open_callbacks(capability):
            root = Path(PROJECT_ROOT)
            open_vscode(
                capability,
                root,
                file_path=Path(CALLBACKS_PATH),
            )
        self._run_vscode_operation(open_callbacks)

    def _show_vscode_status(self):
        if not self._admin_ok():
            return
        def show_status(capability):
            mode = "VS Code Terminal" if os.environ.get("SAKIR_VSCODE_TERMINAL") == "1" else "Designer Console"
            debugger = "available" if os.environ.get("SAKIR_VSCODE_DEBUGGER") == "1" else "not available for this run"
            companion = "installed" if capability.supervisor_extension_ready else "not installed"
            missing = ", ".join(capability.missing_terminal_extensions) or "none"
            editor_status = vscode_editor_issue(capability) or "Ready"
            QtWidgets.QMessageBox.information(
                self,
                "VS Code Integration",
                f"VS Code: {capability.version or 'not detected'}\n"
                f"Minimum supported version: {MINIMUM_VSCODE_VERSION_TEXT}\n"
                f"Executable: {capability.executable or 'not configured'}\n"
                f"Capability: {capability.level}\n"
                f"Editor operations: {editor_status}\n"
                f"SAKiR Supervisor extension: {companion}\n"
                f"Missing required extensions: {missing}\n"
                f"Supervisor owner: {mode}\n"
                f"Debugger endpoint: {debugger}\n\n"
                "Use 'vscode-status' in the supervisor for setup instructions.",
            )
        self._request_vscode_validation(show_status)

    def _open_callback_in_vscode(self, func_name: str):
        if not self._admin_ok():
            return
        def open_callback(capability):
            source = Path(CALLBACKS_PATH).read_text(encoding="utf-8")
            tree = ast.parse(source, filename=CALLBACKS_PATH)
            target = next(
                (node for node in tree.body
                 if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == func_name),
                None,
            )
            if target is None:
                QtWidgets.QMessageBox.information(
                    self, "Callback Not Found",
                    f"'{func_name}' was not found. Save the configuration and try again.",
                )
                return
            root = Path(PROJECT_ROOT)
            open_vscode(
                capability,
                root,
                file_path=Path(CALLBACKS_PATH),
                line=target.lineno,
                column=target.col_offset + 1,
            )
        self._run_vscode_operation(open_callback)

    def _open_ftp_server(self):
        if not self._admin_ok():
            return
        from app.tools.ftp_server import FTPServerWidget
        return Tools.registry.register(
            "ftp_server", self._open_singleton("_ftp_server", FTPServerWidget)
        )
    
    def _open_ftp_client(self):
        if not self._admin_ok():
            return
        from app.tools.ftp_client import FTPClientWidget
        return Tools.registry.register(
            "ftp_client", self._open_singleton("_ftp_client", FTPClientWidget)
        )
    
    def _open_serial(self):
        if not self._admin_ok():
            return
        from app.tools.serial_widget import SerialWidget
        return Tools.registry.register(
            "serial", self._open_singleton("_serial_widget", SerialWidget)
        )

    def _open_telnet(self):
        if not self._admin_ok():
            return
        from app.tools.telnet_widget import TelnetWidget
        return Tools.registry.register(
            "telnet", self._open_singleton("_telnet_widget", TelnetWidget)
        )

    def _open_communication_hub(self):
        if not self._admin_ok():
            return
        from app.tools.communication_hub.widget import CommunicationHubWidget
        return Tools.registry.register(
            "communication", self._open_singleton("_communication_hub", CommunicationHubWidget)
        )

    def _open_message_designer(self):
        if not self._admin_ok():
            return
        widget = Tools.registry.register(
            "message_designer",
            self._open_singleton(
                "_message_designer", MessageDesignerWindow,
                behavior_opener=self._open_message_behavior_in_vscode,
            ),
        )
        if not is_frozen() and self.__dict__.get("phase") in {"baseline", "development"} and not getattr(widget, "_assistant_menu_added", False):
            widget._assistant_menu_added = True
            action = widget.menuBar().addMenu("Assistant").addAction("Open Assistant")
            action.triggered.connect(lambda: self._open_assistant(host=widget))
        return widget

    def _open_message_behavior_in_vscode(self, path: Path, line: int = 1):
        if not self._admin_ok():
            return

        def open_behavior(capability):
            open_vscode(
                capability,
                Path(PROJECT_ROOT),
                file_path=Path(path),
                line=max(1, int(line)),
                column=1,
            )

        self._run_vscode_operation(open_behavior)

    def _open_help(self):
        return self._open_singleton(
            "_help_window",
            HelpWindow,
            HELP_PATH,
            phase=self.phase,
            admin_check=self._admin_ok,
        )

    def _open_assistant(self, context="", host=None):
        if is_frozen() or self.phase not in {"baseline", "development"}:
            return
        if not self._admin_ok():
            return
        try:
            from app.assistant.controller import Controller
            controller = getattr(self, "_assistant_controller", None)
            if controller is None:
                controller = Controller(self, PROJECT_ROOT)
                self._assistant_controller = controller
            if isinstance(context, str) and context:
                controller.selection = context
                controller.event.emit("selection", context)
            window = controller.add_view(host or self)
            if isinstance(context, str) and context:
                window.input.setPlainText(f"Explain or help me modify {context}")
            return window
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "Assistant", str(exc))

    def _acquire_communication_hub(self):
        """Create or return the Hub runtime owner without displaying its UI."""
        hub = getattr(self, "_communication_hub", None)
        if hub is not None:
            try:
                return Tools.registry.register("communication", hub)
            except RuntimeError:
                self._communication_hub = None
        from app.tools.communication_hub.widget import CommunicationHubWidget
        hub = CommunicationHubWidget()
        hub.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        hub.destroyed.connect(lambda: setattr(self, "_communication_hub", None))
        self._communication_hub = hub
        # The same retained object owns API-started workers. Opening the tool
        # later calls reattach_ui() and renders their current state.
        hub.detach_ui()
        apply_app_icon(hub)
        return Tools.registry.register("communication", hub)

    def _requested_shutdown_operation(self):
        if bool(getattr(self, "_upgrade_plan_path", "")):
            return "upgrade"
        supervisor_reason = str(
            getattr(self, "_supervisor_shutdown_reason", "") or ""
        ).casefold()
        if getattr(self, "_restarting", False) or supervisor_reason == "restart":
            return "restart"
        return "close"

    def _cancel_pending_close(self):
        # A rejected Restart must not turn the next ordinary window close into
        # a restart request.
        self._restarting = False

    def _begin_shutdown_feedback(self, operation):
        if self._shutdown_feedback_started:
            return
        self._shutdown_feedback_started = True
        self._shutdown_operation = operation
        self._soft_restart_generation = None
        self._soft_restart_error = ""
        self._soft_restart_result_serial += 1
        self._vscode_validation_closing = True
        self.closing.emit(operation)

    def _complete_shutdown_feedback(self):
        if self._shutdown_feedback_finished:
            return
        self._shutdown_feedback_finished = True
        operation = self._shutdown_operation or self._requested_shutdown_operation()
        self.closed.emit(operation)

    def closeEvent(self, event: QtGui.QCloseEvent):
        """Unified confirmation handler for both Close and Restart."""
        self._consume_supervisor_shutdown_request()
        if getattr(self, "_global_shutdown_complete", False):
            self._finalize_close_event(event)
            return
        if getattr(self, "_global_shutdown_in_progress", False):
            event.ignore()
            return
        try:
            restarting = getattr(self, "_restarting", False)
            upgrading = bool(getattr(self, "_upgrade_plan_path", ""))
            supervisor_shutdown = bool(
                getattr(self, "_supervisor_shutdown_requested", False)
            )
            operation = self._requested_shutdown_operation()

            # --- Determine message ---
            msg = f"Are you sure you want to {'restart' if restarting else 'close'} the application?"

            if not upgrading and not supervisor_shutdown:
                reply = QtWidgets.QMessageBox.question(
                    self,
                    f"Confirm {'Restart' if restarting else 'Exit'}",
                    msg,
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No
                )

                if reply == QtWidgets.QMessageBox.No:
                    self._cancel_pending_close()
                    event.ignore()
                    return

            help_window = getattr(self, "_help_window", None)
            if help_window is not None:
                try:
                    help_window._commit_editor_topic()
                    if not help_window.confirm_pending_changes():
                        self._cancel_pending_close()
                        event.ignore()
                        return
                    help_window.close()
                except RuntimeError:
                    self._help_window = None

            assistant = getattr(self, "_assistant_controller", None)
            if assistant is not None:
                assistant.shutdown()

            self._begin_shutdown_feedback(operation)
            self._stop_source_reloads()
            self._start_hard_shutdown_watchdog()
            
            # --- Gracefull shutdown for all other tools ---
            Tools.begin_shutdown()
            tool_attrs = [
                "_variable_explorer_controller",
                "_ftp_server",
                "_ftp_client",
                "_serial_widget",
                "_telnet_widget",
                "_communication_hub",
            ]

            for attr in tool_attrs:
                win = getattr(self, attr, None)
                if win and hasattr(win, "close"):
                    try:
                        if hasattr(win, "prepare_application_shutdown"):
                            win.prepare_application_shutdown()
                        win.close()
                    except Exception as e:
                        print(f"⚠️ Failed to close {attr}: {e}")

            self._global_shutdown_in_progress = True
            event.ignore()

            def finish_global_shutdown():
                self._global_shutdown_in_progress = False
                self._global_shutdown_complete = True
                self._complete_shutdown_feedback()
                self.close()

            self.global_runtime.begin_shutdown(self, finish_global_shutdown)
            return
        except Exception as e:
            print(f"⚠️ CloseEvent error: {e}")
            self._global_shutdown_complete = True
            self._complete_shutdown_feedback()
            self._finalize_close_event(event)

    def _finalize_close_event(self, event: QtGui.QCloseEvent):
        """Perform process exit/restart only after lifecycle cleanup completes."""
        self._complete_shutdown_feedback()
        completion = getattr(self, "_process_exit_complete", None)
        if completion is not None:
            completion.set()
        upgrading = bool(getattr(self, "_upgrade_plan_path", ""))
        restarting = getattr(self, "_restarting", False)
        if upgrading:
            if os.environ.get(SUPERVISED_ENV_VAR) == "1":
                # Protocol messages must bypass the GUI's print redirector.
                print(f"{APP_UPGRADE_MARKER}{self._upgrade_plan_path}",
                      file=sys.__stdout__ or sys.stdout, flush=True)
            event.accept()
            QtWidgets.QApplication.exit(APP_UPGRADE_EXIT_CODE)
            return
        if restarting:
            if os.environ.get(SUPERVISED_ENV_VAR) == "1":
                print(APP_RESTART_MARKER, flush=True)
                event.accept()
                QtWidgets.QApplication.exit(APP_RESTART_EXIT_CODE)
                return
            if is_frozen():
                QtCore.QProcess.startDetached(sys.executable, sys.argv)
            else:
                QtCore.QProcess.startDetached(
                    gui_python_executable(), ["-m", "app.main"])
        event.accept()
        super().closeEvent(event)


def recover_missing_project_files(parent=None):
    """Offer to restore required project files before MainApp reads them."""
    def ask_generate(missing):
        paths = "\n".join(f"  • {path}" for path in missing)
        box = QtWidgets.QMessageBox(parent)
        box.setIcon(QtWidgets.QMessageBox.Warning)
        box.setWindowTitle(f"{SHORT_NAME} Project Recovery")
        box.setText("Required project files are missing.")
        box.setInformativeText(
            f"{FULL_NAME} found:\n\n{paths}\n\n"
            "Generate Defaults creates only the missing files and continues. "
            "Continue Anyway writes nothing and starts with limited or empty "
            "UI/callback behavior; this question will appear again next launch."
        )
        generate = box.addButton("Generate Defaults", QtWidgets.QMessageBox.AcceptRole)
        box.addButton("Continue Anyway", QtWidgets.QMessageBox.DestructiveRole)
        box.setDefaultButton(generate)
        box.exec_()
        return box.clickedButton() is generate

    def warn_degraded(missing):
        paths = "\n".join(f"  • {path}" for path in missing)
        QtWidgets.QMessageBox.warning(
            parent,
            f"{SHORT_NAME} Limited Startup",
            "The application cannot work properly while these files are missing:\n\n"
            f"{paths}\n\nNo files were generated. You will be asked again next launch.",
        )

    return ensure_project_files(PROJECT_ROOT, ask_generate, warn_degraded)

def main():
    multiprocessing.freeze_support()
    configure_hidden_multiprocessing()
    set_windows_app_id()
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
    apply_app_icon()
    recovery_state = recover_missing_project_files()
    if not is_frozen():
        from app.assistant.controller import recover_project
        try:
            recover_project(PROJECT_ROOT)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(None, "Assistant recovery required", str(exc))
            raise

    startup_loader = LifecycleLoaderSession()
    startup_loader.show("starting")
    early_supervisor_lost = threading.Event()
    early_guard_finished = threading.Event()

    try:
        early_supervisor_pid = int(
            os.environ.get(SUPERVISOR_PID_ENV_VAR, "0")
        )
    except (TypeError, ValueError):
        early_supervisor_pid = 0

    if early_supervisor_pid > 0:
        def watch_supervisor_during_startup():
            while not early_guard_finished.wait(0.25):
                if process_is_running(early_supervisor_pid):
                    continue
                early_supervisor_lost.set()
                # MainApp installs its own graceful-shutdown watchdog once its
                # constructor completes.  This fallback also covers a constructor
                # permanently blocked before that point.
                if not early_guard_finished.wait(
                    GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS + 5.0
                ):
                    os._exit(1)
                return

        threading.Thread(
            target=watch_supervisor_during_startup,
            name="designer-startup-supervisor-watcher",
            daemon=True,
        ).start()

    def on_app_ready():
        try:
            win.ready.disconnect(on_app_ready)
            win.initialization_failed.disconnect(on_app_failed)
        except (TypeError, RuntimeError):
            pass
        startup_loader.finish()
        # ✅ Show ONLY after everything is ready
        win.show()
        apply_app_icon(win)

    def on_app_failed(generation, details):
        startup_loader.crashed()
        # Keep the main process alive long enough to display the actionable
        # traceback dialog emitted by ConfigDrivenWindow.
        win.show()

    try:
        win = MainApp(degraded_startup=recovery_state == "degraded")
        configured_icon = QtGui.QIcon(win.icon)
        if not configured_icon.isNull():
            app.setWindowIcon(configured_icon)
            win.setWindowIcon(configured_icon)
        apply_app_icon(win)
        win.ready.connect(on_app_ready)
        win.initialization_failed.connect(on_app_failed)
        if early_supervisor_lost.is_set():
            QtCore.QTimer.singleShot(0, win._handle_supervisor_lost)
        sys.exit(app.exec_())
    except:
        startup_loader.crashed()
        raise
    finally:
        early_guard_finished.set()


if __name__ == '__main__':
    main()
