from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

from app.branding import SHORT_NAME
from app.upgrade_manager import (
    INSTALLED_MANIFEST,
    PACKAGE_FILENAME,
    STATE_DIRNAME,
    atomic_write_json,
    normalized_relative_path,
    read_json_strict,
    sha256_file,
    validate_manifest,
)


def _inside(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _wait_for_pid(pid: int, timeout: float = 30.0) -> None:
    if pid <= 0:
        return
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes

        synchronize = 0x00100000
        wait_object_0 = 0x00000000
        wait_timeout = 0x00000102
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel32.WaitForSingleObject.restype = wintypes.DWORD
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel32.OpenProcess(synchronize, False, pid)
        if not handle:
            return
        try:
            result = kernel32.WaitForSingleObject(handle, int(timeout * 1000))
            if result == wait_timeout:
                raise TimeoutError(f"Timed out waiting for process {pid} to exit.")
            if result != wait_object_0:
                raise OSError(f"Could not wait for process {pid}; Windows result {result}.")
        finally:
            kernel32.CloseHandle(handle)
        return

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.2)
    raise TimeoutError(f"Timed out waiting for process {pid} to exit.")


def _copy_atomic(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".upgrade-tmp")
    shutil.copy2(source, temporary)
    os.replace(temporary, destination)


def _load_json_or_empty(path: Path) -> dict:
    if not path.exists():
        return {}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} does not contain a JSON object")
    return value


def _clean_restart_environment() -> dict[str, str]:
    env = os.environ.copy()
    for key in list(env):
        if key.startswith("_PYI_") or key == "_MEIPASS2":
            env.pop(key, None)
    # Supported by recent PyInstaller versions and harmless for normal Python.
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    return env


def _latest_supervisor_log(project_root: Path) -> Path | None:
    log_root = project_root / "designer" / "logs"
    try:
        candidates = [path for path in log_root.glob("session_*.log") if path.is_file()]
        return max(
            candidates,
            key=lambda path: (path.stat().st_mtime_ns, path.name),
            default=None,
        )
    except OSError:
        return None


def _post_upgrade_restart_command(restart: list, project_root: Path) -> list[str]:
    command = [str(part) for part in restart]
    if "--post-upgrade" not in command:
        command.append("--post-upgrade")
    if "--continue-session-log" not in command:
        previous_log = _latest_supervisor_log(project_root)
        if previous_log:
            command.extend(("--continue-session-log", str(previous_log.resolve())))
    return command


def _merge_config(
    source: Path, destination: Path, replace: bool, fields: list[str] | None = None
) -> None:
    incoming = _load_json_or_empty(source)
    current = _load_json_or_empty(destination)
    installed_phase = (current.get("window") or {}).get("phase", "development")
    if replace:
        result = incoming
    else:
        result = current
        incoming_window = incoming.get("window") or {}
        result_window = result.setdefault("window", {})
        for key in fields or []:
            if key in incoming_window:
                result_window[key] = incoming_window[key]
    result.setdefault("window", {})["phase"] = installed_phase
    atomic_write_json(destination, result)


def apply_upgrade(plan_path: Path) -> dict:
    plan = read_json_strict(plan_path)
    project_root = Path(plan["project_root"]).resolve()
    state_root = project_root / STATE_DIRNAME
    payload_root = Path(plan["payload_root"]).resolve()
    if not _inside(plan_path, state_root / "staging") or not _inside(payload_root, state_root / "staging"):
        raise ValueError("Upgrade staging paths are outside the application state directory.")
    manifest_path = Path(plan["manifest_path"]).resolve()
    if not _inside(manifest_path, payload_root):
        raise ValueError("The staged manifest path is invalid.")
    manifest = read_json_strict(manifest_path)
    validate_manifest(manifest)
    entries = {entry["path"].casefold(): entry for entry in manifest["files"]}

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup_root = state_root / "backups" / f"baseline-{plan['release'].get('baseline_number')}-{timestamp}"
    backup_files = backup_root / "files"
    backup_files.mkdir(parents=True, exist_ok=False)
    old_manifest_path = state_root / INSTALLED_MANIFEST
    if old_manifest_path.is_file():
        shutil.copy2(old_manifest_path, backup_root / "previous-installed-manifest.json")

    touched: list[tuple[Path, Path | None]] = []
    changed: list[str] = []
    try:
        for operation in plan.get("operations", []):
            relative = normalized_relative_path(operation.get("path", ""))
            destination = (project_root / Path(relative)).resolve()
            if not _inside(destination, project_root):
                raise ValueError(f"Unsafe upgrade destination: {relative}")
            backup = backup_files / Path(relative)
            if destination.is_file():
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(destination, backup)
                touched.append((destination, backup))
            elif destination.exists():
                raise ValueError(f"Cannot replace non-file path: {relative}")
            else:
                touched.append((destination, None))

            action = operation.get("action")
            if action == "delete":
                if destination.exists():
                    destination.unlink()
            elif action in {"copy", "copy_config", "merge_config"}:
                source = (payload_root / Path(relative)).resolve()
                if not _inside(source, payload_root) or not source.is_file():
                    raise ValueError(f"Staged source is missing: {relative}")
                entry = entries.get(relative.casefold())
                if entry is None or sha256_file(source) != entry["sha256"]:
                    raise ValueError(f"Staged checksum failed: {relative}")
                if action == "copy":
                    _copy_atomic(source, destination)
                else:
                    _merge_config(
                        source,
                        destination,
                        replace=action == "copy_config",
                        fields=operation.get("fields", []),
                    )
            else:
                raise ValueError(f"Unknown upgrade action: {action}")
            changed.append(relative)

        atomic_write_json(state_root / INSTALLED_MANIFEST, manifest)
        history_path = state_root / "history.json"
        try:
            history = json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else []
        except Exception:
            history = []
        if not isinstance(history, list):
            history = []
        history.append({
            "installed_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "release": plan["release"],
            "changed": changed,
            "preserved": plan.get("preserved", []),
            "backup": str(backup_root),
        })
        atomic_write_json(history_path, history)
        result = {
            "success": True,
            "release": plan["release"],
            "changed": changed,
            "preserved": plan.get("preserved", []),
            "backup": str(backup_root),
        }
    except Exception as exc:
        for destination, backup in reversed(touched):
            try:
                if backup and backup.is_file():
                    _copy_atomic(backup, destination)
                elif destination.is_file():
                    destination.unlink()
            except Exception:
                pass
        previous_manifest = backup_root / "previous-installed-manifest.json"
        if previous_manifest.is_file():
            _copy_atomic(previous_manifest, old_manifest_path)
        elif old_manifest_path.is_file():
            old_manifest_path.unlink()
        result = {
            "success": False,
            "release": plan.get("release", {}),
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "backup": str(backup_root),
        }
    atomic_write_json(state_root / "last-result.json", result)
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description=f"Apply a staged {SHORT_NAME} GUI upgrade"
    )
    parser.add_argument("plan")
    parser.add_argument("--wait-pid", type=int, default=0)
    parser.add_argument("--restart-json", default="[]")
    args = parser.parse_args(argv)
    _wait_for_pid(args.wait_pid)
    try:
        result = apply_upgrade(Path(args.plan).resolve())
    except Exception as exc:
        result = {"success": False, "error": str(exc), "traceback": traceback.format_exc()}
        try:
            plan = read_json_strict(Path(args.plan))
            atomic_write_json(Path(plan["project_root"]) / STATE_DIRNAME / "last-result.json", result)
        except Exception:
            pass
    try:
        restart = json.loads(args.restart_json)
        if isinstance(restart, list) and restart:
            plan = read_json_strict(Path(args.plan).resolve())
            project_root = Path(plan["project_root"]).resolve()
            restart = _post_upgrade_restart_command(restart, project_root)
            creationflags = 0
            if os.name == "nt":
                creationflags = subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NEW_PROCESS_GROUP
            print(f"Launching upgraded supervisor: {restart[0]}", flush=True)
            subprocess.Popen(
                restart,
                cwd=str(project_root),
                env=_clean_restart_environment(),
                close_fds=True,
                creationflags=creationflags,
            )
    except Exception as exc:
        print(f"Automatic restart failed: {exc}", flush=True)
        traceback.print_exc()
        try:
            plan = read_json_strict(Path(args.plan).resolve())
            result["restart_error"] = str(exc)
            atomic_write_json(
                Path(plan["project_root"]) / STATE_DIRNAME / "last-result.json",
                result,
            )
        except Exception:
            pass
    return 0 if result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main())
