# app/print_redirector.py
import sys, time
import threading

class PrintRedirector:
    """
    Thread-safe redirector for stdout/stderr -> InfoWidget targets.
    """

    def __init__(self, info_registry):
        self.info_registry = info_registry
        self.installed = False
        self._lock = threading.Lock()
        self._routes = {}          # tab_index -> instance_name
        self._active_tab = 0
        self._stdout = sys.stdout
        self._stderr = sys.stderr
        self.info_registry._print_redirector = self
        self._buffer = ""
        self._last_write_ts = 0.0
        self._flush_interval = 0.05  # 50 ms


    # ----------------------------------------
    def install(self):
        sys.stdout = self
        sys.stderr = self
        self.installed = True

    def uninstall(self):
        sys.stdout = self._stdout
        sys.stderr = self._stderr
        self.installed = False

    # ----------------------------------------
    def set_active_tab(self, index):
        self._active_tab = index

    def route(self, tab_index, instance_name):
        self._routes[int(tab_index)] = instance_name

    # ----------------------------------------
    def write(self, text):
        if not text:
            return

        now = time.monotonic()

        with self._lock:
            self._buffer += text
            self._last_write_ts = now

            # 1️⃣ newline-based flush
            while "\n" in self._buffer:
                line, self._buffer = self._buffer.split("\n", 1)
                self._emit(line)

            # 2️⃣ carriage return → immediate emit
            if "\r" in self._buffer:
                parts = self._buffer.split("\r")
                self._buffer = parts[-1]
                self._emit(parts[-2])

            # 3️⃣ time-based flush for end=""
            if self._buffer and (now - self._last_write_ts) >= self._flush_interval:
                self._emit(self._buffer)
                self._buffer = ""


    def _emit(self, text):
        inst = self._routes.get(self._active_tab)
        if not inst:
            return

        w = self.info_registry._get(inst)
        if not w:
            return

        w.invoke_safe(
            "set_text",
            text,
            False,
            True,
            "print"
        )

    def flush(self):
        with self._lock:
            if self._buffer:
                self._emit(self._buffer)
                self._buffer = ""
