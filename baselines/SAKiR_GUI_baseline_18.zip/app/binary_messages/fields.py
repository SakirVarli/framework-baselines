from __future__ import annotations

from dataclasses import MISSING, Field, field
from typing import Any, Callable


BINARY_METADATA_KEY = "binary_message"


def runtime_field(
    *,
    default: Any = MISSING,
    default_factory: Callable[[], Any] | Any = MISSING,
    init: bool = True,
    repr: bool = True,
    compare: bool = False,
    kw_only: bool = False,
) -> Field[Any]:
    """Declare dataclass state that is not part of the binary representation."""
    options: dict[str, Any] = {
        "init": init,
        "repr": repr,
        "compare": compare,
        "kw_only": kw_only,
        "metadata": {BINARY_METADATA_KEY: {"serialized": False}},
    }
    if default is not MISSING:
        options["default"] = default
    if default_factory is not MISSING:
        options["default_factory"] = default_factory
    return field(**options)


def wire_field(
    *,
    name: str | None = None,
    default: Any = MISSING,
    default_factory: Callable[[], Any] | Any = MISSING,
    init: bool = True,
    repr: bool = True,
    compare: bool = True,
    kw_only: bool = False,
) -> Field[Any]:
    """Declare a serialized dataclass field with an optional wire-side name."""
    options: dict[str, Any] = {
        "init": init,
        "repr": repr,
        "compare": compare,
        "kw_only": kw_only,
        "metadata": {
            BINARY_METADATA_KEY: {
                "serialized": True,
                "name": name,
            }
        },
    }
    if default is not MISSING:
        options["default"] = default
    if default_factory is not MISSING:
        options["default_factory"] = default_factory
    return field(**options)


def field_options(dataclass_field: Field[Any]) -> tuple[bool, str]:
    metadata = dataclass_field.metadata.get(BINARY_METADATA_KEY, {})
    serialized = bool(metadata.get("serialized", True))
    wire_name = metadata.get("name") or dataclass_field.name
    return serialized, wire_name
