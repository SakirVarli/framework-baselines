from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class MessageSendSession(Protocol):
    """Structural contract for a running Communication Hub session."""

    @property
    def running(self) -> bool:
        """Whether the session is currently able to send data."""

    def send(self, data: bytes, *, target: str = "") -> Any:
        """Send encoded message bytes and return the session result."""
