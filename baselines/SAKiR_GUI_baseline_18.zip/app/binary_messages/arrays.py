"""Strict array boundaries and bounded object initialization for generated schemas."""
from __future__ import annotations

from dataclasses import dataclass, fields, is_dataclass
from io import BytesIO

from construct import Construct, Container, EnumIntegerString, ListContainer, RangeError, SizeofError, evaluate
from construct.core import stream_read, stream_write, stream_tell
from .fields import field_options


class DefaultBudgetExceeded(ValueError):
    pass


AUTO_ARRAY = object()


@dataclass(frozen=True)
class IndexedSwitch:
    types: dict[int, object]

    def __hash__(self):
        return hash(tuple(sorted(self.types.items())))


class _PayloadBuffer(BytesIO):
    def __init__(self, maximum, path):
        super().__init__()
        self.maximum, self.path = maximum, path
        self.exceeded = False

    def write(self, data):
        if self.maximum is not None and self.tell() + len(data) > self.maximum:
            self.exceeded = True
            raise RangeError(f'array payload exceeds maximum {self.maximum} bytes', path=self.path)
        return super().write(data)


class ArrayCodec(Construct):
    """A repetition codec with explicit boundaries, progress checks, and item limits.

    Unlike GreedyRange, a bounded byte payload cannot hide a truncated final item.
    The surrounding context is preserved, including for prefixed arrays.
    """

    def __init__(self, item, *, mode, count=None, prefix=None, predicate=None,
                 minimum=0, maximum=None, max_bytes=None):
        super().__init__()
        if mode not in {'fixed', 'count_field', 'count_expression', 'prefixed', 'greedy', 'byte_prefixed', 'byte_field', 'byte_expression', 'repeat_until'}:
            raise ValueError('unsupported array mode')
        if type(minimum) is not int or minimum < 0 or maximum is not None and (type(maximum) is not int or maximum < minimum):
            raise ValueError('invalid array item limits')
        if max_bytes is not None and (type(max_bytes) is not int or max_bytes < 0):
            raise ValueError('invalid array byte limit')
        self.item, self.mode, self.count = item, mode, count
        self.prefix, self.predicate = prefix, predicate
        self.minimum, self.maximum = minimum, maximum
        self.max_bytes = max_bytes

    def _check_count(self, count, path):
        if type(count) is not int or count < 0:
            raise RangeError(f"array count/length must be a nonnegative integer, found {count!r}", path=path)
        if self.maximum is not None and count > self.maximum:
            raise RangeError(f"array exceeds maximum {self.maximum} items", path=path)
        if count < self.minimum:
            raise RangeError(f"array requires at least {self.minimum} items", path=path)

    def _parse(self, stream, context, path):
        mode = self.mode
        count = evaluate(self.count, context) if self.count is not None else None
        if mode == "prefixed":
            count = self.prefix._parsereport(stream, context, path)
        if mode in {"byte_prefixed", "byte_field", "byte_expression"}:
            length = self.prefix._parsereport(stream, context, path) if mode == "byte_prefixed" else count
            if type(length) is not int or length < 0:
                raise RangeError("byte length must be a nonnegative integer", path=path)
            if self.max_bytes is not None and length > self.max_bytes:
                raise RangeError(f'array payload exceeds maximum {self.max_bytes} bytes', path=path)
            stream = BytesIO(stream_read(stream, length, path))
            count = None
        if mode in {"fixed", "count_field", "count_expression", "prefixed"}:
            self._check_count(count, path)
        result = ListContainer()
        previous_index = context.get("_index", AUTO_ARRAY)
        try:
            while count is None or len(result) < count:
                if count is None and mode != "repeat_until":
                    position = stream_tell(stream, path)
                    if not stream.read(1):
                        break
                    stream.seek(position)
                if self.maximum is not None and len(result) >= self.maximum:
                    raise RangeError(f"array exceeds maximum {self.maximum} items", path=path)
                context._index = len(result)
                start = stream_tell(stream, path)
                value = self.item._parsereport(stream, context, path + f"[{len(result)}]")
                result.append(value)
                if mode == "repeat_until" and self.predicate(value, result, context):
                    break
                if count is None and stream_tell(stream, path) == start:
                    raise RangeError("repeated item consumed no bytes", path=path)
        finally:
            if previous_index is AUTO_ARRAY:
                context.pop("_index", None)
            else:
                context._index = previous_index
        self._check_count(len(result), path)
        return result

    def _build(self, obj, stream, context, path):
        self._check_count(len(obj), path)
        count = evaluate(self.count, context) if self.count is not None else None
        if self.mode in {'fixed', 'count_field', 'count_expression'}:
            self._check_count(count, path)
        if self.mode in {"fixed", "count_field", "count_expression"} and len(obj) != count:
            raise RangeError(f"expected {count} items, found {len(obj)}", path=path)
        payload = _PayloadBuffer(self.max_bytes, path)
        result = ListContainer()
        previous_index = context.get("_index", AUTO_ARRAY)
        try:
            for index, value in enumerate(obj):
                context._index = index
                start = payload.tell()
                try:
                    built = self.item._build(value, payload, context, path + f"[{index}]")
                except Exception as error:
                    if payload.exceeded:
                        raise RangeError(f'array payload exceeds maximum {self.max_bytes} bytes', path=path) from error
                    raise
                result.append(built)
                if self.mode == "repeat_until" and self.predicate(built, result, context):
                    if index != len(obj) - 1:
                        raise RangeError("items follow the terminating array item", path=path)
                    break
                if self.mode in {'greedy', 'byte_prefixed', 'byte_field', 'byte_expression', 'repeat_until'} and payload.tell() == start:
                    raise RangeError('repeated item produced no bytes', path=path)
            else:
                if self.mode == "repeat_until":
                    raise RangeError("array has no terminating item", path=path)
        finally:
            if previous_index is AUTO_ARRAY:
                context.pop("_index", None)
            else:
                context._index = previous_index
        data = payload.getvalue()
        if self.max_bytes is not None and len(data) > self.max_bytes:
            raise RangeError(f'array payload exceeds maximum {self.max_bytes} bytes', path=path)
        if self.mode == "prefixed":
            self.prefix._build(len(obj), stream, context, path)
        elif self.mode == "byte_prefixed":
            self.prefix._build(len(data), stream, context, path)
        elif self.mode in {"byte_field", "byte_expression"} and len(data) != count:
            raise RangeError(f"expected {count} payload bytes, found {len(data)}", path=path)
        stream_write(stream, data, len(data), path)
        return result

    def _sizeof(self, context, path):
        if self.mode in {"fixed", "count_field", "count_expression"}:
            return evaluate(self.count, context) * self.item._sizeof(context, path)
        if self.mode in {"byte_field", "byte_expression"}:
            return evaluate(self.count, context)
        raise SizeofError("variable array size", path=path)


def _context_value(value):
    if is_dataclass(value):
        return Container({field.name: _context_value(getattr(value, field.name)) for field in fields(value) if field_options(field)[0]})
    if isinstance(value, list):
        return [_context_value(item) for item in value]
    return value


def initialize_arrays(message, *, budget=10000, defer_ancestor=False):
    """Resolve automatic arrays after all constructor arguments are available.

    Only missing array values are assigned. Explicit lists and caller-supplied
    counts are preserved. Structures get parent scopes; array items share scope.
    """
    remaining = [budget]

    def array(value, spec, context, path):
        if value is AUTO_ARRAY:
            try:
                count = evaluate(spec["count"], context)
            except (KeyError, AttributeError):
                if defer_ancestor:
                    return value
                raise
            if isinstance(count, EnumIntegerString):
                count = int(count)
            if type(count) is not int or count < 0:
                raise ValueError(f"{path}: initial item count must be a nonnegative integer")
            if count > remaining[0]:
                raise DefaultBudgetExceeded(f"{path}: automatic initialization exceeds {budget} items; supply explicit values")
            remaining[0] -= count
            value = [spec["factory"]() for _ in range(count)]
            if spec.get("sentinel", AUTO_ARRAY) is not AUTO_ARRAY and count:
                value[-1] = spec["sentinel"]
        if isinstance(value, list):
            for index, item in enumerate(value):
                child_context = Container(context)
                child_context._index = index
                value[index] = visit(item, spec.get("item"), child_context, f"{path}[{index}]")
        return value

    def visit(value, spec, parent, path):
        if spec and spec.get("kind") == "array":
            return array(value, spec, parent, path)
        if is_dataclass(value):
            context = _context_value(value)
            context._ = parent
            context._root = parent.get("_root", context) if parent else context
            specs = getattr(type(value), "_ARRAY_INITIALIZERS", {})
            for field in fields(value):
                if not field_options(field)[0]:
                    continue
                current = getattr(value, field.name)
                updated = visit(current, specs.get(field.name), context, f"{path}.{field.name}")
                if updated is not current:
                    setattr(value, field.name, updated)
                context[field.name] = _context_value(updated)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                value[index] = visit(item, None, parent, f"{path}[{index}]")
        return value

    return visit(message, None, Container(), type(message).__name__)
