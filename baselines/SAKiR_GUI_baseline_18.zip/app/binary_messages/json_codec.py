from __future__ import annotations

import json
import math
from enum import Enum
from construct import EnumInteger, EnumIntegerString
from pathlib import Path
from typing import Any, Mapping

from .errors import MessageJsonError


_TAG = "__binary_message_type__"


def to_json_value(value: Any) -> Any:
    if isinstance(value, (EnumInteger, EnumIntegerString)):
        return int(value)
    if isinstance(value, bytes):
        return {_TAG: "bytes", "hex": value.hex()}
    if isinstance(value, bytearray):
        return {_TAG: "bytes", "hex": bytes(value).hex()}
    if isinstance(value, memoryview):
        return {_TAG: "bytes", "hex": value.tobytes().hex()}
    if isinstance(value, Enum):
        return to_json_value(value.value)
    if isinstance(value, float):
        if math.isnan(value):
            return {_TAG: "float", "value": "nan"}
        if math.isinf(value):
            return {_TAG: "float", "value": "inf" if value > 0 else "-inf"}
        return value
    if isinstance(value, Mapping):
        return {str(key): to_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [to_json_value(item) for item in value]

    value_type = type(value)
    if value_type.__module__.startswith("numpy") and hasattr(value, "item"):
        return to_json_value(value.item())
    return value


def from_json_value(value: Any) -> Any:
    if isinstance(value, list):
        return [from_json_value(item) for item in value]
    if not isinstance(value, dict):
        return value

    tag = value.get(_TAG)
    if tag == "bytes" and set(value) == {_TAG, "hex"}:
        try:
            return bytes.fromhex(value["hex"])
        except (TypeError, ValueError) as error:
            raise MessageJsonError("Invalid tagged byte value") from error
    if tag == "float" and set(value) == {_TAG, "value"}:
        special = value["value"]
        if special == "nan":
            return float("nan")
        if special == "inf":
            return float("inf")
        if special == "-inf":
            return float("-inf")
        raise MessageJsonError(f"Invalid tagged float value: {special!r}")

    return {key: from_json_value(item) for key, item in value.items()}


def dumps(value: Any, *, indent: int | None = 2) -> str:
    try:
        return json.dumps(
            to_json_value(value),
            indent=indent,
            allow_nan=False,
            ensure_ascii=False,
        )
    except (TypeError, ValueError) as error:
        raise MessageJsonError(f"Could not encode JSON: {error}") from error


def loads(text: str) -> Any:
    try:
        return from_json_value(json.loads(text))
    except MessageJsonError:
        raise
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise MessageJsonError(f"Could not decode JSON: {error}") from error


def dump_file(value: Any, path: str | Path, *, indent: int | None = 2) -> None:
    Path(path).write_text(dumps(value, indent=indent), encoding="utf-8")


def load_file(path: str | Path) -> Any:
    return loads(Path(path).read_text(encoding="utf-8"))
