from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from .base import BinaryMessage
from .errors import (
    DispatcherConfigurationError,
    AmbiguousMessageIdError,
    DuplicateMessageIdError,
    UnknownMessageIdError,
    AmbiguousGroupError,
    AmbiguousMessageIdentityError,
    InsufficientRoutingDataError,
    RoutingConfigurationError,
    UnknownGroupError,
    UnknownMessageIdentityError,
)
from .identity import Direction


@dataclass(frozen=True, slots=True)
class FixedIdExtractor:
    offset: int
    width: int
    byteorder: str = "big"
    mask: int | None = None
    shift: int = 0

    def __post_init__(self) -> None:
        if self.offset < 0:
            raise DispatcherConfigurationError("ID offset cannot be negative")
        if self.width not in {1, 2, 3, 4, 8}:
            raise DispatcherConfigurationError("ID width must be 1, 2, 3, 4, or 8")
        if self.byteorder not in {"big", "little"}:
            raise DispatcherConfigurationError("ID byte order must be big or little")
        if self.shift < 0:
            raise DispatcherConfigurationError("ID shift cannot be negative")
        if self.mask is not None and self.mask < 0:
            raise DispatcherConfigurationError("ID mask cannot be negative")

    def extract(self, data: bytes | bytearray | memoryview) -> int:
        view = memoryview(data)
        end = self.offset + self.width
        if len(view) < end:
            raise DispatcherConfigurationError(
                f"Need {end} bytes to extract the message ID; received {len(view)}"
            )
        value = int.from_bytes(view[self.offset:end], self.byteorder, signed=False)
        if self.mask is not None:
            value &= self.mask
        return value >> self.shift


@dataclass(frozen=True, slots=True)
class RoutingProbe:
    """One unsigned value read from an absolute byte location."""

    name: str
    offset: int
    width: int
    expected: int
    byteorder: str = "big"
    mask: int | None = None
    shift: int = 0

    def __post_init__(self) -> None:
        if not self.name or not self.name.isidentifier():
            raise RoutingConfigurationError("Routing probe names must be Python identifiers")
        FixedIdExtractor(self.offset, self.width, self.byteorder, self.mask, self.shift)
        if not isinstance(self.expected, int) or isinstance(self.expected, bool) or self.expected < 0:
            raise RoutingConfigurationError(f"Expected value for {self.name} must be a non-negative integer")

    def extract(self, data: bytes | bytearray | memoryview) -> int:
        try:
            return FixedIdExtractor(
                self.offset, self.width, self.byteorder, self.mask, self.shift,
            ).extract(data)
        except DispatcherConfigurationError as error:
            raise InsufficientRoutingDataError(str(error)) from error


@dataclass(frozen=True, slots=True)
class RoutingSignature:
    probes: tuple[RoutingProbe, ...]

    def __post_init__(self) -> None:
        if not self.probes:
            raise RoutingConfigurationError("A routing signature must contain at least one probe")
        names = [probe.name for probe in self.probes]
        if len(names) != len(set(names)):
            raise RoutingConfigurationError("Routing probe names must be unique inside a signature")

    def values(self, data: bytes | bytearray | memoryview) -> dict[str, int]:
        return {probe.name: probe.extract(data) for probe in self.probes}

    def matches(self, data: bytes | bytearray | memoryview) -> tuple[bool, dict[str, int]]:
        values = self.values(data)
        return all(values[probe.name] == probe.expected for probe in self.probes), values


@dataclass(frozen=True, slots=True)
class RoutedMessage:
    message_type: type[BinaryMessage]
    signatures: tuple[RoutingSignature, ...]


@dataclass(frozen=True, slots=True)
class MessageGroup:
    uid: str
    name: str
    signatures: tuple[RoutingSignature, ...]
    messages: tuple[RoutedMessage, ...]
    groups: tuple["MessageGroup", ...] = ()


@dataclass(frozen=True, slots=True)
class MessageMatch:
    group: MessageGroup
    message_type: type[BinaryMessage]
    group_values: Mapping[str, int]
    message_values: Mapping[str, int]
    group_path: tuple[MessageGroup, ...] = ()
    group_value_path: tuple[Mapping[str, int], ...] = ()


class MessageRegistry:
    def __init__(
        self,
        message_types: Iterable[type[BinaryMessage]] = (),
        *,
        extractor: FixedIdExtractor | None = None,
    ) -> None:
        by_key: dict[tuple[int, Direction], type[BinaryMessage]] = {}
        id_groups: dict[int, list[type[BinaryMessage]]] = {}
        by_name: dict[str, type[BinaryMessage]] = {}
        for message_type in message_types:
            if not isinstance(message_type, type) or not issubclass(message_type, BinaryMessage):
                raise TypeError("Registry entries must be BinaryMessage classes")
            message_id = message_type.MESSAGE_ID
            if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id < 0:
                raise ValueError(f"{message_type.__name__}.MESSAGE_ID must be a non-negative integer")
            raw_direction = (
                message_type.__dict__["DIRECTION"] if "DIRECTION" in message_type.__dict__
                else message_type.__dict__.get("TX_RX", Direction.ANY)
            )
            direction = Direction.normalize(raw_direction)
            key = (message_id, direction)
            existing_directions = {direction for registered_id, direction in by_key if registered_id == message_id}
            if key in by_key:
                raise DuplicateMessageIdError(
                    f"Message identity ({message_id}, {direction.value}) is used by both "
                    f"{by_key[key].__name__} and {message_type.__name__}"
                )
            if existing_directions and (direction == Direction.ANY or Direction.ANY in existing_directions):
                raise DuplicateMessageIdError(
                    f"Message ID {message_id} cannot combine direction ANY with TX or RX"
                )
            name = message_type.MESSAGE_NAME or message_type.__name__
            if name in by_name:
                raise ValueError(f"Duplicate message name: {name}")
            by_key[key] = message_type
            id_groups.setdefault(message_id, []).append(message_type)
            by_name[name] = message_type
        self._by_key = MappingProxyType(by_key)
        self._by_id = MappingProxyType({key: values[0] for key, values in id_groups.items() if len(values) == 1})
        self._by_name = MappingProxyType(by_name)
        self.extractor = extractor

    @property
    def by_id(self) -> Mapping[int, type[BinaryMessage]]:
        return self._by_id

    @property
    def by_name(self) -> Mapping[str, type[BinaryMessage]]:
        return self._by_name

    @property
    def by_key(self) -> Mapping[tuple[int, Direction], type[BinaryMessage]]:
        return self._by_key

    def get_message_type(self, message_id: int, direction: Direction | str | None = None, **legacy: Any) -> type[BinaryMessage]:
        direction = Direction.normalize(_with_legacy_direction(direction, legacy))
        if legacy:
            raise TypeError("Unexpected lookup options: " + ", ".join(sorted(legacy)))
        if direction is not None:
            message_type = self._by_key.get((message_id, direction)) or self._by_key.get((message_id, Direction.ANY))
            if message_type is None:
                raise UnknownMessageIdError(f"Unknown message identity: ({message_id}, {direction.value})")
            return message_type
        candidates = [message_type for (registered_id, _), message_type in self._by_key.items() if registered_id == message_id]
        if not candidates:
            raise UnknownMessageIdError(f"Unknown message ID: {message_id}")
        if len(candidates) > 1:
            raise AmbiguousMessageIdError(f"Message ID {message_id} has TX and RX definitions; provide direction")
        return candidates[0]

    def decode(
        self,
        message_id: int,
        data: bytes | bytearray | memoryview,
        *,
        direction: Direction | str | None = None,
        **context: Any,
    ) -> BinaryMessage:
        direction = _with_legacy_direction(direction, context)
        return self.get_message_type(message_id, direction).decode(data, **context)

    def decode_auto(
        self,
        data: bytes | bytearray | memoryview,
        *,
        direction: Direction | str | None = None,
        **context: Any,
    ) -> BinaryMessage:
        if self.extractor is None:
            raise DispatcherConfigurationError("No automatic message-ID extractor is configured")
        direction = _with_legacy_direction(direction, context)
        return self.decode(self.extractor.extract(data), data, direction=direction, **context)


class RoutingRegistry:
    """Identify messages through wire routing without numeric class IDs."""

    def __init__(self, message_types=(), *, groups: Iterable[MessageGroup]):
        message_types = tuple(message_types)
        by_name: dict[str, type[BinaryMessage]] = {}
        for message_type in message_types:
            if not isinstance(message_type, type) or not issubclass(message_type, BinaryMessage):
                raise TypeError("Registry entries must be BinaryMessage classes")
            Direction.normalize(message_type.__dict__.get("DIRECTION", Direction.ANY))
            name = message_type.MESSAGE_NAME or message_type.__name__
            if name in by_name:
                raise ValueError(f"Duplicate message name: {name}")
            by_name[name] = message_type
        self._message_types = message_types
        self._by_name = MappingProxyType(by_name)
        self.groups = tuple(groups)
        if not self.groups:
            raise RoutingConfigurationError("At least one message group is required")
        if len({group.uid for group in self.groups}) != len(self.groups):
            raise RoutingConfigurationError("Message group UIDs must be unique")
        if len({group.name for group in self.groups}) != len(self.groups):
            raise RoutingConfigurationError("Message group names must be unique")
        registered = set(message_types)
        routed = [route.message_type for group in self.groups for route in self._walk_messages(group)]
        if set(routed) != registered or len(routed) != len(registered):
            raise RoutingConfigurationError("Every registered message must occur in exactly one group")
        all_groups = [item for group in self.groups for item in self._walk_groups(group)]
        if len({group.uid for group in all_groups}) != len(all_groups):
            raise RoutingConfigurationError("Message group UIDs must be unique across the hierarchy")
        if len({group.name for group in all_groups}) != len(all_groups):
            raise RoutingConfigurationError("Message group names must be unique across the hierarchy")
        self.groups_by_name = MappingProxyType({group.name: group for group in all_groups})
        self.groups_by_uid = MappingProxyType({group.uid: group for group in all_groups})

    @property
    def by_name(self) -> Mapping[str, type[BinaryMessage]]:
        return self._by_name

    def identify_group(self, data: bytes | bytearray | memoryview) -> tuple[MessageGroup, Mapping[str, int]]:
        if len(self.groups) == 1 and not self.groups[0].signatures:
            return self.groups[0], MappingProxyType({})
        matches: list[tuple[MessageGroup, dict[str, int]]] = []
        insufficient: list[InsufficientRoutingDataError] = []
        for group in self.groups:
            for signature in group.signatures:
                try:
                    matched, values = signature.matches(data)
                except InsufficientRoutingDataError as error:
                    insufficient.append(error); continue
                if matched:
                    matches.append((group, values)); break
        if not matches:
            if insufficient and len(insufficient) == sum(len(group.signatures) for group in self.groups):
                raise insufficient[0]
            raise UnknownGroupError("No message group routing signature matched the input")
        if len(matches) > 1:
            raise AmbiguousGroupError(
                "Multiple message groups matched: " + ", ".join(group.name for group, _ in matches)
            )
        group, values = matches[0]
        return group, MappingProxyType(values)

    def identify_message(
        self, data: bytes | bytearray | memoryview, *,
        direction: Direction | str | None = None,
    ) -> MessageMatch:
        normalized = Direction.normalize(direction)
        group, group_values = self.identify_group(data)
        return self._identify_in_group(
            group, data, normalized,
            (group,), (group_values,), dict(group_values),
        )

    def _identify_in_group(self, group, data, normalized, path, value_path, combined_values):
        matches: list[tuple[RoutedMessage, dict[str, int]]] = []
        group_matches: list[tuple[MessageGroup, dict[str, int]]] = []
        insufficient: list[InsufficientRoutingDataError] = []
        for child in group.groups:
            for signature in child.signatures:
                try:
                    matched, values = signature.matches(data)
                except InsufficientRoutingDataError as error:
                    insufficient.append(error); continue
                if matched:
                    group_matches.append((child, values)); break
        for route in group.messages:
            route_direction = Direction.normalize(
                route.message_type.__dict__.get("DIRECTION", route.message_type.__dict__.get("TX_RX", Direction.ANY))
            )
            if normalized is not None and route_direction not in {normalized, Direction.ANY}:
                continue
            for signature in route.signatures:
                try:
                    matched, values = signature.matches(data)
                except InsufficientRoutingDataError as error:
                    insufficient.append(error); continue
                if matched:
                    matches.append((route, values)); break
        candidate_count = sum(len(child.signatures) for child in group.groups) + sum(
            len(route.signatures) for route in group.messages
        )
        if not matches and not group_matches:
            if insufficient and len(insufficient) >= candidate_count:
                raise insufficient[0]
            raise UnknownMessageIdentityError(f"No message identity matched in group {group.name}")
        if len(matches) + len(group_matches) > 1:
            names = [route.message_type.__name__ for route, _ in matches]
            names.extend(child.name for child, _ in group_matches)
            raise AmbiguousMessageIdentityError(
                f"Multiple children matched in group {group.name}: {', '.join(names)}"
                + ("; provide direction" if normalized is None else "")
            )
        if group_matches:
            child, values = group_matches[0]
            merged = dict(combined_values); merged.update(values)
            immutable = MappingProxyType(values)
            return self._identify_in_group(
                child, data, normalized, (*path, child), (*value_path, immutable), merged,
            )
        route, values = matches[0]
        return MessageMatch(
            group, route.message_type, MappingProxyType(combined_values), MappingProxyType(values),
            path, value_path,
        )

    def decode_auto(self, data, *, direction=None, **context):
        direction = _with_legacy_direction(direction, context)
        return self.identify_message(data, direction=direction).message_type.decode(data, **context)

    @classmethod
    def _walk_groups(cls, group):
        yield group
        for child in group.groups:
            yield from cls._walk_groups(child)

    @classmethod
    def _walk_messages(cls, group):
        yield from group.messages
        for child in group.groups:
            yield from cls._walk_messages(child)


class HierarchicalMessageRegistry(RoutingRegistry, MessageRegistry):
    """Legacy wire router with additional numeric-ID lookup support."""

    def __init__(self, message_types=(), *, groups: Iterable[MessageGroup], extractor=None):
        super().__init__(message_types, groups=groups)
        id_groups: dict[int, list[type[BinaryMessage]]] = {}
        key_groups: dict[tuple[int, Direction], list[type[BinaryMessage]]] = {}
        for message_type in self._message_types:
            message_id = message_type.MESSAGE_ID
            if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id < 0:
                raise ValueError(f"{message_type.__name__}.MESSAGE_ID must be a non-negative integer")
            direction = Direction.normalize(message_type.__dict__.get("DIRECTION", Direction.ANY))
            id_groups.setdefault(message_id, []).append(message_type)
            key_groups.setdefault((message_id, direction), []).append(message_type)
        self._by_id = MappingProxyType({key: values[0] for key, values in id_groups.items() if len(values) == 1})
        self._by_key = MappingProxyType({key: values[0] for key, values in key_groups.items() if len(values) == 1})
        self.extractor = extractor

    def get_message_type(self, message_id: int, direction: Direction | str | None = None, **legacy):
        direction = Direction.normalize(_with_legacy_direction(direction, legacy))
        if legacy:
            raise TypeError("Unexpected lookup options: " + ", ".join(sorted(legacy)))
        candidates = [message_type for message_type in self._message_types if message_type.MESSAGE_ID == message_id]
        if direction is not None:
            candidates = [
                message_type for message_type in candidates
                if Direction.normalize(message_type.__dict__.get("DIRECTION", Direction.ANY)) in {direction, Direction.ANY}
            ]
        if not candidates:
            raise UnknownMessageIdError(f"Unknown message ID: {message_id}")
        if len(candidates) > 1:
            raise AmbiguousMessageIdError(
                f"Message ID {message_id} identifies multiple routed messages; use decode_auto or provide a full identity"
            )
        return candidates[0]


def _with_legacy_direction(direction, values):
    legacy = values.pop("tx_rx", None)
    if direction is not None and legacy is not None:
        raise TypeError("Provide direction, not both direction and legacy tx_rx")
    return direction if direction is not None else legacy
