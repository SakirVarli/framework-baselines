from __future__ import annotations

from enum import Enum


class Direction(str, Enum):
    """Direction metadata used as the second half of a message registry key."""

    TX = "TX"
    RX = "RX"
    ANY = "ANY"

    @classmethod
    def normalize(cls, value: "Direction | str | None") -> "Direction | None":
        if value is None:
            return None
        if isinstance(value, cls):
            return value
        try:
            return cls(str(value).upper())
        except ValueError as error:
            raise ValueError("direction must be 'TX', 'RX', or 'ANY'") from error


# Compatibility for libraries generated before the Direction rename.
TxRx = Direction
