"""Typed, Construct-backed binary message models."""

from .compiled_routing import CompiledRoutingRegistry, GroupDecoder, Identifier
from .base import BinaryMessage
from .conversion import dataclass_from_mapping, dataclass_to_mapping
from .errors import (
    BinaryMessageError,
    MessageDecodeError,
    MessageDefinitionError,
    MessageEncodeError,
    MessageJsonError,
    MessageSendError,
    DispatcherConfigurationError,
    AmbiguousMessageIdError,
    DuplicateMessageIdError,
    UnknownMessageIdError,
    AmbiguousGroupError,
    AmbiguousMessageIdentityError,
    InsufficientRoutingDataError,
    RoutingConfigurationError,
    UnknownGroupError,
    UnknownMessageIdentityError,
)
from .identity import Direction, TxRx
from .fields import runtime_field, wire_field
from .json_codec import from_json_value, to_json_value
from .registry import (
    FixedIdExtractor, HierarchicalMessageRegistry, MessageGroup, MessageMatch,
    MessageRegistry, RoutedMessage, RoutingProbe, RoutingSignature, RoutingRegistry,
)
from .sending import MessageSendSession

__all__ = [
    "BinaryMessage",
    "CompiledRoutingRegistry",
    "GroupDecoder",
    "Identifier",
    "BinaryMessageError",
    "AmbiguousMessageIdError",
    "AmbiguousGroupError",
    "AmbiguousMessageIdentityError",
    "MessageDecodeError",
    "MessageDefinitionError",
    "DispatcherConfigurationError",
    "DuplicateMessageIdError",
    "MessageEncodeError",
    "MessageJsonError",
    "MessageSendError",
    "MessageSendSession",
    "FixedIdExtractor",
    "HierarchicalMessageRegistry",
    "InsufficientRoutingDataError",
    "MessageGroup",
    "MessageMatch",
    "MessageRegistry",
    "RoutedMessage",
    "RoutingConfigurationError",
    "RoutingProbe",
    "RoutingRegistry",
    "RoutingSignature",
    "Direction",
    "TxRx",
    "UnknownMessageIdError",
    "UnknownGroupError",
    "UnknownMessageIdentityError",
    "dataclass_from_mapping",
    "dataclass_to_mapping",
    "from_json_value",
    "runtime_field",
    "to_json_value",
    "wire_field",
]
