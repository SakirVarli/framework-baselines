from __future__ import annotations

import struct
from dataclasses import dataclass
from types import MappingProxyType

from .errors import (AmbiguousMessageIdentityError, InsufficientRoutingDataError,
                     RoutingConfigurationError, UnknownGroupError, UnknownMessageIdentityError)
from .identity import Direction


@dataclass(frozen=True)
class Identifier:
    uid: str
    name: str
    offset: int = 0
    length: int = 1
    type: str = "uint"
    byteorder: str = "big"
    encoding: str = "utf-8"
    padding: str = "00"
    mask: int | None = None
    shift: int = 0
    enum_values: tuple = ()
    signed: bool = False

    def __post_init__(self):
        if type(self.signed) is not bool or (self.signed and self.type not in {'int', 'enum'}):
            raise ValueError('Signed storage is only available for integer or enum identifiers')
        if not self.uid or not self.name:
            raise ValueError("Identifiers need a stable ID and a name")
        if type(self.offset) is not int or self.offset < 0 or type(self.length) is not int or self.length <= 0:
            raise ValueError("Identifier offsets must be non-negative and lengths must be positive byte counts")
        if self.type not in {"uint", "int", "enum", "bool", "bytes", "text", "float"}:
            raise ValueError("Unsupported identifier type: " + self.type)
        if self.byteorder not in {"big", "little"}:
            raise ValueError("Endianness must be big or little")
        if self.type == "float" and self.length not in {4, 8}:
            raise ValueError("Floating-point identifiers require 4 or 8 bytes")
        if self.type == "bool" and self.length != 1:
            raise ValueError("Boolean identifiers require 1 byte")
        if self.type == "text":
            "".encode(self.encoding)
            if len(bytes.fromhex(self.padding)) != 1:
                raise ValueError("Text padding must be exactly one byte in hex")
        if type(self.shift) is not int or self.shift < 0 or self.shift >= self.length * 8:
            raise ValueError("Invalid identifier shift")
        if self.mask is not None and (type(self.mask) is not int or not 0 <= self.mask < 1 << (8 * self.length)):
            raise ValueError("Mask does not fit the identifier length")
        if (self.mask is not None or self.shift) and (self.type not in {"uint", "enum"} or self.signed):
            raise ValueError("Masks and shifts require an unsigned integer or enum")

    def encode(self, value):
        if self.type in {"uint", "int", "enum"}:
            if self.type == "enum" and isinstance(value, str) and value in dict(self.enum_values):
                value = dict(self.enum_values)[value]
            if isinstance(value, str):
                try:
                    value = int(value, 0)
                except ValueError:
                    value = int(value, 10)
            if type(value) is not int:
                raise ValueError("Expected an integer or enum member")
            raw_value = value << self.shift
            raw = raw_value.to_bytes(self.length, self.byteorder, signed=self.type == "int" or self.signed)
            if self.mask is not None and raw_value & ~self.mask:
                raise ValueError("Expected value cannot be represented by the mask and shift")
            return raw
        if self.type == "bool":
            if isinstance(value, str):
                if value.lower() not in {"true", "false", "0", "1"}:
                    raise ValueError("Expected true or false")
                value = value.lower() in {"true", "1"}
            if type(value) is not bool:
                raise ValueError("Expected true or false")
            return bytes([int(value)])
        if self.type == "float":
            if isinstance(value, dict) and "hex" in value:
                raw = bytes.fromhex(value["hex"])
                if len(raw) != self.length:
                    raise ValueError("Floating-point hex must match the configured length")
                return raw
            if isinstance(value, str) and value.startswith("bits:"):
                return self.encode({"hex": value[5:]})
            return struct.pack(("<" if self.byteorder == "little" else ">") + ("f" if self.length == 4 else "d"), float(value))
        if self.type == "bytes":
            raw = bytes.fromhex(value) if isinstance(value, str) else bytes(value)
            if len(raw) != self.length:
                raise ValueError(f"Expected exactly {self.length} bytes")
            return raw
        if not isinstance(value, str):
            raise ValueError("Expected text")
        raw = value.encode(self.encoding)
        if len(raw) > self.length:
            raise ValueError(f"Text exceeds {self.length} encoded bytes")
        return raw + bytes.fromhex(self.padding) * (self.length - len(raw))

    def key_bytes(self, raw):
        if self.mask is not None or self.shift:
            number = int.from_bytes(raw, self.byteorder)
            if self.mask is not None:
                number &= self.mask
            return (number >> self.shift).to_bytes(self.length, self.byteorder)
        return bytes(raw)

    def decode(self, raw):
        if self.type in {"uint", "enum", "int"}:
            return int.from_bytes(self.key_bytes(raw), self.byteorder, signed=self.type == "int" or self.signed)
        if self.type == "bool":
            return bool(raw[0])
        if self.type == "float":
            return struct.unpack(("<" if self.byteorder == "little" else ">") + ("f" if self.length == 4 else "d"), raw)[0]
        if self.type == "bytes":
            return bytes(raw).hex(" ").upper()
        decoded = bytes(raw).decode(self.encoding, errors='replace')
        return decoded.rstrip('\x00' if self.padding == '00' else ' ' if self.padding == '20' else '')


@dataclass(frozen=True)
class CompiledMatch:
    message_uid: str
    message_type: object
    group: object
    group_path: tuple
    identifiers: tuple

    @property
    def group_values(self):
        return {f"{item['group']}.{item['name']}": item['value'] for item in self.identifiers}

    @property
    def group_value_path(self):
        return tuple({item['name']: item['value'] for item in self.identifiers if item['group_uid'] == group.uid}
                     for group in self.group_path)

    @property
    def message_values(self):
        return {item['name']: item['value'] for item in self.identifiers if item['group_uid'] == self.group.uid}


class GroupDecoder:
    def __init__(self, registry, spec, parent=None):
        self.registry = registry
        self.uid = spec['uid']
        self.name = spec['name']
        self.parent = parent
        self.path = (parent.path + "/" if parent and parent.parent else "") + self.name if parent else ""
        self.identifiers = tuple(Identifier(**identifier) for identifier in spec.get('identifiers', []))
        if len({identifier.uid for identifier in self.identifiers}) != len(self.identifiers) or len({identifier.name for identifier in self.identifiers}) != len(self.identifiers):
            raise RoutingConfigurationError(f"Identifier IDs and names must be unique in {self.name}")
        self.required_length = max((identifier.offset + identifier.length for identifier in self.identifiers), default=0)
        self.lookup = {}
        self.expected_key = None
        self.active = parent is None

    def _key(self, data):
        if len(data) < self.required_length:
            raise InsufficientRoutingDataError(f"{self.name} identifiers require {self.required_length} bytes; got {len(data)}")
        return tuple(identifier.key_bytes(data[identifier.offset:identifier.offset + identifier.length]) for identifier in self.identifiers)

    def decode_auto(self, data, *, direction=None, **context):
        uid = self.registry.select(data, group_uid=self.uid, direction=direction)
        return self.registry.message_types[uid].decode(data, **context)

    def identify_message(self, data, *, direction=None):
        return self.registry.identify_message(data, group_uid=self.uid, direction=direction)


class CompiledRoutingRegistry:
    """Immutable per-group hash tables. No candidate scans on the decoding path."""

    def __init__(self, message_types, specification):
        self.message_types = dict(message_types)
        self.by_name = MappingProxyType({cls.MESSAGE_NAME or cls.__name__: cls for cls in self.message_types.values()})
        root_spec = specification['root']
        self.root = GroupDecoder(self, root_spec)
        self.groups_by_uid = {self.root.uid: self.root}
        group_specs = specification.get('groups', [])
        children = {}
        group_uids = {self.root.uid}
        for spec in group_specs:
            if spec['uid'] in group_uids:
                raise RoutingConfigurationError("Duplicate group UID")
            group_uids.add(spec['uid'])
            children.setdefault(spec.get('parent_uid') or self.root.uid, []).append(spec)
        pending = [self.root]
        for parent in pending:
            for spec in children.get(parent.uid, []):
                group = GroupDecoder(self, spec, parent)
                group.expected_key = self._expected(parent, spec.get('expected_values'))
                group.active = parent.active and group.expected_key is not None
                self.groups_by_uid[group.uid] = group
                pending.append(group)
                if group.expected_key is not None:
                    self._insert(parent, group.expected_key, group=group)
        if len(self.groups_by_uid) != len(group_specs) + 1:
            raise RoutingConfigurationError("Missing parent group or circular group ancestry")
        self.message_specs = {}
        for spec in specification.get('messages', []):
            parent = self.groups_by_uid.get(spec.get('parent_uid') or self.root.uid)
            if parent is None:
                raise RoutingConfigurationError("Message references a missing group")
            if spec['uid'] in self.message_specs or spec['uid'] in self.groups_by_uid:
                raise RoutingConfigurationError("Duplicate message UID")
            self.message_specs[spec['uid']] = spec
            key = self._expected(parent, spec.get('expected_values'))
            if key is not None:
                self._insert(parent, key, message=spec)
        for group in self.groups_by_uid.values():
            group.lookup = MappingProxyType({key: (value[0], MappingProxyType(value[1])) for key, value in group.lookup.items()})
        self.groups_by_path = MappingProxyType({group.path: group for group in self.groups_by_uid.values() if group is not self.root})
        self.groups_by_name = MappingProxyType({group.name: group for group in self.groups_by_uid.values()})
        self.groups_by_uid = MappingProxyType(self.groups_by_uid)

    @staticmethod
    def _expected(parent, values):
        if values is None:
            return None
        if not isinstance(values, dict):
            raise RoutingConfigurationError("Expected identifier values must be an object or unassigned")
        encoded = []
        incomplete = False
        for identifier in parent.identifiers:
            value = values.get(identifier.uid)
            if value is None:
                incomplete = True
                continue
            try:
                encoded.append(identifier.key_bytes(identifier.encode(value)))
            except (ValueError, TypeError, OverflowError, LookupError, struct.error) as error:
                raise RoutingConfigurationError(f"{parent.name}.{identifier.name}: {error}") from error
        return None if incomplete else tuple(encoded)

    @staticmethod
    def _insert(parent, key, *, group=None, message=None):
        bucket = parent.lookup.setdefault(key, [None, {}])
        if group is not None:
            if bucket[0] is not None or bucket[1]:
                raise RoutingConfigurationError(f"Duplicate child identifier values in {parent.name}")
            bucket[0] = group
        else:
            direction = Direction.normalize(message.get('direction', 'ANY')).value
            if bucket[0] is not None or direction in bucket[1] or ('ANY' in bucket[1]) or (direction == 'ANY' and bucket[1]):
                raise RoutingConfigurationError(f"Duplicate child identifier values in {parent.name}")
            bucket[1][direction] = message['uid']

    def _start(self, data, uid, trace):
        group = self.groups_by_uid.get(uid or self.root.uid)
        if group is None or not group.active:
            raise UnknownGroupError("This group or an ancestor has unassigned identifier values")
        chain = []
        current = group
        while current.parent is not None:
            chain.append(current)
            current = current.parent
        for current in reversed(chain):
            if current.parent._key(data) != current.expected_key:
                raise UnknownGroupError(f"Ancestor identifiers do not match {current.name}")
            if trace is not None:
                trace.append(current.parent)
        return group

    def _select(self, data, uid, direction, trace=None):
        direction = Direction.normalize(direction)
        direction = direction.value if direction is not None else None
        group = self._start(data, uid, trace)
        while True:
            if not group.lookup:
                raise UnknownMessageIdentityError(f"{group.name} has no children with complete expected values")
            bucket = group.lookup.get(group._key(data))
            if bucket is None:
                raise UnknownMessageIdentityError(f"No assigned child matches identifiers in {group.name}")
            if trace is not None:
                trace.append(group)
            child, messages = bucket
            if child is not None:
                group = child
                continue
            if direction is not None:
                result = messages.get(direction) or messages.get('ANY')
                if result is None:
                    raise UnknownMessageIdentityError(f"No {direction} message matches identifiers in {group.name}")
                return result, group
            if len(messages) != 1:
                raise AmbiguousMessageIdentityError("The wire identity has TX and RX messages; provide direction")
            return next(iter(messages.values())), group

    def select(self, data, *, group_uid=None, direction=None):
        return self._select(data, group_uid, direction)[0]

    def decode_auto(self, data, *, direction=None, **context):
        return self.root.decode_auto(data, direction=direction, **context)

    def identify_message(self, data, *, group_uid=None, direction=None):
        trace = []
        uid, group = self._select(data, group_uid, direction, trace)
        identifiers = []
        for owner in trace:
            for identifier in owner.identifiers:
                raw = bytes(data[identifier.offset:identifier.offset + identifier.length])
                identifiers.append({'group_uid': owner.uid, 'group': owner.name, 'name': identifier.name,
                                    'type': identifier.type, 'value': identifier.decode(raw), 'hex': raw.hex(' ').upper()})
        return CompiledMatch(uid, self.message_types.get(uid), group, tuple(trace), tuple(identifiers))

    def identify_group(self, data):
        child, messages = self.root.lookup.get(self.root._key(data), (None, {}))
        if child is None:
            raise UnknownGroupError("The root identifiers do not select a group")
        values = {identifier.name: identifier.decode(bytes(data[identifier.offset:identifier.offset + identifier.length]))
                  for identifier in self.root.identifiers}
        return child, MappingProxyType(values)
