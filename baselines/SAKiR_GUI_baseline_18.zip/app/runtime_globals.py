"""Restricted, reload-stable Globals facade for runtime inspection tools."""

from __future__ import annotations

from typing import Any, Callable, Iterable, Iterator, Mapping

from app.global_store import AppGlobals, GlobalRegistry


def _registry_for(view: "RuntimeGlobalsView") -> GlobalRegistry:
    return object.__getattribute__(view, "_registry")


class RuntimeGlobalsView:
    """Expose only the supported runtime Globals API over a stable registry.

    This view intentionally has no declaration, lifecycle, ownership, staging,
    or generation-commit operations. Callback declarations continue to use
    ``class Globals(GlobalsBase)``; inspection tools receive the singleton view
    below under the name ``Globals``.
    """

    __slots__ = ("_registry",)

    def __init__(self, registry: GlobalRegistry = AppGlobals) -> None:
        object.__setattr__(self, "_registry", registry)

    def __getattribute__(self, name: str) -> Any:
        if name == "_registry":
            raise AttributeError("Runtime Globals registry internals are not exposed")
        return object.__getattribute__(self, name)

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(f"Runtime Globals member {name!r} is internal")
        return getattr(_registry_for(self), name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_"):
            raise AttributeError(f"Runtime Globals member {name!r} is internal")
        setattr(_registry_for(self), name, value)

    def __delattr__(self, name: str) -> None:
        if name.startswith("_"):
            raise AttributeError(f"Runtime Globals member {name!r} is internal")
        delattr(_registry_for(self), name)

    def __getitem__(self, key: str) -> Any:
        return _registry_for(self)[key]

    def __setitem__(self, key: str, value: Any) -> None:
        _registry_for(self)[key] = value

    def __delitem__(self, key: str) -> None:
        del _registry_for(self)[key]

    def __contains__(self, key: object) -> bool:
        return key in _registry_for(self)

    def __len__(self) -> int:
        return len(_registry_for(self))

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def keys(self) -> list[str]:
        return _registry_for(self).keys()

    def values(self) -> list[Any]:
        return _registry_for(self).values()

    def items(self) -> list[tuple[str, Any]]:
        return _registry_for(self).items()

    def get(self, key: str, default: Any = None) -> Any:
        return _registry_for(self).get(key, default)

    def pop(self, key: str, *default: Any) -> Any:
        return _registry_for(self).pop(key, *default)

    def setdefault(self, key: str, default: Any = None) -> Any:
        return _registry_for(self).setdefault(key, default)

    def update(
        self, values: Mapping[str, Any] | Iterable[tuple[str, Any]]
    ) -> None:
        _registry_for(self).update(values)

    def clear(self) -> None:
        _registry_for(self).clear()

    def snapshot(self) -> dict[str, Any]:
        return _registry_for(self).snapshot()

    def mutate(self, key: str, operation: Callable[[Any], Any]) -> Any:
        return _registry_for(self).mutate(key, operation)

    @property
    def state(self) -> str:
        return _registry_for(self).state

    @property
    def generation(self) -> int:
        return _registry_for(self).generation

    @property
    def error(self) -> Any:
        return _registry_for(self).error

    def __dir__(self) -> list[str]:
        public = {
            "clear", "error", "generation", "get", "items", "keys",
            "mutate", "pop", "setdefault", "snapshot", "state", "update",
            "values",
        }
        return sorted(public | set(_registry_for(self).keys()))

    def __repr__(self) -> str:
        target = _registry_for(self)
        return (
            f"<RuntimeGlobals state={target.state} "
            f"generation={target.generation} keys={target.keys()}>"
        )


RuntimeGlobals = RuntimeGlobalsView()


__all__ = ["RuntimeGlobals", "RuntimeGlobalsView"]
