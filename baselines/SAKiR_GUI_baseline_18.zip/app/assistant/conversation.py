"""Selectable rich text with rounded message and code surfaces."""
from PyQt5 import QtCore, QtGui, QtWidgets


class Conversation(QtWidgets.QTextBrowser):
    # QTextDocument supports table padding but not CSS border-radius. Retain
    # its text layout and selection, and paint the marked table surfaces here.
    SURFACES = {"#f2f4f7": 12, "#f3f5f8": 10}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._surfaces = []

    def setHtml(self, text):
        self._surfaces = []
        super().setHtml(text)
        # Batch format changes; each setFormat otherwise relayouts the history.
        cursor = QtGui.QTextCursor(self.document())
        cursor.beginEditBlock()
        try:
            self._collect_surfaces(self.document().rootFrame())
        finally:
            cursor.endEditBlock()
        self.viewport().update()

    def replace_html(self, text, follow=False):
        """Replace a streamed document without flashing the scrollbar at zero."""
        bar = self.verticalScrollBar()
        previous = bar.value()
        selection = self.textCursor()
        selected_text = selection.selectedText()
        position, anchor = selection.position(), selection.anchor()
        self.setUpdatesEnabled(False)
        try:
            self.setHtml(text)
            # Finish Qt's lazy layout before restoring the viewport. This also
            # accounts for wrapping when the scrollbar first becomes visible.
            self.document().documentLayout().documentSize()
            if selected_text:
                cursor = QtGui.QTextCursor(self.document())
                last = self.document().characterCount() - 1
                cursor.setPosition(min(anchor, last))
                cursor.setPosition(min(position, last), QtGui.QTextCursor.KeepAnchor)
                if cursor.selectedText() == selected_text:
                    self.setTextCursor(cursor)
            bar.setValue(bar.maximum() if follow else min(previous, bar.maximum()))
        finally:
            self.setUpdatesEnabled(True)

    def update_activity_titles(self, titles):
        """Update only elapsed-time link text, preserving selection and history."""
        replacements = []
        block = self.document().begin()
        while block.isValid():
            iterator = block.begin()
            while not iterator.atEnd():
                fragment = iterator.fragment()
                if fragment.isValid():
                    fmt = fragment.charFormat()
                    title = titles.get(fmt.anchorHref())
                    if title is not None and fragment.text().startswith(("Working for ", "Worked for ")):
                        if fragment.text() != title:
                            replacements.append((fragment.position(), fragment.length(), fmt, title))
                iterator += 1
            block = block.next()
        cursor = QtGui.QTextCursor(self.document())
        cursor.beginEditBlock()
        try:
            for position, length, fmt, title in reversed(replacements):
                cursor.setPosition(position)
                cursor.setPosition(position + length, QtGui.QTextCursor.KeepAnchor)
                cursor.insertText(title, fmt)
        finally:
            cursor.endEditBlock()

    def _collect_surfaces(self, frame):
        for child in frame.childFrames():
            fmt = child.frameFormat()
            brush = fmt.background()
            color = brush.color().name()
            if brush.style() != QtCore.Qt.NoBrush and color in self.SURFACES:
                self._surfaces.append((child, QtGui.QColor(color), self.SURFACES[color]))
                fmt.setBackground(QtGui.QBrush(QtCore.Qt.NoBrush))
                if isinstance(child, QtGui.QTextTable):
                    child.setFormat(fmt.toTableFormat())
                else:
                    child.setFrameFormat(fmt)
            self._collect_surfaces(child)

    def surface_rect(self, frame):
        rect = self.document().documentLayout().frameBoundingRect(frame)
        if isinstance(frame, QtGui.QTextTable):
            # Qt reports the table origin at the first cell's content origin.
            cell = frame.cellAt(0, 0).format().toTableCellFormat()
            rect.translate(-cell.leftPadding(), -cell.topPadding())
        return rect

    def paintEvent(self, event):
        painter = QtGui.QPainter(self.viewport())
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtCore.Qt.NoPen)
        offset = QtCore.QPointF(-self.horizontalScrollBar().value(), -self.verticalScrollBar().value())
        for frame, color, radius in self._surfaces:
            rect = self.surface_rect(frame).translated(offset)
            if rect.intersects(QtCore.QRectF(event.rect())):
                painter.setBrush(color)
                painter.drawRoundedRect(rect, radius, radius)
        painter.end()
        super().paintEvent(event)
