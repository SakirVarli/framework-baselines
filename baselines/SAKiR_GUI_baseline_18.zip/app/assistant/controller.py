"""One project controller and Assistant window shared by all entry points."""
import copy
import json
from pathlib import Path
import threading
import uuid

from PyQt5 import QtCore

from .availability import available
from . import changes
from .context import SourceIndex
from .context_window import ContextWindow, clean_state
from .policy import AssistantError, ProjectPolicy, digest, file_hash, redact
from .provider import ChatProvider
from .service import run
from .storage import Store, Settings, Credentials, atomic_json
from .tools import ToolSet


class Controller(QtCore.QObject):
    # Do not name this signal "event": Qt calls QObject.event() to deliver
    # queued worker completions, and a signal in its place aborts the process.
    activity = QtCore.pyqtSignal(str, object)
    busy_changed = QtCore.pyqtSignal(bool)
    proposal_changed = QtCore.pyqtSignal(object)
    action_changed = QtCore.pyqtSignal(object)
    attachments_changed = QtCore.pyqtSignal(object)
    _worker_done = QtCore.pyqtSignal(object)
    _snapshot_requested = QtCore.pyqtSignal(object)

    def __init__(self, window, root, store=None):
        if not available(window.phase):
            raise AssistantError("UNAVAILABLE", "Assistant is available only in non-frozen baseline/development modes.")
        super().__init__(window)
        self.window = window
        self.policy = ProjectPolicy(root)
        self.store = store or Store(root)
        self.credentials = Credentials()
        self.settings_error = ""
        try:
            self.settings = self.store.load_settings()
        except AssistantError as exc:
            self.settings = Settings()
            self.settings_error = str(exc)
        self.index = SourceIndex(self.policy)
        self.transactions = changes.Transactions(self.policy, self.store)
        self.history = []
        self.context_state = clean_state({}, [])
        self.evidence_summary = []
        self.task_index = None
        self.session_id = uuid.uuid4().hex
        self.proposal = None
        self.action = None
        self.last_transaction = None
        self.busy = False
        self.closing = False
        self.cancel = threading.Event()
        self.provider = None
        self.assistant_window = None
        self.selection = ""
        self.recent_errors = []
        self._reload_generation = None
        self._worker_done.connect(self._done)
        self._snapshot_requested.connect(self._capture_snapshot_revision)
        self.window.global_runtime.reload_finished.connect(self._reloaded)
        for name in ("initialization_failed", "initialization_warning"):
            signal = getattr(window, name, None)
            if signal is not None:
                signal.connect(self.capture_error)

    def capture_error(self, generation, details):
        self.recent_errors.append({"generation": generation, "details": redact(str(details))[-6000:]})
        self.recent_errors = self.recent_errors[-10:]

    @QtCore.pyqtSlot(object)
    def _capture_snapshot_revision(self, query):
        try:
            query["revision"] = self.snapshot()["revision"]
        except Exception as exc:
            query["error"] = str(exc)
        finally:
            query["ready"].set()

    def _freshness_check(self, revision):
        # Request Qt-owned designer state on the GUI thread; never inspect it from a worker.
        query = {"ready": threading.Event()}
        if QtCore.QThread.currentThread() == self.thread():
            self._capture_snapshot_revision(query)
        else:
            self._snapshot_requested.emit(query)
            for _ in range(100):
                if query["ready"].wait(.1):
                    break
                if self.cancel.is_set() or self.closing:
                    raise AssistantError("CANCELLED", "Stopped.")
        if not query["ready"].is_set():
            raise AssistantError("PROJECT_BUSY", "Could not confirm current designer state. Retry when the application is ready.")
        if query.get("error") or query.get("revision") != revision:
            raise AssistantError("SOURCE_CHANGED", "Designer or runtime state changed during this task; retry with current context.")

    def snapshot(self):
        designer = getattr(self.window, "_config_designer", None)
        config_path = self.policy.root / "app/data/config.json"
        callbacks_path = self.policy.root / "callbacks/callbacks.py"
        config = copy.deepcopy(designer.document.to_config()) if designer else json.loads(config_path.read_text(encoding="utf-8"))
        callbacks = designer._callback_source() if designer else callbacks_path.read_text(encoding="utf-8")
        from app.config_designer.document import DesignerDocument
        document = designer.document if designer else DesignerDocument.from_config(config)
        def nodes(node, selector="root"):
            return [{"selector": selector, "node_id": node.node_id, "type": node.node_type, "properties": copy.deepcopy(node.properties)}] + [
                row for i, child in enumerate(node.children) for row in nodes(child, f"{selector}/{i}")]
        from app.tool_api import Tools
        runtime = {}
        for name in ("serial", "telnet", "communication"):
            api = getattr(Tools, name)
            runtime[name] = {"open": api.available, "sessions": []}
            if api.available:
                for session in api.sessions:
                    runtime[name]["sessions"].append({"name": session.name, "running": session.running if name == "communication" else session.connected,
                                                      "settings": redact(session.config() if name == "communication" else session.settings)})
        for name in ("ftp_client", "ftp_server"):
            api = getattr(Tools, name)
            runtime[name] = {"open": api.available}
        message_designer = getattr(self.window, "_message_designer", None)
        manifest = copy.deepcopy(message_designer.document.data) if message_designer else None
        message_path = None
        if message_designer and message_designer.loaded:
            try:
                message_path = (message_designer.loaded.package_dir / "message_library.json").relative_to(self.policy.root).as_posix()
            except ValueError:
                pass
        hashes = {"app/data/config.json": file_hash(config_path), "callbacks/callbacks.py": file_hash(callbacks_path)}
        generation = self.window.global_runtime.generation
        result = {"config": config, "callbacks": callbacks, "hashes": hashes, "runtime_generation": generation,
                  "layout_tree": nodes(document.root), "runtime": runtime, "selection": self.selection,
                  "selected_nodes": designer.document.selected_ids if designer else [], "message_manifest": manifest,
                  "message_library_path": message_path,
                  "message_properties_pending": bool(message_designer and message_designer._properties_pending),
                  "attachments": sorted(map(str, self.policy.attachments)), "recent_errors": copy.deepcopy(self.recent_errors)}
        # Selection and transient runtime status are useful context, but do not
        # invalidate a reviewed code edit. Actual source/document generations do.
        result["revision"] = digest([config, callbacks, hashes, generation, manifest])
        return result

    def submit(self, request, can_edit=True):
        if self.busy or self.closing:
            raise AssistantError("PROJECT_BUSY", "Wait for the current task or stop it.")
        if not self.window._admin_ok():
            return
        from .settings_policy import resolve_settings
        settings = resolve_settings(self.settings)
        settings.validate()
        key = self.credentials.key(settings)
        self.proposal = None
        self.proposal_changed.emit(None)
        self.action = None
        self.action_changed.emit(None)
        snapshot = self.snapshot()
        profile = settings.capability_profile or {}
        tools_supported = profile.get("tool_round_trip", True)
        if can_edit and not tools_supported:
            raise AssistantError("TOOLS_UNSUPPORTED", "This connection failed tool compatibility. Use Explain / Inspect for source-context chat, or configure a tool-capable model.")
        history = copy.deepcopy(self.history)
        context_state = copy.deepcopy(self.context_state)
        previous_evidence = copy.deepcopy(self.evidence_summary)
        self.cancel = threading.Event()
        self.busy = True
        self.busy_changed.emit(True)
        self.history.append({"role": "user", "content": request})
        self.activity.emit("user", request)
        def worker():
            tools = None
            context_window = None
            try:
                tools = ToolSet(self.policy, self.index, snapshot, settings, self.cancel, can_edit,
                                freshness_check=lambda: self._freshness_check(snapshot["revision"]))
                if not tools_supported:
                    tools.definitions.clear()
                self.provider = ChatProvider(settings, key)
                context_window = ContextWindow(settings, self.provider, self.activity.emit, self.cancel, history, context_state)
                text = run(self.provider, tools, history, request, self.activity.emit, self.cancel, previous_evidence, context_window)
                result = {"text": text, "proposal": tools.proposal, "action": tools.action, "evidence": tools.evidence,
                          "task_index": tools.index}
            except Exception as exc:
                result = {"error": "CANCELLED: Stopped." if self.cancel.is_set() else self.error_text(exc),
                          "proposal": getattr(tools, "proposal", None), "action": getattr(tools, "action", None)}
            finally:
                if context_window is not None:
                    result["context_state"] = context_window.state
                if self.provider:
                    try:
                        self.provider.dispose()
                    except Exception:
                        pass
                self.provider = None
            try:
                self._worker_done.emit(result)
            except RuntimeError:
                pass  # the application/window can close while a request ends
        threading.Thread(target=worker, name="sakir-assistant", daemon=True).start()

    def error_text(self, exc):
        text = str(exc)
        try:
            key = self.credentials.key(self.settings)
            if key and key != "local-no-auth":
                text = text.replace(key, "<redacted>")
        except AssistantError:
            pass
        return f"{getattr(exc, 'code', 'ASSISTANT_ERROR')}: {redact(text)}"

    @QtCore.pyqtSlot(object)
    def _done(self, result):
        if self.closing:
            return
        self.busy = False
        self.busy_changed.emit(False)
        if "context_state" in result:
            self.context_state = clean_state(result["context_state"], self.history)
        if result.get("evidence"):
            self.evidence_summary = result["evidence"]
        if result.get("task_index"):
            self.task_index = result["task_index"]
        if not result.get("runtime_action"):
            self.proposal = result.get("proposal")
            self.proposal_changed.emit(self.proposal)
            self.action = result.get("action")
            self.action_changed.emit(self.action)
            if self.proposal:
                try:
                    atomic_json(self.store.private / "proposals" / f"{self.proposal.id}.json",
                                {"id": self.proposal.id, "summary": self.proposal.summary,
                                 "context_revision": self.proposal.context_revision, "fingerprint": self.proposal.fingerprint,
                                 "edits": [e.__dict__ for e in self.proposal.edits]})
                except OSError as exc:
                    self.activity.emit("error", "Proposal stays in memory; could not save draft: " + str(exc))
        if result.get("error"):
            self.activity.emit("error", result["error"])
        elif result.get("text"):
            self.history.append({"role": "assistant", "content": result["text"]})
        # Persist only user-visible messages, not tool data/source or secrets.
        self.history = redact(self.history)
        try:
            self.store.save_session(self.session_id, self.history, self.settings, self.context_state)
        except OSError as exc:
            self.activity.emit("error", "Conversation could not be saved: " + str(exc))
        self.activity.emit("status", "Review the proposal" if self.proposal else "Ready")

    def stop(self):
        self.cancel.set()
        provider = self.provider
        if provider:
            threading.Thread(target=provider.close, daemon=True).start()
        self.activity.emit("status", "Stopping…")

    def shutdown(self):
        self.closing = True
        self.stop()
        view = self.assistant_window
        self.assistant_window = None
        if view is not None:
            try:
                view.paint_timer.stop()
                view.close()
                view.deleteLater()
            except RuntimeError:
                pass

    def new_session(self, history=None, session_id=None):
        if self.busy:
            raise AssistantError("PROJECT_BUSY", "Stop the active task before changing sessions.")
        self.history = history or []
        self.evidence_summary = []
        self.task_index = None
        self.session_id = session_id or uuid.uuid4().hex
        self.context_state = clean_state(self.store.load_context(self.session_id), self.history) if session_id else clean_state({}, self.history)
        self.proposal = None
        self.proposal_changed.emit(None)
        self.action = None
        self.action_changed.emit(None)
        self.activity.emit("session", copy.deepcopy(self.history))

    def review(self, *, structured=False):
        if not self.proposal:
            raise AssistantError("NO_PROPOSAL", "No proposal is ready.")
        snapshot = self.snapshot()
        report = changes.validate(self.policy, self.proposal, snapshot)
        for edit in self.proposal.edits:
            name = Path(edit.path).stem
            if edit.path.startswith("app/data/") and name != "config" and snapshot["runtime"].get(name if name != "communication_hub" else "communication", {}).get("open"):
                report["ok"] = False
                report["issues"].append({"severity": "error", "message": f"Close {name} before applying its saved settings to avoid overwriting its active state."})
            message_path = snapshot.get("message_library_path")
            if message_path and Path(edit.path).parent == Path(message_path).parent and snapshot["message_properties_pending"]:
                report["ok"] = False
                report["issues"].append({"severity": "error", "message": "Apply or discard pending Message Designer property edits before saving its library."})
        return report, (changes.review_files(self.policy, self.proposal, snapshot) if structured
                        else changes.diff(self.policy, self.proposal, snapshot))

    def drafts(self):
        result = []
        for path in sorted((self.store.private / "proposals").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                edits = tuple(changes.Edit(**edit) for edit in value["edits"])
                proposal = changes.Proposal(value["id"], value["summary"], edits, value["context_revision"])
                if proposal.fingerprint == value["fingerprint"]:
                    result.append(proposal)
            except (OSError, ValueError, KeyError, TypeError):
                continue
        return result[:30]

    def load_draft(self, proposal):
        if self.busy:
            raise AssistantError("PROJECT_BUSY", "Stop the active task before loading a draft.")
        for edit in proposal.edits:
            self.policy.path(edit.path, write=True)
        self.proposal = proposal
        self.proposal_changed.emit(proposal)

    def apply(self, fingerprint, reload=True):
        if self.busy or self.closing or getattr(self.window, "_source_reload_in_progress", False):
            raise AssistantError("PROJECT_BUSY", "Application is busy or reloading.")
        if not self.window._admin_ok():
            return
        report, _ = self.review()
        if not report["ok"]:
            raise AssistantError("VALIDATION_FAILED", "\n".join(i["message"] for i in report["issues"] if i["severity"] == "error"))
        window = self.window
        if window._pending_source_paths or window._source_change_prompt is not None or window._source_reload_notice is not None:
            raise AssistantError("PROJECT_BUSY", "Resolve the existing source-change/reload notice before applying.")
        # No event loop reentry while the short commit holds the GUI-side gate.
        proposal = self.proposal
        designer = getattr(window, "_config_designer", None)
        previous_callbacks = designer._callback_source() if designer else None
        saved = self.transactions.commit(proposal, fingerprint)
        self.last_transaction = saved
        window._assistant_reload_hashes = {self.policy.root / e.path: file_hash(self.policy.root / e.path) for e in proposal.edits}
        candidate = json.loads((self.policy.root / "app/data/config.json").read_text(encoding="utf-8"))
        callbacks = (self.policy.root / "callbacks/callbacks.py").read_text(encoding="utf-8")
        warning = ""
        try:
            from app.stub_generator import regenerate_stubs
            regenerate_stubs(candidate)
        except Exception as exc:
            warning = " Saved, but generated stubs need repair: " + str(exc)
        if designer:
            from app.config_designer.document import DesignerDocument
            from app.config_designer.commands import ReplaceDocumentCommand, CallbackSourceCommand
            designer.undo_stack.beginMacro("Assistant changes")
            designer.undo_stack.push(ReplaceDocumentCommand(designer.document, DesignerDocument.from_config(candidate), "Assistant layout"))
            designer.undo_stack.push(CallbackSourceCommand(designer._set_callback_source, previous_callbacks, callbacks, "Assistant callbacks"))
            designer.undo_stack.endMacro()
            designer.document.mark_saved()
            designer._callback_source_override = None
            designer._callback_edit_baseline = None
            designer._reset_callback_tracking()
            designer.undo_stack.setClean()
            designer.run_validation(quiet=True)
        message_designer = getattr(window, "_message_designer", None)
        if message_designer and message_designer.loaded:
            current_manifest = message_designer.loaded.package_dir / "message_library.json"
            if any(self.policy.root / edit.path == current_manifest for edit in proposal.edits):
                from app.tools.message_designer.persistence import load_library
                from app.tools.message_designer.commands import ReplaceManifestCommand
                loaded = load_library(current_manifest.parent)
                message_designer.undo_stack.push(ReplaceManifestCommand(message_designer.document,
                    message_designer.document.snapshot(), loaded.manifest, "Assistant message library"))
                message_designer.document.mark_saved()
                message_designer.loaded = loaded
                message_designer.undo_stack.setClean()
        self.proposal = None
        self.proposal_changed.emit(None)
        self.activity.emit("status", "Saved" + warning)
        if reload:
            self.busy = True
            self.busy_changed.emit(True)
            self._reload_generation = window.global_runtime.generation + 1
            try:
                generation = window._reload_layout(candidate)
                if self._reload_generation is not None:
                    self._reload_generation = generation
                    self.activity.emit("status", "Saved; reloading runtime…" + warning)
            except Exception as exc:
                self._reload_generation = None
                self.busy = False
                self.busy_changed.emit(False)
                self.activity.emit("error", "Files saved, but runtime reload failed: " + str(exc))
        else:
            self.activity.emit("status", "Saved; runtime still uses the previous generation. Reload when ready." + warning)

    def _reloaded(self, generation, success):
        if generation != self._reload_generation:
            return
        self._reload_generation = None
        self.busy = False
        self.busy_changed.emit(False)
        self.activity.emit("status" if success else "error", "Saved and running" if success else "Saved, but reload failed. Review diagnostics or restore the previous contents.")

    def restore(self):
        if not self.last_transaction:
            raise AssistantError("UNDO_UNAVAILABLE", "No saved assistant change to restore in this session.")
        self.proposal = self.transactions.undo_proposal(self.last_transaction, self.snapshot())
        self.proposal_changed.emit(self.proposal)

    def run_action(self, approved_digest):
        if self.busy or self.closing or not self.action:
            raise AssistantError("PROJECT_BUSY", "No runtime action is ready.")
        if not self.window._admin_ok():
            return
        action = copy.deepcopy(self.action)
        snapshot = self.snapshot()
        if approved_digest != digest(action) or snapshot["runtime_generation"] != action["generation"] or digest(snapshot["runtime"]) != action["runtime_revision"]:
            raise AssistantError("STALE_ACTION", "Session state changed; request a new action.")
        from app.tool_api import Tools
        # Locate on the owning thread; effect dispatch uses the public APIs.
        session = getattr(Tools, action["tool"]).session(action["session"]) if action["operation"] != "open" else None
        self.action = None  # consume before execution; repeated clicks cannot resend
        self.action_changed.emit(None)
        self.busy = True
        self.busy_changed.emit(True)
        self.cancel = threading.Event()
        def worker():
            try:
                operation = action["operation"]
                if operation == "open":
                    methods = {"serial": "_open_serial", "telnet": "_open_telnet", "communication": "_open_communication_hub",
                               "ftp_client": "_open_ftp_client", "ftp_server": "_open_ftp_server",
                               "message_designer": "_open_message_designer", "config_designer": "_open_designer"}
                    result = Tools.registry.call_gui(getattr(self.window, methods[action["tool"]]))
                elif operation == "connect":
                    result = session.start() if action["tool"] == "communication" else session.connect()
                elif operation == "disconnect":
                    result = session.stop() if action["tool"] == "communication" else session.disconnect()
                else:
                    result = session.send(action["payload"]) if action["tool"] == "communication" else session.write(action["payload"].encode("utf-8"))
                if hasattr(result, "result"):
                    result = result.result(timeout=30)
                message = f"{operation.title()} dispatched to {action['tool']} / {action['session']}. Check the tool's connection/status for completion."
                self.activity.emit("status", message)
                self._worker_done.emit({"text": message, "runtime_action": True})
            except Exception as exc:
                self._worker_done.emit({"error": self.error_text(exc), "runtime_action": True})
        threading.Thread(target=worker, daemon=True, name="assistant-session-action").start()

    def add_view(self, host=None):
        """Raise the project's tool window, regardless of which menu opened it."""
        if self.closing:
            raise AssistantError("UNAVAILABLE", "Assistant is shutting down.")
        from .ui import AssistantWindow
        view = self.assistant_window
        if view is not None:
            try:
                view.isVisible()
            except RuntimeError:
                view = None
        if view is None:
            view = AssistantWindow(self)
            self.assistant_window = view
        if view.isMinimized():
            view.showNormal()
        else:
            view.show()
        view.raise_()
        view.activateWindow()
        return view


def recover_project(root):
    policy = ProjectPolicy(root)
    store = Store(root)
    if not (store.private / "transactions").exists():
        return []
    return changes.Transactions(policy, store).recover()
