"""Native, virtualized multi-file proposal review with selectable colored diffs."""
from dataclasses import dataclass
import difflib
import html
import json

from PyQt5 import QtCore, QtGui, QtWidgets

from .appearance import ComboBox, apply_theme
from .policy import AssistantError, redact


@dataclass(frozen=True)
class DiffRow:
    kind: str
    old: int | None
    new: int | None
    text: str


class ComparisonDiff:
    def __init__(self, comparison):
        self.comparison = comparison
        self.before = comparison.before.splitlines(True)
        self.after = comparison.after.splitlines(True)
        self.matcher = difflib.SequenceMatcher(None, self.before, self.after)
        self.added = self.removed = 0
        for kind, i, j, a, b in self.matcher.get_opcodes():
            if kind != "equal":
                self.removed += j - i
                self.added += b - a
        self._rows = None
        self.hunks = []

    @property
    def rows(self):
        if self._rows is None:
            rows = []
            for group in self.matcher.get_grouped_opcodes(3):
                self.hunks.append(len(rows))
                old_start, old_end = group[0][1], group[-1][2]
                new_start, new_end = group[0][3], group[-1][4]
                def span(start, end):
                    return str(start + 1) if end - start == 1 else f"{start + 1}–{end}" if end > start else "empty"
                rows.append(DiffRow("hunk", None, None,
                                    f"Lines {span(old_start, old_end)} → {span(new_start, new_end)}"))
                for kind, i, j, a, b in group:
                    if kind == "equal":
                        for offset, line in enumerate(self.before[i:j]):
                            rows.append(DiffRow("context", i + offset + 1, a + offset + 1, line.rstrip("\r\n")))
                    else:
                        for number in range(i, j):
                            self._line(rows, "removed", number + 1, None, self.before[number])
                        for number in range(a, b):
                            self._line(rows, "added", None, number + 1, self.after[number])
            self._rows = rows
        return self._rows

    @staticmethod
    def _line(rows, kind, old, new, line):
        rows.append(DiffRow(kind, old, new, line.rstrip("\r\n")))
        if not line.endswith(("\n", "\r")):
            rows.append(DiffRow("note", None, None, "No newline at end of file"))


class DiffModel(QtCore.QAbstractTableModel):
    COLORS = {"added": ("#e8f5ec", "#205f38"), "removed": ("#fcebea", "#993b35"),
              "hunk": ("#edf2f8", "#526780"), "note": ("#f8f9fb", "#697180")}

    def __init__(self, comparison, parent=None):
        super().__init__(parent)
        self.rows = comparison.rows
        self.font = QtGui.QFont("Consolas", 10)

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else 4

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if orientation == QtCore.Qt.Horizontal and role == QtCore.Qt.DisplayRole:
            return ("Before", "After", "", "Code / configuration")[section]

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        row, column = self.rows[index.row()], index.column()
        if role == QtCore.Qt.DisplayRole:
            return (str(row.old) if row.old is not None else "", str(row.new) if row.new is not None else "",
                    {"added": "+", "removed": "−"}.get(row.kind, ""), row.text.expandtabs(4))[column]
        if role == QtCore.Qt.BackgroundRole and row.kind in self.COLORS:
            return QtGui.QColor(self.COLORS[row.kind][0])
        if role == QtCore.Qt.ForegroundRole:
            return QtGui.QColor(self.COLORS.get(row.kind, (None, "#334155"))[1] if column > 1 else "#7b8492")
        if role == QtCore.Qt.FontRole:
            return self.font
        if role == QtCore.Qt.TextAlignmentRole:
            return int((QtCore.Qt.AlignRight if column < 2 else QtCore.Qt.AlignLeft)
                       | QtCore.Qt.AlignVCenter)
        if role == QtCore.Qt.ToolTipRole:
            return {"added": "Added in the proposal", "removed": "Removed by the proposal",
                    "context": "Unchanged surrounding line", "hunk": "Changed section with surrounding context",
                    "note": "This line has no final newline"}[row.kind]


class DiffView(QtWidgets.QTableView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("reviewDiff")
        self.setAccessibleName("File changes, before and after line numbers")
        self.setEditTriggers(self.NoEditTriggers)
        self.setSelectionBehavior(self.SelectRows)
        self.setSelectionMode(self.ExtendedSelection)
        self.setShowGrid(False)
        self.setWordWrap(False)
        self.setTextElideMode(QtCore.Qt.ElideNone)
        self.verticalHeader().hide()
        self.verticalHeader().setDefaultSectionSize(23)
        self.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Fixed)
        self.horizontalHeader().setHighlightSections(False)
        self.horizontalHeader().setStretchLastSection(False)
        self.horizontalHeader().setDefaultAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        self._content_width = 200
        self.setStyleSheet("QTableView#reviewDiff { background:#ffffff; border:1px solid #dce1e8; "
                           "selection-background-color:#d5e4f5; selection-color:#20344e; }")
        self.setToolTip("Green lines are added; red lines are removed. Select rows and press Ctrl+C to copy.")

    def set_comparison(self, comparison):
        old_model = self.model()
        model = DiffModel(comparison, self)
        self.setModel(model)
        if old_model is not None:
            old_model.deleteLater()
        metrics = QtGui.QFontMetrics(model.font)
        digits = len(str(max(len(comparison.before), len(comparison.after), 1)))
        for column in (0, 1):
            self.setColumnWidth(column, max(66, metrics.horizontalAdvance("9" * digits) + 20))
        self.setColumnWidth(2, 26)
        longest = max((metrics.horizontalAdvance(row.text.expandtabs(4)) for row in model.rows), default=0)
        self._content_width = max(200, longest + 28)
        self.fit_content_width()
        self.scrollToTop()

    def fit_content_width(self):
        if self.model() is not None:
            available = self.viewport().width() - sum(self.columnWidth(column) for column in range(3))
            self.setColumnWidth(3, max(self._content_width, available))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.fit_content_width()

    def keyPressEvent(self, event):
        if event.matches(QtGui.QKeySequence.Copy) and self.model() is not None:
            rows = sorted(index.row() for index in self.selectionModel().selectedRows())
            text = "\n".join({"added": "+", "removed": "-", "context": " "}.get(row.kind, "") + row.text
                             for number in rows for row in (self.model().rows[number],))
            if rows:
                QtWidgets.QApplication.clipboard().setText(text)
            event.accept()
            return
        super().keyPressEvent(event)


def badge(text, color, background):
    label = QtWidgets.QLabel(text)
    label.setStyleSheet(f"color:{color}; background:{background}; border-radius:5px; padding:5px 9px; font-size:9pt;")
    return label


class ReviewDialog(QtWidgets.QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.proposal = controller.proposal
        self.setWindowTitle("Review Assistant Changes")
        self.resize(1180, 780)
        self.setMinimumSize(800, 550)
        apply_theme(self)
        self.report, self.files = controller.review(structured=True)
        self.diffs = [[ComparisonDiff(comparison) for comparison in file.comparisons] for file in self.files]
        self.current_diff = None
        self.current_hunk = -1
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(20, 18, 20, 18)
        heading = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("Review changes")
        title.setStyleSheet("font-size:18pt; font-weight:600;")
        heading.addWidget(title)
        heading.addStretch()
        heading.addWidget(badge(f"{len(self.files)} {'file' if len(self.files) == 1 else 'files'}", "#526074", "#edf1f6"))
        heading.addWidget(badge(f"+{sum(diffs[0].added for diffs in self.diffs)} added", "#205f38", "#e8f5ec"))
        heading.addWidget(badge(f"−{sum(diffs[0].removed for diffs in self.diffs)} removed", "#993b35", "#fcebea"))
        for index in (3, 4):
            heading.itemAt(index).widget().setToolTip("Line totals compare saved files with the proposal.")
        outer.addLayout(heading)
        subtitle = QtWidgets.QLabel("Review every file before saving. Green adds content; red removes it.")
        subtitle.setStyleSheet("color:#697180;")
        outer.addWidget(subtitle)
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setUsesScrollButtons(False)
        self.tabs.setElideMode(QtCore.Qt.ElideNone)
        outer.addWidget(self.tabs, 1)
        self.tabs.addTab(self.build_changes(), "Changes")
        self.tabs.addTab(self.build_overview(), "Overview")
        self.tabs.addTab(self.build_checks(), "Checks" + (" · blocked" if not self.report["ok"] else " · passed"))
        notice = QtWidgets.QLabel("Save Only writes all proposed files. Apply & Reload also reloads project Python.")
        notice.setWordWrap(True)
        notice.setStyleSheet("color:#697180; font-size:9pt;")
        outer.addWidget(notice)
        row = QtWidgets.QHBoxLayout()
        preview = QtWidgets.QPushButton("Layout Preview")
        preview.clicked.connect(self.preview)
        row.addWidget(preview)
        row.addStretch()
        self.apply_buttons = []
        for label, reload in (("Save Only", False), ("Apply && Reload", True)):
            button = QtWidgets.QPushButton(label)
            button.setObjectName("primary" if reload else "")
            button.setEnabled(self.report["ok"] and not controller.busy)
            button.clicked.connect(lambda _, reload=reload: self.apply(reload))
            self.apply_buttons.append(button)
            row.addWidget(button)
        close = QtWidgets.QPushButton("Close")
        close.clicked.connect(self.reject)
        row.addWidget(close)
        outer.addLayout(row)
        self.file_list.setCurrentItem(self.file_list.topLevelItem(0))

    def build_changes(self):
        panel = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(3)
        layout.addWidget(splitter)
        left = QtWidgets.QWidget()
        left.setMinimumWidth(220)
        left_layout = QtWidgets.QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 8, 0)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Find a changed file…")
        self.search.setAccessibleName("Filter changed files by path")
        left_layout.addWidget(self.search)
        self.file_list = QtWidgets.QTreeWidget()
        self.file_list.setObjectName("reviewFiles")
        self.file_list.setAccessibleName("Changed files")
        self.file_list.setHeaderLabels(["File", "Changes"])
        self.file_list.setRootIsDecorated(False)
        self.file_list.setIndentation(0)
        self.file_list.setTextElideMode(QtCore.Qt.ElideMiddle)
        self.file_list.header().setStretchLastSection(False)
        self.file_list.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.file_list.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.file_list.setStyleSheet("QTreeWidget#reviewFiles::item { padding:10px 4px; }")
        for index, file in enumerate(self.files):
            diff = self.diffs[index][0]
            item = QtWidgets.QTreeWidgetItem([file.path, f"+{diff.added}  −{diff.removed}"])
            item.setData(0, QtCore.Qt.UserRole, index)
            item.setToolTip(0, file.path + "\n" + file.status + (" · includes unsaved editor comparison" if len(file.comparisons) > 1 else ""))
            item.setToolTip(1, f"{diff.added} added lines, {diff.removed} removed lines (saved file comparison)")
            self.file_list.addTopLevelItem(item)
        left_layout.addWidget(self.file_list, 1)
        splitter.addWidget(left)
        right = QtWidgets.QWidget()
        right.setMinimumWidth(430)
        detail = QtWidgets.QVBoxLayout(right)
        detail.setContentsMargins(8, 0, 0, 0)
        self.file_title = QtWidgets.QLabel()
        self.file_title.setTextFormat(QtCore.Qt.PlainText)
        self.file_title.setWordWrap(True)
        self.file_title.setStyleSheet("font-size:12pt; font-weight:600;")
        detail.addWidget(self.file_title)
        self.file_status = QtWidgets.QLabel()
        self.file_status.setStyleSheet("color:#697180; font-size:9pt;")
        detail.addWidget(self.file_status)
        toolbar = QtWidgets.QHBoxLayout()
        self.comparison = ComboBox()
        self.comparison.setAccessibleName("Comparison baseline")
        self.comparison.setToolTip("Compare the proposal with the saved file or, when available, the unsaved designer buffer.")
        toolbar.addWidget(self.comparison, 1)
        self.previous_change = QtWidgets.QPushButton("Previous")
        self.next_change = QtWidgets.QPushButton("Next")
        for button in (self.previous_change, self.next_change):
            button.setToolTip("Jump between changed sections in this file")
            toolbar.addWidget(button)
        self.previous_change.clicked.connect(lambda: self.jump_change(-1))
        self.next_change.clicked.connect(lambda: self.jump_change(1))
        self.copy_button = QtWidgets.QPushButton("Copy diff")
        self.copy_button.setToolTip("Copy the current file's complete comparison as a unified diff")
        self.copy_button.clicked.connect(self.copy_diff)
        toolbar.addWidget(self.copy_button)
        detail.addLayout(toolbar)
        self.diff_view = DiffView()
        detail.addWidget(self.diff_view, 1)
        self.change_status = QtWidgets.QLabel()
        self.change_status.setStyleSheet("color:#697180; font-size:9pt;")
        detail.addWidget(self.change_status)
        splitter.addWidget(right)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([320, 800])
        self.file_list.currentItemChanged.connect(self.select_file)
        self.search.textChanged.connect(self.filter_files)
        self.comparison.currentIndexChanged.connect(self.select_comparison)
        return panel

    def build_overview(self):
        browser = QtWidgets.QTextBrowser()
        browser.setOpenLinks(False)
        browser.setAccessibleName("Proposal overview and affected files")
        text = '<h2>Proposal</h2><p>' + html.escape(redact(self.proposal.summary)).replace("\n", "<br>") + '</p><h3>Affected files</h3>'
        for index, file in enumerate(self.files):
            diff = self.diffs[index][0]
            text += f'<p><b>{html.escape(file.path)}</b><br>{file.status} · {diff.added} added, {diff.removed} removed'
            text += (' · Unsaved editor comparison available' if len(file.comparisons) > 1 else '') + '</p>'
        text += '<p>Changes include any existing unsaved designer work. Line totals compare saved files with the proposal.</p>'
        browser.setHtml(text)
        return browser

    def build_checks(self):
        browser = QtWidgets.QTextBrowser()
        browser.setOpenLinks(False)
        browser.setAccessibleName("Proposal validation results")
        title = "Checks passed" if self.report["ok"] else "Saving is blocked"
        color = "#205f38" if self.report["ok"] else "#993b35"
        text = f'<h2 style="color:{color};">{title}</h2><h3>Checks performed</h3><ul>'
        text += ''.join('<li>' + html.escape(check) + '</li>' for check in self.report["checks"]) + '</ul>'
        for issue in self.report["issues"]:
            color = "#993b35" if issue["severity"] == "error" else "#996513"
            text += f'<p style="color:{color};"><b>{html.escape(issue["severity"].title())}'
            text += (' · ' + html.escape(issue["path"]) if issue.get("path") else '') + '</b><br>'
            text += html.escape(redact(issue["message"])).replace("\n", "<br>") + '</p>'
        if not self.report["issues"]:
            text += '<p>No blocking errors.</p>'
        browser.setHtml(text)
        return browser

    def filter_files(self, text):
        visible = []
        for index in range(self.file_list.topLevelItemCount()):
            item = self.file_list.topLevelItem(index)
            item.setHidden(text.casefold() not in self.files[index].path.casefold())
            if not item.isHidden():
                visible.append(item)
        current = self.file_list.currentItem()
        if current is None or current.isHidden():
            self.file_list.setCurrentItem(visible[0] if visible else None)

    def select_file(self, current, previous=None):
        self.comparison.blockSignals(True)
        self.comparison.clear()
        if current is not None:
            file = self.files[current.data(0, QtCore.Qt.UserRole)]
            self.file_title.setText(file.path)
            for index, comparison in enumerate(file.comparisons):
                self.comparison.addItem("Saved file" if index == 0 else "Unsaved editor")
                self.comparison.setItemData(index, comparison.label, QtCore.Qt.ToolTipRole)
        else:
            self.file_title.setText("No matching files")
        self.comparison.blockSignals(False)
        self.select_comparison(0)

    def select_comparison(self, index):
        current = self.file_list.currentItem()
        self.current_diff = None
        if current is not None and index >= 0:
            file_index = current.data(0, QtCore.Qt.UserRole)
            file = self.files[file_index]
            self.current_diff = self.diffs[file_index][index]
            diff = self.current_diff
            self.file_status.setText(f"{file.status} · {diff.added} added lines · {diff.removed} removed lines"
                                     + (" · comparing unsaved editor" if index else " · comparing saved file"))
            self.diff_view.set_comparison(diff)
            self.current_hunk = -1
            self.change_status.setText(f"{len(diff.hunks)} changed {'section' if len(diff.hunks) == 1 else 'sections'} · Select rows to copy with Ctrl+C"
                                       if diff.hunks else {"Added": "A new empty file will be created.",
                                                           "Deleted": "This empty file will be deleted."}.get(
                                                               file.status, "No visible content differences in this comparison."))
        else:
            self.file_status.clear()
            old_model = self.diff_view.model()
            self.diff_view.setModel(None)
            if old_model is not None:
                old_model.deleteLater()
            self.change_status.setText("Try another file name or clear the filter.")
        for button in (self.previous_change, self.next_change):
            button.setEnabled(bool(self.current_diff and self.current_diff.hunks))
        self.copy_button.setEnabled(self.current_diff is not None)

    def jump_change(self, direction):
        if self.current_diff and self.current_diff.hunks:
            self.current_hunk = ((0 if direction > 0 else len(self.current_diff.hunks) - 1)
                                 if self.current_hunk < 0 else (self.current_hunk + direction) % len(self.current_diff.hunks))
            index = self.diff_view.model().index(self.current_diff.hunks[self.current_hunk], 3)
            self.diff_view.setCurrentIndex(index)
            self.diff_view.scrollTo(index, QtWidgets.QAbstractItemView.PositionAtTop)
            self.change_status.setText(f"Changed section {self.current_hunk + 1} of {len(self.current_diff.hunks)}")

    def copy_diff(self):
        if self.current_diff:
            QtWidgets.QApplication.clipboard().setText(self.current_diff.comparison.unified_diff())

    def preview(self):
        from app.config_designer.document import DesignerDocument
        from app.config_designer.window import PreviewDialog
        config = self.controller.snapshot()["config"]
        for edit in self.proposal.edits:
            if edit.path == "app/data/config.json":
                config = json.loads(edit.content)
        PreviewDialog(DesignerDocument.from_config(config), self).exec_()

    def apply(self, reload):
        try:
            if self.controller.proposal is not self.proposal:
                raise AssistantError("STALE_PROPOSAL", "A new proposal replaced this review.")
            self.controller.apply(self.proposal.fingerprint, reload)
            self.accept()
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "Assistant", str(exc))
