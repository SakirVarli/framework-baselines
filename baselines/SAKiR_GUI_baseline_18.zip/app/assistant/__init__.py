"""Source-aware project assistant. Imported only in non-frozen authoring modes."""
