"""Compact, non-clickable usage indicator with a hover-only detail card."""
from PyQt5 import QtCore, QtGui, QtWidgets

from .appearance import apply_theme


class UsageIndicator(QtWidgets.QLabel):
    def __init__(self, parent=None, kind="usage"):
        super().__init__("", parent)
        self.kind = kind
        self.caption = "Usage" if kind == "usage" else "Context"
        self.fraction = None
        self.setMinimumHeight(24)
        self.setObjectName("usageIndicator")
        self.setTextFormat(QtCore.Qt.PlainText)
        self.setFocusPolicy(QtCore.Qt.NoFocus)
        self.setAccessibleName(self.caption + " — hover for details")
        self.setCursor(QtCore.Qt.ArrowCursor)
        self.popup = QtWidgets.QFrame(self, QtCore.Qt.ToolTip | QtCore.Qt.WindowDoesNotAcceptFocus)
        self.popup.setObjectName("usagePanel")
        self.popup.setAttribute(QtCore.Qt.WA_ShowWithoutActivating)
        self.popup.setFocusPolicy(QtCore.Qt.NoFocus)
        apply_theme(self.popup)
        self.popup.installEventFilter(self)
        self.window().installEventFilter(self)
        self.hide_timer = QtCore.QTimer(self)
        self.hide_timer.setSingleShot(True)
        self.hide_timer.setInterval(150)
        self.hide_timer.timeout.connect(self.hide_if_outside)

    def set_meter(self, text, fraction=None):
        self.caption = text
        self.fraction = fraction
        self.setAccessibleName(text + " — hover for details")
        self.updateGeometry()
        self.update()

    def sizeHint(self):
        return QtCore.QSize(self.fontMetrics().horizontalAdvance(self.caption) + 38, 26)

    def minimumSizeHint(self):
        return self.sizeHint()

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        color = "#ad3d32" if self.fraction is not None and self.fraction >= .9 else "#996513" if self.fraction is not None and self.fraction >= .75 else "#697180"
        painter.setPen(QtGui.QPen(QtGui.QColor(color), 1.6, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
        painter.save()
        painter.translate(7, (self.height() - 16) / 2)
        if self.kind == "usage":
            painter.drawArc(QtCore.QRectF(1, 2, 14, 14), 0, 180 * 16)
            painter.drawLine(QtCore.QPointF(8, 9), QtCore.QPointF(12, 5))
            painter.drawPoint(QtCore.QPointF(8, 9))
            painter.drawLine(2, 12, 14, 12)
        else:
            painter.setPen(QtGui.QPen(QtGui.QColor("#d7dce4"), 2))
            painter.drawEllipse(QtCore.QRectF(1, 1, 14, 14))
            painter.setPen(QtGui.QPen(QtGui.QColor(color), 2, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
            if self.fraction is not None:
                painter.drawArc(QtCore.QRectF(1, 1, 14, 14), 90 * 16, -round(max(0, min(1, self.fraction)) * 360 * 16))
        painter.restore()
        painter.setPen(QtGui.QColor(color))
        painter.drawText(self.rect().adjusted(30, 0, -7, 0), QtCore.Qt.AlignVCenter | QtCore.Qt.AlignLeft, self.caption)

    def show_details(self):
        if not self.isVisible():
            return
        self.hide_timer.stop()
        screen = self.screen() or QtWidgets.QApplication.primaryScreen()
        available = screen.availableGeometry().adjusted(8, 8, -8, -8)
        width = min(480, available.width())
        self.popup.resize(width, self.popup.height())
        layout = self.popup.layout()
        layout.activate()
        for scroll in self.popup.findChildren(QtWidgets.QScrollArea):
            content = scroll.widget()
            if content is None:
                continue
            content_width = max(1, scroll.width() - 2 * scroll.frameWidth())
            desired = content.heightForWidth(content_width) if content.hasHeightForWidth() else content.sizeHint().height()
            if desired > 200 and content.hasHeightForWidth():
                desired = content.heightForWidth(max(1, content_width - scroll.verticalScrollBar().sizeHint().width()))
            scroll.setFixedHeight(min(200, max(48, desired + 2)))
        layout.invalidate()
        layout.activate()
        preferred = layout.totalHeightForWidth(width) if layout.hasHeightForWidth() else layout.sizeHint().height()
        height = min(preferred, available.height())
        self.popup.resize(width, height)
        anchor = self.mapToGlobal(QtCore.QPoint(0, 0))
        x = max(available.left(), min(anchor.x() + self.width() - width, available.right() - width + 1))
        y = anchor.y() - height - 6
        if y < available.top():
            y = anchor.y() + self.height() + 6
        y = max(available.top(), min(y, available.bottom() - height + 1))
        self.popup.move(x, y)
        self.popup.show()

    def hide_if_outside(self):
        position = QtGui.QCursor.pos()
        over_label = self.rect().contains(self.mapFromGlobal(position))
        over_popup = self.popup.isVisible() and self.popup.rect().contains(self.popup.mapFromGlobal(position))
        if not over_label and not over_popup:
            self.popup.hide()

    def enterEvent(self, event):
        self.show_details()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hide_timer.start()
        super().leaveEvent(event)

    def hideEvent(self, event):
        self.hide_timer.stop()
        self.popup.hide()
        super().hideEvent(event)

    def eventFilter(self, watched, event):
        if watched is self.popup:
            if event.type() == QtCore.QEvent.Enter:
                self.hide_timer.stop()
            elif event.type() == QtCore.QEvent.Leave:
                self.hide_timer.start()
        elif event.type() in (QtCore.QEvent.Hide, QtCore.QEvent.WindowDeactivate, QtCore.QEvent.Move, QtCore.QEvent.Resize):
            self.hide_timer.stop()
            self.popup.hide()
        return super().eventFilter(watched, event)
