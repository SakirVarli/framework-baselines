"""A bounded live activity line; animation never rebuilds conversation history."""
import time
import re

from PyQt5 import QtCore, QtGui, QtWidgets


class ReasoningHeadings:
    """Recognize completed Markdown headings across streamed chunks, not prose."""
    def __init__(self):
        self.heading = None
        self._line = ""
        self._discard_line = False
        self._after_cr = False
        self._fence = None
        self._previous = None

    def feed(self, text):
        for part in re.split(r"(\r\n|\r|\n)", text):
            if part in {"\r\n", "\r", "\n"}:
                if part == "\n" and self._after_cr:
                    self._after_cr = False
                    continue
                if not self._discard_line:
                    self._complete_line(self._line)
                else:
                    self._previous = None
                self._line = ""
                self._discard_line = False
                self._after_cr = part == "\r"
            elif part:
                self._after_cr = False
                if not self._discard_line:
                    if len(self._line) + len(part) > 512:
                        self._line = ""
                        self._discard_line = True
                    else:
                        self._line += part

    def _complete_line(self, line):
        fence = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if self._fence:
            if (fence and fence[1][0] == self._fence[0] and len(fence[1]) >= self._fence[1]
                    and not fence[2].strip()):
                self._fence = None
            self._previous = None
            return
        if fence:
            self._fence = (fence[1][0], len(fence[1]))
            self._previous = None
            return
        atx = re.fullmatch(r" {0,3}#{1,6}[ \t]+(.+?)(?:[ \t]+#+)?[ \t]*", line)
        bold = re.fullmatch(r" {0,3}(?:\*\*([^*]+)\*\*|__([^_]+)__)[ \t]*", line)
        underline = re.fullmatch(r" {0,3}(?:={3,}|-{3,})[ \t]*", line)
        title = atx[1] if atx else (bold[1] or bold[2]) if bold else self._previous if underline else None
        if title and title.strip():
            self.heading = " ".join(title.split())[:160]
            self._previous = None
        else:
            stripped = line.strip()
            self._previous = stripped if stripped and len(stripped) <= 160 and not line.startswith(("    ", "\t")) else None


class ShimmerLabel(QtWidgets.QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.phase = 0.0
        self.shimmering = False
        self.setTextFormat(QtCore.Qt.PlainText)
        self.setStyleSheet("color: #697180; font-size: 9pt;")
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        self.setMinimumWidth(0)

    def sizeHint(self):
        return QtCore.QSize(440, self.fontMetrics().height() + 6)

    def minimumSizeHint(self):
        return QtCore.QSize(0, self.fontMetrics().height() + 6)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.TextAntialiasing)
        painter.setFont(self.font())
        rect = self.contentsRect()
        text = self.fontMetrics().elidedText(self.text(), QtCore.Qt.ElideRight, rect.width())
        base = QtGui.QColor("#697180")
        if self.shimmering:
            width = min(rect.width(), self.fontMetrics().horizontalAdvance(text))
            band = max(25, min(80, width // 3))
            center = rect.left() - band + (width + band * 2) * self.phase
            gradient = QtGui.QLinearGradient(center - band, 0, center + band, 0)
            gradient.setColorAt(0, base)
            gradient.setColorAt(0.5, QtGui.QColor("#c7d6eb"))
            gradient.setColorAt(1, base)
            painter.setPen(QtGui.QPen(QtGui.QBrush(gradient), 1))
        else:
            painter.setPen(base)
        painter.drawText(rect, QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter | QtCore.Qt.TextSingleLine, text)


class WorkingIndicator(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAccessibleName("Live assistant activity")
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self._running = False
        self._started = 0.0
        self._preview_kind = None
        self._reasoning_headings = ReasoningHeadings()
        self._pending_preview = False
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.phrase = ShimmerLabel()
        self.phrase.setAccessibleName("Current assistant activity")
        layout.addWidget(self.phrase, 1)
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(30)
        self.timer.timeout.connect(self.advance)
        self.hide()

    def set_running(self, running):
        if running == self._running:
            return
        self._running = running
        self.phrase.shimmering = running
        if running:
            self._started = time.monotonic()
            self.phrase.phase = 0.0
            self.set_status("Starting…")
        else:
            self.timer.stop()
            self._clear_preview()
        self.setVisible(running)
        if running and self.isVisible():
            self.timer.start()

    def _clear_preview(self):
        self._preview_kind = None
        self._pending_preview = False
        self._reasoning_headings = ReasoningHeadings()

    def _set_text(self, text):
        text = " ".join(str(text).split())
        if len(text) > 240:
            text = text[:239].rstrip() + "…"
        if self.phrase.text() != text:
            self.phrase.setText(text)
            self.phrase.setAccessibleDescription(text)
        self.setToolTip(text)
        self.phrase.setToolTip(text)

    def set_status(self, text):
        self._clear_preview()
        self._set_text(text)

    def append_model_text(self, kind, text):
        if not self._running or not isinstance(text, str) or not text:
            return
        self._preview_kind = kind
        if kind == "reasoning":
            self._reasoning_headings.feed(text)
        self._pending_preview = True

    def refresh_preview(self):
        if not self._pending_preview:
            return
        if self._preview_kind == "reasoning":
            self._set_text(self._reasoning_headings.heading or "Thinking…")
        else:
            # Ordinary content may be the final answer, whose section headings
            # describe the answer rather than the assistant's current activity.
            self._set_text(self._reasoning_headings.heading or "Preparing response…")
        self._pending_preview = False

    def advance(self):
        if not self._running or not self.isVisible():
            return
        now = time.monotonic()
        if self._pending_preview:
            self.refresh_preview()
        self.phrase.phase = ((now - self._started) % 1.8) / 1.8
        self.phrase.update()

    def showEvent(self, event):
        super().showEvent(event)
        if self._running:
            self.timer.start()

    def hideEvent(self, event):
        self.timer.stop()
        super().hideEvent(event)
