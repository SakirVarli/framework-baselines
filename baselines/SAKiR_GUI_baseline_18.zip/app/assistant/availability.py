import sys


def available(phase):
    return not getattr(sys, "frozen", False) and phase in {"baseline", "development"}
