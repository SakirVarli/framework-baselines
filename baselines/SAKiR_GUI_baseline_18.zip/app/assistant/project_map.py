"""Evidence-backed application relationships; dynamic resolution is explicitly partial."""
from collections import deque
import json

from app.utils import sanitize_func_name

from .policy import redact
from .retrieval import tokens


class ProjectMap:
    def __init__(self, index, snapshot):
        self.index, self.snapshot = index, snapshot
        self.nodes, self.edges = {}, []
        self.revision = snapshot.get("revision")
        self._build()

    def _build(self):
        application = {p: r for p, r in self.index.cache.items() if p.startswith(("callbacks/", "externals/"))}
        symbols = [s for r in application.values() for s in r["symbols"]]
        qualified = {s["qualified_name"]: s for s in symbols}
        for symbol in symbols:
            key = symbol["qualified_name"]
            self.nodes[key] = {"id": key, "kind": symbol["kind"], "name": symbol["name"],
                               "path": symbol["path"], "line": symbol["line"], "state": symbol["state"],
                               "sha256": symbol["sha256"], "content_revision": symbol["content_revision"]}
            if symbol["owner"]:
                self.edges.append({"from": symbol["owner"], "to": key, "relation": "defines", "confidence": "verified_source",
                                   "path": symbol["path"], "line": symbol["line"]})
            for base in symbol["bases"]:
                self.edges.append({"from": key, "to": base, "relation": "inherits", "confidence": "static_reference",
                                   "path": symbol["path"], "line": symbol["line"]})
            for decorator in symbol["decorators"]:
                if "LifecycleManager.on_" in decorator:
                    self.nodes[key]["lifecycle_hook"] = decorator

        for path, record in application.items():
            for declaration in record["declarations"]:
                key = declaration["owner"] + "." + declaration["name"]
                self.nodes[key] = {"id": key, "kind": "global", **declaration, "path": path, "state": record["state"]}
                self.edges.append({"from": declaration["owner"], "to": key, "relation": "declares_global",
                                   "confidence": "verified_source", "path": path, "line": declaration["line"]})

        layout = self.snapshot.get("layout_tree", [])
        for row in layout:
            properties = row.get("properties", {})
            selector = row["selector"]
            key = "widget:" + selector
            instance = properties.get("instance")
            self.nodes[key] = redact({"id": key, "selector": selector, "kind": "widget", "type": row.get("type"),
                                      "node_id": row.get("node_id"),
                                      "instance": instance, "name": properties.get("name", instance or selector),
                                      "output_kind": properties.get("output_kind"), "state": "snapshot"})
            callback = properties.get("callback")
            if not callback and row.get("type") == "button":
                callback = sanitize_func_name(properties.get("name", ""))
            if callback:
                matches = [s for s in symbols if s["path"] == "callbacks/callbacks.py" and s["name"] == callback
                           and s["owner"] is None]
                target = matches[0]["qualified_name"] if len(matches) == 1 else "unresolved:" + callback
                self.edges.append({"from": key, "to": target, "relation": "callback_binding",
                                   "confidence": "verified_config" if len(matches) == 1 else "unresolved",
                                   "selector": selector, "callback": callback,
                                   "binding_source": "explicit" if properties.get("callback") else "generated_name"})

        # Saved session definitions remain discoverable even when a tool window is closed.
        for tool, filename in (("serial", "serial.json"), ("telnet", "telnet.json"), ("communication", "communication_hub.json")):
            record = self.index.cache.get("app/data/" + filename)
            if record:
                try:
                    config = json.loads(record["text"])
                except ValueError:
                    continue
                if not isinstance(config, dict):
                    continue
                workspace = config.get("workspace", {})
                sessions = workspace.get("sessions", config.get("sessions", [])) if isinstance(workspace, dict) else config.get("sessions", [])
                for session in sessions if isinstance(sessions, list) else []:
                    if isinstance(session, dict) and session.get("name"):
                        key = f"session:{tool}:{session['name']}"
                        self.nodes[key] = {"id": key, "kind": "session", "tool": tool, "name": session["name"],
                                           "running": None, "state": "saved", "path": record["path"],
                                           "content_revision": record["content_revision"]}

        for path, record in application.items():
            module = path.removesuffix(".py").replace("/", ".")
            imports = record["imports"]
            for call in record["calls"]:
                name = call["target"]
                candidate = module + "." + name
                # Lexical resolution is a candidate: local reassignment/subclass dispatch may override it.
                for imported in imports:
                    if imported["scope"] not in (None, call["caller"]):
                        continue
                    alias = imported["alias"]
                    if name == alias or name.startswith(alias + "."):
                        base = imported["module"]
                        if base.startswith("."):
                            dots = len(base) - len(base.lstrip("."))
                            package = module.split(".")[:-dots]
                            base = ".".join(package + [base.lstrip(".")]).rstrip(".")
                        imported_name = imported.get("name")
                        if imported_name and imported_name != "*":
                            base += "." + imported_name
                        elif not imported_name and "." in imported["module"] and alias == imported["module"].split(".")[0]:
                            base = alias
                        candidate = base + name[len(alias):]
                if name.startswith("self."):
                    candidate = call["caller"].rsplit(".", 1)[0] + name[4:]
                resolved = candidate in qualified
                self.edges.append({"from": call["caller"], "to": candidate if resolved else "unresolved:" + name,
                                   "relation": "calls", "confidence": "static_candidate" if resolved else "unresolved",
                                   "path": path, "line": call["line"], "expression": name})
                arguments = call["arguments"]
                literal = arguments[0] if arguments else call.get("keywords", {}).get("instance")
                if name == "display" or candidate == "app.stubs.display":
                    targets = [n for n in self.nodes.values() if n.get("kind") == "widget" and literal is not None
                               and n.get("instance") == literal]
                    for target in targets:
                        self.edges.append({"from": call["caller"], "to": target["id"], "relation": "output_reference",
                                           "confidence": "static_literal", "path": path, "line": call["line"]})
                    if not targets:
                        self.edges.append({"from": call["caller"], "to": "unresolved:output", "relation": "output_reference",
                                           "confidence": "unresolved", "path": path, "line": call["line"],
                                           "reason": "Output target is computed or not configured in this snapshot."})
                if name.startswith("Tools.") and ".session" in name:
                    tool = name.split(".")[1]
                    key = f"session:{tool}:{literal}"
                    runtime_match = any(s.get("name") == literal for s in self.snapshot.get("runtime", {}).get(tool, {}).get("sessions", []))
                    if key in self.nodes or runtime_match:
                        self.edges.append({"from": call["caller"], "to": key, "relation": "session_reference",
                                           "confidence": "static_literal", "path": path, "line": call["line"]})

        for tool, runtime in self.snapshot.get("runtime", {}).items():
            for session in runtime.get("sessions", []):
                key = f"session:{tool}:{session.get('name', '')}"
                self.nodes[key] = {"id": key, "kind": "session", "tool": tool, "name": session.get("name"),
                                   "running": session.get("running"), "state": "runtime_snapshot"}
        manifest = self.snapshot.get("message_manifest")
        if manifest is not None:
            self.nodes["message_library"] = {"id": "message_library", "kind": "message_library",
                                            "path": self.snapshot.get("message_library_path"),
                                            "properties_pending": self.snapshot.get("message_properties_pending", False)}

    def summary(self, limit=40):
        widgets = [n for n in self.nodes.values() if n["kind"] == "widget"]
        bindings = [e for e in self.edges if e["relation"] == "callback_binding"]
        return redact({"revision": self.revision, "selection": self.snapshot.get("selection"),
                       "selected_nodes": self.snapshot.get("selected_nodes", []),
                       "widgets": widgets[:limit], "callback_bindings": bindings[:limit],
                       "modules": sorted({n["path"] for n in self.nodes.values() if n.get("path")})[:limit],
                       "sessions": [n for n in self.nodes.values() if n["kind"] == "session"][:limit],
                       "globals": [n for n in self.nodes.values() if n["kind"] == "global"][:limit],
                       "lifecycle_hooks": [n for n in self.nodes.values() if n.get("lifecycle_hook")][:limit],
                       "node_count": len(self.nodes), "relationship_count": len(self.edges),
                       "truncated": len(widgets) > limit or len(bindings) > limit or len(self.nodes) > limit,
                       "limitation": "Static call targets are candidates; dynamic dispatch and computed names may be unresolved."})

    def relevant(self, request):
        selected = set(self.snapshot.get("selected_nodes", []))
        wording = set(tokens(request + " " + str(self.snapshot.get("selection", ""))))
        seeds = []
        for key, node in self.nodes.items():
            if node.get("node_id") in selected or (node["kind"] == "widget" and
                set(tokens(str(node.get("name", "")) + " " + str(node.get("instance") or ""))) & wording):
                seeds.append(key)
        return [self.related(key, 16) for key in seeds[:2]]

    def related(self, identifier, limit=40):
        limit = max(1, min(100, int(limit)))
        seeds = [key for key, node in self.nodes.items() if identifier in
                 (key, node.get("selector"), node.get("instance"), node.get("name"))]
        if not seeds:
            return {"revision": self.revision, "nodes": [], "relationships": [], "unresolved": identifier,
                    "truncated": False}
        visited, queue, edges, seen = set(seeds), deque((s, 0) for s in seeds), [], set()
        while queue and len(edges) < limit:
            key, depth = queue.popleft()
            if depth >= 4:
                continue
            for i, edge in enumerate(self.edges):
                if i in seen or (edge["from"] != key and edge["to"] != key):
                    continue
                seen.add(i)
                edges.append(edge)
                target = edge["to"] if edge["from"] == key else edge["from"]
                if target not in visited:
                    visited.add(target)
                    queue.append((target, depth+1))
                if len(edges) >= limit:
                    break
        return redact({"revision": self.revision, "nodes": [n for k, n in self.nodes.items() if k in visited][:limit],
                       "relationships": edges, "truncated": bool(queue) or len(edges) >= limit,
                       "limitation": "Inferred calls and literal references are not proof of runtime dispatch."})
