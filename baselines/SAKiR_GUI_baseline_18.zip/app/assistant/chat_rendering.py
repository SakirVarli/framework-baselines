"""Bounded Markdown work and cached formatting for completed chat messages."""
from functools import lru_cache
import html
import re

try:
    import markdown2
except ImportError:
    markdown2 = None


MAX_MARKDOWN_CHARS = 32_000


def message_html(role, content):
    # Partial Markdown can be expensive and malformed. Format once when final.
    if role == "pending":
        return _format(role, content, markdown=False)
    return _completed_message_html(role, content)


@lru_cache(maxsize=128)
def _completed_message_html(role, content):
    return _format(role, content, markdown=True)


def _format(role, content, markdown):
    text = "<pre>" + html.escape(content) + "</pre>"
    if markdown and markdown2 is not None and len(content) <= MAX_MARKDOWN_CHARS:
        try:
            text = markdown2.markdown(content, safe_mode="escape", extras=["fenced-code-blocks", "tables"])
            text = re.sub(r"<img\b[^>]*>", "", text, flags=re.I)
        except Exception:
            pass  # A formatting error must not interrupt the GUI's event loop.
    text = re.sub(r"<pre\b[^>]*>.*?</pre>",
                  lambda match: '<table width="100%" cellspacing="0" cellpadding="12" bgcolor="#f3f5f8">'
                  '<tr><td style="padding:12px;">' + match.group() + '</td></tr></table>', text, flags=re.S | re.I)
    name = {"user": "You", "assistant": "SAKiR", "pending": "SAKiR · response in progress",
            "error": "Something went wrong"}.get(role, role.title())
    background = ' bgcolor="#f2f4f7"' if role == "user" else ""
    color = "#b43c32" if role == "error" else "#697180"
    return ('<table width="100%" cellspacing="0" cellpadding="14"' + background + '><tr><td style="padding:14px;">'
            + '<p style="color:' + color + '; font-size:9pt;"><b>' + html.escape(name) + "</b></p>" + text
            + "</td></tr></table><p style='font-size:6pt;'>&nbsp;</p>")
