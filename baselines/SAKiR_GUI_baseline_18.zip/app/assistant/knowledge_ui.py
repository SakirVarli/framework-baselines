"""Offline knowledge coverage and source browser, with background index refresh."""
import threading

from PyQt5 import QtCore, QtGui, QtWidgets


class KnowledgeDialog(QtWidgets.QDialog):
    loaded = QtCore.pyqtSignal(object)

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.index = None
        self.loading = False
        self.closed = threading.Event()
        self.setWindowTitle("Framework Capabilities and Project Understanding")
        self.resize(1000, 720)
        outer = QtWidgets.QVBoxLayout(self)
        row = QtWidgets.QHBoxLayout()
        self.status = QtWidgets.QLabel("Loading local knowledge…")
        self.status.setWordWrap(True)
        row.addWidget(self.status, 1)
        self.refresh_button = QtWidgets.QPushButton("Refresh")
        self.refresh_button.clicked.connect(self.refresh)
        row.addWidget(self.refresh_button)
        outer.addLayout(row)
        self.details = QtWidgets.QLabel()
        self.details.setWordWrap(True)
        self.details.setTextFormat(QtCore.Qt.PlainText)
        outer.addWidget(self.details)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Filter qualified symbols, handbook topics and source paths…")
        self.search.textChanged.connect(self.filter_items)
        outer.addWidget(self.search)
        splitter = QtWidgets.QSplitter()
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["Capability / topic", "Source"])
        self.source = QtWidgets.QPlainTextEdit()
        self.source.setReadOnly(True)
        self.source.setFont(QtGui.QFont("Consolas", 10))
        splitter.addWidget(self.tree)
        splitter.addWidget(self.source)
        outer.addWidget(splitter, 1)
        self.tree.itemClicked.connect(self.selected)
        self.loaded.connect(self.populate)
        self.finished.connect(lambda _: self.closed.set())
        self.refresh()

    def refresh(self):
        if self.loading:
            return
        self.loading = True
        self.refresh_button.setEnabled(False)
        self.status.setText("Indexing saved source and current designer state…")
        try:
            snapshot = self.controller.snapshot()
        except Exception as exc:
            self.populate({"error": str(exc)})
            return

        def worker():
            try:
                index = self.controller.index.for_snapshot(snapshot)
                result = {"index": index, "catalog": index.catalog(), "coverage": index.coverage()}
            except Exception as exc:
                result = {"error": str(exc)}
            if not self.closed.is_set():
                try:
                    self.loaded.emit(result)
                except RuntimeError:
                    pass  # The owning window can be disposed during an index refresh.
        threading.Thread(target=worker, name="sakir-knowledge-browser", daemon=True).start()

    @QtCore.pyqtSlot(object)
    def populate(self, result):
        self.loading = False
        self.refresh_button.setEnabled(True)
        if result.get("error"):
            self.status.setText("Knowledge refresh failed: " + result["error"])
            return
        self.index = result["index"]
        coverage = result["coverage"]
        self.status.setText(f"{coverage['files']} files · {coverage['symbols']} symbols · {coverage['help_topics']} handbook topics")
        omitted = [name for name, present in coverage["optional_material"].items() if not present]
        details = ["Revision: " + coverage["generation"][:12],
                   "Unsaved overlays: " + (", ".join(coverage["unsaved_paths"]) or "none"),
                   "Optional material absent: " + (", ".join(omitted) or "none")]
        details.extend(f"{d['path']}: {d['message']}" for d in coverage["diagnostics"][:5])
        if len(coverage["diagnostics"]) > 5 or coverage["diagnostics_truncated"]:
            details.append("More skipped-source diagnostics are available through get_index_coverage.")
        details.append("Static relationships can be incomplete. Index coverage does not guarantee an answer is correct.")
        self.details.setText("\n".join(details))
        self.tree.clear()
        catalog = result["catalog"]
        groups = list(catalog["groups"].items()) + [("Project callbacks and helpers", "project")]
        for name, path in groups:
            top = QtWidgets.QTreeWidgetItem(self.tree, [name, path])
            for entry in catalog["symbols"]:
                matches = entry["path"].startswith(("callbacks/", "externals/")) if path == "project" else entry["path"].startswith(path)
                if matches:
                    item = QtWidgets.QTreeWidgetItem(top, [entry["qualified_name"] + " — " + entry["full_signature"],
                                                          entry["path"] + ":" + str(entry["line"])])
                    item.setData(0, QtCore.Qt.UserRole, entry)
        help_group = QtWidgets.QTreeWidgetItem(self.tree, ["Bundled handbook", "app/data/help.json"])
        for section, entry in self.index.handbook.sections.items():
            item = QtWidgets.QTreeWidgetItem(help_group, [" / ".join(entry["ancestry"] + [entry["title"]]), section])
            item.setData(0, QtCore.Qt.UserRole, {"section_id": section})
        self.filter_items(self.search.text())

    def selected(self, item, column=0):
        entry = item.data(0, QtCore.Qt.UserRole)
        if not entry or self.index is None:
            return
        try:
            if "section_id" in entry:
                data = self.index.read_help(entry["section_id"])
            else:
                data = self.index.read(entry["path"], entry["line"], 250)
            self.source.setPlainText(data["text"] + ("\n\n[More content available through paginated knowledge tools.]" if data["truncated"] else ""))
        except Exception as exc:
            self.source.setPlainText(str(exc))

    def filter_items(self, text):
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            visible = False
            for j in range(top.childCount()):
                item = top.child(j)
                match = text.casefold() in (item.text(0) + item.text(1)).casefold()
                item.setHidden(not match)
                visible |= match
            top.setHidden(not visible and text.casefold() not in top.text(0).casefold())
            top.setExpanded(bool(text))
