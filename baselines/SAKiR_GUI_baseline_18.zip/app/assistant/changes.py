"""Immutable proposals and recoverable multi-file commits. No model-facing commit tool."""
import ast
import base64
from contextlib import contextmanager
from dataclasses import dataclass
import difflib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import uuid

from .policy import AssistantError, digest, file_hash, redact
from .storage import atomic_json


@dataclass(frozen=True)
class Edit:
    path: str
    content: str | None
    expected_sha256: str | None


@dataclass(frozen=True)
class Proposal:
    id: str
    summary: str
    edits: tuple
    context_revision: str

    @property
    def fingerprint(self):
        return digest({"id": self.id, "summary": self.summary, "revision": self.context_revision,
                       "edits": [e.__dict__ for e in self.edits]})


@dataclass(frozen=True)
class ReviewComparison:
    label: str
    before: str
    after: str
    fromfile: str
    tofile: str

    def unified_diff(self):
        lines = difflib.unified_diff(self.before.splitlines(True), self.after.splitlines(True),
                                     fromfile=self.fromfile, tofile=self.tofile)
        # Keep adjacent rows separate even when an input has no final newline.
        return "".join(line if line.endswith("\n") else line + "\n\\ No newline at end of file\n" for line in lines)


@dataclass(frozen=True)
class ReviewFile:
    path: str
    status: str
    comparisons: tuple


def prepare(policy, edits, snapshot, summary):
    staged = {}
    for item in edits:
        path = policy.path(item["path"], write=True)
        relative = path.relative_to(policy.root).as_posix()
        if relative in staged:
            raise AssistantError("VALIDATION_FAILED", "A file appears more than once.")
        expected = item.get("expected_sha256")
        if expected != file_hash(path):
            raise AssistantError("FILE_CHANGED", f"Read the current {relative} before proposing an edit.")
        if "replacements" in item:
            if "content" in item or not path.is_file():
                raise AssistantError("INVALID_ARGUMENTS", "Targeted replacements require an existing file and no full content field.")
            content = path.read_text(encoding="utf-8")
            for replacement in item["replacements"]:
                old, new = replacement["old_text"], replacement["new_text"]
                if not old or content.count(old) != 1:
                    raise AssistantError("FILE_CHANGED", "Each replacement must match exactly one existing source fragment.")
                if "<redacted>" in old or "<redacted>" in new:
                    raise AssistantError("PATH_DENIED", "Do not edit redacted source fragments.")
                content = content.replace(old, new, 1)
        elif "content" in item:
            content = item["content"]
            if "<redacted>" in content and (not path.exists() or "<redacted>" not in path.read_text(encoding="utf-8")) and not relative.startswith("app/data/"):
                raise AssistantError("PATH_DENIED", "Use targeted replacements to preserve redacted values in source files.")
        else:
            raise AssistantError("INVALID_ARGUMENTS", "Provide full content or targeted replacements.")
        if len(content.encode("utf-8")) > 1_000_000 or "\x00" in content:
            raise AssistantError("VALIDATION_FAILED", "File content exceeds the editing limit.")
        # A JSON read is redacted. Restore existing protected values only when the
        # model preserved the redaction marker; actual credential changes are denied.
        if relative.startswith("app/data/"):
            before = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            value = json.loads(content)
            def restore(candidate, original):
                if isinstance(candidate, dict) and isinstance(original, dict):
                    for key in candidate:
                        if candidate[key] == "<redacted>" and key in original:
                            candidate[key] = original[key]
                        else:
                            restore(candidate[key], original.get(key))
                elif isinstance(candidate, list) and isinstance(original, list):
                    def identity(item):
                        return (item.get("id") or item.get("instance") or item.get("name")) if isinstance(item, dict) else None
                    originals = {identity(item): item for item in original if identity(item)}
                    for index, item in enumerate(candidate):
                        before_item = originals.get(identity(item)) if identity(item) else original[index] if index < len(original) else None
                        restore(item, before_item)
            restore(value, before)
            policy.validate_config(path, value, before)
            content = json.dumps(value, indent=4, ensure_ascii=False) + "\n"
        staged[relative] = Edit(relative, content, expected)
    # Include pre-existing unsaved designer work explicitly in the reviewed diff.
    for path, key in (("app/data/config.json", "config"), ("callbacks/callbacks.py", "callbacks")):
        if path not in staged:
            content = json.dumps(snapshot[key], indent=4, ensure_ascii=False) + "\n" if key == "config" else snapshot[key]
            target = policy.path(path, write=True)
            saved = target.read_text(encoding="utf-8") if target.exists() else ""
            equal = json.loads(saved or "{}") == snapshot[key] if key == "config" else saved == content
            if not equal:
                staged[path] = Edit(path, content, snapshot["hashes"].get(path))
    if not staged:
        raise AssistantError("VALIDATION_FAILED", "No changes were proposed.")
    return Proposal(uuid.uuid4().hex, summary, tuple(staged.values()), snapshot["revision"])


def validate(policy, proposal, snapshot):
    issues = []
    config = snapshot["config"]
    callbacks = snapshot["callbacks"]
    candidate_paths = {e.path for e in proposal.edits}
    for edit in proposal.edits:
        try:
            target = policy.path(edit.path, write=True)
            if file_hash(target) != edit.expected_sha256:
                raise AssistantError("FILE_CHANGED", "File changed after preview.")
            if edit.content is None:
                continue
            if target.suffix == ".py":
                tree = ast.parse(edit.content, filename=edit.path)
                compile(tree, edit.path, "exec")
                for node in ast.walk(tree):
                    names = ([a.name.split(".")[0] for a in node.names] if isinstance(node, ast.Import)
                             else [node.module.split(".")[0]] if isinstance(node, ast.ImportFrom) and node.module and not node.level else [])
                    for name in names:
                        if name in sys.stdlib_module_names or name in {"app", "callbacks", "externals"}:
                            continue
                        if name + ".py" in candidate_paths or (policy.root / (name + ".py")).exists():
                            continue
                        if importlib.util.find_spec(name) is None:
                            issues.append({"severity": "error", "path": edit.path, "message": f"Missing dependency: {name}"})
            if target.suffix == ".json":
                value = json.loads(edit.content)
                if edit.path.startswith("app/data/"):
                    before = json.loads(target.read_text(encoding="utf-8")) if target.exists() else {}
                    policy.validate_config(target, value, before)
            if edit.path == "app/data/config.json":
                config = json.loads(edit.content)
            if edit.path == "callbacks/callbacks.py":
                callbacks = edit.content
                old_tree = ast.parse(snapshot["callbacks"])
                new_tree = ast.parse(callbacks)
                def imports_stubs(tree):
                    return any(isinstance(n, ast.ImportFrom) and n.module == "app.stubs" and any(a.name == "*" for a in n.names) for n in tree.body)
                if imports_stubs(old_tree) and not imports_stubs(new_tree):
                    raise AssistantError("VALIDATION_FAILED", "Preserve the required from app.stubs import * API import.")
                for old in old_tree.body:
                    if isinstance(old, ast.ClassDef) and old.name == "Globals" and any(isinstance(b, ast.Name) and b.id == "GlobalsBase" for b in old.bases):
                        new = next((n for n in new_tree.body if isinstance(n, ast.ClassDef) and n.name == "Globals"), None)
                        init = next((n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == "init_globals"), None) if new else None
                        if new is None or not any(isinstance(b, ast.Name) and b.id == "GlobalsBase" for b in new.bases) or init is None or len(init.args.args) != 1:
                            raise AssistantError("VALIDATION_FAILED", "Preserve Globals(GlobalsBase) and init_globals(self).")
        except Exception as exc:
            issues.append({"severity": "error", "path": edit.path, "message": str(exc)})
    try:
        from app.config_designer.document import DesignerDocument
        from app.config_designer.validation import validate_document
        from app.stub_generator import render_stubs
        document = DesignerDocument.from_config(config)
        for issue in validate_document(document, callbacks, str(policy.root)):
            issues.append({"severity": issue.severity, "path": "app/data/config.json", "message": issue.message})
        render_stubs(config)
    except Exception as exc:
        issues.append({"severity": "error", "path": "app/data/config.json", "message": str(exc)})
    if proposal.context_revision != snapshot["revision"]:
        issues.append({"severity": "error", "message": "Unsaved designer or runtime context changed. Prepare a new proposal."})
    return {"ok": not any(i["severity"] == "error" for i in issues), "issues": issues,
            "checks": ["Path permissions", "File revisions", "Python syntax (no execution)",
                       "Dependencies", "Layout and callback references", "Generated stub rendering"]}


def review_files(policy, proposal, snapshot=None):
    files = []
    for edit in proposal.edits:
        target = policy.path(edit.path, write=True)
        before = target.read_text(encoding="utf-8") if target.exists() else ""
        after = redact(edit.content or "")
        comparisons = [ReviewComparison("Saved file → Proposed", redact(before), after, edit.path, edit.path)]
        if snapshot:
            working = None
            if edit.path == "callbacks/callbacks.py":
                working = snapshot["callbacks"]
            elif edit.path == "app/data/config.json":
                working = json.dumps(snapshot["config"], indent=4, ensure_ascii=False) + "\n"
                before = json.dumps(json.loads(before), indent=4, ensure_ascii=False) + "\n"
            elif edit.path == snapshot.get("message_library_path"):
                working = json.dumps(snapshot["message_manifest"], indent=4, ensure_ascii=False) + "\n"
                before = json.dumps(json.loads(before), indent=4, ensure_ascii=False) + "\n"
            if working is not None and working != before:
                comparisons.append(ReviewComparison("Unsaved editor → Proposed", redact(working), after,
                                                    edit.path + " (unsaved)", edit.path + " (proposal)"))
        status = "Deleted" if edit.content is None else "Added" if not target.exists() else "Modified"
        files.append(ReviewFile(edit.path, status, tuple(comparisons)))
    return files


def diff(policy, proposal, snapshot=None):
    parts = []
    for file in review_files(policy, proposal, snapshot):
        for index, comparison in enumerate(file.comparisons):
            if index:
                parts.append("\n--- Existing unsaved working state compared with proposal ---\n")
            parts.append(comparison.unified_diff())
    return "".join(parts)


def replace_bytes(target, data):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, filename = tempfile.mkstemp(prefix=".sakir-write-", dir=target.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(filename, target)
    finally:
        if os.path.exists(filename):
            os.unlink(filename)


class Transactions:
    def __init__(self, policy, store):
        self.policy, self.store = policy, store
        self.folder = store.private / "transactions"
        self.folder.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def lock(self):
        with (self.folder / "project.lock").open("a+b") as stream:
            stream.seek(0)
            if os.name == "nt":
                import msvcrt
                if not stream.read(1):
                    stream.write(b"0")
                    stream.flush()
                stream.seek(0)
                try:
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                except OSError:
                    raise AssistantError("PROJECT_BUSY", "Another assistant transaction is active.") from None
                try:
                    yield
                finally:
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                try:
                    yield
                finally:
                    fcntl.flock(stream, fcntl.LOCK_UN)

    def commit(self, proposal, approved_digest):
        if approved_digest != proposal.fingerprint:
            raise AssistantError("APPROVAL_INVALID", "The proposal changed after approval.")
        with self.lock():
            entries = []
            for edit in proposal.edits:
                target = self.policy.path(edit.path, write=True)
                if file_hash(target) != edit.expected_sha256:
                    raise AssistantError("FILE_CHANGED", f"{edit.path} changed after preview.")
                entries.append({"path": edit.path, "before": base64.b64encode(target.read_bytes()).decode() if target.exists() else None,
                                "after": base64.b64encode(edit.content.encode("utf-8")).decode() if edit.content is not None else None,
                                "after_hash": digest(edit.content.encode("utf-8")) if edit.content is not None else None})
            journal_path = self.folder / f"{proposal.id}.json"
            journal = {"id": proposal.id, "status": "applying", "entries": entries}
            atomic_json(journal_path, journal)
            try:
                for entry in entries:
                    target = self.policy.path(entry["path"], write=True)
                    before_hash = digest(base64.b64decode(entry["before"])) if entry["before"] is not None else None
                    if file_hash(target) != before_hash:
                        raise AssistantError("FILE_CHANGED", "A file changed while saving.")
                    if entry["after"] is None:
                        target.unlink(missing_ok=True)
                    else:
                        replace_bytes(target, base64.b64decode(entry["after"]))
            except BaseException:
                self._restore(journal, journal_path)
                raise
            journal["status"] = "saved"
            atomic_json(journal_path, journal)
            return proposal.id

    def _restore(self, journal, journal_path):
        # Preflight every path before restoring any; retain the journal on conflicts.
        for entry in journal["entries"]:
            target = self.policy.path(entry["path"], write=True)
            before_hash = digest(base64.b64decode(entry["before"])) if entry["before"] is not None else None
            if file_hash(target) not in {before_hash, entry["after_hash"]}:
                raise AssistantError("RECOVERY_CONFLICT", f"Preserve external edits in {entry['path']}; recovery journal: {journal_path}")
        for entry in reversed(journal["entries"]):
            target = self.policy.path(entry["path"], write=True)
            if entry["before"] is None:
                target.unlink(missing_ok=True)
            else:
                replace_bytes(target, base64.b64decode(entry["before"]))
        journal["status"] = "restored"
        atomic_json(journal_path, journal)

    def recover(self):
        restored = []
        with self.lock():
            for path in self.folder.glob("*.json"):
                journal = json.loads(path.read_text(encoding="utf-8"))
                if journal["status"] == "applying":
                    self._restore(journal, path)
                    restored.append(journal["id"])
        return restored

    def undo_proposal(self, transaction_id, snapshot):
        journal = json.loads((self.folder / f"{transaction_id}.json").read_text(encoding="utf-8"))
        if journal["status"] != "saved":
            raise AssistantError("UNDO_UNAVAILABLE", "This transaction is not saved.")
        edits = []
        for entry in journal["entries"]:
            target = self.policy.path(entry["path"], write=True)
            if file_hash(target) != entry["after_hash"]:
                raise AssistantError("FILE_CHANGED", f"{entry['path']} changed since Apply; restore needs a new proposal.")
            if entry["before"] is None:
                content = None
            else:
                content = base64.b64decode(entry["before"]).decode("utf-8")
            edits.append(Edit(entry["path"], content, entry["after_hash"]))
        return Proposal(uuid.uuid4().hex, "Restore previous contents and remove newly created files", tuple(edits), snapshot["revision"])
