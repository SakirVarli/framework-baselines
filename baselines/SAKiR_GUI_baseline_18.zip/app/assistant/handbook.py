"""Read-only access to the one bundled handbook, independent of private file access."""
from html.parser import HTMLParser
import json
import re
import stat
import threading

from .policy import AssistantError, digest, redact
from .retrieval import LexicalIndex


class PlainHelp(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.links = [], []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.hidden += 1
        if self.hidden:
            return
        if tag in {"p", "div", "pre", "tr", "li", "h1", "h2", "h3", "h4", "br"}:
            self.parts.append("\n")
        if tag in {"td", "th"}:
            self.parts.append("\t")
        if tag == "a":
            href = dict(attrs).get("href", "")
            if href.startswith("#"):
                self.links.append(href[1:])

    def handle_endtag(self, tag):
        if tag in {"script", "style"}:
            self.hidden = max(0, self.hidden-1)
        if not self.hidden and tag in {"p", "div", "pre", "tr", "li", "h1", "h2", "h3", "h4"}:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


class HandbookIndex:
    def __init__(self, policy):
        self.policy = policy
        self.sha256 = None
        self.sections = {}
        self.records = []
        self.diagnostics = []
        self.lexical = LexicalIndex([])
        self.lock = threading.RLock()

    def raw(self):
        path = self.policy.root / "app/data/help.json"
        # A fixed resource exception, never an exception for arbitrary model paths.
        for item in (path, path.parent, path.parent.parent):
            if item.exists() or item.is_symlink():
                attrs = item.lstat()
                if item.is_symlink() or getattr(attrs, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 1024):
                    raise AssistantError("PATH_DENIED", "Handbook links/junctions are not supported.")
        if path.stat().st_size > 2_000_000:
            raise AssistantError("FILE_TOO_LARGE", "Handbook exceeds the indexing limit.")
        return path.read_bytes()

    def refresh(self):
        with self.lock:
            self._refresh()

    def _refresh(self):
        try:
            raw = self.raw()
            stamp = digest(raw)
        except (OSError, AssistantError) as exc:
            self.sections, self.records = {}, []
            self.sha256 = None
            self.diagnostics = [{"path": "app/data/help.json", "message": str(exc), "kind": "handbook"}]
            self.lexical = LexicalIndex([])
            return
        if stamp == self.sha256:
            return
        self.sha256, self.sections, self.records, self.diagnostics = stamp, {}, [], []
        try:
            document = json.loads(raw.decode("utf-8-sig"))
            if not isinstance(document, dict) or not isinstance(document.get("topics"), list):
                raise ValueError("Expected a handbook object with a topics list.")

            def visit(topics, ancestry=(), depth=0):
                if depth > 40:
                    raise ValueError("Handbook topic nesting exceeds 40 levels.")
                for topic in topics:
                    if not isinstance(topic, dict):
                        raise ValueError("Expected a topic object.")
                    section = topic.get("id", "")
                    if not isinstance(section, str) or not re.fullmatch(r"[\w.-]{1,100}", section):
                        raise ValueError("Invalid handbook section ID.")
                    if section in self.sections:
                        raise ValueError("Duplicate handbook section ID: " + section)
                    title = redact(str(topic.get("title", section)))
                    parser = PlainHelp()
                    parser.feed(str(topic.get("body_html", "")))
                    body = redact(re.sub(r"\n{3,}", "\n\n", "".join(parser.parts)).strip())
                    item = {"section_id": section, "title": title, "ancestry": list(ancestry),
                            "path": "app/data/help.json", "sha256": stamp, "content_revision": stamp,
                            "source_kind": "handbook", "state": "saved", "links": parser.links,
                            "citation": "sakir-help:" + section, "text": body}
                    self.sections[section] = item
                    for offset in range(0, max(1, len(body)), 1400):
                        self.records.append({**item, "id": f"help:{section}:{offset}",
                                             "definition_id": "help:" + section,
                                             "text": body[max(0, offset-150):offset+1550]})
                    children = topic.get("children", [])
                    if not isinstance(children, list):
                        raise ValueError("Expected topic children list.")
                    visit(children, (*ancestry, title), depth+1)
            visit(document["topics"])
        except (ValueError, UnicodeError, RecursionError) as exc:
            self.sections, self.records = {}, []
            self.diagnostics = [{"path": "app/data/help.json", "message": str(exc), "kind": "handbook"}]
        self.lexical = LexicalIndex(self.records)

    def search(self, query, limit=10):
        return self.lexical.search(query, limit)

    def read(self, section_id, offset=0, count=6000):
        if section_id not in self.sections:
            raise AssistantError("SECTION_NOT_FOUND", "Unknown handbook section ID.")
        item = self.sections[section_id]
        text = item["text"]
        offset, count = max(0, int(offset)), max(1, min(12000, int(count)))
        return {**item, "text": text[offset:offset+count], "offset": offset, "total_chars": len(text),
                "truncated": offset+count < len(text), "next_offset": offset+count if offset+count < len(text) else None}
