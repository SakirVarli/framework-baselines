"""Bounded, sanitized snapshots used only for display, never model history."""
import copy
import json

from .policy import redact


def snapshot(value, limit=64000):
    value = redact(value)
    if (isinstance(value, dict) and set(value) == {"preview", "display_truncated"}
            and value["display_truncated"] is True and isinstance(value["preview"], str)
            and len(value["preview"]) <= limit):
        return copy.deepcopy(value)
    encoded = json.dumps(value, ensure_ascii=False, default=str)
    if len(encoded) > limit:
        return {"preview": encoded[:limit], "display_truncated": True}
    return copy.deepcopy(value)
