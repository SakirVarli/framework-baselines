from PyQt5 import QtCore, QtWidgets


class _SnapSplitterHandle(QtWidgets.QSplitterHandle):
    def mousePressEvent(self, event):
        splitter = self.splitter()
        splitter._active_handle_index = splitter.indexOf(self)
        splitter._active_handle_pos = splitter._event_axis_pos(self.mapTo(splitter, event.pos()))
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        splitter = self.splitter()
        splitter._active_handle_index = splitter.indexOf(self)
        splitter._active_handle_pos = splitter._event_axis_pos(self.mapTo(splitter, event.pos()))
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        splitter = self.splitter()
        splitter._grid._clear_snap_lock(splitter)
        splitter._active_handle_index = None
        splitter._active_handle_pos = None
        super().mouseReleaseEvent(event)


class _SnapSplitter(QtWidgets.QSplitter):
    def __init__(self, orientation, grid, role, parent=None):
        super().__init__(orientation, parent)
        self._grid = grid
        self._role = role
        self._active_handle_index = None
        self._active_handle_pos = None
        self.setChildrenCollapsible(False)
        self.splitterMoved.connect(self._on_splitter_moved)

    def createHandle(self):
        return _SnapSplitterHandle(self.orientation(), self)

    def _event_axis_pos(self, point):
        return point.x() if self.orientation() == QtCore.Qt.Horizontal else point.y()

    def _on_splitter_moved(self, pos, index):
        self._grid._handle_splitter_moved(self, pos, index)


class SplitterGrid(QtWidgets.QWidget):
    def __init__(self, rows, cols, parent=None, snap_enabled=True, snap_threshold=10, unlock_threshold=18):
        super().__init__(parent)

        self._cells = {}
        self._row_splitters = []
        self._snap_enabled = snap_enabled
        self._snap_threshold = int(snap_threshold)
        self._unlock_threshold = max(int(unlock_threshold), self._snap_threshold + 1)
        self._snap_lock = None
        self._syncing_snap = False
        self._vsplit = _SnapSplitter(QtCore.Qt.Vertical, self, "rows", self)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.addWidget(self._vsplit)

        for row in range(rows):
            hsplit = _SnapSplitter(QtCore.Qt.Horizontal, self, "cols")
            self._row_splitters.append(hsplit)

            for col in range(cols):
                placeholder = self._make_placeholder()
                hsplit.addWidget(placeholder)
                self._cells[(row, col)] = placeholder
                hsplit.setStretchFactor(col, 1)

            self._vsplit.addWidget(hsplit)
            self._vsplit.setStretchFactor(row, 1)

    @property
    def rows(self):
        return self._vsplit.sizes()

    @property
    def cols(self):
        return [splitter.sizes() for splitter in self._row_splitters]

    def addWidget(self, widget, row, col):
        assert 0 <= row < len(self._row_splitters)
        assert 0 <= col < self._row_splitters[row].count()

        old = self._cells.get((row, col))
        if old is not None:
            old.setParent(None)
            old.deleteLater()

        hsplit = self._row_splitters[row]
        hsplit.insertWidget(col, widget)
        self._cells[(row, col)] = widget
        self._set_equal_stretch(hsplit)

    def takeWidget(self, row, col):
        widget = self._cells.get((row, col))
        if widget is None:
            return None

        hsplit = self._row_splitters[row]
        idx = hsplit.indexOf(widget)
        placeholder = self._make_placeholder()

        widget.setParent(None)
        hsplit.insertWidget(idx, placeholder)
        self._cells[(row, col)] = placeholder
        self._set_equal_stretch(hsplit)
        return widget

    def removeWidget(self, row, col):
        widget = self.takeWidget(row, col)
        if widget is not None:
            widget.deleteLater()

    def undock_widget(self, row, col):
        state = self.save_state()
        self.removeWidget(row, col)
        self.restore_state(state)

    def dock_widget(self, widget, row, col):
        state = self.save_state()
        self.addWidget(widget, row, col)
        self.restore_state(state)

    def save_state(self):
        return {
            "rows": self.rows,
            "cols": self.cols,
        }

    def restore_state(self, state):
        if "rows" in state:
            self._vsplit.setSizes(state["rows"])
        if "cols" in state:
            for splitter, sizes in zip(self._row_splitters, state["cols"]):
                splitter.setSizes(sizes)

    def distribute_evenly(self):
        self._set_equal_stretch(self._vsplit)
        if self._vsplit.count() > 0:
            self._vsplit.setSizes(self._even_sizes(self._vsplit.size().height(), self._vsplit.count()))
        for splitter in self._row_splitters:
            self._set_equal_stretch(splitter)
            if splitter.count() > 0:
                splitter.setSizes(self._even_sizes(splitter.size().width(), splitter.count()))

    def clear_cell(self, row, col):
        self.removeWidget(row, col)

    def clear_all(self):
        for row, col in list(self._cells.keys()):
            self.removeWidget(row, col)

    def set_snap_enabled(self, enabled):
        self._snap_enabled = bool(enabled)
        if not self._snap_enabled:
            self._snap_lock = None

    def set_snap_thresholds(self, snap_threshold=None, unlock_threshold=None):
        if snap_threshold is not None:
            self._snap_threshold = int(snap_threshold)
        if unlock_threshold is not None:
            self._unlock_threshold = int(unlock_threshold)
        self._unlock_threshold = max(self._unlock_threshold, self._snap_threshold + 1)

    def _handle_splitter_moved(self, splitter, pos, index):
        if self._syncing_snap or not self._snap_enabled:
            return
        if index <= 0:
            return

        raw_pos = splitter._active_handle_pos
        if raw_pos is None or splitter._active_handle_index != index:
            raw_pos = pos

        lock = self._snap_lock
        if lock and lock.get("splitter") is splitter and lock.get("index") == index:
            if abs(raw_pos - lock["target_pos"]) <= self._unlock_threshold:
                self._move_splitter_to(splitter, index, lock["target_pos"])
                return
            self._snap_lock = None
            return

        target_pos = self._nearest_snap_position(splitter, index, raw_pos)
        if target_pos is None:
            return

        self._snap_lock = {
            "splitter": splitter,
            "index": index,
            "target_pos": target_pos,
        }
        self._move_splitter_to(splitter, index, target_pos)

    def _nearest_snap_position(self, splitter, index, raw_pos):
        candidates = self._snap_candidates(splitter, index)
        nearest = None
        nearest_distance = None
        for candidate in candidates:
            distance = abs(raw_pos - candidate)
            if distance <= self._snap_threshold and (nearest_distance is None or distance < nearest_distance):
                nearest = candidate
                nearest_distance = distance
        return nearest

    def _snap_candidates(self, splitter, index):
        if splitter.orientation() == QtCore.Qt.Horizontal:
            siblings = self._row_splitters
        else:
            siblings = []

        candidates = []
        for other in siblings:
            if other is splitter or index >= other.count():
                continue
            handle = other.handle(index)
            if handle is None:
                continue
            point = handle.pos()
            candidates.append(point.x() if other.orientation() == QtCore.Qt.Horizontal else point.y())
        return candidates

    def _move_splitter_to(self, splitter, index, pos):
        self._syncing_snap = True
        try:
            splitter.moveSplitter(int(pos), index)
        finally:
            self._syncing_snap = False

    def _clear_snap_lock(self, splitter):
        if self._snap_lock and self._snap_lock.get("splitter") is splitter:
            self._snap_lock = None

    @staticmethod
    def _set_equal_stretch(splitter):
        for index in range(splitter.count()):
            splitter.setStretchFactor(index, 1)

    @staticmethod
    def _even_sizes(total, count):
        count = max(1, int(count))
        total = max(count, int(total))
        base = total // count
        sizes = [base] * count
        for index in range(total - base * count):
            sizes[index] += 1
        return sizes

    @staticmethod
    def _make_placeholder():
        placeholder = QtWidgets.QWidget()
        placeholder.setMinimumSize(1, 1)
        placeholder.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        return placeholder
