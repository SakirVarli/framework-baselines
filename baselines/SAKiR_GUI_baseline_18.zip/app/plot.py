import array
import time, json
import multiprocessing
import numpy as np
import threading, queue
from PyQt5 import QtWidgets, QtCore
from typing import Optional, Literal
import queue

import sys, tempfile, zipfile
import os
import datetime
import pandas as pd
from pandas.io.formats.style import Styler
import numpy as np
import OpenGL.GL as GL
import pyqtgraph as pg
import pyqtgraph.opengl as gl
from typing import Optional, Literal, Dict, Tuple, Any
import warnings
from app.branding import application_id

from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import Qt, QRectF, QPointF, QAbstractTableModel
from PyQt5.QtGui import (
    QColor, QFont, QIcon, QPainter, QPainterPath, QBrush, QPen, QPixmap, QTextDocument, QFontMetrics, QImage, QMatrix4x4, QKeySequence, QPolygonF
)
from PyQt5.QtWidgets import (
    QMessageBox, QGraphicsSimpleTextItem, QGraphicsPathItem
)

from math import cos, radians, sin, tan

from pyqtgraph.exporters import SVGExporter

from PyQt5.QtPrintSupport import QPrinter
from PyQt5.QtSvg import QSvgGenerator
from contextlib import contextmanager
import uuid

from pyqtgraph.opengl import shaders
from app.splitter_grid import SplitterGrid

CIRCLE_SHADER = {
    'vertex': """
        varying vec2 vPointCoord;
        void main() {
            vPointCoord = gl_PointCoord;
            gl_Position = ftransform();
        }
    """,
    'fragment': """
        varying vec2 vPointCoord;
        void main() {
            vec2 c = vPointCoord - vec2(0.5);
            float r = dot(c, c);
            if (r > 0.25) discard;   // radius^2 = 0.5^2
            gl_FragColor = gl_Color;
        }
    """
}

shaders.ShaderProgram('circular', [CIRCLE_SHADER])

class FigureAnchor:
    TopLeft     = Qt.AlignLeft  | Qt.AlignTop
    TopRight    = Qt.AlignRight | Qt.AlignTop
    BottomLeft  = Qt.AlignLeft  | Qt.AlignBottom
    BottomRight = Qt.AlignRight | Qt.AlignBottom
    Center      = Qt.AlignHCenter | Qt.AlignVCenter

class AxisTickAnchor:
    Left     = Qt.AlignLeft
    Right    = Qt.AlignRight
    Center      = Qt.AlignHCenter | Qt.AlignVCenter

class RotatableAxisItem(pg.AxisItem):
    """
    AxisItem with manual tick text rotation + anchoring.

    Features:
    - Arbitrary rotation angle
    - Anchor control (left/right/center/top/bottom)
    - Correct handling for X vs Y axes
    - Version-safe (no tickTextAngle style)
    """

    def __init__(self, orientation="bottom", *args, **kwargs):
        super().__init__(orientation=orientation, *args, **kwargs)

        # ---- rotation state ----
        self._tick_angle = 0.0
        self._tick_anchor = None  # None | 'left' | 'right' | 'center' | 'top' | 'bottom'

        # ---- axis orientation semantic ----
        # bottom/top → x axis
        # left/right → y axis
        if orientation in ("bottom", "top"):
            self._axis_orientation = "x"
        else:
            self._axis_orientation = "y"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def setTickRotation(self, angle: float = 0.0, anchor: str | None = None):
        """
        Set tick label rotation.

        Parameters
        ----------
        angle : float
            Rotation angle in degrees.
        anchor : str | None
            'left', 'right', 'center' for X axis
            'top', 'bottom', 'center' for Y axis
        """
        self._tick_angle = float(angle)
        self._tick_anchor = anchor

        # Invalidate cached picture
        self.picture = None
        self.update()

    def clearTickRotation(self):
        """Reset tick rotation to default."""
        self._tick_angle = 0.0
        self._tick_anchor = None
        self.picture = None
        self.update()

    # ------------------------------------------------------------------
    # Anchor logic
    # ------------------------------------------------------------------
    def _anchor_to_flags(self, base_flags):
        if not self._tick_anchor:
            return base_flags

        if self._axis_orientation == "x":
            return {
                "left":   Qt.AlignLeft   | Qt.AlignVCenter,
                "right":  Qt.AlignRight  | Qt.AlignVCenter,
                "center": Qt.AlignHCenter | Qt.AlignVCenter,
            }.get(self._tick_anchor, base_flags)

        else:  # y axis
            return {
                "top":    Qt.AlignTop    | Qt.AlignHCenter,
                "bottom": Qt.AlignBottom | Qt.AlignHCenter,
                "center": Qt.AlignVCenter | Qt.AlignHCenter,
            }.get(self._tick_anchor, base_flags)

    # ------------------------------------------------------------------
    # Core drawing override
    # ------------------------------------------------------------------
    def drawPicture(self, p, axisSpec, tickSpecs, textSpecs):
        """
        Custom draw implementation with rotation + anchoring.
        """
        # ---- render hints ----
        p.setRenderHint(p.RenderHint.Antialiasing, False)
        p.setRenderHint(p.RenderHint.TextAntialiasing, True)

        # ---- axis line ----
        pen, p1, p2 = axisSpec
        p.setPen(pen)
        p.drawLine(p1, p2)

        # ---- ticks ----
        for pen, tp1, tp2 in tickSpecs:
            p.setPen(pen)
            p.drawLine(tp1, tp2)

        # ---- tick labels ----
        if self.style.get("tickFont") is not None:
            p.setFont(self.style["tickFont"])

        p.setPen(self.textPen())

        bounding = self.boundingRect().toAlignedRect()
        p.setClipRect(bounding)

        angle = self._tick_angle

        for rect, flags, text in textSpecs:
            flags = self._anchor_to_flags(flags)

            if angle:
                p.save()
                p.translate(rect.center())
                p.rotate(angle)
                p.translate(-rect.center())
                p.drawText(rect, flags, text)
                p.restore()
            else:
                p.drawText(rect, flags, text)

class FigureOverlay(QtWidgets.QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)
        self.setAttribute(Qt.WA_StyledBackground, False)
        self._annotations = {}
        parent.installEventFilter(self)
        self.setGeometry(parent.rect())
        self.raise_()
    
    def eventFilter(self, obj, event):
        if obj is self.parent() and event.type() == QtCore.QEvent.Resize:
            self.setGeometry(obj.rect())
            for ann in self._annotations.values():
                ann.reposition()

        return super().eventFilter(obj, event)

    def add_annotation(
        self,
        text: str,
        *,
        anchor: Qt.Alignment,
        offset: tuple[int, int],
        style: dict | None = None,
    ):
        key = (anchor, offset)

        old = self._annotations.pop(key, None)
        if old:
            old.deleteLater()

        ann = FigureAnnotation(
            text,
            anchor=anchor,
            offset=offset,
            parent=self,
            style=style,
        )

        ann.reposition()
        ann.show()
        ann.raise_()

        self._annotations[key] = ann
        return ann

    def remove_annotation(
            self,
            *,
            anchor: Qt.Alignment,
            offset: tuple[int, int],
        ) -> bool:
            """
            Remove annotation at (anchor, offset).

            Returns True if an annotation was removed,
            False if none existed.
            """
            key = (anchor, offset)

            ann = self._annotations.pop(key, None)
            if ann is None:
                return False

            ann.deleteLater()
            return True

class FigureAnnotation(QtWidgets.QLabel):
    def __init__(
        self,
        text: str,
        *,
        anchor: Qt.Alignment,
        offset: tuple[int, int] = (35, 45),
        parent=None,
        style: dict | None = None,
    ):
        super().__init__(text, parent)

        self.anchor = anchor
        self.offset = offset

        # ---- Default style ----
        self._style = {
            "font_family": "Arial",
            "font_size": 10,
            "bold": False,
            "italic": False,
            "text_color": "white",
            "bg_color": (0, 0, 0, 160),   # RGBA
            "padding": (4, 8, 4, 8),      # t, l, b, r
            "border_radius": 6,
        }

        if style:
            self._style.update(style)

        self.setAlignment(Qt.AlignCenter)
        self.apply_style()
        self.adjustSize()

    def reposition(self):
        """Recompute position based on anchor + offset."""
        overlay = self.parent()
        if overlay is None:
            return

        ow, oh = overlay.width(), overlay.height()
        w, h = self.width(), self.height()
        dx, dy = self.offset
        a = self.anchor

        # ---- Horizontal ----
        if a & Qt.AlignLeft:
            x = dx
        elif a & Qt.AlignRight:
            x = ow - w - dx
        else:  # HCenter
            x = (ow - w) // 2 + dx

        # ---- Vertical ----
        if a & Qt.AlignTop:
            y = dy
        elif a & Qt.AlignBottom:
            y = oh - h - dy
        else:  # VCenter
            y = (oh - h) // 2 + dy

        self.move(int(x), int(y))
    
    def set_style(self, **kwargs):
        """
        Update annotation style at runtime.
        Example:
            ann.set_style(
                font_size=12,
                bg_color=(255, 0, 0, 180),
                bold=True
            )
        """
        self._style.update(kwargs)
        self.apply_style()
        self.adjustSize()
        self.reposition()

    def apply_style(self):
        s = self._style

        # ---- Font ----
        font = QFont(
            s["font_family"],
            int(s["font_size"])
        )
        font.setBold(bool(s["bold"]))
        font.setItalic(bool(s["italic"]))
        self.setFont(font)

        # ---- Colors ----
        fg = s["text_color"]

        bg = s["bg_color"]
        if isinstance(bg, (tuple, list)):
            r, g, b, a = bg
            bg_css = f"rgba({r},{g},{b},{a})"
        else:
            bg_css = bg  # string

        pt, pl, pb, pr = s["padding"]

        # ---- Stylesheet ----
        self.setStyleSheet(f"""
            QLabel {{
                color: {fg};
                background-color: {bg_css};
                padding-top: {pt}px;
                padding-left: {pl}px;
                padding-bottom: {pb}px;
                padding-right: {pr}px;
                border-radius: {s["border_radius"]}px;
            }}
        """)

class WrappingLabel(QtWidgets.QLabel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setWordWrap(True)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Minimum
        )
        self.setContentsMargins(5, 5, 5, 5)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        fm = QFontMetrics(self.font())

        # Account for style padding
        left, top, right, bottom = self.getContentsMargins()
        w = max(0, width - left - right)

        rect = fm.boundingRect(
            QtCore.QRect(0, 0, w, 10_000),
            Qt.TextWordWrap,
            self.text()
        )

        return rect.height() + top + bottom
        
class FigureTitleWidget(QtWidgets.QWidget):
    def __init__(self, text="", style=None, parent=None):
        super().__init__(parent)

        self._style = {
            "font_family": "Arial",
            "font_size": 14,
            "bold": True,
            "italic": False,
            "text_color": "#eaeaea",
            "bg_color": "#000000",        # None = transparent
            "padding": (0, 0, 0, 0),  # top, left, bottom, right
            "alignment": Qt.AlignCenter,
            "border_radius": 0,
        }

        if style:
            self._style.update(style)

        self.label = WrappingLabel(text)
        self.label.setWordWrap(True)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Minimum
        )

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.label)

        self.apply_style()

    # ------------------------------------------------------------------
    # Style system
    # ------------------------------------------------------------------
    def apply_style(self):
        s = self._style

        # ---- Font ----
        font = QFont(s["font_family"], int(s["font_size"]))
        font.setBold(bool(s["bold"]))
        font.setItalic(bool(s["italic"]))
        self.label.setFont(font)

        # ---- Alignment ----
        self.label.setAlignment(s["alignment"])

        # ---- Padding ----
        pt, pl, pb, pr = s["padding"]

        # ---- Background ----
        bg = s["bg_color"]
        bg_css = "transparent" if bg in (None, "transparent") else bg

        self.label.setStyleSheet(f"""
            QLabel {{
                color: {s["text_color"]};
                background-color: {bg_css};
                padding-top: {pt}px;
                padding-left: {pl}px;
                padding-bottom: {pb}px;
                padding-right: {pr}px;
                border-radius: {s["border_radius"]}px;
            }}
        """)

        self.updateGeometry()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def setText(self, text: str):
        self.label.setText(text)
        self.updateGeometry()

    def text(self):
        return self.label.text()

    def set_style(self, **kwargs):
        """
        Update one or more style attributes at runtime.

        Example:
            title.set_style(
                font_size=18,
                bg_color="#202225",
                text_color="white"
            )
        """
        self._style.update(kwargs)
        self.apply_style()

    def style(self):
        return dict(self._style)

class StyledDFModel(QAbstractTableModel):
    """DataFrame/Styler-aware model with fast, style-aware rendering."""

    def __init__(self, data: pd.DataFrame):
        super().__init__()

        # Detect whether it's a Styler or a plain DataFrame
        if isinstance(data, Styler):
            self.df = data.data
            self.styles = self._extract_styles(data)
        else:
            self.df = data
            self.styles = {}

        self._numeric_columns = self.df.select_dtypes(include=[np.number]).columns

    def rowCount(self, parent=None):
        return len(self.df.index)

    def columnCount(self, parent=None):
        return len(self.df.columns)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None

        row, col = index.row(), index.column()
        value = self.df.iat[row, col]

        if role == Qt.DisplayRole:
            # simple formatting
            return str(value)

        # --- Style roles ---
        if (row, col) in self.styles:
            style_dict = self.styles[(row, col)]
            if role == Qt.BackgroundRole and 'background-color' in style_dict:
                return QBrush(QColor(style_dict['background-color']))
            if role == Qt.ForegroundRole and 'color' in style_dict:
                return QBrush(QColor(style_dict['color']))
            if role == Qt.FontRole and 'font-weight' in style_dict:
                font = QFont()
                if style_dict['font-weight'] in ('bold', '700'):
                    font.setBold(True)
                return font

        # Default alignment
        if role == Qt.TextAlignmentRole:
            if self.df.columns[col] in self._numeric_columns:
                return Qt.AlignRight | Qt.AlignVCenter
            return Qt.AlignLeft | Qt.AlignVCenter

        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return str(self.df.columns[section])
        else:
            return str(self.df.index[section])

    def _extract_styles(self, styler):
        """
        Converts Styler's internal ctx dict into a
        {(row, col): {'property': 'value'}} mapping.
        """
        styles = {}
        try:
            ctx = styler._compute().ctx  # {(row, col): [("color","red"),("background-color","blue")]}
            for key, css_list in ctx.items():
                styles[key] = {prop: val for prop, val in css_list}
        except Exception:
            pass
        return styles

    def sort(self, column, order=Qt.AscendingOrder):
        """Advanced stable sort with NaN handling and natural string ordering."""
        try:
            col_name = self.df.columns[column]
            ascending = (order == Qt.AscendingOrder)

            self.layoutAboutToBeChanged.emit()

            series = self.df[col_name]

            # ✅ Detect numeric vs object column
            if pd.api.types.is_numeric_dtype(series):
                # ✅ Stable numeric sort with NaN always at bottom
                self.df = self.df.sort_values(
                    by=col_name,
                    ascending=ascending,
                    na_position="last",
                    kind="mergesort"  # ✅ STABLE SORT
                )

            else:
                # ✅ NATURAL STRING SORT (item2 < item10)
                try:
                    import re

                    def natural_key(val):
                        if pd.isna(val):
                            return (1, "")
                        val = str(val)
                        return (
                            0,
                            [int(t) if t.isdigit() else t.lower()
                            for t in re.split(r"(\d+)", val)]
                        )

                    self.df = self.df.assign(
                        __sortkey__=series.map(natural_key)
                    ).sort_values(
                        "__sortkey__",
                        ascending=ascending,
                        kind="mergesort"
                    ).drop(columns="__sortkey__")

                except Exception:
                    # ✅ Fallback safe lexicographic sort
                    self.df = self.df.sort_values(
                        by=col_name,
                        ascending=ascending,
                        na_position="last",
                        kind="mergesort"
                    )

            # ✅ Rebuild numeric column cache
            self._numeric_columns = self.df.select_dtypes(include=[np.number]).columns

            # ✅ Re-map styles to new row order safely
            if self.styles:
                new_styles = {}
                for (old_row, col), style in self.styles.items():
                    if old_row < len(self.df):
                        new_styles[(old_row, col)] = style
                self.styles = new_styles

            self.layoutChanged.emit()

        except Exception as e:
            pass

class DFSearchProxy(QtCore.QSortFilterProxyModel):
    """
    Fast filtering + column-aware search proxy.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._search_text = ""
        self._column = None  # None = all columns
        self.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.setDynamicSortFilter(False)

    def set_search(self, text: str, column=None):
        self._search_text = text.strip()
        self._column = column
        self.invalidateFilter()

    def filterAcceptsRow(self, row, parent):
        if not self._search_text:
            return True

        model = self.sourceModel()

        if self._column is not None:
            idx = model.index(row, self._column)
            val = model.data(idx, Qt.DisplayRole)
            return self._search_text.lower() in str(val).lower()

        # Search ALL columns
        for col in range(model.columnCount()):
            idx = model.index(row, col)
            val = model.data(idx, Qt.DisplayRole)
            if self._search_text.lower() in str(val).lower():
                return True

        return False

class DataFrameExplorer(QtWidgets.QWidget):
    def __init__(
            self, 
            data: pd.DataFrame | Styler,
            *,
            title: str | None = None,
            row_height: int | list[int] | None = None,
            col_width: int | list[int] | None = None,
            initial_sort: tuple[int, Qt.SortOrder] | None = None):
        super().__init__()

        self._title_widget = FigureTitleWidget(
            title or "",
            {
                "font_family": "Arial",
                "font_size": 14,
                "bold": True,
                "italic": False,
                "text_color": "#222222",
                "bg_color": None,        # None = transparent
                "padding": (6, 12, 6, 12),  # top, left, bottom, right
                "alignment": Qt.AlignCenter,
                "border_radius": 0,
            }
        )
        self._title_widget.setVisible(bool(title))

        # --- Models ---
        self.model = StyledDFModel(data)
        self.proxy = DFSearchProxy()
        self.proxy.setSourceModel(self.model)

        # --- View ---
        self.view = QtWidgets.QTableView()

        self.view.setModel(self.proxy)
        # ✅ User resizable columns
        h = self.view.horizontalHeader()
        h.setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
        h.setDefaultAlignment(Qt.AlignCenter)

        # ✅ FORCE HEADER HEIGHT FOR MULTI-LINE TEXT
        h.setMinimumHeight(80) 

        self.view.setAlternatingRowColors(True)
        self.view.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
        self.view.setSelectionMode(QtWidgets.QTableView.ExtendedSelection)

        # Apply sizing
        self._apply_row_heights(row_height)
        self._apply_column_widths(col_width)

        self.view.setSortingEnabled(True)
        # Apply initial sort ONLY if requested
        if initial_sort is not None:
            col = initial_sort
            order = Qt.AscendingOrder  # default

            if isinstance(initial_sort, tuple):
                col, order = initial_sort
            
            col_idx = self._resolve_sort_column(col)
            order_qt = self._resolve_sort_order(order)

            if col_idx is not None and order_qt is not None:
                self.proxy.sort(col_idx, order_qt)
            else:
                self.proxy.setSortRole(Qt.DisplayRole)
                self.proxy.sort(-1)
        
        # # Enable user sorting AFTER setup
        # self.view.setSortingEnabled(True)

        # --- Search bar ---
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Search (Ctrl+F)")
        self.search.textChanged.connect(
            lambda t: self.proxy.set_search(t)
        )

        # --- Column selector ---
        self.col_combo = QtWidgets.QComboBox()
        self.col_combo.addItem("All columns", None)
        for i, col in enumerate(self.model.df.columns):
            self.col_combo.addItem(str(col), i)

        self.col_combo.currentIndexChanged.connect(
            lambda: self.proxy.set_search(
                self.search.text(),
                self.col_combo.currentData()
            )
        )

        # --- Toolbar ---
        tb = QtWidgets.QToolBar()
        tb.addWidget(QtWidgets.QLabel("🔍"))
        tb.addWidget(self.search)
        tb.addSeparator()
        tb.addWidget(self.col_combo)
        tb.addSeparator()

        export_csv = QtWidgets.QAction("Export CSV", self)
        export_xlsx = QtWidgets.QAction("Export Excel", self)
        copy_clip = QtWidgets.QAction("Copy Selection", self)

        export_csv.triggered.connect(self.export_csv)
        export_xlsx.triggered.connect(self.export_excel)
        copy_clip.triggered.connect(self.copy_selection)

        tb.addAction(export_csv)
        tb.addAction(export_xlsx)
        tb.addAction(copy_clip)

        # --- Layout ---
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(self._title_widget)
        layout.addWidget(tb)
        layout.addWidget(self.view, 1)

        # --- Shortcuts ---
        QtWidgets.QShortcut(QKeySequence("Ctrl+F"), self, activated=self.search.setFocus)
        QtWidgets.QShortcut(QKeySequence("Ctrl+C"), self, activated=self.copy_selection)

    def export_csv(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Export CSV", "table.csv", "CSV (*.csv)"
        )
        if not path:
            return

        df = self.get_visible_df()
        df.to_csv(path, index=True)
    
    def export_excel(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Export Excel", "table.xlsx", "Excel (*.xlsx)"
        )
        if not path:
            return

        df = self.get_visible_df()
        df.to_excel(path, index=True)
    
    def copy_selection(self):
        sel = self.view.selectionModel().selectedIndexes()
        if not sel:
            return

        rows = sorted(set(i.row() for i in sel))
        cols = sorted(set(i.column() for i in sel))

        data = []
        for r in rows:
            row = []
            for c in cols:
                idx = self.proxy.index(r, c)
                row.append(self.proxy.data(idx))
            data.append("\t".join(row))

        QtWidgets.QApplication.clipboard().setText("\n".join(data))
    
    def get_visible_df(self) -> pd.DataFrame:
        rows = []
        for r in range(self.proxy.rowCount()):
            src_row = self.proxy.mapToSource(self.proxy.index(r, 0)).row()
            rows.append(src_row)
        return self.model.df.iloc[rows]

    def _resolve_sort_order(self, order):
        """
        Resolve Qt.SortOrder from string or Qt.SortOrder.
        """
        if isinstance(order, Qt.SortOrder):
            return order

        if isinstance(order, str):
            o = order.strip().lower()
            if o in ("asc", "ascending"):
                return Qt.AscendingOrder
            if o in ("desc", "descending"):
                return Qt.DescendingOrder

        return None

    def _resolve_sort_column(self, col):
        if isinstance(col, int):
            return col if 0 <= col < self.model.columnCount() else None

        if isinstance(col, str):
            try:
                return self.model.df.columns.get_loc(col)
            except Exception:
                return None

        return None
    
    def _apply_row_heights(self, row_height):
        if row_height is None:
            return

        if isinstance(row_height, int):
            self.view.verticalHeader().setDefaultSectionSize(row_height)
            return

        # list-like
        for i, h in enumerate(row_height):
            if i < self.model.rowCount():
                self.view.setRowHeight(i, int(h))
    
    def _apply_column_widths(self, col_width):
        if col_width is None:
            return

        if isinstance(col_width, int):
            for c in range(self.model.columnCount()):
                self.view.setColumnWidth(c, int(col_width))
            return

        # list-like
        for c, w in enumerate(col_width):
            if c < self.model.columnCount():
                self.view.setColumnWidth(c, int(w))

    def setTitle(self, text: str | None):
        if not text:
            self._title_widget.setVisible(False)
            return

        self._title_widget.setText(text)
        self._title_widget.setVisible(True)

    def title(self) -> str:
        return self._title_widget.text()

class CategoricalAxisManager:
    """
    Drop-in replacement for your current CategoricalAxisManager, but optimized for streaming:

    Applied improvements (everything except "Principle 3"):
      ✅ Vectorized datetime encoding (no Python per-point loops)
      ✅ Incremental min/max updates per-curve (no full-buffer recompute)
      ✅ Frozen / incremental categorical mapping (no rebuild per update)
      ✅ Faster hover decode path (ns origin + arithmetic; formatting only at the end)
      ✅ More correct category merge (choose the biggest label-set)
      ✅ Same public API: encode_x/encode_y, decode_x/decode_y, apply_ticks

    Note: This keeps your behavior of applying ticks whenever apply_ticks() is called
    (i.e., it does NOT throttle tick updates).
    """

    def __init__(self):
        # (row, col, axis) -> dict[curve_name -> info]
        self.registry: Dict[Tuple[int, int, str], Dict[str, Dict[str, Any]]] = {}

        # axis domain cache to avoid unnecessary re-ticks
        self._axis_domain: Dict[Tuple[int, int, str], Tuple[float, float]] = {}

        # GLOBAL datetime origin per axis in ns (int64)
        # (row, col, axis) -> origin_ns_int64
        self._datetime_origin_ns: Dict[Tuple[int, int, str], int] = {}

        # GLOBAL datetime origin per axis also cached as datetime.datetime (for formatting)
        self._datetime_origin_py: Dict[Tuple[int, int, str], datetime.datetime] = {}

        # Categorical mapping per axis (frozen/incremental)
        # (row, col, axis) -> {"map": {label: idx}, "labels": [label,...]}
        self._cat_maps: Dict[Tuple[int, int, str], Dict[str, Any]] = {}

    # ==========================================================
    # Public encode interface
    # ==========================================================
    def encode_x(self, arr, row, col, curve_name):
        return self._encode(arr, row, col, "x", curve_name)

    def encode_y(self, arr, row, col, curve_name):
        return self._encode(arr, row, col, "y", curve_name)

    # ==========================================================
    # Public decode interface (hover)
    # ==========================================================
    def decode_x(self, val, row, col, curve_name=None):
        return self._decode(val, row, col, "x", curve_name)

    def decode_y(self, val, row, col, curve_name=None):
        return self._decode(val, row, col, "y", curve_name)

    # ==========================================================
    # Type helpers
    # ==========================================================
    def _is_datetime_arr(self, arr: np.ndarray) -> bool:
        # True if dtype is datetime64
        if isinstance(arr, np.ndarray) and arr.dtype.kind == "M":
            return True

        # Object arrays: check first non-None element
        if isinstance(arr, np.ndarray) and arr.dtype == object and arr.size:
            v = arr.flat[0]
            if isinstance(v, (datetime.datetime, datetime.date, np.datetime64)):
                return True
            if pd is not None and isinstance(v, pd.Timestamp):
                return True
        return False

    def _coerce_datetime64ns(self, arr: np.ndarray) -> np.ndarray:
        """
        Convert any supported datetime-like array to numpy datetime64[ns] array.
        This is vectorized and avoids per-element Python loops for numpy/pandas inputs.
        """
        if arr.dtype.kind == "M":
            return arr.astype("datetime64[ns]")

        # pandas Timestamp / python datetime in object arrays
        # np.array(..., dtype='datetime64[ns]') handles python datetime/date pretty well.
        # If pandas is present, pd.to_datetime is robust and still vectorized.
        if pd is not None:
            try:
                return pd.to_datetime(arr).to_numpy(dtype="datetime64[ns]")
            except Exception:
                pass

        return np.array(arr, dtype="datetime64[ns]")

    @staticmethod
    def _dt64ns_to_py(dt64: np.datetime64) -> datetime.datetime:
        """
        Convert numpy datetime64[ns] to naive python datetime (UTC-based).
        """
        ns = dt64.astype("datetime64[ns]").astype(np.int64)
        # ns -> seconds + remainder
        sec = ns // 1_000_000_000
        rem_ns = ns % 1_000_000_000
        dt = datetime.datetime.utcfromtimestamp(int(sec))
        return dt.replace(microsecond=int(rem_ns // 1000))

    # ==========================================================
    # Encoding
    # ==========================================================
    def _encode(self, arr, row, col, axis, curve_name):
        arr = np.asarray(arr)
        key = (row, col, axis)

        # ---- Numeric passthrough ----
        # (includes ints, floats, etc.)
        if arr.dtype.kind in ("i", "u", "f"):
            out = arr.astype(float, copy=False)
            # keep registry minimal; numeric doesn't need per-curve info
            return out

        # ---- Datetime encoding (GLOBAL ORIGIN, VECTORIZED) ----
        if self._is_datetime_arr(arr):
            d64 = self._coerce_datetime64ns(arr)
            ns = d64.astype(np.int64)  # vectorized int64 ns

            # establish global origin ONCE per axis
            if key not in self._datetime_origin_ns:
                origin_ns = int(ns.min())
                self._datetime_origin_ns[key] = origin_ns
                # cache a python datetime for formatting
                self._datetime_origin_py[key] = self._dt64ns_to_py(
                    np.datetime64(origin_ns, "ns")
                )
            origin_ns = self._datetime_origin_ns[key]

            encoded = (ns - origin_ns) / 1e9  # seconds float, vectorized

            infos = self.registry.setdefault(key, {})
            info = infos.get(curve_name)

            # Incremental min/max update (no full-buffer min/max from python datetimes)
            cur_min = int(ns.min())
            cur_max = int(ns.max())

            if info is None:
                infos[curve_name] = {
                    "type": "datetime",
                    "ns_min": cur_min,
                    "ns_max": cur_max,
                }
            else:
                # keep type stable
                info["type"] = "datetime"
                info["ns_min"] = min(int(info.get("ns_min", cur_min)), cur_min)
                info["ns_max"] = max(int(info.get("ns_max", cur_max)), cur_max)

            return encoded.astype(float, copy=False)

        # ---- Categorical strings (FROZEN / INCREMENTAL MAP) ----
        # Convert to str labels vectorized-ish
        # (np.array(obj, dtype=str) can be expensive; list(str(v)) is sometimes faster,
        # but categorical streams are usually low-rate. We'll do a safe approach.)
        labels = [str(v) for v in arr.tolist()] if arr.ndim else [str(arr.item())]

        cmap = self._cat_maps.get(key)
        if cmap is None:
            cmap = {"map": {}, "labels": []}
            self._cat_maps[key] = cmap

        m = cmap["map"]
        labs = cmap["labels"]

        # incremental assign indices
        encoded = np.empty(len(labels), dtype=float)
        for i, lab in enumerate(labels):
            idx = m.get(lab)
            if idx is None:
                idx = len(labs)
                m[lab] = idx
                labs.append(lab)
            encoded[i] = float(idx)

        infos = self.registry.setdefault(key, {})
        infos[curve_name] = {
            "type": "category",
            # store reference to axis labels (not per-curve copies)
            "labels_ref": labs,
        }

        return encoded

    # ==========================================================
    # Decoding (hover)
    # ==========================================================
    def _decode(self, val, row, col, axis, curve_name):
        key = (row, col, axis)
        infos = self.registry.get(key)
        if not infos:
            return f"{float(val):.3f}"

        curve_info = infos.get(curve_name) if curve_name is not None else None
        if curve_info is None:
            return f"{float(val):.3f}"

        t = curve_info.get("type")

        # ---- Category ----
        if t == "category":
            labels = curve_info.get("labels_ref")
            if not labels:
                return f"{float(val):.3f}"
            idx = int(round(float(val)))
            if 0 <= idx < len(labels):
                return labels[idx]
            return f"{float(val):.3f}"

        # ---- Datetime (curve-aware span; global-origin arithmetic) ----
        if t == "datetime":
            origin_ns = self._datetime_origin_ns.get(key)
            origin_py = self._datetime_origin_py.get(key)
            if origin_ns is None or origin_py is None:
                return f"{float(val):.3f}"

            ns_min = curve_info.get("ns_min")
            ns_max = curve_info.get("ns_max")
            if ns_min is None or ns_max is None:
                return f"{float(val):.3f}"

            span_seconds = (int(ns_max) - int(ns_min)) / 1e9

            # val is seconds from origin
            try:
                ns = origin_ns + int(round(float(val) * 1e9))
                dt = self._dt64ns_to_py(np.datetime64(ns, "ns"))
                return self._format_datetime_hover(dt, span_seconds)
            except Exception:
                return f"{float(val):.3f}"

        return f"{float(val):.3f}"

    # ==========================================================
    # Tick application (public)
    # ==========================================================
    def apply_ticks(self, plotwidget, row, col):
        if not hasattr(plotwidget, "getPlotItem"):
            return
        pi = plotwidget.getPlotItem()
        if pi is None:
            return

        self._apply_axis(pi.getAxis("bottom"), (row, col, "x"))
        self._apply_axis(pi.getAxis("left"), (row, col, "y"))

    # ==========================================================
    # Axis internals
    # ==========================================================
    def _apply_axis(self, axis_item, key):
        infos = self.registry.get(key)
        if not infos:
            return

        types = {info.get("type") for info in infos.values() if info}
        types.discard(None)
        if not types:
            return
        if len(types) != 1:
            raise ValueError(f"Mixed axis types detected: {types}")

        merged = self._merge_axis_infos(key, infos, next(iter(types)))
        if merged is None:
            return

        domain = merged["domain"]
        if self._axis_domain.get(key) == domain:
            return

        self._axis_domain[key] = domain
        self._set_axis_ticks(axis_item, merged, key)

    def _merge_axis_infos(self, key, infos, t):
        # ---- Category ----
        if t == "category":
            # choose the largest label set among curves (they all reference the same axis map in this impl)
            best = None
            best_n = -1
            for info in infos.values():
                labels = info.get("labels_ref") or []
                if len(labels) > best_n:
                    best_n = len(labels)
                    best = labels
            if not best:
                return None
            return {
                "type": "category",
                "labels": best,
                "domain": (0.0, float(len(best) - 1)) if best else (0.0, 0.0),
            }

        # ---- Datetime ----
        if t == "datetime":
            origin_ns = self._datetime_origin_ns.get(key)
            if origin_ns is None:
                return None

            ns_min = min(int(info["ns_min"]) for info in infos.values() if "ns_min" in info)
            ns_max = max(int(info["ns_max"]) for info in infos.values() if "ns_max" in info)

            lo = (ns_min - origin_ns) / 1e9
            hi = (ns_max - origin_ns) / 1e9
            return {
                "type": "datetime",
                "ns_min": ns_min,
                "ns_max": ns_max,
                "domain": (float(lo), float(hi)),
            }

        return None

    # ==========================================================
    # Tick creation
    # ==========================================================
    def _set_axis_ticks(self, axis_item, info, key):
        max_ticks = self._auto_tick_count(axis_item)

        # ---- Category ----
        if info["type"] == "category":
            labels = info["labels"]
            ticks = [(float(i), lab) for i, lab in enumerate(labels)]

        # ---- Datetime ----
        elif info["type"] == "datetime":
            origin_py = self._datetime_origin_py.get(key)
            if origin_py is None:
                return

            lo, hi = info["domain"]
            span = hi - lo
            if span <= 0:
                return

            step = span / max_ticks
            ticks = []
            for i in range(max_ticks + 1):
                sec = lo + i * step
                dt = origin_py + datetime.timedelta(seconds=float(sec))
                ticks.append((float(sec), self._format_datetime_tick(dt)))
        else:
            return

        ticks = self._limit_ticks(ticks, max_ticks)
        axis_item.setTicks([ticks])

    # ==========================================================
    # Utilities
    # ==========================================================
    def _auto_tick_count(self, axis):
        try:
            px = axis.geometry().width()
            return int(max(3, px // 90))
        except Exception:
            return 6

    def _limit_ticks(self, items, max_ticks):
        n = len(items)
        if n <= max_ticks:
            return items
        step = max(1, n // max_ticks)
        return items[::step]

    # ==========================================================
    # Formatting
    # ==========================================================
    def _format_datetime_tick(self, dt: datetime.datetime) -> str:
        today = datetime.date.today()
        if dt.date() == today:
            return dt.strftime("%H:%M:%S")
        return dt.strftime("%Y-%m-%d")

    def _format_datetime_hover(self, dt: datetime.datetime, span_seconds: float) -> str:
        if span_seconds < 60:
            return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        if span_seconds < 3600:
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        if span_seconds < 86400:
            return dt.strftime("%Y-%m-%d %H:%M")
        if span_seconds < 86400 * 90:
            return dt.strftime("%Y-%m-%d %H:%M")
        return dt.strftime("%Y-%m-%d %H:00")

class PlotExportDialog(QtWidgets.QDialog):
    def __init__(self, plot, default_target="figure", parent=None):
        super().__init__(parent)
        self.plot = plot
        self.setWindowTitle("Export Plot")
        self.setModal(True)
        self.resize(460, 380)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 12)
        root.setSpacing(12)

        bold = QFont()
        bold.setBold(True)

        # ======================================
        # TARGET SECTION
        # ======================================
        target_grp = QtWidgets.QGroupBox("Target")
        target_layout = QtWidgets.QFormLayout(target_grp)

        self.target_cb = QtWidgets.QComboBox()
        self.target_cb.addItems(["figure", "subplot"])
        self.target_cb.setCurrentText(default_target)

        # --- ROW / COL SELECTORS ---
        self.row_spin = QtWidgets.QSpinBox()
        self.row_spin.setRange(0, 10_000)
        self.row_spin.setToolTip("Subplot row index")

        self.col_spin = QtWidgets.QSpinBox()
        self.col_spin.setRange(0, 10_000)
        self.col_spin.setToolTip("Subplot column index")

        self.row_spin.setRange(0, self.plot._rows - 1)
        self.col_spin.setRange(0, self.plot._cols - 1)

        rc_container = QtWidgets.QWidget()
        rc_layout = QtWidgets.QHBoxLayout(rc_container)
        rc_layout.setContentsMargins(0, 0, 0, 0)
        rc_layout.setSpacing(6)
        rc_layout.addWidget(QtWidgets.QLabel("Row:"))
        rc_layout.addWidget(self.row_spin)
        rc_layout.addWidget(QtWidgets.QLabel("Col:"))
        rc_layout.addWidget(self.col_spin)
        rc_layout.addStretch(1)

        target_layout.addRow("Export Target:", self.target_cb)
        target_layout.addRow("Subplot (row, col):", rc_container)

        root.addWidget(target_grp)

        # ======================================
        # FORMAT SECTION
        # ======================================
        format_grp = QtWidgets.QGroupBox("Format")
        format_layout = QtWidgets.QFormLayout(format_grp)

        self.format_cb = QtWidgets.QComboBox()
        self.format_cb.addItems(["png", "svg", "pdf"])

        self.dpi_spin = QtWidgets.QSpinBox()
        self.dpi_spin.setRange(50, 1000)
        self.dpi_spin.setValue(300)

        self.transparent_chk = QtWidgets.QCheckBox("Transparent background (PNG only)")

        format_layout.addRow("File Type:", self.format_cb)
        format_layout.addRow("DPI:", self.dpi_spin)
        format_layout.addRow("", self.transparent_chk)

        root.addWidget(format_grp)

        # ======================================
        # PRESET SECTION
        # ======================================
        preset_grp = QtWidgets.QGroupBox("Export Preset")
        preset_layout = QtWidgets.QHBoxLayout(preset_grp)

        self.preset_cb = QtWidgets.QComboBox()
        self.preset_cb.addItems(["publication", "presentation", "web"])

        preset_layout.addWidget(QtWidgets.QLabel("Profile:"))
        preset_layout.addWidget(self.preset_cb)
        preset_layout.addStretch(1)

        root.addWidget(preset_grp)

        # ======================================
        # EXTRA OPTIONS
        # ======================================
        extras_grp = QtWidgets.QGroupBox("Extras")
        extras_layout = QtWidgets.QVBoxLayout(extras_grp)

        self.state_chk = QtWidgets.QCheckBox("Also save figure state (.json)")
        extras_layout.addWidget(self.state_chk)
        extras_layout.addStretch(1)

        root.addWidget(extras_grp)

        root.addStretch(1)

        # ======================================
        # BUTTONS
        # ======================================
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        root.addWidget(btns)

        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        # ======================================
        # LIVE LOGIC
        # ======================================
        def on_target_change(text):
            is_subplot = (text == "subplot")
            self.row_spin.setEnabled(is_subplot)
            self.col_spin.setEnabled(is_subplot)

        def on_format_change(fmt):
            is_png = (fmt == "png")
            self.transparent_chk.setEnabled(is_png)
            if not is_png:
                self.transparent_chk.setChecked(False)

        self.target_cb.currentTextChanged.connect(on_target_change)
        self.format_cb.currentTextChanged.connect(on_format_change)

        # Initial state
        on_target_change(default_target)
        on_format_change(self.format_cb.currentText())

    # ======================================
    # CONFIG EXTRACTION
    # ======================================
    def get_config(self):
        return {
            "target": self.target_cb.currentText(),
            "row": self.row_spin.value(),
            "col": self.col_spin.value(),
            "format": self.format_cb.currentText(),
            "dpi": self.dpi_spin.value(),
            "transparent": self.transparent_chk.isChecked(),
            "preset": self.preset_cb.currentText(),
            "save_state": self.state_chk.isChecked(),
        }

class PlotWidget3D(gl.GLViewWidget):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ortho_enabled = True

    def set_ortho(self, ortho: bool):
        self.ortho_enabled = ortho
        self.update()

    def projectionMatrix(self, region=None):
        if region is None:
            region = (0, 0, self.deviceWidth(), self.deviceHeight())

        dist = float(self.opts['distance'])
        nearClip = 0.01 * dist
        farClip  = 100.0 * dist

        # Screen parameters
        w = float(self.width())
        h = float(self.height())
        aspect = w / max(1.0, h)

        tr = QMatrix4x4()

        # ==============================
        # ORTHOGRAPHIC MODE (corrected)
        # ==============================
        if self.ortho_enabled:

            # Scale world coordinates proportionally to distance
            # so zooming behaves the same as perspective
            world_scale = dist * 0.5

            if aspect >= 1:
                left   = -world_scale * aspect
                right  =  world_scale * aspect
                bottom = -world_scale
                top    =  world_scale
            else:
                left   = -world_scale
                right  =  world_scale
                bottom = -world_scale / aspect
                top    =  world_scale / aspect

            tr.ortho(left, right, bottom, top, nearClip, farClip)
            return tr

        # ==============================
        # PERSPECTIVE MODE (unchanged)
        # ==============================
        x0, y0, vw, vh = self.getViewport()
        fov = self.opts['fov']

        r = nearClip * tan(0.5 * radians(fov))
        t = r * vh / vw

        left   = r * ((region[0]-x0)          * (2.0/vw) - 1)
        right  = r * ((region[0]+region[2]-x0)* (2.0/vw) - 1)
        bottom = t * ((region[1]-y0)          * (2.0/vh) - 1)
        top    = t * ((region[1]+region[3]-y0)* (2.0/vh) - 1)

        tr.frustum(left, right, bottom, top, nearClip, farClip)
        return tr

class PlotStyleProfile:
    """
    Defines styling for titles, axes, ticks, gridlines, legends,
    3D axis, hover labels, and global background.

    Use built-in presets via:
        PlotStyleProfile.dark()
        PlotStyleProfile.light()
        PlotStyleProfile.matlab()
        PlotStyleProfile.seaborn()
        PlotStyleProfile.ggplot()
        PlotStyleProfile.midnight_blue()
        PlotStyleProfile.neon()
        PlotStyleProfile.blender_dark()
        PlotStyleProfile.grayscale()
        PlotStyleProfile.monokai()
        PlotStyleProfile.cyberpunk()
        PlotStyleProfile.pastel()
        PlotStyleProfile.oceanic()
        PlotStyleProfile.lava()
        PlotStyleProfile.solarized_dark()
        PlotStyleProfile.solarized_light()
        PlotStyleProfile.retro_wave()
        PlotStyleProfile.charcoal()
        PlotStyleProfile.inferno()
        PlotStyleProfile.clean_minimal()
        PlotStyleProfile.presentation()
        PlotStyleProfile.terminal_green()
    """

    def __init__(
        self,
        # Titles
        title_color="white",
        title_font="Arial",
        title_size=12,

        # Axis labels
        axis_label_color="white",
        axis_label_font="Arial",
        axis_label_size=10,

        # Tick labels
        tick_label_color="white",
        tick_label_font="Arial",
        tick_label_size=9,

        # Ticks & gridlines (2D)
        tick_line_color=(150, 150, 150),
        tick_line_width=1,
        grid_color=(60, 60, 60),
        grid_width=1,

        # Legend
        legend_text_color="white",
        legend_bg_color=(30, 30, 30, 180),

        # Background (main window / canvas)
        background_color=(20, 20, 20),

        # Hover labels (2D)
        hover_text_color="yellow",
        hover_bg_color=(40, 40, 40, 220),

        # 3D Axis
        axis3d_color=(160, 160, 160, 255),
        axis3d_line_width=1,
        axis3d_font="Arial",
        axis3d_font_size=13,

        # Extra layout styling
        content_background=None,   # 3D content area / panel background
        title_background=None,     # 3D title bar background
    ):
        # Fallbacks for extra keys
        if content_background is None:
            content_background = background_color
        if title_background is None:
            title_background = background_color

        # Save as plain dict so it's JSON-serializable.
        self.data = {
            "title_color": title_color,
            "title_font": title_font,
            "title_size": title_size,

            "axis_label_color": axis_label_color,
            "axis_label_font": axis_label_font,
            "axis_label_size": axis_label_size,

            "tick_label_color": tick_label_color,
            "tick_label_font": tick_label_font,
            "tick_label_size": tick_label_size,

            "tick_line_color": tick_line_color,
            "tick_line_width": tick_line_width,
            "grid_color": grid_color,
            "grid_width": grid_width,

            "legend_text_color": legend_text_color,
            "legend_bg_color": legend_bg_color,

            "background_color": background_color,

            "hover_text_color": hover_text_color,
            "hover_bg_color": hover_bg_color,

            "axis3d_color": axis3d_color,
            "axis3d_line_width": axis3d_line_width,
            "axis3d_font": axis3d_font,
            "axis3d_font_size": axis3d_font_size,

            "content_background": content_background,
            "title_background": title_background,
        }

    # ==========================================================
    # BASIC / CORE PRESETS
    # ==========================================================

    @classmethod
    def dark(cls):
        """Default dark theme (what you already had, now explicit)."""
        return cls(
            title_color="white",
            title_font="Arial",
            title_size=12,

            axis_label_color="white",
            axis_label_font="Arial",
            axis_label_size=10,

            tick_label_color="white",
            tick_label_font="Arial",
            tick_label_size=9,

            tick_line_color=(150, 150, 150),
            tick_line_width=1,
            grid_color=(60, 60, 60),
            grid_width=1,

            legend_text_color="white",
            legend_bg_color=(30, 30, 30, 180),

            background_color=(20, 20, 20),

            hover_text_color="yellow",
            hover_bg_color=(40, 40, 40, 220),

            axis3d_color=(160, 160, 160, 255),
            axis3d_line_width=1,
            axis3d_font="Arial",
            axis3d_font_size=13,

            content_background=(20, 20, 20),
            title_background=(0, 0, 0),
        )

    @classmethod
    def light(cls):
        return cls(
            title_color="#000000",
            title_font="Arial",
            title_size=12,

            axis_label_color="#000000",
            axis_label_font="Arial",
            axis_label_size=10,

            tick_label_color="#222222",
            tick_label_font="Arial",
            tick_label_size=9,

            tick_line_color=(80, 80, 80),
            tick_line_width=1,
            grid_color=(200, 200, 200),
            grid_width=1,

            legend_text_color="#000000",
            legend_bg_color=(245, 245, 245, 230),

            background_color=(245, 245, 245),

            hover_text_color="#000000",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(50, 50, 50, 255),
            axis3d_line_width=1,
            axis3d_font="Arial",
            axis3d_font_size=13,

            content_background=(245, 245, 245),
            title_background=(230, 230, 230),
        )

    @classmethod
    def matlab(cls):
        """
        Roughly reminiscent of classic MATLAB default look:
        white background, bold colors, light gray grid.
        """
        return cls(
            title_color="#000000",
            title_font="Arial",
            title_size=13,

            axis_label_color="#000000",
            axis_label_font="Arial",
            axis_label_size=11,

            tick_label_color="#000000",
            tick_label_font="Arial",
            tick_label_size=9,

            tick_line_color=(150, 150, 150),
            tick_line_width=0.5,
            grid_color=(180, 180, 180),
            grid_width=0.5,

            legend_text_color="#000000",
            legend_bg_color=(255, 255, 255, 220),

            background_color=(255, 255, 255),

            hover_text_color="#000000",
            hover_bg_color=(255, 255, 210, 230),

            axis3d_color=(0, 0, 0, 255),
            axis3d_line_width=1,
            axis3d_font="Arial",
            axis3d_font_size=13,

            content_background=(255, 255, 255),
            title_background=(240, 240, 240),
        )

    @classmethod
    def seaborn(cls):
        """
        Inspired by Seaborn darkgrid: light background, soft grid, neutral text.
        """
        return cls(
            title_color="#111111",
            title_font="DejaVu Sans",
            title_size=13,

            axis_label_color="#222222",
            axis_label_font="DejaVu Sans",
            axis_label_size=11,

            tick_label_color="#333333",
            tick_label_font="DejaVu Sans",
            tick_label_size=9,

            tick_line_color=(120, 120, 120),
            tick_line_width=1,
            grid_color=(210, 210, 210),
            grid_width=1,

            legend_text_color="#111111",
            legend_bg_color=(245, 245, 245, 230),

            background_color=(246, 246, 246),

            hover_text_color="#111111",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(80, 80, 80, 255),
            axis3d_line_width=1,
            axis3d_font="DejaVu Sans",
            axis3d_font_size=13,

            content_background=(246, 246, 246),
            title_background=(235, 235, 235),
        )

    @classmethod
    def ggplot(cls):
        """
        Inspired by ggplot2: gray background, white gridlines.
        """
        return cls(
            title_color="#3C3C3C",
            title_font="DejaVu Sans",
            title_size=13,

            axis_label_color="#3C3C3C",
            axis_label_font="DejaVu Sans",
            axis_label_size=11,

            tick_label_color="#555555",
            tick_label_font="DejaVu Sans",
            tick_label_size=9,

            tick_line_color=(120, 120, 120),
            tick_line_width=1,
            grid_color=(255, 255, 255),
            grid_width=1,

            legend_text_color="#3C3C3C",
            legend_bg_color=(230, 230, 230, 230),

            background_color=(225, 225, 225),

            hover_text_color="#000000",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(80, 80, 80, 255),
            axis3d_line_width=1,
            axis3d_font="DejaVu Sans",
            axis3d_font_size=13,

            content_background=(225, 225, 225),
            title_background=(210, 210, 210),
        )

    @classmethod
    def midnight_blue(cls):
        """
        Dark navy background, cyan/teal friendly look.
        """
        return cls(
            title_color="#E0F7FA",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#B2EBF2",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#B2EBF2",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(80, 140, 180),
            tick_line_width=1,
            grid_color=(40, 80, 120),
            grid_width=1,

            legend_text_color="#E0F7FA",
            legend_bg_color=(10, 40, 80, 200),

            background_color=(10, 20, 40),

            hover_text_color="#FFFFFF",
            hover_bg_color=(30, 70, 120, 230),

            axis3d_color=(180, 220, 255, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(10, 20, 40),
            title_background=(5, 10, 25),
        )

    @classmethod
    def neon(cls):
        """
        High-contrast neon look: black background, bright accents.
        """
        return cls(
            title_color="#FF00FF",
            title_font="Consolas",
            title_size=14,

            axis_label_color="#00FFFF",
            axis_label_font="Consolas",
            axis_label_size=11,

            tick_label_color="#39FF14",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(80, 80, 80),
            tick_line_width=1,
            grid_color=(50, 50, 50),
            grid_width=1,

            legend_text_color="#FFFFFF",
            legend_bg_color=(0, 0, 0, 220),

            background_color=(0, 0, 0),

            hover_text_color="#FFFF00",
            hover_bg_color=(30, 30, 30, 230),

            axis3d_color=(255, 0, 255, 255),
            axis3d_line_width=1,
            axis3d_font="Consolas",
            axis3d_font_size=13,

            content_background=(0, 0, 0),
            title_background=(10, 0, 20),
        )

    @classmethod
    def blender_dark(cls):
        """Blender-like dark gray UI."""
        return cls(
            title_color="#FFFFFF",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#E0E0E0",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#CCCCCC",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(120, 120, 120),
            tick_line_width=1,
            grid_color=(70, 70, 70),
            grid_width=1,

            legend_text_color="#FFFFFF",
            legend_bg_color=(40, 40, 40, 220),

            background_color=(50, 50, 50),

            hover_text_color="#FFFFFF",
            hover_bg_color=(60, 60, 60, 230),

            axis3d_color=(220, 220, 220, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(45, 45, 45),
            title_background=(35, 35, 35),
        )

    @classmethod
    def grayscale(cls):
        """Fully grayscale, good for printing."""
        return cls(
            title_color="#202020",
            title_font="Arial",
            title_size=13,

            axis_label_color="#303030",
            axis_label_font="Arial",
            axis_label_size=11,

            tick_label_color="#404040",
            tick_label_font="Arial",
            tick_label_size=9,

            tick_line_color=(120, 120, 120),
            tick_line_width=1,
            grid_color=(200, 200, 200),
            grid_width=1,

            legend_text_color="#202020",
            legend_bg_color=(235, 235, 235, 230),

            background_color=(245, 245, 245),

            hover_text_color="#000000",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(40, 40, 40, 255),
            axis3d_line_width=1,
            axis3d_font="Arial",
            axis3d_font_size=13,

            content_background=(245, 245, 245),
            title_background=(230, 230, 230),
        )

    @classmethod
    def monokai(cls):
        """Monokai-inspired dark theme."""
        return cls(
            title_color="#F8F8F2",
            title_font="Consolas",
            title_size=13,

            axis_label_color="#A6E22E",
            axis_label_font="Consolas",
            axis_label_size=11,

            tick_label_color="#F8F8F2",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(120, 120, 120),
            tick_line_width=1,
            grid_color=(60, 60, 60),
            grid_width=1,

            legend_text_color="#F8F8F2",
            legend_bg_color=(40, 40, 40, 220),

            background_color=(39, 40, 34),

            hover_text_color="#FD971F",
            hover_bg_color=(60, 60, 50, 230),

            axis3d_color=(248, 248, 242, 255),
            axis3d_line_width=1,
            axis3d_font="Consolas",
            axis3d_font_size=13,

            content_background=(39, 40, 34),
            title_background=(30, 31, 26),
        )

    @classmethod
    def cyberpunk(cls):
        """Aggressive neon magenta/cyan cyberpunk look."""
        return cls(
            title_color="#FF00FF",
            title_font="Consolas",
            title_size=14,

            axis_label_color="#00FFFF",
            axis_label_font="Consolas",
            axis_label_size=11,

            tick_label_color="#FFB3FF",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(100, 0, 150),
            tick_line_width=1,
            grid_color=(40, 0, 70),
            grid_width=1,

            legend_text_color="#FFEEFF",
            legend_bg_color=(10, 0, 30, 230),

            background_color=(5, 0, 15),

            hover_text_color="#FFFF00",
            hover_bg_color=(40, 0, 60, 230),

            axis3d_color=(255, 0, 255, 255),
            axis3d_line_width=1,
            axis3d_font="Consolas",
            axis3d_font_size=13,

            content_background=(5, 0, 15),
            title_background=(20, 0, 40),
        )

    @classmethod
    def pastel(cls):
        """Soft pastel look for reports."""
        return cls(
            title_color="#444444",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#666666",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#777777",
            tick_label_font="Segoe UI",
            tick_label_size=9,

            tick_line_color=(170, 170, 170),
            tick_line_width=1,
            grid_color=(220, 220, 230),
            grid_width=1,

            legend_text_color="#444444",
            legend_bg_color=(245, 245, 255, 230),

            background_color=(250, 250, 255),

            hover_text_color="#333333",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(120, 120, 140, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(250, 250, 255),
            title_background=(235, 235, 245),
        )

    @classmethod
    def oceanic(cls):
        """Cool blue/teal oceanic theme."""
        return cls(
            title_color="#E0F7FA",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#B2EBF2",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#B2EBF2",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(60, 130, 160),
            tick_line_width=1,
            grid_color=(30, 80, 110),
            grid_width=1,

            legend_text_color="#E0F7FA",
            legend_bg_color=(10, 40, 70, 220),

            background_color=(5, 25, 50),

            hover_text_color="#FFFFFF",
            hover_bg_color=(20, 80, 120, 230),

            axis3d_color=(200, 230, 255, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(5, 25, 50),
            title_background=(0, 15, 35),
        )

    @classmethod
    def lava(cls):
        """Dark theme with hot orange/red accents."""
        return cls(
            title_color="#FFCC80",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#FFAB40",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#FFECB3",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(200, 80, 40),
            tick_line_width=1,
            grid_color=(80, 30, 20),
            grid_width=1,

            legend_text_color="#FFE0B2",
            legend_bg_color=(40, 15, 10, 230),

            background_color=(20, 5, 5),

            hover_text_color="#FFFFFF",
            hover_bg_color=(70, 25, 20, 230),

            axis3d_color=(255, 204, 128, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(20, 5, 5),
            title_background=(40, 10, 10),
        )

    @classmethod
    def solarized_dark(cls):
        """Solarized Dark-inspired theme."""
        return cls(
            title_color="#93A1A1",
            title_font="DejaVu Sans",
            title_size=13,

            axis_label_color="#EEE8D5",
            axis_label_font="DejaVu Sans",
            axis_label_size=11,

            tick_label_color="#93A1A1",
            tick_label_font="DejaVu Sans",
            tick_label_size=9,

            tick_line_color=(88, 110, 117),
            tick_line_width=1,
            grid_color=(7, 54, 66),
            grid_width=1,

            legend_text_color="#EEE8D5",
            legend_bg_color=(0, 43, 54, 230),

            background_color=(0, 43, 54),

            hover_text_color="#B58900",
            hover_bg_color=(7, 54, 66, 230),

            axis3d_color=(131, 148, 150, 255),
            axis3d_line_width=1,
            axis3d_font="DejaVu Sans",
            axis3d_font_size=13,

            content_background=(0, 43, 54),
            title_background=(7, 54, 66),
        )

    @classmethod
    def solarized_light(cls):
        """Solarized Light-inspired theme."""
        return cls(
            title_color="#657B83",
            title_font="DejaVu Sans",
            title_size=13,

            axis_label_color="#586E75",
            axis_label_font="DejaVu Sans",
            axis_label_size=11,

            tick_label_color="#657B83",
            tick_label_font="DejaVu Sans",
            tick_label_size=9,

            tick_line_color=(147, 161, 161),
            tick_line_width=1,
            grid_color=(238, 232, 213),
            grid_width=1,

            legend_text_color="#586E75",
            legend_bg_color=(253, 246, 227, 230),

            background_color=(253, 246, 227),

            hover_text_color="#B58900",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(88, 110, 117, 255),
            axis3d_line_width=1,
            axis3d_font="DejaVu Sans",
            axis3d_font_size=13,

            content_background=(253, 246, 227),
            title_background=(238, 232, 213),
        )

    @classmethod
    def retro_wave(cls):
        """80s synthwave / retrowave style."""
        return cls(
            title_color="#FF7DEB",
            title_font="Consolas",
            title_size=14,

            axis_label_color="#7DF9FF",
            axis_label_font="Consolas",
            axis_label_size=11,

            tick_label_color="#FFB3FF",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(120, 50, 150),
            tick_line_width=1,
            grid_color=(60, 30, 80),
            grid_width=1,

            legend_text_color="#FFECFF",
            legend_bg_color=(20, 5, 40, 230),

            background_color=(5, 0, 20),

            hover_text_color="#FFFF8D",
            hover_bg_color=(40, 10, 70, 230),

            axis3d_color=(255, 125, 235, 255),
            axis3d_line_width=1,
            axis3d_font="Consolas",
            axis3d_font_size=13,

            content_background=(5, 0, 20),
            title_background=(25, 0, 50),
        )

    @classmethod
    def charcoal(cls):
        """Very dark gray, subtle contrast."""
        return cls(
            title_color="#F0F0F0",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#DDDDDD",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#CCCCCC",
            tick_label_font="Segoe UI",
            tick_label_size=9,

            tick_line_color=(90, 90, 90),
            tick_line_width=1,
            grid_color=(60, 60, 60),
            grid_width=1,

            legend_text_color="#F0F0F0",
            legend_bg_color=(35, 35, 35, 220),

            background_color=(25, 25, 25),

            hover_text_color="#FFFFFF",
            hover_bg_color=(55, 55, 55, 230),

            axis3d_color=(220, 220, 220, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(25, 25, 25),
            title_background=(15, 15, 15),
        )

    @classmethod
    def inferno(cls):
        """Dark theme tuned for Inferno colormap visuals."""
        return cls(
            title_color="#FFD180",
            title_font="Segoe UI",
            title_size=13,

            axis_label_color="#FFCC80",
            axis_label_font="Segoe UI",
            axis_label_size=11,

            tick_label_color="#FFE0B2",
            tick_label_font="Segoe UI",
            tick_label_size=9,

            tick_line_color=(120, 60, 60),
            tick_line_width=1,
            grid_color=(50, 20, 40),
            grid_width=1,

            legend_text_color="#FFE0B2",
            legend_bg_color=(30, 10, 30, 230),

            background_color=(10, 5, 15),

            hover_text_color="#FFFFFF",
            hover_bg_color=(60, 25, 40, 230),

            axis3d_color=(255, 204, 128, 255),
            axis3d_line_width=1,
            axis3d_font="Segoe UI",
            axis3d_font_size=13,

            content_background=(10, 5, 15),
            title_background=(30, 10, 30),
        )

    @classmethod
    def clean_minimal(cls):
        """Super minimal white theme for publications."""
        return cls(
            title_color="#000000",
            title_font="Arial",
            title_size=13,

            axis_label_color="#111111",
            axis_label_font="Arial",
            axis_label_size=11,

            tick_label_color="#222222",
            tick_label_font="Arial",
            tick_label_size=9,

            tick_line_color=(160, 160, 160),
            tick_line_width=1,
            grid_color=(220, 220, 220),
            grid_width=1,

            legend_text_color="#111111",
            legend_bg_color=(255, 255, 255, 230),

            background_color=(255, 255, 255),

            hover_text_color="#000000",
            hover_bg_color=(255, 255, 255, 240),

            axis3d_color=(60, 60, 60, 255),
            axis3d_line_width=1,
            axis3d_font="Arial",
            axis3d_font_size=13,

            content_background=(255, 255, 255),
            title_background=(240, 240, 240),
        )

    @classmethod
    def presentation(cls):
        """High-contrast theme optimized for projectors."""
        return cls(
            title_color="#FFFFFF",
            title_font="Segoe UI",
            title_size=16,

            axis_label_color="#FFFFFF",
            axis_label_font="Segoe UI",
            axis_label_size=13,

            tick_label_color="#F0F0F0",
            tick_label_font="Segoe UI",
            tick_label_size=11,

            tick_line_color=(180, 180, 180),
            tick_line_width=2,
            grid_color=(80, 80, 80),
            grid_width=1,

            legend_text_color="#FFFFFF",
            legend_bg_color=(0, 0, 0, 220),

            background_color=(0, 0, 0),

            hover_text_color="#FFFF00",
            hover_bg_color=(40, 40, 40, 230),

            axis3d_color=(240, 240, 240, 255),
            axis3d_line_width=2,
            axis3d_font="Segoe UI",
            axis3d_font_size=14,

            content_background=(0, 0, 0),
            title_background=(20, 20, 20),
        )

    @classmethod
    def terminal_green(cls):
        """Old-school terminal green-on-black."""
        return cls(
            title_color="#00FF00",
            title_font="Consolas",
            title_size=13,

            axis_label_color="#00DD00",
            axis_label_font="Consolas",
            axis_label_size=11,

            tick_label_color="#00AA00",
            tick_label_font="Consolas",
            tick_label_size=9,

            tick_line_color=(0, 80, 0),
            tick_line_width=1,
            grid_color=(0, 40, 0),
            grid_width=1,

            legend_text_color="#00FF00",
            legend_bg_color=(0, 0, 0, 230),

            background_color=(0, 0, 0),

            hover_text_color="#00FF00",
            hover_bg_color=(0, 30, 0, 230),

            axis3d_color=(0, 255, 0, 255),
            axis3d_line_width=1,
            axis3d_font="Consolas",
            axis3d_font_size=13,

            content_background=(0, 0, 0),
            title_background=(0, 10, 0),
        )

class GLTextQuad(gl.GLGraphicsItem.GLGraphicsItem):
    def __init__(self, text, pos=(0, 0, 0), font="Arial", font_size=32,
                 color=(255, 255, 255), bg=None, scale=1.0):
        super().__init__()
        self.text = text
        self.font = font
        self.font_size = font_size
        self.color = color
        self.bg = bg
        self.scale = scale
        self.pos = np.array(pos, dtype=float)

        # Rotation matrix (3x3)
        self.rotation = np.eye(3)

        # Texture info
        self._img_array = None
        self._texture_id = None
        self._texture_ready = False

        # Pre-render QImage → numpy array (no GL upload yet)
        self._create_image_array()

    def _create_image_array(self):
        fnt = QFont(self.font, self.font_size)
        fnt.setBold(True)
        fnt.setStyleStrategy(QFont.PreferAntialias)
        ### FIX: isolate font instance so metrics never leak across text objects
        unique_family = f"{self.font}_{id(self)}"
        fnt.setFamily(unique_family)
        fnt.setHintingPreference(QFont.PreferFullHinting)
        fnt.setKerning(False)
        fnt.setFixedPitch(True)
        metrics = QFontMetrics(fnt)
        w, h = metrics.horizontalAdvance(self.text) + 10, metrics.height() + 10

        img = QImage(w, h, QImage.Format_ARGB32_Premultiplied)
        img.fill(QtCore.Qt.transparent if self.bg is None else QColor(*self.bg))
        painter = QPainter(img)
        painter.setFont(fnt)
        painter.setPen(QColor(*self.color))
        painter.setRenderHint(QPainter.HighQualityAntialiasing, True)
        painter.setRenderHint(QPainter.TextAntialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.drawText(img.rect(), QtCore.Qt.AlignCenter, self.text)
        painter.end()

        img = img.mirrored(False, True)  # OpenGL Y-axis fix
        ptr = img.bits()
        ptr.setsize(img.byteCount())
        self._img_array = np.array(ptr, dtype=np.uint8).reshape(h, w, 4)
        self.size = (w, h)
        self._texture_ready = False  # Will be uploaded in paint()

    def _upload_texture(self):
        if self._img_array is None:
            return

        arr = self._img_array
        h, w = arr.shape[:2]

        # Create texture if not yet created
        if self._texture_id is None:
            self._texture_id = int(GL.glGenTextures(1))

        GL.glBindTexture(GL.GL_TEXTURE_2D, self._texture_id)

        # ------------------------------------------------------------
        # *** FINAL SETTINGS FOR SHARPEST POSSIBLE TEXT ***
        # ------------------------------------------------------------
        # 1) No mipmaps → avoids zoom-out blur
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)

        # 2) Clamp edges to avoid seams
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)

        # 3) Upload texture without mipmap levels
        GL.glTexImage2D(
            GL.GL_TEXTURE_2D, 0,
            GL.GL_RGBA, w, h, 0,
            GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, arr
        )

        GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
        self._texture_ready = True

    def setText(self, text, font=None, font_size=None,
                 color=None, bg=None):
        if text != self.text:
            current_scale = self.scale  # preserve exact world-scale
            self.text = text
            if font: self.font = font
            if font_size: self.font_size = font_size
            if color: self.color = color
            if bg: self.bg = bg
            self._create_image_array()
            self.scale = current_scale  # restore unchanged

    def setPos(self, x, y, z):
        self.pos = np.array([x, y, z], dtype=float)

    def setScale(self, s):
        self.scale = float(round(s, 2))

    def setRotation(self, angles):
        """Set Euler rotation angles (degrees)."""
        ax, ay, az = np.radians(angles)
        Rx = np.array([[1, 0, 0],
                       [0, np.cos(ax), -np.sin(ax)],
                       [0, np.sin(ax), np.cos(ax)]])
        Ry = np.array([[np.cos(ay), 0, np.sin(ay)],
                       [0, 1, 0],
                       [-np.sin(ay), 0, np.cos(ay)]])
        Rz = np.array([[np.cos(az), -np.sin(az), 0],
                       [np.sin(az), np.cos(az), 0],
                       [0, 0, 1]])
        self.rotation = Rz @ Ry @ Rx

    def get_world_size(self, reflect_rotation=False):
        """
        Return the approximate width and height of the text quad in world-space units.

        Parameters
        ----------
        reflect_rotation : bool, default=False
            If True, returns the full axis-aligned world-space bounding box size
            (which changes with rotation).
            If False, returns the intrinsic logical width and height,
            independent of rotation.

        Returns
        -------
        np.ndarray
            Array [width, height] in world units.
        """
        if not hasattr(self, "size"):
            return np.array([0.0, 0.0])

        w, h = self.size
        w *= self.scale
        h *= self.scale

        if not reflect_rotation:
            # Logical size: independent of rotation
            return np.array([w, h])

        # --- Reflect rotation: compute actual rotated extents ---
        local_corners = np.array([
            [-w * 0.5, -h * 0.5, 0],
            [ w * 0.5, -h * 0.5, 0],
            [ w * 0.5,  h * 0.5, 0],
            [-w * 0.5,  h * 0.5, 0],
        ])
        world_corners = (local_corners @ self.rotation.T) + self.pos
        min_pt = world_corners.min(axis=0)
        max_pt = world_corners.max(axis=0)
        size = max_pt - min_pt

        return np.array([size[0], size[1]])

    @property
    def base_size(self):
        """Return intrinsic pixel width/height (ignores scaling)."""
        if not hasattr(self, "size"):
            return np.array([0.0, 0.0])
        return np.array(self.size)
    
    def paint(self):
        """Render textured quad in 3D scene (flicker-free)."""
        if self._img_array is None:
            return

        # Ensure texture is uploaded only when GL context is ready
        if not self._texture_ready:
            try:
                self._upload_texture()
            except Exception:
                return  # context might not yet be ready

        if self._texture_id is None:
            return

        GL.glPushAttrib(GL.GL_ALL_ATTRIB_BITS)
        GL.glPushClientAttrib(GL.GL_CLIENT_ALL_ATTRIB_BITS)
        GL.glEnable(GL.GL_TEXTURE_2D)
        GL.glBindTexture(GL.GL_TEXTURE_2D, self._texture_id)
        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

        # Compute quad corners
        w, h = self.size
        w, h = w * self.scale * 0.5, h * self.scale * 0.5

        # Local quad (centered)
        corners = np.array([
            [-w, -h, 0],
            [ w, -h, 0],
            [ w,  h, 0],
            [-w,  h, 0],
        ])
        rotated = (corners @ self.rotation.T) + self.pos

        # Draw textured quad
        GL.glBegin(GL.GL_QUADS)
        GL.glTexCoord2f(0, 0); GL.glVertex3f(*rotated[0])
        GL.glTexCoord2f(1, 0); GL.glVertex3f(*rotated[1])
        GL.glTexCoord2f(1, 1); GL.glVertex3f(*rotated[2])
        GL.glTexCoord2f(0, 1); GL.glVertex3f(*rotated[3])
        GL.glEnd()

        # Restore GL state
        GL.glBindTexture(GL.GL_TEXTURE_2D, 0)
        GL.glDisable(GL.GL_BLEND)
        GL.glDisable(GL.GL_TEXTURE_2D)
        GL.glPopClientAttrib()
        GL.glPopAttrib()

    def cleanup(self):
        """Release GPU texture."""
        if self._texture_id is not None:
            GL.glDeleteTextures(int(self._texture_id))
            self._texture_id = None

class Axis3D(gl.GLGraphicsItem.GLGraphicsItem):
    def __init__(self, parent_view=None, gridlines_enabled = False):
        super().__init__()
        self.parent_view = parent_view
        self.color = (160, 160, 160, 255)
        self.line_width = 1
        self.font = "Arial"
        self.font_size = 13
        self.ticks_line_color = self.color
        self.ticks_line_width = self.line_width
        self.ticks_label_color = self.color
        self.ticks_label_font = self.font
        self.ticks_label_font_size = self.font_size
        self.axis_line_width = self.line_width
        self.axis_line_color = self.color
        self.axis_label_font = self.font
        self.axis_label_font_size = self.font_size
        self.axis_label_color = self.color
        self.gridlines_enabled = gridlines_enabled
        self.gridlines_color = self.color
        self.gridlines_width = self.line_width
        self._grid_line_depth_offset = 0
        self._text_image_scale = 1
        self.aspect_scales = (1.0, 1.0, 1.0)
        self._tick_labels = {"x": [], "y": [], "z": []}
        self._tick_label_items = {"x": [], "y": [], "z": [], "max_w_x": 0, "max_w_y": 0, "max_w_z": 0, "max_h_x": 0, "max_h_y": 0, "max_h_z": 0}
        self._axis_titles = {"x": None, "y": None, "z": None}
        self._axis_title_items = {"x": None, "y": None, "z": None}
        self._last_faces = None
        self._last_az_el = (None, None)
        self._last_shifts = [0, 0, 0]
        self._z_axis_visible = True
        self._x_axis_visible = True
        self._y_axis_visible = True
        self._pending_initial_layout = True

        # Data-space bounds
        self.xmin = self.xmax = 0.0
        self.ymin = self.ymax = 0.0
        self.zmin = self.zmax = 0.0

        # Continuous update timer
        # self._cam_timer = QtCore.QTimer()
        # self._cam_timer.timeout.connect(self._check_camera_motion)
        # self._cam_timer.start(50)

    @property
    def a_xmin(self):
        sx, sy, sz = self.aspect_scales
        return self.xmin * sx

    @property
    def a_ymin(self):
        sx, sy, sz = self.aspect_scales
        return self.ymin * sy
    
    @property
    def a_zmin(self):
        sx, sy, sz = self.aspect_scales
        return self.zmin * sz

    @property
    def a_xmax(self):
        sx, sy, sz = self.aspect_scales
        return self.xmax * sx

    @property
    def a_ymax(self):
        sx, sy, sz = self.aspect_scales
        return self.ymax * sy
    
    @property
    def a_zmax(self):
        sx, sy, sz = self.aspect_scales
        return self.zmax * sz
    
    @property
    def size(self):
        return (
            abs(self.xmax - self.xmin),
            abs(self.ymax - self.ymin),
            abs(self.zmax - self.zmin),
        )

    @property
    def a_size(self):
        return (
            abs(self.a_xmax - self.a_xmin),
            abs(self.a_ymax - self.a_ymin),
            abs(self.a_zmax - self.a_zmin),
        )

    def _check_camera_motion(self):
        """Continuously track camera motion and refresh axis."""
        if not self.parent_view:
            return
        az, el = self._current_angles()
        if (az, el) != self._last_az_el:
            self._last_az_el = (az, el)
            self._last_faces = None
            self.update()

    def _current_angles(self):
        """Get azimuth and elevation (in radians)."""
        try:
            az_deg = float(self.parent_view.opts.get('azimuth', 45.0)) % 360.0
            el_deg = float(self.parent_view.opts.get('elevation', 30.0)) % 360.0
        except Exception:
            az_deg, el_deg = 45.0, 30.0
        
        self._x_axis_visible = True
        self._y_axis_visible = True
        self._z_axis_visible = True

        if az_deg == 270 and el_deg == 90:
            self._z_axis_visible = False
        if az_deg == 0 and el_deg == 0:
            self._x_axis_visible = False
        if az_deg == 270 and el_deg == 0:
            self._y_axis_visible = False

        return np.deg2rad(az_deg), np.deg2rad(el_deg)

    def _auto_ticks(self, axis):
        """
        Compute aesthetically spaced ticks between axis min max
        """

        if axis == "x":
            a_range = self.a_size[0]
            raw_range = self.size[0]
            vmin, vmax = self.xmin, self.xmax
        elif axis == "y":
            a_range = self.a_size[1]
            raw_range = self.size[1]
            vmin, vmax = self.ymin, self.ymax
        elif axis == "z":
            a_range = self.a_size[2]
            raw_range = self.size[2]
            vmin, vmax = self.zmin, self.zmax

        # --- Estimate target tick count logically based on range ---
        # Wider ranges → more ticks; smaller ranges → fewer ticks
        
        exp = 2*np.log10(a_range)
        if exp < 0:
            target_ticks = 2
        elif exp < 1:
            target_ticks = 3
        elif exp < 2:
            target_ticks = 4
        elif exp < 3:
            target_ticks = 5
        else:
            target_ticks = 6

        # --- Compute rough step size ---
        step = raw_range / (target_ticks - 1)

        # --- Generate ticks ---
        n_steps = int(np.round(raw_range / step))
        ticks = np.linspace(vmin, vmax, n_steps + 1)

        # --- Ensure nice rounding for human readability ---
        ticks = np.round(ticks, int(max(0, -np.floor(np.log10(step))) + 1))
        return ticks

    def _get_visible_faces(self):
        """Determine which cube faces face the camera."""
        try:
            cam = np.array(self.parent_view.cameraPosition())
        except Exception:
            return ['xy_bottom', 'yz', 'xz']

        direction = -cam / (np.linalg.norm(cam) + 1e-9)
        faces = []
        faces.append('xy_top' if direction[2] <= 0 else 'xy_bottom')
        faces.append('yz_back' if direction[0] < 0 else 'yz')
        faces.append('xz_back' if direction[1] < 0 else 'xz')

        az = np.arctan2(direction[1], direction[0])
        if az < 0:
            az += 2 * np.pi
        return faces

    def _get_axis_bases(self, faces, aspect_ratio = False):
        """
        Compute adaptive base positions and corrected axis lengths.
        Axis lengths and offsets depend only on elevation (not azimuth).
        Azimuth affects only which edges are visible (orientation).
        """
        
        az, el = self._current_angles()
        if aspect_ratio:
            xmin, xmax, ymin, ymax, zmin, zmax = self.a_xmin, self.a_xmax, self.a_ymin, self.a_ymax, self.a_zmin, self.a_zmax
            xlen, ylen, zlen = self.a_size
        else:
            xmin, xmax, ymin, ymax, zmin, zmax = self.xmin, self.xmax, self.ymin, self.ymax, self.zmin, self.zmax
            xlen, ylen, zlen = self.size

        # --- Offset and scaling depend only on elevation ---
        el_term = np.abs(np.cos(el))   # 1 = face-on, 0 = top view
        x_off = 0.02 * xlen * el_term +  0.04 * xlen   # smaller at top view, larger at face-on
        y_off = 0.02 * ylen * el_term +  0.04 * ylen   # smaller at top view, larger at face-on
        z_off = 0.02 * zlen * el_term +  0.04 * zlen   # smaller at top view, larger at face-on

        try:
            cam = np.array(self.parent_view.cameraPosition())
            direction = cam / (np.linalg.norm(cam) + 1e-9)
        except Exception:
            direction = np.array([0, 0, 1.0])

        # Outward offset — only elevation controls distance
        x_shift = x_off * np.sign(direction[0]) if direction[0] != 0 else self._last_shifts[0]
        y_shift = y_off * np.sign(direction[1]) if direction[1] != 0 else self._last_shifts[1]
        z_shift = z_off
        self._last_shifts = [x_shift, y_shift, z_shift]

        # Determine which faces are front/back
        x_front = 'yz_back' not in faces
        y_front = 'xz_back' not in faces
        z_top = 'xy_top' in faces

        # --- Common virtual corner ---
        corner = np.array([
            xmax if not x_front else xmin,
            ymax if not y_front else ymin,
            zmin
        ]) + np.array([x_shift, y_shift, - z_shift])

        # --- Z-axis left/right placement (azimuth affects only this) ---
        if all(elem in faces for elem in ['yz_back', 'xz_back']):
            z_axis_x = xmax + abs(x_shift)
            z_axis_y = ymin - abs(y_shift)
        elif all(elem in faces for elem in ['yz', 'xz_back']):
            z_axis_x = xmax + abs(x_shift)
            z_axis_y = ymax + abs(y_shift)
        elif all(elem in faces for elem in ['yz', 'xz']):
            z_axis_x = xmin - abs(x_shift)
            z_axis_y = ymax + abs(y_shift)
        elif all(elem in faces for elem in ['yz_back', 'xz']):
            z_axis_x = xmin - abs(x_shift)
            z_axis_y = ymin - abs(y_shift)
        else:
            z_axis_x, z_axis_y = corner[0], corner[1]

        # --- Common base positions ---
        x_base_y, x_base_z = corner[1], corner[2]
        y_base_x, y_base_z = corner[0], corner[2]
        z_base_x, z_base_y = z_axis_x, z_axis_y

        return (
            x_base_y, x_base_z,
            y_base_x, y_base_z,
            z_base_x, z_base_y
        )

    def _create_tick_labels(self):
        """Create or update tick labels efficiently (reusing existing GLTextQuad)."""
        if not self.parent_view:
            return

        def _format_tick_value(v):
            """Compact ≤5-char numeric formatter."""
            if v == 0:
                return "0"
            abs_v = abs(v)
            if abs_v >= 10000 or (abs_v < 0.001 and abs_v != 0):
                s = f"{v:.0e}".replace("+0", "").replace("+", "").replace("e0", "e").replace("E", "e")
                try:
                    val = float(s)
                    int_str = str(int(val))
                    if len(int_str) <= 5:
                        s = int_str
                except Exception:
                    pass
            else:
                for p in range(6, 0, -1):
                    s = f"{v:.{p}f}"
                    if len(s) <= 5:
                        break
            if "." in s:
                s = s.rstrip("0").rstrip(".")
            if "e" in s:
                try:
                    val = float(s)
                    int_str = str(int(val))
                    if len(int_str) <= 5:
                        s = int_str
                except Exception:
                    pass
            return s

        # --- Compute new tick positions ---
        new_ticks = {
            "x": self._auto_ticks("x"),
            "y": self._auto_ticks("y"),
            "z": self._auto_ticks("z"),
        }
        axis_len = {
            "x": self.a_size[0],
            "y": self.a_size[1],
            "z": self.a_size[2]
        }
        # --- For each axis ---
        for axis in ["x", "y", "z"]:
            old_ticks = self._tick_labels[axis]
            old_items = self._tick_label_items[axis]
            new_vals = new_ticks[axis]
            n_old, n_new = len(old_ticks), len(new_vals)

            # Update tick array
            self._tick_labels[axis] = new_vals

            # Case 1: same count — just update text
            if n_old == n_new and n_new > 0:
                for lbl, val in zip(old_items, new_vals):
                    lbl.setText(_format_tick_value(val))

            # Case 2: fewer new ticks — remove extras
            elif n_new < n_old:
                for lbl in old_items[n_new:]:
                    if lbl in self.parent_view.items:
                        self.parent_view.removeItem(lbl)
                self._tick_label_items[axis] = old_items[:n_new]
                for lbl, val in zip(self._tick_label_items[axis], new_vals):
                    lbl.setText(_format_tick_value(val))

            # Case 3: more new ticks — reuse existing + create new
            else:
                # Update existing labels first
                for lbl, val in zip(old_items, new_vals[:n_old]):
                    lbl.setText(_format_tick_value(val))

                # Create additional ones
                extra_labels = []
                for val in new_vals[n_old:]:
                    lbl = GLTextQuad(
                        _format_tick_value(val),
                        color=self.ticks_label_color,
                        font=self.ticks_label_font,
                        font_size=self.ticks_label_font_size,
                        scale=self._text_image_scale
                    )
                    lbl.setGLOptions("translucent")
                    lbl.setDepthValue(1e6)
                    extra_labels.append(lbl)
                    if lbl not in self.parent_view.items:
                        self.parent_view.addItem(lbl)
                        pass
                self._tick_label_items[axis].extend(extra_labels)

            # --- Update max length for scaling ---
            max_w = max(lbl.base_size[0] for lbl in self._tick_label_items[axis])
            max_h = max(lbl.base_size[1] for lbl in self._tick_label_items[axis])

            scale = 1
            target_w = max_w * (len(new_ticks[axis]) + 1)
            if axis_len[axis] != target_w:
                scale = axis_len[axis] / target_w
            for lbl in self._tick_label_items[axis]:
                lbl.setScale(scale)

            self._tick_label_items[f"max_w_{axis}"] = max_w*scale
            self._tick_label_items[f"max_h_{axis}"] = max_h*scale

    def _update_labels(self, force=False):
        """
        Reposition tick labels and axis titles with full compensation for
        equal-aspect scaling.

        This version keeps visual distances consistent even when the axis
        is scaled non-uniformly (sx, sy, sz).
        """
        if not self.parent_view:
            return
        
        if self._pending_initial_layout:
            QtCore.QTimer.singleShot(0, lambda: self._update_labels(force=True))
            self._pending_initial_layout = False
            return

        # ---------- 1) CAMERA + FACES ----------
        faces = self._get_visible_faces()
        az, el = self._current_angles()
        sx, sy, sz = self.aspect_scales

        if (not force) and (faces == self._last_faces) and ((az, el) == self._last_az_el):
            return

        # ---------- 3) AXIS BASE LOCATIONS ----------
        (
            x_axis_y, x_axis_z,
            y_axis_x, y_axis_z,
            z_axis_x, z_axis_y
        ) = self._get_axis_bases(faces, True)

        xlen, ylen, zlen = self.a_size

        # ---------- 4) AXIS ORIENTATION COEFFS ----------
        x_axis_coeff = y_axis_coeff = 1
        z_axis_x_coeff = z_axis_y_coeff = 1
        if all(elem in faces for elem in ['yz_back', 'xz_back']):
            z_axis_y_coeff = -1
        elif all(elem in faces for elem in ['yz', 'xz_back']):
            z_axis_y_coeff = 1
            y_axis_coeff *= -1
        elif all(elem in faces for elem in ['yz', 'xz']):
            x_axis_coeff *= -1
            y_axis_coeff *= -1
            z_axis_x_coeff = -1
        elif all(elem in faces for elem in ['yz_back', 'xz']):
            x_axis_coeff *= -1
            z_axis_y_coeff = -1
            z_axis_x_coeff = -1

        # =======================================================
        # 5) REPOSITION TICK LABELS (COMPENSATED BY 1/sx, 1/sy, 1/sz)
        # =======================================================
        for axis, ticks, labels, max_h in [
            ("x", self._tick_labels["x"], self._tick_label_items["x"], self._tick_label_items["max_h_x"]),
            ("y", self._tick_labels["y"], self._tick_label_items["y"], self._tick_label_items["max_h_y"]),
            ("z", self._tick_labels["z"], self._tick_label_items["z"], self._tick_label_items["max_h_z"]),
        ]:

            for val, lbl in zip(ticks, labels):
                if axis == "x":
                    if self._x_axis_visible:
                        lbl.setVisible(True)
                    else:
                        lbl.setVisible(False)

                    size = lbl.get_world_size()

                    # **Compensated offsets**
                    y_off = (x_axis_coeff * size[1])
                    z_off = (-max_h)

                    lbl.setPos(
                        val*sx,
                        x_axis_y + y_off,
                        x_axis_z + z_off
                    )

                    lbl.setRotation((90 - np.rad2deg(el), 0,
                                    180 if x_axis_coeff == 1 else 0))

                elif axis == "y":
                    if self._y_axis_visible:
                        lbl.setVisible(True)
                    else:
                        lbl.setVisible(False)

                    size = lbl.get_world_size()

                    x_off = (y_axis_coeff * size[1])
                    z_off = (-max_h)

                    lbl.setPos(
                        y_axis_x + x_off,
                        val*sy,
                        y_axis_z + z_off
                    )

                    lbl.setRotation((90 - np.rad2deg(el), 0,
                                    90 if y_axis_coeff == 1 else 270))

                else:  # ------- Z axis labels -------
                    if self._z_axis_visible:
                        lbl.setVisible(True)
                    else:
                        lbl.setVisible(False)

                    x_off = (z_axis_x_coeff * max_h)
                    y_off = (z_axis_y_coeff * max_h)

                    lbl.setPos(
                        z_axis_x + x_off,
                        z_axis_y + y_off,
                        val*sz
                    )

                    x_ang = -90 * z_axis_x_coeff
                    lbl.setRotation((x_ang - np.rad2deg(az),
                                    90,
                                    z_axis_x_coeff * 90 + z_axis_y_coeff * 180))

        # =======================================================
        # 6) REPOSITION AXIS TITLES (ALSO COMPENSATED BY 1/sx,1/sy,1/sz)
        # =======================================================
        for axis, title_item in self._axis_title_items.items():
            if not title_item:
                continue

            size = title_item.get_world_size()
            max_h = self._tick_label_items[f"max_h_{axis}"]

            if axis == "x":
                vis = self._x_axis_visible
                y_off = (x_axis_coeff * (size[1] + max_h))
                z_off = -(size[1] + max_h)

                title_item.setVisible(vis)
                title_item.setPos(
                    self.a_xmin + xlen / 2,
                    x_axis_y + y_off,
                    x_axis_z + z_off
                )

                title_item.setRotation((90 - np.rad2deg(el), 0,
                                        180 if x_axis_coeff == 1 else 0))

            elif axis == "y":
                vis = self._y_axis_visible
                x_off = (y_axis_coeff * (size[1] + max_h))
                z_off = -(size[1] + max_h)

                title_item.setVisible(vis)
                title_item.setPos(
                    y_axis_x + x_off,
                    self.a_ymin + ylen / 2,
                    y_axis_z + z_off
                )

                title_item.setRotation((90 - np.rad2deg(el), 0,
                                        90 if y_axis_coeff == 1 else 270))

            else:  # Z axis title
                vis = self._z_axis_visible
                x_off = (z_axis_x_coeff * (size[1] + max_h))
                y_off = (z_axis_y_coeff * (size[1] + max_h))

                title_item.setVisible(vis)
                title_item.setPos(
                    z_axis_x + x_off,
                    z_axis_y + y_off,
                    self.a_zmin + zlen / 2
                )

                x_ang = -90 * z_axis_x_coeff
                title_item.setRotation((x_ang - np.rad2deg(az),
                                        90,
                                        z_axis_x_coeff * 90 + z_axis_y_coeff * 180))

        # Save state
        self._last_faces = faces
        self._last_az_el = (az, el)

    def _set_aspect_scale_factors(self, sx, sy, sz):
        self.aspect_scales = (sx, sy, sz)

    def _scale_axis_title(self, axis: str, item):
        """
        Scale axis title so that its *height* on screen is consistent
        regardless of world position or axis length.
        Based on GLTextQuad base_size (texture pixel size).
        """

        if item is None:
            return

        # Texture height at scale=1 (world units)
        try:
            base_w, base_h = item.base_size
        except Exception:
            return

        if base_h <= 0:
            return

        # Use longest axis for normalization (overall plot scale)
        longest_axis = max(self.a_size)
        if longest_axis <= 0:
            return

        # Desired title height: 8% of longest axis
        # (tweak: 0.06 → smaller, 0.10 → larger)
        desired_height = longest_axis * 0.08

        raw_scale = desired_height / base_h

        # Clamp scale so text never becomes microscopic or massive
        min_scale = 0.01 * self._text_image_scale

        scale = max(raw_scale, min_scale)
        item.setScale(scale)

    def _rescale_axis_titles(self):
        """Rescale all current axis titles after bounds / theme changes."""
        for axis, item in self._axis_title_items.items():
            if item is None:
                continue
            self._scale_axis_title(axis, item)

    def set_bounds(self, xmin=None, xmax=None, ymin=None, ymax=None, zmin=None, zmax=None): 
        """Set data-space bounds for axis and labels (robust for tiny ranges)."""     
        # --- X ---
        if xmin is not None and xmax is not None:
            self.xmin, self.xmax = float(xmin), float(xmax)

        # --- Y ---
        if ymin is not None and ymax is not None:
            self.ymin, self.ymax = float(ymin), float(ymax)

        # --- Z ---
        if zmin is not None and zmax is not None:
            self.zmin, self.zmax = float(zmin), float(zmax)

        self._grid_line_depth_offset = 0.002 * max(self.a_size)
        self._create_tick_labels()
        self._rescale_axis_titles()
        self._update_labels(force=True)
        self.update()

    def set_axis_labels(self, x=None, y=None, z=None, font=None, font_size=None, color=None):
        """
        Set or update axis titles using GLTextQuad, avoiding unnecessary redraws.

        - Only rebuilds a label if its text or style actually changed.
        - Keeps previously created GLTextQuad objects if possible.
        - Scales titles based on axis length and texture size.
        """
        labels = {"x": x, "y": y, "z": z}
        color = color or self.axis_label_color
        font = font or self.axis_label_font
        font_size = font_size or self.axis_label_font_size

        for axis, new_text in labels.items():
            if new_text is None:
                continue  # skip if not specified

            # already stored text
            current_text = self._axis_titles.get(axis)
            self._axis_titles[axis] = new_text  # always update stored name

            item = self._axis_title_items.get(axis)

            # --- Case 1: Create new label ---
            if item is None:
                item = GLTextQuad(
                    new_text,
                    color=color,
                    font=font,
                    font_size=font_size,
                    scale=self._text_image_scale,
                )
                item.setGLOptions("translucent")
                item.setDepthValue(1e6)
                self._axis_title_items[axis] = item
                if self.parent_view and item not in self.parent_view.items:
                    self.parent_view.addItem(item)

            # --- Case 2: Update existing label if text/style changed ---
            elif (
                new_text != current_text
                or item.color != color
                or item.font != font
                or item.font_size != font_size
            ):
                item.setText(new_text, color=color, font=font, font_size=font_size)

            # --- Scale title relative to axis length ---
            self._scale_axis_title(axis, item)

        # --- Clean up unused labels (if some axis title removed explicitly later) ---
        # (You can call set_axis_labels(x="", y=None, z=None) etc if you want to clear.)

        # --- Finally update their positions ---
        self._update_labels(force=True)

    def paint(self):
        """Draw axis lines and ticks with dynamic perspective."""
        eps = self._grid_line_depth_offset
        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)

        faces = self._get_visible_faces()
        az, el = self._current_angles()
        if (faces != self._last_faces) or ((az, el) != self._last_az_el):
            self._update_labels(force=True)
            self._last_faces = faces
            self._last_az_el = (az, el)

        (
            x_axis_y, x_axis_z,
            y_axis_x, y_axis_z,
            z_axis_x, z_axis_y
        ) = self._get_axis_bases(faces)

        # === Main axes ===
        x_start = (self.xmin, x_axis_y, x_axis_z)
        x_end = (self.xmax, x_axis_y, x_axis_z)
        y_start = (y_axis_x, self.ymin, y_axis_z)
        y_end = (y_axis_x, self.ymax, y_axis_z)
        z_start = (z_axis_x, z_axis_y, x_axis_z)
        z_end = (z_axis_x, z_axis_y, self.zmax)

        xticks = self._auto_ticks("x")
        yticks = self._auto_ticks("y")
        zticks = self._auto_ticks("z")
        xy_grid_lines = False
        yz_grid_lines = False
        xz_grid_lines = False

        if all(elem in faces for elem in ['yz_back', 'xz_back']):
            x_end = (y_axis_x, x_axis_y, x_axis_z)
            y_start = (y_axis_x, x_axis_y, y_axis_z)
            y_end = (y_axis_x, z_axis_y, y_axis_z)
            xz_grid_lines = True
            yz_grid_lines = True
            if "xy_bottom" in faces:
                xy_grid_lines = True
        elif all(elem in faces for elem in ['yz', 'xz_back']):
            y_end = (y_axis_x, x_axis_y, y_axis_z)
            x_start = (y_axis_x, x_axis_y, x_axis_z)
            x_end = (z_axis_x, x_axis_y, x_axis_z)
            xz_grid_lines = True
            yz_grid_lines = False
            if "xy_bottom" in faces:
                xy_grid_lines = True
        elif all(elem in faces for elem in ['yz', 'xz']):
            x_start = (y_axis_x, x_axis_y, x_axis_z)
            y_start = (y_axis_x, x_axis_y, y_axis_z)
            y_end = (y_axis_x, z_axis_y, y_axis_z)
            xz_grid_lines = False
            yz_grid_lines = False
            if "xy_bottom" in faces:
                xy_grid_lines = True
        elif all(elem in faces for elem in ['yz_back', 'xz']):
            y_start = (y_axis_x, x_axis_y, y_axis_z)
            x_start = (y_axis_x, x_axis_y, x_axis_z)
            x_end = (z_axis_x, x_axis_y, x_axis_z)
            xz_grid_lines = False
            yz_grid_lines = True
            if "xy_bottom" in faces:
                xy_grid_lines = True

        GL.glLineWidth(self.axis_line_width)
        GL.glColor4fv(np.array(self.axis_line_color)/255)
        GL.glBegin(GL.GL_LINES)          

        if self._x_axis_visible:
            GL.glVertex3fv(x_start)
            GL.glVertex3fv(x_end)

        if self._y_axis_visible:
            GL.glVertex3fv(y_start)
            GL.glVertex3fv(y_end)

        if self._z_axis_visible:
            GL.glVertex3fv(z_start)
            GL.glVertex3fv(z_end)

        GL.glEnd()

        GL.glEnable(GL.GL_POINT_SMOOTH)
        GL.glPointSize(5*self.ticks_line_width)
        GL.glColor4fv(np.array(self.ticks_line_color)/255)
        GL.glBegin(GL.GL_POINTS)   
        
        if self._x_axis_visible:
            for xs in xticks:
                GL.glVertex3f(xs, x_axis_y, x_axis_z)              

        if self._y_axis_visible:
            for ys in yticks:
                GL.glVertex3f(y_axis_x, ys, y_axis_z)

        if self._z_axis_visible:
            for zs in zticks:
                GL.glVertex3f(z_axis_x, z_axis_y, zs)
        
        GL.glEnd()

        if self.gridlines_enabled:
            GL.glLineWidth(self.gridlines_width)
            GL.glColor4fv(np.array(self.gridlines_color)/255)
            GL.glBegin(GL.GL_LINES)
            if self._x_axis_visible:
                for xs in xticks: 
                    if self._z_axis_visible:
                        if xz_grid_lines:
                            GL.glVertex3f(xs, self.ymin - eps, self.zmin)
                            GL.glVertex3f(xs, self.ymin - eps, self.zmax)
                        else:
                            GL.glVertex3f(xs, self.ymax + eps, self.zmin)
                            GL.glVertex3f(xs, self.ymax + eps, self.zmax)
                    if self._y_axis_visible:
                        if xy_grid_lines:
                            GL.glVertex3f(xs, self.ymin, self.zmax + eps)
                            GL.glVertex3f(xs, self.ymax, self.zmax + eps)
                        else:
                            GL.glVertex3f(xs, self.ymin, self.zmin - eps)
                            GL.glVertex3f(xs, self.ymax, self.zmin - eps)

            if self._y_axis_visible: 
                for ys in yticks:
                    if self._z_axis_visible:
                        if yz_grid_lines:
                            GL.glVertex3f(self.xmin - eps, ys, self.zmin)
                            GL.glVertex3f(self.xmin - eps, ys, self.zmax)
                        else:
                            GL.glVertex3f(self.xmax + eps, ys, self.zmin)
                            GL.glVertex3f(self.xmax + eps, ys, self.zmax)
                    if self._x_axis_visible:
                        if xy_grid_lines:
                            GL.glVertex3f(self.xmin, ys, self.zmax + eps)
                            GL.glVertex3f(self.xmax, ys, self.zmax + eps)
                        else:                    
                            GL.glVertex3f(self.xmin, ys, self.zmin - eps)
                            GL.glVertex3f(self.xmax, ys, self.zmin - eps)

            if self._z_axis_visible: 
                for zs in zticks:
                    if self._y_axis_visible:
                        if yz_grid_lines:
                            GL.glVertex3f(self.xmin - eps, self.ymin, zs)
                            GL.glVertex3f(self.xmin - eps, self.ymax, zs)
                        else:
                            GL.glVertex3f(self.xmax + eps, self.ymin, zs)
                            GL.glVertex3f(self.xmax + eps, self.ymax, zs)

                    if self._x_axis_visible:
                        if xz_grid_lines:
                            GL.glVertex3f(self.xmin, self.ymin - eps, zs)
                            GL.glVertex3f(self.xmax, self.ymin - eps, zs)
                        else:
                            GL.glVertex3f(self.xmin, self.ymax + eps, zs)
                            GL.glVertex3f(self.xmax, self.ymax + eps, zs)
            
            GL.glEnd()
        GL.glDisable(GL.GL_BLEND)

    def rebuild(self):
        """
        Fully rebuild all axis elements from scratch:
            - Tick values
            - Tick GLTextQuad labels
            - Axis title GLTextQuad labels
            - Visibility states
            - Internal caches
            - Label scales and positions
        This is used after style/theme changes or after major camera changes.
        """
        if not self.parent_view:
            return

        # -------------------------------------------------------
        # 1 — Reset caches so everything recomputes cleanly
        # -------------------------------------------------------
        self._last_faces = None
        self._last_az_el = (None, None)
        self._last_shifts = [0, 0, 0]

        # Clear tick labels
        for axis in ["x", "y", "z"]:
            # delete old GLTextQuad objects
            for lbl in self._tick_label_items[axis]:
                try:
                    if lbl in self.parent_view.items:
                        self.parent_view.removeItem(lbl)
                except Exception:
                    pass

            self._tick_label_items[axis] = []
            self._tick_labels[axis] = []

            # clear max sizes
            self._tick_label_items[f"max_w_{axis}"] = 0
            self._tick_label_items[f"max_h_{axis}"] = 0

        # Clear axis titles
        for axis, lbl in list(self._axis_title_items.items()):
            if lbl is not None:
                try:
                    if lbl in self.parent_view.items:
                        self.parent_view.removeItem(lbl)
                except Exception:
                    pass
            self._axis_title_items[axis] = None

        # -------------------------------------------------------
        # 2 — Recompute tick values
        # -------------------------------------------------------
        xticks = self._auto_ticks("x")
        yticks = self._auto_ticks("y")
        zticks = self._auto_ticks("z")

        self._tick_labels["x"] = xticks
        self._tick_labels["y"] = yticks
        self._tick_labels["z"] = zticks

        # -------------------------------------------------------
        # 3 — Recreate tick label GLTextQuad objects
        # -------------------------------------------------------
        for axis in ["x", "y", "z"]:
            ticks = self._tick_labels[axis]

            for val in ticks:
                lbl = GLTextQuad(
                    str(val),
                    color=self.ticks_label_color,
                    font=self.ticks_label_font,
                    font_size=self.ticks_label_font_size,
                    scale=self._text_image_scale,
                )
                lbl.setGLOptions("translucent")
                lbl.setDepthValue(1e6)

                self._tick_label_items[axis].append(lbl)
                self.parent_view.addItem(lbl)

            # update max sizes
            if self._tick_label_items[axis]:
                max_w = max(lbl.base_size[0] for lbl in self._tick_label_items[axis])
                max_h = max(lbl.base_size[1] for lbl in self._tick_label_items[axis])
            else:
                max_w = max_h = 0

            self._tick_label_items[f"max_w_{axis}"] = max_w
            self._tick_label_items[f"max_h_{axis}"] = max_h

        # -------------------------------------------------------
        # 4 — Recreate axis titles if text exists
        # -------------------------------------------------------
        for axis, text in self._axis_titles.items():
            if text in (None, ""):
                continue

            lbl = GLTextQuad(
                text,
                color=self.axis_label_color,
                font=self.axis_label_font,
                font_size=self.axis_label_font_size,
                scale=self._text_image_scale,
            )
            lbl.setGLOptions("translucent")
            lbl.setDepthValue(1e6)

            self._axis_title_items[axis] = lbl
            self.parent_view.addItem(lbl)

        # -------------------------------------------------------
        # 5 — Force new layout and repaint
        # -------------------------------------------------------
        self._create_tick_labels()     # rebuild auto formatting, scaling
        self._rescale_axis_titles()
        self._update_labels(force=True)
        self.update()

class StylishHoverLabel:
    locked_labels = []

    def __init__(self, viewbox, text_color="yellow", bg_color=(80, 80, 80, 200)):
        self.vb = viewbox
        self.data_pos = None
        self.nearest_curve = None

        self.text_item = QGraphicsSimpleTextItem()
        self.text_item.setZValue(10)
        self.text_item.setBrush(pg.mkBrush(text_color))
        self.text_item.hide()

        self.bg_item = QGraphicsPathItem()
        self.bg_item.setZValue(9)
        self.bg_item.setBrush(QBrush(QColor(*bg_color)))
        self.bg_item.setPen(QPen(Qt.NoPen))
        self.bg_item.hide()

        scene = self.vb.scene()
        scene.addItem(self.bg_item)
        scene.addItem(self.text_item)
        self.text_item.setParentItem(self.vb)
        self.bg_item.setParentItem(self.vb)

    def show(self, text, xdata, ydata, nearst_curve):
        """Draw tooltip at (xdata, ydata) in data coordinates."""
        self.nearest_curve = nearst_curve
        self.text = text
        self.data_pos = (xdata, ydata)
        self._draw()

    def _clamp_rect(self, rect, bounds):
        dx = dy = 0

        if rect.right() > bounds.right():
            dx = bounds.right() - rect.right()
        elif rect.left() < bounds.left():
            dx = bounds.left() - rect.left()

        if rect.bottom() > bounds.bottom():
            dy = bounds.bottom() - rect.bottom()
        elif rect.top() < bounds.top():
            dy = bounds.top() - rect.top()

        return rect.translated(dx, dy), dx, dy

    def _draw(self):
        if self.data_pos is None:
            return

        xdata, ydata = self.data_pos

        # -------------------------------------------------
        # 1) Data → ViewBox-local coordinates
        # -------------------------------------------------
        scene_pt = self.vb.mapViewToScene(QPointF(xdata, ydata))
        local_pt = self.vb.mapFromScene(scene_pt)
        px, py = local_pt.x(), local_pt.y()

        vb_rect = self.vb.boundingRect()

        # -------------------------------------------------
        # 2) Arrow TIP = data point (clamped only to be drawable)
        # -------------------------------------------------
        arrow_tip_x = min(max(px, vb_rect.left()), vb_rect.right())
        arrow_tip_y = min(max(py, vb_rect.top()), vb_rect.bottom())

        # -------------------------------------------------
        # 3) Text + bubble size
        # -------------------------------------------------
        self.text_item.setText(self.text)
        text_rect = self.text_item.boundingRect()

        padding = 4
        arrow_h = 10
        arrow_w = 7
        gap = 2

        bubble_w = text_rect.width() + padding * 2
        bubble_h = text_rect.height() + padding * 2

        # -------------------------------------------------
        # 4) Initial bubble rect (ABOVE arrow, centered)
        # -------------------------------------------------
        bubble_rect = QRectF(
            arrow_tip_x - bubble_w / 2,
            arrow_tip_y - arrow_h - gap - bubble_h,
            bubble_w,
            bubble_h,
        )

        # -------------------------------------------------
        # 5) Clamp bubble to ViewBox (bubble moves, arrow tip does NOT)
        # -------------------------------------------------
        bubble_rect, dx, dy = self._clamp_rect(bubble_rect, vb_rect)

        # -------------------------------------------------
        # 6) Text position
        # -------------------------------------------------
        self.text_item.setPos(
            bubble_rect.left() + padding,
            bubble_rect.top() + padding,
        )

        # -------------------------------------------------
        # 7) Arrow BASE = bubble bottom-center (after clamp)
        # -------------------------------------------------
        base_x = bubble_rect.center().x()
        base_y = bubble_rect.bottom()

        # -------------------------------------------------
        # 8) Build background + arrow path
        # -------------------------------------------------
        path = QPainterPath()
        path.addRoundedRect(bubble_rect, 5, 5)

        arrow = QPainterPath()
        arrow.moveTo(arrow_tip_x, arrow_tip_y)
        arrow.lineTo(base_x + arrow_w, base_y)
        arrow.lineTo(base_x - arrow_w, base_y)
        arrow.closeSubpath()

        path.addPath(arrow)

        self.bg_item.setPath(path)

        # -------------------------------------------------
        # 9) Show
        # -------------------------------------------------
        self.bg_item.show()
        self.text_item.show()

    def update_position(self):
        """Reposition when pan/zoom occurs."""
        if self.isVisible() and self.data_pos:
            self._draw()

    def hide(self):
        self.text_item.hide()
        self.bg_item.hide()

    def isVisible(self):
        return self.text_item.isVisible() or self.bg_item.isVisible()

    @classmethod
    def update_locked(cls):
        for lbl in list(cls.locked_labels):
            lbl.update_position()

    @classmethod
    def lock_label(cls, view, text, xdata, ydata, nearst_curve):
        lbl = StylishHoverLabel(view)
        lbl.show(text, xdata, ydata, nearst_curve)
        cls.locked_labels.append(lbl)

    @classmethod
    def clear_locked(cls):
        for lbl in list(cls.locked_labels):
            lbl.hide()
        cls.locked_labels.clear()
    
    @classmethod
    def remove_locked(cls, xdata, ydata):
        for lbl in list(cls.locked_labels):
            if lbl.data_pos == (xdata, ydata):
                lbl.hide()
                cls.locked_labels.remove(lbl)
                return True
        return False

class StylishHoverLabel3D(QtWidgets.QWidget):
    """
    Floating hover label for GLViewWidget meshes.
    ✅ Rounded rectangle + arrow like 2D StylishHoverLabel
    ✅ Tracks 3D world coordinates in screen space
    ✅ Supports locked labels and right-click clear
    """
    locked_labels = []

    def __init__(self, view, text_color="yellow", bg_color=(40, 40, 40, 220)):
        super().__init__(view)
        self.view = view
        self.text_color = text_color
        self.bg_color = bg_color
        self.data_pos = None
        self._text_str = ""
        self.name = None

        # Make transparent widget overlay
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.hide()

        # Text label
        self.text_label = QtWidgets.QLabel(self)
        self.text_label.setStyleSheet(f"""
            QLabel {{
                color: {text_color};
                background-color: transparent;
                font-family: Consolas;
                font-size: 8pt;
            }}
        """)

        self.arrow_size = 8
        self.padding = 6

    def show_text(self, text, world_pos, name):
        """Display text anchored to a 3D world coordinate."""
        self._text_str = text
        self.name = name
        self.data_pos = world_pos
        self._draw()
        self.show()

    def _draw(self):
        if self.data_pos is None:
            return

        x, y, z = self.data_pos
        w, h = self.view.width(), self.view.height()

        # === Project world → screen coordinates ===
        proj_mat = np.array(self.view.projectionMatrix().data()).reshape(4, 4).T
        view_mat = np.array(self.view.viewMatrix().data()).reshape(4, 4).T
        clip = proj_mat @ (view_mat @ np.array([x, y, z, 1.0]))
        if clip[3] <= 0:
            self.hide()
            return
        clip /= clip[3]
        sx = (clip[0] * 0.5 + 0.5) * w
        sy = (1 - (clip[1] * 0.5 + 0.5)) * h

        # === Update label text ===
        self.text_label.setText(self._text_str)

        # --- Robust multi-line measurement via QTextDocument ---
        doc = QTextDocument()
        doc.setDefaultFont(self.text_label.font())
        doc.setPlainText(self._text_str)         # treats '\n' as line breaks
        doc.setTextWidth(-1)                     # no forced wrapping; measure natural size
        doc_size = doc.size()                    # QSizeF in device-independent px
        text_w = int(np.ceil(doc_size.width()))
        text_h = int(np.ceil(doc_size.height()))

        # --- Box size (padding + arrow) ---
        width  = text_w + self.padding * 2
        height = text_h + self.padding * 2 + self.arrow_size + 2  # +2 safety

        # Apply geometry (don't rely on self.width() immediately—use computed values)
        # NOTE: ensure you are NOT using setFixedSize(...) in __init__. If you are, remove it.
        self.setMinimumSize(width, height)
        self.resize(width, height)

        # Size the QLabel to its text rectangle (no wrap here)
        self.text_label.resize(text_w, text_h)
        self.text_label.move(self.padding, self.padding)  # sits above arrow area

        # Position the bubble, centered horizontally over the anchor point
        self.move(int(sx - width // 2), int(sy - height))

        self.update()

    def paintEvent(self, event):
        """Draw rounded box and arrow below text, fully encapsulating text."""
        if not self._text_str:
            return
        if not self.isVisible():
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QtCore.Qt.NoPen)
        painter.setBrush(QColor(*self.bg_color))

        w, h = self.width(), self.height()
        arrow = self.arrow_size
        r = 6

        # --- Box rect (includes padding and leaves room for arrow) ---
        box_rect = QtCore.QRectF(0, 0, w, h - arrow)

        path = QPainterPath()
        path.addRoundedRect(box_rect, r, r)

        # --- Arrow path (downward triangle at bottom center) ---
        arrow_path = QPainterPath()
        arrow_path.moveTo(w / 2 - arrow / 2, h - arrow)  # left base
        arrow_path.lineTo(w / 2 + arrow / 2, h - arrow)  # right base
        arrow_path.lineTo(w / 2, h)                      # tip
        arrow_path.closeSubpath()
        path.addPath(arrow_path)

        painter.drawPath(path)
        painter.end()

        # --- Move text inside the padded box, not overlapping the arrow ---
        self.text_label.move(self.padding, self.padding // 2)

    def update_position(self):
        if self.isVisible() and self.data_pos is not None:
            self._draw()

    @classmethod
    def remove_locked(cls, world_pos):
        for lbl in list(cls.locked_labels):
            if np.array_equal(lbl.data_pos, world_pos):
                lbl.hide()
                cls.locked_labels.remove(lbl)
                return True
        return False
    
    @classmethod
    def lock_label(cls, view, text, world_pos, name):
        lbl = StylishHoverLabel3D(view)
        lbl.show_text(text, world_pos, name)
        cls.locked_labels.append(lbl)

    @classmethod
    def clear_locked(cls):
        for lbl in list(cls.locked_labels):
            lbl.hide()
        cls.locked_labels.clear()

class Plot3DItemMeta:
    def __init__(self, name, item_type, view):
        self.name = name
        self.type = item_type        # "mesh3d" or "scatter3d"
        self.view = view
        self.key = None
        self.aspect_scales = None

        # Geometry
        self.x = None
        self.y = None
        self.z = None     # Z for mesh → 2D array | Z for scatter → 1D vector

        # Colormap
        self.cmap = None
        self.levels = None      # (min, max)
        self.values = None      # Z or c_values

        # Graphics Items
        self.mesh = None        # MeshData
        self.item = None        # GLMeshItem or GLScatterPlotItem
        self.axis = None
        self.cbar = None
        self.cbar_widget = None

        # Hover
        self.hover_label = None

class PlotBackend3D:
    def __init__(self, parent):
        self.parent = parent  # main PlotBackend
        self.meta = {}        # name → Plot3DItemMeta
        self.views = {}       # (row, col) → view widget
        self.hboxes = {}      # (row, col) → hbox for colorbar
        self.containers = {}  # (row, col) → container widget
        self.titles = {}      # (row, col) → title label
        self.content_widgets = {}
        self._hover3d_installed = set()     # (row, col) keys
        self._hover3d_labels = {}          # (row, col) -> StylishHoverLabel3D
        self._hover3d_timers = {}          # (row, col) -> QTimer
        self._3d_location = {}

    def create_3d_subplot_container(self, row, col, view_widget):
        container = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(container)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        title = QtWidgets.QLabel("")
        title.setContentsMargins(0, 5, 0, 5)
        title.setAlignment(QtCore.Qt.AlignHCenter | QtCore.Qt.AlignVCenter)
        title.setStyleSheet("""
            QLabel {
                background-color: #000000;
                font-size: 14px;
                color: #a0a0a0;
            }
        """)
        title.setFixedHeight(30)

        v.addWidget(title)

        hbox = QtWidgets.QHBoxLayout()
        hbox.setContentsMargins(0, 0, 0, 0)
        hbox.setSpacing(0)
        hbox.addWidget(view_widget)

        v.addLayout(hbox)

        self.titles[(row, col)] = title
        self.containers[(row, col)] = container
        self.hboxes[(row, col)] = hbox

        return container
    
    def ensure_view(self, row, col, x_range, y_range, z_range,
                show_axis=True, show_grid=True):
        """
        Ensures a 3D view exists at (row, col). If not:
        • creates GLViewWidget
        • wraps it in a container with:
                - title bar
                - horizontal box (view + colorbar)
        • optionally attaches Axis3D
        Returns:
            view (GLViewWidget)
        """

        key = (row, col)

        # -------------------------------------------------------------
        # CASE 1 — view already exists → reuse it
        # -------------------------------------------------------------
        if key in self.views:
            return self.views[key]

        parent = self.parent  # main PlotBackend

        # -------------------------------------------------------------
        # CASE 2 — create new GLViewWidget
        # -------------------------------------------------------------
        view = PlotWidget3D()
        view.setMouseTracking(True)

        # Compute camera distance from bounding box
        x0, x1 = x_range
        y0, y1 = y_range
        z0, z1 = z_range

        dx = x1 - x0
        dy = y1 - y0
        dz = z1 - z0
        diag = np.sqrt(dx * dx + dy * dy + dz * dz)

        view.opts["distance"] = max(1.2 * diag, 1.0)
        view.opts.setdefault("azimuth", -45)
        view.opts.setdefault("elevation", 30)

        # -------------------------------------------------------------
        # Build container (title + HBox)
        # -------------------------------------------------------------
        container = self.create_3d_subplot_container(row, col, view)

        # -------------------------------------------------------------
        # Insert container into the main layout
        # -------------------------------------------------------------
        parent._set_subplot_widget(row, col, container)

        # -------------------------------------------------------------
        # Attach 3D axis (optional)
        # -------------------------------------------------------------
        axis = None
        if show_axis:
            try:
                axis = Axis3D(view, gridlines_enabled=show_grid)
                axis.set_bounds(x0, x1, y0, y1, z0, z1)
                axis.set_axis_labels(x="X", y="Y", z="Z")
                view.addItem(axis)
            except Exception:
                axis = None

        # -------------------------------------------------------------
        # Store everything in subsystem dictionaries
        # -------------------------------------------------------------
        self.views[key] = view
        self.containers[key] = container

        if axis:
            # Use the same indexing convention as your 2D axis storage
            parent._plots[(row, col, "axis")] = axis

        # Also register view as a plot
        parent._plots[(row, col)] = view

        return view

    def apply_style_to_3d(self, style: dict):
        """
        Apply style profile to all 3D subplots:
        • GLViewWidget background
        • Subplot title bar
        • Content background (under title, behind GLView and colorbar)
        • Axis3D colors, widths, fonts
        • 3D hover labels
        """
        if style is not None:
            parent = self.parent

            axis_color   = style.get("axis3d_color", (160, 160, 160, 255))
            line_width   = int(style.get("axis3d_line_width", 1))
            font_name    = style.get("axis3d_font", "Arial")
            font_size    = int(style.get("axis3d_font_size", 13))
            bg           = style.get("background_color", (0, 0, 0))
            title_color  = style.get("title_color", "white")
            title_bg     = style.get("title_background", bg)
            title_size   = style.get("title_size", 14)
            content_bg   = style.get("content_background", bg)

            # Helper: convert RGB tuple → CSS
            def rgb_to_css(c):
                if isinstance(c, (tuple, list)):
                    return f"rgb({c[0]}, {c[1]}, {c[2]})"
                return c

            css_bg        = rgb_to_css(bg)
            css_title_bg  = rgb_to_css(title_bg)
            css_content_bg = rgb_to_css(content_bg)

            # --------------------------------------------------------
            # LOOP: ALL 3D SUBPLOTS
            # parent._plots[(row,col)] = GLViewWidget
            # --------------------------------------------------------
            for key, widget in list(parent._plots.items()):
                if not isinstance(key, tuple) or len(key) != 2:
                    continue

                row, col = key
                if not isinstance(widget, PlotWidget3D):
                    continue  # skip 2D plots

                # ---------------------------------------
                # 1) GLVIEWWIDGET BACKGROUND
                # ---------------------------------------
                try:
                    widget.setBackgroundColor(bg)
                except Exception:
                    pass

                # ---------------------------------------
                # 2) TITLE BAR STYLE
                # ---------------------------------------
                title = self.titles.get((row, col))
                if title is not None:
                    title.setStyleSheet(
                        f"""
                        QLabel {{
                            font-size: {title_size};
                            color: {title_color};
                            background-color: {css_title_bg};
                        }}
                        """
                    )

                # ---------------------------------------
                # 3) CONTENT BACKGROUND (HBox container)
                # ---------------------------------------
                layout = self.hboxes.get((row, col))
                if layout is not None:
                    for i in range(layout.count()):
                        item = layout.itemAt(i)
                        w = item.widget()
                        if w is None:
                            continue

                        # Colorbar is GraphicsLayoutWidget
                        if isinstance(w, pg.GraphicsLayoutWidget):
                            # use setBackground, NOT stylesheet
                            try:
                                if isinstance(content_bg, (tuple, list)):
                                    r, g, b = content_bg[:3]
                                    w.setBackground(pg.mkColor(r, g, b))
                                else:
                                    w.setBackground(content_bg)
                            except Exception:
                                pass
                        else:
                            # normal QWidget fallback
                            w.setStyleSheet(f"background-color: {css_content_bg};")

                # ---------------------------------------
                # 5) FIND Axis3D
                # ---------------------------------------
                axis = None
                if (row, col, "axis") in parent._plots:
                    axis = parent._plots[(row, col, "axis")]
                else:
                    for m in self.meta.values():
                        if m.key == (row, col) and m.axis is not None:
                            axis = m.axis
                            break

                if axis is None:
                    continue

                # ---------------------------------------
                # 6) APPLY AXIS STYLE
                # ---------------------------------------
                axis.color = axis_color
                axis.axis_line_color = axis_color
                axis.ticks_line_color = axis_color
                axis.gridlines_color = axis_color
                axis.ticks_label_color = axis_color
                axis.axis_label_color = axis_color

                axis.line_width = line_width
                axis.axis_line_width = line_width
                axis.ticks_line_width = line_width
                axis.gridlines_width = line_width

                axis.font = font_name
                axis.font_size = font_size
                axis.ticks_label_font = font_name
                axis.ticks_label_font_size = font_size
                axis.axis_label_font = font_name
                axis.axis_label_font_size = font_size

                # Force full visual update
                axis.rebuild()
                widget.update()

            # ---------------------------------------
            # 7) 3D HOVER LABELS
            # ---------------------------------------
            txt = style.get("hover_text_color")
            bg_hover = style.get("hover_bg_color")

            if txt or bg_hover:
                for lbl in getattr(self, "_hover3d_labels", {}).values():
                    if txt:
                        lbl.text_color = txt
                        lbl.text_label.setStyleSheet(
                            f"QLabel {{ color: {txt}; background-color: transparent; }}"
                        )
                    if bg_hover:
                        lbl.bg_color = bg_hover
                        lbl.update()

    def normalize_color(self, color, *, default_alpha=1.0):
        """
        Convert various color formats to RGBA float tuple.
        Supports:
        - (r,g,b)
        - (r,g,b,a)
        - '#RRGGBB'
        - '#RRGGBBAA'
        - color names ('red')
        - QColor
        """
        if color is None:
            return None

        # Already RGBA floats
        if isinstance(color, (tuple, list)):
            if len(color) == 3:
                return (*color, default_alpha)
            if len(color) == 4:
                return tuple(color)
            raise ValueError("Color tuple must be (r,g,b) or (r,g,b,a)")

        # Hex string or named color
        if isinstance(color, str):
            qcolor = QColor(color)
            if not qcolor.isValid():
                raise ValueError(f"Invalid color string: {color}")
            return qcolor.getRgbF()

        # QColor
        if isinstance(color, QColor):
            return color.getRgbF()

        raise TypeError(f"Unsupported color type: {type(color)}")

    def apply_visual_equal_scaling(self, row, col):
        key = (row, col)
        if key not in self.views:
            return

        # collect all items in this subplot
        metas = [m for m in self.meta.values() if m.key == key]

        if not metas:
            return

        # compute bounding ranges across ALL items
        xs, ys, zs = [], [], []
        for m in metas:
            xs.extend([np.nanmin(m.x), np.nanmax(m.x)])
            ys.extend([np.nanmin(m.y), np.nanmax(m.y)])
            zs.extend([np.nanmin(m.z), np.nanmax(m.z)])
        x0, x1 = float(min(xs)), float(max(xs))
        y0, y1 = float(min(ys)), float(max(ys))
        z0, z1 = float(min(zs)), float(max(zs))

        # Compute scale factors
        dx = x1 - x0 or 1.0
        dy = y1 - y0 or 1.0
        dz = z1 - z0 or 1.0

        max_len = max(dx, dy, dz)

        sx = max_len / dx
        sy = max_len / dy
        sz = max_len / dz
        aspect_scales = (sx, sy, sz)
        m.aspect_scales = aspect_scales

        for m in metas:
            if m.item is None:
                continue
                
            if m.type == "mesh3d":
                # GLMeshItem → safe to scale visually
                m.item.resetTransform()
                m.item.scale(*m.aspect_scales)

            elif m.type == "scatter3d":
                # Scatter MUST NOT use GLItem.scale()
                # Instead scale positions manually
                xs = m.x * sx
                ys = m.y * sy
                zs = m.z * sz
                pts = np.column_stack((xs, ys, zs))
                m.item.setData(pos=pts)

        # Also scale Axis3D
        axis = self.parent._plots.get((row, col, "axis"))
        if axis:
            if axis.aspect_scales != aspect_scales:
                axis._set_aspect_scale_factors(*m.aspect_scales)
                axis.resetTransform()
                axis.scale(*m.aspect_scales)

    def create_mesh(self, msg):
        """
        Clean creation of a 3D mesh plot.
        """
        parent = self.parent
        name = msg.get("name") or self.parent.next_auto_name()

        # Extract data
        Z = self.parent.as_array_or_self(msg["zdata"])
        cmap = msg.get("cmap", "viridis")
        x = self.parent.as_array_or_self(msg.get("xdata")) or np.arange(Z.shape[1])
        y = self.parent.as_array_or_self(msg.get("ydata")) or np.arange(Z.shape[0])
        row = msg.get("row", 0)
        col = msg.get("col", 0)

        show_axis = msg.get("show_axis", True)
        show_grid = msg.get("show_grid", True)
        want_cbar = msg.get("cbar", False)
        smooth = msg.get("smooth", False)
        draw_edges = msg.get("draw_edges", False)
        compute_normals = msg.get("compute_normals", False)

        # Compute ranges for 3D scene
        x0, x1 = float(np.nanmin(x)), float(np.nanmax(x))
        y0, y1 = float(np.nanmin(y)), float(np.nanmax(y))
        z0, z1 = float(np.nanmin(Z)), float(np.nanmax(Z))

        # -------------------------------------------------------------
        # Ensure a 3D view exists for (row, col)
        # -------------------------------------------------------------
        view = self.ensure_view(
            row, col,
            x_range=(x0, x1),
            y_range=(y0, y1),
            z_range=(z0, z1),
            show_axis=show_axis,
            show_grid=show_grid
        )

        # -------------------------------------------------------------
        # Prepare mesh colors
        # -------------------------------------------------------------
        cmap_obj = pg.colormap.get(cmap)
        norm = np.clip((Z - z0) / max((z1 - z0), 1e-9), 0, 1)
        qcols = cmap_obj.mapToQColor(norm.ravel())
        colors = np.array([c.getRgbF() for c in qcols])

        # -------------------------------------------------------------
        # Create MeshData
        # -------------------------------------------------------------
        # Same helper you already have in PlotBackend
        verts, faces = self.parent.make_grid_3d(x, y, Z)

        mesh = gl.MeshData(vertexes=verts, faces=faces)
        mesh.setVertexColors(colors)

        # -------------------------------------------------------------
        # Create GLMeshItem
        # -------------------------------------------------------------
        item = gl.GLMeshItem(
            meshdata=mesh,
            smooth=smooth,
            drawEdges=draw_edges,
            shader=None,
            computeNormals=compute_normals
        )
        item.setGLOptions("opaque")
        view.addItem(item)

        # -------------------------------------------------------------
        # Build metadata
        # -------------------------------------------------------------
        meta = Plot3DItemMeta(name, "mesh3d", view)
        meta.key = (row, col)
        meta.x = x
        meta.y = y
        meta.z = Z  # mesh uses 2D grid
        meta.values = Z
        meta.cmap = cmap
        meta.levels = (z0, z1)
        meta.mesh = mesh
        meta.item = item

        self.meta[name] = meta
        self.parent._curves[name] = item
        self._3d_location[name] = (row, col)

        # -------------------------------------------------------------
        # Attach hover logic (Step 6)
        # -------------------------------------------------------------
        self.attach_hover(view, meta)

        # -------------------------------------------------------------
        # Optional colorbar
        # -------------------------------------------------------------
        if want_cbar:
            self.add_colorbar(meta)
        
        self.apply_visual_equal_scaling(row, col)

        self.apply_style_to_3d(parent._style_profile)

    def create_scatter(self, msg):
        """
        Clean creation of a 3D scatter plot.
        """
        parent = self.parent
        name = msg.get("name") or self.parent.next_auto_name()

        x = self.parent.as_array_or_self(msg["xdata"])
        y = self.parent.as_array_or_self(msg["ydata"])
        z = self.parent.as_array_or_self(msg["zdata"])

        row = msg.get("row", 0)
        col = msg.get("col", 0)

        smooth = msg.get("smooth", True)
        color = self.normalize_color(msg.get("color"))
        size = msg.get("size", 8.0)
        cmap = msg.get("cmap", None)
        c_values = msg.get("c_values", None)

        show_axis = msg.get("show_axis", True)
        show_grid = msg.get("show_grid", True)
        want_cbar = msg.get("cbar", False)

        # Compute bounding box
        x0, x1 = float(np.nanmin(x)), float(np.nanmax(x))
        y0, y1 = float(np.nanmin(y)), float(np.nanmax(y))
        z0, z1 = float(np.nanmin(z)), float(np.nanmax(z))

        # -------------------------------------------------------------
        # Ensure 3D view exists
        # -------------------------------------------------------------
        view = self.ensure_view(
            row, col,
            x_range=(x0, x1),
            y_range=(y0, y1),
            z_range=(z0, z1),
            show_axis=show_axis,
            show_grid=show_grid,
        )

        # -------------------------------------------------------------
        # Build colors
        # -------------------------------------------------------------
        if cmap:
            if c_values is None:
                c_values = z.copy()
            cmin, cmax = float(np.nanmin(c_values)), float(np.nanmax(c_values))
            cmap_obj = pg.colormap.get(cmap)
            norm = np.clip((c_values - cmin) / max(cmax - cmin, 1e-9), 0, 1)
            qcols = cmap_obj.mapToQColor(norm)
            colors = np.array([c.getRgbF() for c in qcols])
        else:
            colors = np.tile(np.array(color, dtype=float), (len(x), 1))

        pts = np.column_stack((x, y, z))
        scatter = gl.GLScatterPlotItem(pos=pts, size=size, color=colors, pxMode=False)
        
        scatter.setGLOptions("opaque")
        view.addItem(scatter)

        # -------------------------------------------------------------
        # Build metadata
        # -------------------------------------------------------------
        meta = Plot3DItemMeta(name, "scatter3d", view)
        meta.key = (row, col)
        meta.x = x
        meta.y = y
        meta.z = z
        meta.values = c_values
        meta.cmap = cmap
        if cmap:
            meta.levels = (cmin, cmax)
        else:
            meta.levels = (0.0, 1.0)
        meta.item = scatter

        self.meta[name] = meta
        self.parent._curves[name] = scatter
        self._3d_location[name] = (row, col)

        # -------------------------------------------------------------
        # Hover logic
        # -------------------------------------------------------------
        self.attach_hover(view, meta)

        # -------------------------------------------------------------
        # Optional colorbar
        # -------------------------------------------------------------
        if want_cbar and cmap and c_values is not None:
            self.add_colorbar(meta)

        self.apply_visual_equal_scaling(row, col)

        self.apply_style_to_3d(parent._style_profile)

    def update_mesh(self, msg):
        """
        Update an existing mesh3d efficiently (GPU-friendly),
        preserving old behavior.
        """
        parent = self.parent
        name = msg["name"]

        meta = self.meta.get(name)
        if not meta or meta.type != "mesh3d":
            return
        
        Znew = np.asarray(msg["zdata"])
        meta.z = Znew
        meta.values = Znew

        # keep old levels (don't auto-rescale colors)
        zmin, zmax = meta.levels if meta.levels else (
            float(np.nanmin(Znew)), float(np.nanmax(Znew))
        )

        # -------------------------------------------------------------
        # FAST PATH: update vertex buffer directly
        # -------------------------------------------------------------
        try:
            verts = meta.mesh.vertexes()
            if verts is not None and verts.shape[0] == Znew.size:
                verts[:, 2] = Znew.ravel()
                meta.mesh.setVertexes(verts)

                # recolor using fixed levels
                colors = parent.map_colors_3d(Znew, meta.cmap, zmin, zmax)
                meta.mesh.setVertexColors(colors)

                # notify GLMeshItem
                meta.item.meshDataChanged()

            else:
                raise ValueError("Vertex count mismatch → rebuild mesh")

        except Exception:
            # ---------------------------------------------------------
            # FALLBACK: rebuild mesh (older pg safety)
            # ---------------------------------------------------------
            x, y = meta.x, meta.y
            if x is None or y is None:
                return

            colors = parent.map_colors_3d(Znew, meta.cmap, zmin, zmax)
            verts, faces = parent.make_grid_3d(x, y, Znew)
            mesh = gl.MeshData(vertexes=verts, faces=faces)
            mesh.setVertexColors(colors)

            # remove old item safely
            try:
                meta.view.removeItem(meta.item)
            except Exception:
                pass

            item = gl.GLMeshItem(meshdata=mesh, smooth=True, drawEdges=False, shader=None)
            item.setGLOptions("opaque")
            meta.view.addItem(item)

            meta.mesh = mesh
            meta.item = item

        # -------------------------------------------------------------
        # Update axis bounds (your old behavior)
        # -------------------------------------------------------------
        row, col = self._3d_location.get(name, (None, None))
        axis_key = (row, col, "axis")
        if axis_key in parent._plots:
            try:
                parent._plots[axis_key].set_bounds(
                    zmin=float(np.nanmin(Znew)),
                    zmax=float(np.nanmax(Znew))
                )
            except Exception:
                pass

        # -------------------------------------------------------------
        # Update locked hover labels (same logic as old code)
        # -------------------------------------------------------------
        if parent._hover_enabled:
            for lbl in list(StylishHoverLabel3D.locked_labels):
                if lbl.name != name or lbl.data_pos is None:
                    continue

                x0, y0, _ = lbl.data_pos
                x_arr = np.asarray(meta.x)
                y_arr = np.asarray(meta.y)

                if np.isclose(x_arr, x0, atol=1e-8).any() and np.isclose(y_arr, y0, atol=1e-8).any():
                    xi = np.where(np.isclose(x_arr, x0, atol=1e-8))[0][0]
                    yi = np.where(np.isclose(y_arr, y0, atol=1e-8))[0][0]
                    new_z = Znew[yi, xi]

                    lbl.data_pos = (float(x0), float(y0), float(new_z))

                    extra = ""
                    if name in parent._point_meta:
                        meta_data = np.array(parent._point_meta[name])
                        if meta_data.shape == Znew.shape:
                            extra = str(meta_data[yi, xi])
                        else:
                            extra = "Hover info and Z not in the same shape!"
                    elif name in parent._curve_meta:
                        extra = str(parent._curve_meta[name])

                    text = f"{name}\nX={x0:.2f}\nY={y0:.2f}\nZ={new_z:.2f}"
                    if extra:
                        text += f"\n{extra}"

                    lbl._text_str = text
                    lbl.update_position()
                else:
                    lbl.hide()
                    StylishHoverLabel3D.remove_locked(lbl.data_pos)

        self.apply_visual_equal_scaling(row, col)

    def update_scatter(self, msg):
        """
        Update an existing scatter3d, preserving old behavior.
        """
        parent = self.parent
        name = msg["name"]

        meta = self.meta.get(name)
        if not meta or meta.type != "scatter3d":
            return

        scatter = meta.item
        if scatter is None:
            return
        
        # -------------------------------------------------------------
        # Pull new data (fallback to existing)
        # -------------------------------------------------------------
        new_x = msg.get("xdata")
        new_y = msg.get("ydata")
        new_z = msg.get("zdata")
        x = np.asarray(new_x if new_x is not None else meta.x)
        y = np.asarray(new_y if new_y is not None else meta.y)
        z = np.asarray(new_z if new_z is not None else meta.z)

        c_values = msg.get("c_values", meta.values)
        cmap = msg.get("cmap", meta.cmap)
        color = msg.get("color", None)
        size = msg.get("size", None)

        # update positions
        pts = np.column_stack((x, y, z))
        scatter.setData(pos=pts)

        meta.x, meta.y, meta.z = x, y, z

        # -------------------------------------------------------------
        # Optional recolor
        # -------------------------------------------------------------
        if cmap and c_values is not None:
            c_values = np.asarray(c_values)
            cmin, cmax = float(np.nanmin(c_values)), float(np.nanmax(c_values))
            cmap_obj = pg.colormap.get(cmap)
            norm = np.clip((c_values - cmin) / max(cmax - cmin, 1e-9), 0, 1)
            qcols = cmap_obj.mapToQColor(norm)
            colors = np.array([c.getRgbF() for c in qcols])
            scatter.setData(color=colors)

            meta.values = c_values
            meta.cmap = cmap
            meta.levels = (cmin, cmax)

        elif color is not None:
            colors = np.tile(np.array(color, dtype=float), (len(x), 1))
            scatter.setData(color=colors)

        # -------------------------------------------------------------
        # Optional size update
        # -------------------------------------------------------------
        if size is not None:
            scatter.setData(size=float(size))

        # -------------------------------------------------------------
        # Update axis bounds
        # -------------------------------------------------------------
        row, col = self._3d_location.get(name, (None, None))
        axis_key = (row, col, "axis")
        if axis_key in parent._plots:
            try:
                parent._plots[axis_key].set_bounds(
                    xmin=float(np.nanmin(x)),
                    xmax=float(np.nanmax(x)),
                    ymin=float(np.nanmin(y)),
                    ymax=float(np.nanmax(y)),
                    zmin=float(np.nanmin(z)),
                    zmax=float(np.nanmax(z))
                )
            except Exception:
                pass

        # -------------------------------------------------------------
        # Update colorbar levels (if exists)
        # -------------------------------------------------------------
        if meta.cbar and meta.cmap and meta.values is not None:
            try:
                cmin, cmax = float(np.nanmin(meta.values)), float(np.nanmax(meta.values))
                meta.cbar.setLevels((cmin, cmax))
                try:
                    meta.cbar.sigLevelsChanged.emit((cmin, cmax))
                except Exception:
                    pass
                meta.levels = (cmin, cmax)
            except Exception:
                pass

        # -------------------------------------------------------------
        # Update locked hover labels (same as old logic)
        # -------------------------------------------------------------
        if parent._hover_enabled:
            for lbl in list(StylishHoverLabel3D.locked_labels):
                if lbl.name != name or lbl.data_pos is None:
                    continue

                x0, y0, _ = lbl.data_pos

                if np.isclose(meta.x, x0, atol=1e-8).any() and np.isclose(meta.y, y0, atol=1e-8).any():
                    idx = np.where(np.isclose(meta.x, x0, atol=1e-8))[0][0]

                    lbl.data_pos = (float(meta.x[idx]), float(meta.y[idx]), float(meta.z[idx]))

                    extra = ""
                    if name in parent._point_meta:
                        meta_data = np.array(parent._point_meta[name])
                        if meta_data.shape == meta.z.shape:
                            extra = str(meta_data[idx])
                    elif name in parent._curve_meta:
                        extra = str(parent._curve_meta[name])

                    text = f"{name}\nX={meta.x[idx]:.2f}\nY={meta.y[idx]:.2f}\nZ={meta.z[idx]:.2f}"
                    if extra:
                        text += f"\n{extra}"

                    lbl._text_str = text
                    lbl.update_position()
                else:
                    lbl.hide()
                    StylishHoverLabel3D.remove_locked(lbl.data_pos)

        self.apply_visual_equal_scaling(row, col)

    def add_colorbar(self, meta):
        """
        Add a colorbar to a mesh3d or scatter3d item.
        """
        parent = self.parent
        name = meta.name

        # Already exists → just update its levels
        if meta.cbar is not None:
            self.update_colorbar_levels(meta, meta.levels)
            return

        # -------------------------------------------------------------
        # Build the colorbar widget (pg.ColorBarItem)
        # -------------------------------------------------------------
        cmin, cmax = meta.levels
        cmap = meta.cmap

        # Your existing helper that creates a ColorBarItem
        cbar = self.make_colorbar_item(cmap=cmap, levels=(cmin, cmax))

        # Build PG graphics widget around it
        cbar_widget = self._build_colorbar_widget(meta, cbar)

        # -------------------------------------------------------------
        # Add to layout (inside hbox of this subplot)
        # -------------------------------------------------------------
        row, col = self._3d_location.get(name, (None, None))
        hbox = self.hboxes.get((row, col))
        if hbox:
            hbox.addWidget(cbar_widget)

        # -------------------------------------------------------------
        # Store references
        # -------------------------------------------------------------
        meta.cbar = cbar
        meta.cbar_widget = cbar_widget

        # Link colorbar changes → update mesh/scatter colors
        cbar.sigLevelsChanged.connect(lambda: self.update_colorbar_levels(meta, cbar.values, setLevels=False))
        def _cbar_context_menu(event, meta=meta, cbar=cbar):
            self._open_colorbar_menu(event, meta, cbar)
            event.accept()

        cbar.contextMenuEvent = _cbar_context_menu

    def _build_colorbar_widget(self, meta, cbar):
        """
        Wrap ColorBarItem inside a QWidget for layout.
        """

        # Graphics layout for ColorBarItem
        glw = pg.GraphicsLayoutWidget()
        glw.setAutoFillBackground(True)
        glw.addItem(cbar)
        try:
            # Access representative tick values
            tick_values = np.linspace(meta.levels[0], meta.levels[1], 5)
            tick_labels = [f"{v:.3g}" for v in tick_values]
            longest_label = max(tick_labels, key=len)

            # Measure text width using QFontMetrics
            font = glw.font()
            fm = QFontMetrics(font)
            text_width = fm.horizontalAdvance(longest_label)

            # Add space for gradient + margins
            colorbar_width = text_width + 30
            colorbar_width = max(60, min(160, colorbar_width))  # clamp
        except Exception as e:
            colorbar_width = 60  # fallback

        glw.setFixedWidth(colorbar_width)
        
        return glw

    def update_colorbar_levels(self, meta, levels, setLevels=True):
        """
        Update cbar and reapply colors to the 3D object.
        """
        if not meta.cbar:
            return

        cmin, cmax = levels
        meta.levels = (cmin, cmax)
        
        if setLevels:
            # update the colorbar widget
            try:
                meta.cbar.setLevels((cmin, cmax))
            except Exception:
                pass

        # ------------------------------------------
        # mesh3d
        # ------------------------------------------
        if meta.type == "mesh3d":
            Z = meta.values
            if Z is None:
                return
            colors = self.map_colors_1d(Z.ravel(), meta.cmap, cmin, cmax)
            try:
                meta.mesh.setVertexColors(colors)
                meta.item.meshDataChanged()
            except Exception:
                pass

        # ------------------------------------------
        # scatter3d
        # ------------------------------------------
        elif meta.type == "scatter3d":
            if meta.values is None:
                return
            cvals = np.asarray(meta.values)
            colors = self.map_colors_1d(cvals, meta.cmap, cmin, cmax)
            try:
                meta.item.setData(color=colors)
            except Exception:
                pass

    def remove_colorbar(self, meta):
        """
        Clean removal of colorbar widget & references.
        """
        if meta.cbar_widget:
            try:
                meta.cbar_widget.setParent(None)
                meta.cbar_widget.deleteLater()
            except Exception:
                pass

        meta.cbar_widget = None
        meta.cbar = None
    
    def _open_colorbar_menu(self, event, meta, cbar):
        menu = cbar.colorMapMenu
        existing_actions = [a.text() for a in menu.actions()]

        # Add custom actions
        if not "Remove Colorbar" in existing_actions: 
            remove_act = QtWidgets.QAction("Remove Colorbar")
            remove_act.triggered.connect(lambda: self.remove_colorbar(meta))
            menu.insertAction(menu.actions()[0], remove_act)
        if not "Reset Levels" in existing_actions:
            reset_act = QtWidgets.QAction("Reset Levels")
            reset_act.triggered.connect(lambda: self._reset_colorbar(meta))
            menu.insertAction(menu.actions()[0], reset_act)
        if not "Edit Levels…" in existing_actions:
            edit_act = QtWidgets.QAction("Edit Levels…")
            edit_act.triggered.connect(lambda: self._edit_colorbar_dialog(meta))
            menu.insertAction(menu.actions()[0], edit_act)

        # Use global coordinates from event
        if hasattr(event, "globalPos"):
            pos = event.globalPos()
        else:
            local_pos = event.pos()
            if isinstance(local_pos, QtCore.QPointF):
                local_pos = QtCore.QPoint(int(local_pos.x()), int(local_pos.y()))
            pos = event.widget().mapToGlobal(local_pos)
        menu.exec_(pos)
    
    def _edit_colorbar_dialog(self, meta):
        """
        Simple dialog to edit min/max values manually.
        """
        cmin, cmax = meta.levels

        d = QtWidgets.QDialog()
        d.setWindowTitle(f"Edit Colorbar: {meta.name}")
        layout = QtWidgets.QVBoxLayout(d)

        min_edit = QtWidgets.QLineEdit(str(cmin))
        max_edit = QtWidgets.QLineEdit(str(cmax))

        form = QtWidgets.QFormLayout()
        form.addRow("Min:", min_edit)
        form.addRow("Max:", max_edit)
        layout.addLayout(form)

        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        layout.addWidget(btns)

        btns.accepted.connect(d.accept)
        btns.rejected.connect(d.reject)

        if d.exec_() == QtWidgets.QDialog.Accepted:
            try:
                new_cmin = float(min_edit.text())
                new_cmax = float(max_edit.text())
                self.update_colorbar_levels(meta, (new_cmin, new_cmax))
            except Exception:
                pass
    
    def _reset_colorbar(self, meta):
        """
        Reset levels to min/max of data.
        """
        v = meta.values
        if v is None:
            return

        cmin = float(np.nanmin(v))
        cmax = float(np.nanmax(v))

        self.update_colorbar_levels(meta, (cmin, cmax))

    def map_colors_1d(self, values, cmap_name, vmin, vmax):
        """Map 1D scalar array to RGBA float colors using pg colormap."""
        values = np.asarray(values, dtype=float)
        cmap_obj = pg.colormap.get(cmap_name)
        norm = np.clip((values - vmin) / max(vmax - vmin, 1e-9), 0, 1)
        qcols = cmap_obj.mapToQColor(norm)
        return np.array([c.getRgbF() for c in qcols])

    def make_colorbar_item(self, cmap, levels):
        """
        Create a ColorBarItem matching your old behavior:
        - interactive
        - uses pg colormap
        Returns: pg.ColorBarItem
        """
        return pg.ColorBarItem(
            values=levels,
            colorMap=pg.colormap.get(cmap),
            interactive=True
        )
    
    def set_levels(self, name, levels):
        """
        Public entry to set color scaling levels for an existing 3D item.
        Works for both mesh3d and scatter3d.
        """
        meta = self.meta.get(name)
        if not meta:
            return
        self.update_colorbar_levels(meta, tuple(levels))
    
    # ==========================================================
    # HOVER HANDLING
    # ==========================================================
    def attach_hover(self, view, meta):
        """
        Attach hover system to a GLViewWidget once per subplot.
        Hover searches ALL 3D items living in that view.
        """
        parent = self.parent
        key = self._3d_location.get(meta.name, None)
        if key is None:
            return

        # already installed for this view
        if key in self._hover3d_installed:
            meta.hover_label = self._hover3d_labels[key]
            return

        # create one shared hover label per view
        label3d = StylishHoverLabel3D(view)
        self._hover3d_labels[key] = label3d

        # install handlers (shared across all items in view)
        view.mouseMoveEvent = lambda evt, v=view, k=key: self._hover3d_move(evt, v, k)
        view.mousePressEvent = lambda evt, v=view, k=key: self._hover3d_press(evt, v, k)
        view.mouseReleaseEvent = lambda evt, v=view: PlotWidget3D.mouseReleaseEvent(v, evt)
        view.leaveEvent = lambda evt, k=key: self._hover3d_labels[k].hide()

        # timer to keep locked labels reprojected
        t = QtCore.QTimer(view)
        t.timeout.connect(lambda v=view: self._hover3d_update_locked(v))
        t.start(25)
        self._hover3d_timers[key] = t

        self._hover3d_installed.add(key)

        # save label in current meta too
        meta.hover_label = label3d

    def _hover3d_move(self, evt, view, key):
        parent = self.parent

        if not parent._hover_enabled:
            return PlotWidget3D.mouseMoveEvent(view, evt)

        pos = evt.pos()
        if not (0 <= pos.x() <= view.width() and 0 <= pos.y() <= view.height()):
            self._hover3d_labels[key].hide()
            return

        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if not (modifiers & QtCore.Qt.AltModifier):
            self._hover3d_labels[key].hide()
            return PlotWidget3D.mouseMoveEvent(view, evt)

        # gather all items living in this view
        candidates = [m for m in self.meta.values() if m.view is view]
        if not candidates:
            self._hover3d_labels[key].hide()
            return

        best = None  # (dist2, meta, idx, vx, vy, vz)

        for m in candidates:
            verts = None

            if m.type == "mesh3d":
                if m.mesh is None:
                    continue
                try:
                    verts = m.mesh.vertexes()
                except Exception:
                    verts = None

            elif m.type == "scatter3d":
                # robust scatter verts extraction
                try:
                    posdata = getattr(m.item, "pos", None)
                    if posdata is None:
                        continue
                    verts = np.asarray(posdata)
                except Exception:
                    verts = None

            if verts is None or len(verts) == 0:
                continue

            # project to screen
            pts2d = parent.screen_projection_3d(view, verts)
            dx = pts2d[:, 0] - pos.x()
            dy = pts2d[:, 1] - pos.y()
            dist2 = dx*dx + dy*dy
            idx = int(np.argmin(dist2))

            if best is None or dist2[idx] < best[0]:
                vx, vy, vz = verts[idx]
                best = (dist2[idx], m, idx, float(vx), float(vy), float(vz))

        if best is None:
            self._hover3d_labels[key].hide()
            return

        dist2, m, idx, vx, vy, vz = best

        # same threshold you used before
        if dist2 > 150:
            self._hover3d_labels[key].hide()
            return

        # -----------------------
        # Gather extra metadata
        # -----------------------
        extra = ""
        name = m.name

        try:
            if name in parent._point_meta:
                meta_data = np.array(parent._point_meta[name])

                if m.type == "mesh3d" and meta_data.shape == m.z.shape:
                    # map vx,vy to nearest grid indices
                    x_idx = np.where(np.isclose(m.x, vx, atol=1e-8))[0][0]
                    y_idx = np.where(np.isclose(m.y, vy, atol=1e-8))[0][0]
                    extra = str(meta_data[y_idx, x_idx])

                elif m.type == "scatter3d":
                    if meta_data.ndim == 1 and len(meta_data) > idx:
                        extra = str(meta_data[idx])
            elif name in parent._curve_meta:
                extra = str(parent._curve_meta[name])
        except Exception:
            pass

        # -----------------------
        # Show hover label
        # -----------------------
        text = f"{name}\nX={vx:.2f}\nY={vy:.2f}\nZ={vz:.2f}"
        if extra:
            text += f"\n{extra}"

        label3d = self._hover3d_labels[key]
        label3d.show_text(text, (vx, vy, vz), name)

    def _hover3d_press(self, evt, view, key):
        parent = self.parent
        label3d = self._hover3d_labels[key]
        modifiers = QtWidgets.QApplication.keyboardModifiers()

        # -------------------------------------------------
        # Alt + Left click → lock/unlock label
        # -------------------------------------------------
        if (modifiers & QtCore.Qt.AltModifier) and evt.button() == QtCore.Qt.LeftButton:
            if label3d.isVisible() and label3d.data_pos is not None:
                if StylishHoverLabel3D.remove_locked(label3d.data_pos):
                    return
                StylishHoverLabel3D.lock_label(
                    view, label3d._text_str, label3d.data_pos, label3d.name
                )
            return  # skip normal rotation when Alt-Clicking

        # -------------------------------------------------
        # Right click → open view context menu
        # -------------------------------------------------
        if evt.button() == QtCore.Qt.RightButton:
            self._open_view_context_menu(evt, view, key)
            return

        # otherwise normal GL behaviour
        return PlotWidget3D.mousePressEvent(view, evt)
    
    def _open_view_context_menu(self, evt, view, key):
        parent = self.parent
        menu = QtWidgets.QMenu(parent.win if hasattr(parent, "win") else view)
        container = self.containers.get(key)

        action_clear = menu.addAction("Clear all labels")
        action_custom = menu.addAction("Set Custom View…")
        menu.addSeparator()
        action_xy = menu.addAction("XY Plane (Top View)")
        action_yz = menu.addAction("YZ Plane (Side View)")
        action_xz = menu.addAction("XZ Plane (Front View)")

        action_clear.triggered.connect(StylishHoverLabel3D.clear_locked)
        action_custom.triggered.connect(lambda: self._set_custom_view(view, key))
        action_xy.triggered.connect(lambda: self._set_plane_view(view, key, plane="xy"))
        action_yz.triggered.connect(lambda: self._set_plane_view(view, key, plane="yz"))
        action_xz.triggered.connect(lambda: self._set_plane_view(view, key, plane="xz"))

        menu.addSeparator()
        if not getattr(container, "_undocked", False):
            maximize = QtWidgets.QAction("Maximize subplot", menu)
            maximize.triggered.connect(
                lambda checked, k=key, w=container: parent._undock_subplot(w, k)
            )
            menu.addAction(maximize)
        else:
            restore = QtWidgets.QAction("Restore subplot", menu)
            restore.triggered.connect(lambda checked, k=key, w=container: parent._dock_subplot(w, k))
            menu.addAction(restore)

        menu.addSeparator()
        export_fig = menu.addAction("Export")
        export_fig.triggered.connect(lambda: parent.open_export_dialog("figure"))
        
        pos = evt.globalPos() if hasattr(evt, "globalPos") else \
            view.mapToGlobal(QtCore.QPoint(int(evt.pos().x()), int(evt.pos().y())))
        menu.exec_(pos)        

    def _recenter_view(self, view, key):
        """
        Recenter camera to bounding box of ALL items in this view.
        """
        candidates = [m for m in self.meta.values() if m.view is view]
        if not candidates:
            return

        xs, ys, zs = [], [], []
        for m in candidates:
            if m.x is not None: xs.append(np.nanmin(m.x)); xs.append(np.nanmax(m.x))
            if m.y is not None: ys.append(np.nanmin(m.y)); ys.append(np.nanmax(m.y))
            if m.z is not None:
                zs.append(np.nanmin(m.z)); zs.append(np.nanmax(m.z))

        if not xs or not ys or not zs:
            return

        cx = 0.5 * (min(xs) + max(xs))
        cy = 0.5 * (min(ys) + max(ys))
        cz = float(min(zs))

        view.opts["center"] = pg.Vector(cx, cy, cz)
        view.update()

    def _set_plane_view(self, view, key, plane="xy"):
        self._recenter_view(view, key)

        if plane == "xy":
            view.opts["azimuth"], view.opts["elevation"] = -90, 90
        elif plane == "yz":
            view.opts["azimuth"], view.opts["elevation"] = 0, 0
        elif plane == "xz":
            view.opts["azimuth"], view.opts["elevation"] = -90, 0

        view.update()

    def _set_custom_view(self, view, key):
        parent = self.parent
        dlg = QtWidgets.QDialog(parent.win if hasattr(parent, "win") else view)
        dlg.setWindowTitle("Set Camera Angles")
        form = QtWidgets.QFormLayout(dlg)
        form.setContentsMargins(15, 15, 15, 15)

        az_box = QtWidgets.QDoubleSpinBox()
        az_box.setRange(-360, 360)
        az_box.setValue(view.opts.get("azimuth", 0))

        el_box = QtWidgets.QDoubleSpinBox()
        el_box.setRange(-90, 90)
        el_box.setValue(view.opts.get("elevation", 30))

        form.addRow("Azimuth (°):", az_box)
        form.addRow("Elevation (°):", el_box)

        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        form.addRow(btns)

        def apply_angles():
            self._recenter_view(view, key)
            view.opts["azimuth"] = az_box.value()
            view.opts["elevation"] = el_box.value()
            view.update()
            dlg.accept()

        btns.accepted.connect(apply_angles)
        btns.rejected.connect(dlg.reject)
        dlg.exec_()

    def _hover3d_update_locked(self, view):
        """
        Reproject and reposition all locked 3D labels.
        """
        for lbl in list(StylishHoverLabel3D.locked_labels):
            try:
                lbl.update_position()
            except Exception:
                pass
    
    # ==========================================================
    # CLEARING / RESETTING
    # ==========================================================
    def erase_item(self, name):
        """
        Remove a single 3D item by name.
        Called when a subplot clears or when an item is replaced.
        """
        if name not in self.meta:
            return

        m = self.meta[name]

        # remove GL item
        try:
            if m.item is not None:
                m.view.removeItem(m.item)
        except Exception:
            pass

        # remove colorbar widget if exists
        try:
            if m.cbar_widget is not None:
                hbox = self.hboxes.get(m.key)
                if hbox:
                    hbox.removeWidget(m.cbar_widget)
                m.cbar_widget.setParent(None)
                m.cbar_widget.deleteLater()
        except Exception:
            pass

        # remove hover label
        try:
            if hasattr(m, "hover_label") and m.hover_label:
                m.hover_label.hide()
        except Exception:
            pass

        # delete metadata
        if m.key in self._3d_location:
            del self._3d_location[name]

        del self.meta[name]
    
    def clear(self):
        parent = self.parent

        # remove all items & colorbars
        for name in list(self.meta.keys()):
            self.erase_item(name)

        # stop hover timers
        for key, timer in self._hover3d_timers.items():
            timer.stop()
        self._hover3d_timers.clear()

        # clear hover labels
        for key, label in self._hover3d_labels.items():
            try: label.hide()
            except: pass
        self._hover3d_labels.clear()

        self._hover3d_installed.clear()

        # remove all containers
        for key, container in list(self.containers.items()):
            try:
                parent.splitter_grid.removeWidget(container)
                container.setParent(None)
                container.deleteLater()
            except Exception:
                pass

        # clear dictionaries
        self.views.clear()
        self.hboxes.clear()
        self.containers.clear()
        self.titles.clear()
    
class PlotBackend:
    def __init__(self, title="Plot", rows=1, cols=1, update_interval=50, blocks=True, mode: Literal["standalone", "widget"] = "standalone", antialiasing = False):
        self._backend3d = PlotBackend3D(self)
        self._title = title
        self._update_interval = update_interval
        self._rows = rows
        self._cols = cols
        self._blocks = blocks
        self._mode = mode
        self._antialiasing = antialiasing
        self._rx_queue = None
        self._process = None
        self._started = False
        self._annotations = {}
        self._plots = {}
        self._hover_items = {}
        self._curves = {}
        self._curve_location = {}
        self._heatmap_location = {}
        self._colorbars = {}
        self._curve_meta = {}      # general per-curve text
        self._point_meta = {}      # dict of name → list or array of strings (per point)
        self._heatmap_labels = {}
        self._hover_proxies_2d = [] # convert mouse move event to proxy to be able to rate limit, store proxies to prevent grabage collector from reaching and cleaning the signal connection
        self._close_enabled = True  # can be toggled via tx_queue
        self._hover_enabled = True
        self._auto_colors = [
            "#1f77b4",
            "#ff7f0e",
            "#2ca02c",
            "#d62728",
            "#9467bd",
            "#8c564b",
            "#e377c2",
            "#7f7f7f",
            "#bcbd22",
            "#17becf",
            "#e41a1c",
            "#377eb8",
            "#4daf4a",
            "#984ea3",
            "#ff7f00",
            "#ffff33",
            "#a65628",
            "#f781bf",
            "#66c2a5",
            "#fc8d62",
            "#8da0cb",
            "#e78ac3",
            "#a6d854",
            "#ffd92f",
            "#e5c494",
            "#b3b3b3",
            "#00e5ff",
            "#ff00e5",
            "#c6ff00",
        ]
        self._auto_color_idx = 0
        self._hover_threshold_px = 50
        self._style_profile = None

        # --- Export / save system ------------------------------------
        self._export_presets = {
            "publication": {
                "dpi": 600,
                "transparent": False,
                "style": None,   # you can plug your own style profile here
            },
            "presentation": {
                "dpi": 200,
                "transparent": False,
                "style": None,
            },
            "web": {
                "dpi": 120,
                "transparent": True,
                "style": None,
            },
        }
        self._current_preset = "presentation"
        self._active_threads = []
        self.cat = CategoricalAxisManager()
        self._batch_depth = 0

    def _send_done(self, force = False):
        # Suppress per-command _done while running a batch;
        # the batch handler will send exactly one at the end.
        if getattr(self, "_batch_depth", 0) > 0 and not force:
            return

        if (getattr(self, "_blocks", False) or force) and hasattr(self, "_tx_queue") and self._tx_queue:
            try:
                self._tx_queue.put({"cmd": "_done"})
            except Exception:
                pass
    
    def _send_frontend(self, cmd: dict):
        if hasattr(self, "_tx_queue") and self._tx_queue:
            try:
                self._tx_queue.put(cmd)
            except Exception:
                pass
    
    def as_array_or_self(self, x, dtype=None):
        if x is None or isinstance(x, str):
            return x
        try:
            arr = np.asarray(x)
            if dtype is not None:
                try:
                    arr = arr.astype(dtype)
                except Exception:
                    pass  # keep original array
            return arr
        except Exception:
            return x
        
    def generate_icon(self, size=32):
        """Return a QIcon: small rounded window with an elegant S-shaped plot line."""
        pix = QPixmap(size, size)
        pix.fill(Qt.transparent)

        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)

        # === Rounded background window ===
        bg_rect = QRectF(1, 1, size - 2, size - 2)
        p.setBrush(QBrush(QColor(35, 35, 40)))          # dark gray background
        p.setPen(QPen(QColor(80, 80, 90), 1.2))         # border
        p.drawRoundedRect(bg_rect, 5, 5)

        # === Axes ===
        margin = 6
        left = margin
        right = size - margin
        top = margin
        bottom = size - margin

        axis_pen = QPen(QColor(180, 180, 190), 1.1)
        p.setPen(axis_pen)
        p.drawLine(left, bottom, right, bottom)   # x-axis
        p.drawLine(left, bottom, left, top)       # y-axis

        # === Stylized S-curve ===
        graph_pen = QPen(QColor(46, 204, 113), 2.4)   # bright green line
        graph_pen.setCapStyle(Qt.RoundCap)
        p.setPen(graph_pen)

        path = QPainterPath()
        path.moveTo(left + 4, bottom - 4)
        path.cubicTo(
            left + size * 0.35, bottom - size * 0.75,
            right - size * 0.35, bottom - size * 0.25,
            right - 4, top + 6
        )
        p.drawPath(path)

        p.end()
        return QIcon(pix)

    def closeEvent(self, event):
        """Custom close confirmation with programmatic-close detection."""
        programmatic = getattr(self, "_programmatic_close", False)

        def send_closed_signal():
            try:
                if hasattr(self, "_tx_queue") and self._tx_queue:
                    self._tx_queue.put({"cmd": "_closed"})
            except Exception:
                pass

        if programmatic or self._close_enabled:
            self.timer.stop()
            send_closed_signal()
            self.app.quit()
            event.accept()
            return

        else:
            QMessageBox.information(
                self.win,
                "Action Disabled",
                "Closing this window manually is currently disabled."
            )
            event.ignore()

    def _ensure_plotwidget(self, row, col):
        p = self._plots.get((row, col))
        if p is None or not isinstance(p, pg.PlotWidget):
            return None
        return p

    def _generate_subplot_widget(self, row, col):
        p = pg.PlotWidget(useOpenGL = True)
        vb = p.getViewBox()
        vb.setMouseMode(vb.RectMode)
        p.addLegend()
        p.getAxis("bottom").setStyle(stopAxisAtTick = (False, True))
        p.getAxis("left").setStyle(stopAxisAtTick = (True, False))
        self._set_subplot_widget(row, col, p)

    def _set_subplot_widget(self, row, col, widget):
        try:
            old = self._plots.get((row, col))
            self.splitter_grid.removeWidget(old)
            old.setParent(None)
            old.deleteLater()
        except Exception:
            pass

        self.splitter_grid.addWidget(widget, row, col)
        self._plots[(row, col)] = widget

    def _undock_subplot(self, widget: QtWidgets.QWidget, key = None):
        widget._dock_pos = key

        # Floating dialog
        dlg = QtWidgets.QDialog(self.win)
        dlg.setWindowTitle("Subplot (Maximized)")
        dlg.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        dlg.resize(1200, 800)

        lay = QtWidgets.QVBoxLayout(dlg)
        lay.setContentsMargins(0, 0, 0, 0)
        
        self.splitter_grid.undock_widget(*key)
        lay.addWidget(widget)

        dlg.finished.connect(lambda *_: self._dock_subplot(widget, key))
        dlg.show()

        widget._dock_dialog = dlg
        widget._undocked = True

        if key:
            axis = self._plots.get(key + ("axis",))
            if isinstance(axis, Axis3D):
                axis.rebuild()

    def _dock_subplot(self, widget: QtWidgets.QWidget, key = None):
        undocked = getattr(widget, "_undocked", False)

        if undocked:
            pos = getattr(widget, "_dock_pos", None)
            self.splitter_grid.dock_widget(widget, *pos)
            widget._undocked = False

            dlg = getattr(widget, "_dock_dialog", None)
            if dlg:
                dlg.deleteLater()

            if key:
                axis = self._plots.get(key + ("axis",))
                if isinstance(axis, Axis3D):
                    axis.rebuild()

    def _register_2d_item(self, name, item, row, col):
        """Uniform registration for every 2D item."""
        
        self._curves[name] = item
        self._curve_location[name] = (row, col)

    def _legend_style_for_item(self, item):
        """Return kwargs to mimic item in legend proxy."""
        # LINE / STEP (PlotDataItem)
        if isinstance(item, pg.PlotDataItem):
            pen = item.opts.get("pen", None)
            symbol = item.opts.get("symbol", None)
            symbolSize = item.opts.get("symbolSize", None)
            symbolBrush = item.opts.get("symbolBrush", None)
            symbolPen = item.opts.get("symbolPen", None)
            return dict(pen=pen, symbol=symbol, symbolSize=symbolSize,
                        symbolBrush=symbolBrush, symbolPen=symbolPen)

        # SCATTER
        if isinstance(item, pg.ScatterPlotItem):
            brush = item.opts.get("brush", None)
            pen = item.opts.get("pen", None)
            size = item.opts.get("size", 8)
            return dict(pen=pen, symbol="o", symbolSize=size,
                        symbolBrush=brush, symbolPen=pen)

        # BAR
        if isinstance(item, pg.BarGraphItem):
            brush = item.opts.get("brush", None)
            return dict(pen=None, symbol="s", symbolSize=10,
                        symbolBrush=brush, symbolPen=None)

        # INFINITE LINE
        if isinstance(item, pg.InfiniteLine):
            pen = item.pen
            return dict(pen=pen)

        # REGION
        if isinstance(item, pg.LinearRegionItem):
            brush = item.brush
            return dict(pen=None, symbol="s", symbolSize=8,
                        symbolBrush=brush, symbolPen=None)

        # HEATMAP
        if isinstance(item, pg.ImageItem):
            return dict(pen=None, symbol="s", symbolSize=10,
                        symbolBrush=(200, 200, 200, 150), symbolPen=None)

        return dict(pen=None)

    def _refresh_locked_labels_2d(self, name):
        """Update locked labels attached to a specific 2D curve/heatmap/etc."""
        if not self._hover_enabled:
            return
        if name not in self._curves:
            return

        item = self._curves[name]

        for lbl in list(StylishHoverLabel.locked_labels):
            if lbl.nearest_curve != name or lbl.data_pos is None:
                continue

            # ---------- LINE / STEP ----------
            if isinstance(item, pg.PlotDataItem):
                xs, ys = item.getData()
                if xs is None or ys is None or len(xs) == 0:
                    lbl.hide(); StylishHoverLabel.remove_locked(*lbl.data_pos)
                    continue

                x0, _y0 = lbl.data_pos
                idx = int(np.argmin(np.abs(xs - x0)))
                x, y = float(xs[idx]), float(ys[idx])

                extra = ""
                if name in self._point_meta:
                    meta_list = self._point_meta[name]
                    if len(meta_list) > idx:
                        extra = str(meta_list[idx])
                elif name in self._curve_meta:
                    extra = str(self._curve_meta[name])
                
                xs = self._format_hover_x(x, name)
                ys = self._format_hover_y(y, name)
                txt = f"{name}\nX={xs}\nY={ys}"
                if extra:
                    txt += f"\n{extra}"

                lbl.text = txt
                lbl.data_pos = (x, y)
                lbl.update_position()

            # ---------- SCATTER ----------
            elif isinstance(item, pg.ScatterPlotItem):
                pts = item.data.get("pos")
                if pts is None or len(pts) == 0:
                    lbl.hide(); StylishHoverLabel.remove_locked(*lbl.data_pos)
                    continue

                x0, y0 = lbl.data_pos
                dx = pts[:, 0] - x0
                dy = pts[:, 1] - y0
                idx = int(np.argmin(dx*dx + dy*dy))
                x, y = pts[idx]

                extra = ""
                if name in self._point_meta and len(self._point_meta[name]) > idx:
                    extra = str(self._point_meta[name][idx])
                elif name in self._curve_meta:
                    extra = str(self._curve_meta[name])

                xs = self._format_hover_x(x, name)
                ys = self._format_hover_y(y, name)
                txt = f"{name}\nX={xs}\nY={ys}"
                if extra:
                    txt += f"\n{extra}"

                lbl.text = txt
                lbl.data_pos = (float(x), float(y))
                lbl.update_position()

            # ---------- BAR ----------
            elif isinstance(item, pg.BarGraphItem):
                xs = item.opts.get("x")
                hs = item.opts.get("height")
                if xs is None or hs is None:
                    lbl.hide(); StylishHoverLabel.remove_locked(*lbl.data_pos)
                    continue

                x0, _y0 = lbl.data_pos
                idx = int(np.argmin(np.abs(xs - x0)))
                x = float(xs[idx]); h = float(hs[idx])

                extra = ""
                if name in self._point_meta and len(self._point_meta[name]) > idx:
                    extra = str(self._point_meta[name][idx])
                elif name in self._curve_meta:
                    extra = str(self._curve_meta[name])

                xs = self._format_hover_x(x, name)
                txt = f"{name}\nX={xs}\nHeight={h:.3f}"
                if extra:
                    txt += f"\n{extra}"

                lbl.text = txt
                lbl.data_pos = (x, h)
                lbl.update_position()

            # ---------- INFINITE LINE ----------
            elif isinstance(item, pg.InfiniteLine):
                pos = float(item.value())
                x0, y0 = lbl.data_pos
                if item.angle == 90:
                    lbl.data_pos = (pos, y0)
                    pos = self._format_hover_x(pos, name)
                    lbl.text = f"{name}\nX={pos}"
                else:
                    lbl.data_pos = (x0, pos)
                    pos = self._format_hover_y(pos, name)
                    lbl.text = f"{name}\nY={pos:.3f}"
                lbl.update_position()

            # ---------- REGION ----------
            elif isinstance(item, pg.LinearRegionItem):
                lo, hi = item.getRegion()
                x0, y0 = lbl.data_pos
                # keep x0 within region
                x0 = float(np.clip(x0, lo, hi))
                lbl.data_pos = (x0, y0)
                lbl.text = f"{name}\n[{lo:.3f} → {hi:.3f}]"
                lbl.update_position()

            # ---------- HEATMAP ----------
            elif isinstance(item, pg.ImageItem):
                img = item.image
                if img is None:
                    lbl.hide(); StylishHoverLabel.remove_locked(*lbl.data_pos)
                    continue
                x0, y0 = lbl.data_pos
                h, w = img.shape[:2]
                ix, iy = int(round(x0)), int(round(y0))
                if not (0 <= ix < w and 0 <= iy < h):
                    lbl.hide(); StylishHoverLabel.remove_locked(*lbl.data_pos)
                    continue

                val = float(img[iy, ix])
                extra = ""
                if name in self._point_meta:
                    meta_arr = np.asarray(self._point_meta[name])
                    if meta_arr.shape[:2] == img.shape[:2]:
                        extra = str(meta_arr[iy, ix])
                elif name in self._curve_meta:
                    extra = str(self._curve_meta[name])

                ix = self._format_hover_x(ix, name)
                iy = self._format_hover_y(iy, name)
                txt = f"{name}\nX={ix}\nY={iy}\nVal={val:.3f}"
                if extra:
                    txt += f"\n{extra}"

                lbl.text = txt
                lbl.data_pos = (ix + 0.5, iy + 0.5)
                lbl.update_position()

    def _hover_line(self, name, item, mx, my):
        vb = item.getViewBox()
        pos_scene = vb.mapViewToScene(QtCore.QPointF(mx, my))

        res = self._closest_point_on_curve(item, pos_scene, vb.parentItem())
        if res is None:
            return None

        x, y, dist2_px, idx = res

        xs = self._format_hover_x(x, name)
        ys = self._format_hover_y(y, name)

        txt = f"{name}\nX={xs}\nY={ys}"

        # ---------- NEW: Per-point meta ----------
        if name in self._point_meta:
            meta_list = self._point_meta[name]
            if isinstance(meta_list, (list, np.ndarray)) and len(meta_list) > idx:
                txt += f"\n{meta_list[idx]}"

        # ---------- Curve-level meta fallback ----------
        elif name in self._curve_meta:
            txt += f"\n{self._curve_meta[name]}"

        return x, y, dist2_px, txt

    def _hover_heatmap(self, name, item, mx, my):
        """
        Heatmap hover (pg.ImageItem) that returns a data-space hover anchor.

        Returns:
            (x_data, y_data, dist2_px, text)  or None
        """
        img = getattr(item, "image", None)
        if img is None:
            return None

        vb = item.getViewBox()
        pos_scene = vb.mapViewToScene(QtCore.QPointF(mx, my))

        try:
            local = item.mapFromScene(pos_scene)
        except Exception:
            return None

        px = int(local.x())
        py = int(local.y())

        h, w = img.shape[:2]
        if not (0 <= px < w and 0 <= py < h):
            return None

        val = img[py, px]
        try:
            if np.isnan(val):
                return None
        except Exception:
            pass

        # Anchor at CENTER of the pixel, but converted to *data/view coords*
        try:
            pt_scene = item.mapToScene(QtCore.QPointF(px + 0.5, py + 0.5))
            pt_view = vb.mapSceneToView(pt_scene)
            x_data, y_data = float(pt_view.x()), float(pt_view.y())
        except Exception:
            return None

        # Distance is measured in scene pixels (consistent with your other hovers)
        dx = float(pt_scene.x() - pos_scene.x())
        dy = float(pt_scene.y() - pos_scene.y())
        dist2_px = dx * dx + dy * dy

        # Format X/Y using your existing formatter, but feed it DATA coords (not px/py)
        xs = self._format_hover_x(x_data, name)
        ys = self._format_hover_y(y_data, name)
        # Optional: include pixel indices too (useful for debugging)
        txt = f"{name}\nX={xs}\nY={ys}\nVal={float(val):.3f}"
        
        if name in self._point_meta:
            meta_arr = np.asarray(self._point_meta[name])
            if meta_arr.shape[:2] == img.shape[:2]:
                extra = meta_arr[py, px]
                if extra not in (None, "", np.nan):
                    txt += f"\n{extra}"

        elif name in self._curve_meta:
            txt += f"\n{self._curve_meta[name]}"

        return (x_data, y_data, dist2_px, txt)

    def _hover_scatter(self, name, item, mx, my):
        data = getattr(item, "data", None)
        if data is None:
            return None

        pts = None

        # ------------------------------------------------------------
        # CASE 1 : Structured array with unnamed fields ("f0","f1")
        # ------------------------------------------------------------
        try:
            if data.dtype.names and len(data.dtype.names) >= 2:
                # Get first two fields f0, f1
                x = data[data.dtype.names[0]]
                y = data[data.dtype.names[1]]
                pts = np.column_stack((x, y))
        except Exception:
            pts = None

        # ------------------------------------------------------------
        # CASE 2 : Try getData() (PG API fallback)
        # ------------------------------------------------------------
        if pts is None:
            try:
                xs, ys = item.getData()
                if xs is not None and ys is not None:
                    pts = np.column_stack((xs, ys))
            except Exception:
                pts = None

        # ------------------------------------------------------------
        # If STILL no points -> give up
        # ------------------------------------------------------------
        if pts is None or pts.shape[0] == 0:
            return None

        # ------------------------------------------------------------
        # Nearest point search
        # ------------------------------------------------------------
        dx = pts[:, 0] - mx
        dy = pts[:, 1] - my
        dist = dx*dx + dy*dy
        idx = int(np.argmin(dist))

        if dist[idx] > 0.5:
            return None

        x, y = pts[idx]

        extra = ""
        if name in self._point_meta and len(self._point_meta[name]) > idx:
            extra = str(self._point_meta[name][idx])
        elif name in self._curve_meta:
            extra = str(self._curve_meta[name])

        xs = self._format_hover_x(x, name)
        ys = self._format_hover_y(y, name)
        txt = f"{name}\nX={xs}\nY={ys}"
        if extra:
            txt += f"\n{extra}"

        vb = item.getViewBox()
        pt_scene = vb.mapViewToScene(QtCore.QPointF(x, y))
        pos_scene = vb.mapViewToScene(QtCore.QPointF(mx, my))

        dx = pt_scene.x() - pos_scene.x()
        dy = pt_scene.y() - pos_scene.y()
        dist2_px = dx*dx + dy*dy

        return float(x), float(y), dist2_px, txt

    def _hover_bar(self, name, item, mx, my):
        xs = item.opts.get("x")
        hs = item.opts.get("height")
        w = item.opts.get("width", 1.0)

        if xs is None or hs is None:
            return None

        vb = item.getViewBox()
        pos_scene = vb.mapViewToScene(QtCore.QPointF(mx, my))

        for i, (x, h) in enumerate(zip(xs, hs)):
            if abs(mx - x) <= w / 2 and 0 <= my <= h:

                # ---- extra text ----
                extra = ""
                if name in self._point_meta:
                    extra = str(self._point_meta[name][i])
                elif name in self._curve_meta:
                    extra = str(self._curve_meta[name])

                # ---- geometry uses RAW numeric values ----
                pt_scene = vb.mapViewToScene(QtCore.QPointF(float(x), float(h)))
                dx = pt_scene.x() - pos_scene.x()
                dy = pt_scene.y() - pos_scene.y()
                dist2_px = dx*dx + dy*dy

                # ---- formatting ONLY for text ----
                x_fmt = self._format_hover_x(x, name)
                txt = f"{name}\nX={x_fmt}\nHeight={h:.3f}"
                if extra:
                    txt += f"\n{extra}"

                return float(x), float(h), dist2_px, txt

        return None

    def _hover_infline(self, name, item, mx, my):
        angle = item.angle
        pos = float(item.value())
        vb = item.getViewBox()
        pos_scene = vb.mapViewToScene(QtCore.QPointF(mx, my))

        if angle == 90:
            x, y = pos, my

        elif angle == 0:
            x, y = mx, pos

        else:
            return None

        pt_scene = vb.mapViewToScene(QtCore.QPointF(x, y))
        dx = pt_scene.x() - pos_scene.x()
        dy = pt_scene.y() - pos_scene.y()
        dist2_px = dx*dx + dy*dy

        if angle == 90:
            xs = self._format_hover_x(x, name)
            txt = f"{name}\nX={xs}"
        else:
            ys = self._format_hover_y(y, name)
            txt = f"{name}\nY={ys}"

        return x, y, dist2_px, txt
    
    def _hover_region(self, name, item, mx, my):
        lo, hi = item.getRegion()

        if lo <= mx <= hi:
            txt = f"{name}\n[{lo:.3f} → {hi:.3f}]"
            vb = item.getViewBox()
            pos_scene = vb.mapViewToScene(QtCore.QPointF(mx, my))

            # dist = 0 → region always wins inside
            return mx, my, 0.0, txt

        return None

    def _apply_style_to_2d_subplot(self, p: pg.PlotWidget, style: dict):
        if not isinstance(p, pg.PlotWidget):
            return

        pi = p.getPlotItem()

        # -------- Background --------
        bg = style.get("background_color")
        if bg is not None:
            try:
                p.setBackground(bg)
            except Exception:
                pass

        # -------- Tick labels + tick lines --------
        tick_font = QFont(
            style.get("tick_label_font", "Arial"),
            int(style.get("tick_label_size", 9)),
        )

        tick_pen_color = style.get("tick_line_color", (150, 150, 150))
        tick_pen_width = int(style.get("tick_line_width", 1))
        try:
            tick_pen = pg.mkPen(tick_pen_color, width=tick_pen_width)
        except Exception:
            tick_pen = pg.mkPen("w")

        tick_text_pen = pg.mkPen(style.get("tick_label_color", "white"))

        for axis_name in ("bottom", "left", "top", "right"):
            ax = pi.getAxis(axis_name)
            if ax is None:
                continue
            try:
                ax.setPen(tick_pen)
            except Exception:
                pass
            try:
                ax.setTextPen(tick_text_pen)
            except Exception:
                pass
            try:
                ax.setTickFont(tick_font)
            except Exception:
                pass

        # -------- Axis labels --------
        label_font = QFont(
            style.get("axis_label_font", "Arial"),
            int(style.get("axis_label_size", 10)),
        )
        label_color = style.get("axis_label_color", "white")

        for axis_name in ("bottom", "left"):
            ax = pi.getAxis(axis_name)
            if ax is None:
                continue
            try:
                if ax.label is not None:
                    ax.label.setFont(label_font)
                    ax.label.setColor(label_color)
            except Exception:
                pass

        # -------- Gridlines --------
        grid_color = style.get("grid_color", (60, 60, 60))
        grid_width = int(style.get("grid_width", 1))
        try:
            grid_pen = pg.mkPen(grid_color, width=grid_width)
        except Exception:
            grid_pen = pg.mkPen((60, 60, 60))

        # Keep your existing showGrid for “on/off”
        # Try to override the grid pen where supported
        for axis_name in ("bottom", "left"):
            ax = pi.getAxis(axis_name)
            if ax is None:
                continue
            # Newer pyqtgraph: AxisItem has setGrid() & gridPen
            # try:
            #     ax.setGrid(255)  # full strength, alpha is in pen
            #     ax._gridPen = grid_pen  # Not public API, but works in practice
            # except Exception:
            #     pass

        # -------- Legend --------
        legend = pi.legend
        if legend is not None:
            # bg = style.get("legend_bg_color", (30, 30, 30, 180))
            # try:
            #     legend.setBrush(pg.mkBrush(bg))
            # except Exception:
            #     pass
            text_color = style.get("legend_text_color", "white")
            # legend.items is list of (sample, label)
            try:
                for sample, label in legend.items:
                    label.setAttr("color", text_color)
            except Exception:
                pass

        # -------- Title --------
        title_color = style.get("title_color", "white")
        title_size = int(style.get("title_size", 12))
        title_font = style.get("title_font", "Arial")

        title_item = getattr(pi, "titleLabel", None)
        if title_item is not None:
            # The titleLabel.text is HTML or plain text, we keep the raw text content
            raw = title_item.text
            if raw:
                # Strip outer HTML if it exists
                # (simple heuristic; if it's already HTML, we still rewrap)
                text_only = raw
                # Build new HTML
                new_html = (
                    f'<span style="color:{title_color}; '
                    f'font-size:{title_size}pt; '
                    f'font-family:{title_font};">{text_only}</span>'
                )
                try:
                    pi.setTitle(new_html)
                except Exception:
                    pass

    def _apply_style_to_hover_labels_2d(self, style: dict):
        """
        Update colors for StylishHoverLabel instances (2D).
        """
        txt = style.get("hover_text_color", None)
        bg = style.get("hover_bg_color", None)

        if txt is None and bg is None:
            return

        for lbl in list(self._hover_items.values()):
            try:
                if txt is not None:
                    lbl.text_item.setBrush(pg.mkBrush(txt))
                if bg is not None:
                    if isinstance(bg, (tuple, list)):
                        qcol = QColor(*bg)
                    else:
                        qcol = QColor(bg)
                    lbl.bg_item.setBrush(QBrush(qcol))
            except Exception:
                pass
    
    def apply_style(self, style: dict):
        """
        Apply a style dict (from PlotStyleProfile) to all subplots
        and 3D views.
        """
        self._style_profile = style

        #title
        r, g, b = self._style_profile.get("content_background")
        bg_color = f"#{r:02X}{g:02X}{b:02X}"
        self.figure_title.set_style(
            font_family=self._style_profile.get("title_font"),
            font_size=self._style_profile.get("title_size"),
            text_color=self._style_profile.get("title_color"),
            bg_color=bg_color,
        )

        # 2D subplots
        for key, widget in list(self._plots.items()):
            if not isinstance(key, tuple):
                continue

            # Only handle 2D or 3D subplots
            if len(key) != 2:
                continue

            row, col = key
            if isinstance(widget, pg.PlotWidget):
                self._apply_style_to_2d_subplot(widget, style)

        # Hover labels (2D)
        self._apply_style_to_hover_labels_2d(style)

        # 3D backend (views + Axis3D + 3D hover labels)
        self._backend3d.apply_style_to_3d(style)

    def _format_hover_x(self, x, name):
        row, col = self._curve_location.get(name, (None, None))
        if row is None:
            return f"{x:.3f}"

        return self.cat.decode_x(x, row, col, curve_name=name)

    def _format_hover_y(self, y, name):
        row, col = self._curve_location.get(name, (None, None))
        if row is None:
            return f"{y:.3f}"

        return self.cat.decode_y(y, row, col, curve_name=name)

    def _closest_point_on_curve(self, item, pos_scene, p):
        x, y = item.getData()
        if x is None or len(x) < 2:
            return None

        vb = p.vb

        # ---- DECIMATE ----
        max_pts = 2000
        stride = max(1, len(x) // max_pts)
        x = x[::stride]
        y = y[::stride]

        # ---- DATA → SCENE (Qt-native, FAST) ----
        poly = QPolygonF()
        append = poly.append
        for xi, yi in zip(x, y):
            append(QtCore.QPointF(float(xi), float(yi)))

        scene_poly = vb.mapViewToScene(poly)

        px = np.fromiter((p.x() for p in scene_poly), dtype=float)
        py = np.fromiter((p.y() for p in scene_poly), dtype=float)

        mx, my = pos_scene.x(), pos_scene.y()

        # ---- SEGMENT MATH (vectorized numpy) ----
        ax = px[:-1]
        ay = py[:-1]
        bx = px[1:]
        by = py[1:]

        vx = bx - ax
        vy = by - ay
        wx = mx - ax
        wy = my - ay

        denom = vx*vx + vy*vy
        mask = denom > 0
        if not np.any(mask):
            return None

        t = np.zeros_like(denom)
        t[mask] = (wx[mask]*vx[mask] + wy[mask]*vy[mask]) / denom[mask]
        t = np.clip(t, 0.0, 1.0)

        qx = ax + t * vx
        qy = ay + t * vy

        dx = mx - qx
        dy = my - qy
        dist2 = dx*dx + dy*dy

        idx = int(np.argmin(dist2))
        t_best = t[idx]   # how far along the segment (0 → left, 1 → right)

        # ---- Choose the closer endpoint for metadata index ----
        if t_best >= 0.5:
            data_index = int((idx + 1) * stride)
        else:
            data_index = int(idx * stride)

        # Clamp to valid bounds (important for last point)
        data_index = min(data_index, len(item.getData()[0]) - 1)

        # ---- SCENE → VIEW ----
        view_pt = vb.mapSceneToView(QtCore.QPointF(qx[idx], qy[idx]))

        return view_pt.x(), view_pt.y(), float(dist2[idx]), data_index

    def on_mouse_press_2d(self, evt, p, label, key):
        if evt.button() == Qt.LeftButton and label.isVisible():
            # If clicking same position -> remove that locked label
            if StylishHoverLabel.remove_locked(*label.data_pos):
                return
            else:
            # Otherwise, create a new locked label at data coords
                StylishHoverLabel.lock_label(p.plotItem.vb, label.text, *label.data_pos, label.nearest_curve)
            
            evt.accept()

        elif evt.button() == Qt.RightButton:
            evt.accept()

            # --------------------------------------------------
            # CREATE CLEAN CUSTOM MENU (NO PYQTGRAPH DEFAULT)
            # --------------------------------------------------
            view = p.getViewBox().scene().views()[0]  # real QWidget
            menu = QtWidgets.QMenu(view)

            # ---------------- Rectangle Zoom ------------------
            rect_zoom = QtWidgets.QAction("Rectangle zoom", menu)
            rect_zoom.setCheckable(True)
            rect_zoom.setChecked(p.plotItem.vb.state["mouseMode"] == p.plotItem.vb.RectMode)
            rect_zoom.triggered.connect(
                lambda checked: p.plotItem.vb.setMouseMode(
                    p.plotItem.vb.RectMode if checked else p.plotItem.vb.PanMode
                )
            )
            menu.addAction(rect_zoom)

            # ---------------- Auto Range ----------------------
            auto_range = QtWidgets.QAction("Auto range", menu)
            auto_range.triggered.connect(
                lambda: p.plotItem.vb.enableAutoRange(p.plotItem.vb.XYAxes)
            )
            menu.addAction(auto_range)

            # ---------------- Clear Labels --------------------
            clear_lbl = QtWidgets.QAction("Clear all labels", menu)
            clear_lbl.triggered.connect(StylishHoverLabel.clear_locked)
            menu.addAction(clear_lbl)

            # ---------------- Subplot Maximize ----------------
            menu.addSeparator()

            if not getattr(p, "_undocked", False):
                maximize = QtWidgets.QAction("Maximize subplot", menu)
                maximize.triggered.connect(
                    lambda checked, k=key, w=p: self._undock_subplot(w, k)
                )
                menu.addAction(maximize)
            else:
                restore = QtWidgets.QAction("Restore subplot", menu)
                restore.triggered.connect(lambda checked, k=key, w=p: self._dock_subplot(w, k))
                menu.addAction(restore)

            # ---------------- Export --------------------------
            menu.addSeparator()

            export_fig = QtWidgets.QAction("Export", menu)
            export_fig.triggered.connect(lambda: self.open_export_dialog("figure"))
            menu.addAction(export_fig)

            # ---------------- Show menu -----------------------
            qpos = QtCore.QPoint(
                int(evt.screenPos().x()),
                int(evt.screenPos().y())
            )
            menu.popup(qpos)

    def on_mouse_move_2d(self, evt, p, label):

        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if not (modifiers & QtCore.Qt.AltModifier):
            label.hide()
            return
        
        if not self._hover_enabled:
            return

        # event may come as tuple from SignalProxy
        pos = evt[0] if isinstance(evt, tuple) else evt

        # if mouse outside subplot scene → hide label
        if not p.sceneBoundingRect().contains(pos):
            label.hide()
            return

        # map mouse to data coords
        mouse_point = p.plotItem.vb.mapSceneToView(pos)
        mx, my = mouse_point.x(), mouse_point.y()

        nearest_curve = None
        nearest_point = None
        nearest_text = None
        min_dist2 = float("inf")

        # === SEARCH FOR NEAREST ITEM ==========================================
        for name, item in self._curves.items():

            # Skip items that do NOT have isVisible() → GLMeshItem, GLScatterPlotItem, etc.
            if not hasattr(item, "isVisible"):
                continue

            # If item is not visible skip it
            if not item.isVisible():
                continue

            # Skip if item does not come from this subplot
            if hasattr(item, "getViewBox") and item.getViewBox() is not p.plotItem.vb:
                continue

            result = None

            # --- LINE ---
            if isinstance(item, pg.PlotDataItem):
                result = self._hover_line(name, item, mx, my)

            # --- SCATTER ---
            elif isinstance(item, pg.ScatterPlotItem):
                result = self._hover_scatter(name, item, mx, my)

            # --- BAR ---
            elif isinstance(item, pg.BarGraphItem):
                result = self._hover_bar(name, item, mx, my)

            # --- INFINITE LINE ---
            elif isinstance(item, pg.InfiniteLine):
                result = self._hover_infline(name, item, mx, my)

            # --- REGION ---
            elif isinstance(item, pg.LinearRegionItem):
                result = self._hover_region(name, item, mx, my)

            # --- HEATMAP ---
            elif isinstance(item, pg.ImageItem):
                result = self._hover_heatmap(name, item, mx, my)

            # skip unknown types
            if not result:
                continue

            x, y, dist2, text = result

            if dist2 < min_dist2:
                min_dist2 = dist2
                nearest_curve = name
                nearest_point = (x, y)
                nearest_text = text

        # === NO NEAR ITEM FOUND ===============================================
        if nearest_curve is None:
            label.hide()
            return

        # === PIXEL DISTANCE THRESHOLD =========================================
        threshold_px = getattr(self, "_hover_threshold_px", 50)

        if min_dist2 > (threshold_px * threshold_px):
            label.hide()
            return

        # === SHOW LABEL =======================================================
        x, y = nearest_point
        label.show(nearest_text, x, y, nearest_curve)

    def attach_hover_2d(self, p, key):
        if p in self._hover_items:
            return

        label = StylishHoverLabel(p.plotItem.vb)
        self._hover_items[p] = label

        # update locked labels on zoom
        p.plotItem.vb.sigRangeChanged.connect(StylishHoverLabel.update_locked)

        # mouse click → locking logic
        p.plotItem.vb.mouseClickEvent = lambda evt: self.on_mouse_press_2d(evt, p, label, key)

        # hide on leave
        p.leaveEvent = lambda evt: label.hide()

        # MAIN HOVER PROXY (rate limited)
        proxy = pg.SignalProxy(
            p.scene().sigMouseMoved,
            rateLimit=60,
            slot=lambda evt: self.on_mouse_move_2d(evt, p, label),
        )
        self._hover_proxies_2d.append(proxy)

    def next_auto_color(self):
        c = self._auto_colors[self._auto_color_idx % len(self._auto_colors)]
        self._auto_color_idx += 1
        return c

    def next_auto_name(self):
        return f"curve_{len(self._curves)}"

    def make_pen(self, pen_desc):
        if pen_desc is None:
            return None
        if isinstance(pen_desc, dict):
            style_map = {
                "solid": QtCore.Qt.SolidLine,
                "dash": QtCore.Qt.DashLine,
                "dot": QtCore.Qt.DotLine,
                "dashdot": QtCore.Qt.DashDotLine,
                "dashdotdot": QtCore.Qt.DashDotDotLine,
            }
            style = style_map.get(pen_desc.get("style", "solid"), QtCore.Qt.SolidLine)
            return pg.mkPen(color=pen_desc.get("color", "y"),
                            width=pen_desc.get("width", 1),
                            style=style,
                            alpha=pen_desc.get("alpha", 255))
        return pen_desc

    def make_grid_3d(self, x, y, Z):
        verts = np.array([[xv, yv, Z[j, i]]
                        for j, yv in enumerate(y)
                        for i, xv in enumerate(x)], dtype=float)
        faces = []
        ncols = len(x); nrows = len(y)
        for j in range(nrows - 1):
            for i in range(ncols - 1):
                i0 = j * ncols + i
                i1 = i0 + 1
                i2 = i0 + ncols
                i3 = i2 + 1
                faces.append([i0, i2, i1])
                faces.append([i1, i2, i3])
        faces = np.array(faces, dtype=int)
        return verts, faces

    def map_colors_3d(self, Z, cmap_name, zmin, zmax):
        cmap = pg.colormap.get(cmap_name)
        norm = np.clip((Z - zmin) / max((zmax - zmin), 1e-9), 0, 1)
        q = cmap.mapToQColor(norm.ravel())
        return np.array([c.getRgbF() for c in q])

    def screen_projection_3d(self, view, pts3d):
        """Return Nx2 screen coordinates of 3D points for GLViewWidget."""
        proj_mat = np.array(view.projectionMatrix().data()).reshape(4, 4).T
        view_mat = np.array(view.viewMatrix().data()).reshape(4, 4).T
        m = proj_mat @ view_mat

        pts4 = np.c_[pts3d, np.ones(len(pts3d))].T
        proj = m @ pts4
        proj /= np.clip(proj[3], 1e-9, None)
        proj = proj[:3].T

        w, h = view.width(), view.height()
        proj[:, 0] = (proj[:, 0] * 0.5 + 0.5) * w
        proj[:, 1] = (1 - (proj[:, 1] * 0.5 + 0.5)) * h
        return proj[:, :2]

    def create_heatmap_labels(
        self,
        name,
        img_item: pg.ImageItem,
        plot: pg.PlotWidget,
        labels: np.ndarray,
        color,
        size,
        bg_shape,
        bg_color,
        label_pos,
    ):
        """
        Internal helper to overlay labels on a heatmap.
        Runs after the image has been laid out, to avoid freezes/glitches.
        """
        img = img_item.image
        if img is None:
            return

        ny, nx = img.shape[:2]

        # --- Colormap / LUT ---
        colormap = getattr(img_item, "_custom_colormap", None)
        if colormap is None:
            try:
                colormap = img_item.colorMap()
            except Exception:
                colormap = pg.colormap.get("viridis")
        lut = colormap.getLookupTable(nPts=256)

        # --- Levels (value range) ---
        try:
            lv = img_item.levels
            if callable(lv):
                lo, hi = lv()
            else:
                lo, hi = lv
        except Exception:
            lo, hi = float(np.nanmin(img)), float(np.nanmax(img))

        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            lo, hi = float(np.nanmin(img)), float(np.nanmax(img) + 1e-9)

        # --- Font parsing ---
        font_size = 10
        if isinstance(size, str) and size.endswith("pt"):
            try:
                font_size = int(size.replace("pt", "").strip())
            except ValueError:
                pass
        elif isinstance(size, (int, float)):
            font_size = int(size)
        font = QFont("Arial", font_size)

        # --- Helper for contrast color ---
        def get_contrast_color(base_rgb):
            """
            base_rgb: 3-component array in [0,1]
            Return 'white' or 'black' depending on perceived luminance.
            """
            rgb_lin = np.where(
                base_rgb <= 0.04045,
                base_rgb / 12.92,
                ((base_rgb + 0.055) / 1.055) ** 2.4
            )
            luminance = float(np.dot(rgb_lin, [0.2126, 0.7152, 0.0722]))
            return "white" if luminance < 0.5 else "black"

        # --- Background color base (if any) ---
        bg_rgb_for_contrast = None
        if bg_shape and bg_color is not None:
            try:
                bg_rgb = np.array(pg.mkColor(bg_color).getRgb()[:3]) / 255.0
                bg_rgb_for_contrast = bg_rgb
            except Exception:
                bg_rgb_for_contrast = None

        # --- Prepare storage ---
        if name not in self._heatmap_labels:
            self._heatmap_labels[name] = []
        label_items = self._heatmap_labels[name]

        # --- Determine label grid shape ---
        ny_lab, nx_lab = labels.shape[:2]

        # Iterate over label grid
        for j in range(ny_lab):
            for i in range(nx_lab):
                text = labels[j, i]
                if text is None or text == "":
                    continue

                # --- Choose pixel position in image index coordinates ---
                if label_pos is not None:
                    # label_pos is assumed in image index coordinates (x, y)
                    x_local, y_local = label_pos[j, i]
                else:
                    # Map label grid → image grid (center of each block)
                    xi = int((i + 0.5) * nx / nx_lab)
                    yj = int((j + 0.5) * ny / ny_lab)
                    xi = int(np.clip(xi, 0, nx - 1))
                    yj = int(np.clip(yj, 0, ny - 1))
                    x_local, y_local = xi + 0.5, yj + 0.5  # center of pixel

                # --- Sample value for color ---
                xi_idx = int(np.clip(round(x_local - 0.5), 0, nx - 1))
                yj_idx = int(np.clip(round(y_local - 0.5), 0, ny - 1))
                val = img[yj_idx, xi_idx]
                if np.isnan(val):
                    continue

                # --- Compute base color from colormap ---
                norm = np.clip((val - lo) / (hi - lo), 0, 1)
                lut_idx = int(norm * (len(lut) - 1))
                rgb = np.array(lut[lut_idx][:3]) / 255.0

                # --- Decide text color ---
                if color is not None:
                    txt_color = color
                else:
                    base_for_contrast = (
                        bg_rgb_for_contrast if bg_rgb_for_contrast is not None else rgb
                    )
                    txt_color = get_contrast_color(base_for_contrast)

                # --- Create TextItem as child of the ImageItem ---
                titem = pg.TextItem(text=str(text), color=txt_color, anchor=(0.5, 0.5))
                titem.setFont(font)
                titem._base_font_size = font_size
                titem._font = font
                scene_pt = img_item.mapToScene(QtCore.QPointF(x_local, y_local))
                vb_pt = plot.getPlotItem().vb.mapSceneToView(scene_pt)

                titem.setParentItem(plot.getPlotItem().vb)
                titem.setPos(vb_pt.x(), vb_pt.y())
                plot.getPlotItem().addItem(titem)
                label_items.append(titem)

                # --- Optional background shape attached to the text ---
                if bg_shape:
                    try:
                        # Measure approximate text rect in local coords
                        rect = titem.boundingRect()
                        pad = max(rect.height(), rect.width()) * 0.2

                        if bg_color is None:
                            shape_color = "white"
                        else:
                            shape_color = bg_color

                        if bg_shape == "rect":
                            bg_item = pg.QtWidgets.QGraphicsRectItem(
                                -rect.width() / 2 - pad,
                                -rect.height() / 2 - pad,
                                rect.width() + 2 * pad,
                                rect.height() + 2 * pad,
                            )
                        elif bg_shape == "circle":
                            d = max(rect.width(), rect.height()) + 2 * pad
                            bg_item = pg.QtWidgets.QGraphicsEllipseItem(
                                -d / 2, -d / 2, d, d
                            )
                        else:
                            bg_item = None

                        if bg_item is not None:
                            bg_item.setBrush(pg.mkBrush(pg.mkColor(shape_color).lighter(110)))
                            bg_item.setOpacity(1.0)
                            bg_item.setPen(pg.mkPen(None))
                            bg_item.setParentItem(titem)
                            bg_item.setZValue(titem.zValue() - 1)
                            titem._bg_item = bg_item
                            titem._bg_pad = pad
                    except Exception:
                        pass

        # (Optional) Simple zoom-aware font scaling
        vb = plot.getPlotItem().vb

        def scale_labels_on_range_change(*_args, vb=vb, name=name):
            # Keep a simple relative scaling based on view width
            if name not in self._heatmap_labels:
                return
            view_rect = vb.viewRect()
            view_width = view_rect.width()
            if not hasattr(vb, "_heatmap_base_width"):
                vb._heatmap_base_width = view_width if view_width > 0 else 1.0
            base_ref = vb._heatmap_base_width
            scale_factor = base_ref / max(view_width, 1e-9)

            for item in self._heatmap_labels[name]:
                f = getattr(item, "_font", None)
                if f is None:
                    continue
                base_size = getattr(item, "_base_font_size", font_size)
                new_font = QFont(f)
                new_font.setPointSizeF(base_size * scale_factor)
                item.setFont(new_font)
                bg_item = getattr(item, "_bg_item", None)
                if bg_item is not None:
                    bg_item.setScale(scale_factor)

        vb.sigRangeChanged.connect(scale_labels_on_range_change)
        # Trigger once to set initial font scaling
        scale_labels_on_range_change()

    def rebuild_grid(self, rows, cols):
        # 2. Remove old grid
        self.splitter_grid.clear_all()
        self.vlayout.removeWidget(self.splitter_grid)
        self.splitter_grid.setParent(None)
        self.splitter_grid.deleteLater()

        # 3. Create new grid
        self.splitter_grid = SplitterGrid(rows, cols)
        self.vlayout.addWidget(self.splitter_grid)

    def clear(self):
        # Remove 3D containers and hboxes
        self._backend3d.clear()

        # Reset registries
        self._plots.clear()
        self._curves.clear()
        self._curve_location.clear()
        self._heatmap_location.clear()
        self._colorbars.clear()
        self._point_meta.clear()
        self._curve_meta.clear()
        self._heatmap_labels.clear()

        self.splitter_grid.clear_all()

        self.rebuild_grid(self._rows, self._cols)

        # Recreate empty subplots
        for r in range(self._rows):
            for c in range(self._cols):
                self._generate_subplot_widget(r, c)

        self.apply_style(self._style_profile)
        return

    def get_target_subplot_keys(self, row, col):
        # Only allow (row, col) keys (length 2 tuples)
        subplot_keys = [k for k in self._plots.keys() if isinstance(k, tuple) and len(k) == 2]

        if row is None and col is None:
            return subplot_keys

        if row is not None and col is None:
            return [(r, c) for (r, c) in subplot_keys if r == row]

        if row is None and col is not None:
            return [(r, c) for (r, c) in subplot_keys if c == col]

        # both row and col given
        return [(row, col)] if (row, col) in subplot_keys else []
    
    def _handle_save(self, msg):
        target = msg.get("target")
        path = msg.get("path")
        raw_dpi = msg.get("dpi", None)
        dpi = 300 if raw_dpi is None else int(raw_dpi)
        transparent = bool(msg.get("transparent", False))

        if target == "figure":
            self._save_full_figure(path, dpi, transparent)

        elif target == "subplot":
            row, col = msg["row"], msg["col"]
            self._save_subplot(row, col, path, dpi, transparent)

        elif target == "item":
            name = msg["name"]
            self._save_item_data(name, path, msg.get("data", True), msg.get("meta", True))
    
    def _save_full_figure(self, path, dpi, transparent):
        pixmap = self.win.grab()
        if transparent:
            pixmap = pixmap.copy(pixmap.rect())

        pixmap.save(path, quality=100)
    
    def _save_subplot(self, row, col, path, dpi, transparent):
        widget = self._plots.get((row, col))

        if isinstance(widget, pg.PlotWidget):
            exporter = pg.exporters.ImageExporter(widget.plotItem)
            exporter.parameters()['width'] = int(8 * dpi)
            exporter.export(path)

        elif isinstance(widget, PlotWidget3D):
            pixmap = widget.grabFramebuffer()
            pixmap.save(path, quality=100)
    
    def _save_item_data(self, name, path, save_data=True, save_meta=True):
        meta = self._curve_meta.get(name)
        item = self._curves.get(name)

        base = os.path.splitext(path)[0]

        # ---------- NUMERIC DATA ----------
        if save_data:
            if isinstance(item, pg.PlotDataItem):
                x, y = item.getData()
                np.savetxt(base + ".csv", np.column_stack([x, y]), delimiter=",")

            elif isinstance(item, pg.ImageItem):
                np.save(base + ".npy", item.image)

            elif name in self._backend3d.meta:
                m = self._backend3d.meta[name]
                np.save(base + "_x.npy", m.x)
                np.save(base + "_y.npy", m.y)
                np.save(base + "_z.npy", m.z)

        # ---------- METADATA ----------
        if save_meta:
            with open(base + "_meta.json", "w") as f:
                json.dump({
                    "name": name,
                    "type": type(item).__name__,
                    "meta": meta
                }, f, indent=4)

    def _run_async(self, func, *args, **kwargs):
        """Run non-Qt, heavy work in a background thread."""
        t = threading.Thread(target=func, args=args, kwargs=kwargs, daemon=True)
        self._active_threads.append(t)
        t.start()
    
    def save_vector_figure(self, path: str, fmt: str = "pdf"):
        """High-level vector export of the whole window."""
        if not path.lower().endswith(f".{fmt.lower()}"):
            path += f".{fmt.lower()}"
        if fmt.lower() == "pdf":
            self._save_figure_pdf(path)
        elif fmt.lower() == "svg":
            self._save_figure_svg(path)

    def save_vector_subplot(self, row: int, col: int, path: str, fmt: str = "svg"):
        """Vector export of a single 2D subplot."""
        widget = self._plots.get((row, col))
        if not isinstance(widget, pg.PlotWidget):
            return
        if not path.lower().endswith(f".{fmt.lower()}"):
            path += f".{fmt.lower()}"
        if fmt.lower() == "svg":
            exporter = SVGExporter(widget.plotItem)
            exporter.export(path)
        elif fmt.lower() == "pdf":
            # PDF via printer
            self._save_item_pdf(widget, path)
    
    def _save_figure_pdf(self, path: str):
        """Render the entire plot window into a correctly scaled A4 PDF."""
        w = self.win.width()
        h = self.win.height()

        # ---------- Create A4 printer ----------
        printer = QPrinter(QPrinter.HighResolution)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName(path)
        printer.setPaperSize(QPrinter.A4)
        printer.setResolution(300)  # DPI

        # ---------- A4 page geometry ----------
        page_rect = printer.pageRect(QPrinter.DevicePixel)
        pw, ph = page_rect.width(), page_rect.height()

        # ---------- Compute uniform scale (preserve aspect ratio) ----------
        scale = min(pw / w, ph / h)

        # ---------- Painter ----------
        painter = QPainter(printer)

        painter.save()
        painter.translate((pw - w * scale) / 2, (ph - h * scale) / 2)  # center on page
        painter.scale(scale, scale)

        # ---------- Render ----------
        self.win.render(painter)

        painter.restore()
        painter.end()

    def _save_figure_svg(self, path: str):
        """Render the entire window to a single SVG (approximate)."""
        gen = QSvgGenerator()
        gen.setFileName(path)
        gen.setSize(self.win.size())
        gen.setViewBox(self.win.rect())
        gen.setTitle(self._title)
        gen.setDescription("PlotBackend SVG export")

        painter = QPainter(gen)
        self.win.render(painter)
        painter.end()

    def _save_item_pdf(self, widget: QtWidgets.QWidget, path: str):
        """Render a subplot widget into a correctly scaled A4 PDF."""
        # -----------------------------
        # 1) Get the full grid geometry
        # -----------------------------
        total_rows = self._rows
        total_cols = self._cols

        # subplot area fraction on A4
        frac_w = 1.0 / total_cols
        frac_h = 1.0 / total_rows

        # -----------------------------
        # 2) A4 Printer setup
        # -----------------------------
        printer = QPrinter(QPrinter.HighResolution)
        printer.setOutputFormat(QPrinter.PdfFormat)
        printer.setOutputFileName(path)
        printer.setPaperSize(QPrinter.A4)
        printer.setResolution(300)

        page_rect = printer.pageRect(QPrinter.DevicePixel)
        pw, ph = page_rect.width(), page_rect.height()

        # -----------------------------
        # 3) Target subplot A4 area
        # -----------------------------
        target_w = pw * frac_w
        target_h = ph * frac_h

        # -----------------------------
        # 4) Compute scale factor
        # -----------------------------
        ww = widget.width()
        wh = widget.height()

        scale = min(target_w / ww, target_h / wh)

        # Optional safety clamps
        scale = max(min(scale, 2.0), 0.2)

        # -----------------------------
        # 5) Center inside its A4 cell
        # -----------------------------
        # top-left corner of subplot cell (in PDF coords)
        cell_x = target_w
        cell_y = target_h

        painter = QPainter(printer)
        painter.save()

        painter.translate(
            cell_x + (target_w - ww * scale) / 2,
            cell_y + (target_h - wh * scale) / 2
        )
        painter.scale(scale, scale)

        widget.render(painter)

        painter.restore()
        painter.end()

    def save_state(self, path: str):
        """
        Export full figure state (2D & 3D items + style) to JSON.
        Note: large arrays -> large JSON files.
        """
        state = {
            "rows": self._rows,
            "cols": self._cols,
            "style": self._style_profile,
            "subplots": [],
            "three_d": [],
        }

        # ---- 2D subplots ----
        for key, widget in self._plots.items():
            if isinstance(key, tuple) and len(key) >= 2:
                r, c = key[0], key[1]
            else:
                continue
            if not isinstance(widget, pg.PlotWidget):
                continue

            pi = widget.getPlotItem()
            subplot = {
                "row": r,
                "col": c,
                "title": getattr(pi.titleLabel, "text", ""),
                "xlabel": pi.getAxis("bottom").labelText if pi.getAxis("bottom") else "",
                "ylabel": pi.getAxis("left").labelText if pi.getAxis("left") else "",
                "items": [],
            }

            # find all curve names in this subplot
            for name, (rr, cc) in list(self._curve_location.items()):
                if (rr, cc) != (r, c):
                    continue
                item = self._curves.get(name)
                if item is None:
                    continue

                rec = {"name": name}

                if isinstance(item, pg.PlotDataItem):
                    xs, ys = item.getData()
                    rec.update({
                        "type": "plot",
                        "x": xs.tolist() if xs is not None else [],
                        "y": ys.tolist() if ys is not None else [],
                    })
                elif isinstance(item, pg.ScatterPlotItem):
                    data = getattr(item, "data", None)
                    pts = None
                    if data is not None and hasattr(data, "dtype"):
                        try:
                            if data.dtype.names and len(data.dtype.names) >= 2:
                                x = data[data.dtype.names[0]]
                                y = data[data.dtype.names[1]]
                                pts = np.column_stack((x, y))
                        except Exception:
                            pts = None
                    if pts is None:
                        try:
                            xs, ys = item.getData()
                            pts = np.column_stack((xs, ys))
                        except Exception:
                            pts = None
                    if pts is not None:
                        rec.update({
                            "type": "scatter2d",
                            "x": pts[:, 0].tolist(),
                            "y": pts[:, 1].tolist(),
                        })
                elif isinstance(item, pg.BarGraphItem):
                    xs = np.asarray(item.opts.get("x", []))
                    hs = np.asarray(item.opts.get("height", []))
                    w = float(item.opts.get("width", 0.8))
                    rec.update({
                        "type": "bar",
                        "x": xs.tolist(),
                        "height": hs.tolist(),
                        "width": w,
                    })
                elif isinstance(item, pg.ImageItem):
                    img = item.image
                    if img is not None:
                        rec.update({
                            "type": "heatmap",
                            "data": np.asarray(img).tolist(),
                        })
                elif isinstance(item, pg.InfiniteLine):
                    rec.update({
                        "type": "infline",
                        "pos": float(item.value()),
                        "orientation": "horizontal" if item.angle == 0 else "vertical"
                    })
                elif isinstance(item, pg.LinearRegionItem):
                    lo, hi = item.getRegion()
                    rec.update({
                        "type": "region",
                        "range": [float(lo), float(hi)],
                    })
                else:
                    continue

                subplot["items"].append(rec)

            state["subplots"].append(subplot)

        # ---- 3D items ----
        for name, m in self._backend3d.meta.items():
            rec = {
                "name": name,
                "type": m.type,
                "row": m.key[0],
                "col": m.key[1],
                "cmap": m.cmap,
                "levels": m.levels,
            }
            rec["x"] = np.asarray(m.x).tolist() if m.x is not None else None
            rec["y"] = np.asarray(m.y).tolist() if m.y is not None else None
            if m.type == "mesh3d":
                rec["z"] = np.asarray(m.z).tolist()
            elif m.type == "scatter3d":
                rec["z"] = np.asarray(m.z).tolist()
            state["three_d"].append(rec)

        # write JSON asynchronously
        def _worker():
            with open(path, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)

        self._run_async(_worker)
    
    def load_state(self, path: str):
        """
        Clear current figure and rebuild from JSON state.
        This is best-effort and uses your existing creation commands.
        """
        if not os.path.exists(path):
            return

        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)

        rows = state.get("rows", self._rows)
        cols = state.get("cols", self._cols)
        self._rows, self._cols = rows, cols

        # Rebuild layout
        self.clear()

        # Re-apply style if present
        style = state.get("style")
        if style:
            self.apply_style(style)

        # Recreate 2D items via your own command logic
        for sp in state.get("subplots", []):
            r = sp["row"]; c = sp["col"]
            title = sp.get("title") or ""
            xlabel = sp.get("xlabel") or ""
            ylabel = sp.get("ylabel") or ""

            if (r, c) not in self._plots:
                continue
            p = self._plots[(r, c)]
            if title:
                p.setTitle(title)
            if xlabel:
                p.setLabel("bottom", xlabel)
            if ylabel:
                p.setLabel("left", ylabel)

            for it in sp.get("items", []):
                t = it.get("type")
                name = it["name"]

                if t == "plot":
                    msg = {
                        "cmd": "plot",
                        "name": name,
                        "xdata": np.array(it.get("x", [])),
                        "ydata": np.array(it.get("y", [])),
                        "row": r, "col": c,
                    }
                    # reuse implement_cmd logic
                    self._handle_single_message(msg)

                elif t == "scatter2d":
                    msg = {
                        "cmd": "scatter2d",
                        "name": name,
                        "xdata": np.array(it.get("x", [])),
                        "ydata": np.array(it.get("y", [])),
                        "row": r, "col": c,
                    }
                    self._handle_single_message(msg)

                elif t == "bar":
                    msg = {
                        "cmd": "bar",
                        "name": name,
                        "x": np.array(it.get("x", [])),
                        "height": np.array(it.get("height", [])),
                        "width": it.get("width", 0.8),
                        "row": r, "col": c,
                    }
                    self._handle_single_message(msg)

                elif t == "heatmap":
                    msg = {
                        "cmd": "heatmap",
                        "name": name,
                        "data": np.array(it.get("data", [])),
                        "row": r, "col": c,
                    }
                    self._handle_single_message(msg)

                elif t == "infline":
                    msg = {
                        "cmd": "infline",  # simple mapping; you can refine
                        "name": name,
                        "pos": it.get("pos"),
                        "row": r, "col": c,
                        "orientation": it.get("orientation")
                    }
                    self._handle_single_message(msg)

                elif t == "region":
                    msg = {
                        "cmd": "region",
                        "name": name,
                        "range": it.get("range", [0, 1]),
                        "row": r, "col": c,
                    }
                    self._handle_single_message(msg)

        # Recreate 3D items
        for m in state.get("three_d", []):
            name = m["name"]
            row, col = m["row"], m["col"]
            t = m["type"]

            if t == "mesh3d":
                msg = {
                    "cmd": "mesh3d",
                    "name": name,
                    "xdata": np.array(m.get("x")),
                    "ydata": np.array(m.get("y")),
                    "zdata": np.array(m.get("z")),
                    "row": row, "col": col,
                    "cmap": m.get("cmap", "viridis"),
                }
                self._handle_single_message(msg)

            elif t == "scatter3d":
                msg = {
                    "cmd": "scatter3d",
                    "name": name,
                    "xdata": np.array(m.get("x")),
                    "ydata": np.array(m.get("y")),
                    "zdata": np.array(m.get("z")),
                    "row": row, "col": col,
                    "cmap": m.get("cmap"),
                }
                self._handle_single_message(msg)
    
    def apply_preset(self, name: str):
        preset = self._export_presets.get(name)
        if not preset:
            return
        self._current_preset = name
        style = preset.get("style")
        if style:
            self.apply_style(style)

    def current_preset_params(self):
        preset = self._export_presets.get(self._current_preset, {})
        return {
            "dpi": preset.get("dpi", 200),
            "transparent": preset.get("transparent", False),
        }
    
    def save_bundle(self, path):
        with tempfile.TemporaryDirectory() as tmp:
            self._save_full_figure(os.path.join(tmp, "figure.png"), 300, False)

            for name in self._curves:
                self._save_item_data(name, os.path.join(tmp, name), True, True)

            with zipfile.ZipFile(path, "w") as z:
                for f in os.listdir(tmp):
                    z.write(os.path.join(tmp, f), f)

    def open_export_dialog(self, default_target="figure"):
        dlg = PlotExportDialog(self, default_target, self.win)
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return

        cfg = dlg.get_config()

        # -------- APPLY PRESET (MESSAGE) --------
        self._handle_single_message({
            "cmd": "apply_preset",
            "preset": cfg["preset"],
        })

        # -------- ASK FILE --------
        ext = cfg["format"]
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            None,
            "Save Plot",
            f"plot.{ext}",
            f"{ext.upper()} (*.{ext})"
        )

        if not path:
            return

        target = cfg["target"]
        dpi = cfg["dpi"]
        transparent = cfg["transparent"]

        # ==========================================================
        # ✅ DISPATCH EXPORT VIA _rx_queue (NOT _send_backend)
        # ==========================================================

        # ---------- FIGURE EXPORT ----------
        if target == "figure":

            if ext == "png":
                self._handle_single_message({
                    "cmd": "save",
                    "target": "figure",
                    "path": path,
                    "dpi": dpi,
                    "transparent": transparent,
                })

            else:  # svg / pdf
                self._handle_single_message({
                    "cmd": "save_vector",
                    "target": "figure",
                    "format": ext,
                    "path": path,
                })

        # ---------- SUBPLOT EXPORT ----------
        elif target == "subplot":
            row = cfg["row"]
            col = cfg["col"]

            if ext == "png":
                self._handle_single_message({
                    "cmd": "save",
                    "target": "subplot",
                    "row": row,
                    "col": col,
                    "path": path,
                    "dpi": dpi,
                    "transparent": transparent,
                })

            else:  # svg / pdf
                self._handle_single_message({
                    "cmd": "save_vector",
                    "target": "subplot",
                    "row": row,
                    "col": col,
                    "format": ext,
                    "path": path,
                })

        # ---------- OPTIONAL STATE SAVE ----------
        if cfg["save_state"]:
            self._handle_single_message({
                "cmd": "save_state",
                "path": path.replace(f".{ext}", ".json"),
            })

    def figure_anchor_from_string(self, name: str) -> Qt.Alignment:
        key = name.strip().replace(" ", "").lower()

        for attr in dir(FigureAnchor):
            if attr.lower() == key:
                return getattr(FigureAnchor, attr)

        raise ValueError(f"Invalid FigureAnchor: {name}")

    def axis_tick_anchor_from_string(self, name: str) -> Qt.Alignment:
        key = name.strip().replace(" ", "").lower()

        for attr in dir(AxisTickAnchor):
            if attr.lower() == key:
                return getattr(AxisTickAnchor, attr)

        raise ValueError(f"Invalid AxisTickAnchor: {name}")

    def set_figure_title(self, title):
        self.title = title
        self.win.setWindowTitle(self._title)
        self.figure_title.setText(self._title)

    def _align_heatmap_cells_to_x_y(self, img_item, data, x, y):
        rect = img_item.sceneBoundingRect()
        x_rect = rect.x()
        y_rect = rect.y()
        w = rect.width()
        h = rect.height()
        if x is not None and len(x) == data.shape[1]:
            step_distance = abs(x[1]-x[0])
            x_rect = x[0] - step_distance/2
            w = x[-1]-x[0] + step_distance
        else:
            x_rect = -0.5
            w = data.shape[:2][1]

        if y is not None and len(y) == data.shape[0]:
            step_distance = abs(y[1]-y[0])
            y_rect = y[0] - step_distance/2
            h = y[-1]-y[0] + step_distance
        else:
            y_rect = -0.5
            h = data.shape[:2][0]
        
        img_item.setRect(x_rect, y_rect, w, h)

    def _heatmap_safe_levels(self, data, fallback=(0.0, 1.0)):
        arr = np.asarray(data)
        finite = arr[np.isfinite(arr)]
        if finite.size == 0:
            return fallback
        lo, hi = float(finite.min()), float(finite.max())
        if lo == hi:
            eps = 1e-12 if lo != 0 else 1.0
            lo -= eps
            hi += eps
        return lo, hi

    def _handle_single_message(self, msg: dict):
        cmd = msg.get("cmd")

        if cmd == "plot":
            name_in = self.as_array_or_self(msg.get("name"))
            name_in = self.next_auto_name() if name_in is None else name_in
            y = self.as_array_or_self(msg["ydata"])
            x_raw = self.as_array_or_self(msg.get("xdata"))

            row = msg.get("row", 0)
            col = msg.get("col", 0)

            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            pen_desc = msg.get("pen")

            # ---------- helpers ----------
            def make_x(x, length):
                return np.arange(length) if x is None else np.asarray(x)

            def normalize_names(base, n):
                if isinstance(base, (list, tuple, np.ndarray)):
                    if len(base) != n:
                        raise ValueError(
                            f"name length ({len(base)}) does not match number of lines ({n})"
                        )
                    return list(base)
                else:
                    return [base]

            # ---------- SINGLE LINE ----------
            if y.ndim == 1:
                names = normalize_names(name_in, 1)
                name = names[0]

                if name in self._curves:
                    return

                x = make_x(x_raw, len(y))
                x = self.cat.encode_x(x, row, col, name)
                y = self.cat.encode_y(y, row, col, name)

                if pen_desc is None:
                    pen = pg.mkPen(color=self.next_auto_color(), width=2)
                elif isinstance(pen_desc, dict):
                    pen = self.make_pen(pen_desc)
                else:
                    pen = pen_desc

                item = p.plot(x=x, y=y, pen=pen, name=name)
                self._register_2d_item(name, item, row, col)

            # ---------- MULTI LINE ----------
            elif y.ndim == 2:
                n_lines = y.shape[0]
                names = normalize_names(name_in, n_lines)

                # Normalize X
                if x_raw is None:
                    xs = [np.arange(y.shape[1])] * n_lines
                else:
                    x_raw = np.asarray(x_raw)
                    if x_raw.ndim == 1:
                        xs = [x_raw] * n_lines
                    elif x_raw.ndim == 2:
                        if x_raw.shape[0] != n_lines:
                            raise ValueError("xdata rows must match ydata rows")
                        xs = list(x_raw)
                    else:
                        raise ValueError("xdata must be 1D or 2D")

                # Normalize pens
                if isinstance(pen_desc, (list, tuple)):
                    if len(pen_desc) != n_lines:
                        raise ValueError("pen list length must match number of lines")
                    pens = pen_desc
                else:
                    pens = [pen_desc] * n_lines

                for i in range(n_lines):
                    name = names[i]
                    if name in self._curves:
                        continue

                    xi = make_x(xs[i], y.shape[1])
                    yi = y[i]

                    xi = self.cat.encode_x(xi, row, col, name)
                    yi = self.cat.encode_y(yi, row, col, name)

                    pen_i = pens[i]
                    if pen_i is None:
                        pen_i = pg.mkPen(color=self.next_auto_color(), width=2)
                    elif isinstance(pen_i, dict):
                        pen_i = self.make_pen(pen_i)

                    item = p.plot(x=xi, y=yi, pen=pen_i, name=name)
                    self._register_2d_item(name, item, row, col)

            else:
                raise ValueError("ydata must be 1D or 2D")

            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()
 
        elif cmd == "step":
            name = msg.get("name") or self.next_auto_name()
            if name in self._curves:
                return

            x = self.as_array_or_self(msg["xdata"])
            y = self.as_array_or_self(msg["ydata"])
            row = msg.get("row", 0); col = msg.get("col", 0)
            x = self.cat.encode_x(x, row, col, name)
            y = self.cat.encode_y(y, row, col, name)
            pen_desc = msg.get("pen")

            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            pen = self.make_pen(pen_desc) if pen_desc else pg.mkPen(self.next_auto_color(), width=2)
            item = p.plot(x=x, y=y, pen=pen, stepMode=True, name=name)

            self._register_2d_item(name, item, row, col)
            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()

        elif cmd == "scatter2d":
            name = msg.get("name") or self.next_auto_name()
            if name in self._curves:
                return

            x = self.as_array_or_self(msg["xdata"])
            y = self.as_array_or_self(msg["ydata"])
            row = msg.get("row", 0); col = msg.get("col", 0)
            x = self.cat.encode_x(x, row, col, name)
            y = self.cat.encode_y(y, row, col, name)
            size = msg.get("size", 8)
            color = msg.get("color", "y")
            
            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            item = pg.ScatterPlotItem(
                x=x, y=y, size=size,
                pen=pg.mkPen(None),
                brush=pg.mkBrush(color),
                name=name
            )
            
            p.addItem(item)

            self._register_2d_item(name, item, row, col)
            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()
                
        elif cmd == "bar":
            name = msg.get("name") or self.next_auto_name()
            if name in self._curves:
                return

            h = self.as_array_or_self(msg["height"])
            x = self.as_array_or_self(msg["x"])
            x = np.arange(len(h)) if x is None else x
            row = msg.get("row", 0); col = msg.get("col", 0)
            x = self.cat.encode_x(x, row, col, name)
            w = msg.get("width", 0.8)
            color = msg.get("color", "c")

            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            item = pg.BarGraphItem(x=x, height=h, width=w, brush=color)
            p.addItem(item)

            self._register_2d_item(name, item, row, col)
            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()
                
        elif cmd == "infline":
            name = msg.get("name") or self.next_auto_name()
            if name in self._curves:
                return

            pos = self.as_array_or_self(msg["pos"], float)
            row = msg.get("row", 0); col = msg.get("col", 0)
            color = msg.get("color", "y")
            orientation = msg.get("orientation", "horizontal")
            if orientation == "horizontal":
                pos = self.cat.encode_y(pos, row, col, name)
                angle = 0
            elif orientation == "vertical":
                pos = self.cat.encode_x(pos, row, col, name)
                angle = 90
            else:
                return
            
            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            item = pg.InfiniteLine(pos=pos, angle=angle, pen=pg.mkPen(color), name=name)
            p.addItem(item)

            self._register_2d_item(name, item, row, col)
            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()
                
        elif cmd == "region":
            name = msg.get("name") or self.next_auto_name()
            if name in self._curves:
                return

            bounds = self.as_array_or_self(msg["range"])
            color = msg.get("color", (50, 50, 150, 80))
            row = msg.get("row", 0); col = msg.get("col", 0)

            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            item = pg.LinearRegionItem(values=bounds, brush=color)
            p.addItem(item)

            self._register_2d_item(name, item, row, col)
            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()

        elif cmd == "heatmap":
            name = msg.get("name") or self.next_auto_name()
            if name in self._curves:
                return

            data = self.as_array_or_self(msg["data"])
            x = self.as_array_or_self(msg["x"])
            y = self.as_array_or_self(msg["y"])
            row = msg.get("row", 0); col = msg.get("col", 0)
            cmap = msg.get("cmap", "viridis")
            want_cbar = msg.get("cbar", True)

            p = self._ensure_plotwidget(row, col)
            if p is None:
                return

            img_item = pg.ImageItem(image=data)
            colormap = pg.colormap.get(cmap)
            lut = colormap.getLookupTable(nPts=256)
            img_item.setLookupTable(lut)
            lo, hi = self._heatmap_safe_levels(data)
            img_item.setLevels((lo, hi))
            img_item._custom_colormap = colormap
            img_item.setOpts(axisOrder='row-major')
            self._align_heatmap_cells_to_x_y(img_item, data, x, y)
            p.addItem(img_item)

            self._register_2d_item(name, img_item, row, col)
            self._heatmap_location[name] = (row, col)

            if want_cbar:
                colorbar = pg.ColorBarItem(values=(lo, hi), colorMap=colormap, label=name)
                colorbar.setImageItem(img_item, insert_in=p.getPlotItem())
                self._colorbars[name] = colorbar

            self.attach_hover_2d(p, (row, col))
            self.cat.apply_ticks(p, row, col)
            self._send_done()
                
        elif cmd == "mesh3d":
            self._backend3d.create_mesh(msg)
            self._send_done() 

        elif cmd == "scatter3d":
            self._backend3d.create_scatter(msg)
            self._send_done() 
        
        elif cmd == "table":
            name = msg.get("name") or self.next_auto_name()
            row = msg.get("row", 0)
            col = msg.get("col", 0)
            data = msg["data"]   # DataFrame or Styler

            # ---- NEW: optional table config ----
            row_height = msg.get("row_height", None)
            col_width = msg.get("col_width", None)
            initial_sort = msg.get("initial_sort", None)

            w = DataFrameExplorer(
                data,
                row_height=row_height,
                col_width=col_width,
                initial_sort=initial_sort,
            )
            
            self._register_2d_item(name, w.model, row, col)
            self._set_subplot_widget(row, col, w)

            self._send_done()

        elif cmd == "update":
            name = msg["name"]
            if name not in self._curves:
                return

            item = self._curves[name]
            row, col = self._curve_location.get(name)
            p = self._ensure_plotwidget(row, col)

            # ---- LINE / STEP ----
            if isinstance(item, pg.PlotDataItem):
                y = self.as_array_or_self(msg["ydata"])
                x = self.as_array_or_self(msg["xdata"])
                x = np.arange(len(y)) if x is None else x
                x = self.cat.encode_x(x, row, col, name)
                y = self.cat.encode_y(y, row, col, name)
                item.setData(x=x, y=y)
                self.cat.apply_ticks(p, row, col)

            # ---- SCATTER ----
            elif isinstance(item, pg.ScatterPlotItem):
                x = self.as_array_or_self(msg["xdata"])
                y = self.as_array_or_self(msg["ydata"])
                x = self.cat.encode_x(x, row, col, name)
                y = self.cat.encode_y(y, row, col, name)
                size = msg.get("size", None)
                color = msg.get("color", None)
                if color is not None:
                    item.setBrush(pg.mkBrush(color))
                if size is not None:
                    item.setSize(size)
                item.setData(x=x, y=y)
                self.cat.apply_ticks(p, row, col)

            # ---- BAR ----
            elif isinstance(item, pg.BarGraphItem):
                h = self.as_array_or_self(msg.get("height"))
                h = item.opts.get("height") if h is None else h
                x = self.as_array_or_self(msg.get("x"))
                x = item.opts.get("x") if x is None else x
                x = self.cat.encode_x(x, row, col, name)

                w = self.as_array_or_self(msg.get("width"), float) or item.opts.get("width")
                if w is None:
                    w = 0.8   # final safe fallback

                color = msg.get("color")
                if color is None:
                    color = item.opts.get("brush", "c")
                (row, col) = self._curve_location.get(name, (0, 0))
                p = self._ensure_plotwidget(row, col)
                if p:
                    p.removeItem(item)

                new_item = pg.BarGraphItem(x=x, height=h, width=w, brush=color)

                if p:
                    p.addItem(new_item)

                self._register_2d_item(name, new_item, row, col)
                item = new_item
                self.cat.apply_ticks(p, row, col)

            # ---- VLINE ----
            elif isinstance(item, pg.InfiniteLine):
                pos = self.as_array_or_self(msg.get("pos"), float)
                pos = item.value() if pos is None else pos
                pos = self.cat.encode_x(pos, row, col, name) if item.angle == 90 else self.cat.encode_y(pos, row, col, name)
                item.setValue(pos)
                self.cat.apply_ticks(p, row, col)
                
            # ---- REGION ----
            elif isinstance(item, pg.LinearRegionItem):
                bounds = self.as_array_or_self(msg.get("range"))
                if bounds is not None:
                    item.setRegion(bounds)

            # ---- HEATMAP ----
            elif isinstance(item, pg.ImageItem):
                data = self.as_array_or_self(msg["data"])
                x = self.as_array_or_self(msg["x"])
                y = self.as_array_or_self(msg["y"])
                item.setImage(data, autoLevels=False)
                self._align_heatmap_cells_to_x_y(item, data, x, y)
                
                if name in self._colorbars:
                    self._colorbars[name].setLevels((self._heatmap_safe_levels(data)))

            # refresh locked labels for ANY 2D kind
            self._refresh_locked_labels_2d(name)

            self._send_done()

        elif cmd == "update_scatter2d":
            # kept for backward compatibility; routes to update
            msg["cmd"] = "update"
            self._handle_single_message(msg)
            return


        elif cmd == "update_bar":
            # explicit bar update command if you want to send it
            msg["cmd"] = "update"
            self._handle_single_message(msg)
            return

        elif cmd == "update_vline":
            msg["cmd"] = "update"
            self._handle_single_message(msg)
            return

        elif cmd == "update_region":
            msg["cmd"] = "update"
            self._handle_single_message(msg)
            return

        elif cmd == "update_heatmap":
            # explicit heatmap update -> routes to update
            msg["cmd"] = "update"
            self._handle_single_message(msg)
            return
        
        elif cmd == "update_mesh3d":
            self._backend3d.update_mesh(msg)
            self._send_done() 

        elif cmd == "update_scatter3d":
            self._backend3d.update_scatter(msg)
            self._send_done()
        
        elif cmd == "update_table":
            name = msg["name"]
            data = msg["data"]

            item = self._curves[name]
            row, col = self._curve_location.get(name)
            p = self._ensure_plotwidget(row, col)

            item.beginResetModel()

            # ---------------------------
            # Handle DataFrame / Styler
            # ---------------------------
            if isinstance(data, Styler):
                item.df = data.data
                item.styles = item._extract_styles(data)
            else:
                item.df = data
                item.styles = {}

            # ---------------------------
            # Rebuild numeric column cache
            # ---------------------------
            item._numeric_columns = item.df.select_dtypes(
                include=[np.number]
            ).columns

            item.endResetModel()

            self._send_done()

        elif cmd == "set_heatmap_levels":
            name = msg["name"]
            levels = tuple(msg["levels"])
            if name in self._curves and isinstance(self._curves[name], pg.ImageItem):
                item = self._curves[name]
                item.setLevels(levels)
                if name in self._colorbars:
                    self._colorbars[name].setLevels(levels)
            self._send_done()

        elif cmd == "set_heatmap_labels":
            name = msg["name"]
            labels = self.as_array_or_self(msg["labels"], str)
            color = msg.get("color", None)
            size = msg.get("size", "5pt")
            label_pos = self.as_array_or_self(msg["label_pos"])
            bg_shape = msg.get("bg_shape", None)       # "rect" | "circle" | None
            bg_color = msg.get("bg_color", "white")

            # --- ImageItem must exist ---
            img_item = self._curves.get(name)
            if not isinstance(img_item, pg.ImageItem):
                return

            (row, col) = self._curve_location.get(name, (0, 0))
            p = self._ensure_plotwidget(row, col)
                            
            # --- Schedule heavy label creation after the heatmap is stable ---
            QtCore.QTimer.singleShot(
                0,
                lambda n=name,
                    img=img_item,
                    p=p,
                    lab=labels,
                    c=color,
                    s=size,
                    bg=bg_shape,
                    bgc=bg_color,
                    lp=label_pos: self.create_heatmap_labels(
                        n, img, p, lab, c, s, bg, bgc, lp
                    )
            )

            self._send_done()
        
        elif cmd == "clear_heatmap_labels":
            name = msg["name"]

            # --- ImageItem must exist ---
            img_item = self._curves.get(name)
            if not isinstance(img_item, pg.ImageItem):
                return

            (row, col) = self._curve_location.get(name, (0, 0))
            p = self._ensure_plotwidget(row, col)
            
            # --- Clear any previous labels for this heatmap ---
            if name in self._heatmap_labels:
                for it in self._heatmap_labels[name]:
                    try:
                        if it is not None and it.scene() is not None:
                            p.getPlotItem().removeItem(it)
                    except Exception:
                        pass
                self._heatmap_labels[name].clear()
            else:
                self._heatmap_labels[name] = []

            self._send_done()
                
        # --- Update figure title ---
        elif cmd == "set_figure_title":
            new_title = msg.get("title", None)
            if self._title != new_title and isinstance(new_title, str):
                self.set_figure_title(new_title)
            self._send_done()
                
        # --- Update subplot title ---
        elif cmd == "set_subplot_title":
            row = msg["row"]
            col = msg["col"]
            title = msg["title"]

            # --- 2D subplot (PlotWidget)
            if (row, col) in self._plots and isinstance(self._plots[(row, col)], (pg.PlotWidget, DataFrameExplorer)):
                self._plots[(row, col)].setTitle(title)

            # --- 3D subplot (GLViewWidget)
            if (row, col) in self._backend3d.titles:
                self._backend3d.titles[(row, col)].setText(title)

            self._send_done()
                
        # --- Update axis labels ---
        elif cmd == "set_axis_labels":
            row, col = msg["row"], msg["col"]
            xlabel, ylabel, zlabel = msg.get("xlabel"), msg.get("ylabel"), msg.get("zlabel")

            targets = self.get_target_subplot_keys(row, col)

            for (r, c) in targets:
                if (r, c, "axis") in self._plots:
                    self._plots[(r, r, "axis")].set_axis_labels(
                        x=xlabel, y=ylabel, z=zlabel
                    )
                elif (r, c) in self._plots:
                    if xlabel:
                        self._plots[(r, c)].setLabel("bottom", xlabel)
                    if ylabel:
                        self._plots[(r, c)].setLabel("left", ylabel)
            self._send_done()
                
        elif cmd == "set_legend_visibility":
            row = msg.get("row", None)
            col = msg.get("col", None)
            show = msg["show"]

            targets = self.get_target_subplot_keys(row, col)

            for (r, c) in targets:
                p = self._plots[(r, c)]
                pi = p.getPlotItem()

                if pi.legend is None:
                    pi.addLegend()

                if show:
                    pi.legend.show()
                else:
                    pi.legend.hide()

            self._send_done()
                
        elif cmd == "hover_enable":
            self._hover_enabled = msg["enable"]
            for label in self._hover_items.values():
                if self._hover_enabled:
                    label.text_item.show()
                    label.bg_item.show()
                else:
                    label.hide()
            
            self._send_done()
                
        elif cmd == "set_hover_info":
            name = msg["name"]
            info = msg.get("info", "")
            per_point = msg.get("per_point", False)
            if per_point:
                self._point_meta[name] = np.array(info)  # expect list/array of same length as curve data
            else:
                self._curve_meta[name] = np.array(info)
            self._send_done()
                
        elif cmd == "set_close_enabled":
            self._close_enabled = msg["enabled"]
            self._send_done()
                
        elif cmd == "trigger_close":
            self._programmatic_close = True
            self.win.close()
            self._send_done()
                
        elif cmd == "clear":
            self.clear()
            self._send_done()
        
        elif cmd == "apply_style":
            style = msg.get("style", {})
            self.apply_style(style)
            self._send_done()
        
        elif cmd == "set_3d_projection":
            row = msg.get("row", None)
            col = msg.get("col", None)
            projection = msg["projection"]

            targets = self.get_target_subplot_keys(row, col)

            for (r, c) in targets:
                p = self._plots[(r, c)]
                if hasattr(p, "set_ortho"):
                    p.set_ortho(projection == "Orthographic")

            self._send_done()
        
        elif cmd == "save":
            self._handle_save(msg)
            self._send_done()
        
        elif cmd == "save_vector":
            target = msg.get("target", "figure")
            path = msg["path"]
            fmt = msg.get("format", "pdf")

            if target == "figure":
                if fmt.lower() == "pdf":
                    self._save_figure_pdf(path)
                else:
                    self._save_figure_svg(path)
            elif target == "subplot":
                row = msg["row"]; col = msg["col"]
                self.save_vector_subplot(row, col, path, fmt=fmt)

            self._send_done()
        
        elif cmd == "save_state":
            path = msg["path"]
            self.save_state(path)
            self._send_done()

        elif cmd == "load_state":
            path = msg["path"]
            self.load_state(path)
            self._send_done()
        
        elif cmd == "apply_preset":
            preset_name = msg["preset"]
            self.apply_preset(preset_name)
            self._send_done()
        
        elif cmd == "save_bundle":
            path = msg["path"]
            self.save_bundle(path)
            self._send_done()
        
        elif cmd == "set_annotation":
            text = msg["text"]
            anchor = msg.get("anchor", "Center")
            offset = msg.get("offset", (0, 0))
            style = msg.get("style", {})

            anchor_qt = self.figure_anchor_from_string(anchor)

            self._overlay.add_annotation(
                text,
                anchor=anchor_qt,
                offset=offset,
                style=style,
            )

            self._send_done()
        
        elif cmd == "remove_annotation":
            anchor = msg.get("anchor", "Center")
            offset = msg.get("offset", (0, 0))

            anchor_qt = self.figure_anchor_from_string(anchor)
            removed = self._overlay.remove_annotation(
                anchor=anchor_qt,
                offset=offset,
            )

            self._send_done()
        
        elif cmd == "tick_rotation":
            row, col = msg.get("row", None), msg.get("col", None)
            axis = msg.get("axis", "x")
            anchor = msg.get("anchor", "center")
            angle = msg.get("angle", 0)

            targets = self.get_target_subplot_keys(row, col)

            for (r, c) in targets:
                p = self._plots[(r, c)]
                if isinstance(p, pg.PlotWidget):
                    pi = p.getPlotItem()
                    if pi is not None:
                        if axis in ("x", "both"):
                            pi.getAxis("bottom").setTickRotation(angle=angle, anchor=anchor)

                        if axis in ("y", "both"):
                            pi.getAxis("left").setTickRotation(angle=angle, anchor=anchor)

            self._send_done()
        
        elif cmd == "show_grid":
            row, col = msg.get("row", None), msg.get("col", None)
            axis = msg.get("axis", "both")
            alpha = msg.get("alpha", "0.3")

            targets = self.get_target_subplot_keys(row, col)

            for (r, c) in targets:
                p = self._plots[(r, c)]
                if isinstance(p, pg.PlotWidget):
                    p.showGrid(x=True if axis in ("x", "both") else False, y=True if axis in ("y", "both") else False, alpha=alpha)

            self._send_done()
        
        elif cmd == "set_layout":
            rows, cols, title = msg.get("rows", None), msg.get("cols", None), msg.get("title", None)
            rebuild = False
            if self._rows != rows and isinstance(rows, int):
                self._rows = rows
                rebuild = True
            if self._cols != cols and isinstance(cols, int):
                self._cols = cols
                rebuild = True

            if rebuild:
                self.clear()
            
            if self._title != title and isinstance(title, str):
                self.set_figure_title(title)

            self._send_done()

    def implement_cmd(self):
        while not self._rx_queue.empty():
            msg = self._rx_queue.get()
            cmd = msg.get("cmd")

            if cmd == "_batch":
                messages = msg.get("messages", [])
                self._batch_depth += 1

                try:
                    # ---- Execute sub-commands ----
                    for sub in messages:
                        if not isinstance(sub, dict):
                            continue
                        if sub.get("cmd") is None:
                            continue
                        self._handle_single_message(sub)

                finally:
                    self._batch_depth -= 1
                    if self._batch_depth == 0:
                        self._send_done()

                continue
            
            elif cmd == "get_curve_list":
                self._send_frontend({
                    "cmd": "_curves", 
                    "curves": list(self._curves.keys())
                    })
                self._send_done(True)
            
            elif cmd == "get_layout":
                self._send_frontend({
                    "cmd": "_layout", 
                    "layout": [self._title, [len(self.splitter_grid.rows), len(self.splitter_grid.rows)]]
                    })
                self._send_done(True)
                
            # ---- Normal command ----
            self._handle_single_message(msg)

    def worker(self, rx_queue=None, tx_queue=None):
        
        """
        Start the backend either as a standalone process window (process mode)
        or as an embeddable widget (thread mode).

        Parameters
        ----------
        rx_queue : multiprocessing.Queue | None
            Queue to receive messages from the main process (used in process mode).
        tx_queue : multiprocessing.Queue | None
            Queue to send messages back to the main process (used in process mode).
        mode : str
            Either "standalone" (process) or "widget" (thread).
        """
        
        try:
            # Shared setup
            self._rx_queue = rx_queue
            self._tx_queue = tx_queue
            self._plots = {}

            if self._mode == "standalone":
                # -------------------------------
                # Standalone (separate process)
                # -------------------------------
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    application_id("plot")
                )
                QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
                QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)
                self.app = QtWidgets.QApplication(sys.argv)
                pg.setConfigOptions(antialias=self._antialiasing)

                self.central = QtWidgets.QWidget()
                self.win = QtWidgets.QMainWindow()
                self.win.setCentralWidget(self.central)
                self.win.setWindowTitle(self._title)
                self.win.setWindowIcon(self.generate_icon())
                self.win.closeEvent = self.closeEvent
                
                self.vlayout = QtWidgets.QVBoxLayout(self.central)
                self.vlayout.setContentsMargins(0, 0, 0, 0)
                self.vlayout.setSpacing(0)

                self.figure_title = FigureTitleWidget(
                    text=self._title
                )
                
                self.vlayout.addWidget(self.figure_title)

                self.splitter_grid = SplitterGrid(self._rows, self._cols)

                self.vlayout.addWidget(self.splitter_grid)

                self._overlay = FigureOverlay(self.win)
                
                # Create subplots
                for r in range(self._rows):
                    for c in range(self._cols):
                        self._generate_subplot_widget(r, c)
                
                if self._tx_queue:
                    self._tx_queue.put({"cmd": "_ready"})

                # Event loop for process mode
                self.timer = QtCore.QTimer()
                self.timer.timeout.connect(self.implement_cmd)
                self.timer.start(self._update_interval)

                self.win.show()
                sys.exit(self.app.exec_())

            elif self._mode == "widget":
                # -------------------------------
                # Thread / Embedded mode
                # -------------------------------
                pg.setConfigOptions(antialias=self._antialiasing)
                self.win = QtWidgets.QWidget()
                self.win.setWindowTitle(self._title)
                self.win.setWindowIcon(self.generate_icon())

                self.vlayout = QtWidgets.QVBoxLayout(self.win)
                self.vlayout.setContentsMargins(0, 0, 0, 0)
                self.vlayout.setSpacing(0)

                self.figure_title = FigureTitleWidget(
                    text=self._title
                )
                
                self.vlayout.addWidget(self.figure_title)

                self.splitter_grid = SplitterGrid(self._rows, self._cols)

                self.vlayout.addWidget(self.splitter_grid)

                self._overlay = FigureOverlay(self.win)

                # Create subplots
                for r in range(self._rows):
                    for c in range(self._cols):
                        self._generate_subplot_widget(r, c)

                # Attach QTimer to host app event loop
                self.timer = QtCore.QTimer(self.win)
                self.timer.timeout.connect(self.implement_cmd)
                self.timer.start(self._update_interval)

                # No app.exec_() → this widget integrates into the parent GUI
                if self._tx_queue:
                    self._tx_queue.put({"cmd": "_ready", "win": self.win})

        except Exception as e:
            import traceback
            err = traceback.format_exc()
            print("Backend crashed:\n", err)
            if self._tx_queue:
                try:
                    self._tx_queue.put({"cmd": "_error", "error": err})
                except Exception:
                    pass

class Plot:
    def __init__(self, title="Plot", *, rows=1, cols=1, update_interval=50,
                blocks=True, block_timeout=5, initiation_timeout=5,
                mode:Literal["standalone", "widget"] = "standalone", antialiasing=True):
        """
        Initialize a Plot frontend and start its backend.

        This class is a high-level controller that communicates with a
        PlotBackend (2D + 3D) running either in a separate process
        ("standalone" mode) or embedded in the current Qt application
        ("widget" mode).

        Parameters
        ----------
        title : str
            Title of the figure window.
        rows : int
            Number of subplot rows.
        cols : int
            Number of subplot columns.
        update_interval : int
            Backend refresh interval in milliseconds.
        blocks : bool
            If True, frontend waits for backend completion after each command.
        block_timeout : float
            Maximum seconds to wait for backend "_done".
        initiation_timeout : float
            Timeout for backend startup handshake.
        mode : {"standalone", "widget"}
            Backend execution mode.
        antialiasing : bool
            Enable or disable antialiasing in backend plots.
        """

        self._blocks = blocks
        self._block_timeout = block_timeout
        self._initiation_timeout = initiation_timeout
        self._mode = mode
        self._tx_queue = None
        self._rx_queue = None
        self._process = None
        self._backend = PlotBackend(title, rows, cols, update_interval, self._blocks, self._mode, antialiasing)
        self._started = False
        self._done = False
        self._batch_depth = 0
        self._batch_buffer = None   # None when not batching, else list[dict]
        self._curves = []
        self._layout = ()
        self._ensure_backend()
        self.set_style(PlotStyleProfile.matlab())
    
    class PenHelper:
        """Helper for creating PyQtGraph pens easily."""
        def __new__(cls, color='y', width=1, style='solid', alpha=255):
            """
            Returns a pg.mkPen object with the given properties.

            Parameters
            ----------

            color : str | tuple
                Color name ('r', 'red', etc.) or RGB/RGBA tuple.

            width : int
                Line width.

            style : str
                One of ['solid', 'dash', 'dot', 'dashdot', 'dashdotdot'].

            alpha : int
                Transparency (0–255).
            """
            
            return dict(color=color, width=width, style=style, alpha=alpha)
    
    @property
    def widget(self):
        """
        Return the backend plot window as a QWidget.

        Only valid when Plot is created with mode="widget".

        Returns
        -------
        QWidget
            Embedded plot widget.

        Raises
        ------
        RuntimeError
            If Plot was created in standalone mode.
        """
        self._ensure_backend()
        # Reuse cached container if already created
        if hasattr(self, "_widget") and self._widget is not None:
            return self._widget

        if self._mode == "widget":
            return self._widget
        else:
            raise RuntimeError(f"While 'mode' is {self._mode}, widget attibute cannot be generated. Use 'widget' as mode argument!")

    @property
    def curves(self):
        """
        Returns the backend curves as a list.

        Returns
        -------
        List

        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "get_curve_list"
        })
        self._block(True)
        return self._curves
    
    @property
    def layout(self):
        """
        Returns the backend layout as a list of (title, (rows, cols)).

        Returns
        -------
        List

        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "get_layout"
        })
        self._block(True)
        return self._layout
    
    @contextmanager
    def batch_update(self):
        """
        Group multiple plotting commands into a single atomic backend update.

        All commands issued inside this context are buffered and sent to the
        backend as one batch. The backend executes them in order and emits
        exactly one completion signal.

        This significantly improves performance for large or frequent updates
        and guarantees visual consistency.

        Notes
        -----
        - Fully nestable.
        - Only the outermost context triggers execution.
        """
        self._ensure_backend()

        self._batch_depth += 1
        if self._batch_depth == 1:
            self._batch_buffer = []

        try:
            yield self
        finally:
            self._batch_depth -= 1

            # Only the outermost batch actually flushes
            if self._batch_depth == 0:
                msgs = self._batch_buffer or []
                self._batch_buffer = None

                if msgs:
                    payload = {
                        "cmd": "_batch",
                        "batch_id": str(uuid.uuid4()),
                        "messages": msgs,
                    }
                    # send as a single queue item
                    self._send_backend(payload)

                    # one block() for the whole batch
                    if self._blocks:
                        self._block()

    def _send_backend(self, cmd: dict):
        # If we're batching, buffer and return immediately
        if getattr(self, "_batch_depth", 0) > 0 and not cmd.get("cmd") == "get_curve_list":
            if self._batch_buffer is None:
                self._batch_buffer = []
            self._batch_buffer.append(cmd)
            return

        if self._started:
            try:
                self._tx_queue.put_nowait(cmd)
            except Exception:
                raise RuntimeError(
                    "Unexpected Backend error — the window may have been closed or crashed."
                )
        else:
            raise RuntimeError(
                "Plot backend is not running — the window may not be started at all, have been closed or crashed."
            )
        
    def _ensure_backend(self):
        """Start the plot process if not already started."""
        if not self._started:
            if self._mode == "standalone":
                ctx = multiprocessing.get_context("spawn")
                self._tx_queue = ctx.Queue()
                self._rx_queue = ctx.Queue()
                self._process = ctx.Process(
                    target=self._backend.worker,
                    args=(self._tx_queue, self._rx_queue),
                    daemon=False,
                )
                self._process.start()

            elif self._mode == "widget":
                self._tx_queue = queue.Queue()
                self._rx_queue = queue.Queue()

                self._backend.worker(self._tx_queue, self._rx_queue)
            else:
                raise ValueError(f"'mode' cannot be {self._mode}, use either 'standalone' or 'widget'.")
            
            start = time.time()
            while True:
                if not self._rx_queue.empty():
                    msg = self._rx_queue.get()
                    cmd = msg.get("cmd")
                    if cmd == "_ready":
                        if self._mode == "widget":
                            self._widget = msg.get("win")
                        break
                    elif cmd == "_error":
                        print(f"Backend error: {msg.get('error', 'unknown')}")
                        break
                if time.time() - start > self._initiation_timeout:
                    print(f"Backend did not report ready within {self._initiation_timeout} seconds which is set as initiation timeout.\nWaiting can be a solution but not gauranteed!")
                    break
                time.sleep(0.05)

            self._started = True
            threading.Thread(target=self._watch_backend, daemon=True).start()

    def _watch_backend(self):
        """Monitor backend messages like _closed or _error."""
        while self._started:
            try:
                # Handle both multiprocessing.Queue and queue.Queue
                if self._rx_queue:
                    try:
                        msg = self._rx_queue.get()
                    except Exception:
                        msg = None
                    if msg:
                        cmd = msg.get("cmd")
                        if cmd == "_closed":
                            self._close()
                            self._started = False
                            break
                        elif cmd == "_done":
                            self._done = True
                        elif cmd == "_error":
                            print(f"⚠️ Backend error: {msg.get('error', 'unknown')}")
                            break
                        elif cmd == "_curves":
                            self._curves = msg.get("curves")
                        elif cmd == "_layout":
                            self._layout = msg.get("layout")
                # Check thread/process liveness
                if self._mode == "standalone":
                    if not self._process or not self._process.is_alive():
                        print("⚠️ Backend process terminated unexpectedly.")
                        self.close()
                        self._started = False
                        break
                elif self._mode == "widget":
                    if self._process and not self._process.isRunning():
                        print("⚠️ Backend thread terminated unexpectedly.")
                        self.close()
                        self._started = False
                        break

            except Exception as e:
                print(f"[Plot] Watcher error: {e}")
                break

            time.sleep(0.01)
    
    def _block(self, force = False):
        # If we're batching, return immediately
        if getattr(self, "_batch_depth", 0) > 0 and not force:
            return True
        
        if self._blocks or force:
            self._done = False
            b_start = time.time()
            while time.time() - b_start < self._block_timeout:
                if self._done:
                    return True
                else:
                    time.sleep(0.01)
            return False
        return True

    def plot(self, ydata, xdata=None, row=0, col=0, name=None, pen=None):
        """
        Create a 2D line plot in the specified subplot.

        Parameters
        ----------
        ydata : array-like
            Y-axis data.
        xdata : array-like, optional
            X-axis data. If None, indices are used.
        row : int
            Subplot row index.
        col : int
            Subplot column index.
        name : str, optional
            Curve identifier. Auto-generated if omitted.
        pen : dict or pg.Pen, optional
            Line style description.

        Returns
        -------
        bool
            True if the command completed successfully.
        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "plot",
            "name": name,
            "ydata": ydata,
            "xdata": xdata,
            "pen": pen,
            "row": row,
            "col": col
        })
        return self._block()

    def update_plot(self, name, ydata, xdata=None):
        """
        Update an existing 2D line plot.

        Parameters
        ----------
        name : str
            Name of the curve to update.
        ydata : array-like
            New Y-axis data.
        xdata : array-like, optional
            New X-axis data.

        Returns
        -------
        bool
            True if update completed successfully.
        """
        self._send_backend({
            "cmd": "update",
            "name": name,
            "ydata": ydata,
            "xdata": xdata
        })
        return self._block()
    
    def plot_heatmap(self, data, x=None, y=None, row=0, col=0,
                    name=None, cmap="viridis", cbar=True):
        """
        Create a 2D heatmap.

        Parameters
        ----------
        data : 2D array-like
            Heatmap values.
        x : 1D array-like
            x values.
        y : 1D array-like
            y values.
        row : int
            Subplot row index.
        col : int
            Subplot column index.
        name : str, optional
            Heatmap identifier.
        cmap : str
            Colormap name.
        cbar : bool
            Whether to attach a colorbar.

        Returns
        -------
        bool
            True if creation succeeded.
        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "heatmap",
            "name": name,
            "data": data,
            "x": x,
            "y": y,
            "row": row,
            "col": col,
            "cmap": cmap,
            "cbar": cbar
        })
        return self._block()

    def update_heatmap(self, name, data, x=None, y=None):
        """
        Update an existing heatmap.

        Parameters
        ----------
        name : str
            Heatmap identifier.
        data : 2D array-like
            New heatmap values.
        x : 1D array-like
            x values.
        y : 1D array-like
            y values.

        Returns
        -------
        bool
            True if update succeeded.
        """
        self._send_backend({
            "cmd": "update_heatmap",
            "name": name,
            "data": data,
            "x": x,
            "y": y,
        })
        return self._block() 
    
    def plot_scatter2d(self, ydata, xdata, row=0, col=0,
                    name=None, size=8, color="#FF0000"):
        """
        Create a 2D scatter plot.

        Parameters
        ----------
        ydata : array-like
            Y coordinates.
        xdata : array-like
            X coordinates.
        row : int
            Subplot row index.
        col : int
            Subplot column index.
        name : str, optional
            Scatter identifier.
        size : float
            Marker size in pixels.
        color : str or tuple
            Marker color.

        Returns
        -------
        bool
            True if creation succeeded.
        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "scatter2d",
            "name": name,
            "xdata": xdata,
            "ydata": ydata,
            "size": size,
            "color": color,
            "row": row,
            "col": col
        })
        return self._block()

    def update_scatter2d(self, name, ydata=None, xdata=None,
                        size=None, color=None):
        """
        Update an existing 2D scatter plot.

        Parameters
        ----------
        name : str
            Scatter plot identifier.
        ydata : array-like, optional
            New Y data.
        xdata : array-like, optional
            New X data.
        size : float, optional
            New marker size.
        color : str or tuple, optional
            New marker color.

        Returns
        -------
        bool
            True if update succeeded.
        """
        self._send_backend({
            "cmd": "update_scatter2d",
            "name": name,
            "xdata": xdata,
            "ydata": ydata,
            "size": size,
            "color": color
        })
        return self._block()

    def plot_step(self, ydata, xdata, row=0, col=0, name=None, pen=None):
        """
        Create a step plot in the specified subplot.

        If xdata and ydata have equal length, the backend automatically
        appends one additional X value to satisfy step-plot requirements.

        Parameters
        ----------
        ydata : array-like
            Step heights.
        xdata : array-like
            Step boundaries.
        row : int
            Subplot row index.
        col : int
            Subplot column index.
        name : str, optional
            Curve identifier.
        pen : dict or pg.Pen, optional
            Line style.

        Returns
        -------
        bool
            True if creation succeeded.
        """
        self._ensure_backend()

        xdata = np.asarray(xdata)
        ydata = np.asarray(ydata)

        # -----------------------------
        # Fix invalid x length
        # -----------------------------
        if len(xdata) == len(ydata):
            warnings.warn((
                f"plot_step('{name}') received x,y of equal length "
                f"({len(xdata)}). Step plotting requires len(x)=len(y)+1. "
                f"Auto-appending last x point."
            ), RuntimeWarning)

            dx = xdata[-1] - xdata[-2] if len(xdata) > 1 else 1.0
            xdata = np.append(xdata, xdata[-1] + dx)

        self._send_backend({
            "cmd": "step",
            "name": name,
            "xdata": np.array(xdata),
            "ydata": np.array(ydata),
            "pen": pen,
            "row": row,
            "col": col
        })
        return self._block()

    def update_step(self, name, ydata=None, xdata=None):
        """
        Update an existing step line plot.

        Parameters
        ----------
        name : str
            Name of the curve to update.
        ydata : array-like
            New Y-axis data.
        xdata : array-like, optional
            New X-axis data.

        Returns
        -------
        bool
            True if update completed successfully.
        """
        return self.update_plot(name, ydata=ydata, xdata=xdata)
    
    def plot_bar(self, heights, xdata, row=0, col=0, name=None, width=0.8, color="c"):
        """Create a bar graph."""
        self._ensure_backend()
        self._send_backend({
            "cmd": "bar",
            "name": name,
            "x": xdata,
            "height": heights,
            "width": width,
            "color": color,
            "row": row,
            "col": col
        })
        return self._block()

    def update_bar(self, name, heights=None, x=None, width=None, color=None):
        """Update an existing BarGraphItem."""
        self._send_backend({
            "cmd": "update_bar",
            "name": name,
            "x": x,
            "height": heights,
            "width": width,
            "color": color
        })
        return self._block()

    def plot_infline(self, pos, orientation: Literal["horizontal", "vertical"], row=0, col=0, name=None, color="y"):
        """Create an infinite vertical line."""
        self._ensure_backend()
        self._send_backend({
            "cmd": "infline",
            "name": name,
            "pos": pos,
            "orientation": orientation,
            "color": color,
            "row": row,
            "col": col
        })
        return self._block()

    def update_hline(self, name, pos):
        """Move an existing InfiniteLine."""
        self._send_backend({
            "cmd": "update_vline",
            "name": name,
            "pos": pos
        })
        return self._block()

    def plot_region(self, range, row=0, col=0, name=None, color=(50, 100, 180, 80)):
        """Create a shaded region."""
        self._ensure_backend()
        self._send_backend({
            "cmd": "region",
            "name": name,
            "range": range,
            "color": color,
            "row": row,
            "col": col
        })
        return self._block()

    def update_region(self, name, range):
        """Update region boundaries."""
        self._send_backend({
            "cmd": "update_region",
            "name": name,
            "range": tuple(range)
        })
        return self._block()

    def plot_mesh3d(self, zdata, ydata=None, xdata=None,
                    row=0, col=0, name=None, cmap="viridis",
                    cbar=False, show_grid=True, show_axis=True,
                    draw_edges=False, smooth=False, compute_normals=False):
        """
        Create a 3D surface or mesh plot.

        Parameters
        ----------
        zdata : 2D array-like
            Surface height values.
        ydata : array-like, optional
            Y coordinates.
        xdata : array-like, optional
            X coordinates.
        row : int
            Subplot row index.
        col : int
            Subplot column index.
        name : str, optional
            Plot identifier.
        cmap : str
            Colormap name.
        cbar : bool
            Attach a colorbar.
        show_grid : bool
            Show 3D grid.
        show_axis : bool
            Show 3D axes.
        draw_edges : bool
            Render mesh edges.
        smooth : bool
            Enable smooth shading.
        compute_normals : bool
            Compute vertex normals.

        Returns
        -------
        bool
            True if creation succeeded.
        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "mesh3d",
            "name": name,
            "zdata": zdata,
            "xdata": xdata if xdata is not None else np.arange(zdata.shape[1]),
            "ydata": ydata if ydata is not None else np.arange(zdata.shape[0]),
            "row": row,
            "col": col,
            "cmap": cmap,
            "cbar": cbar,
            "show_grid": show_grid,
            "show_axis": show_axis,
            "draw_edges": draw_edges,
            "smooth": smooth,
            "compute_normals": compute_normals
        })
        return self._block()

    def update_mesh3d(self, name, zdata):
        """Update existing 3D surface mesh data."""
        self._send_backend({
            "cmd": "update_mesh3d",
            "name": name,
            "zdata": np.array(zdata)
        })
        return self._block()
    
    def plot_scatter3d(self, zdata, ydata, xdata,
                    row=0, col=0, name=None,
                    size=8.0, color="#FF0000",
                    cmap=None, cbar=False, c_values=None,
                    show_axis=True, show_grid=True, smooth=True):
        """
        Create a 3D scatter plot.

        Parameters
        ----------
        zdata : array-like
            Z coordinates.
        ydata : array-like
            Y coordinates.
        xdata : array-like
            X coordinates.
        row : int
            Subplot row index.
        col : int
            Subplot column index.
        name : str, optional
            Plot identifier.
        size : float
            Marker size.
        color : str or tuple
            Fixed marker color.
        cmap : str, optional
            Colormap for scalar coloring.
        cbar : bool
            Attach a colorbar.
        c_values : array-like, optional
            Values mapped to colormap.
        show_axis : bool
            Show 3D axes.
        show_grid : bool
            Show gridlines.
        smooth : bool
            Enable additive blending.

        Returns
        -------
        bool
            True if creation succeeded.
        """
        self._ensure_backend()
        self._send_backend({
            "cmd": "scatter3d",
            "name": name,
            "xdata": xdata,
            "ydata": ydata,
            "zdata": zdata,
            "row": row,
            "col": col,
            "color": color,
            "size": size,
            "smooth": smooth,
            "cmap": cmap,
            "c_values": c_values,
            "cbar": cbar,
            "show_axis": show_axis,
            "show_grid": show_grid,
        })
        return self._block()
    
    def update_scatter3d(self, name, zdata=None, ydata=None,
                        xdata=None, size=None, color=None,
                        cmap=None, c_values=None):
        """
        Update an existing 3D scatter plot.

        Parameters
        ----------
        name : str
            Plot identifier.
        zdata, ydata, xdata : array-like, optional
            New coordinates.
        size : float, optional
            New marker size.
        color : str or tuple, optional
            New fixed color.
        cmap : str, optional
            New colormap.
        c_values : array-like, optional
            New scalar values.

        Returns
        -------
        bool
            True if update succeeded.
        """
        self._send_backend({
            "cmd": "update_scatter3d",
            "name": name,
            "xdata": xdata,
            "ydata": ydata,
            "zdata": zdata,
            "c_values": c_values,
            "color": color,
            "size": size,
            "cmap": cmap,
        })
        return self._block()
    
    def plot_table(self, data, row=0, col=0, name=None, initial_sort=None, sort_order=None, row_height=None, col_width=None):
        self._ensure_backend()
        self._send_backend({
            "cmd": "table",
            "name": name,
            "row": row,
            "col": col,
            "data": data,
            "initial_sort": (initial_sort, sort_order),
            "row_height": row_height,
            "col_width": col_width
        })
        return self._block()

    def update_table(self, name, data):
        self._send_backend({
            "cmd": "update_table",
            "name": name,
            "data": data,
        })
        return self._block()

    def set_heatmap_levels(self, name, levels):
        """Fix colorbar/lookup levels for a heatmap: levels=(min_val, max_val)."""
        self._send_backend({"cmd": "set_heatmap_levels", "name": name, "levels": tuple(levels)})
        return self._block()

    def set_heatmap_labels(self, name, labels, color=None, size="10pt", bg_shape=None, bg_color=None, label_pos=None):
        """
        Overlay text labels (e.g., temperatures) on a heatmap.

        Parameters
        ----------
        name : str
            Heatmap name used in plot_heatmap().
        labels : 2D list or array
            Same shape as heatmap data if label_pos is not given if so labels and label_pos should be in the same shape. Each entry is converted to string.
        color : str, optional
            Text color override. If None, color is auto-selected for contrast.
        size : str or float, optional
            Font size (e.g. '10pt' or numeric value).
        bg_shape : str, optional
            Background shape for each label ('rect', 'circle', or None).
        bg_color : str or tuple, optional
            Background color (RGBA or color name). Defaults to white if bg_shape is given.
        label_pos : array_like, optional
            Optional array of custom label positions in the shape labels.
        """
        labels = np.array(labels).astype(str)
        if labels.size > 100:
            warnings.warn(f"When the number of labels exceeds 100 (currently {labels.size}), rendering performance may be significantly reduced depending on your system.", RuntimeWarning)
        self._send_backend({
            "cmd": "set_heatmap_labels",
            "name": name,
            "labels": labels.tolist(),
            "color": color,
            "size": size,
            "bg_shape": bg_shape,
            "bg_color": bg_color,
            "label_pos": np.array(label_pos).tolist() if label_pos is not None else None
        })
        return self._block()

    def clear_heatmap_labels(self, name):
        """
        Clear overlayed text labels (e.g., temperatures) on a heatmap.

        Parameters
        ----------
        name : str
            Heatmap name used in plot_heatmap().
        """
        
        self._send_backend({
            "cmd": "clear_heatmap_labels",
            "name": name,
        })
        return self._block()

    def set_figure_title(self, title):
        """Change the main figure (window) title."""
        self._send_backend({"cmd": "set_figure_title", "title": title})
        return self._block()

    def set_subplot_title(self, title, row=0, col=0):
        """Change the title of a specific subplot."""
        self._send_backend({"cmd": "set_subplot_title", "row": row, "col": col, "title": title})
        return self._block()

    def set_axis_labels(self, xlabel=None, ylabel=None, zlabel=None, row=None, col=None):
        """Change axis labels of a subplot."""
        self._send_backend({
            "cmd": "set_axis_labels",
            "row": row,
            "col": col,
            "xlabel": xlabel,
            "ylabel": ylabel,
            "zlabel": zlabel
        })
        return self._block()

    def show_legend(self, show=True, row=None, col=None):
        """Show or hide legend for a subplot."""
        self._send_backend({
            "cmd": "set_legend_visibility",
            "row": row,
            "col": col,
            "show": show
        })
        return self._block()  
    
    def enable_hover(self, enabled=True):
        """Enable or disable hover info (data cursor) tool."""
        self._send_backend({"cmd": "hover_enable", "enable": enabled})
        return self._block()

    def set_hover_info(self, name, info, per_point=False):
        """
        Attach hover metadata to a curve or to individual points.

        Parameters
        ----------
        name : str
            Curve or heatmap name.
        info : str | array
            Info to add to the the tooltip, could be either a single variable or an array (one per point, first axis is the y and second axis is the x).
        per_point : bool
            If True, 'info' must be an array matching data length/shape.
        """
        self._send_backend({
            "cmd": "set_hover_info",
            "name": name,
            "info": info,
            "per_point": per_point
        })
        return self._block()

    def set_style(self, profile: PlotStyleProfile):
        """
        Apply global styling to all plots, axes, gridlines, legends,
        hover labels, and 3D axes.

        Example:
            p.set_style(PlotStyleProfile.midnight_blue())
        """
        self._send_backend({
            "cmd": "apply_style",
            "style": profile.data,
        })

        if self._blocks:
            return self._block()
        return True

    def set_3d_projection(self, projection: Literal["Frustum", "Orthographic"] = "Orthographic", row=None, col=None):
        self._send_backend({
            "cmd": "set_3d_projection",
            "projection": projection,
        })

        if self._blocks:
            return self._block()
        return True
    
    def allow_close(self, allowed=True):
        """Enable/disable close button and prompt."""
        self._send_backend({"cmd": "set_close_enabled", "enabled": allowed})
        return self._block()

    def clear(self):
        """
        Clear plot contents.s

        Returns
        -------
        bool
            True if clear operation completed.
        """
        self._send_backend({"cmd": "clear"})
        return self._block()
    
    def save(
        self,
        path: str,
        *,
        target: str = "figure",
        row: int | None = None,
        col: int | None = None,
        format: str | None = None,
        dpi: int | None = None,
        transparent: bool = False,
        preset: str | None = None,
        save_state: bool = False,
        bundle: bool = False,
    ):
        """
        Save the current plot, subplot, or full export bundle to disk.

        This is the unified export interface for all raster, vector, state,
        and bundled exports. The operation is dispatched to the backend and
        executed asynchronously if async saving is enabled.

        Parameters
        ----------
        path : str
            Output file path. The file extension may be inferred from this if
            `format` is not explicitly provided.

        target : {"figure", "subplot"}, optional, keyword-only
            Export target:
            - "figure": Export the full plot window (default)
            - "subplot": Export a single subplot defined by (`row`, `col`)

        row : int, optional, keyword-only
            Subplot row index (required if target="subplot").

        col : int, optional, keyword-only
            Subplot column index (required if target="subplot").

        format : {"png", "jpg", "svg", "pdf"}, optional, keyword-only
            Output format. If omitted, it is inferred from `path`.

            - PNG/JPG → Raster output
            - SVG/PDF → Vector output

        dpi : int, optional, keyword-only
            Raster resolution in dots-per-inch. Applies to PNG/JPG outputs.
            If None, backend defaults are used.

        transparent : bool, optional, keyword-only
            If True, exports PNG images with a transparent background.
            Ignored for vector formats.

        preset : {"publication", "presentation", "web"}, optional, keyword-only
            Apply a visual styling preset before exporting.

        save_state : bool, optional, keyword-only
            If True, also saves the full plot state as a JSON file next to
            the exported file.

        bundle : bool, optional, keyword-only
            If True, saves a full export bundle as a ZIP archive containing:
            - Raster and vector exports
            - Plot state JSON
            - All metadata

        Returns
        -------
        bool
            True if the export operation was dispatched successfully.
            If blocking mode is enabled, this reflects backend completion.

        Notes
        -----
        - This method unifies all legacy export helpers:
        `save_png`, `save_pdf`, `save_svg`, `save_state`, and `save_bundle`.
        - When `target="subplot"`, both `row` and `col` must be provided.
        - When `bundle=True`, `format`, `dpi`, and `transparent` are ignored.
        """


        # Auto-detect file format if not given
        if format is None:
            ext = path.split(".")[-1].lower()
            format = ext

        # Apply preset before saving (optional)
        if preset is not None:
            self.apply_preset(preset)

        # ZIP bundle export
        if bundle:
            self._send_backend({"cmd": "save_bundle", "path": path})
            return self._block()

        # JSON state export
        if save_state:
            self._send_backend({"cmd": "save_state", "path": path})
            return self._block()

        # ---- VECTOR FORMATS ----
        if format in ("pdf", "svg"):
            msg = {
                "cmd": "save_vector",
                "target": target,
                "format": format,
                "path": path
            }
            if target == "subplot":
                msg["row"] = row
                msg["col"] = col

            self._send_backend(msg)
            return self._block()

        # ---- RASTER FORMATS (PNG, JPG) ----
        if format in ("png", "jpg", "jpeg"):
            msg = {
                "cmd": "save",
                "target": target,
                "path": path,
            }

            if dpi is not None:
                msg["dpi"] = int(dpi)
            if transparent is not None:
                msg["transparent"] = bool(transparent)

            if target == "subplot":
                msg["row"] = row
                msg["col"] = col

            self._send_backend(msg)
            return self._block()

        raise ValueError(f"Unsupported format: {format}")

    def load_state(self, path: str):
        """
        Restore figure from JSON state.
        """
        self._send_backend({
            "cmd": "load_state",
            "path": path
        })
        return self._block()

    def apply_preset(self, preset_name: str):
        """
        Apply display/export preset: 'publication', 'presentation', 'web'
        """
        self._send_backend({
            "cmd": "apply_preset",
            "preset": preset_name,
        })
        return self._block()

    def set_annotation(self, 
                       text: str, 
                       anchor: Literal["BottomLeft", "BottomRight", "Topleft", "TopRight", "Center"] = "Center", 
                       offset: tuple[int, int] = (0, 0), 
                       style: dict = {
                                "font_size": 7,
                                "bold": True,
                                "bg_color": (0, 0, 0, 180),
                                "text_color": "#D0D0D0",
                                "border_radius": 8,
                                "padding": (6, 10, 6, 10),
                            }
                        ):
        self._send_backend({
            "cmd": "set_annotation", 
            "text": text,
            "anchor": anchor,
            "offset": offset,
            "style": style
        })
        return self._block()
    
    def remove_annotation(self,
                          anchor: Literal["BottomLeft", "BottomRight", "Topleft", "TopRight", "Center"] = "Center", 
                          offset: tuple[int, int] = (0, 0)
                          ):
        self._send_backend({
            "cmd": "remove_annotation",
            "anchor": anchor,
            "offset": offset
        })
        return self._block()
    
    def set_axis_tick_rotation(self,
                               axis: Literal["x", "y", "both"] = "x",
                               angle: float = 0,
                               anchor: Literal["left", "right", "center"] = "center",
                               row = None, 
                               col = None
                               ):
        self._send_backend({
            "cmd": "tick_rotation",
            "axis": axis,
            "angle": angle,
            "anchor": anchor,
            "row": row,
            "col": col
        })
        return self._block()

    def show_grid(self,
                  axis: Literal["x", "y", "both"] = "both",
                  alpha: float = 0.3,
                  row = None,
                  col = None
                ):
        self._send_backend({
            "cmd": "show_grid",
            "axis": axis,
            "alpha": alpha,
            "row": row,
            "col": col
        })
        return self._block()

    def set_layout(self,
                  rows = None,
                  cols = None,
                  title = None
                ):
        self._send_backend({
            "cmd": "set_layout",
            "rows": rows,
            "cols": cols,
            "title": title
        })
        return self._block()
    
    def _close(self):
        if self._process.is_alive():
            try:
                self._process.terminate()
                self._process.join()
            except Exception:
                pass

        for qname in ("_tx_queue", "_rx_queue"):
            q = getattr(self, qname, None)
            if q is not None:
                try:
                    q.close()          # closes pipe endpoints
                    q.join_thread()    # waits for feeder thread
                    q = None
                except Exception:
                    pass
                setattr(self, qname, None)

        try:
            self._process.terminate()
            self._process.join()
        except Exception:
            pass
        self._process = None
        self._started = False

    def close(self):
        """
        Gracefully close the plot and terminate the backend.

        Sends a close command to the backend and releases all
        associated resources.
        """
        if not self._process:
            return
    
        self._send_backend({"cmd": "trigger_close"})
        self._block()

        

