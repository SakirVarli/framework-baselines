from __future__ import annotations

import re
from pathlib import Path

from PyQt5 import QtCore, QtWidgets

from app.branding import SHORT_NAME
from app.exporter import create_baseline_package
from app.upgrade_manager import (
    INSTALLED_MANIFEST,
    STATE_DIRNAME,
    PackageError,
    compare_package,
    inspect_archive,
    prepare_upgrade,
)
from app.utils import PROJECT_ROOT


class AppVersionDialog(QtWidgets.QDialog):
    def __init__(self, parent, version: str, notes: str):
        super().__init__(parent)
        self.setWindowTitle("Set App Version")
        self.resize(560, 420)
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()
        self.version = QtWidgets.QLineEdit(version or "")
        self.notes = QtWidgets.QPlainTextEdit(notes or "")
        self.notes.setPlaceholderText("Changes in this application version…")
        form.addRow("MAJOR.MINOR.PATCH:", self.version)
        form.addRow("Version release notes:", self.notes)
        layout.addLayout(form)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def accept(self):
        if not re.fullmatch(r"\d+\.\d+\.\d+", self.version.text().strip()):
            QtWidgets.QMessageBox.warning(
                self, "Invalid Version",
                "Version must be in MAJOR.MINOR.PATCH format, for example 1.4.2."
            )
            return
        super().accept()


class BaselineExportWizard(QtWidgets.QWizard):
    def __init__(self, parent, baseline_number: int, version: str, build):
        super().__init__(parent)
        self.setWindowTitle("Export Baseline")
        self.setWizardStyle(QtWidgets.QWizard.ModernStyle)
        self.resize(720, 560)
        self.export_result: dict[str, str] | None = None
        self._app_version = str(version or "")
        self._app_build = build

        release_page = QtWidgets.QWizardPage()
        release_page.setTitle("Release information")
        release_page.setSubTitle("Describe this baseline for users who install or upgrade to it.")
        form = QtWidgets.QFormLayout(release_page)
        self.baseline = QtWidgets.QSpinBox()
        self.baseline.setRange(0, 999999)
        self.baseline.setValue(int(baseline_number))
        self.title = QtWidgets.QLineEdit(f"Baseline {baseline_number}")
        self.summary = QtWidgets.QLineEdit()
        self.notes = QtWidgets.QPlainTextEdit()
        self.notes.setPlaceholderText("What changed, migration advice, known limitations…")
        self.minimum = QtWidgets.QSpinBox()
        self.minimum.setRange(-1, 999999)
        self.minimum.setSpecialValueText("No minimum")
        self.minimum.setValue(-1)
        form.addRow("Baseline number:", self.baseline)
        form.addRow("Release title:", self.title)
        form.addRow("Summary:", self.summary)
        form.addRow("Minimum baseline:", self.minimum)
        form.addRow("Release notes:", self.notes)
        self.addPage(release_page)

        output_page = QtWidgets.QWizardPage()
        output_page.setTitle("Package output")
        output_page.setSubTitle("ZIP is the installable upgrade package. A folder is useful for inspection.")
        output_layout = QtWidgets.QVBoxLayout(output_page)
        destination_row = QtWidgets.QHBoxLayout()
        self.destination = QtWidgets.QLineEdit(PROJECT_ROOT)
        browse = QtWidgets.QPushButton("Browse…")
        browse.clicked.connect(self._browse_destination)
        destination_row.addWidget(self.destination, 1)
        destination_row.addWidget(browse)
        output_layout.addWidget(QtWidgets.QLabel("Destination folder:"))
        output_layout.addLayout(destination_row)
        self.output_mode = QtWidgets.QComboBox()
        self.output_mode.addItem("ZIP archive (recommended)", "zip")
        self.output_mode.addItem("Uncompressed folder", "folder")
        self.output_mode.addItem("ZIP archive and folder", "both")
        output_layout.addSpacing(12)
        output_layout.addWidget(QtWidgets.QLabel("Output format:"))
        output_layout.addWidget(self.output_mode)
        output_layout.addStretch(1)
        self.addPage(output_page)

        review_page = QtWidgets.QWizardPage()
        review_page.setTitle("Review")
        review_page.setSubTitle("The package will be created and verified before the baseline counter advances.")
        review_layout = QtWidgets.QVBoxLayout(review_page)
        self.review = QtWidgets.QTextBrowser()
        review_layout.addWidget(self.review)
        self.addPage(review_page)
        self.currentIdChanged.connect(self._refresh_review)

    def _browse_destination(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Baseline Export Folder", self.destination.text() or PROJECT_ROOT
        )
        if path:
            self.destination.setText(path)

    def _refresh_review(self, page_id: int):
        if page_id != 2:
            return
        mode = self.output_mode.currentText()
        minimum = "None" if self.minimum.value() < 0 else str(self.minimum.value())
        self.review.setPlainText(
            f"Baseline: {self.baseline.value()}\n"
            f"Title: {self.title.text()}\n"
            f"Minimum baseline: {minimum}\n"
            f"Output: {mode}\n"
            f"Destination: {self.destination.text()}\n\n"
            f"Summary:\n{self.summary.text()}\n\nRelease notes:\n{self.notes.toPlainText()}"
        )

    def validateCurrentPage(self) -> bool:
        if self.currentId() == 0 and not self.title.text().strip():
            QtWidgets.QMessageBox.warning(self, "Release title required", "Enter a release title.")
            return False
        if self.currentId() == 1:
            destination = Path(self.destination.text().strip())
            if not destination.is_dir():
                QtWidgets.QMessageBox.warning(self, "Invalid destination", "Select an existing destination folder.")
                return False
        return super().validateCurrentPage()

    def accept(self):
        try:
            self.export_result = create_baseline_package(
                self.destination.text().strip(),
                self.baseline.value(),
                version=self._app_version,
                build=self._app_build,
                title=self.title.text().strip(),
                summary=self.summary.text().strip(),
                notes=self.notes.toPlainText().strip(),
                minimum_baseline=None if self.minimum.value() < 0 else self.minimum.value(),
                output_mode=self.output_mode.currentData(),
            )
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Baseline Export Failed", str(exc))
            return
        super().accept()


class UpgradeWizard(QtWidgets.QWizard):
    upgrade_prepared = QtCore.pyqtSignal(str)

    def __init__(self, parent, current_baseline: int):
        super().__init__(parent)
        self.setWindowTitle(f"Upgrade {SHORT_NAME} GUI")
        self.setWizardStyle(QtWidgets.QWizard.ModernStyle)
        self.resize(860, 620)
        self.current_baseline = int(current_baseline)
        self.manifest = None
        self.comparison = []
        self.plan_path: Path | None = None

        select_page = QtWidgets.QWizardPage()
        select_page.setTitle("Select baseline package")
        select_page.setSubTitle("Choose a zipped baseline export. The complete payload will be verified.")
        select_layout = QtWidgets.QVBoxLayout(select_page)
        row = QtWidgets.QHBoxLayout()
        self.archive = QtWidgets.QLineEdit()
        browse = QtWidgets.QPushButton("Browse…")
        browse.clicked.connect(self._browse_archive)
        row.addWidget(self.archive, 1)
        row.addWidget(browse)
        select_layout.addWidget(QtWidgets.QLabel("Baseline ZIP:"))
        select_layout.addLayout(row)
        self.validation_message = QtWidgets.QLabel()
        self.validation_message.setWordWrap(True)
        select_layout.addWidget(self.validation_message)
        select_layout.addStretch(1)
        self.addPage(select_page)

        release_page = QtWidgets.QWizardPage()
        release_page.setTitle("Release notes")
        release_layout = QtWidgets.QVBoxLayout(release_page)
        self.release_heading = QtWidgets.QLabel()
        self.release_heading.setWordWrap(True)
        self.release_notes = QtWidgets.QTextBrowser()
        release_layout.addWidget(self.release_heading)
        release_layout.addWidget(self.release_notes, 1)
        self.addPage(release_page)

        options_page = QtWidgets.QWizardPage()
        options_page.setTitle("Selective upgrade")
        options_page.setSubTitle("Modified and user-owned files are preserved unless you explicitly select them.")
        options_layout = QtWidgets.QVBoxLayout(options_page)
        self.upgrade_baseline_number = QtWidgets.QCheckBox("Upgrade baseline number")
        self.upgrade_baseline_number.setChecked(True)
        self.upgrade_version = QtWidgets.QCheckBox("Upgrade application version to the baseline value")
        self.upgrade_build = QtWidgets.QCheckBox("Upgrade build number to the baseline value")
        self.replace_core = QtWidgets.QCheckBox("Replace locally modified core framework files")
        self.replace_callbacks = QtWidgets.QCheckBox("Replace locally modified callbacks.py")
        self.replace_externals = QtWidgets.QCheckBox("Replace locally modified files under externals")
        self.replace_data = QtWidgets.QCheckBox("Replace app/data JSON files (advanced)")
        for checkbox in (
            self.upgrade_baseline_number, self.upgrade_version, self.upgrade_build,
            self.replace_core, self.replace_callbacks, self.replace_externals,
            self.replace_data,
        ):
            options_layout.addWidget(checkbox)
            checkbox.toggled.connect(self._populate_comparison)
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["File", "Category", "Detected state", "Planned action"])
        self.tree.setRootIsDecorated(False)
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setStretchLastSection(True)
        options_layout.addWidget(self.tree, 1)
        self.addPage(options_page)

        review_page = QtWidgets.QWizardPage()
        review_page.setTitle("Ready to upgrade")
        review_page.setSubTitle("A backup and transactional plan will be created before the application closes.")
        review_layout = QtWidgets.QVBoxLayout(review_page)
        self.review = QtWidgets.QTextBrowser()
        review_layout.addWidget(self.review)
        self.addPage(review_page)
        self.currentIdChanged.connect(self._page_changed)

    def _browse_archive(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select Baseline Upgrade Package", PROJECT_ROOT, "ZIP archives (*.zip)"
        )
        if path:
            self.archive.setText(path)

    def _options(self) -> dict[str, bool]:
        return {
            "upgrade_baseline_number": self.upgrade_baseline_number.isChecked(),
            "upgrade_version": self.upgrade_version.isChecked(),
            "upgrade_build": self.upgrade_build.isChecked(),
            "replace_core": self.replace_core.isChecked(),
            "replace_callbacks": self.replace_callbacks.isChecked(),
            "replace_externals": self.replace_externals.isChecked(),
            "replace_user_data": self.replace_data.isChecked(),
            "replace_user_data_category": self.replace_data.isChecked(),
        }

    def validateCurrentPage(self) -> bool:
        if self.currentId() == 0:
            try:
                self.manifest = inspect_archive(self.archive.text().strip(), verify_payload=True)
                minimum = self.manifest["release"].get("minimum_baseline")
                if minimum is not None and self.current_baseline < int(minimum):
                    raise PackageError(
                        f"This release requires baseline {minimum} or later; the installed baseline is {self.current_baseline}."
                    )
                self.comparison = compare_package(Path(PROJECT_ROOT), self.manifest)
                self.validation_message.setText("Package validation passed.")
                target = int(self.manifest["release"]["baseline_number"])
                if target <= self.current_baseline:
                    answer = QtWidgets.QMessageBox.warning(
                        self, "Same or Older Baseline",
                        f"The package baseline is {target}, while the current baseline is {self.current_baseline}. "
                        "Continuing may reinstall or downgrade files. Continue?",
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                        QtWidgets.QMessageBox.No,
                    )
                    if answer != QtWidgets.QMessageBox.Yes:
                        return False
                if not (Path(PROJECT_ROOT) / STATE_DIRNAME / INSTALLED_MANIFEST).is_file():
                    QtWidgets.QMessageBox.information(
                        self, "Legacy Installation",
                        "This installation has no previous baseline manifest. Existing differing files will be "
                        "treated as unknown and preserved unless you explicitly select their category."
                    )
            except Exception as exc:
                self.validation_message.setText(str(exc))
                QtWidgets.QMessageBox.critical(self, "Invalid Baseline Package", str(exc))
                return False
        return super().validateCurrentPage()

    def _page_changed(self, page_id: int):
        if not self.manifest:
            return
        release = self.manifest["release"]
        if page_id == 1:
            baseline_label = f"Baseline {release.get('baseline_number')}"
            release_title = str(release.get("title") or "").strip()
            heading = baseline_label
            if release_title and release_title.casefold() != baseline_label.casefold():
                heading = f"{release_title}<br>{baseline_label}"
            self.release_heading.setText(
                f"<b>{heading}</b><br><br>"
                f"{release.get('summary', '')}"
            )
            self.release_notes.setPlainText(release.get("notes", "") or "No detailed release notes were supplied.")
        elif page_id == 2:
            self._populate_comparison()
        elif page_id == 3:
            counts: dict[str, int] = {}
            for item in self.comparison:
                counts[item["status"]] = counts.get(item["status"], 0) + 1
            self.review.setPlainText(
                f"Current baseline: {self.current_baseline}\n"
                f"Target baseline: {release.get('baseline_number')}\n\n"
                + "Detected files:\n"
                + "\n".join(f"  {key}: {value}" for key, value in sorted(counts.items()))
                + "\n\nModified and unknown files remain preserved unless their category was selected. "
                "The application will close, create a backup, apply the upgrade, and restart."
            )

    def _populate_comparison(self):
        self.tree.clear()
        options = self._options()
        for item in self.comparison:
            category, status = item["category"], item["status"]
            if item["path"] == "app/data/config.json":
                selected = []
                if options["upgrade_baseline_number"]:
                    selected.append("baseline number")
                if options["upgrade_version"]:
                    selected.append("version")
                if options["upgrade_build"]:
                    selected.append("build")
                action = "Upgrade " + ", ".join(selected) if selected else "Preserve"
                if options["replace_user_data"]:
                    action = "Replace (preserving phase)"
            elif status == "same":
                action = "Already current"
            elif category == "user_data" and not options["replace_user_data"]:
                action = "Preserve"
            elif status in {"new", "unchanged"}:
                action = "Install"
            elif options.get(f"replace_{category}", False):
                action = "Replace by request"
            else:
                action = "Preserve"
            QtWidgets.QTreeWidgetItem(
                self.tree, [item["path"], category.replace("_", " "), status, action]
            )
        for column in range(3):
            self.tree.resizeColumnToContents(column)

    def accept(self):
        try:
            self.plan_path, details = prepare_upgrade(
                self.archive.text().strip(), PROJECT_ROOT, self._options()
            )
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Could Not Prepare Upgrade", str(exc))
            return
        if not details["plan"]["operations"]:
            QtWidgets.QMessageBox.information(self, "Nothing to Upgrade", "No files or metadata were selected for upgrade.")
            return
        super().accept()
