import time
import datetime
from PyQt5 import QtCore, QtWidgets, QtGui

class InfoWidget(QtWidgets.QFrame):
    """
    Thread-safe InfoWidget with stopwatch, progress bar, dock/undock,
    auto-scroll, context menu, and log output.
    """
    _sig_action = QtCore.pyqtSignal(str, object, object)  # func_name, args, kwargs

    def __init__(self, instance: str, orientation="horizontal",
                 bg_color=None, fg_color=None, font=None,
                 width=None, height=None, visible=True, dockable=True,
                 parent=None):
        super().__init__(parent)
        self.setObjectName("InfoWidgetOuter")
        self.instance = instance
        self.orientation = orientation.lower()
        self._bg_color = bg_color if bg_color else "#f8f9fa"
        self._fg_color = fg_color if fg_color else "#020202"
        self._font = font
        self._width = width
        self._height = height
        self._start_time = None
        self._total_steps = None
        self._current_step = 0
        self._force_auto_scroll = False
        self.dockable = dockable
        self._docked = True
        self._state = "reset"
        self._tqdm_ctx = None
        self._min_interval = 0.01
        self._last_ui_update = 0.0
        self._last_eta_step = 0
        self._last_eta_ts = None
        self._eta_rate = None   # steps/sec
        self._eta_anchor = None       # seconds at last progress update
        self._eta_anchor_ts = None    # monotonic timestamp
        self._pending_parent_visibility = None

        self._init_ui()
        self._init_timer()
        self._apply_default_style()
        if self.parentWidget() is None:
            # A parentless QWidget is a top-level window. Remember the
            # configured state instead of briefly showing a Python window
            # before the runtime or designer has inserted us into a layout.
            self._pending_parent_visibility = bool(visible)
            self.hide()
        else:
            self.setVisible(bool(visible))
        self._sig_action.connect(self._safe_action, QtCore.Qt.QueuedConnection)
            
        self.set_size(self._width, self._height)

        self._internal_widgets = [
            self.state_label,
            self.time_label,
            self.progress_label,
            self.eta_label,
            self.progress,
        ]

        self._hide_internal()

    def event(self, event):
        result = super().event(event)
        if (
            event.type() == QtCore.QEvent.ParentChange
            and self.parentWidget() is not None
            and self._pending_parent_visibility is not None
        ):
            visible = self._pending_parent_visibility
            self._pending_parent_visibility = None
            self.setVisible(visible)
        return result

    # ======================================================
    # Thread-safe dispatcher
    # ======================================================
    def invoke_safe(self, func_name: str, *args, **kwargs):
        """Public entry for thread-safe UI updates."""
        self._sig_action.emit(func_name, args, kwargs)

    @QtCore.pyqtSlot(str, object, object)
    def _safe_action(self, func_name, args, kwargs):
        try:
            func = getattr(self, func_name, None)
            if func:
                func(*args, **(kwargs or {}))
        except Exception as e:
            raise RuntimeError(f"[InfoWidget:{self.instance}] Error in {func_name}: {e}")

    # ======================================================
    # UI Initialization
    # ======================================================
    def _init_ui(self):
        self.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.setFrameShadow(QtWidgets.QFrame.Raised)

        self.time_label = QtWidgets.QLabel("Elapsed: 00:00")

        self.progress = QtWidgets.QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress_label = QtWidgets.QLabel("Progress: 0%")
        self.eta_label = QtWidgets.QLabel("ETA: --:--")
        self.state_label = QtWidgets.QLabel("")

        self.output_area = QtWidgets.QPlainTextEdit()
        self.output_area.setReadOnly(True)
        self.output_area.setMaximumBlockCount(2000)
        self.output_area.setLineWrapMode(QtWidgets.QPlainTextEdit.WidgetWidth)

        for w in (
            self.state_label,
            self.time_label,
            self.progress_label,
            self.eta_label,
            self.progress,
            self.output_area
        ):
            w.setProperty("cls", "inner")

        # Context menu handling
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._context_menu)
        for child in (self.state_label, self.time_label, self.progress_label,
                      self.progress, self.eta_label, self.output_area):
            child.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            child.customContextMenuRequested.connect(self._context_menu)

        if self.orientation == "horizontal":
            self._init_horizontal_layout()
        else:
            self._init_vertical_layout()

    def _init_vertical_layout(self):
        header = QtWidgets.QHBoxLayout()
        header.setContentsMargins(0,0,0,0)
        header.addWidget(self.state_label)
        header.addWidget(self.time_label)

        prog = QtWidgets.QHBoxLayout()
        prog.setContentsMargins(0,0,0,0)
        prog.addWidget(self.progress_label)
        prog.addWidget(self.eta_label)
        
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        layout.addLayout(header)
        layout.addLayout(prog)
        layout.addWidget(self.progress)
        layout.addWidget(self.output_area)

    def _init_horizontal_layout(self):
        main = QtWidgets.QHBoxLayout(self)
        main.setContentsMargins(0,0,0,0)
        left = QtWidgets.QVBoxLayout()
        left.setContentsMargins(0,0,0,0)
        left.addWidget(self.state_label)
        left.addWidget(self.time_label)
        left.addWidget(self.progress_label)
        left.addWidget(self.eta_label)
        right = QtWidgets.QVBoxLayout()
        right.setContentsMargins(0,0,0,0)
        right.addWidget(self.progress)
        right.addWidget(self.output_area)
        main.addLayout(left)
        main.addLayout(right)

    def _init_timer(self):
        self._timer = QtCore.QTimer()
        self._timer.timeout.connect(self._update_time)

    # ======================================================
    # Style & Size
    # ======================================================
    def _apply_default_style(self):
        self.set_style(self._bg_color, self._fg_color, self._font)

    def set_style(self, bg_color=None, fg_color=None, font=None):
        if bg_color:
            self._bg_color = bg_color
        if fg_color:
            self._fg_color = fg_color
        if font:
            self._font = font

        css = f"""
        #InfoWidgetOuter {{
            background-color: {self._bg_color};
        }}

        /* Apply borders ONLY to inner widgets */
        *[cls="inner"] {{
            border: 1px solid #dddddd;
            padding: 1px;
        }}
        QLabel, QPlainTextEdit {{
            color: {self._fg_color};
            background-color: {self._bg_color};
        }}
        """

        self.setStyleSheet(css)

        if font:
            qfont = QtGui.QFont(font)
            for w in [self.state_label, self.time_label, self.progress_label,
                    self.eta_label, self.output_area]:
                w.setFont(qfont)

    def set_size(self, width=None, height=None):
        if width and height:
            self.setFixedSize(width, height)
        elif width:
            self.setFixedWidth(width)
        elif height:
            self.setFixedHeight(height)

    # ======================================================
    # Stopwatch / Progress
    # ======================================================
    def start(self):
        self._start_time = time.time()
        self._timer.start(500)
        self.set_state("running")
        self._show_internal([0, 1])

    def stop(self):
        self._timer.stop()
        if not self.get_state() in ["done", "failed", "aborted"]:
            self.set_state("done")
        self._update_time()

    def reset(self):
        self._timer.stop()
        self._start_time = None
        self._current_step = 0
        self.progress.setValue(0)
        self.progress_label.setText("Progress: 0%")
        self.eta_label.setText("ETA: --:--")
        self.time_label.setText("Elapsed: 00:00")
        self.set_state("reset")
        self._hide_internal()
    
    def clear(self):
        self.output_area.clear()

    def _update_time(self):
        if not self._start_time:
            return
        elapsed = int(time.time() - self._start_time)
        m, s = divmod(elapsed, 60)
        self.time_label.setText(f"Elapsed: {m:02d}:{s:02d}")

        now = time.monotonic()
        if self._total_steps and self._current_step > 0:

            # -------------------------------------------------
            # Re-anchor ETA when progress changes
            # -------------------------------------------------
            if self._current_step != self._last_eta_step:
                if self._last_eta_ts is not None:
                    dt = now - self._last_eta_ts
                    ds = self._current_step - self._last_eta_step

                    if dt > 0 and ds > 0:
                        inst_rate = ds / dt

                        # EMA smoothing of rate
                        if self._eta_rate is None:
                            self._eta_rate = inst_rate
                        else:
                            self._eta_rate = 0.3 * inst_rate + 0.7 * self._eta_rate

                self._last_eta_ts = now
                self._last_eta_step = self._current_step

                # 🔑 Compute anchored ETA (seconds)
                if self._eta_rate and self._eta_rate > 0:
                    remaining_steps = max(self._total_steps - self._current_step, 0)
                    self._eta_anchor = remaining_steps / self._eta_rate
                    self._eta_anchor_ts = now

            # -------------------------------------------------
            # Smooth countdown between steps
            # -------------------------------------------------
            if self._eta_anchor is not None and self._eta_anchor_ts is not None:
                remaining = self._eta_anchor - (now - self._eta_anchor_ts)
                remaining = max(remaining, 0.0)

                rm, rs = divmod(int(remaining + 0.5), 60)
                self.eta_label.setText(f"ETA: {rm:02d}:{rs:02d}")
            else:
                self.eta_label.setText(f"ETA: Calculating" + "." * (s % 3 + 1))
        else:
            self.eta_label.setText(f"ETA: Calculating" + "." * (s % 3 + 1))

    def set_progress(self, value, total=None):
        if self._tqdm_ctx is not None and not getattr(self._tqdm_ctx, "_active", False):
            raise RuntimeError(
                f"InfoWidget '{self.instance}' has a tqdm context that was never started. "
                f"Use 'with info.tqdm(...)' or 'for x in info.tqdm(...)'."
            )

        if total is not None:
            self._total_steps = total

        if not self._total_steps:
            self._total_steps = 100

        if self._tqdm_ctx is not None:
            self._current_step += value
        else:
            self._current_step = value

        if self._current_step > self._total_steps:
            self._current_step = self._total_steps

        finished = (
            self._tqdm_ctx is not None
            and self._current_step >= self._total_steps
        )

        now = time.monotonic()
        ui_due = (now - self._last_ui_update) >= self._min_interval

        if ui_due or finished:
            self._last_ui_update = now
            self._show_internal([2, 3, 4])

            percent = int((self._current_step / self._total_steps) * 100)
            self.progress.setValue(percent)
            self.progress_label.setText(f"Progress: {percent}%")

    # ======================================================
    # Text / Logging
    # ======================================================
    def _save_scroll_state(self):
        sb = self.output_area.verticalScrollBar()
        state = {
            "value": sb.value(),
            "maximum": sb.maximum(),
            "at_bottom": sb.value() >= sb.maximum() - 1,
        }
        return state

    def _restore_scroll_state(self, state):
        sb = self.output_area.verticalScrollBar()
        if state["at_bottom"]:
            sb.setValue(sb.maximum())
        else:
            sb.setValue(min(state["value"], sb.maximum()))

    def set_text(self, msg, popup=False, append=True, level="info"):
        if not append:
            self.output_area.clear()
        ts = time.strftime("[%H:%M:%S]")
        color = {
            "info": self._fg_color, "print": self._fg_color, "warning": "#ffaa00",
            "error": "#ff5555", "success": "#00cc66"
        }.get(level, self._fg_color)
        scroll_state = self._save_scroll_state()
        self.output_area.appendHtml(f'<span style="color:{color}">{ts} {msg}</span>')
        self._restore_scroll_state(scroll_state)
        if popup:
            icon = {
                "info": QtWidgets.QMessageBox.Information,
                "warning": QtWidgets.QMessageBox.Warning,
                "error": QtWidgets.QMessageBox.Critical,
                "success": QtWidgets.QMessageBox.Information,
            }[level]
            QtWidgets.QMessageBox(icon, "Message", msg).exec_()

    # ======================================================
    # State Handling
    # ======================================================
    def set_state(self, state, colored=True):
        self._state = state
        if colored:
            colors = {
                "reset": "#555555",
                "waiting": "#E7D535",
                "running": "#3daee9",
                "done": "#00cc66",
                "failed": "#cc2e2e",
                "aborted": "#E2A739",
            }
            self.progress.setStyleSheet(f"""
            QProgressBar::chunk {{
                background-color: {colors.get(state, "#555555")}
            }}
            """)
        self.state_label.setText(state.title())

    def get_state(self):
        return self._state
    
    def tqdm(self, iterable=None, total=None, desc=None):
        if self._tqdm_ctx is not None:
            raise RuntimeError(
                f"InfoWidget '{self.instance}' already has an active tqdm context, for inner loops do not use tqdm context."
            )
        return InfoTQDM(self, iterable=iterable, total=total, desc=desc)

    def finalize_tqdm(self):
        self.stop()
        self._tqdm_ctx._active = False
        self._tqdm_ctx = None
        
    # ======================================================
    # Dock / Utility / Menu
    # ======================================================
    def _context_menu(self, pos):
        menu = QtWidgets.QMenu(self)
        if self.dockable:
            menu.addAction("Undock" if self._docked else "Dock",
                           self._undock if self._docked else self._dock)
        menu.addSeparator()
        menu.addAction("Auto Scroll", self._auto_scroll)
        menu.addAction("Reset", self.reset)
        menu.addAction("Clear", self.clear)
        menu.addAction("Save to File", self._save_to_file)
        menu.exec_(self.mapToGlobal(pos))

    def _auto_scroll(self):
        self._force_auto_scroll = True

    def _save_to_file(self):
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        default = f"{self.instance}_{datetime.datetime.now():%Y%m%d_%H%M%S}"
        text = self.output_area.toPlainText()
        if not text.strip():
            QMessageBox.information(self, "Save", "No text to save.")
            return
        fn, _ = QFileDialog.getSaveFileName(self, "Save Output", default, "Text Files (*.txt)")
        if fn:
            try:
                with open(fn, "w", encoding="utf-8") as f:
                    f.write(text)
                QMessageBox.information(self, "Saved", f"Text saved to {fn}")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def _undock(self):
        if not self.dockable or not self._docked:
            return

        parent = self.parentWidget()
        if parent:
            self._original_parent = parent

            # Try to remember the layout + exact grid position, if any
            layout = parent.layout()
            self._original_layout = layout
            self._original_pos = None  # (row, col, rowSpan, colSpan) or None
            definition_getter = getattr(layout, "widgetDefinition", None)
            self._original_canvas_definition = (
                definition_getter(self) if callable(definition_getter) else None)

            if isinstance(layout, QtWidgets.QGridLayout):
                # Safer: iterate over all items and use getItemPosition()
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget() is self:
                        r, c, rs, cs = layout.getItemPosition(i)
                        self._original_pos = (r, c, rs, cs)
                        break

        # Create floating dialog
        self._float = QtWidgets.QDialog(parent=self.window())
        self._float.setWindowTitle(f"{self.instance} (Undocked)")
        self._float.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        self._float.resize(600, 400)

        # Re-parent into dialog
        self.setParent(None)
        fl = QtWidgets.QVBoxLayout(self._float)
        fl.setContentsMargins(0, 0, 0, 0)
        fl.addWidget(self)

        # Expand freely in the floating dialog
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding,
                           QtWidgets.QSizePolicy.Expanding)
        self.setMinimumSize(0, 0)
        self.setMaximumSize(16777215, 16777215)

        self._float.show()
        self._docked = False
        self._float.finished.connect(self._dock)


    def _dock(self):
        if self._docked:
            return

        parent = getattr(self, "_original_parent", None)
        layout = None

        if parent is not None:
            layout = parent.layout()
            # Re-parent back
            self.setParent(parent)

            pos = getattr(self, "_original_pos", None)

            if isinstance(layout, QtWidgets.QGridLayout) and pos is not None:
                r, c, rs, cs = pos
                layout.addWidget(self, r, c, rs, cs)
            elif (
                getattr(self, "_original_canvas_definition", None) is not None
                and hasattr(layout, "addWidgetDefinition")
            ):
                layout.addWidgetDefinition(
                    self, self._original_canvas_definition)
            else:
                # Fallback: just add to layout (for non-grid layouts)
                layout.addWidget(self)

            layout.activate()
            parent.update()

        # Clean up floating dialog if it still exists
        if hasattr(self, "_float") and self._float:
            self._float.deleteLater()
            self._float = None

        self._docked = True

        # Restore original fixed size, if any
        self.set_size(self._width, self._height)

    # ======================================================
    # Visibility & Access
    # ======================================================
    def show_widget(self):
        self._pending_parent_visibility = True
        self.show()

    def hide_widget(self):
        self._pending_parent_visibility = False
        self.hide()

    def container(self):
        return self

    def _show_internal(self, idx = None):
        state = self._save_scroll_state()
        if idx is not None:
            if isinstance(idx, int):
                idx = [idx]
            for w in idx:
                if not self._internal_widgets[w].isVisible():
                    self._internal_widgets[w].show()
        else:
            for w in self._internal_widgets:
                if not w.isVisible():
                    w.show()
        
        self._restore_scroll_state(state)

    def _hide_internal(self):
        for w in self._internal_widgets:
            w.hide()
        

class InfoTQDM:
    def __init__(self, info: InfoWidget, iterable=None, total=None, desc=None):
        self.info = info
        self.iterable = iterable
        self.total = total if total is not None else (
            len(iterable) if iterable is not None else None
        )
        self.iter = 0
        self.desc = desc
        self._active = False

    # --------------------------------------------------
    def __enter__(self):
        if self.info._tqdm_ctx is not None:
            raise RuntimeError(
                f"InfoWidget '{self.info.instance}' already has an active tqdm"
            )

        self.info._tqdm_ctx = self
        self._active = True

        self.info.invoke_safe("reset")
        self.info.invoke_safe("start")

        if self.desc:
            self.info.invoke_safe("set_state", self.desc, False)

        if self.total is not None:
            self.info.invoke_safe("set_progress", 0, self.total)

        return self

    def __exit__(self, exc_type, exc, tb):
        if not self._active:
            return

        if exc:
            self.info.invoke_safe("set_text", str(exc), level="error")
            self.info.invoke_safe("set_state", "failed")
        else:
            # ✅ Respect existing terminal state
            if self.iter != self.total:
                self.info.invoke_safe("set_state", "aborted")
            else:
                self.info.invoke_safe("set_state", "done")

        self.info.invoke_safe("finalize_tqdm")

    # --------------------------------------------------
    def __iter__(self):
        if self.iterable is None:
            raise TypeError("InfoTQDM object is not iterable")

        self.__enter__()
        try:
            for item in self.iterable:
                yield item
                self.info.invoke_safe("set_progress", 1)
                self.iter += 1
        finally:
            self.__exit__(None, None, None)

# =========================================================
# Thread-safe InfoRegistry
# =========================================================
class InfoRegistry:
    def __init__(self, window):
        self.window = window
        self._by_instance = {}

    def register(self, info: InfoWidget):
        self._by_instance[info.instance] = info

    def clear_registry(self):
        """Forget widgets from the previous layout without invoking their public clear action."""
        self._by_instance.clear()

    def route_prints(self, tab, instance_name):
        """
        Allow user to call route_prints() with either:
            - tab index (int)
            - tab name (string)

        Examples:
            route_prints(0, "console")
            route_prints("Main", "console")
        """

        tab_index = self._resolve_tab_index(tab)
        if tab_index is None:
            raise KeyError(f"Tab not found: {tab}")

        if instance_name not in self._by_instance:
            raise KeyError(f"Unknown InfoWidget instance: {instance_name}")

        # Forward to redirector
        if not self._print_redirector.installed:
            self._print_redirector.install()

        self._print_redirector.route(tab_index, instance_name)
    
    def _resolve_tab_index(self, tab):
        """
        Convert tab index or tab name → numeric index.
        Returns None if not found.
        """
        from PyQt5 import QtWidgets

        # 1. Already an index
        if isinstance(tab, int):
            return tab

        # 2. Tab name → find matching tab
        win = self.window
        if not hasattr(win, "tabs") or not isinstance(win.tabs, QtWidgets.QTabWidget):
            return None

        tabs = win.tabs
        for i in range(tabs.count()):
            if tabs.tabText(i).strip().lower() == str(tab).strip().lower():
                return i

        return None  # not found

    def _get(self, instance):
        if '/' in instance:
            instance = instance.split('/')[-1]
        info = self._by_instance.get(instance)
        if not info:
            QtCore.QTimer.singleShot(0, lambda: QtWidgets.QMessageBox.warning(
                self.window, 'Info', f'Unknown info widget: {instance}'
            ))
            return None
        return info

    # Thread-safe wrappers
    def start(self, instance): 
        if (w := self._get(instance)): w.invoke_safe("start")

    def stop(self, instance): 
        if (w := self._get(instance)): w.invoke_safe("stop")

    def reset(self, instance): 
        if (w := self._get(instance)): w.invoke_safe("reset")

    def clear(self, instance): 
        if (w := self._get(instance)): w.invoke_safe("clear")

    def show(self, instance): 
        if (w := self._get(instance)): w.invoke_safe("show_widget")

    def hide(self, instance): 
        if (w := self._get(instance)): w.invoke_safe("hide_widget")

    def set_progress(self, instance, value, total=None): 
        if (w := self._get(instance)): w.invoke_safe("set_progress", value, total)

    def set_text(self, instance, msg, popup=False, append=True, level="info"): 
        if (w := self._get(instance)): w.invoke_safe("set_text", msg, popup, append, level)

    def set_state(self, instance, state): 
        if (w := self._get(instance)): w.invoke_safe("set_state", state)

    def tqdm(self, instance, iterable=None, total=None, desc=None):
        if (w:=self._get(instance)): return w.tqdm(iterable=iterable, total=total, desc=desc)


