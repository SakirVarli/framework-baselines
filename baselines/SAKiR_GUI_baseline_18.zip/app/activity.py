"""Working phrases and animation for the Designer console."""

WORKING_PHRASES = [
    "Thinking it through",
    "Working on your request",
    "Putting things together",
    "Considering the details",
    "Working through it",
    "Taking a closer look",
    "Connecting the dots",
    "Making sense of it",
]

ACTIVITY_ANIMATION = [
    (".   .", 0.14),
    (" ~ ~ ", 0.14),
    (" s s ", 0.14),
    ("  §  ", 0.14),
    ("  S  ", 0.30),
    ("  §  ", 0.14),
    (" s s ", 0.14),
    (" ~ ~ ", 0.14),
]
