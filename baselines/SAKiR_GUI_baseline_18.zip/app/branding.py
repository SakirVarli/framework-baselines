from __future__ import annotations

import json
import re
import sys
import unicodedata
from dataclasses import dataclass
from pathlib import Path


def _project_root() -> Path:
    if getattr(sys, "frozen", False):
        executable_dir = Path(sys.executable).resolve().parent
        for internal_name in ("_internal", "_internals"):
            internal_dir = executable_dir / internal_name
            if internal_dir.is_dir():
                return internal_dir
        return executable_dir
    return Path(__file__).resolve().parent.parent


BRANDING_PATH = _project_root() / "app" / "data" / "branding.json"


@dataclass(frozen=True)
class Branding:
    short_name: str
    full_name: str


def load_branding(path: str | Path = BRANDING_PATH) -> Branding:
    branding_path = Path(path)
    try:
        value = json.loads(branding_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Cannot load internal branding metadata from {branding_path}: {exc}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"Internal branding metadata in {branding_path} must be a JSON object.")

    fields: dict[str, str] = {}
    for key in ("short_name", "full_name"):
        field = value.get(key)
        if not isinstance(field, str) or not field.strip():
            raise RuntimeError(
                f"Internal branding metadata field {key!r} must be a non-empty string."
            )
        fields[key] = field.strip()
    return Branding(**fields)


BRANDING = load_branding()
SHORT_NAME = BRANDING.short_name
FULL_NAME = BRANDING.full_name


def expand_branding(value: str) -> str:
    return str(value).replace("{short_name}", SHORT_NAME).replace(
        "{full_name}", FULL_NAME
    )


def filename_short_name() -> str:
    component = re.sub(r"[^\w.-]+", "_", SHORT_NAME, flags=re.UNICODE).strip("._")
    return component or "project"


def _ascii_identifier(value: str, separator: str, uppercase: bool = False) -> str:
    ascii_value = (
        unicodedata.normalize("NFKD", str(value))
        .encode("ascii", "ignore")
        .decode("ascii")
    )
    component = re.sub(r"[^A-Za-z0-9]+", separator, ascii_value).strip(separator)
    component = component or "project"
    return component.upper() if uppercase else component.lower()


def identifier_slug(value: str = SHORT_NAME) -> str:
    return _ascii_identifier(value, "-")


def environment_prefix(value: str = SHORT_NAME) -> str:
    return _ascii_identifier(value, "_", uppercase=True)


def environment_name(suffix: str) -> str:
    return f"{environment_prefix()}_{_ascii_identifier(suffix, '_', uppercase=True)}"


def application_id(component: str) -> str:
    return f"com.{identifier_slug()}.{identifier_slug(component)}"


def mime_type(component: str) -> str:
    return f"application/x-{identifier_slug()}-{identifier_slug(component)}"
