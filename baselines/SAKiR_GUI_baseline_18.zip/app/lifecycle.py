"""Owner-scoped lifecycle registration for startup, reload, and shutdown."""

from __future__ import annotations

import contextvars
import inspect
import itertools
from dataclasses import dataclass
from threading import RLock
from typing import Any, Callable, Dict, Iterable, Optional


LIFECYCLE_STAGES = ("startup", "unload", "reload", "close")


@dataclass(frozen=True)
class HookRecord:
    stage: str
    priority: int
    order: int
    owner: str
    key: str
    callback: Callable[..., Any]


class LifecycleRegistration:
    """A staged owner registration committed only after module validation."""

    def __init__(self, manager: "_LifecycleManager", owner: str):
        self.manager = manager
        self.owner = owner
        self.records: list[HookRecord] = []
        self.committed = False
        self._token = None

    def __enter__(self) -> "LifecycleRegistration":
        self._token = self.manager._active_registration.set(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self._token is not None:
            self.manager._active_registration.reset(self._token)
            self._token = None
        return False

    def add(self, record: HookRecord) -> None:
        # A second declaration with the same stable identity replaces the first.
        self.records[:] = [
            existing for existing in self.records
            if not (existing.stage == record.stage and existing.key == record.key)
        ]
        self.records.append(record)

    def for_stage(self, stage: str) -> list[HookRecord]:
        stage = self.manager.validate_stage(stage)
        return self.manager.sort_records(
            record for record in self.records if record.stage == stage
        )

    def commit(self) -> None:
        if not self.committed:
            self.manager.commit(self)
            self.committed = True


class _LifecycleManager:
    def __init__(self) -> None:
        self._lock = RLock()
        self._records: Dict[str, list[HookRecord]] = {
            stage: [] for stage in LIFECYCLE_STAGES
        }
        self._orders = itertools.count()
        self._active_registration: contextvars.ContextVar[
            LifecycleRegistration | None
        ] = contextvars.ContextVar("lifecycle_registration", default=None)

    @staticmethod
    def validate_stage(stage: str) -> str:
        stage = str(stage).lower().strip()
        if stage not in LIFECYCLE_STAGES:
            raise ValueError(
                f"Invalid lifecycle stage {stage!r}; expected one of {LIFECYCLE_STAGES}."
            )
        return stage

    @staticmethod
    def sort_records(records: Iterable[HookRecord]) -> list[HookRecord]:
        return sorted(records, key=lambda record: (-record.priority, record.order))

    def registration_scope(self, owner: str) -> LifecycleRegistration:
        owner = str(owner or "").strip()
        if not owner:
            raise ValueError("Lifecycle registration owner must be non-empty")
        return LifecycleRegistration(self, owner)

    def commit(self, registration: LifecycleRegistration) -> None:
        """Atomically replace every hook belonging to one owner."""
        with self._lock:
            for stage in LIFECYCLE_STAGES:
                retained = [
                    record for record in self._records[stage]
                    if record.owner != registration.owner
                ]
                incoming = [
                    record for record in registration.records
                    if record.stage == stage
                ]
                self._records[stage] = self.sort_records(retained + incoming)

    def _discard_owner(self, owner: str) -> None:
        with self._lock:
            for stage in LIFECYCLE_STAGES:
                self._records[stage] = [
                    record for record in self._records[stage]
                    if record.owner != owner
                ]

    def records(self, stage: str) -> list[HookRecord]:
        stage = self.validate_stage(stage)
        with self._lock:
            records = list(self._records[stage])
        return self.sort_records(records)

    def _register(
        self, stage: str, func: Callable[..., Any], priority: int
    ) -> Callable[..., Any]:
        stage = self.validate_stage(stage)
        if not callable(func):
            raise TypeError("Lifecycle hook must be callable")
        active = self._active_registration.get()
        owner = active.owner if active is not None else str(
            getattr(func, "__module__", "runtime") or "runtime"
        )
        key = str(
            getattr(func, "__qualname__", getattr(func, "__name__", repr(func)))
        )
        record = HookRecord(
            stage=stage,
            priority=int(priority),
            order=next(self._orders),
            owner=owner,
            key=key,
            callback=func,
        )
        if active is not None:
            active.add(record)
        else:
            with self._lock:
                self._records[stage] = [
                    existing for existing in self._records[stage]
                    if not (existing.owner == owner and existing.key == key)
                ]
                self._records[stage].append(record)
                self._records[stage] = self.sort_records(self._records[stage])
        return func

    def _decorator(self, stage: str, func=None, *, priority: int = 0):
        if func is None:
            return lambda callback: self._register(stage, callback, priority)
        return self._register(stage, func, priority)

    def on_startup(self, func=None, *, priority: int = 0):
        return self._decorator("startup", func, priority=priority)

    def on_unload(self, func=None, *, priority: int = 0):
        return self._decorator("unload", func, priority=priority)

    def on_reload(self, func=None, *, priority: int = 0):
        return self._decorator("reload", func, priority=priority)

    def on_close(self, func=None, *, priority: int = 0):
        return self._decorator("close", func, priority=priority)

    @staticmethod
    def invoke(record: HookRecord, *args: Any) -> Any:
        """Invoke a hook using signature-aware positional argument binding."""
        callback = record.callback
        try:
            signature = inspect.signature(callback)
        except (TypeError, ValueError):
            return callback(*args)
        parameters = list(signature.parameters.values())
        if any(parameter.kind == parameter.VAR_POSITIONAL for parameter in parameters):
            return callback(*args)
        positional = [
            parameter for parameter in parameters
            if parameter.kind in (
                parameter.POSITIONAL_ONLY,
                parameter.POSITIONAL_OR_KEYWORD,
            )
        ]
        required = [
            parameter for parameter in positional
            if parameter.default is parameter.empty
        ]
        if len(required) > len(args):
            raise TypeError(
                f"Lifecycle hook {record.key!r} requires {len(required)} positional "
                f"argument(s), but the {record.stage} stage provides {len(args)}."
            )
        return callback(*args[:len(positional)])

    def __repr__(self) -> str:
        counts = ", ".join(
            f"{stage}={len(self.records(stage))}" for stage in LIFECYCLE_STAGES
        )
        return f"<LifecycleManager {counts}>"


LifecycleManager = _LifecycleManager()


__all__ = [
    "HookRecord", "LifecycleManager", "LifecycleRegistration", "LIFECYCLE_STAGES"
]
