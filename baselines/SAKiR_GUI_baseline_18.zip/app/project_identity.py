from __future__ import annotations

import json
import sys
import uuid
from pathlib import Path


def _project_root() -> Path:
    if getattr(sys, "frozen", False):
        executable_dir = Path(sys.executable).resolve().parent
        for internal_name in ("_internal", "_internals"):
            internal_dir = executable_dir / internal_name
            if internal_dir.is_dir():
                return internal_dir
        return executable_dir
    return Path(__file__).resolve().parent.parent


PRODUCT_IDENTITY_PATH = (
    _project_root() / "app" / "data" / "product_identity.json"
)


def load_baseline_family_id(
    path: str | Path = PRODUCT_IDENTITY_PATH,
) -> str:
    identity_path = Path(path)
    try:
        value = json.loads(identity_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(
            f"Cannot load internal product identity from {identity_path}: {exc}"
        ) from exc
    if not isinstance(value, dict):
        raise RuntimeError(
            f"Internal product identity in {identity_path} must be a JSON object."
        )

    family_id = value.get("baseline_family_id")
    if not isinstance(family_id, str):
        raise RuntimeError(
            "Internal product identity field 'baseline_family_id' must be a UUID string."
        )
    try:
        parsed = uuid.UUID(family_id)
    except (ValueError, AttributeError) as exc:
        raise RuntimeError(
            "Internal product identity field 'baseline_family_id' must be a valid UUID."
        ) from exc
    canonical = str(parsed)
    if family_id != canonical:
        raise RuntimeError(
            "Internal product identity field 'baseline_family_id' must use canonical lowercase UUID format."
        )
    return canonical


BASELINE_FAMILY_ID = load_baseline_family_id()
