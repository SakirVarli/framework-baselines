"""Callback-facing APIs for the built-in connection tools.

``Tools`` is a stable singleton.  Tool windows may be created, destroyed, or
reloaded without changing the object imported by callbacks.  Normal API calls
are routed to the Qt GUI thread; ``raw`` properties intentionally expose the
underlying third-party objects for advanced use.
"""

from __future__ import annotations

import threading
import weakref
import copy
import uuid
from pathlib import Path
from dataclasses import dataclass
from typing import Any, Callable, Generic, Optional, TypeVar

from PyQt5 import QtCore


class ToolUnavailableError(RuntimeError):
    pass


_T = TypeVar("_T")


class ToolCallFuture(Generic[_T]):
    """Small thread-safe future used by owner-thread connection calls."""

    def __init__(self):
        self._event = threading.Event()
        self._result = None
        self._error: Optional[BaseException] = None

    def set_result(self, value=None):
        self._result = value
        self._event.set()

    def set_exception(self, error: BaseException):
        self._error = error
        self._event.set()

    def done(self) -> bool:
        return self._event.is_set()

    def result(self, timeout: Optional[float] = None):
        if not self._event.wait(timeout):
            raise TimeoutError("Tool operation timed out")
        if self._error is not None:
            raise self._error
        return self._result


@dataclass
class _GuiRequest:
    func: Callable[[], Any]
    future: ToolCallFuture


class _GuiDispatcher(QtCore.QObject):
    requested = QtCore.pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.requested.connect(self._execute, QtCore.Qt.QueuedConnection)

    @QtCore.pyqtSlot(object)
    def _execute(self, request: _GuiRequest):
        try:
            request.future.set_result(request.func())
        except BaseException as error:
            request.future.set_exception(error)


class ToolSubscription:
    def __init__(self, registry: "ToolRegistry", signal, callback):
        self._registry = registry
        self._signal = signal
        self._callback = callback
        self._active = True

    def unsubscribe(self):
        if not self._active:
            return
        try:
            self._registry.call_gui(lambda: self._signal.disconnect(self._callback))
        except (TypeError, RuntimeError):
            pass
        self._active = False

    close = unsubscribe


class ToolRegistry:
    def __init__(self):
        self._lock = threading.RLock()
        self._widgets: dict[str, weakref.ReferenceType] = {}
        self._openers: dict[str, Callable[[], Any]] = {}
        self._acquirers: dict[str, Callable[[], Any]] = {}
        self._dispatcher: Optional[_GuiDispatcher] = None
        self._gui_thread = None
        self._shutting_down = False

    def bind(
        self,
        openers: dict[str, Callable[[], Any]],
        acquirers: Optional[dict[str, Callable[[], Any]]] = None,
    ):
        app = QtCore.QCoreApplication.instance()
        if app is None:
            raise RuntimeError("QApplication must exist before binding Tools")
        with self._lock:
            self._openers = dict(openers)
            self._acquirers = dict(acquirers or {})
            self._gui_thread = app.thread()
            if self._dispatcher is None:
                self._dispatcher = _GuiDispatcher()
                self._dispatcher.moveToThread(self._gui_thread)
            self._shutting_down = False

    def call_gui(self, func: Callable[[], Any], timeout: Optional[float] = 30):
        dispatcher = self._dispatcher
        if dispatcher is None:
            raise ToolUnavailableError("Tools API is not bound to the application")
        if QtCore.QThread.currentThread() == self._gui_thread:
            return func()
        future = ToolCallFuture()
        dispatcher.requested.emit(_GuiRequest(func, future))
        return future.result(timeout)

    def register(self, name: str, widget):
        with self._lock:
            self._widgets[name] = weakref.ref(widget)

        def clear(*_):
            with self._lock:
                ref = self._widgets.get(name)
                if ref is not None and ref() is widget:
                    self._widgets.pop(name, None)

        widget.destroyed.connect(clear)
        return widget

    def get(self, name: str, create: bool = False):
        with self._lock:
            ref = self._widgets.get(name)
            widget = ref() if ref is not None else None
            opener = self._openers.get(name)
            shutting_down = self._shutting_down
        if widget is not None:
            return widget
        if not create:
            return None
        if shutting_down:
            raise ToolUnavailableError("Application shutdown is in progress")
        if opener is None:
            raise ToolUnavailableError(f"Tool '{name}' has no registered opener")
        widget = self.call_gui(opener)
        if widget is None:
            raise ToolUnavailableError(f"Tool '{name}' could not be opened")
        return widget

    def acquire(self, name: str):
        """Return a shared tool owner without requiring its window to be shown."""
        with self._lock:
            ref = self._widgets.get(name)
            widget = ref() if ref is not None else None
            acquirer = self._acquirers.get(name)
            shutting_down = self._shutting_down
        if widget is not None:
            return widget
        if shutting_down:
            raise ToolUnavailableError("Application shutdown is in progress")
        if acquirer is None:
            return self.get(name, create=True)
        widget = self.call_gui(acquirer)
        if widget is None:
            raise ToolUnavailableError(f"Tool '{name}' could not be acquired")
        return widget

    def open(self, name: str):
        """Display a tool, reattaching an invisibly acquired owner when needed."""
        with self._lock:
            opener = self._openers.get(name)
            shutting_down = self._shutting_down
        if shutting_down:
            raise ToolUnavailableError("Application shutdown is in progress")
        if opener is None:
            return self.get(name, create=True)
        widget = self.call_gui(opener)
        if widget is None:
            raise ToolUnavailableError(f"Tool '{name}' could not be opened")
        return widget

    def begin_shutdown(self):
        with self._lock:
            self._shutting_down = True


class _ToolAPI:
    key = ""

    def __init__(self, registry: ToolRegistry):
        self._registry = registry

    @property
    def widget(self):
        return self._registry.get(self.key, create=False)

    @property
    def available(self) -> bool:
        return self.widget is not None

    def open(self):
        return self._registry.open(self.key)

    show = open

    def close(self):
        widget = self.widget
        if widget is not None:
            return self._registry.call_gui(widget.close)

    def _gui(self, func: Callable[[], Any], timeout: Optional[float] = 30):
        return self._registry.call_gui(func, timeout)

    def _require(self):
        return self._registry.get(self.key, create=True)

    def subscribe(self, signal_name: str, callback: Callable):
        widget = self._require()
        signal = getattr(widget, signal_name)
        self._gui(lambda: signal.connect(callback))
        return ToolSubscription(self._registry, signal, callback)


class FTPClientAPI(_ToolAPI):
    key = "ftp_client"

    @property
    def backend(self):
        widget = self.widget
        return getattr(widget, "backend", None) if widget else None

    @property
    def raw(self):
        backend = self.backend
        return getattr(backend, "ftp", None) if backend else None

    @property
    def connected(self) -> bool:
        return self.raw is not None

    @property
    def cwd(self) -> Optional[str]:
        widget = self.widget
        return getattr(widget, "_remote_cwd", None) if widget else None

    def connect(self, host: str, port: int = 21, user: str = "anonymous", password: str = ""):
        widget = self._require()
        def apply_settings():
            widget.host_edit.setText(host)
            widget.port_edit.setText(str(port))
            widget.user_edit.setText(user)
            widget.pass_edit.setText(password)
            widget._save_settings()
        self._gui(apply_settings)
        return widget.backend.submit(
            lambda obj: obj.connect_to(host, int(port), user, password)
        )

    def disconnect(self):
        backend = self.backend
        if backend is not None:
            return backend.submit(lambda obj: obj.disconnect())

    def run_raw_async(self, func: Callable[[Any], Any]) -> ToolCallFuture:
        backend = self.backend
        if backend is None:
            raise ToolUnavailableError("FTP client is not open")
        return backend.submit(lambda obj: func(obj.ftp))

    def run_raw(self, func: Callable[[Any], Any], timeout: Optional[float] = 30):
        return self.run_raw_async(func).result(timeout)

    def _backend_call(self, name, *args):
        backend = self.backend
        if backend is None:
            raise ToolUnavailableError("FTP client is not open")
        return backend.submit(lambda obj: getattr(obj, name)(*args))

    def subscribe(self, signal_name: str, callback: Callable):
        backend = self.backend
        if backend is None:
            self.open()
            backend = self.backend
        signal = getattr(backend, signal_name)
        self._gui(lambda: signal.connect(callback))
        return ToolSubscription(self._registry, signal, callback)

    def listdir(self, path: str = ".", timeout: Optional[float] = 30):
        def operation(ftp):
            current = ftp.pwd()
            try:
                ftp.cwd(path)
                try:
                    return list(ftp.mlsd())
                except (AttributeError, OSError):
                    return ftp.nlst()
            finally:
                ftp.cwd(current)
        return self.run_raw(operation, timeout)

    def mkdir(self, path: str): return self.run_raw_async(lambda ftp: ftp.mkd(path))
    def delete(self, path: str): return self.run_raw_async(lambda ftp: ftp.delete(path))
    def rmdir(self, path: str): return self.run_raw_async(lambda ftp: ftp.rmd(path))
    def rename(self, source: str, destination: str):
        return self.run_raw_async(lambda ftp: ftp.rename(source, destination))
    def cancel(self, job_id: int): return self._backend_call("cancel_job", int(job_id))

    def navigate(self, path: str):
        widget = self._require()
        return self._gui(lambda: widget._remote_set_cwd(path))

    def refresh(self):
        widget = self._require()
        return self._gui(widget._remote_refresh_root)

    def jobs(self):
        widget = self.widget
        if widget is None:
            return []
        return self._gui(lambda: [item for item, _progress in widget._jobs.values()])

    def upload(self, local_paths, remote_directory: Optional[str] = None):
        widget = self._require()
        paths = [str(p) for p in ([local_paths] if isinstance(local_paths, (str, bytes)) else local_paths)]
        def enqueue():
            before = set(widget._jobs)
            widget._enqueue_upload_from_paths(paths, remote_base=remote_directory)
            return sorted(set(widget._jobs) - before)
        return self._gui(enqueue)

    def download(self, remote_items: list[dict], local_directory: Optional[str] = None):
        widget = self._require()
        def enqueue():
            before = set(widget._jobs)
            if local_directory is None:
                widget._download_items_to_current_local(remote_items)
            else:
                widget._download_items_to_local_dir(remote_items, str(local_directory))
            return sorted(set(widget._jobs) - before)
        return self._gui(enqueue)

    def delete_local(self, paths):
        widget = self._require()
        values = [str(p) for p in ([paths] if isinstance(paths, (str, bytes)) else paths)]
        return self._gui(lambda: widget._delete_local_paths(values))

    def open_local_in_explorer(self, path: str):
        widget = self._require()
        return self._gui(lambda: widget._open_in_explorer(str(path)))


class FTPServerAPI(_ToolAPI):
    key = "ftp_server"

    @property
    def thread(self):
        widget = self.widget
        return getattr(widget, "_server_thread", None) if widget else None

    @property
    def raw(self):
        thread = self.thread
        return getattr(thread, "_server", None) if thread else None

    @property
    def authorizer(self):
        widget = self.widget
        return getattr(widget, "_authorizer", None) if widget else None

    @property
    def running(self) -> bool:
        thread = self.thread
        return bool(thread and thread.is_running())

    def start(self, host: Optional[str] = None, port: Optional[int] = None):
        widget = self._require()
        def start():
            if host is not None: widget.host_edit.setText(host)
            if port is not None: widget.port_edit.setText(str(port))
            widget.start_server(confirm_port_owner=False)
        return self._gui(start)

    def stop(self, confirm: bool = False):
        widget = self.widget
        if widget is not None:
            return self._gui(lambda: widget.stop_server(confirm=confirm))

    def add_user(self, username, password, home, permissions="elradfmwMT", home_relative=False):
        widget = self._require()
        return self._gui(lambda: widget.add_user(username, password, home, permissions, home_relative))

    def remove_user(self, username: str):
        widget = self._require()
        return self._gui(lambda: widget.remove_user(username))

    def update_user(self, username, *, new_username=None, password, home,
                    permissions="elradfmwMT", home_relative=False):
        widget = self._require()
        def update():
            if not widget.remove_user(username):
                raise KeyError(f"FTP user '{username}' does not exist")
            return widget.add_user(
                new_username or username, password, home, permissions, home_relative
            )
        return self._gui(update)

    def users(self):
        widget = self._require()
        return self._gui(widget.list_users)

    def sessions(self):
        thread = self.thread
        return thread.snapshot() if thread else []

    def logs(self):
        widget = self.widget
        return self._gui(lambda: list(widget.log_widget._entries)) if widget else []

    def clear_logs(self):
        widget = self.widget
        if widget:
            return self._gui(widget.log_widget.clear)

    def run_raw_async(self, func: Callable[[Any], Any]):
        future = ToolCallFuture()
        thread = self.thread
        if thread is None:
            future.set_exception(ToolUnavailableError("FTP server is not running"))
        else:
            thread.submit(lambda: func(thread._server), future)
        return future

    def run_raw(self, func, timeout: Optional[float] = 30):
        return self.run_raw_async(func).result(timeout)


class _SessionAPI:
    def __init__(self, registry: ToolRegistry, session):
        self._registry = registry
        self._ref = weakref.ref(session)

    @property
    def widget(self):
        value = self._ref()
        if value is None:
            raise ToolUnavailableError("The session has been closed")
        return value

    @property
    def name(self): return self.widget.session_name
    @property
    def connected(self): return self.widget.is_connected()
    def settings(self): return self._registry.call_gui(self.widget.to_settings)
    def disconnect(self): raise NotImplementedError

    def subscribe(self, signal_name, callback):
        signal = getattr(self.widget, signal_name)
        self._registry.call_gui(lambda: signal.connect(callback))
        return ToolSubscription(self._registry, signal, callback)


class SerialSessionAPI(_SessionAPI):
    @property
    def worker(self): return self.widget.worker
    @property
    def raw(self):
        worker = self.worker
        return getattr(worker, "_ser", None) if worker else None
    @property
    def terminal(self): return self.widget.model

    def connect(self): return self._registry.call_gui(self.widget.connect_serial)
    def disconnect(self): return self._registry.call_gui(self.widget.disconnect_serial)
    def configure(self, **settings):
        session = self.widget
        def apply():
            if "name" in settings:
                session.session_name = str(settings["name"])
                session.title_label.setText(session.session_name)
            for key, value in settings.items():
                if key in session.cfg.__dataclass_fields__:
                    setattr(session.cfg, key, value)
            session._push_cfg_into_ui()
            session._save_settings()
            return session.to_settings()
        return self._registry.call_gui(apply)
    def write(self, data):
        worker = self.worker
        if worker is None:
            raise ToolUnavailableError("Serial session is not connected")
        if isinstance(data, str):
            data = data.encode(self.widget.cfg.encoding, errors="replace")
        worker.enqueue_write(bytes(data))
    send = write
    def execute(self, text, expected=None, timeout=3, match_type="substring"):
        return self.widget.execute_macro_command(text, expected, timeout, match_type)
    def buffers(self):
        session = self.widget
        with session._rx_lock:
            return bytes(session._rx_bytes), str(session._rx_text)
    def run_raw_async(self, func):
        worker = self.worker
        if worker is None:
            raise ToolUnavailableError("Serial session is not connected")
        return worker.submit_raw(func)
    def run_raw(self, func, timeout=30): return self.run_raw_async(func).result(timeout)

    def subscribe(self, signal_name, callback):
        session = self.widget
        target = session if hasattr(session, signal_name) else self.worker
        if target is None or not hasattr(target, signal_name):
            raise AttributeError(f"Unknown serial event '{signal_name}'")
        signal = getattr(target, signal_name)
        self._registry.call_gui(lambda: signal.connect(callback))
        return ToolSubscription(self._registry, signal, callback)


class TelnetSessionAPI(_SessionAPI):
    @property
    def reader(self): return self.widget._reader
    @property
    def raw(self):
        reader = self.reader
        return getattr(reader, "_tn", None) if reader else None
    @property
    def socket(self):
        raw = self.raw
        return getattr(raw, "sock", None) if raw else None
    def connect(self, host=None, port=None):
        return self._registry.call_gui(lambda: self.widget.connect_to_host(host, port))
    def disconnect(self): return self._registry.call_gui(self.widget.disconnect_from_host)
    def configure(self, **settings):
        session = self.widget
        def apply():
            merged = session.to_settings()
            merged.update(settings)
            session.apply_settings(merged)
            session._notify_settings_changed()
            return session.to_settings()
        return self._registry.call_gui(apply)
    def send(self, text): return self._registry.call_gui(lambda: self.widget.send_text(str(text)))
    def write(self, data):
        reader = self.reader
        if reader is None:
            raise ToolUnavailableError("Telnet session is not connected")
        reader.enqueue_write(bytes(data))
    def execute(self, text, expected=None, timeout=3, match_type="substring"):
        return self.widget.execute_macro_command(text, expected, timeout, match_type)
    def buffers(self):
        session = self.widget
        with session._rx_lock:
            return bytes(session._rx_bytes), str(session._rx_text)
    def run_raw_async(self, func):
        reader = self.reader
        if reader is None:
            raise ToolUnavailableError("Telnet session is not connected")
        return reader.submit_raw(func)
    def run_raw(self, func, timeout=30): return self.run_raw_async(func).result(timeout)


class _WorkspaceAPI(_ToolAPI):
    session_api_type = _SessionAPI

    @property
    def sessions(self):
        widget = self.widget
        return [self.session_api_type(self._registry, s) for s in list(widget.sessions)] if widget else []

    @property
    def selected(self):
        widget = self.widget
        session = getattr(widget, "_selected_session", None) if widget else None
        return self.session_api_type(self._registry, session) if session else None

    def session(self, name_or_index=0):
        sessions = self.sessions
        if isinstance(name_or_index, int):
            try: return sessions[name_or_index]
            except IndexError: raise ToolUnavailableError(f"Session index {name_or_index} does not exist")
        for session in sessions:
            if session.name == name_or_index:
                return session
        raise ToolUnavailableError(f"Session '{name_or_index}' does not exist")

    def new_session(self, settings: Optional[dict] = None):
        widget = self._require()
        session = self._gui(lambda: widget._add_session(settings or {}, save=True))
        return self.session_api_type(self._registry, session)

    def close_session(self, name_or_index=0):
        session = self.session(name_or_index)
        widget = self._require()
        return self._gui(lambda: widget._remove_session(session.widget))

    def select(self, name_or_index=0):
        session = self.session(name_or_index)
        widget = self._require()
        self._gui(lambda: widget._select_session(session.widget))
        return session


class SerialAPI(_WorkspaceAPI):
    key = "serial"
    session_api_type = SerialSessionAPI

    def ports(self):
        import serial.tools.list_ports
        return list(serial.tools.list_ports.comports())


class TelnetAPI(_WorkspaceAPI):
    key = "telnet"
    session_api_type = TelnetSessionAPI


class CommunicationSessionAPI:
    """Callback facade for one process-isolated Communication Hub session."""

    def __init__(self, registry: ToolRegistry, hub, session_id: str):
        self._registry = registry
        self._hub_ref = weakref.ref(hub)
        self.session_id = session_id

    @property
    def hub(self):
        hub = self._hub_ref()
        if hub is None:
            raise ToolUnavailableError("Communication Hub has been closed")
        return hub

    def _config(self):
        def find():
            for config in self.hub.config.get("sessions", []):
                if config["id"] == self.session_id:
                    return config
            raise ToolUnavailableError(f"Communication session '{self.session_id}' does not exist")
        return self._registry.call_gui(find)

    def config(self):
        """Return an isolated copy of the complete persisted session configuration."""
        return copy.deepcopy(self._config())

    @property
    def name(self): return self._config()["name"]
    @property
    def protocol(self): return self._config()["protocol"]
    @property
    def lifecycle_scope(self):
        return self._config().get("lifecycle", {}).get("scope", "window")
    @property
    def application_lifetime(self):
        return self.lifecycle_scope == "application"
    @property
    def restore_last_state(self):
        return bool(self._config().get("lifecycle", {}).get("restore_last_state", True))
    @property
    def running(self):
        controller = self.hub.controllers.get(self.session_id)
        return bool(controller and controller.running)

    def set_application_lifetime(self, enabled=True):
        """Choose whether this session may continue after the Hub window closes."""
        def update():
            config = next(
                (
                    item for item in self.hub.config.get("sessions", [])
                    if item.get("id") == self.session_id
                ),
                None,
            )
            if config is None:
                raise ToolUnavailableError(
                    f"Communication session '{self.session_id}' does not exist"
                )
            lifecycle = config.setdefault("lifecycle", {})
            lifecycle["scope"] = "application" if bool(enabled) else "window"
            self.hub._save()
            if getattr(self.hub, "_ui_attached", True):
                self.hub._reload_sessions()
            return lifecycle["scope"]
        return self._registry.call_gui(update)

    def set_restore_last_state(self, enabled=True):
        """Choose whether a previously running session starts when the Hub reopens."""
        def update():
            config = next(
                (
                    item for item in self.hub.config.get("sessions", [])
                    if item.get("id") == self.session_id
                ),
                None,
            )
            if config is None:
                raise ToolUnavailableError(
                    f"Communication session '{self.session_id}' does not exist"
                )
            lifecycle = config.setdefault("lifecycle", {})
            lifecycle["restore_last_state"] = bool(enabled)
            self.hub._save()
            return lifecycle["restore_last_state"]
        return self._registry.call_gui(update)

    def _controller(self, create=False):
        def resolve():
            controller = self.hub.controllers.get(self.session_id)
            if controller is None and create:
                factory = getattr(self.hub, "_controller_for_config", None)
                if callable(factory):
                    controller = factory(self._config())
                else:
                    from app.tools.communication_hub.controller import SessionController
                    from app.utils import PROJECT_ROOT
                    controller = SessionController(self._config(), PROJECT_ROOT)
                    self.hub.controllers[self.session_id] = controller
            return controller
        controller = self._registry.call_gui(resolve)
        if controller is None:
            raise ToolUnavailableError(f"Communication session '{self.name}' is not running")
        return controller

    def start(self):
        result = self._controller(create=True).start()
        self._registry.call_gui(lambda: self.hub._session_started(self.session_id, result))
        return result
    def stop(self):
        controller = self._controller(create=False)
        self._registry.call_gui(lambda: self._prepare_stop())
        result = controller.stop()
        self._registry.call_gui(lambda: self.hub._clear_protocol_insight_session_states(self.session_id))
        return result
    def _prepare_stop(self):
        config = self._config()
        config.setdefault("lifecycle", {})["last_running_on_close"] = False
        self.hub._pause_periodic_messages_for_session(self.session_id)
        self.hub._save()
    def restart(self):
        self.stop()
        return self.start()
    def status(self): return self._controller(create=True).status()
    def send(self, data, encoding="utf-8", target=""):
        """Send exactly the supplied message bytes without applying receive framing."""
        return self._controller().send(data, encoding=encoding, target=target)
    def query(self, query=None, **options): return self._controller().query(query, **options)
    def delete_preview(self, query=None):
        return self._controller().request("delete_preview", {"query": query or {}})
    def delete(self, query=None, expected_version=None):
        return self._controller().request("delete", {"query": query or {}, "expected_version": expected_version})
    def names(self): return self._controller().request("names")
    def fields(self, name=None): return self._controller().request("fields", {"name": name})
    def clients(self): return self._controller().request("clients")

    def configure(self, config=None, **changes):
        """Replace or merge this stopped session's persisted configuration."""
        controller = self.hub.controllers.get(self.session_id)
        if controller is not None and controller.running:
            raise RuntimeError("Stop the communication session before changing its configuration")
        from app.tools.communication_hub.config import normalize_session_config
        source = self.config() if config is None else copy.deepcopy(config)
        source.update(copy.deepcopy(changes))
        source["id"] = self.session_id
        value = normalize_session_config(source)
        def apply():
            for index, current in enumerate(self.hub.config.get("sessions", [])):
                if current.get("id") == self.session_id:
                    self.hub.config["sessions"][index] = value
                    self.hub.controllers.pop(self.session_id, None)
                    self.hub._save()
                    if self.hub._ui_attached: self.hub._reload_sessions()
                    return copy.deepcopy(value)
            raise ToolUnavailableError(f"Communication session '{self.session_id}' does not exist")
        return self._registry.call_gui(apply)

    def duplicate(self, name=None):
        value = self.config()
        value["id"] = str(uuid.uuid4())
        value["name"] = str(name or f"{value['name']} Copy")
        value["autostart"] = False
        value.setdefault("lifecycle", {})["last_running_on_close"] = False
        return self.hub_api.new_session(value)

    def select(self):
        """Select this session in the shared workspace and return this facade."""
        def select():
            for index, item in enumerate(self.hub.config.get("sessions", [])):
                if item.get("id") == self.session_id:
                    tree_item = self.hub.sessions.topLevelItem(index)
                    if tree_item is not None: self.hub.sessions.setCurrentItem(tree_item)
                    return
            raise ToolUnavailableError(f"Communication session '{self.session_id}' does not exist")
        self._registry.call_gui(select)
        return self

    @property
    def hub_api(self):
        return CommunicationAPI(self._registry)

    def remove(self):
        """Remove this stopped session and disable schedules that target it."""
        controller = self.hub.controllers.get(self.session_id)
        if controller is not None and controller.running:
            raise RuntimeError("Stop the communication session before removing it")
        def remove():
            before = len(self.hub.config.get("sessions", []))
            self.hub.config["sessions"] = [
                item for item in self.hub.config.get("sessions", [])
                if item.get("id") != self.session_id
            ]
            if len(self.hub.config["sessions"]) == before:
                return False
            self.hub.controllers.pop(self.session_id, None)
            self.hub.config.setdefault("query_ui_state_by_session", {}).pop(self.session_id, None)
            for entry in self.hub.config.get("periodic_messages", []):
                if entry.get("session_id") == self.session_id:
                    entry["enabled"] = False
                    entry["last_error"] = "Destination session was removed"
            self.hub._save()
            if self.hub._ui_attached: self.hub._reload_sessions()
            return True
        return self._registry.call_gui(remove)

    def export_messages(self, path, query=None, scope_label=None):
        """Export this session's current or retained message table to an XLSX workbook."""
        from app.tools.communication_hub.excel_export import export_messages_excel
        config = self.config()
        controller = self._controller(create=True)
        destination = Path(path)
        if destination.suffix.casefold() != ".xlsx": destination = destination.with_suffix(".xlsx")
        sources = [{
            "session_name": config["name"], "session_id": self.session_id,
            "protocol": config["protocol"], "frame": controller.table_snapshot(),
        }]
        return export_messages_excel(
            destination, sources, query or {},
            scope_label or f"Session: {config['name']}",
        )
    def apply_protocol_insight(self, config):
        """Compatibility wrapper that persists and starts a shared Hub insight."""
        value = copy.deepcopy(config)
        source = value.setdefault("source", {})
        source["scope"] = "selected"
        source["session_ids"] = [self.session_id]
        insight = self.hub_api.new_protocol_insight(value)
        return insight.start()
    def export_protocol_insight(self, protocol_insight_id, final=True, config=None):
        insight = self.hub_api.protocol_insight(protocol_insight_id)
        return insight.export(final=final)
    def protocol_insight_checkpoint_info(self, config):
        return self.hub._protocol_insight_service_request(
            "checkpoint_info", {"config": config}
        )
    def pause_protocol_insight(self, protocol_insight_id):
        return self.hub_api.protocol_insight(protocol_insight_id).pause()
    def resume_protocol_insight(self, protocol_insight_id):
        return self.hub_api.protocol_insight(protocol_insight_id).resume()
    def remove_protocol_insight(self, protocol_insight_id):
        return self.hub_api.protocol_insight(protocol_insight_id).remove()


class ProtocolInsightAPI:
    """Facade for one persisted Protocol Insight and its shared backend runtime."""

    def __init__(self, registry: ToolRegistry, hub, insight_id: str):
        self._registry = registry
        self._hub_ref = weakref.ref(hub)
        self.insight_id = str(insight_id)

    @property
    def hub(self):
        value = self._hub_ref()
        if value is None:
            raise ToolUnavailableError("Communication Hub has been closed")
        return value

    def _view(self):
        def find():
            for item in self.hub.config.get("protocol_insights", []):
                if str(item.get("id", "")) == self.insight_id:
                    return item
            raise ToolUnavailableError(f"Protocol Insight '{self.insight_id}' does not exist")
        return self._registry.call_gui(find)

    def config(self): return copy.deepcopy(self._view())
    @property
    def name(self): return str(self._view().get("name", ""))
    @property
    def active(self): return bool(self._view().get("dataset", {}).get("runtime", {}).get("active", False))
    @property
    def paused(self): return bool(self._view().get("dataset", {}).get("runtime", {}).get("paused", False))

    def configure(self, config=None, **changes):
        """Normalize and persist a stopped insight while preserving its identity."""
        if self.active:
            raise RuntimeError("Stop the Protocol Insight before changing its configuration")
        from app.tools.communication_hub.protocol_insights import normalize_protocol_insight_config
        source = self.config() if config is None else copy.deepcopy(config)
        source.update(copy.deepcopy(changes)); source["id"] = self.insight_id
        value = normalize_protocol_insight_config(source)
        def apply():
            for index, current in enumerate(self.hub.config.get("protocol_insights", [])):
                if str(current.get("id", "")) == self.insight_id:
                    self.hub.config["protocol_insights"][index] = value
                    self.hub._synchronize_protocol_insight_saved_query_references(
                        migrate_embedded=True,
                    )
                    self.hub._save()
                    if self.hub._ui_attached: self.hub.insight_panel.refresh()
                    return copy.deepcopy(self.hub.config["protocol_insights"][index])
            raise ToolUnavailableError(f"Protocol Insight '{self.insight_id}' does not exist")
        return self._registry.call_gui(apply)

    def set_application_lifetime(self, enabled=True):
        def update():
            scope = "application" if enabled else "window"
            self._view().setdefault("lifecycle", {})["scope"] = scope
            self.hub._save(); return scope
        return self._registry.call_gui(update)

    def set_restore_last_state(self, enabled=True):
        def update():
            value = bool(enabled)
            self._view().setdefault("lifecycle", {})["restore_last_state"] = value
            self.hub._save(); return value
        return self._registry.call_gui(update)

    def duplicate(self, name=None):
        value = self.config(); value["id"] = str(uuid.uuid4())
        value["name"] = str(name or f"{value['name']} Copy"); value["autostart"] = False
        dataset = value.setdefault("dataset", {})
        dataset["id"] = str(uuid.uuid4())
        dataset.setdefault("runtime", {}).update({
            "active": False, "paused": False, "last_active_on_close": False,
        })
        return CommunicationAPI(self._registry).new_protocol_insight(value)

    def runtime_config(self):
        return self._registry.call_gui(lambda: self.hub._protocol_insight_runtime_config(self._view()))

    def start(self, start_source_sessions=False):
        """Start collection in the shared service and connect all in-scope publishers."""
        def activate():
            view = self._view(); sessions = list(self.hub._protocol_insight_sessions(view))
            monitor = self.hub._protocol_insight_runtime_config(view)
            if not sessions: raise RuntimeError("Protocol Insight has no source sessions")
            if not monitor.get("series"): raise RuntimeError("Protocol Insight has no configured value series")
            dataset = view.setdefault("dataset", {})
            dataset["enabled"] = True
            runtime = dataset.setdefault("runtime", {})
            runtime.update({"active": True, "paused": False, "last_active_on_close": True})
            monitor["enabled"] = True
            self.hub._save()
            return monitor, [copy.deepcopy(item) for item in sessions]
        monitor, sessions = self._registry.call_gui(activate)
        if start_source_sessions:
            for session in sessions:
                api = CommunicationSessionAPI(self._registry, self.hub, str(session["id"]))
                if not api.running: api.start()
        result = self.hub._protocol_insight_service_request("upsert", {"config": monitor}, timeout=30)
        replayed = 0
        collection = monitor.get("insights", {}).get("source", {}).get("collection", {})
        if collection.get("start_position") == "retained_then_new":
            records = []
            for session in sessions:
                controller = self.hub.controllers.get(str(session["id"]))
                if controller is not None and controller.table_available:
                    rows = controller.table_snapshot(timeout=60).to_dict(orient="records")
                    for row in rows: row.setdefault("session_name", str(session.get("name", "")))
                    records.extend(rows)
            if records:
                replayed = int(self.hub._protocol_insight_service_request("replay", {
                    "protocol_insight_id": monitor["id"], "records": records,
                }, timeout=120) or 0)
        publishers = []
        for session in sessions:
            controller = self.hub.controllers.get(str(session["id"]))
            if controller is not None and controller.running:
                controller.request("protocol_insight_publisher", {"enabled": True})
                publishers.append(str(session["id"]))
        return {"result": result, "replayed_records": replayed, "publisher_session_ids": publishers}

    def status(self):
        runtime_id = str(self.runtime_config().get("id", ""))
        status = self.hub._protocol_insight_service_request("status", {})
        runtime = next((item for item in status.get("runtimes", []) if str(item.get("id", "")) == runtime_id), None)
        return {"active": self.active, "paused": self.paused, "runtime": runtime, "service": status}

    def pause(self):
        runtime_id = str(self.runtime_config()["id"])
        result = self.hub._protocol_insight_service_request("pause", {"protocol_insight_id": runtime_id})
        self._registry.call_gui(lambda: self._set_paused(True))
        return result

    def resume(self):
        monitor = self.runtime_config(); runtime_id = str(monitor["id"])
        self.hub._protocol_insight_service_request("ensure", {"config": monitor})
        result = self.hub._protocol_insight_service_request("resume", {"protocol_insight_id": runtime_id})
        self._registry.call_gui(lambda: self._set_paused(False))
        return result

    def _set_paused(self, paused):
        self._view().setdefault("dataset", {}).setdefault("runtime", {})["paused"] = bool(paused)
        self.hub._save()
        for session in self.hub._protocol_insight_sessions(self._view()):
            self.hub._sync_protocol_insights_for_session(str(session.get("id", "")))

    def stop(self):
        monitor = self.runtime_config(); runtime_id = str(monitor["id"])
        def deactivate():
            runtime = self._view().setdefault("dataset", {}).setdefault("runtime", {})
            runtime.update({"active": False, "paused": False, "last_active_on_close": False})
            self.hub._save()
        self._registry.call_gui(deactivate)
        result = self.hub._protocol_insight_service_request("delete", {"protocol_insight_id": runtime_id}, timeout=120)
        for session in self.hub.config.get("sessions", []):
            self._registry.call_gui(lambda sid=str(session.get("id", "")): self.hub._sync_protocol_insights_for_session(sid))
        return result

    def samples(self, limit=1000):
        return self.hub._protocol_insight_service_request("samples", {
            "protocol_insight_id": str(self.runtime_config()["id"]), "limit": int(limit),
        })

    def display_snapshot(self, sample_limit=1000, event_limit=1000):
        return self.hub._protocol_insight_service_request("display_snapshot", {
            "protocol_insight_id": str(self.runtime_config()["id"]),
            "sample_limit": int(sample_limit), "event_limit": int(event_limit),
        })

    def checkpoint_info(self):
        return self.hub._protocol_insight_service_request("checkpoint_info", {"config": self.runtime_config()})

    def export(self, final=True):
        monitor = self.runtime_config(); runtime_id = str(monitor["id"])
        payload = {"protocol_insight_id": runtime_id, "config": monitor}
        return self.hub._protocol_insight_service_request("final_export" if final else "export", payload, timeout=120)

    def remove(self):
        if self.active: self.stop()
        def remove():
            before = len(self.hub.config.get("protocol_insights", []))
            self.hub.config["protocol_insights"] = [
                item for item in self.hub.config.get("protocol_insights", [])
                if str(item.get("id", "")) != self.insight_id
            ]
            changed = len(self.hub.config["protocol_insights"]) != before
            if changed: self.hub._save()
            if changed and self.hub._ui_attached: self.hub.insight_panel.refresh()
            return changed
        return self._registry.call_gui(remove)


class CommunicationAPI(_ToolAPI):
    key = "communication"

    def _require(self):
        return self._registry.acquire(self.key)

    @property
    def sessions(self):
        widget = self._require()
        session_ids = self._registry.call_gui(lambda: [item["id"] for item in widget.config.get("sessions", [])])
        return [CommunicationSessionAPI(self._registry, widget, session_id) for session_id in session_ids]

    @property
    def selected(self):
        widget = self._require()
        config = self._registry.call_gui(widget._selected_config)
        return CommunicationSessionAPI(self._registry, widget, config["id"]) if config else None

    def session(self, name_or_index=0):
        sessions = self.sessions
        if isinstance(name_or_index, int):
            try: return sessions[name_or_index]
            except IndexError: raise ToolUnavailableError(f"Communication session index {name_or_index} does not exist")
        for session in sessions:
            if session.name == name_or_index or session.session_id == name_or_index:
                return session
        raise ToolUnavailableError(f"Communication session '{name_or_index}' does not exist")

    def new_session(self, config=None):
        widget = self._require()
        from app.tools.communication_hub.config import normalize_session_config
        value = normalize_session_config(config or {})
        def add():
            widget.config.setdefault("sessions", []).append(value)
            widget._save(); widget._reload_sessions()
        self._gui(add)
        return CommunicationSessionAPI(self._registry, widget, value["id"])

    def select(self, name_or_index=0):
        """Select a session in the shared workspace and return its facade."""
        return self.session(name_or_index).select()

    @property
    def protocol_insights(self):
        widget = self._require()
        ids = self._registry.call_gui(lambda: [str(item["id"]) for item in widget.config.get("protocol_insights", [])])
        return [ProtocolInsightAPI(self._registry, widget, insight_id) for insight_id in ids]

    def protocol_insight(self, name_or_index=0):
        insights = self.protocol_insights
        if isinstance(name_or_index, int):
            try: return insights[name_or_index]
            except IndexError: raise ToolUnavailableError(f"Protocol Insight index {name_or_index} does not exist")
        for insight in insights:
            config = insight.config()
            if (
                insight.insight_id == str(name_or_index)
                or str(config.get("dataset", {}).get("id", "")) == str(name_or_index)
                or insight.name == str(name_or_index)
            ): return insight
        raise ToolUnavailableError(f"Protocol Insight '{name_or_index}' does not exist")

    def new_protocol_insight(self, config=None):
        from app.tools.communication_hub.protocol_insights import normalize_protocol_insight_config
        widget = self._require(); value = normalize_protocol_insight_config(config or {})
        def add():
            widget.config.setdefault("protocol_insights", []).append(value)
            widget.config["active_protocol_insight_id"] = value["id"]
            widget._synchronize_protocol_insight_saved_query_references(
                migrate_embedded=True,
            )
            widget._save()
            if widget._ui_attached: widget.insight_panel.refresh()
        self._gui(add)
        return ProtocolInsightAPI(self._registry, widget, value["id"])

    def query(self, query=None, page=0, page_size=200):
        """Query all running or retained session tables as one time-sorted table."""
        widget = self._require()
        return widget._query_global_tables(query or {}, int(page), int(page_size))

    def delete_preview(self, query=None):
        """Count matches across all available session tables without deleting them."""
        return self._require()._global_delete_preview(query or {})

    def delete(self, query=None):
        """Delete matches across all available session tables."""
        return self._require()._global_delete(query or {})

    def export_messages(self, path, query=None, scope_label="Global Communication Hub table"):
        """Export all available session tables through the same XLSX exporter as the UI."""
        from app.tools.communication_hub.excel_export import export_messages_excel
        widget = self._require(); destination = Path(path)
        if destination.suffix.casefold() != ".xlsx": destination = destination.with_suffix(".xlsx")
        sources = []
        for config, controller in widget._available_table_controllers():
            sources.append({
                "session_name": str(config.get("name", "Unnamed")),
                "session_id": str(config.get("id", "")),
                "protocol": str(config.get("protocol", "")),
                "frame": controller.table_snapshot(),
            })
        if not sources: raise RuntimeError("No running or retained session tables are available")
        return export_messages_excel(destination, sources, query or {}, str(scope_label))

    @property
    def saved_messages(self):
        return self._registry.call_gui(lambda: copy.deepcopy(self._require().config.get("saved_messages", [])))

    def save_message(self, name, content, encoding="utf-8", message_id=None):
        """Create or replace a named payload used by the Hub send workspace."""
        encoding = str(encoding); content = str(content)
        if encoding == "hex": bytes.fromhex("".join(content.split()))
        else: content.encode(encoding)
        widget = self._require()
        def save():
            messages = widget.config.setdefault("saved_messages", [])
            target = next((item for item in messages if item.get("id") == message_id), None)
            if target is None:
                target = next((item for item in messages if str(item.get("name", "")).casefold() == str(name).casefold()), None)
            if target is None:
                target = {"id": str(message_id or uuid.uuid4())}; messages.append(target)
            target.update({"name": str(name), "encoding": encoding, "content": content})
            widget._save()
            if widget._ui_attached: widget._reload_saved_messages(target["id"])
            return copy.deepcopy(target)
        return self._registry.call_gui(save)

    def remove_saved_message(self, name_or_id):
        widget = self._require()
        def remove():
            messages = widget.config.get("saved_messages", [])
            target = next((item for item in messages if item.get("id") == name_or_id or item.get("name") == name_or_id), None)
            if target is None: return False
            messages.remove(target); widget._save()
            if widget._ui_attached: widget._reload_saved_messages()
            return True
        return self._registry.call_gui(remove)

    @property
    def saved_queries(self):
        return self._registry.call_gui(lambda: copy.deepcopy(self._require().config.get("saved_queries", [])))

    def save_query(self, name, query, query_id=None):
        """Create or replace reusable Hub query JSON."""
        widget = self._require()
        # Exercise the canonical validator without requiring a message table.
        validator = getattr(widget, "_validate_query_node", None)
        if callable(validator): validator(copy.deepcopy(query or {}))
        def save():
            queries = widget.config.setdefault("saved_queries", [])
            target = next((item for item in queries if item.get("id") == query_id), None)
            if target is None:
                target = next((item for item in queries if str(item.get("name", "")).casefold() == str(name).casefold()), None)
            if target is None:
                target = {"id": str(query_id or uuid.uuid4())}; queries.append(target)
            target.update({"name": str(name), "query": copy.deepcopy(query or {})})
            widget._synchronize_protocol_insight_saved_query_references()
            widget._save()
            if widget._ui_attached: widget._reload_saved_queries(target["id"])
            return copy.deepcopy(target)
        return self._registry.call_gui(save)

    def remove_saved_query(self, name_or_id):
        widget = self._require()
        def remove():
            queries = widget.config.get("saved_queries", [])
            target = next((item for item in queries if item.get("id") == name_or_id or item.get("name") == name_or_id), None)
            if target is None: return False
            queries.remove(target)
            widget._synchronize_protocol_insight_saved_query_references()
            widget._save()
            if widget._ui_attached: widget._reload_saved_queries()
            return True
        return self._registry.call_gui(remove)

    @property
    def periodic_messages(self):
        return self._registry.call_gui(lambda: copy.deepcopy(self._require().config.get("periodic_messages", [])))

    def _sync_periodic(self, session_ids):
        widget = self._require(); results = {}
        for session_id in {str(item) for item in session_ids if str(item)}:
            controller = widget.controllers.get(session_id)
            if controller is None or not controller.running: continue
            results[session_id] = controller.request("periodic_configure", {
                "entries": widget._periodic_worker_definitions(session_id),
                "revision": widget._periodic_schedule_revisions.get(session_id, 0) + 1,
                "maximum_inflight": min(64, max(1, int(widget.config.get("periodic_max_inflight", 16) or 16))),
            }, timeout=10)
            widget._periodic_schedule_revisions[session_id] = widget._periodic_schedule_revisions.get(session_id, 0) + 1
        return results

    def schedule_periodic(
        self, session, name, content, interval_seconds, *, encoding="utf-8",
        target="", enabled=True, auto_start=True, start_with_session=True,
        schedule_id=None,
    ):
        """Create or replace a worker-owned periodic send schedule."""
        session_api = session if isinstance(session, CommunicationSessionAPI) else self.session(session)
        entry = {
            "id": str(schedule_id or uuid.uuid4()), "name": str(name),
            "session_id": session_api.session_id, "target": str(target),
            "target_label": str(target or "Configured endpoint"),
            "encoding": str(encoding), "content": str(content),
            "interval_seconds": max(0.05, float(interval_seconds)),
            "enabled": bool(enabled), "auto_start": bool(auto_start),
            "start_with_session": bool(start_with_session), "sent_count": 0,
            "last_sent_at": "", "last_error": "",
        }
        # Validate exact transmitted bytes before persistence.
        self._require()._periodic_bytes(entry)
        widget = self._require()
        def save():
            entries = widget.config.setdefault("periodic_messages", [])
            current = next((item for item in entries if item.get("id") == entry["id"]), None)
            if current is None: entries.append(entry); current = entry
            else:
                counts = {key: current.get(key) for key in ("sent_count", "last_sent_at")}
                current.update(entry); current.update(counts)
            widget._normalize_periodic_settings(widget.config); widget._save()
            if widget._ui_attached: widget._reload_periodic_messages(selected_ids={current["id"]})
            return copy.deepcopy(current)
        result = self._registry.call_gui(save)
        self._sync_periodic([session_api.session_id])
        return result

    def set_periodic_enabled(self, schedule_id, enabled=True):
        widget = self._require()
        def update():
            entry = widget._periodic_entry_by_id(str(schedule_id))
            if entry is None: raise KeyError(f"Periodic schedule '{schedule_id}' does not exist")
            entry["enabled"] = bool(enabled); entry["paused_by_session_stop"] = False
            widget._save()
            if widget._ui_attached: widget._reload_periodic_messages(selected_ids={entry["id"]})
            return copy.deepcopy(entry)
        result = self._registry.call_gui(update)
        self._sync_periodic([result["session_id"]]); return result

    def remove_periodic(self, schedule_id):
        widget = self._require()
        def remove():
            entry = widget._periodic_entry_by_id(str(schedule_id))
            if entry is None: return None
            widget.config["periodic_messages"].remove(entry); widget._save()
            if widget._ui_attached: widget._reload_periodic_messages()
            return copy.deepcopy(entry)
        removed = self._registry.call_gui(remove)
        if removed is not None: self._sync_periodic([removed["session_id"]])
        return removed is not None

    def send_periodic_now(self, schedule_id):
        """Synchronously send one schedule payload, honoring its auto-start setting."""
        widget = self._require(); entry = self._registry.call_gui(lambda: copy.deepcopy(widget._periodic_entry_by_id(str(schedule_id))))
        if entry is None: raise KeyError(f"Periodic schedule '{schedule_id}' does not exist")
        config = self.session(entry["session_id"]).config()
        controller = widget._controller_for_config(config)
        was_running = controller.running
        result = widget._send_bytes_operation(
            controller, config, widget._periodic_bytes(entry), str(entry.get("encoding", "utf-8")),
            str(entry.get("target", "")), bool(entry.get("auto_start", True)),
        )
        if not was_running and controller.running:
            self._registry.call_gui(
                lambda: widget._session_started(str(config["id"]), controller.status())
            )
        self._registry.call_gui(lambda: widget._periodic_send_succeeded(str(schedule_id), result))
        return result


class ToolsProxy:
    def __init__(self):
        self.registry = ToolRegistry()
        self.ftp_client = FTPClientAPI(self.registry)
        self.ftp_server = FTPServerAPI(self.registry)
        self.serial = SerialAPI(self.registry)
        self.telnet = TelnetAPI(self.registry)
        self.communication = CommunicationAPI(self.registry)

    def bind(self, openers, acquirers=None):
        self.registry.bind(openers, acquirers=acquirers)

    def begin_shutdown(self):
        self.registry.begin_shutdown()


Tools = ToolsProxy()

__all__ = [
    "Tools", "ToolsProxy", "ToolRegistry", "ToolCallFuture",
    "ToolSubscription", "ToolUnavailableError", "FTPClientAPI",
    "FTPServerAPI", "SerialAPI", "SerialSessionAPI", "TelnetAPI",
    "TelnetSessionAPI", "CommunicationAPI", "CommunicationSessionAPI",
    "ProtocolInsightAPI",
]
