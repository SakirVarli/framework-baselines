from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from app.branding import SHORT_NAME
from app.project_identity import BASELINE_FAMILY_ID


PACKAGE_FILENAME = "baseline-package.json"
SCHEMA_VERSION = 2
STATE_DIRNAME = ".upgrade"
INSTALLED_MANIFEST = "installed-manifest.json"
MAX_ARCHIVE_FILES = 10000
MAX_UNCOMPRESSED_BYTES = 2 * 1024 * 1024 * 1024


class PackageError(ValueError):
    pass


def hide_windows_path(path: str | Path) -> bool:
    path = Path(path)
    if os.name != "nt" or not path.exists():
        return False
    try:
        import ctypes

        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        if attrs == -1:
            return False
        return bool(ctypes.windll.kernel32.SetFileAttributesW(str(path), attrs | 0x02))
    except Exception:
        return False


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    os.replace(temporary, path)


def read_json_strict(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise PackageError(f"Cannot read {path.name}: {exc}") from exc
    if not isinstance(value, dict):
        raise PackageError(f"{path.name} must contain a JSON object.")
    return value


def normalized_relative_path(value: str) -> str:
    value = str(value).replace("\\", "/")
    path = PurePosixPath(value)
    if (
        not value
        or value.startswith("/")
        or path.is_absolute()
        or any(part in ("", ".", "..") for part in path.parts)
        or ":" in path.parts[0]
    ):
        raise PackageError(f"Unsafe package path: {value!r}")
    return path.as_posix()


def category_for(path: str) -> str:
    path = path.replace("\\", "/")
    if path in {
        "app/data/branding.json",
        "app/data/product_identity.json",
    }:
        return "core"
    if path.startswith("app/data/") and path.endswith(".json"):
        return "user_data"
    if path == "callbacks/callbacks.py":
        return "callbacks"
    if path.startswith("externals/"):
        return "externals"
    return "core"


def build_file_entries(root: Path, relative_paths: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for relative in sorted(set(relative_paths), key=str.casefold):
        relative = normalized_relative_path(relative)
        source = root / Path(relative)
        if not source.is_file():
            raise PackageError(f"Required package file is missing: {relative}")
        entries.append(
            {
                "path": relative,
                "size": source.stat().st_size,
                "sha256": sha256_file(source),
                "category": category_for(relative),
            }
        )
    return entries


def make_manifest(
    *, baseline_number: int, version: str, build: Any, title: str,
    summary: str, notes: str, files: list[dict[str, Any]],
    minimum_baseline: int | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "baseline_family_id": BASELINE_FAMILY_ID,
        "package_id": str(uuid.uuid4()),
        "created_at": utc_now(),
        "release": {
            "baseline_number": int(baseline_number),
            "version": str(version or ""),
            "build": build,
            "title": str(title or f"Baseline {baseline_number}"),
            "summary": str(summary or ""),
            "notes": str(notes or ""),
            "minimum_baseline": minimum_baseline,
        },
        "managed_config": [
            "window.baseline_number",
            "window.version",
            "window.app_version_release_notes",
            "window.build",
        ],
        "files": files,
    }


def validate_manifest(manifest: dict[str, Any]) -> None:
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise PackageError(
            f"Unsupported baseline package schema: {manifest.get('schema_version')!r}"
        )
    if manifest.get("baseline_family_id") != BASELINE_FAMILY_ID:
        raise PackageError(
            f"This archive does not belong to the {SHORT_NAME} baseline family."
        )
    release = manifest.get("release")
    files = manifest.get("files")
    if not isinstance(release, dict) or not isinstance(files, list):
        raise PackageError("The package manifest is missing release or file data.")
    try:
        if int(release["baseline_number"]) < 0:
            raise ValueError
    except Exception as exc:
        raise PackageError("The package baseline number is invalid.") from exc
    if not files:
        raise PackageError("The package contains no managed files.")

    seen: set[str] = set()
    required = {
        "app/main.py",
        "app/data/branding.json",
        "app/data/config.json",
        "app/data/product_identity.json",
        "callbacks/callbacks.py",
        "designer.exe",
    }
    for item in files:
        if not isinstance(item, dict):
            raise PackageError("A package file entry is malformed.")
        relative = normalized_relative_path(item.get("path", ""))
        folded = relative.casefold()
        if not (
            relative == "designer.exe"
            or relative.startswith("app/")
            or relative.startswith("callbacks/")
            or relative.startswith("externals/")
        ):
            raise PackageError(f"File is outside the baseline payload scope: {relative}")
        if folded in seen:
            raise PackageError(f"Duplicate or case-colliding path: {relative}")
        seen.add(folded)
        if not isinstance(item.get("size"), int) or item["size"] < 0:
            raise PackageError(f"Invalid size for {relative}")
        digest = item.get("sha256", "")
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdefABCDEF" for c in digest):
            raise PackageError(f"Invalid checksum for {relative}")
        if item.get("category") not in {"core", "callbacks", "externals", "user_data"}:
            raise PackageError(f"Invalid category for {relative}")
    missing = sorted(required - seen)
    if missing:
        raise PackageError("The baseline package is incomplete: " + ", ".join(missing))


def _safe_archive_members(archive: zipfile.ZipFile) -> dict[str, zipfile.ZipInfo]:
    members = archive.infolist()
    if len(members) > MAX_ARCHIVE_FILES:
        raise PackageError("The archive contains too many files.")
    if sum(item.file_size for item in members) > MAX_UNCOMPRESSED_BYTES:
        raise PackageError("The archive is too large after extraction.")
    result: dict[str, zipfile.ZipInfo] = {}
    for item in members:
        name = item.filename.replace("\\", "/").rstrip("/")
        if not name:
            continue
        normalized = normalized_relative_path(name)
        folded = normalized.casefold()
        if folded in result:
            raise PackageError(f"Duplicate or case-colliding archive path: {normalized}")
        result[folded] = item
    return result


def inspect_archive(archive_path: str | Path, verify_payload: bool = True) -> dict[str, Any]:
    archive_path = Path(archive_path)
    if not archive_path.is_file():
        raise PackageError("Select an existing ZIP baseline package.")
    if not zipfile.is_zipfile(archive_path):
        raise PackageError("The selected file is not a valid ZIP archive.")
    try:
        with zipfile.ZipFile(archive_path, "r") as archive:
            members = _safe_archive_members(archive)
            manifest_info = members.get(PACKAGE_FILENAME.casefold())
            if manifest_info is None:
                raise PackageError(f"The archive does not contain {PACKAGE_FILENAME}.")
            try:
                manifest = json.loads(archive.read(manifest_info).decode("utf-8"))
            except Exception as exc:
                raise PackageError(f"The package manifest cannot be read: {exc}") from exc
            if not isinstance(manifest, dict):
                raise PackageError("The package manifest must be a JSON object.")
            validate_manifest(manifest)
            allowed = {item["path"].casefold() for item in manifest["files"]}
            allowed.update({PACKAGE_FILENAME.casefold(), f"{STATE_DIRNAME}/{INSTALLED_MANIFEST}".casefold()})
            for folded, info in members.items():
                if not info.is_dir() and folded not in allowed:
                    raise PackageError(f"Unexpected file in baseline archive: {info.filename}")
            for entry in manifest["files"]:
                relative = entry["path"]
                info = members.get(relative.casefold())
                if info is None or info.is_dir():
                    raise PackageError(f"Package payload is missing: {relative}")
                if info.file_size != entry["size"]:
                    raise PackageError(f"Size check failed for {relative}")
                if verify_payload:
                    digest = hashlib.sha256()
                    with archive.open(info) as stream:
                        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                            digest.update(chunk)
                    if digest.hexdigest() != entry["sha256"]:
                        raise PackageError(f"Checksum check failed for {relative}")
            return manifest
    except zipfile.BadZipFile as exc:
        raise PackageError(f"The ZIP archive is damaged: {exc}") from exc


def extract_archive(archive_path: Path, target: Path) -> dict[str, Any]:
    manifest = inspect_archive(archive_path, verify_payload=True)
    target.mkdir(parents=True, exist_ok=False)
    wanted = {item["path"].casefold(): item["path"] for item in manifest["files"]}
    with zipfile.ZipFile(archive_path, "r") as archive:
        members = _safe_archive_members(archive)
        for folded, relative in wanted.items():
            info = members[folded]
            destination = target / Path(relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)
    atomic_write_json(target / PACKAGE_FILENAME, manifest)
    return manifest


def _installed_manifest(project_root: Path) -> dict[str, Any] | None:
    path = project_root / STATE_DIRNAME / INSTALLED_MANIFEST
    if not path.is_file():
        return None
    try:
        manifest = read_json_strict(path)
        validate_manifest(manifest)
        return manifest
    except PackageError:
        return None


def compare_package(project_root: Path, manifest: dict[str, Any]) -> list[dict[str, Any]]:
    old_manifest = _installed_manifest(project_root)
    old_files = {
        item["path"].casefold(): item
        for item in (old_manifest or {}).get("files", [])
        if isinstance(item, dict) and "path" in item
    }
    comparison: list[dict[str, Any]] = []
    for entry in manifest["files"]:
        relative = entry["path"]
        destination = project_root / Path(relative)
        old = old_files.get(relative.casefold())
        if not destination.exists():
            status = "new"
        elif not destination.is_file():
            status = "conflict"
        else:
            current_hash = sha256_file(destination)
            if current_hash == entry["sha256"]:
                status = "same"
            elif old and current_hash == old.get("sha256"):
                status = "unchanged"
            else:
                status = "modified" if old else "unknown"
        comparison.append({**entry, "status": status})
    return comparison


def prepare_upgrade(
    archive_path: str | Path, project_root: str | Path, options: dict[str, bool]
) -> tuple[Path, dict[str, Any]]:
    project_root = Path(project_root).resolve()
    archive_path = Path(archive_path).resolve()
    state_root = project_root / STATE_DIRNAME
    state_root.mkdir(parents=True, exist_ok=True)
    hide_windows_path(state_root)
    staging_root = state_root / "staging" / str(uuid.uuid4())
    payload_root = staging_root / "package"
    manifest = extract_archive(archive_path, payload_root)
    comparison = compare_package(project_root, manifest)
    old_manifest = _installed_manifest(project_root)

    operations: list[dict[str, Any]] = []
    preserved: list[dict[str, str]] = []
    for item in comparison:
        relative, status, category = item["path"], item["status"], item["category"]
        if relative == "app/data/config.json":
            continue
        replace_modified = bool(options.get(f"replace_{category}", False))
        if category == "user_data" and not options.get("replace_user_data", False):
            preserved.append({"path": relative, "reason": "user data"})
        elif status == "same":
            preserved.append({"path": relative, "reason": "already current"})
        elif status in {"new", "unchanged"} or replace_modified:
            operations.append({"action": "copy", "path": relative})
        else:
            preserved.append({"path": relative, "reason": status})

    config_fields: list[str] = []
    if options.get("upgrade_baseline_number", True):
        config_fields.append("baseline_number")
    if options.get("upgrade_version", False):
        config_fields.extend(("version", "app_version_release_notes"))
    if options.get("upgrade_build", False):
        config_fields.append("build")

    if options.get("replace_user_data", False):
        operations.append({"action": "copy_config", "path": "app/data/config.json"})
    elif config_fields:
        operations.append({
            "action": "merge_config",
            "path": "app/data/config.json",
            "fields": config_fields,
        })
    else:
        preserved.append({"path": "app/data/config.json", "reason": "user configuration"})

    new_paths = {item["path"].casefold() for item in manifest["files"]}
    for old in (old_manifest or {}).get("files", []):
        relative = old.get("path", "")
        if not relative or relative.casefold() in new_paths:
            continue
        destination = project_root / Path(relative)
        if (
            old.get("category") != "user_data"
            and destination.is_file()
            and sha256_file(destination) == old.get("sha256")
        ):
            operations.append({"action": "delete", "path": relative})
        else:
            preserved.append({"path": relative, "reason": "removed upstream but locally modified"})

    plan = {
        "schema_version": 1,
        "created_at": utc_now(),
        "project_root": str(project_root),
        "payload_root": str(payload_root),
        "manifest_path": str(payload_root / PACKAGE_FILENAME),
        "operations": operations,
        "preserved": preserved,
        "release": manifest["release"],
        "legacy_install": old_manifest is None,
        "restart": {
            "executable": str(Path(os.sys.executable).resolve()),
            "arguments": list(os.sys.argv),
        },
    }
    plan_path = staging_root / "upgrade-plan.json"
    atomic_write_json(plan_path, plan)
    return plan_path, {"manifest": manifest, "comparison": comparison, "plan": plan}


def create_temporary_export_root(parent: Path, name: str) -> Path:
    return Path(tempfile.mkdtemp(prefix=f".{name}-", dir=str(parent)))
