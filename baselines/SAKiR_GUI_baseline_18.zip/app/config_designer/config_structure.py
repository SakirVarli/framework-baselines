"""Version-neutral traversal helpers for legacy and window-layout configs."""


def is_window_layout_config(config):
    return isinstance(config, dict) and isinstance(config.get("widgets"), list)


def iter_tab_definitions(config):
    """Yield every tab page, including pages in nested tab widgets."""
    if not isinstance(config, dict):
        return
    for tab in config.get("tabs", []) or []:
        if isinstance(tab, dict):
            yield tab
            yield from _tabs_in_widgets(tab.get("widgets", []))
    yield from _tabs_in_widgets(config.get("widgets", []))


def _tabs_in_widgets(widgets):
    for widget in widgets or []:
        if not isinstance(widget, dict):
            continue
        if widget.get("type") == "tab_widget":
            for tab in widget.get("tabs", []) or []:
                if isinstance(tab, dict):
                    yield tab
                    yield from _tabs_in_widgets(tab.get("widgets", []))
        yield from _tabs_in_widgets(widget.get("widgets", []))


def iter_widget_definitions(config):
    """Yield controls recursively across both supported config schemas."""
    if not isinstance(config, dict):
        return
    for tab in config.get("tabs", []) or []:
        if isinstance(tab, dict):
            yield from _widgets(tab.get("widgets", []))
    yield from _widgets(config.get("widgets", []))


def _widgets(widgets):
    for widget in widgets or []:
        if not isinstance(widget, dict):
            continue
        yield widget
        if widget.get("type") == "tab_widget":
            for tab in widget.get("tabs", []) or []:
                if isinstance(tab, dict):
                    yield from _widgets(tab.get("widgets", []))
        yield from _widgets(widget.get("widgets", []))
