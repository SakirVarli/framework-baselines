"""Central mutable document model for every designer view."""

import copy
from contextlib import contextmanager
from typing import Callable, Iterable, Optional

from .nodes import DesignerNode
from .schema import default_properties


ALLOWED_CHILDREN = {
    "root": {"tab_widget", "group", "button", "output", "info"},
    "tab_widget": {"tab"},
    "tab": {"tab_widget", "group", "button", "output", "info"},
    "group": {"tab_widget", "group", "button", "output", "info"},
}


class DocumentError(ValueError):
    pass


class DesignerDocument:
    def __init__(self, root, source_config=None):
        self.root = root
        self.source_config = copy.deepcopy(source_config or {})
        self.saved_snapshot = copy.deepcopy(source_config or {})
        self.applied_snapshot = None
        self._listeners = []
        self._selected_ids = []
        self._notification_batch_depth = 0
        self._batched_notification = None

    @classmethod
    def from_config(cls, config):
        if not isinstance(config, dict):
            raise DocumentError("Configuration root must be an object.")
        root_props = {
            key: copy.deepcopy(value)
            for key, value in config.items() if key not in {"tabs", "widgets"}
        }
        root = DesignerNode("root", root_props)
        if isinstance(config.get("widgets"), list):
            for widget_data in config.get("widgets", []):
                if isinstance(widget_data, dict):
                    child = cls._node_from_dict(
                        widget_data.get("type", "unknown"), widget_data, root)
                    root.children.append(child)
        else:
            shell_props = default_properties("tab_widget")
            shell_props.update({
                "instance": "main_tabs",
                "bounds": [0, 0, 1200, 800],
                "anchors": ["left", "right", "top", "bottom"],
                "dock": "fill",
            })
            shell = DesignerNode("tab_widget", shell_props, parent=root)
            shell.metadata["legacy_implicit"] = True
            shell.metadata["legacy_properties"] = copy.deepcopy(shell_props)
            for tab_data in config.get("tabs", []):
                shell.children.append(cls._node_from_dict("tab", tab_data, shell))
            root.children.append(shell)
        return cls(root, config)

    @classmethod
    def _node_from_dict(cls, node_type, data, parent=None):
        props = copy.deepcopy(data) if isinstance(data, dict) else {}
        raw_children = props.pop("tabs", []) if node_type == "tab_widget" else props.pop("widgets", [])
        if node_type != "tab":
            node_type = props.get("type", node_type)
        node = DesignerNode(node_type, props, parent=parent)
        if isinstance(raw_children, list):
            for child_data in raw_children:
                if isinstance(child_data, dict):
                    child_type = "tab" if node_type == "tab_widget" else child_data.get("type", "unknown")
                    child = cls._node_from_dict(child_type, child_data, node)
                    node.children.append(child)
        return node

    def to_config(self):
        result = copy.deepcopy(self.root.properties)
        if self._legacy_compatible():
            result.pop("schemaVersion", None)
            result["tabs"] = [
                self._node_to_dict(tab) for tab in self.root.children[0].children
            ]
            return result
        result["schemaVersion"] = max(2, int(result.get("schemaVersion", 2) or 2))
        result.setdefault("layout", {
            "mode": "canvas", "designSize": [1200, 800],
            "resizeMode": "anchors", "snap": 8,
        })
        result["widgets"] = [self._node_to_dict(node) for node in self.root.children]
        return result

    def _legacy_compatible(self):
        if len(self.root.children) != 1:
            return False
        shell = self.root.children[0]
        if not shell.metadata.get("legacy_implicit"):
            return False
        if shell.properties != shell.metadata.get("legacy_properties"):
            return False
        return not any(
            node.node_type == "tab_widget"
            for tab in shell.children for node in tab.walk() if node is not tab
        )

    @property
    def is_legacy_layout(self):
        """Whether this document still uses the implicit legacy tab shell."""
        return bool(
            len(self.root.children) == 1
            and self.root.children[0].node_type == "tab_widget"
            and self.root.children[0].metadata.get("legacy_implicit")
        )

    def upgrade_legacy_layout(self):
        """Promote legacy top-level tabs to an explicit schema-v2 tab widget."""
        if not self.is_legacy_layout:
            return False
        shell = self.root.children[0]
        shell.metadata.pop("legacy_implicit", None)
        shell.metadata.pop("legacy_properties", None)
        return True

    @classmethod
    def _node_to_dict(cls, node):
        data = {
            key: copy.deepcopy(value)
            for key, value in node.properties.items() if not key.startswith("_")
        }
        if node.node_type != "tab":
            data["type"] = node.node_type
        if node.node_type == "tab_widget":
            data["tabs"] = [cls._node_to_dict(child) for child in node.children]
        elif node.node_type in {"tab", "group"}:
            data["widgets"] = [cls._node_to_dict(child) for child in node.children]
        return data

    def on_change(self, callback: Callable):
        self._listeners.append(callback)

    def remove_listener(self, callback):
        if callback in self._listeners:
            self._listeners.remove(callback)

    def notify(self, reason="changed", node=None):
        if self._notification_batch_depth:
            self._batched_notification = (reason, node)
            return
        for callback in list(self._listeners):
            callback(reason, node)

    @contextmanager
    def batch_notifications(self, reason="changed", node=None):
        """Coalesce a multi-command edit into one UI refresh."""
        self._notification_batch_depth += 1
        try:
            yield
        finally:
            self._notification_batch_depth -= 1
            if self._notification_batch_depth == 0 and self._batched_notification:
                pending_reason, pending_node = self._batched_notification
                self._batched_notification = None
                self.notify(reason or pending_reason, node or pending_node)

    def find(self, node_id):
        return self.root.find(node_id)

    @staticmethod
    def can_parent(parent_type, child_type):
        return child_type in ALLOWED_CHILDREN.get(parent_type, set())

    def add_node(self, parent_id, node, index=None, notify=True):
        parent = self.find(parent_id)
        if parent is None:
            raise DocumentError("Parent no longer exists.")
        if not self.can_parent(parent.node_type, node.node_type):
            raise DocumentError(f"{node.node_type.title()} cannot be placed inside {parent.node_type}.")
        if node is parent or any(candidate is parent for candidate in node.walk()):
            raise DocumentError("A node cannot contain itself.")
        if node.parent is not None and node in node.parent.children:
            node.parent.children.remove(node)
        node.parent = parent
        if index is None:
            parent.children.append(node)
        else:
            parent.children.insert(max(0, min(index, len(parent.children))), node)
        if notify:
            self.notify("add", node)
        return node

    def create_node(self, node_type, parent_id, properties=None, index=None):
        props = default_properties(node_type)
        props.update(copy.deepcopy(properties or {}))
        node = DesignerNode(node_type, props)
        if node_type == "tab_widget":
            page = DesignerNode("tab", default_properties("tab"), parent=node)
            node.children.append(page)
        return self.add_node(parent_id, node, index)

    def remove_node(self, node_id, notify=True):
        node = self.find(node_id)
        if node is None or node is self.root or node.parent is None:
            raise DocumentError("The selected node cannot be removed.")
        parent = node.parent
        index = parent.children.index(node)
        parent.children.pop(index)
        node.parent = None
        if notify:
            self.notify("remove", parent)
        return node, parent.node_id, index

    def reparent(self, node_id, parent_id, index=None, notify=True):
        node = self.find(node_id)
        parent = self.find(parent_id)
        if node is None or parent is None:
            raise DocumentError("Move target no longer exists.")
        if any(candidate is parent for candidate in node.walk()):
            raise DocumentError("A node cannot be moved inside itself.")
        if not self.can_parent(parent.node_type, node.node_type):
            raise DocumentError(f"{node.node_type.title()} cannot be placed inside {parent.node_type}.")
        old_parent = node.parent
        old_index = old_parent.children.index(node)
        old_parent.children.pop(old_index)
        node.parent = None
        self.add_node(parent_id, node, index, notify=False)
        if notify:
            self.notify("reparent", node)
        return old_parent.node_id, old_index

    def set_property(self, node_id, key, value, notify=True):
        node = self.find(node_id)
        if node is None:
            raise DocumentError("Selected node no longer exists.")
        old = copy.deepcopy(node.get_property(key))
        node.set_property(key, copy.deepcopy(value))
        if notify:
            self.notify("property", node)
        return old

    def delete_property(self, node_id, key, notify=True):
        node = self.find(node_id)
        if node is None:
            raise DocumentError("Selected node no longer exists.")
        node.delete_property(key)
        if notify:
            self.notify("property", node)

    @property
    def is_dirty(self):
        return self.to_config() != self.saved_snapshot

    def mark_saved(self):
        self.saved_snapshot = self.to_config()
        self.source_config = copy.deepcopy(self.saved_snapshot)
        self.notify("saved", self.root)

    def mark_applied(self):
        self.applied_snapshot = self.to_config()
        self.notify("applied", self.root)

    def restore_saved(self):
        restored = DesignerDocument.from_config(self.saved_snapshot)
        self.root = restored.root
        self._selected_ids = []
        self.source_config = copy.deepcopy(self.saved_snapshot)
        self.notify("revert", self.root)

    def replace_working_root(self, root):
        """Replace the editable tree without changing the saved baseline.

        Keeping this operation on the existing document lets every designer
        view retain its document reference. Cloning with stable IDs is
        important: commands on either side of an import must still find their
        nodes after the import itself is undone or redone.
        """
        self.root = root.clone(fresh_ids=False)
        self._selected_ids = []
        self.notify("replace", self.root)

    @property
    def selected_ids(self):
        return list(self._selected_ids)

    def set_selection(self, node_ids: Iterable[str]):
        valid = [node_id for node_id in node_ids if self.find(node_id)]
        if valid != self._selected_ids:
            self._selected_ids = valid
            self.notify("selection", self.find(valid[0]) if valid else None)
