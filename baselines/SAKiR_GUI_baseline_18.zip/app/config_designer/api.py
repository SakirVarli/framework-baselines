"""Public GUI API for the visual configuration designer.

Import from this module when opening the designer or using its shared parsing
and schema helpers.
"""

from .window import ConfigDesignerWindow
from .parsing import PropertyParseError, parse_optional_int, parse_property
from .schema import FEATURES

__all__ = [
    "ConfigDesignerWindow",
    "FEATURES",
    "PropertyParseError",
    "parse_optional_int",
    "parse_property",
]
