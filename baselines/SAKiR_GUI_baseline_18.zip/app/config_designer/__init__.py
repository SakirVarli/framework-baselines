"""Visual configuration designer.

The GUI window is exposed by :mod:`app.config_designer.api`, while this package
root keeps document and validation utilities usable in headless environments.
"""

from .document import DesignerDocument
from .nodes import DesignerNode
from .validation import ValidationIssue, validate_document

__all__ = ["DesignerDocument", "DesignerNode", "ValidationIssue", "validate_document"]
