from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional
import copy
import uuid

from .schema import CONTAINER_TYPES


@dataclass
class DesignerNode:
    node_type: str
    properties: Dict[str, Any] = field(default_factory=dict)
    children: List["DesignerNode"] = field(default_factory=list)
    node_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    parent: Optional["DesignerNode"] = field(default=None, repr=False, compare=False)
    metadata: Dict[str, Any] = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self):
        for child in self.children:
            child.parent = self

    @property
    def label(self):
        if self.node_type == "root":
            return "Configuration"
        return str(self.properties.get("name") or self.properties.get("instance") or self.node_type.title())

    @property
    def is_container(self):
        return self.node_type in CONTAINER_TYPES

    def walk(self) -> Iterable["DesignerNode"]:
        yield self
        for child in self.children:
            yield from child.walk()

    def find(self, node_id):
        return next((node for node in self.walk() if node.node_id == node_id), None)

    def get_property(self, path, default=None):
        value = self.properties
        for part in path.split("."):
            if not isinstance(value, dict) or part not in value:
                return default
            value = value[part]
        return value

    def has_property(self, path):
        value = self.properties
        for part in path.split("."):
            if not isinstance(value, dict) or part not in value:
                return False
            value = value[part]
        return True

    def set_property(self, path, value):
        target = self.properties
        parts = path.split(".")
        for part in parts[:-1]:
            child = target.get(part)
            if not isinstance(child, dict):
                child = {}
                target[part] = child
            target = child
        target[parts[-1]] = value

    def delete_property(self, path):
        parts = path.split(".")
        target = self.properties
        parents = []
        for part in parts[:-1]:
            if not isinstance(target, dict) or part not in target:
                return
            parents.append((target, part))
            target = target[part]
        if isinstance(target, dict):
            target.pop(parts[-1], None)
        for parent, key in reversed(parents):
            child = parent.get(key)
            if isinstance(child, dict) and not child:
                parent.pop(key, None)
            else:
                break

    def clone(self, fresh_ids=True):
        cloned = DesignerNode(
            self.node_type, copy.deepcopy(self.properties),
            [child.clone(fresh_ids) for child in self.children],
            uuid.uuid4().hex if fresh_ids else self.node_id,
        )
        cloned.metadata = copy.deepcopy(self.metadata)
        return cloned
