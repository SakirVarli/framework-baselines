from dataclasses import dataclass
import ast
import os
import re

from app.utils import sanitize_func_name
from .callback_manager import (
    available_callback_symbols, empty_top_level_functions,
    top_level_function_references,
)
from .document import ALLOWED_CHILDREN
from .schema import FEATURES


@dataclass(frozen=True)
class ValidationIssue:
    severity: str
    code: str
    message: str
    node_id: str = ""
    action: str = ""
    action_target: str = ""
    actions: tuple = ()
    previous_target: str = ""

    @property
    def blocking(self):
        return self.severity == "error"


def _position(value):
    if not isinstance(value, list) or len(value) not in (2, 4):
        return None
    if any(isinstance(x, bool) or not isinstance(x, int) for x in value):
        return None
    return value if len(value) == 4 else value + [1, 1]


def _derived_grid(node):
    explicit = node.properties.get("grid")
    if isinstance(explicit, list) and len(explicit) == 2:
        return explicit
    max_row = max_col = 1
    for child in node.children:
        pos = _position(child.properties.get("pos"))
        if pos:
            max_row = max(max_row, pos[0] + pos[2])
            max_col = max(max_col, pos[1] + pos[3])
    return [max_row, max_col]


def _layout_mode(node):
    return node.get_property("layout.mode", "grid") if node else "grid"


def validate_document(document, callback_source=None, project_root=None,
                      callback_migrations=None):
    issues = []
    ids = set()
    tab_names = {}
    tab_widgets = set()
    outputs = set()
    infos = set()
    callback_owners = {}
    callback_migrations = callback_migrations or {}

    for node in document.root.walk():
        if node.node_id in ids:
            issues.append(ValidationIssue("error", "duplicate-id", "Duplicate designer ID.", node.node_id))
        ids.add(node.node_id)
        parent_type = node.parent.node_type if node.parent else ""
        if node is not document.root and node.node_type not in ALLOWED_CHILDREN.get(parent_type, set()):
            issues.append(ValidationIssue(
                "error", "invalid-hierarchy",
                f"{node.node_type.title()} cannot be inside {parent_type or 'nothing'}.", node.node_id))
        if node.node_type not in FEATURES:
            issues.append(ValidationIssue("error", "unknown-type",
                                          f"Unknown widget type '{node.node_type}'.", node.node_id))
            continue
        if node.node_type == "tab_widget":
            instance = str(node.properties.get("instance", "")).strip()
            if not instance:
                issues.append(ValidationIssue(
                    "error", "missing-instance", "Tab widget instance is required.", node.node_id))
            elif instance in tab_widgets:
                issues.append(ValidationIssue(
                    "error", "duplicate-tab-widget",
                    f"Duplicate tab widget instance '{instance}'.", node.node_id))
            tab_widgets.add(instance)
            position = node.properties.get("tabPosition", "top")
            orientation = node.properties.get("tabTextOrientation", "native")
            if position not in {"top", "bottom", "left", "right"}:
                issues.append(ValidationIssue(
                    "error", "invalid-tab-position",
                    f"Unknown tab header position '{position}'.", node.node_id))
            if orientation not in {"native", "horizontal"}:
                issues.append(ValidationIssue(
                    "error", "invalid-tab-orientation",
                    f"Unknown tab text orientation '{orientation}'.", node.node_id))
        if node.node_type == "tab":
            name = str(node.properties.get("name", "")).strip()
            owner_names = tab_names.setdefault(node.parent.node_id if node.parent else "", set())
            if not name:
                issues.append(ValidationIssue("error", "missing-name", "Tab name is required.", node.node_id))
            elif name in owner_names:
                issues.append(ValidationIssue("error", "duplicate-tab", f"Duplicate tab name '{name}'.", node.node_id))
            owner_names.add(name)
        if node.node_type == "tab_widget" and not node.children:
            issues.append(ValidationIssue(
                "warning", "empty-tab-widget",
                f"Tab widget '{node.label}' has no pages.", node.node_id))
        if node.node_type in {"root", "tab", "group"}:
            mode = _layout_mode(node)
            if mode not in {"grid", "canvas"}:
                issues.append(ValidationIssue("error", "invalid-layout-mode",
                                              f"Unknown layout mode '{mode}'.", node.node_id))
                mode = "grid"
            if node is not document.root and not node.children:
                issues.append(ValidationIssue("warning", "empty-container",
                                              f"{node.node_type.title()} '{node.label}' is empty.", node.node_id))
            occupied = {}
            if mode == "grid":
                grid = _derived_grid(node)
                if (len(grid) != 2 or any(isinstance(x, bool) or not isinstance(x, int) or x <= 0 for x in grid)):
                    issues.append(ValidationIssue("error", "invalid-grid", "Grid dimensions must be positive integers.", node.node_id))
                    grid = [1, 1]
                for child in node.children:
                    pos = _position(child.properties.get("pos"))
                    if pos is None:
                        issues.append(ValidationIssue("error", "invalid-position",
                                                      f"'{child.label}' has an invalid grid position.", child.node_id))
                        continue
                    row, col, row_span, col_span = pos
                    if row < 0 or col < 0 or row_span <= 0 or col_span <= 0:
                        issues.append(ValidationIssue("error", "invalid-span",
                                                      f"'{child.label}' has a negative position or non-positive span.", child.node_id))
                    elif row + row_span > grid[0] or col + col_span > grid[1]:
                        issues.append(ValidationIssue("error", "outside-grid",
                                                      f"'{child.label}' exceeds its {grid[0]}×{grid[1]} parent grid.", child.node_id))
                    for r in range(max(0, row), max(0, row + row_span)):
                        for c in range(max(0, col), max(0, col + col_span)):
                            other = occupied.setdefault((r, c), child)
                            if other is not child:
                                issues.append(ValidationIssue("error", "overlap",
                                    f"'{child.label}' overlaps '{other.label}' at ({r}, {c}).", child.node_id))
                                break
            else:
                bounds = node.properties.get("bounds") if node.node_type == "group" else None
                design_size = node.get_property("layout.designSize")
                if not (isinstance(design_size, list) and len(design_size) == 2):
                    design_size = (
                        bounds[2:4]
                        if isinstance(bounds, list) and len(bounds) == 4
                        else [1200, 800])
                if (not isinstance(design_size, list) or len(design_size) != 2 or
                        any(isinstance(x, bool) or not isinstance(x, int) or x <= 0 for x in design_size)):
                    issues.append(ValidationIssue("error", "invalid-design-size",
                                                  "Canvas design size must contain two positive integers.", node.node_id))
                    design_size = [1, 1]
                for child in node.children:
                    bounds = child.properties.get("bounds")
                    if (not isinstance(bounds, list) or len(bounds) != 4 or
                            any(isinstance(x, bool) or not isinstance(x, int) for x in bounds)):
                        issues.append(ValidationIssue("error", "invalid-bounds",
                                                      f"'{child.label}' requires X, Y, width and height.", child.node_id))
                        continue
                    x, y, width, height = bounds
                    if x < 0 or y < 0 or width <= 0 or height <= 0:
                        issues.append(ValidationIssue("error", "invalid-bounds",
                                                      f"'{child.label}' has negative coordinates or a non-positive size.", child.node_id))
                    elif x + width > design_size[0] or y + height > design_size[1]:
                        issues.append(ValidationIssue("warning", "outside-canvas",
                                                      f"'{child.label}' extends beyond the design canvas.", child.node_id))
                    anchors = child.properties.get("anchors", ["left", "top"])
                    if (not isinstance(anchors, list) or not anchors or
                            any(anchor not in {"left", "right", "top", "bottom"} for anchor in anchors)):
                        issues.append(ValidationIssue("error", "invalid-anchors",
                                                      f"'{child.label}' has invalid anchors.", child.node_id))
        if node.node_type in {"output", "info"}:
            instance = str(node.properties.get("instance", "")).strip()
            seen = outputs if node.node_type == "output" else infos
            if not instance:
                issues.append(ValidationIssue("error", "missing-instance", "Instance name is required.", node.node_id))
            elif instance in seen:
                issues.append(ValidationIssue("error", "duplicate-instance",
                                              f"Duplicate {node.node_type} instance '{instance}'.", node.node_id))
            seen.add(instance)
        if node.node_type == "button":
            name = str(node.properties.get("name", "")).strip()
            callback = str(node.properties.get("callback") or sanitize_func_name(name)).strip()
            if not name:
                issues.append(ValidationIssue("error", "missing-name", "Button label is required.", node.node_id))
            if not callback.isidentifier():
                issues.append(ValidationIssue("error", "invalid-callback",
                                              f"'{callback}' is not a valid callback name.", node.node_id))
            else:
                callback_owners.setdefault(callback, []).append(node)

        for key, meta in FEATURES.get(node.node_type, {}).items():
            value = node.get_property(key)
            effective = meta.get("default") if value is None and "." in key else value
            geometry_optional = (
                key == "pos" and node.parent and _layout_mode(node.parent) == "canvas")
            if meta.get("required") and not geometry_optional and (effective is None or effective == ""):
                issues.append(ValidationIssue("error", "required",
                                              f"'{node.label}' requires {meta['label']}.", node.node_id))
            value = effective
            if meta["type"] == "color" and value and not re.fullmatch(r"#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?", str(value)):
                issues.append(ValidationIssue("error", "invalid-color",
                                              f"'{value}' is not a valid hex color.", node.node_id))
            if meta["type"] == "int" and value is not None and (isinstance(value, bool) or not isinstance(value, int)):
                issues.append(ValidationIssue("error", "invalid-integer",
                                              f"{meta['label']} must be an integer.", node.node_id))
            if meta["type"] == "shortcut" and value:
                if not isinstance(value, str) or ",," in value or value.startswith("+") or value.endswith("+"):
                    issues.append(ValidationIssue("error", "invalid-shortcut",
                                                  f"'{value}' is not a valid shortcut.", node.node_id))
            if meta["type"] == "file" and value and project_root:
                path = value if os.path.isabs(value) else os.path.join(project_root, value)
                if not os.path.isfile(path):
                    issues.append(ValidationIssue("error", "missing-file", f"File not found: {value}", node.node_id))

    if callback_source is not None:
        try:
            tree = ast.parse(callback_source)
            defined = {item.name for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))}
            available = available_callback_symbols(callback_source)
            empty = empty_top_level_functions(callback_source)
            for callback, owners in callback_owners.items():
                if callback not in available:
                    migrated = [owner for owner in owners
                                if callback_migrations.get(owner.node_id)]
                    for owner in migrated or owners[:1]:
                        previous = callback_migrations.get(owner.node_id, "")
                        actions = ["generate-callback"]
                        if previous and previous != callback and previous in available:
                            actions.append("keep-previous-callback")
                            previous_is_shared = bool(callback_owners.get(previous))
                            references = (
                                top_level_function_references(callback_source, previous)
                                if previous in defined else ())
                            if previous in defined and not previous_is_shared and not references:
                                actions.append("rename-previous-callback")
                            message = (
                                f"Button '{owner.label}' was rebound from '{previous}' to missing "
                                f"callback '{callback}'. It will be generated on Save.")
                            if previous_is_shared:
                                message += " The previous callback is still used by another button."
                            elif references:
                                message += " The previous function is referenced by Python code and cannot be renamed safely."
                        else:
                            message = (
                                f"Button '{owner.label}' is bound to missing callback "
                                f"'{callback}'. It will be generated on Save.")
                        issues.append(ValidationIssue(
                            "warning", "missing-callback", message, owner.node_id,
                            action_target=callback, actions=tuple(actions),
                            previous_target=previous))
            for callback, owners in sorted(callback_owners.items()):
                if len(owners) > 1:
                    labels = ", ".join(f"'{owner.label}'" for owner in owners)
                    issues.append(ValidationIssue(
                        "warning", "shared-callback",
                        f"Callback '{callback}' is shared by {len(owners)} buttons: {labels}. "
                        "All of them will execute the same function.", owners[0].node_id))
            for callback in sorted(defined):
                if callback.startswith("btn_") and callback.endswith("_callback") and callback not in callback_owners:
                    if callback in empty:
                        issues.append(ValidationIssue(
                            "warning", "empty-callback",
                            f"Empty callback '{callback}' is not assigned to a button.",
                            action="delete-callback", action_target=callback))
                    else:
                        issues.append(ValidationIssue(
                            "warning", "unused-callback",
                            f"Callback '{callback}' is not assigned to a button."))
        except SyntaxError as error:
            issues.append(ValidationIssue("error", "malformed-callbacks",
                                          f"callbacks.py is invalid at line {error.lineno}: {error.msg}"))
    return issues
