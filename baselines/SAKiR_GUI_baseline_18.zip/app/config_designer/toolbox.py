from PyQt5 import QtCore, QtGui, QtWidgets

from app.branding import mime_type

MIME_TYPE = mime_type("designer-widget")


class ToolboxList(QtWidgets.QListWidget):
    ITEMS = [
        ("Tab Widget", "tab_widget", "▤"),
        ("Group", "group", "▣"),
        ("Button", "button", "▰"),
        ("Output", "output", "▤"),
        ("Info Panel", "info", "ⓘ"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("DesignerToolbox")
        self.setDragEnabled(True)
        self.setSpacing(3)
        self.setIconSize(QtCore.QSize(24, 24))
        for label, node_type, glyph in self.ITEMS:
            pixmap = QtGui.QPixmap(28, 28)
            pixmap.fill(QtCore.Qt.transparent)
            painter = QtGui.QPainter(pixmap)
            painter.setRenderHint(QtGui.QPainter.Antialiasing)
            painter.setPen(QtGui.QColor("#4f7cac"))
            painter.setFont(QtGui.QFont("Segoe UI Symbol", 15))
            painter.drawText(pixmap.rect(), QtCore.Qt.AlignCenter, glyph)
            painter.end()
            item = QtWidgets.QListWidgetItem(QtGui.QIcon(pixmap), label)
            item.setData(QtCore.Qt.UserRole, node_type)
            item.setToolTip(
                f"Drag a {label.lower()} onto the window, a tab page, or a group.")
            self.addItem(item)

    def mimeData(self, items):
        mime = QtCore.QMimeData()
        if items:
            mime.setData(MIME_TYPE, items[0].data(QtCore.Qt.UserRole).encode("utf-8"))
        return mime

    def supportedDropActions(self):
        return QtCore.Qt.CopyAction
