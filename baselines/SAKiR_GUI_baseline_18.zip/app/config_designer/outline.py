from PyQt5 import QtCore, QtWidgets
from .commands import RenameCommand, ReparentCommand


class DocumentOutline(QtWidgets.QTreeWidget):
    def __init__(self, document, undo_stack, parent=None):
        super().__init__(parent)
        self.document = document
        self.undo_stack = undo_stack
        self.setHeaderHidden(True)
        self.setSelectionMode(self.ExtendedSelection)
        self.setDragDropMode(self.DragDrop)
        self.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.itemSelectionChanged.connect(self._selection_changed)
        self.itemChanged.connect(self._item_renamed)
        self.document.on_change(self._document_changed)
        self.rebuild()

    def rebuild(self):
        selected = set(self.document.selected_ids)
        self.blockSignals(True)
        self.clear()
        root_item = QtWidgets.QTreeWidgetItem(["Window"])
        root_item.setData(0, QtCore.Qt.UserRole, self.document.root.node_id)
        root_item.setToolTip(0, "Application window design surface")
        self.addTopLevelItem(root_item)
        for node in self.document.root.children:
            self._add_node(root_item, node)
        self.expandAll()
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        while iterator.value():
            item = iterator.value()
            item.setSelected(item.data(0, QtCore.Qt.UserRole) in selected)
            iterator += 1
        self.blockSignals(False)

    def _add_node(self, parent_item, node):
        item = QtWidgets.QTreeWidgetItem([node.label])
        item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)
        item.setData(0, QtCore.Qt.UserRole, node.node_id)
        item.setToolTip(0, node.node_type.title())
        if parent_item is None:
            self.addTopLevelItem(item)
        else:
            parent_item.addChild(item)
        for child in node.children:
            self._add_node(item, child)

    def _selection_changed(self):
        ids = [item.data(0, QtCore.Qt.UserRole) for item in self.selectedItems()]
        self.document.set_selection(ids)

    def _item_renamed(self, item):
        node = self.document.find(item.data(0, QtCore.Qt.UserRole))
        if not node or node.node_type == "root":
            return
        key = "instance" if node.node_type in {"output", "info"} else "name"
        new_value = item.text(0).strip()
        if new_value and new_value != str(node.properties.get(key, "")):
            self.undo_stack.push(RenameCommand(
                self.document, node.node_id, key, new_value))

    def _document_changed(self, reason, node):
        if reason != "selection":
            self.rebuild()
            return
        selected = set(self.document.selected_ids)
        self.blockSignals(True)
        iterator = QtWidgets.QTreeWidgetItemIterator(self)
        while iterator.value():
            item = iterator.value()
            item.setSelected(item.data(0, QtCore.Qt.UserRole) in selected)
            iterator += 1
        self.blockSignals(False)

    def dropEvent(self, event):
        source = self.currentItem()
        target = self.itemAt(event.pos())
        if not source or not target or source is target:
            event.ignore()
            return
        node = self.document.find(source.data(0, QtCore.Qt.UserRole))
        target_node = self.document.find(target.data(0, QtCore.Qt.UserRole))
        if not node or not target_node:
            event.ignore()
            return
        parent = target_node if target_node.node_type in {"tab", "group"} else target_node.parent
        if not parent or not self.document.can_parent(parent.node_type, node.node_type):
            event.ignore()
            return
        self.undo_stack.push(ReparentCommand(self.document, node.node_id, parent.node_id))
        event.acceptProposedAction()
