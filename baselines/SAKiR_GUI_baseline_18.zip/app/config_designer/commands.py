"""QUndoStack commands that mutate the central document."""

from copy import deepcopy
from PyQt5 import QtWidgets


class AddNodeCommand(QtWidgets.QUndoCommand):
    def __init__(self, document, parent_id, node, index=None, text="Add item"):
        super().__init__(text)
        self.document, self.parent_id, self.node, self.index = document, parent_id, node, index

    def redo(self):
        self.document.add_node(self.parent_id, self.node, self.index)

    def undo(self):
        self.document.remove_node(self.node.node_id)


class DeleteNodeCommand(QtWidgets.QUndoCommand):
    def __init__(self, document, node_id):
        node = document.find(node_id)
        super().__init__(f"Delete {node.label if node else 'item'}")
        self.document, self.node_id = document, node_id
        self.node = self.parent_id = self.index = None

    def redo(self):
        self.node, self.parent_id, self.index = self.document.remove_node(self.node_id)

    def undo(self):
        self.document.add_node(self.parent_id, self.node, self.index)


class CallbackSourceCommand(QtWidgets.QUndoCommand):
    """Replace the designer's working callbacks source with Undo support."""

    def __init__(self, setter, old_source, new_source, text="Edit callbacks"):
        super().__init__(text)
        self.setter = setter
        self.old_source = old_source
        self.new_source = new_source

    def redo(self):
        self.setter(self.new_source)

    def undo(self):
        self.setter(self.old_source)


class ReplaceDocumentCommand(QtWidgets.QUndoCommand):
    """Replace the complete working configuration as one undoable edit."""

    def __init__(self, document, replacement, text="Import config.json"):
        super().__init__(text)
        self.document = document
        self.old_root = document.root.clone(fresh_ids=False)
        self.new_root = replacement.root.clone(fresh_ids=False)

    def redo(self):
        self.document.replace_working_root(self.new_root)

    def undo(self):
        self.document.replace_working_root(self.old_root)


class PropertyCommand(QtWidgets.QUndoCommand):
    def __init__(self, document, node_ids, key, value, text=None):
        super().__init__(text or f"Change {key}")
        self.document, self.node_ids, self.key = document, list(node_ids), key
        self.new_value = deepcopy(value)
        self.old_values = {
            node_id: (
                document.find(node_id).has_property(key),
                deepcopy(document.find(node_id).get_property(key)),
            )
            for node_id in self.node_ids
        }

    def redo(self):
        for node_id in self.node_ids:
            self.document.set_property(node_id, self.key, self.new_value, notify=False)
        self.document.notify("property", self.document.find(self.node_ids[0]))

    def undo(self):
        for node_id, (existed, value) in self.old_values.items():
            if existed:
                self.document.set_property(node_id, self.key, value, notify=False)
            else:
                self.document.delete_property(node_id, self.key, notify=False)
        self.document.notify("property", self.document.find(self.node_ids[0]))

    def id(self):
        return hash(("property", tuple(self.node_ids), self.key)) & 0x7FFFFFFF

    def mergeWith(self, other):
        if not isinstance(other, PropertyCommand):
            return False
        if self.node_ids != other.node_ids or self.key != other.key:
            return False
        self.new_value = deepcopy(other.new_value)
        return True


class ReparentCommand(QtWidgets.QUndoCommand):
    def __init__(self, document, node_id, parent_id, index=None):
        super().__init__("Move item")
        self.document, self.node_id = document, node_id
        self.new_parent, self.new_index = parent_id, index
        self.old_parent = self.old_index = None

    def redo(self):
        previous = self.document.reparent(self.node_id, self.new_parent, self.new_index)
        if self.old_parent is None:
            self.old_parent, self.old_index = previous

    def undo(self):
        self.document.reparent(self.node_id, self.old_parent, self.old_index)


class GeometryCommand(PropertyCommand):
    def __init__(self, document, node_id, position, text="Move/resize item"):
        super().__init__(document, [node_id], "pos", position, text)


class BoundsCommand(PropertyCommand):
    def __init__(self, document, node_id, bounds, text="Move/resize item"):
        super().__init__(document, [node_id], "bounds", bounds, text)


class RenameCommand(PropertyCommand):
    def __init__(self, document, node_id, key, value):
        super().__init__(document, [node_id], key, value, "Rename item")


class PasteCommand(AddNodeCommand):
    pass
