"""Strict property parsing. User input is never evaluated as Python."""

import re


class PropertyParseError(ValueError):
    pass


def parse_optional_int(value):
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise PropertyParseError("Enter a whole number.")
    if isinstance(value, int):
        return value
    text = str(value).strip()
    if not re.fullmatch(r"[+-]?\d+", text):
        raise PropertyParseError("Enter a whole number.")
    return int(text, 10)


def parse_int_list(value, lengths, label):
    if isinstance(value, (list, tuple)):
        parts = list(value)
    else:
        parts = [part.strip() for part in str(value).split(",")]
    if len(parts) not in set(lengths):
        expected = " or ".join(str(n) for n in lengths)
        raise PropertyParseError(f"{label} needs {expected} comma-separated integers.")
    try:
        parsed = [parse_optional_int(part) for part in parts]
    except PropertyParseError:
        raise PropertyParseError(f"{label} accepts integers only.") from None
    if any(value is None for value in parsed):
        raise PropertyParseError(f"{label} accepts integers only.")
    return parsed


def parse_property(kind, value):
    if kind == "int":
        return parse_optional_int(value)
    if kind == "pos":
        parsed = parse_int_list(value, (2, 4), "Position")
        return parsed if len(parsed) == 4 else parsed + [1, 1]
    if kind == "grid":
        if value in (None, ""):
            return None
        return parse_int_list(value, (2,), "Grid")
    if kind == "size":
        parsed = parse_int_list(value, (2,), "Size")
        if any(item <= 0 for item in parsed):
            raise PropertyParseError("Size values must be positive.")
        return parsed
    if kind == "rect":
        parsed = parse_int_list(value, (4,), "Bounds")
        if parsed[2] <= 0 or parsed[3] <= 0:
            raise PropertyParseError("Width and height must be positive.")
        return parsed
    if kind == "anchors":
        if isinstance(value, (list, tuple)):
            parts = [str(part).strip().lower() for part in value]
        else:
            parts = [part.strip().lower() for part in str(value).split(",") if part.strip()]
        valid = {"left", "right", "top", "bottom"}
        if not parts or any(part not in valid for part in parts):
            raise PropertyParseError("Anchors may contain left, right, top and bottom.")
        return list(dict.fromkeys(parts))
    if kind == "bool":
        if isinstance(value, bool):
            return value
        lowered = str(value).strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            return True
        if lowered in {"false", "0", "no", "off"}:
            return False
        raise PropertyParseError("Choose True or False.")
    if kind == "color":
        text = "" if value is None else str(value).strip()
        if text and not re.fullmatch(r"#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?", text):
            raise PropertyParseError("Use a hex color such as #336699.")
        return text
    if kind == "shortcut":
        text = "" if value is None else str(value).strip()
        if ",," in text or text.startswith("+") or text.endswith("+"):
            raise PropertyParseError("Enter a valid keyboard shortcut.")
        return text
    return "" if value is None else str(value)
