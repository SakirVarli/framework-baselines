"""AST-based callback analysis and conservative stub generation."""

from dataclasses import dataclass
import ast
import re

from app.utils import sanitize_func_name
from .config_structure import iter_widget_definitions


@dataclass(frozen=True)
class CallbackAnalysis:
    required: tuple
    existing: tuple
    missing: tuple
    unused: tuple
    collisions: dict


def callback_name(button):
    return str(button.get("callback") or sanitize_func_name(button.get("name", "")))


def iter_buttons(config):
    for widget in iter_widget_definitions(config):
        if widget.get("type") == "button":
            yield widget


def top_level_functions(source):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    result = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            start = node.lineno - 1
            if node.decorator_list:
                start = min(item.lineno for item in node.decorator_list) - 1
            end = node.end_lineno or node.lineno
            result[node.name] = (sum(map(len, lines[:start])), sum(map(len, lines[:end])))
    return result


def imported_callback_symbols(source):
    """Names made directly available by ``from module import name``."""
    tree = ast.parse(source)
    return {
        alias.asname or alias.name
        for node in tree.body if isinstance(node, ast.ImportFrom)
        for alias in node.names if alias.name != "*"
    }


def available_callback_symbols(source):
    return set(top_level_functions(source)) | imported_callback_symbols(source)


def top_level_function_references(source, function_name):
    """Line numbers that reference a function binding outside its definition."""
    tree = ast.parse(source)
    return tuple(sorted({
        node.lineno for node in ast.walk(tree)
        if isinstance(node, ast.Name) and node.id == function_name
        and isinstance(node.ctx, ast.Load)
    }))


def rename_top_level_function(source, old_name, new_name):
    """Rename one top-level function declaration without rewriting user code."""
    if not old_name.isidentifier() or not new_name.isidentifier():
        raise ValueError("Callback names must be valid Python identifiers.")
    if new_name in available_callback_symbols(source):
        raise ValueError(f"Callback '{new_name}' already exists.")
    if top_level_function_references(source, old_name):
        raise ValueError(
            f"Callback '{old_name}' is referenced by Python code and cannot be renamed safely.")
    tree = ast.parse(source)
    node = next((item for item in tree.body
                 if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                 and item.name == old_name), None)
    if node is None:
        raise ValueError(f"Callback '{old_name}' is not defined in callbacks.py.")
    lines = source.splitlines(keepends=True)
    line_index = node.lineno - 1
    pattern = re.compile(
        rf"^(\s*(?:async\s+)?def\s+){re.escape(old_name)}\b")
    updated_line, count = pattern.subn(
        rf"\g<1>{new_name}", lines[line_index], count=1)
    if count != 1:
        raise ValueError(f"Could not locate the declaration for '{old_name}'.")
    lines[line_index] = updated_line
    updated = "".join(lines)
    compile(updated, "callbacks.py", "exec")
    return updated


def append_empty_callback(source, function_name):
    if not function_name.isidentifier():
        raise ValueError(f"Invalid callback name: {function_name}")
    if function_name in available_callback_symbols(source):
        return source
    updated = source.rstrip() + (
        f"\n\n\ndef {function_name}():\n"
        '    """Generated callback stub. This body is safe to edit."""\n'
        "    pass\n"
    )
    compile(updated, "callbacks.py", "exec")
    return updated


def empty_top_level_functions(source):
    """Return top-level functions whose bodies contain no executable work.

    A docstring and ``pass`` are treated as empty.  The deliberately narrow
    definition prevents the designer from offering to delete callbacks that
    contain user code.
    """
    tree = ast.parse(source)
    empty = set()
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        statements = list(node.body)
        if (statements and isinstance(statements[0], ast.Expr) and
                isinstance(statements[0].value, ast.Constant) and
                isinstance(statements[0].value.value, str)):
            statements.pop(0)
        if not statements or all(isinstance(item, ast.Pass) for item in statements):
            empty.add(node.name)
    return empty


def analyze_callbacks(config, source):
    functions = top_level_functions(source)
    available = available_callback_symbols(source)
    owners = {}
    collisions = {}
    for button in iter_buttons(config):
        name = callback_name(button)
        if name in owners:
            collisions.setdefault(name, [owners[name]]).append(button.get("name", ""))
        else:
            owners[name] = button.get("name", "")
    required = set(owners)
    existing = set(available)
    managed_existing = {
        name for name in functions
        if name.startswith("btn_") and name.endswith("_callback")
    }
    return CallbackAnalysis(
        tuple(sorted(required)), tuple(sorted(existing)),
        tuple(sorted(required - existing)),
        tuple(sorted(managed_existing - required)),
        collisions,
    )


def prepare_callback_source(config, source):
    """Append missing stubs without renaming or deleting any user function."""
    analysis = analyze_callbacks(config, source)
    updated = source.rstrip()
    for name in analysis.missing:
        if not name.isidentifier():
            raise ValueError(f"Invalid callback name: {name}")
        updated += (
            f"\n\n\ndef {name}():\n"
            '    """Generated callback stub. This body is safe to edit."""\n'
            "    pass"
        )
    updated += "\n"
    compile(updated, "callbacks.py", "exec")
    return updated, analysis


def remove_top_level_function(source, function_name):
    """Remove exactly one AST-delimited top-level function.

    This is intentionally opt-in; normal saves never remove unused callbacks.
    Adjacent helpers and comments outside the function boundary are preserved.
    """
    bounds = top_level_functions(source)
    if function_name not in bounds:
        return source
    start, end = bounds[function_name]
    updated = source[:start] + source[end:]
    compile(updated, "callbacks.py", "exec")
    return updated
