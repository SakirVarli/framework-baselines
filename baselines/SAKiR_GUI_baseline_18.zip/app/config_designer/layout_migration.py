"""Silent measurement-based migration from Qt grids to canvas layouts."""

from PyQt5 import QtCore, QtWidgets

from .canvas_layout import CanvasLayout
from app.tab_widgets import configure_tab_widget
from .preview_factory import create_preview_widget


SPATIAL_CONTAINERS = {"root", "tab", "group"}


def _layout_mode(node):
    default = "canvas" if node.node_type == "root" else "grid"
    return node.get_property("layout.mode", default)


def has_grid_layouts(document):
    return any(
        node.node_type in SPATIAL_CONTAINERS and _layout_mode(node) != "canvas"
        for node in document.root.walk()
    )


def migrate_grid_layouts(document, reference_size=(1200, 800)):
    """Measure every grid container and replace it with equivalent canvas bounds.

    Original ``grid`` and child ``pos`` values remain in the document as
    compatibility metadata, while runtime placement switches to measured
    ``bounds``. Returns ``True`` when at least one container was migrated.
    """
    if not has_grid_layouts(document):
        return False
    probe = _LayoutProbe(document, reference_size)
    try:
        measurements = probe.capture()
    finally:
        probe.dispose()
    changed = False
    for container in document.root.walk():
        if (container.node_type not in SPATIAL_CONTAINERS or
                _layout_mode(container) == "canvas"):
            continue
        measurement = measurements.get(container.node_id)
        if not measurement:
            continue
        design_size, child_bounds = measurement
        design_size = _containing_design_size(design_size, child_bounds)
        layout = container.properties.setdefault("layout", {})
        layout.update({
            "mode": "canvas",
            "designSize": design_size,
            # Scaling most closely preserves a grid's proportional row/column
            # behavior after the exact reference-size geometry is captured.
            "resizeMode": "scale",
            "snap": int(layout.get("snap", 8) or 8),
        })
        for child in container.children:
            bounds = child_bounds.get(child.node_id)
            if bounds:
                child.properties["bounds"] = bounds
        changed = True
    return changed


def _containing_design_size(design_size, child_bounds):
    """Expand a migrated canvas so every measured child remains contained."""
    width = max(1, int(design_size[0]))
    height = max(1, int(design_size[1]))
    for bounds in child_bounds.values():
        if not isinstance(bounds, list) or len(bounds) != 4:
            continue
        x, y, child_width, child_height = bounds
        width = max(width, int(x) + max(1, int(child_width)))
        height = max(height, int(y) + max(1, int(child_height)))
    return [width, height]


def capture_layout_geometries(document, reference_size=(1200, 800)):
    """Testing/diagnostic helper returning measured container geometries."""
    probe = _LayoutProbe(document, reference_size)
    try:
        return probe.capture()
    finally:
        probe.dispose()


class _LayoutProbe:
    """Build a hidden callback-free copy using the same Qt layout primitives."""

    def __init__(self, document, reference_size):
        self.document = document
        self.reference_size = [
            max(1, int(reference_size[0])), max(1, int(reference_size[1]))]
        self.layouts = {}
        self.widgets = {}
        self.tab_widgets = {}
        self.root = self._build_container(document.root)
        self.root.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
        self.root.resize(*self.reference_size)
        self.root.show()
        QtWidgets.QApplication.processEvents()

    def dispose(self):
        self.root.hide()
        self.root.deleteLater()

    def capture(self):
        result = {}
        for container in self.document.root.walk():
            if container.node_type not in SPATIAL_CONTAINERS:
                continue
            self._reveal(container)
            layout = self.layouts.get(container.node_id)
            if layout is None:
                continue
            layout.activate()
            QtWidgets.QApplication.processEvents()
            geometry = layout.geometry()
            origin = geometry.topLeft()
            children = {}
            for child in container.children:
                widget = self.widgets.get(child.node_id)
                if widget is None:
                    continue
                rect = widget.geometry().translated(-origin)
                children[child.node_id] = [
                    rect.x(), rect.y(), max(1, rect.width()), max(1, rect.height())]
            result[container.node_id] = (
                [max(1, geometry.width()), max(1, geometry.height())], children)
        return result

    def _reveal(self, node):
        pages = []
        cursor = node
        while cursor:
            if (cursor.node_type == "tab" and cursor.parent and
                    cursor.parent.node_type == "tab_widget"):
                pages.append((cursor.parent, cursor))
            cursor = cursor.parent
        for tab_node, page in reversed(pages):
            widget = self.tab_widgets.get(tab_node.node_id)
            if widget is not None:
                index = tab_node.children.index(page)
                widget.setCurrentIndex(index)
        QtWidgets.QApplication.processEvents()

    def _build_container(self, node, parent=None):
        surface = (
            QtWidgets.QGroupBox(node.label, parent)
            if node.node_type == "group" else QtWidgets.QWidget(parent))
        if node.node_type == "root":
            surface.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
        self.widgets[node.node_id] = surface
        mode = _layout_mode(node)
        if mode == "canvas":
            definition = node.properties.get("layout") or {}
            design_size = definition.get("designSize")
            if node.node_type == "group" and not (
                    isinstance(design_size, list) and len(design_size) == 2):
                bounds = node.properties.get("bounds")
                if isinstance(bounds, list) and len(bounds) == 4:
                    design_size = bounds[2:4]
            design_size = design_size or [1200, 800]
            layout = CanvasLayout(
                design_size=design_size,
                resize_mode=definition.get("resizeMode", "anchors"))
            surface.setLayout(layout)
        else:
            layout = QtWidgets.QGridLayout(surface)
            if node.node_type == "tab":
                layout.setContentsMargins(6, 6, 6, 6)
                layout.setSpacing(6)
            if node.node_type in {"root", "tab"}:
                rows, columns = self._grid(node)
                for row in range(rows):
                    layout.setRowStretch(row, 1)
                for column in range(columns):
                    layout.setColumnStretch(column, 1)
        self.layouts[node.node_id] = layout
        for child in node.children:
            widget = self._build_widget(child, surface)
            self._apply_explicit_size(widget, child, mode)
            if isinstance(layout, CanvasLayout):
                layout.addWidgetDefinition(widget, child.properties)
            else:
                position = list(child.properties.get("pos") or [0, 0, 1, 1])
                position += [1] * (4 - len(position))
                layout.addWidget(
                    widget, position[0], position[1], position[2], position[3])
        return surface

    def _build_widget(self, node, parent):
        if node.node_type == "group":
            return self._build_container(node, parent)
        if node.node_type == "tab_widget":
            tabs = configure_tab_widget(
                QtWidgets.QTabWidget(parent), node.properties)
            self.widgets[node.node_id] = tabs
            self.tab_widgets[node.node_id] = tabs
            for page in node.children:
                surface = self._build_container(page)
                scroll = QtWidgets.QScrollArea(tabs)
                scroll.setWidgetResizable(True)
                scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
                scroll.setWidget(surface)
                tabs.addTab(scroll, page.label)
            return tabs
        widget = create_preview_widget(node, parent=parent)
        self.widgets[node.node_id] = widget
        return widget

    @staticmethod
    def _apply_explicit_size(widget, node, parent_mode):
        if parent_mode == "canvas":
            return
        width = node.properties.get("width")
        height = node.properties.get("height")
        width = width if isinstance(width, int) and not isinstance(width, bool) and width > 0 else None
        height = height if isinstance(height, int) and not isinstance(height, bool) and height > 0 else None
        if width and height:
            widget.setFixedSize(int(width), int(height))
        elif width:
            widget.setFixedWidth(int(width))
        elif height:
            widget.setFixedHeight(int(height))

    @staticmethod
    def _grid(node):
        grid = node.properties.get("grid")
        if isinstance(grid, list) and len(grid) == 2:
            return max(1, int(grid[0])), max(1, int(grid[1]))
        rows = columns = 1
        for child in node.children:
            position = list(child.properties.get("pos") or [0, 0, 1, 1])
            position += [1] * (4 - len(position))
            rows = max(rows, int(position[0]) + int(position[2]))
            columns = max(columns, int(position[1]) + int(position[3]))
        return rows, columns
