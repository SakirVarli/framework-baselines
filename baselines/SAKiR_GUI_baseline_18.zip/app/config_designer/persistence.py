"""Crash-safe paired config/callback persistence."""

from dataclasses import dataclass
import json
import os
from pathlib import Path
import shutil
import tempfile
import time


@dataclass(frozen=True)
class SaveResult:
    config_backup: str
    callbacks_backup: str


class AtomicConfigTransaction:
    def __init__(self, config_path, callbacks_path):
        self.config_path = Path(config_path)
        self.callbacks_path = Path(callbacks_path)

    @staticmethod
    def _write_temp(target, content):
        target.parent.mkdir(parents=True, exist_ok=True)
        handle, name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
        try:
            with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            return Path(name)
        except Exception:
            try:
                os.unlink(name)
            except OSError:
                pass
            raise

    def commit(self, config, callbacks_source):
        config_text = json.dumps(config, indent=4, ensure_ascii=False) + "\n"
        json.loads(config_text)
        compile(callbacks_source, str(self.callbacks_path), "exec")
        config_tmp = self._write_temp(self.config_path, config_text)
        callbacks_tmp = self._write_temp(self.callbacks_path, callbacks_source.rstrip() + "\n")
        stamp = time.strftime("%Y%m%d-%H%M%S")
        config_backup = self.config_path.with_name(f"{self.config_path.name}.{stamp}.bak")
        callbacks_backup = self.callbacks_path.with_name(f"{self.callbacks_path.name}.{stamp}.bak")
        config_existed = self.config_path.exists()
        callbacks_existed = self.callbacks_path.exists()
        try:
            if config_existed:
                shutil.copy2(self.config_path, config_backup)
            if callbacks_existed:
                shutil.copy2(self.callbacks_path, callbacks_backup)
            os.replace(callbacks_tmp, self.callbacks_path)
            try:
                os.replace(config_tmp, self.config_path)
            except Exception:
                if callbacks_existed:
                    shutil.copy2(callbacks_backup, self.callbacks_path)
                else:
                    self.callbacks_path.unlink(missing_ok=True)
                raise
        except Exception:
            config_tmp.unlink(missing_ok=True)
            callbacks_tmp.unlink(missing_ok=True)
            raise
        return SaveResult(
            str(config_backup) if config_existed else "",
            str(callbacks_backup) if callbacks_existed else "",
        )

    def commit_config(self, config):
        """Atomically replace only config.json, leaving callbacks untouched."""
        config_text = json.dumps(config, indent=4, ensure_ascii=False) + "\n"
        json.loads(config_text)
        config_tmp = self._write_temp(self.config_path, config_text)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        config_backup = self.config_path.with_name(
            f"{self.config_path.name}.{stamp}.bak")
        config_existed = self.config_path.exists()
        try:
            if config_existed:
                shutil.copy2(self.config_path, config_backup)
            os.replace(config_tmp, self.config_path)
        except Exception:
            config_tmp.unlink(missing_ok=True)
            raise
        return SaveResult(
            str(config_backup) if config_existed else "", "")
