"""Create non-executing instances of the application's real Qt controls."""

from PyQt5 import QtCore, QtGui, QtWidgets

from .canvas_layout import CanvasLayout
from app.info_widgets import InfoWidget
from app.output_widgets import OutputArea
from app.tab_widgets import configure_tab_widget


def create_preview_widget(node, include_children=True, parent=None):
    props = node.properties
    kind = node.node_type
    if kind == "button":
        widget = QtWidgets.QPushButton(node.label, parent)
        icon = props.get("icon")
        if icon:
            widget.setIcon(QtGui.QIcon(icon))
        shortcut = props.get("shortcut")
        if shortcut:
            widget.setShortcut(QtGui.QKeySequence(shortcut))
    elif kind == "tab_widget":
        widget = configure_tab_widget(QtWidgets.QTabWidget(parent), props)
        for page in node.children:
            surface = QtWidgets.QWidget(widget)
            widget.addTab(surface, page.label)
        active_id = (
            node.metadata.get("header_view_page_id")
            or node.metadata.get("active_page_id"))
        for index, page in enumerate(node.children):
            if page.node_id == active_id:
                widget.setCurrentIndex(index)
                break
    elif kind == "group":
        widget = QtWidgets.QGroupBox(node.label, parent)
        layout_definition = props.get("layout") or {}
        if layout_definition.get("mode") == "canvas":
            design_size = layout_definition.get("designSize")
            bounds = props.get("bounds")
            if (not (isinstance(design_size, list) and len(design_size) == 2) and
                    isinstance(bounds, list) and len(bounds) == 4 and
                    bounds[2] > 0 and bounds[3] > 0):
                design_size = bounds[2:4]
            design_size = design_size or [800, 600]
            layout = CanvasLayout(
                design_size=design_size,
                resize_mode=layout_definition.get("resizeMode", "anchors"))
            widget.setLayout(layout)
            if include_children:
                for child in node.children:
                    layout.addWidgetDefinition(
                        create_preview_widget(child, parent=widget),
                        child.properties)
        else:
            layout = QtWidgets.QGridLayout(widget)
            if include_children:
                for child in node.children:
                    position = list(child.properties.get("pos") or [0, 0, 1, 1])
                    position += [1] * (4 - len(position))
                    layout.addWidget(
                        create_preview_widget(child, parent=widget),
                        position[0], position[1], position[2], position[3])
    elif kind == "output":
        widget = OutputArea(
            instance=props.get("instance", "output"),
            kind=props.get("output_kind", "any"),
            editable=props.get("editable", False),
            dockable=props.get("dockable", True),
            df_row_height=props.get("df_row_height"),
            df_column_width=props.get("df_column_width"),
            df_auto_wrap=props.get("df_auto_wrap", False),
            allow_save=props.get("save_to_file", True),
            parent=parent,
        )
        widget._text.setPlaceholderText(
            f"{props.get('instance', 'output')}  •  {props.get('output_kind', 'any')} output")
    elif kind == "info":
        widget = InfoWidget(
            instance=props.get("instance", "info"),
            orientation=props.get("orientation", "horizontal"),
            bg_color=props.get("bg"),
            fg_color=props.get("fg"),
            font=props.get("font"),
            visible=True,
            dockable=False,
            parent=parent,
        )
        widget._timer.setParent(widget)
        widget.output_area.setPlaceholderText(
            f"{props.get('instance', 'info')} information and progress")
    else:
        widget = QtWidgets.QFrame(parent)

    widget.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
    widget.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)
    widget.setToolTip(str(props.get("tooltip") or ""))
    _apply_appearance(widget, props)
    return widget


def render_preview(node, size, include_children=True):
    width = max(1, int(size.width()))
    height = max(1, int(size.height()))
    # Some runtime widgets make themselves visible in their constructors.
    # Parenting them to an already-hidden host prevents those real controls
    # from briefly becoming top-level "Python" windows during preview renders.
    host = QtWidgets.QWidget()
    host.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
    host.hide()
    widget = create_preview_widget(
        node, include_children=include_children, parent=host)
    widget.resize(width, height)
    if widget.layout():
        widget.layout().setGeometry(QtCore.QRect(0, 0, width, height))
    widget.ensurePolished()
    pixmap = QtGui.QPixmap(width, height)
    pixmap.fill(QtCore.Qt.transparent)
    widget.render(pixmap)
    widget.hide()
    widget.deleteLater()
    host.deleteLater()
    return pixmap


def _apply_appearance(widget, props):
    background = props.get("bg")
    foreground = props.get("fg")
    if isinstance(widget, QtWidgets.QPushButton):
        base = QtGui.QColor(background) if background else widget.palette().color(QtGui.QPalette.Button)
        if not foreground:
            brightness = 0.299 * base.red() + 0.587 * base.green() + 0.114 * base.blue()
            foreground = "#000000" if brightness > 160 else "#ffffff"
        widget.setStyleSheet(
            "QPushButton {"
            f"background-color:{base.name()};color:{foreground};"
            f"border:1px solid {base.darker(140).name()};border-radius:4px;padding:4px 8px;"
            "}")
        return
    palette = widget.palette()
    if background:
        color = QtGui.QColor(background)
        palette.setColor(QtGui.QPalette.Window, color)
        palette.setColor(QtGui.QPalette.Base, color)
        widget.setAutoFillBackground(True)
    if foreground:
        color = QtGui.QColor(foreground)
        palette.setColor(QtGui.QPalette.WindowText, color)
        palette.setColor(QtGui.QPalette.Text, color)
        palette.setColor(QtGui.QPalette.ButtonText, color)
    widget.setPalette(palette)
