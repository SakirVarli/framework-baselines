from PyQt5 import QtCore, QtGui, QtWidgets

from .commands import (
    AddNodeCommand, BoundsCommand, DeleteNodeCommand, GeometryCommand,
    ReparentCommand,
)
from .design_items import ContentClipItem, DesignerItem
from .nodes import DesignerNode
from .schema import default_properties


class DesignScene(QtWidgets.QGraphicsScene):
    statusChanged = QtCore.pyqtSignal(str)
    contextActionRequested = QtCore.pyqtSignal(str, str)
    tabPageMenuRequested = QtCore.pyqtSignal(str, QtCore.QPoint)

    def __init__(self, document, undo_stack, container_id, parent=None):
        super().__init__(parent)
        self.document, self.undo_stack = document, undo_stack
        self.container_id = container_id
        self.cell_size = 76
        self._preview = None
        self._drop_parent_id = None
        self._alignment_guides = []
        self._items_by_node = {}
        self.selectionChanged.connect(self._selection_changed)
        self.document.on_change(self._document_changed)
        self.rebuild()

    def dispose(self):
        self.document.remove_listener(self._document_changed)

    @property
    def container(self):
        return self.document.find(self.container_id)

    def set_container(self, node_id):
        node = self.document.find(node_id)
        if node and node.node_type in {"tab", "group"}:
            self.container_id = node_id
            self.rebuild()

    def grid(self):
        node = self.container
        explicit = node.properties.get("grid") if node else None
        if isinstance(explicit, list) and len(explicit) == 2:
            return explicit
        rows = cols = 1
        for child in node.children if node else []:
            pos = list(child.properties.get("pos") or [0, 0, 1, 1])
            pos += [1] * (4 - len(pos))
            rows, cols = max(rows, pos[0] + pos[2]), max(cols, pos[1] + pos[3])
        return [max(3, rows), max(3, cols)]

    @property
    def layout_mode(self):
        if not self.container:
            return "grid"
        default = "canvas" if self.container.node_type == "root" else "grid"
        return self.container.get_property("layout.mode", default)

    @property
    def snap_spacing(self):
        return max(1, int(self.container.get_property("layout.snap", 8) or 1)) if self.container else 8

    def design_size(self):
        node = self.container
        if not node:
            return [1200, 800]
        if node.node_type == "group":
            configured = node.get_property("layout.designSize")
            if (isinstance(configured, list) and len(configured) == 2 and
                    configured[0] > 0 and configured[1] > 0):
                return configured
            bounds = node.properties.get("bounds")
            if isinstance(bounds, list) and len(bounds) == 4 and bounds[2] > 0 and bounds[3] > 0:
                return [bounds[2], bounds[3]]
            width, height = node.properties.get("width"), node.properties.get("height")
            if isinstance(width, int) and width > 0 and isinstance(height, int) and height > 0:
                return [width, height]
        return node.get_property(
            "layout.designSize",
            [1200, 800] if node.node_type in {"root", "tab"} else [800, 600])

    def rebuild(self):
        self.blockSignals(True)
        self.clear()
        self._items_by_node = {}
        self._alignment_guides = []
        node = self.container
        if self.layout_mode == "canvas":
            size = self.design_size()
            self.setSceneRect(0, 0, max(1, size[0]), max(1, size[1]))
        else:
            rows, cols = self.grid()
            self.setSceneRect(0, 0, cols * self.cell_size, rows * self.cell_size)
        if node:
            for child in node.children:
                self._add_designer_item(child)
        self.blockSignals(False)
        self._sync_selection()
        self.update()

    def _add_designer_item(self, node, parent_item=None):
        item = DesignerItem(self, node, parent_item)
        self._items_by_node[node.node_id] = item
        if parent_item is None:
            self.addItem(item)
        if node.node_type == "group":
            clip = ContentClipItem(item.child_content_rect(), item)
            for child in node.children:
                child_item = self._add_designer_item(child, item)
                child_item.setParentItem(clip)
        elif node.node_type == "tab_widget":
            clip = ContentClipItem(item.child_content_rect(), item)
            page = self.active_page(node)
            for child in page.children if page else []:
                child_item = self._add_designer_item(child, item)
                child_item.setParentItem(clip)
        return item

    @staticmethod
    def active_page(tab_widget):
        active_id = tab_widget.metadata.get("active_page_id")
        page = next(
            (child for child in tab_widget.children if child.node_id == active_id),
            None)
        if page is None and tab_widget.children:
            page = tab_widget.children[0]
            tab_widget.metadata["active_page_id"] = page.node_id
        return page

    def contains_node(self, node_id):
        return node_id in self._items_by_node

    def _container_item_at(self, scene_pos):
        containers = [
            item for item in self.items(scene_pos)
            if isinstance(item, DesignerItem)
            and item.node.node_type in {"group", "tab_widget"}
            and item.child_content_rect().contains(item.mapFromScene(scene_pos))
        ]
        if not containers:
            return None
        def depth(item):
            value = 0
            parent = item.parentItem()
            while parent is not None:
                value += 1
                parent = parent.parentItem()
            return value
        return max(containers, key=depth)

    def _drop_context(self, scene_pos):
        selected = self.document.selected_ids
        if len(selected) == 1 and selected[0] == self.document.root.node_id:
            return self.document.root, QtCore.QPointF(scene_pos), None
        container_item = self._container_item_at(scene_pos)
        if container_item:
            content = container_item.child_content_rect()
            local = container_item.mapFromScene(scene_pos) - content.topLeft()
            parent = (
                self.active_page(container_item.node)
                if container_item.node.node_type == "tab_widget"
                else container_item.node)
            return parent, local, container_item
        return self.container, QtCore.QPointF(scene_pos), None

    @staticmethod
    def _node_layout_mode(node):
        if not node:
            return "grid"
        return node.get_property(
            "layout.mode", "canvas" if node.node_type == "root" else "grid")

    @staticmethod
    def _node_snap(node):
        return max(1, int(node.get_property("layout.snap", 8) or 1))

    def _grid_metrics_for(self, container, group_item=None):
        explicit = container.properties.get("grid") if container else None
        if isinstance(explicit, list) and len(explicit) == 2:
            rows, columns = explicit
        else:
            rows = columns = 1
            for child in container.children if container else []:
                position = list(child.properties.get("pos") or [0, 0, 1, 1])
                position += [1] * (4 - len(position))
                rows = max(rows, position[0] + position[2])
                columns = max(columns, position[1] + position[3])
        if group_item:
            rect = group_item.child_content_rect()
            return rect.width() / columns, rect.height() / rows, rows, columns
        return self.cell_size, self.cell_size, rows, columns

    def drawBackground(self, painter, rect):
        painter.fillRect(rect, QtGui.QColor("#f8fafc"))
        cell = self.snap_spacing if self.layout_mode == "canvas" else self.cell_size
        left = int(rect.left()) - (int(rect.left()) % cell)
        top = int(rect.top()) - (int(rect.top()) % cell)
        minor = QtGui.QPen(QtGui.QColor("#e2e8ee" if self.layout_mode == "canvas" else "#dce3ea"))
        minor.setWidth(1)
        painter.setPen(minor)
        for x in range(left, int(rect.right()) + cell, cell):
            painter.drawLine(QtCore.QLineF(float(x), rect.top(), float(x), rect.bottom()))
        for y in range(top, int(rect.bottom()) + cell, cell):
            painter.drawLine(QtCore.QLineF(rect.left(), float(y), rect.right(), float(y)))
        if self.layout_mode == "canvas":
            major = cell * 5
            painter.setPen(QtGui.QPen(QtGui.QColor("#c7d2dc"), 1))
            major_left = int(rect.left()) - (int(rect.left()) % major)
            major_top = int(rect.top()) - (int(rect.top()) % major)
            for x in range(major_left, int(rect.right()) + major, major):
                painter.drawLine(QtCore.QLineF(float(x), rect.top(), float(x), rect.bottom()))
            for y in range(major_top, int(rect.bottom()) + major, major):
                painter.drawLine(QtCore.QLineF(rect.left(), float(y), rect.right(), float(y)))
        painter.setPen(QtGui.QPen(QtGui.QColor("#9fb3c8"), 2))
        painter.drawRect(self.sceneRect())
        if self._preview:
            painter.fillRect(self._preview, QtGui.QColor(60, 140, 220, 70))
            painter.setPen(QtGui.QPen(QtGui.QColor("#0078d4"), 2, QtCore.Qt.DashLine))
            painter.drawRect(self._preview)

    def drawForeground(self, painter, rect):
        super().drawForeground(painter, rect)
        if not self._alignment_guides:
            return
        painter.save()
        pen = QtGui.QPen(QtGui.QColor("#d81b60"), 1.35)
        pen.setCosmetic(True)
        painter.setPen(pen)
        for line in self._alignment_guides:
            painter.drawLine(line)
        painter.restore()

    def clear_alignment_guides(self):
        if self._alignment_guides:
            self._alignment_guides = []
            self.update()

    def _guide_tolerance(self):
        scales = [abs(view.transform().m11()) for view in self.views()
                  if abs(view.transform().m11()) > 0.001]
        return 6.0 / (scales[0] if scales else 1.0)

    @staticmethod
    def _alignment_axis_choice(moving, parent_start, parent_size,
                               sibling_rects, horizontal, tolerance):
        start = moving.left() if horizontal else moving.top()
        center = moving.center().x() if horizontal else moving.center().y()
        end = moving.right() if horizontal else moving.bottom()
        parent_end = parent_start + parent_size
        candidates = [
            # Parent center, then sibling centers, sibling edges, parent edges.
            (0, abs(parent_start + parent_size / 2 - center),
             parent_start + parent_size / 2 - center,
             parent_start + parent_size / 2),
        ]
        for rect in sibling_rects:
            sibling_start = rect.left() if horizontal else rect.top()
            sibling_center = rect.center().x() if horizontal else rect.center().y()
            sibling_end = rect.right() if horizontal else rect.bottom()
            candidates.append((1, abs(sibling_center - center),
                               sibling_center - center, sibling_center))
            for target in (sibling_start, sibling_end):
                for anchor in (start, end):
                    candidates.append((2, abs(target - anchor),
                                       target - anchor, target))
        candidates.extend((
            (3, abs(parent_start - start), parent_start - start, parent_start),
            (3, abs(parent_end - end), parent_end - end, parent_end),
        ))
        eligible = [candidate for candidate in candidates
                    if candidate[1] <= tolerance]
        return min(eligible, key=lambda value: (value[0], value[1])) if eligible else None

    def smart_snap_item(self, item, proposed_position, modifiers=QtCore.Qt.NoModifier):
        """Return a canvas position snapped to parent/sibling smart guides."""
        if (modifiers & QtCore.Qt.AltModifier or item.layout_mode != "canvas" or
                not item.node.parent):
            self.clear_alignment_guides()
            return QtCore.QPointF(proposed_position), False, False
        offset = item._content_offset()
        parent = item.node.parent
        configured = parent.get_property("layout.designSize")
        if (isinstance(configured, list) and len(configured) == 2 and
                all(isinstance(value, (int, float)) and value > 0
                    for value in configured)):
            parent_width, parent_height = configured
        elif item.parent_designer_item:
            content = item.parent_designer_item.child_content_rect()
            parent_width, parent_height = content.width(), content.height()
        else:
            parent_width, parent_height = self.sceneRect().width(), self.sceneRect().height()
        moving = QtCore.QRectF(
            proposed_position.x(), proposed_position.y(),
            item.rect().width(), item.rect().height())
        siblings = []
        for sibling in parent.children:
            if sibling is item.node:
                continue
            sibling_item = self._items_by_node.get(sibling.node_id)
            if (sibling_item is not None and sibling_item.isVisible() and
                    sibling_item.parentItem() is item.parentItem()):
                siblings.append(QtCore.QRectF(
                    sibling_item.pos().x(), sibling_item.pos().y(),
                    sibling_item.rect().width(), sibling_item.rect().height()))
        tolerance = self._guide_tolerance()
        x_choice = self._alignment_axis_choice(
            moving, offset.x(), float(parent_width), siblings, True, tolerance)
        y_choice = self._alignment_axis_choice(
            moving, offset.y(), float(parent_height), siblings, False, tolerance)
        snapped = QtCore.QPointF(proposed_position)
        if x_choice:
            snapped.setX(snapped.x() + x_choice[2])
        if y_choice:
            snapped.setY(snapped.y() + y_choice[2])

        parent_rect = QtCore.QRectF(
            offset.x(), offset.y(), float(parent_width), float(parent_height))
        coordinate_parent = item.parentItem()
        def scene_point(point):
            return (coordinate_parent.mapToScene(point)
                    if coordinate_parent is not None else point)
        guides = []
        if x_choice:
            guides.append(QtCore.QLineF(
                scene_point(QtCore.QPointF(x_choice[3], parent_rect.top())),
                scene_point(QtCore.QPointF(x_choice[3], parent_rect.bottom()))))
        if y_choice:
            guides.append(QtCore.QLineF(
                scene_point(QtCore.QPointF(parent_rect.left(), y_choice[3])),
                scene_point(QtCore.QPointF(parent_rect.right(), y_choice[3]))))
        self._alignment_guides = guides
        self.update()
        return snapped, bool(x_choice), bool(y_choice)

    def smart_snap_resize_item(self, item, proposed_rect, handle,
                               modifiers=QtCore.Qt.NoModifier):
        """Snap only the actively resized canvas edges to smart guides."""
        if (modifiers & QtCore.Qt.AltModifier or item.layout_mode != "canvas" or
                not item.node.parent):
            self.clear_alignment_guides()
            return QtCore.QRectF(proposed_rect), False, False
        offset = item._content_offset()
        parent = item.node.parent
        configured = parent.get_property("layout.designSize")
        if (isinstance(configured, list) and len(configured) == 2 and
                all(isinstance(value, (int, float)) and value > 0
                    for value in configured)):
            parent_width, parent_height = configured
        elif item.parent_designer_item:
            content = item.parent_designer_item.child_content_rect()
            parent_width, parent_height = content.width(), content.height()
        else:
            parent_width, parent_height = self.sceneRect().width(), self.sceneRect().height()

        siblings = []
        for sibling in parent.children:
            if sibling is item.node:
                continue
            sibling_item = self._items_by_node.get(sibling.node_id)
            if (sibling_item is not None and sibling_item.isVisible() and
                    sibling_item.parentItem() is item.parentItem()):
                siblings.append(QtCore.QRectF(
                    sibling_item.pos().x(), sibling_item.pos().y(),
                    sibling_item.rect().width(), sibling_item.rect().height()))

        def targets(horizontal):
            start = offset.x() if horizontal else offset.y()
            size = float(parent_width if horizontal else parent_height)
            values = [(0, start + size / 2)]
            for rect in siblings:
                sibling_start = rect.left() if horizontal else rect.top()
                sibling_center = rect.center().x() if horizontal else rect.center().y()
                sibling_end = rect.right() if horizontal else rect.bottom()
                values.extend(((1, sibling_center),
                               (2, sibling_start), (2, sibling_end)))
            values.extend(((3, start), (3, start + size)))
            unique = {}
            for priority, value in values:
                unique[value] = min(priority, unique.get(value, priority))
            return [(priority, value) for value, priority in unique.items()]

        tolerance = self._guide_tolerance()
        rect = QtCore.QRectF(proposed_rect)
        minimum = 12.0

        def choice(active_edge, fixed_edge, candidates):
            eligible = []
            for priority, target in candidates:
                new_size = abs(fixed_edge - target)
                distance = abs(target - active_edge)
                if distance <= tolerance and new_size >= minimum:
                    eligible.append((priority, distance, target))
            return min(eligible, key=lambda value: (value[0], value[1])) if eligible else None

        x_choice = None
        if "left" in handle:
            x_choice = choice(rect.left(), rect.right(), targets(True))
            if x_choice:
                right = rect.right()
                rect.setLeft(x_choice[2])
                rect.setRight(right)
        elif "right" in handle:
            x_choice = choice(rect.right(), rect.left(), targets(True))
            if x_choice:
                rect.setRight(x_choice[2])

        y_choice = None
        if "top" in handle:
            y_choice = choice(rect.top(), rect.bottom(), targets(False))
            if y_choice:
                bottom = rect.bottom()
                rect.setTop(y_choice[2])
                rect.setBottom(bottom)
        elif "bottom" in handle:
            y_choice = choice(rect.bottom(), rect.top(), targets(False))
            if y_choice:
                rect.setBottom(y_choice[2])

        parent_rect = QtCore.QRectF(
            offset.x(), offset.y(), float(parent_width), float(parent_height))
        coordinate_parent = item.parentItem()
        def scene_point(point):
            return (coordinate_parent.mapToScene(point)
                    if coordinate_parent is not None else point)
        guides = []
        if x_choice:
            guides.append(QtCore.QLineF(
                scene_point(QtCore.QPointF(x_choice[2], parent_rect.top())),
                scene_point(QtCore.QPointF(x_choice[2], parent_rect.bottom()))))
        if y_choice:
            guides.append(QtCore.QLineF(
                scene_point(QtCore.QPointF(parent_rect.left(), y_choice[2])),
                scene_point(QtCore.QPointF(parent_rect.right(), y_choice[2]))))
        self._alignment_guides = guides
        self.update()
        return rect, bool(x_choice), bool(y_choice)

    def preview_drop(self, scene_pos, node_type=None):
        parent, local, group_item = self._drop_context(scene_pos)
        self._drop_parent_id = parent.node_id
        mode = self._node_layout_mode(parent)
        if mode == "canvas":
            snap = self._node_snap(parent)
            x = max(0, round(local.x() / snap) * snap)
            y = max(0, round(local.y() / snap) * snap)
            props = default_properties(node_type) if node_type else {}
            bounds = list(props.get("bounds") or [0, 0, 180, 44])
            local_rect = QtCore.QRectF(x, y, bounds[2], bounds[3])
            self._preview = (
                group_item.mapRectToScene(local_rect.translated(group_item.child_content_rect().topLeft()))
                if group_item else local_rect)
            self.update()
            return y, x
        cell_width, cell_height, _rows, _columns = self._grid_metrics_for(parent, group_item)
        row = max(0, int(local.y() // cell_height))
        col = max(0, int(local.x() // cell_width))
        local_rect = QtCore.QRectF(
            col * cell_width + 2, row * cell_height + 2,
            cell_width - 4, cell_height - 4)
        self._preview = (
            group_item.mapRectToScene(local_rect.translated(group_item.child_content_rect().topLeft()))
            if group_item else local_rect)
        self.update()
        return row, col

    def clear_preview(self):
        self._preview = None
        self._drop_parent_id = None
        self.update()

    def add_type(self, node_type, scene_pos):
        first, second = self.preview_drop(scene_pos, node_type)
        parent = self.document.find(self._drop_parent_id) or self.container
        props = default_properties(node_type)
        if self._node_layout_mode(parent) == "canvas":
            default_bounds = list(props.get("bounds") or [0, 0, 180, 44])
            props["bounds"] = [second, first, default_bounds[2], default_bounds[3]]
            # Canvas-native controls have no legacy grid position. Converted
            # controls retain theirs so conversion back can restore it exactly.
            props.pop("pos", None)
        else:
            props["pos"] = [first, second, 1, 1]
        node = DesignerNode(node_type, props)
        if node_type == "tab_widget":
            page = DesignerNode("tab", default_properties("tab"), parent=node)
            node.children.append(page)
        self.undo_stack.push(AddNodeCommand(
            self.document, parent.node_id, node, text=f"Add {node_type}"))
        self.clear_preview()
        self.document.set_selection([node.node_id])

    def add_tab_page(self, tab_widget_id):
        """Add and activate a page on one explicit tab widget."""
        tab_widget = self.document.find(tab_widget_id)
        if not tab_widget or tab_widget.node_type != "tab_widget":
            return
        existing = {page.label for page in tab_widget.children}
        base = "New Tab"
        label = base
        suffix = 2
        while label in existing:
            label = f"{base} {suffix}"
            suffix += 1
        properties = default_properties("tab")
        properties["name"] = label
        bounds = list(tab_widget.properties.get("bounds") or [0, 0, 1200, 800])
        if len(bounds) < 4:
            bounds = [0, 0, 1200, 800]
        width, height = max(1, int(bounds[2])), max(1, int(bounds[3]))
        position = tab_widget.properties.get("tabPosition", "top")
        horizontal = tab_widget.properties.get("tabTextOrientation") == "horizontal"
        if position in {"left", "right"}:
            width = max(1, width - (112 if horizontal else 42) - 6)
            height = max(1, height - 12)
        else:
            width = max(1, width - 12)
            height = max(1, height - 38)
        properties["layout"] = {
            "mode": "canvas", "designSize": [width, height],
            "resizeMode": "scale", "snap": 8,
        }
        page = DesignerNode("tab", properties)
        self.undo_stack.push(AddNodeCommand(
            self.document, tab_widget.node_id, page, text="Add tab page"))
        tab_widget.metadata["active_page_id"] = page.node_id
        self.document.set_selection([page.node_id])

    def activate_tab_page(self, page_id):
        page = self.document.find(page_id)
        if (not page or page.node_type != "tab" or not page.parent or
                page.parent.node_type != "tab_widget"):
            return False
        page.parent.metadata.pop("header_view_page_id", None)
        page.parent.metadata["active_page_id"] = page.node_id
        self.document.set_selection([page.node_id])
        self.rebuild()
        return True

    def navigate_tab_widget(self, tab_widget_id, delta):
        tab_widget = self.document.find(tab_widget_id)
        if (not tab_widget or tab_widget.node_type != "tab_widget" or
                not tab_widget.children):
            return False
        active = self.active_page(tab_widget)
        index = tab_widget.children.index(active)
        target = max(0, min(len(tab_widget.children) - 1, index + int(delta)))
        if target == index:
            return False
        return self.activate_tab_page(tab_widget.children[target].node_id)

    def reorder_tab_page(self, page_id, new_index):
        page = self.document.find(page_id)
        if (not page or page.node_type != "tab" or not page.parent or
                page.parent.node_type != "tab_widget"):
            return False
        parent = page.parent
        old_index = parent.children.index(page)
        new_index = max(0, min(int(new_index), len(parent.children) - 1))
        if new_index == old_index:
            self.rebuild()
            return False
        self.undo_stack.push(ReparentCommand(
            self.document, page.node_id, parent.node_id, new_index))
        parent.metadata["active_page_id"] = page.node_id
        self.document.set_selection([page.node_id])
        return True

    def contextMenuEvent(self, event):
        if self.itemAt(event.scenePos(), QtGui.QTransform()) is not None:
            super().contextMenuEvent(event)
            return
        self.document.set_selection([self.container.node_id])
        menu = QtWidgets.QMenu()
        paste = menu.addAction("Paste")
        if menu.exec_(event.screenPos()) == paste:
            self.contextActionRequested.emit("paste", self.container.node_id)
        event.accept()

    def delete_selection(self):
        ids = [item.node.node_id for item in self.selectedItems() if isinstance(item, DesignerItem)]
        if ids:
            self.undo_stack.beginMacro("Delete items")
            try:
                for node_id in ids:
                    self.undo_stack.push(DeleteNodeCommand(self.document, node_id))
            finally:
                self.undo_stack.endMacro()

    def nudge_selection(self, key, modifiers=QtCore.Qt.NoModifier):
        """Move or resize selected controls with one undoable key stroke."""
        nodes = [self.document.find(node_id) for node_id in self.document.selected_ids]
        nodes = [
            node for node in nodes
            if node and node.node_type not in {"root", "tab"} and node.parent
        ]
        if not nodes:
            return False
        row_delta = -1 if key == QtCore.Qt.Key_Up else 1 if key == QtCore.Qt.Key_Down else 0
        column_delta = -1 if key == QtCore.Qt.Key_Left else 1 if key == QtCore.Qt.Key_Right else 0
        resize = bool(modifiers & QtCore.Qt.ShiftModifier)
        changed = []
        for node in nodes:
            canvas = self._node_layout_mode(node.parent) == "canvas"
            property_name = "bounds" if canvas else "pos"
            geometry = list(node.properties.get(property_name) or [0, 0, 1, 1])
            geometry += [1] * (4 - len(geometry))
            updated = list(geometry)
            if canvas:
                step = self._node_snap(node.parent) if modifiers & QtCore.Qt.ControlModifier else 1
                if resize:
                    updated[2] = max(1, updated[2] + column_delta * step)
                    updated[3] = max(1, updated[3] + row_delta * step)
                else:
                    updated[0] = max(0, updated[0] + column_delta * step)
                    updated[1] = max(0, updated[1] + row_delta * step)
            elif resize:
                updated[2] = max(1, updated[2] + row_delta)
                updated[3] = max(1, updated[3] + column_delta)
            else:
                updated[0] = max(0, updated[0] + row_delta)
                updated[1] = max(0, updated[1] + column_delta)
            if updated != geometry:
                changed.append((node, updated, canvas))
        if not changed:
            return True
        self.undo_stack.beginMacro("Resize selection" if resize else "Move selection")
        try:
            for node, geometry, canvas in changed:
                command = BoundsCommand if canvas else GeometryCommand
                self.undo_stack.push(command(
                    self.document, node.node_id, geometry,
                    "Resize item" if resize else "Move item"))
        finally:
            self.undo_stack.endMacro()
        return True

    def _selection_changed(self):
        ids = [item.node.node_id for item in self.selectedItems() if isinstance(item, DesignerItem)]
        self.document.set_selection(ids)
        if ids:
            node = self.document.find(ids[0])
            geometry = node.properties.get(
                "bounds" if self._node_layout_mode(node.parent) == "canvas" else "pos")
            self.update_status(node, geometry)

    def _sync_selection(self):
        selected = set(self.document.selected_ids)
        self.blockSignals(True)
        for item in self.items():
            if isinstance(item, DesignerItem):
                item.setSelected(item.node.node_id in selected)
        self.blockSignals(False)

    def _document_changed(self, reason, node):
        if reason == "selection":
            self._sync_selection()
        else:
            self.rebuild()

    def update_status(self, node, pos):
        if self.layout_mode == "canvas":
            bounds = list(pos or node.properties.get("bounds") or [0, 0, 160, 40])
            self.statusChanged.emit(
                f"{node.node_type.title()}: {node.label}  |  X {bounds[0]}, Y {bounds[1]}, "
                f"Width {bounds[2]}, Height {bounds[3]}")
        else:
            pos = list(pos or [0, 0, 1, 1])
            pos += [1] * (4 - len(pos))
            self.statusChanged.emit(
                f"{node.node_type.title()}: {node.label}  |  row {pos[0]}, column {pos[1]}, span {pos[2]}×{pos[3]}")


class DesignView(QtWidgets.QGraphicsView):
    zoomChanged = QtCore.pyqtSignal(int)

    def __init__(self, scene, parent=None):
        super().__init__(scene, parent)
        self._active_context_menu = None
        self._ctrl_rubber_origin = None
        self._ctrl_rubber_band = None
        self._ctrl_rubber_active = False
        self._ctrl_rubber_initial = []
        self._ctrl_rubber_scope_id = None
        self._ctrl_pressed_target_id = None
        self.setAcceptDrops(True)
        self.setRenderHints(QtGui.QPainter.Antialiasing | QtGui.QPainter.TextAntialiasing)
        self.setDragMode(self.RubberBandDrag)
        self.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        self.setViewportUpdateMode(self.FullViewportUpdate)
        self.setTransformationAnchor(self.AnchorUnderMouse)
        # QAbstractScrollArea forwards viewport context events through the
        # view itself; setting the policy on viewport() bypasses that path on
        # Windows and no signal is emitted.
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_designer_context_menu)
        scene.tabPageMenuRequested.connect(self._show_tab_page_menu)

    def _designer_target_at(self, viewport_position):
        scene_position = self.mapToScene(viewport_position)
        item = self.itemAt(viewport_position)
        while item is not None and not isinstance(item, DesignerItem):
            item = item.parentItem()
        if not isinstance(item, DesignerItem):
            return None
        page = item._tab_page_at(item.mapFromScene(scene_position))
        return page or item.node

    def _selection_scope_at(self, viewport_position):
        scene = self.scene()
        container_item = scene._container_item_at(
            self.mapToScene(viewport_position))
        if container_item is None:
            return scene.container
        if container_item.node.node_type == "tab_widget":
            return scene.active_page(container_item.node)
        return container_item.node

    @staticmethod
    def _ancestor_ids(node):
        result = set()
        while node is not None:
            result.add(node.node_id)
            node = node.parent
        return result

    def _update_ctrl_rubber_selection(self, viewport_position):
        rectangle = QtCore.QRect(
            self._ctrl_rubber_origin, viewport_position).normalized()
        self._ctrl_rubber_band.setGeometry(rectangle)
        scene_polygon = self.mapToScene(rectangle)
        scene_rectangle = scene_polygon.boundingRect()
        scene = self.scene()
        scope = scene.document.find(self._ctrl_rubber_scope_id)
        hits = []
        for child in scope.children if scope else []:
            item = scene._items_by_node.get(child.node_id)
            if (item is not None and item.isVisible() and
                    item.sceneBoundingRect().intersects(scene_rectangle)):
                hits.append(child.node_id)
        selected = list(self._ctrl_rubber_initial)
        selected.extend(node_id for node_id in hits if node_id not in selected)
        scene.document.set_selection(selected)

    def mousePressEvent(self, event):
        if (event.button() == QtCore.Qt.LeftButton and
                event.modifiers() & QtCore.Qt.ControlModifier):
            scope = self._selection_scope_at(event.pos())
            target = self._designer_target_at(event.pos())
            excluded = self._ancestor_ids(scope)
            visible_ids = set(self.scene()._items_by_node)
            self._ctrl_rubber_initial = [
                node_id for node_id in self.scene().document.selected_ids
                if node_id in visible_ids and node_id not in excluded
            ]
            self._ctrl_rubber_scope_id = scope.node_id if scope else None
            self._ctrl_pressed_target_id = (
                target.node_id if target and target.node_id not in excluded
                else None)
            self._ctrl_rubber_origin = QtCore.QPoint(event.pos())
            self._ctrl_rubber_active = False
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if (self._ctrl_rubber_origin is not None and
                event.buttons() & QtCore.Qt.LeftButton):
            distance = event.pos() - self._ctrl_rubber_origin
            if (not self._ctrl_rubber_active and
                    abs(distance.x()) + abs(distance.y()) >=
                    QtWidgets.QApplication.startDragDistance()):
                self._ctrl_rubber_active = True
                self._ctrl_rubber_band = QtWidgets.QRubberBand(
                    QtWidgets.QRubberBand.Rectangle, self.viewport())
                self._ctrl_rubber_band.setGeometry(QtCore.QRect(
                    self._ctrl_rubber_origin, QtCore.QSize()))
                self._ctrl_rubber_band.show()
            if self._ctrl_rubber_active:
                self._update_ctrl_rubber_selection(event.pos())
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if (event.button() == QtCore.Qt.LeftButton and
                self._ctrl_rubber_origin is not None):
            if self._ctrl_rubber_active:
                self._update_ctrl_rubber_selection(event.pos())
            elif self._ctrl_pressed_target_id:
                selected = list(self._ctrl_rubber_initial)
                target_id = self._ctrl_pressed_target_id
                if target_id in selected:
                    selected.remove(target_id)
                else:
                    selected.append(target_id)
                self.scene().document.set_selection(selected)
            else:
                self.scene().document.set_selection(
                    self._ctrl_rubber_initial)
            if self._ctrl_rubber_band is not None:
                self._ctrl_rubber_band.hide()
                self._ctrl_rubber_band.deleteLater()
            self._ctrl_rubber_origin = None
            self._ctrl_rubber_band = None
            self._ctrl_rubber_active = False
            self._ctrl_rubber_scope_id = None
            self._ctrl_pressed_target_id = None
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def _show_designer_context_menu(self, viewport_position):
        scene = self.scene()
        scene_position = self.mapToScene(viewport_position)
        item = self.itemAt(viewport_position)
        while item is not None and not isinstance(item, DesignerItem):
            item = item.parentItem()

        if isinstance(item, DesignerItem):
            local_position = item.mapFromScene(scene_position)
            page = item._tab_page_at(local_position)
            target = page or item.node
            if page is not None:
                item.node.metadata["active_page_id"] = page.node_id
            # Preserve a multi-selection when its member is right-clicked so
            # arrange commands can operate on the whole selection.
            if target.node_id not in scene.document.selected_ids:
                scene.document.set_selection([target.node_id])
            menu = item._build_context_menu(target)
            if page is not None:
                scene.rebuild()
        else:
            target = scene.container
            scene.document.set_selection([target.node_id])
            menu = QtWidgets.QMenu()
            paste = menu.addAction("Paste")
            paste.setData("paste")

        target_id = target.node_id
        menu.triggered.connect(
            lambda action, target_id=target_id: scene.contextActionRequested.emit(
                str(action.data()), target_id) if action.data() else None)
        self._active_context_menu = menu

        def clear_menu():
            if self._active_context_menu is menu:
                self._active_context_menu = None

        menu.aboutToHide.connect(clear_menu)
        menu.popup(self.viewport().mapToGlobal(viewport_position))

    def _show_tab_page_menu(self, tab_widget_id, screen_position):
        scene = self.scene()
        tab_widget = scene.document.find(tab_widget_id)
        if not tab_widget or tab_widget.node_type != "tab_widget":
            return
        active = DesignScene.active_page(tab_widget)
        menu = QtWidgets.QMenu()
        for page in tab_widget.children:
            action = menu.addAction(page.label)
            action.setCheckable(True)
            action.setChecked(page is active)
            action.setData(page.node_id)
        menu.triggered.connect(
            lambda action: scene.activate_tab_page(str(action.data())))
        self._active_context_menu = menu

        def clear_menu():
            if self._active_context_menu is menu:
                self._active_context_menu = None

        menu.aboutToHide.connect(clear_menu)
        menu.popup(screen_position)

    def set_zoom_percent(self, percent):
        percent = max(50, min(175, int(percent)))
        self.resetTransform()
        factor = percent / 100.0
        self.scale(factor, factor)

    def zoom_by_steps(self, steps):
        current = round(self.transform().m11() * 100)
        target = max(50, min(175, current + int(steps) * 10))
        if target != current:
            self.set_zoom_percent(target)
            self.zoomChanged.emit(target)
        return target

    def scroll_horizontally(self, wheel_delta, pixel_delta=0):
        """Move the horizontal scrollbar from a vertical wheel gesture."""
        bar = self.horizontalScrollBar()
        if bar.minimum() >= bar.maximum():
            return False
        if pixel_delta:
            distance = int(pixel_delta)
        elif wheel_delta:
            lines = max(1, QtWidgets.QApplication.wheelScrollLines())
            distance = round(
                (wheel_delta / 120.0) * lines * max(20, bar.singleStep()))
        else:
            return False
        before = bar.value()
        bar.setValue(before - distance)
        return bar.value() != before

    def wheelEvent(self, event):
        if event.modifiers() & QtCore.Qt.ControlModifier:
            delta = event.angleDelta().y()
            if delta:
                self.zoom_by_steps(1 if delta > 0 else -1)
            event.accept()
            return
        if event.modifiers() & QtCore.Qt.ShiftModifier:
            angle = event.angleDelta()
            pixels = event.pixelDelta()
            wheel_delta = angle.y() or angle.x()
            pixel_delta = pixels.y() or pixels.x()
            self.scroll_horizontally(wheel_delta, pixel_delta)
            # Shift+wheel belongs exclusively to horizontal navigation.  Do
            # not fall through to QGraphicsView at a horizontal scroll limit,
            # because its default handler can move the vertical scrollbar.
            event.accept()
            return
        super().wheelEvent(event)

    def dragEnterEvent(self, event):
        from .toolbox import MIME_TYPE
        if event.mimeData().hasFormat(MIME_TYPE):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        from .toolbox import MIME_TYPE
        if event.mimeData().hasFormat(MIME_TYPE):
            node_type = bytes(event.mimeData().data(MIME_TYPE)).decode("utf-8")
            self.scene().preview_drop(self.mapToScene(event.pos()), node_type)
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dragLeaveEvent(self, event):
        self.scene().clear_preview()
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        from .toolbox import MIME_TYPE
        if event.mimeData().hasFormat(MIME_TYPE):
            node_type = bytes(event.mimeData().data(MIME_TYPE)).decode("utf-8")
            self.scene().add_type(node_type, self.mapToScene(event.pos()))
            event.acceptProposedAction()
        else:
            super().dropEvent(event)

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Delete:
            self.scene().delete_selection()
            event.accept()
            return
        if event.key() in (QtCore.Qt.Key_Left, QtCore.Qt.Key_Right,
                           QtCore.Qt.Key_Up, QtCore.Qt.Key_Down):
            if self.scene().nudge_selection(event.key(), event.modifiers()):
                event.accept()
                return
        super().keyPressEvent(event)
