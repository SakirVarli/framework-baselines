from PyQt5 import QtCore, QtGui, QtWidgets


class ValidationPanel(QtWidgets.QTreeWidget):
    issueActivated = QtCore.pyqtSignal(str)
    issueActionRequested = QtCore.pyqtSignal(object)
    ACTION_LABELS = {
        "delete-callback": "Delete",
        "generate-callback": "Generate Now",
        "keep-previous-callback": "Keep Previous",
        "rename-previous-callback": "Rename Previous",
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderLabels(["Severity", "Message", "Action"])
        self.setRootIsDecorated(False)
        self.setAlternatingRowColors(True)
        self.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.itemActivated.connect(self._activate)

    def set_issues(self, issues):
        self.clear()
        for issue in issues:
            item = QtWidgets.QTreeWidgetItem([issue.severity.title(), issue.message])
            item.setData(0, QtCore.Qt.UserRole, issue.node_id)
            color = "#c0392b" if issue.blocking else "#b9770e"
            item.setForeground(0, QtGui.QBrush(QtGui.QColor(color)))
            item.setToolTip(1, issue.code)
            self.addTopLevelItem(item)
            actions = tuple(issue.actions) or ((issue.action,) if issue.action else ())
            if len(actions) == 1:
                action_key = actions[0]
                button = QtWidgets.QPushButton(
                    self.ACTION_LABELS.get(action_key, "Apply"))
                button.setToolTip("This action is undoable and is not written until Save.")
                button.setMaximumWidth(104)
                button.clicked.connect(
                    lambda checked=False, selected=issue, key=action_key:
                    self.issueActionRequested.emit((selected, key)))
                self.setItemWidget(item, 2, button)
            elif actions:
                button = QtWidgets.QToolButton()
                button.setText("Actions")
                button.setPopupMode(QtWidgets.QToolButton.InstantPopup)
                menu = QtWidgets.QMenu(button)
                menu.setToolTipsVisible(True)
                for action_key in actions:
                    action = menu.addAction(
                        self.ACTION_LABELS.get(action_key, action_key))
                    action.setToolTip(
                        "Undoable; callbacks.py is not written until Save.")
                    action.triggered.connect(
                        lambda checked=False, selected=issue, key=action_key:
                        self.issueActionRequested.emit((selected, key)))
                button.setMenu(menu)
                self.setItemWidget(item, 2, button)

    def _activate(self, item):
        node_id = item.data(0, QtCore.Qt.UserRole)
        if node_id:
            self.issueActivated.emit(node_id)
