"""Typed property metadata shared by the designer and validator."""

from copy import deepcopy


def _p(kind, label, default=None, required=False, category="Appearance", **extra):
    return {
        "type": kind, "label": label, "default": default,
        "required": required, "category": category, **extra,
    }


FEATURES = {
    "root": {
        "layout.mode": _p("readonly", "Window layout mode", "canvas", True, "Layout"),
        "layout.designSize": _p("size", "Window design size", [1200, 800], True, "Layout"),
        "layout.resizeMode": _p("combo", "Window resize behavior", "anchors", True, "Layout",
                                options=["anchors", "fixed", "scale"]),
        "layout.snap": _p("int", "Window snap spacing", 8, False, "Layout"),
    },
    "tab_widget": {
        "type": _p("readonly", "Type", "tab_widget", True, "Identity"),
        "instance": _p("text", "Instance", "tabs", True, "Identity"),
        "pos": _p("pos", "Grid position", [0, 0, 1, 1], True, "Layout"),
        "bounds": _p("rect", "Bounds (X, Y, W, H)", [40, 40, 720, 520], False, "Layout"),
        "anchors": _p("anchors", "Anchors", ["left", "top"], False, "Layout"),
        "dock": _p("combo", "Dock", "none", False, "Layout",
                   options=["none", "top", "bottom", "left", "right", "fill"]),
        "zIndex": _p("int", "Z-order", 0, False, "Layout"),
        "tabPosition": _p("combo", "Tab header position", "top", True, "Appearance",
                          options=["top", "bottom", "left", "right"]),
        "tabTextOrientation": _p("combo", "Tab text orientation", "native", True, "Appearance",
                                 options=["native", "horizontal"]),
        "movable": _p("bool", "Movable pages", False, False, "Behavior"),
        "tooltip": _p("text", "Tooltip", "", False, "Behavior"),
    },
    "tab": {
        "name": _p("text", "Name", "New Tab", True, "Identity"),
        "grid": _p("grid", "Grid (rows, columns)", [6, 4], True, "Layout"),
        "layout.mode": _p("readonly", "Layout mode", "grid", True, "Layout",
                          help="Grid preserves row/column placement. Canvas enables exact X, Y, width and height."),
        "layout.designSize": _p("size", "Design size", [1200, 800], True, "Layout",
                                help="Reference width and height used by the canvas and runtime resizing."),
        "layout.resizeMode": _p("combo", "Resize behavior", "anchors", True, "Layout",
                                options=["anchors", "fixed", "scale"],
                                help="Anchors preserve edge distances; fixed uses scrolling; scale resizes everything proportionally."),
        "layout.snap": _p("int", "Snap spacing", 8, False, "Layout",
                          help="Movement and resizing snap interval in logical pixels. Use 1 for unrestricted placement."),
        "password": _p("password", "Password", "", False, "Security"),
    },
    "group": {
        "type": _p("readonly", "Type", "group", True, "Identity"),
        "name": _p("text", "Name", "New Group", True, "Identity"),
        "pos": _p("pos", "Grid position", [0, 0, 1, 1], True, "Layout"),
        "bounds": _p("rect", "Bounds (X, Y, W, H)", [0, 0, 280, 220], False, "Layout",
                     help="Exact position and size relative to the parent canvas."),
        "anchors": _p("anchors", "Anchors", ["left", "top"], False, "Layout",
                      help="Parent edges whose distances remain fixed when the container resizes."),
        "dock": _p("combo", "Dock", "none", False, "Layout",
                   options=["none", "top", "bottom", "left", "right", "fill"],
                   help="Attach the control to an edge or fill the remaining parent area."),
        "zIndex": _p("int", "Z-order", 0, False, "Layout",
                     help="Higher values appear in front of lower values."),
        "grid": _p("grid", "Child grid", None, False, "Layout"),
        "layout.mode": _p("readonly", "Child layout mode", "grid", True, "Layout",
                          help="Controls inside this group can use grid placement or exact canvas bounds."),
        "layout.designSize": _p("size", "Child design size", [800, 600], True, "Layout",
                                help="Fallback child size for grid-parented groups. In canvas mode the group's Bounds determine its child surface."),
        "layout.resizeMode": _p("combo", "Child resize behavior", "anchors", True, "Layout",
                                options=["anchors", "fixed", "scale"]),
        "layout.snap": _p("int", "Child snap spacing", 8, False, "Layout"),
        "height": _p("int", "Minimum height", None, False, "Layout"),
        "width": _p("int", "Minimum width", None, False, "Layout"),
        "bg": _p("color", "Background", "", False, "Appearance"),
        "fg": _p("color", "Foreground", "", False, "Appearance"),
        "tooltip": _p("text", "Tooltip", "", False, "Behavior",
                      help="Helpful text shown when the user pauses over this group."),
    },
    "button": {
        "type": _p("readonly", "Type", "button", True, "Identity"),
        "name": _p("text", "Label", "New Button", True, "Identity"),
        "pos": _p("pos", "Grid position", [0, 0, 1, 1], True, "Layout"),
        "bounds": _p("rect", "Bounds (X, Y, W, H)", [0, 0, 180, 44], False, "Layout"),
        "anchors": _p("anchors", "Anchors", ["left", "top"], False, "Layout"),
        "dock": _p("combo", "Dock", "none", False, "Layout",
                   options=["none", "top", "bottom", "left", "right", "fill"]),
        "zIndex": _p("int", "Z-order", 0, False, "Layout"),
        "height": _p("int", "Minimum height", None, False, "Layout"),
        "width": _p("int", "Minimum width", None, False, "Layout"),
        "bg": _p("color", "Background", "", False, "Appearance"),
        "fg": _p("color", "Foreground", "", False, "Appearance"),
        "icon": _p("file", "Icon", "", False, "Appearance", filter="Images (*.png *.ico *.jpg *.svg)"),
        "password": _p("password", "Password", "", False, "Security"),
        "tooltip": _p("text", "Tooltip", "", False, "Behavior"),
        "confirm": _p("bool", "Require confirmation", False, False, "Behavior"),
        "shortcut": _p("shortcut", "Shortcut", "", False, "Behavior"),
        "callback": _p("callback", "Callback", "", False, "Events"),
    },
    "output": {
        "type": _p("readonly", "Type", "output", True, "Identity"),
        "instance": _p("text", "Instance", "new_output", True, "Identity"),
        "pos": _p("pos", "Grid position", [0, 0, 1, 1], True, "Layout"),
        "bounds": _p("rect", "Bounds (X, Y, W, H)", [0, 0, 320, 240], False, "Layout"),
        "anchors": _p("anchors", "Anchors", ["left", "top"], False, "Layout"),
        "dock": _p("combo", "Dock", "none", False, "Layout",
                   options=["none", "top", "bottom", "left", "right", "fill"]),
        "zIndex": _p("int", "Z-order", 0, False, "Layout"),
        "height": _p("int", "Minimum height", None, False, "Layout"),
        "width": _p("int", "Minimum width", None, False, "Layout"),
        "output_kind": _p("combo", "Output type", "any", True, "Data/output",
                          options=["any", "array", "df", "dict", "html", "image",
                                   "markdown", "object", "text", "widget"]),
        "df_row_height": _p("int", "DataFrame row height", None, False, "Data/output"),
        "df_column_width": _p("int", "DataFrame column width", None, False, "Data/output"),
        "df_auto_wrap": _p("bool", "Wrap DataFrame cells", False, False, "Data/output"),
        "editable": _p("bool", "Editable", False, False, "Behavior"),
        "dockable": _p("bool", "Dockable", True, False, "Behavior"),
        "bg": _p("color", "Background", "", False, "Appearance"),
        "fg": _p("color", "Foreground", "", False, "Appearance"),
        "save_to_file": _p("bool", "Allow save to file", True, False, "Behavior"),
        "tooltip": _p("text", "Tooltip", "", False, "Behavior",
                      help="Helpful text shown when the user pauses over this output."),
    },
    "info": {
        "type": _p("readonly", "Type", "info", True, "Identity"),
        "instance": _p("text", "Instance", "new_info", True, "Identity"),
        "pos": _p("pos", "Grid position", [0, 0, 1, 1], True, "Layout"),
        "bounds": _p("rect", "Bounds (X, Y, W, H)", [0, 0, 320, 150], False, "Layout"),
        "anchors": _p("anchors", "Anchors", ["left", "top"], False, "Layout"),
        "dock": _p("combo", "Dock", "none", False, "Layout",
                   options=["none", "top", "bottom", "left", "right", "fill"]),
        "zIndex": _p("int", "Z-order", 0, False, "Layout"),
        "orientation": _p("combo", "Orientation", "horizontal", True, "Behavior",
                          options=["horizontal", "vertical"]),
        "height": _p("int", "Minimum height", None, False, "Layout"),
        "width": _p("int", "Minimum width", None, False, "Layout"),
        "bg": _p("color", "Background", "", False, "Appearance"),
        "fg": _p("color", "Foreground", "", False, "Appearance"),
        "font": _p("font", "Font", "", False, "Appearance"),
        "visible": _p("bool", "Initially visible", True, True, "Behavior"),
        "tooltip": _p("text", "Tooltip", "", False, "Behavior",
                      help="Helpful text shown when the user pauses over this information panel."),
    },
}

CONTAINER_TYPES = {"root", "tab_widget", "tab", "group"}
WIDGET_TYPES = {"tab_widget", "group", "button", "output", "info"}


def default_properties(node_type):
    result = {}
    for key, meta in FEATURES[node_type].items():
        value = deepcopy(meta.get("default"))
        target = result
        parts = key.split(".")
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        target[parts[-1]] = value
    return result
