"""Safe, schema-aware normalization for imported designer documents."""

import re

from .schema import FEATURES


_INTEGER_TEXT = re.compile(r"[+-]?\d+")
_NULL_TEXT = {"", "none", "null"}


def normalize_legacy_property_values(document):
    """Normalize unambiguous legacy values in-place and return a change count.

    Legacy configs commonly serialized optional integers as empty strings,
    ``"None"`` or numeric strings. Unknown values remain untouched so normal
    validation can report them instead of silently changing user data.
    """
    changed = 0
    for node in document.root.walk():
        for key, metadata in FEATURES.get(node.node_type, {}).items():
            if metadata.get("type") != "int" or not node.has_property(key):
                continue
            value = node.get_property(key)
            normalized = _normalized_optional_integer(value)
            if normalized is not value and normalized != value:
                node.set_property(key, normalized)
                changed += 1
    return changed


def _normalized_optional_integer(value):
    if value is None or isinstance(value, bool) or isinstance(value, int):
        return value
    if not isinstance(value, str):
        return value
    text = value.strip()
    if text.casefold() in _NULL_TEXT:
        return None
    if _INTEGER_TEXT.fullmatch(text):
        return int(text, 10)
    return value
