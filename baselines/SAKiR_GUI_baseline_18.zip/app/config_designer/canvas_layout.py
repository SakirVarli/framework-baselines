"""WinForms-style parent-relative runtime layout for PyQt widgets."""

from PyQt5 import QtCore, QtWidgets


class CanvasLayout(QtWidgets.QLayout):
    """A QLayout that applies bounds, anchors, docking and z-order.

    Geometry values are logical Qt pixels relative to ``design_size``. Existing
    grid layouts never instantiate this class and retain their original path.
    """

    def __init__(self, parent=None, design_size=(1200, 800), resize_mode="anchors"):
        super().__init__(parent)
        self.design_size = tuple(design_size or (1200, 800))
        self.resize_mode = resize_mode or "anchors"
        self._entries = []
        self.setContentsMargins(0, 0, 0, 0)
        self.setSpacing(0)

    def addItem(self, item):
        self._entries.append((item, {}))

    def addWidgetDefinition(self, widget, definition):
        self.addChildWidget(widget)
        self._entries.append((QtWidgets.QWidgetItem(widget), dict(definition or {})))
        self.invalidate()

    def widgetDefinition(self, widget):
        """Return a copy of the canvas metadata assigned to ``widget``."""
        for item, definition in self._entries:
            if item.widget() is widget:
                return dict(definition)
        return None

    def count(self):
        return len(self._entries)

    def itemAt(self, index):
        return self._entries[index][0] if 0 <= index < len(self._entries) else None

    def takeAt(self, index):
        if 0 <= index < len(self._entries):
            return self._entries.pop(index)[0]
        return None

    def sizeHint(self):
        return QtCore.QSize(*self.design_size)

    def minimumSize(self):
        if self.resize_mode == "fixed":
            return self.sizeHint()
        size = QtCore.QSize(100, 80)
        for item, definition in self._entries:
            minimum = definition.get("minSize")
            if isinstance(minimum, list) and len(minimum) == 2:
                size = size.expandedTo(QtCore.QSize(*minimum))
            else:
                size = size.expandedTo(item.minimumSize())
        return size

    def setGeometry(self, rect):
        super().setGeometry(rect)
        left, top, right, bottom = self.getContentsMargins()
        available = rect.adjusted(left, top, -right, -bottom)
        design_width = max(1, int(self.design_size[0]))
        design_height = max(1, int(self.design_size[1]))
        remaining = QtCore.QRectF(available)

        entries = sorted(
            self._entries, key=lambda entry: int(entry[1].get("zIndex", 0) or 0))
        for item, definition in entries:
            widget = item.widget()
            if widget is None:
                continue
            bounds = definition.get("bounds") or [0, 0, 160, 40]
            if not isinstance(bounds, list) or len(bounds) != 4:
                bounds = [0, 0, 160, 40]
            x, y, width, height = map(float, bounds)
            dock = str(definition.get("dock") or "none").lower()

            if dock == "top":
                geometry = QtCore.QRectF(remaining.left(), remaining.top(), remaining.width(), height)
                remaining.setTop(remaining.top() + height)
            elif dock == "bottom":
                geometry = QtCore.QRectF(
                    remaining.left(), remaining.bottom() - height + 1,
                    remaining.width(), height)
                remaining.setBottom(remaining.bottom() - height)
            elif dock == "left":
                geometry = QtCore.QRectF(remaining.left(), remaining.top(), width, remaining.height())
                remaining.setLeft(remaining.left() + width)
            elif dock == "right":
                geometry = QtCore.QRectF(
                    remaining.right() - width + 1, remaining.top(),
                    width, remaining.height())
                remaining.setRight(remaining.right() - width)
            elif dock == "fill":
                geometry = QtCore.QRectF(remaining)
            else:
                geometry = self._free_geometry(
                    x, y, width, height, available, design_width, design_height,
                    definition.get("anchors") or ["left", "top"])

            minimum = definition.get("minSize")
            maximum = definition.get("maxSize")
            if isinstance(minimum, list) and len(minimum) == 2:
                geometry.setWidth(max(geometry.width(), minimum[0]))
                geometry.setHeight(max(geometry.height(), minimum[1]))
            if isinstance(maximum, list) and len(maximum) == 2:
                geometry.setWidth(min(geometry.width(), maximum[0]))
                geometry.setHeight(min(geometry.height(), maximum[1]))
            widget.setGeometry(geometry.toAlignedRect())
            widget.show()

        for item, _definition in entries:
            if item.widget():
                item.widget().raise_()

    def _free_geometry(self, x, y, width, height, available,
                       design_width, design_height, anchors):
        if self.resize_mode == "scale":
            scale_x = available.width() / design_width
            scale_y = available.height() / design_height
            return QtCore.QRectF(
                available.left() + x * scale_x,
                available.top() + y * scale_y,
                width * scale_x, height * scale_y)

        delta_width = available.width() - design_width
        delta_height = available.height() - design_height
        anchors = set(anchors)
        if self.resize_mode == "anchors":
            if "left" in anchors and "right" in anchors:
                width += delta_width
            elif "right" in anchors and "left" not in anchors:
                x += delta_width
            if "top" in anchors and "bottom" in anchors:
                height += delta_height
            elif "bottom" in anchors and "top" not in anchors:
                y += delta_height
        return QtCore.QRectF(
            available.left() + x, available.top() + y,
            max(1.0, width), max(1.0, height))
