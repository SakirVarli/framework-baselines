from PyQt5 import QtCore, QtGui, QtWidgets

from .commands import BoundsCommand, GeometryCommand
from .preview_factory import render_preview
from app.tab_widgets import tab_header_layout


TYPE_COLORS = {
    "tab_widget": ("#e8eefc", "#3659a2"),
    "group": ("#dbeafe", "#2563eb"),
    "button": ("#e8f5e9", "#2e7d32"),
    "output": ("#fff3e0", "#ef6c00"),
    "info": ("#f3e5f5", "#7b1fa2"),
}


class ContentClipItem(QtWidgets.QGraphicsRectItem):
    """Transparent child host that clips editable controls to container content."""

    def __init__(self, rect, parent=None):
        super().__init__(rect, parent)
        self.setPen(QtGui.QPen(QtCore.Qt.NoPen))
        self.setBrush(QtGui.QBrush(QtCore.Qt.NoBrush))
        self.setAcceptedMouseButtons(QtCore.Qt.NoButton)
        self.setFlag(self.ItemClipsChildrenToShape, True)


class DesignerItem(QtWidgets.QGraphicsRectItem):
    HANDLE = 9

    def __init__(self, scene, node, parent_item=None):
        super().__init__(parent_item)
        self.designer_scene = scene
        self.node = node
        self.parent_designer_item = parent_item
        self._resizing = False
        self._resize_handle = ""
        self._before = None
        self._preview_pixmap = None
        self._tab_hit_regions = []
        self._tab_add_region = QtCore.QRectF()
        self._tab_overflow_menu_region = QtCore.QRectF()
        self._tab_bar_region = QtCore.QRectF()
        self._tab_previous_region = QtCore.QRectF()
        self._tab_next_region = QtCore.QRectF()
        self._tab_has_overflow = False
        self._tab_page_menu_pending = False
        self._tab_drag_page_id = None
        self._tab_drag_target_index = None
        self._tab_drag_origin_index = None
        self._tab_drag_active = False
        self._tab_drag_edge_direction = 0
        self._smart_snap_x = False
        self._smart_snap_y = False
        self.setFlags(
            self.ItemIsSelectable | self.ItemIsMovable |
            self.ItemSendsGeometryChanges | self.ItemIsFocusable
        )
        self.setAcceptHoverEvents(True)
        if self.node.node_type in {"group", "tab_widget"}:
            self.setFlag(self.ItemClipsChildrenToShape, True)
        self.sync_from_node()

    @property
    def layout_mode(self):
        if not self.node.parent:
            return self.designer_scene.layout_mode
        default = "canvas" if self.node.parent.node_type == "root" else "grid"
        return self.node.parent.get_property("layout.mode", default)

    @property
    def snap_spacing(self):
        return max(
            1, int(self.node.parent.get_property("layout.snap", 8) or 1)
        ) if self.node.parent else self.designer_scene.snap_spacing

    def child_content_rect(self):
        rect = self.rect()
        if self.node.node_type == "tab_widget":
            position = self.node.properties.get("tabPosition", "top")
            regions = [region for _page_id, region in self._tab_hit_regions]
            if regions:
                if position == "bottom":
                    edge = min(region.top() for region in regions) - 3
                    return QtCore.QRectF(
                        rect.left() + 6, rect.top() + 6,
                        max(1, rect.width() - 12),
                        max(1, edge - rect.top() - 6))
                if position == "left":
                    edge = max(region.right() for region in regions) + 3
                    return QtCore.QRectF(
                        edge, rect.top() + 6,
                        max(1, rect.right() - 6 - edge),
                        max(1, rect.height() - 12))
                if position == "right":
                    edge = min(region.left() for region in regions) - 3
                    return QtCore.QRectF(
                        rect.left() + 6, rect.top() + 6,
                        max(1, edge - rect.left() - 6),
                        max(1, rect.height() - 12))
                edge = max(region.bottom() for region in regions) + 3
                return QtCore.QRectF(
                    rect.left() + 6, edge,
                    max(1, rect.width() - 12),
                    max(1, rect.bottom() - 6 - edge))
            horizontal = self.node.properties.get(
                "tabTextOrientation") == "horizontal"
            side = 112 if horizontal else 42
            if position == "bottom":
                return rect.adjusted(6, 6, -6, -32)
            if position == "left":
                return rect.adjusted(side, 6, -6, -6)
            if position == "right":
                return rect.adjusted(6, 6, -side, -6)
            return rect.adjusted(6, 32, -6, -6)
        if self.node.node_type != "group":
            return QtCore.QRectF(rect)
        return rect.adjusted(7, 24, -7, -7)

    def _content_offset(self):
        if self.parent_designer_item:
            return self.parent_designer_item.child_content_rect().topLeft()
        return QtCore.QPointF(0, 0)

    def _grid_metrics(self):
        grid = self.node.parent.properties.get("grid") if self.node.parent else None
        if not (isinstance(grid, list) and len(grid) == 2):
            rows = columns = 1
            for child in self.node.parent.children if self.node.parent else []:
                pos = list(child.properties.get("pos") or [0, 0, 1, 1])
                pos += [1] * (4 - len(pos))
                rows = max(rows, pos[0] + pos[2])
                columns = max(columns, pos[1] + pos[3])
            grid = [rows, columns]
        if self.parent_designer_item:
            content = self.parent_designer_item.child_content_rect()
            return (
                content.width() / max(1, grid[1]),
                content.height() / max(1, grid[0]),
            )
        return self.designer_scene.cell_size, self.designer_scene.cell_size

    def sync_from_node(self):
        offset = self._content_offset()
        if self.layout_mode == "canvas":
            bounds = list(self.node.properties.get("bounds") or [0, 0, 160, 40])
            self.setPos(offset.x() + bounds[0], offset.y() + bounds[1])
            self.setRect(0, 0, max(1, bounds[2]), max(1, bounds[3]))
            self.setZValue(int(self.node.properties.get("zIndex", 0) or 0))
            self.setToolTip(
                f"{self.node.label}\nX {bounds[0]}, Y {bounds[1]}, "
                f"Width {bounds[2]}, Height {bounds[3]}")
            self._refresh_preview()
            return
        cell_width, cell_height = self._grid_metrics()
        pos = self.node.properties.get("pos") or [0, 0, 1, 1]
        pos = list(pos) + [1] * (4 - len(pos))
        row, col, row_span, col_span = pos[:4]
        self.setPos(offset.x() + col * cell_width, offset.y() + row * cell_height)
        self.setRect(
            2, 2,
            max(20, col_span * cell_width - 4),
            max(20, row_span * cell_height - 4))
        self.setToolTip(f"{self.node.label}\nrow {row}, column {col}, span {row_span}×{col_span}")
        self._refresh_preview()

    def _refresh_preview(self):
        self._tab_hit_regions = []
        self._tab_add_region = QtCore.QRectF()
        self._tab_overflow_menu_region = QtCore.QRectF()
        self._tab_bar_region = QtCore.QRectF()
        self._tab_previous_region = QtCore.QRectF()
        self._tab_next_region = QtCore.QRectF()
        self._tab_has_overflow = False
        try:
            self._preview_pixmap = render_preview(
                self.node, self.rect().size(),
                include_children=self.node.node_type not in {"group", "tab_widget"})
            if self.node.node_type == "tab_widget":
                offset = self.rect().topLeft()
                view_id = (
                    self.node.metadata.get("header_view_page_id")
                    or self.node.metadata.get("active_page_id"))
                current_index = next(
                    (index for index, page in enumerate(self.node.children)
                     if page.node_id == view_id), 0)
                header = tab_header_layout(
                    self.node.properties,
                    [page.label for page in self.node.children],
                    self.rect().size(), current_index=current_index)
                rectangles = header["tabs"]
                self._tab_hit_regions = [
                    (page.node_id, rectangle.translated(offset))
                    for page, rectangle in zip(self.node.children, rectangles)
                ]
                self._tab_bar_region = header["bar"].translated(offset)
                if header["previous"] is not None:
                    self._tab_previous_region = header["previous"].translated(offset)
                if header["next"] is not None:
                    self._tab_next_region = header["next"].translated(offset)
                self._tab_has_overflow = bool(header["overflow"])
                self._tab_add_region = self._tab_add_button_rect()
                self._tab_overflow_menu_region = self._tab_overflow_button_rect()
        except Exception:
            # Unknown/custom widgets still retain the safe painted fallback.
            self._preview_pixmap = None

    def paint(self, painter, option, widget=None):
        if self._preview_pixmap and not self._preview_pixmap.isNull():
            painter.drawPixmap(self.rect().toAlignedRect(), self._preview_pixmap)
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.setPen(QtGui.QPen(
                QtGui.QColor("#0078d4" if self.isSelected() else "#9aa8b5"),
                3 if self.isSelected() else 1))
            painter.drawRect(self.rect())
            self._paint_tab_add_button(painter)
            self._paint_tab_overflow_button(painter)
            self._paint_tab_drop_indicator(painter)
            if self.isSelected():
                painter.setBrush(QtGui.QColor("#0078d4"))
                painter.setPen(QtCore.Qt.NoPen)
                for handle in self._handle_rects().values():
                    painter.drawRect(handle)
            return
        fill, outline = TYPE_COLORS.get(self.node.node_type, ("#eeeeee", "#555555"))
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setBrush(QtGui.QColor(fill))
        pen = QtGui.QPen(QtGui.QColor("#0078d4" if self.isSelected() else outline))
        pen.setWidth(3 if self.isSelected() else 1)
        painter.setPen(pen)
        painter.drawRoundedRect(self.rect(), 5, 5)
        title = self.node.label
        type_label = self.node.node_type.upper()
        painter.setPen(QtGui.QColor("#17202a"))
        painter.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.DemiBold))
        text_rect = self.rect().adjusted(9, 8, -9, -8)
        painter.drawText(text_rect, QtCore.Qt.AlignTop | QtCore.Qt.TextWordWrap, title)
        if self.node.node_type == "group" and self.node.children:
            self._paint_group_preview(painter, text_rect)
        painter.setFont(QtGui.QFont("Segoe UI", 7))
        painter.setPen(QtGui.QColor("#607080"))
        footer = type_label
        painter.drawText(text_rect, QtCore.Qt.AlignBottom | QtCore.Qt.AlignRight, footer)
        if self.isSelected():
            painter.setBrush(QtGui.QColor("#0078d4"))
            painter.setPen(QtCore.Qt.NoPen)
            for handle in self._handle_rects().values():
                painter.drawRect(handle)

    def _tab_add_button_rect(self):
        rect = self.rect()
        position = self.node.properties.get("tabPosition", "top")
        last = self._tab_hit_regions[-1][1] if self._tab_hit_regions else None
        button_size = 14.0
        if self._tab_has_overflow and not self._tab_previous_region.isEmpty():
            previous = self._tab_previous_region
            if position in {"top", "bottom"}:
                return QtCore.QRectF(
                    previous.left() - button_size - 4,
                    previous.center().y() - button_size / 2,
                    button_size, button_size)
            return QtCore.QRectF(
                previous.center().x() - button_size / 2,
                previous.top() - button_size - 4,
                button_size, button_size)
        if position in {"top", "bottom"}:
            header_top = (last.top() if last else
                          rect.top() if position == "top" else rect.bottom() - 28)
            header_height = last.height() if last else 28.0
            y = header_top + (header_height - button_size) / 2
            x = last.right() + 4 if last else rect.left() + 4
            x = min(x, rect.right() - button_size - 4)
            return QtCore.QRectF(x, y, button_size, button_size)
        header_left = (last.left() if last else
                       rect.left() if position == "left" else rect.right() - 28)
        header_width = last.width() if last else 28.0
        x = header_left + (header_width - button_size) / 2
        y = last.bottom() + 4 if last else rect.top() + 4
        y = min(y, rect.bottom() - button_size - 4)
        return QtCore.QRectF(x, y, button_size, button_size)

    def _tab_overflow_button_rect(self):
        if not self._tab_has_overflow or self._tab_add_region.isEmpty():
            return QtCore.QRectF()
        size = 14.0
        position = self.node.properties.get("tabPosition", "top")
        if position in {"top", "bottom"}:
            return QtCore.QRectF(
                self._tab_add_region.left() - size - 4,
                self._tab_add_region.top(), size, size)
        return QtCore.QRectF(
            self._tab_add_region.left(),
            self._tab_add_region.top() - size - 4, size, size)

    def _paint_tab_add_button(self, painter):
        if self.node.node_type != "tab_widget" or self._tab_add_region.isEmpty():
            return
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setBrush(QtGui.QColor("#f3f6f9"))
        painter.setPen(QtGui.QPen(QtGui.QColor("#7b8b9a"), 1))
        painter.drawRoundedRect(self._tab_add_region, 2, 2)
        center = self._tab_add_region.center()
        painter.setPen(QtGui.QPen(QtGui.QColor("#263746"), 1.2))
        painter.drawLine(QtCore.QPointF(center.x() - 3, center.y()),
                         QtCore.QPointF(center.x() + 3, center.y()))
        painter.drawLine(QtCore.QPointF(center.x(), center.y() - 3),
                         QtCore.QPointF(center.x(), center.y() + 3))
        painter.restore()

    def _paint_tab_overflow_button(self, painter):
        if self._tab_overflow_menu_region.isEmpty():
            return
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setBrush(QtGui.QColor("#f3f6f9"))
        painter.setPen(QtGui.QPen(QtGui.QColor("#7b8b9a"), 1))
        painter.drawRoundedRect(self._tab_overflow_menu_region, 2, 2)
        center = self._tab_overflow_menu_region.center()
        path = QtGui.QPainterPath()
        path.moveTo(center.x() - 3.5, center.y() - 1.5)
        path.lineTo(center.x() + 3.5, center.y() - 1.5)
        path.lineTo(center.x(), center.y() + 2.5)
        path.closeSubpath()
        painter.fillPath(path, QtGui.QColor("#263746"))
        painter.restore()

    def _paint_tab_drop_indicator(self, painter):
        if (not self._tab_drag_active or
                self._tab_drag_target_index is None or
                self._tab_drag_origin_index is None or
                self._tab_drag_target_index == self._tab_drag_origin_index or
                not (0 <= self._tab_drag_target_index < len(self._tab_hit_regions))):
            return
        target = self._tab_hit_regions[self._tab_drag_target_index][1]
        forward = self._tab_drag_target_index > self._tab_drag_origin_index
        vertical_tabs = self.node.properties.get("tabPosition", "top") in {
            "left", "right"}
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.fillRect(target, QtGui.QColor(0, 120, 212, 35))
        painter.setPen(QtGui.QPen(
            QtGui.QColor("#0078d4"), 3, QtCore.Qt.SolidLine,
            QtCore.Qt.RoundCap))
        if vertical_tabs:
            y = target.bottom() if forward else target.top()
            painter.drawLine(QtCore.QPointF(target.left(), y),
                             QtCore.QPointF(target.right(), y))
        else:
            x = target.right() if forward else target.left()
            painter.drawLine(QtCore.QPointF(x, target.top()),
                             QtCore.QPointF(x, target.bottom()))
        painter.restore()

    def _paint_group_preview(self, painter, text_rect):
        """Show lightweight child controls without making the preview executable."""
        available = text_rect.adjusted(0, 25, 0, -20)
        if available.height() < 22:
            return
        children = self.node.children
        row_height = max(18.0, min(28.0, available.height() / max(1, len(children))))
        visible_count = max(1, int(available.height() // row_height))
        for index, child in enumerate(children[:visible_count]):
            row = QtCore.QRectF(
                available.left(), available.top() + index * row_height,
                available.width(), row_height - 3,
            )
            fill, outline = TYPE_COLORS.get(child.node_type, ("#ffffff", "#8292a2"))
            painter.setBrush(QtGui.QColor(fill))
            painter.setPen(QtGui.QPen(QtGui.QColor(outline), 1))
            painter.drawRoundedRect(row, 3, 3)
            painter.setPen(QtGui.QColor("#263746"))
            painter.setFont(QtGui.QFont("Segoe UI", 7))
            painter.drawText(row.adjusted(6, 0, -5, 0),
                             QtCore.Qt.AlignVCenter | QtCore.Qt.AlignLeft,
                             child.label)
        hidden = len(children) - visible_count
        if hidden > 0:
            painter.setPen(QtGui.QColor("#607080"))
            painter.drawText(
                available, QtCore.Qt.AlignBottom | QtCore.Qt.AlignRight,
                f"+{hidden} more")

    def _handle_rects(self):
        rect = self.rect()
        half = self.HANDLE / 2
        points = {
            "top-left": rect.topLeft(),
            "top": QtCore.QPointF(rect.center().x(), rect.top()),
            "top-right": rect.topRight(),
            "right": QtCore.QPointF(rect.right(), rect.center().y()),
            "bottom-right": rect.bottomRight(),
            "bottom": QtCore.QPointF(rect.center().x(), rect.bottom()),
            "bottom-left": rect.bottomLeft(),
            "left": QtCore.QPointF(rect.left(), rect.center().y()),
        }
        return {
            name: QtCore.QRectF(point.x() - half, point.y() - half, self.HANDLE, self.HANDLE)
            for name, point in points.items()
        }

    def _handle_at(self, position):
        for name, rect in self._handle_rects().items():
            if rect.contains(position):
                return name
        return ""

    def _tab_page_at(self, position):
        if self.node.node_type != "tab_widget" or not self.node.children:
            return None
        for page_id, rectangle in self._tab_hit_regions:
            if rectangle.contains(position):
                return next(
                    (page for page in self.node.children
                     if page.node_id == page_id), None)
        return None

    def _tab_reorder_index(self, position):
        if not self._tab_hit_regions:
            return 0
        vertical = self.node.properties.get("tabPosition", "top") in {
            "left", "right"}
        coordinate = position.y() if vertical else position.x()
        centers = [
            rectangle.center().y() if vertical else rectangle.center().x()
            for _page_id, rectangle in self._tab_hit_regions
        ]
        return min(
            range(len(centers)), key=lambda index: abs(centers[index] - coordinate))

    def hoverMoveEvent(self, event):
        handle = self._handle_at(event.pos()) if self.isSelected() else ""
        cursors = {
            "top-left": QtCore.Qt.SizeFDiagCursor, "bottom-right": QtCore.Qt.SizeFDiagCursor,
            "top-right": QtCore.Qt.SizeBDiagCursor, "bottom-left": QtCore.Qt.SizeBDiagCursor,
            "top": QtCore.Qt.SizeVerCursor, "bottom": QtCore.Qt.SizeVerCursor,
            "left": QtCore.Qt.SizeHorCursor, "right": QtCore.Qt.SizeHorCursor,
        }
        self.setCursor(cursors.get(handle, QtCore.Qt.OpenHandCursor))
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._tab_header_press = False
            self._tab_drag_page_id = None
            event.accept()
            return
        if (event.button() == QtCore.Qt.LeftButton and
                self.node.node_type == "tab_widget" and
                self._tab_overflow_menu_region.contains(event.pos())):
            self._tab_header_press = True
            self._tab_drag_page_id = None
            self._tab_page_menu_pending = True
            event.accept()
            return
        if (event.button() == QtCore.Qt.LeftButton and
                self.node.node_type == "tab_widget" and
                (self._tab_previous_region.contains(event.pos()) or
                 self._tab_next_region.contains(event.pos()))):
            self._tab_header_press = True
            self._tab_drag_page_id = None
            delta = -1 if self._tab_previous_region.contains(event.pos()) else 1
            tab_widget_id = self.node.node_id
            QtCore.QTimer.singleShot(
                0, lambda: self.designer_scene.navigate_tab_widget(
                    tab_widget_id, delta))
            event.accept()
            return
        if (event.button() == QtCore.Qt.LeftButton and
                self.node.node_type == "tab_widget" and
                self._tab_add_region.contains(event.pos())):
            self._tab_header_press = True
            self._tab_drag_page_id = None
            tab_widget_id = self.node.node_id
            QtCore.QTimer.singleShot(
                0, lambda: self.designer_scene.add_tab_page(tab_widget_id))
            event.accept()
            return
        page = self._tab_page_at(event.pos()) if event.button() == QtCore.Qt.LeftButton else None
        if page is not None:
            self._tab_header_press = True
            self._tab_drag_page_id = page.node_id
            self._tab_drag_target_index = self.node.children.index(page)
            self._tab_drag_origin_index = self._tab_drag_target_index
            self._tab_drag_active = False
            self._tab_drag_start_pos = event.pos()
            self.node.metadata["active_page_id"] = page.node_id
            self.designer_scene.document.set_selection([page.node_id])
            event.accept()
            return
        self._tab_header_press = False
        property_name = "bounds" if self.layout_mode == "canvas" else "pos"
        self._before = list(self.node.properties.get(property_name) or [0, 0, 1, 1])
        self._before += [1] * (4 - len(self._before))
        self._resize_handle = self._handle_at(event.pos()) if self.isSelected() else ""
        self._resizing = bool(self._resize_handle)
        self._press_scene_pos = event.scenePos()
        self._start_item_pos = self.pos()
        self._start_rect = self.rect()
        self._smart_snap_x = False
        self._smart_snap_y = False
        self.designer_scene.clear_alignment_guides()
        if self._resizing:
            event.accept()
        else:
            self.setCursor(QtCore.Qt.ClosedHandCursor)
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if getattr(self, "_tab_header_press", False):
            if self._tab_drag_page_id:
                distance = event.pos() - self._tab_drag_start_pos
                if (abs(distance.x()) + abs(distance.y()) >=
                        QtWidgets.QApplication.startDragDistance()):
                    self._tab_drag_active = True
                    self._tab_drag_target_index = self._tab_reorder_index(event.pos())
                    self.setCursor(QtCore.Qt.ClosedHandCursor)
                    self.update()
                    direction = (
                        -1 if self._tab_previous_region.contains(event.pos())
                        else 1 if self._tab_next_region.contains(event.pos())
                        else 0)
                    if direction != self._tab_drag_edge_direction:
                        self._tab_drag_edge_direction = direction
                        if direction:
                            QtCore.QTimer.singleShot(
                                0, lambda direction=direction:
                                self._auto_scroll_tab_drag(direction))
            event.accept()
            return
        if self._resizing:
            if self.layout_mode == "canvas":
                self._resize_canvas(event.scenePos(), event.modifiers())
                event.accept()
                return
            cell_width, cell_height = self._grid_metrics()
            width = max(cell_width, event.pos().x())
            height = max(cell_height, event.pos().y())
            self.setRect(
                2, 2,
                round(width / cell_width) * cell_width - 4,
                round(height / cell_height) * cell_height - 4)
            self.update()
            event.accept()
        else:
            super().mouseMoveEvent(event)
            if self.layout_mode == "canvas":
                snapped, self._smart_snap_x, self._smart_snap_y = (
                    self.designer_scene.smart_snap_item(
                        self, self.pos(), event.modifiers()))
                self.setPos(snapped)

    def _resize_canvas(self, scene_position, modifiers=QtCore.Qt.NoModifier):
        delta = scene_position - self._press_scene_pos
        x, y = self._start_item_pos.x(), self._start_item_pos.y()
        width, height = self._start_rect.width(), self._start_rect.height()
        minimum = 12.0
        if "left" in self._resize_handle:
            new_x = min(x + delta.x(), x + width - minimum)
            width += x - new_x
            x = new_x
        if "right" in self._resize_handle:
            width = max(minimum, width + delta.x())
        if "top" in self._resize_handle:
            new_y = min(y + delta.y(), y + height - minimum)
            height += y - new_y
            y = new_y
        if "bottom" in self._resize_handle:
            height = max(minimum, height + delta.y())
        proposed = QtCore.QRectF(x, y, width, height)
        proposed, self._smart_snap_x, self._smart_snap_y = (
            self.designer_scene.smart_snap_resize_item(
                self, proposed, self._resize_handle, modifiers))
        x, y = proposed.x(), proposed.y()
        width, height = proposed.width(), proposed.height()
        self.setPos(x, y)
        self.setRect(0, 0, width, height)
        self.update()

    def _geometry_changed_since_press(self):
        """Distinguish a click/selection from an actual move or resize."""
        if not hasattr(self, "_start_item_pos") or not hasattr(self, "_start_rect"):
            return False
        position_delta = self.pos() - self._start_item_pos
        current = self.rect()
        start = self._start_rect
        return (
            abs(position_delta.x()) > 0.5
            or abs(position_delta.y()) > 0.5
            or abs(current.x() - start.x()) > 0.5
            or abs(current.y() - start.y()) > 0.5
            or abs(current.width() - start.width()) > 0.5
            or abs(current.height() - start.height()) > 0.5
        )

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            event.accept()
            return
        if getattr(self, "_tab_header_press", False):
            self._tab_header_press = False
            if self._tab_page_menu_pending:
                self._tab_page_menu_pending = False
                tab_widget_id = self.node.node_id
                screen_position = QtCore.QPoint(event.screenPos())
                QtCore.QTimer.singleShot(
                    0, lambda: self.designer_scene.tabPageMenuRequested.emit(
                        tab_widget_id, screen_position))
                event.accept()
                return
            page_id = self._tab_drag_page_id
            target_index = (
                self._tab_drag_target_index if self._tab_drag_active
                else self._tab_drag_origin_index)
            self._tab_drag_page_id = None
            self._tab_drag_target_index = None
            self._tab_drag_origin_index = None
            self._tab_drag_active = False
            self._tab_drag_edge_direction = 0
            self.node.metadata.pop("header_view_page_id", None)
            self.unsetCursor()
            if page_id is not None:
                QtCore.QTimer.singleShot(
                    0, lambda: self.designer_scene.reorder_tab_page(
                        page_id, target_index))
            event.accept()
            return
        if not self._resizing:
            super().mouseReleaseEvent(event)
        self.designer_scene.clear_alignment_guides()
        self.unsetCursor()
        if not self._geometry_changed_since_press():
            # Existing documents can contain dimensions that are intentionally
            # off the current snap grid. Selecting one must never normalize it.
            self.sync_from_node()
            self._resizing = False
            return
        offset = self._content_offset()
        if self.layout_mode == "canvas":
            snap = self.snap_spacing
            relative_x = self.pos().x() - offset.x()
            relative_y = self.pos().y() - offset.y()
            if self._resizing:
                left = "left" in self._resize_handle
                right = "right" in self._resize_handle
                top = "top" in self._resize_handle
                bottom = "bottom" in self._resize_handle
                x = (max(0, round(relative_x) if self._smart_snap_x
                         else round(relative_x / snap) * snap)
                     if left else self._before[0])
                y = (max(0, round(relative_y) if self._smart_snap_y
                         else round(relative_y / snap) * snap)
                     if top else self._before[1])
                width = (max(snap, round(self.rect().width()) if self._smart_snap_x
                             else round(self.rect().width() / snap) * snap)
                         if left or right else self._before[2])
                height = (max(snap, round(self.rect().height()) if self._smart_snap_y
                              else round(self.rect().height() / snap) * snap)
                          if top or bottom else self._before[3])
            else:
                x = max(0, round(relative_x) if self._smart_snap_x
                        else round(relative_x / snap) * snap)
                y = max(0, round(relative_y) if self._smart_snap_y
                        else round(relative_y / snap) * snap)
                # Moving must never normalize an intentionally off-grid size.
                width, height = self._before[2], self._before[3]
            new_bounds = [x, y, width, height]
            self.sync_from_node()
            self._resizing = False
            self._smart_snap_x = self._smart_snap_y = False
            self.designer_scene.update_status(self.node, new_bounds)
            if self._before and new_bounds != self._before:
                self.designer_scene.undo_stack.push(
                    BoundsCommand(self.designer_scene.document, self.node.node_id, new_bounds))
            return
        cell_width, cell_height = self._grid_metrics()
        row = max(0, round((self.pos().y() - offset.y()) / cell_height))
        col = max(0, round((self.pos().x() - offset.x()) / cell_width))
        row_span = max(1, round((self.rect().height() + 4) / cell_height))
        col_span = max(1, round((self.rect().width() + 4) / cell_width))
        new_pos = [row, col, row_span, col_span]
        self.sync_from_node()
        self._resizing = False
        self.designer_scene.update_status(self.node, new_pos)
        if self._before and new_pos != self._before:
            self.designer_scene.undo_stack.push(
                GeometryCommand(self.designer_scene.document, self.node.node_id, new_pos))

    def keyPressEvent(self, event):
        if event.key() in (QtCore.Qt.Key_Left, QtCore.Qt.Key_Right,
                           QtCore.Qt.Key_Up, QtCore.Qt.Key_Down):
            property_name = "bounds" if self.layout_mode == "canvas" else "pos"
            pos = list(self.node.properties.get(property_name) or [0, 0, 1, 1])
            pos += [1] * (4 - len(pos))
            row_delta = -1 if event.key() == QtCore.Qt.Key_Up else 1 if event.key() == QtCore.Qt.Key_Down else 0
            col_delta = -1 if event.key() == QtCore.Qt.Key_Left else 1 if event.key() == QtCore.Qt.Key_Right else 0
            if self.layout_mode == "canvas":
                step = self.snap_spacing if event.modifiers() & QtCore.Qt.ControlModifier else 1
                if event.modifiers() & QtCore.Qt.ShiftModifier:
                    pos[2] = max(1, pos[2] + col_delta * step)
                    pos[3] = max(1, pos[3] + row_delta * step)
                else:
                    pos[0] = max(0, pos[0] + col_delta * step)
                    pos[1] = max(0, pos[1] + row_delta * step)
                self.designer_scene.undo_stack.push(
                    BoundsCommand(self.designer_scene.document, self.node.node_id, pos))
            elif event.modifiers() & QtCore.Qt.ShiftModifier:
                pos[2] = max(1, pos[2] + row_delta)
                pos[3] = max(1, pos[3] + col_delta)
            else:
                pos[0] = max(0, pos[0] + row_delta)
                pos[1] = max(0, pos[1] + col_delta)
            if self.layout_mode != "canvas":
                self.designer_scene.undo_stack.push(
                    GeometryCommand(self.designer_scene.document, self.node.node_id, pos))
            event.accept()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if (self.node.node_type == "tab_widget" and self._tab_has_overflow and
                self._tab_bar_region.contains(event.pos())):
            delta = -1 if event.delta() > 0 else 1
            tab_widget_id = self.node.node_id
            QtCore.QTimer.singleShot(
                0, lambda: self.designer_scene.navigate_tab_widget(
                    tab_widget_id, delta))
            event.accept()
            return
        super().wheelEvent(event)

    def _auto_scroll_tab_drag(self, direction):
        if (not self._tab_drag_active or
                self._tab_drag_edge_direction != direction or
                not self.node.children):
            return
        view_id = (
            self.node.metadata.get("header_view_page_id")
            or self.node.metadata.get("active_page_id")
            or self._tab_drag_page_id)
        index = next(
            (index for index, page in enumerate(self.node.children)
             if page.node_id == view_id), 0)
        target = max(0, min(len(self.node.children) - 1, index + direction))
        if target == index:
            return
        self.node.metadata["header_view_page_id"] = self.node.children[target].node_id
        self._tab_drag_target_index = target
        self._refresh_preview()
        self.update()
        QtCore.QTimer.singleShot(
            350, lambda: self._auto_scroll_tab_drag(direction))

    def contextMenuEvent(self, event):
        # DesignView owns context menus at viewport level. This avoids native
        # QGraphicsScene context-event inconsistencies on Windows.
        event.accept()

    def _build_context_menu(self, target):
        menu = QtWidgets.QMenu()
        menu.setToolTipsVisible(True)

        def add(label, key, enabled=True):
            action = menu.addAction(label)
            action.setData(key)
            action.setEnabled(enabled)
            return action

        add("Cut", "cut")
        add("Copy", "copy")
        add("Paste", "paste")
        add("Duplicate", "duplicate")
        menu.addSeparator()
        add("Delete", "delete")
        selected = [
            self.designer_scene.document.find(node_id)
            for node_id in self.designer_scene.document.selected_ids
        ]
        selected = [
            node for node in selected
            if node and node.node_type not in {"root", "tab"} and node.parent
        ]
        compatible = bool(selected) and len({
            node.parent.node_id for node in selected
        }) == 1
        if target.node_type not in {"root", "tab"}:
            menu.addSeparator()
            align = menu.addMenu("Align")
            align.setToolTipsVisible(True)
            align.setEnabled(compatible)
            align.menuAction().setToolTip(
                "Align one component to its parent, or align selected siblings to a reference or parent."
                if compatible else
                "Select one movable component, or multiple components in the same parent, to align.")
            directions = (
                ("Left edges", "left"),
                ("Horizontal centers", "hcenter"),
                ("Right edges", "right"),
                ("Top edges", "top"),
                ("Vertical centers", "vcenter"),
                ("Bottom edges", "bottom"),
            )
            if len(selected) > 1 and compatible:
                reference = align.addMenu("Align to First Selected")
                reference.setToolTipsVisible(True)
                for label, direction in directions:
                    action = reference.addAction(label)
                    action.setData(f"align_selection_{direction}")
                    action.setToolTip(
                        "Keep the first-selected component fixed and align the other selected siblings to it.")
            parent = align.addMenu("Align to Parent")
            parent.setToolTipsVisible(True)
            for label, direction in directions:
                action = parent.addAction(label)
                action.setData(f"align_parent_{direction}")
                action.setToolTip(
                    "Align each selected component inside the corresponding edge or center of its parent.")

            distribute = menu.addMenu("Distribute")
            distribute.setToolTipsVisible(True)
            distribute_enabled = compatible and len(selected) >= 3
            distribute.setEnabled(distribute_enabled)
            distribute.menuAction().setToolTip(
                "Space selected siblings with equal gaps while keeping the outer components fixed."
                if distribute_enabled else
                "Select at least three components in the same parent to distribute.")
            rows = distribute.addAction("Rows (Vertically)")
            rows.setData("distribute_vertical")
            rows.setToolTip(
                "Keep the topmost and bottommost components fixed and make the vertical gaps equal.")
            columns = distribute.addAction("Columns (Horizontally)")
            columns.setData("distribute_horizontal")
            columns.setToolTip(
                "Keep the leftmost and rightmost components fixed and make the horizontal gaps equal.")
        if target.node_type == "tab":
            index = target.parent.children.index(target)
            menu.addSeparator()
            add("Move Left / Up", "move_left", index > 0)
            add("Move Right / Down", "move_right",
                index < len(target.parent.children) - 1)
        elif target.node_type == "tab_widget":
            menu.addSeparator()
            add("Add Page", "add_page")
        if (target.node_type not in {"tab", "root"} and target.parent and
                self.designer_scene._node_layout_mode(target.parent) == "canvas"):
            menu.addSeparator()
            add("Bring to Front", "bring_front")
            add("Send to Back", "send_back")
        return menu
