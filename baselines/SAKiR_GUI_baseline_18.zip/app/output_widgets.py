import re, json, pickle, datetime
from PyQt5 import QtWidgets, QtCore, QtGui
from bs4 import BeautifulSoup
from rich.pretty import pretty_repr
from PyQt5.QtCore import Qt, QAbstractTableModel
from PyQt5.QtGui import QColor, QBrush, QFont
import numpy as np
import pandas as pd
from pandas.io.formats.style import Styler
import traceback

class PyObjectTreeItem:
    __slots__ = ("key", "value", "parent", "children")

    def __init__(self, key, value, parent=None):
        self.key = key
        self.value = value
        self.parent = parent
        self.children = []

    def child(self, row):
        return self.children[row]

    def child_count(self):
        return len(self.children)

    def column_count(self):
        return 3  # Key | Type | Value

    def row(self):
        if self.parent:
            return self.parent.children.index(self)
        return 0

    def data(self, column):
        if column == 0:
            return str(self.key)
        if column == 1:
            return type(self.value).__name__
        if column == 2:
            try:
                r = repr(self.value)
                return r if len(r) < 300 else r[:300] + "…"
            except Exception:
                return "<unreprable>"

def build_object_tree(obj, parent=None, seen=None):
    if seen is None:
        seen = set()

    obj_id = id(obj)
    if obj_id in seen:
        return PyObjectTreeItem("<cycle>", "<recursive>", parent)

    seen.add(obj_id)

    # ---- DICT ----
    if isinstance(obj, dict):
        root = PyObjectTreeItem("dict", obj, parent)
        for k, v in obj.items():
            child = build_object_tree(v, root, seen)
            child.key = k
            root.children.append(child)
        return root

    # ---- SEQUENCES ----
    elif isinstance(obj, (list, tuple, set)):
        root = PyObjectTreeItem(type(obj).__name__, obj, parent)
        for i, v in enumerate(obj):
            child = build_object_tree(v, root, seen)
            child.key = i
            root.children.append(child)
        return root

    # ---- NUMPY ----
    elif isinstance(obj, np.ndarray):
        root = PyObjectTreeItem("ndarray", obj, parent)
        root.children.append(PyObjectTreeItem("shape", obj.shape, root))
        root.children.append(PyObjectTreeItem("dtype", obj.dtype, root))
        return root

    # ---- CUSTOM OBJECT ----
    elif hasattr(obj, "__dict__"):
        root = PyObjectTreeItem(type(obj).__name__, obj, parent)
        for k, v in vars(obj).items():
            child = build_object_tree(v, root, seen)
            child.key = k
            root.children.append(child)
        return root

    # ---- LEAF ----
    else:
        return PyObjectTreeItem("", obj, parent)

class PyObjectTreeModel(QtCore.QAbstractItemModel):
    def __init__(self, root, parent=None):
        super().__init__(parent)
        self.root = root

    def columnCount(self, parent):
        return 3

    def rowCount(self, parent):
        item = parent.internalPointer() if parent.isValid() else self.root
        return item.child_count()

    def index(self, row, col, parent):
        parent_item = parent.internalPointer() if parent.isValid() else self.root
        if row >= parent_item.child_count():
            return QtCore.QModelIndex()
        return self.createIndex(row, col, parent_item.child(row))

    def parent(self, index):
        if not index.isValid():
            return QtCore.QModelIndex()

        parent_item = index.internalPointer().parent
        if parent_item is None or parent_item == self.root:
            return QtCore.QModelIndex()

        return self.createIndex(parent_item.row(), 0, parent_item)

    def data(self, index, role):
        if not index.isValid():
            return None
        item = index.internalPointer()
        if role == QtCore.Qt.DisplayRole:
            return item.data(index.column())
        return None

    def headerData(self, sec, orient, role):
        if role == QtCore.Qt.DisplayRole and orient == QtCore.Qt.Horizontal:
            return ["Key", "Type", "Value"][sec]

class ObjectTreeViewer(QtWidgets.QWidget):
    """
    Fully Featured Python Object Tree Viewer

    Features:
        ✅ set_object(obj)
        ✅ live refresh()
        ✅ search / filter
        ✅ copy as repr
        ✅ copy as json
        ✅ send node -> DataFrame
        ✅ send node -> JSON
        ✅ cycle safe
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        self._current_object = None

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Search object tree...")
        layout.addWidget(self.search)

        self.tree = QtWidgets.QTreeView()
        self.tree.setUniformRowHeights(True)
        self.tree.setAlternatingRowColors(True)
        layout.addWidget(self.tree)

        self._proxy = QtCore.QSortFilterProxyModel()
        self._proxy.setRecursiveFilteringEnabled(True)
        self._proxy.setFilterCaseSensitivity(QtCore.Qt.CaseInsensitive)

        self.search.textChanged.connect(self._filter)

    # =====================================================
    # Public API (like set_array)
    # =====================================================

    def set_object(self, obj):
        self._current_object = obj
        self.refresh()

    def refresh(self):
        if self._current_object is None:
            return

        root = build_object_tree(self._current_object)
        model = PyObjectTreeModel(root)

        self._proxy.setSourceModel(model)
        self.tree.setModel(self._proxy)

        self.tree.expandToDepth(2)
        for i in range(3):
            self.tree.resizeColumnToContents(i)

    # =====================================================
    # Filtering
    # =====================================================

    def _filter(self, text):
        self._proxy.setFilterWildcard(text)
        self.tree.expandAll()

    # =====================================================
    # Context Menu
    # =====================================================


    # =====================================================
    # Helpers
    # =====================================================

    def _get_selected_value(self):
        idx = self.tree.currentIndex()
        if not idx.isValid():
            return None
        src = self._proxy.mapToSource(idx)
        return src.internalPointer().value

    def _copy_repr(self):
        val = self._get_selected_value()
        if val is not None:
            QtWidgets.QApplication.clipboard().setText(repr(val))

    def _copy_json(self):
        val = self._get_selected_value()
        if val is None:
            return
        try:
            txt = json.dumps(val, indent=2, default=str)
        except Exception:
            txt = json.dumps(str(val), indent=2)
        QtWidgets.QApplication.clipboard().setText(txt)

    def _send_df(self):
        val = self._get_selected_value()
        if val is None:
            return
        try:
            if isinstance(val, dict):
                df = pd.DataFrame(val.items(), columns=["Key", "Value"])
            elif isinstance(val, (list, tuple, set)):
                df = pd.DataFrame(list(val), columns=["Value"])
            else:
                df = pd.DataFrame([val], columns=["Value"])

            if hasattr(self.parent(), "display"):
                self.parent().display(df, mode="replace")

        except Exception as e:
            if hasattr(self.parent(), "display"):
                self.parent().display(f"[DF Send Error] {e}")

    def _send_json(self):
        val = self._get_selected_value()
        if val is None:
            return
        try:
            txt = json.dumps(val, indent=2, default=str)
        except Exception:
            txt = repr(val)

        if hasattr(self.parent(), "display"):
            self.parent().display(txt, mode="replace")

class RotatedLabel(QtWidgets.QLabel):
    """
    A QLabel that draws its text rotated 90° counter-clockwise.
    Used for compact vertical labels: 'rows (size=N)'.
    """
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.setAlignment(QtCore.Qt.AlignCenter)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.TextAntialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)
        painter.translate(self.width() / 2, self.height() / 2)
        painter.rotate(-90)  # rotate counter-clockwise
        painter.translate(-self.height() / 2, -self.width() / 2)
        rect = QtCore.QRect(0, 0, self.height(), self.width())
        painter.drawText(rect, QtCore.Qt.AlignCenter, self.text())

    def sizeHint(self):
        # swap width/height because it's rotated
        s = super().sizeHint()
        return QtCore.QSize(s.height(), s.width())

class NDArrayModel(QtCore.QAbstractTableModel):
    def __init__(self, array_2d):
        super().__init__()
        self.arr = array_2d

    def rowCount(self, parent=None):
        return 0 if self.arr is None else self.arr.shape[0]

    def columnCount(self, parent=None):
        return 0 if self.arr is None else self.arr.shape[1]

    def data(self, index, role=Qt.DisplayRole):
        if (
            not index.isValid()
            or self.arr is None
            or index.row() < 0
            or index.column() < 0
            or index.row() >= self.rowCount()
            or index.column() >= self.columnCount()
        ):
            return None

        val = self.arr[index.row(), index.column()]

        if role == Qt.DisplayRole:
            if isinstance(val, float):
                if np.isnan(val):
                    return ""
                return f"{val:.6g}"   # ✅ fast formatting
            return str(val)

        if role == Qt.TextAlignmentRole:
            return Qt.AlignRight | Qt.AlignVCenter

        return None

    def set_array(self, arr):
        self.beginResetModel()
        self.arr = arr
        self.endResetModel()

class ArrayViewer(QtWidgets.QWidget):
    """
    Fully Featured MATLAB-Style N-D NumPy Array Viewer
    --------------------------------------------------
    Features:
        ✔ Supports arrays of ANY dimension (1D → ∞D)
        ✔ Dim selectors appear in ONE horizontal scroll row
        ✔ Clean 2D table slice viewer
        ✔ 'rows(size=N)' vertical rotated label
        ✔ 'columns(size=M)' horizontal label
        ✔ Never repeats 'size' on every row/col
        ✔ Efficient slicing, no recursion
        ✔ Can be instantiated EMPTY and updated later with set_array()
    """

    def __init__(self, arr=None, parent=None):
        super().__init__(parent)

        self.arr = None
        self.shape = ()
        self.nd = 0
        self.selectors = []

        self.setWindowTitle("N-D Array Viewer")

        self._build_ui()

        if arr is not None:
            self.set_array(arr)

    # =========================================================
    # UI BUILD (UNCHANGED STRUCTURE, NOW SAFE)
    # =========================================================
    def _build_ui(self):
        old = self.layout()
        if old:
            while old.count():
                item = old.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            old.deleteLater()

        main_layout = QtWidgets.QVBoxLayout(self)

        # =========================================================
        # DIMENSION SELECTORS (horizontal scroll area)
        # =========================================================
        self.selector_scroll = QtWidgets.QScrollArea()
        self.selector_scroll.setWidgetResizable(True)
        self.selector_scroll.setFixedHeight(40)
        self.selector_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        self.selector_scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.selector_scroll.setVisible(False)

        selector_widget = QtWidgets.QWidget()
        self.selector_layout = QtWidgets.QHBoxLayout(selector_widget)
        self.selector_layout.setContentsMargins(5, 5, 5, 5)
        self.selector_layout.setSpacing(15)

        self.selector_scroll.setWidget(selector_widget)
        main_layout.addWidget(self.selector_scroll)

        # =========================================================
        # COLUMN SIZE LABEL
        # =========================================================
        self.col_label = QtWidgets.QLabel("")
        self.col_label.setAlignment(QtCore.Qt.AlignCenter)
        self.col_label.setStyleSheet("font-size: 10px")
        main_layout.addWidget(self.col_label)

        # =========================================================
        # MAIN TABLE LAYOUT WITH ROTATED ROW LABEL
        # =========================================================
        table_container = QtWidgets.QHBoxLayout()

        self.row_label = RotatedLabel("")
        self.row_label.setStyleSheet("font-size: 10px")
        self.row_label.setMaximumWidth(10)
        table_container.addWidget(self.row_label)

        self.table = QtWidgets.QTableView()
        self.table.setFont(QtGui.QFont("Consolas", 10))
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideNone)
        self.table.setAlternatingRowColors(False)
        self.table.setSortingEnabled(False)

        self.table.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollPerPixel)
        self.table.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollPerPixel)

        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Fixed)
        self.table.verticalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Fixed)

        self.table.horizontalHeader().setDefaultSectionSize(80)
        self.table.verticalHeader().setDefaultSectionSize(18)

        table_container.addWidget(self.table)
        main_layout.addLayout(table_container)

    # =========================================================
    # SET / UPDATE ARRAY (LIVE SAFE UPDATE)
    # =========================================================
    def set_array(self, arr: np.ndarray):
        """
        Update or replace the currently displayed array.
        Safely rebuilds selectors & refreshes the view.
        """
        if not isinstance(arr, np.ndarray):
            raise TypeError("ArrayViewer only accepts numpy.ndarray")

        self.arr = arr
        self.shape = arr.shape
        self.nd = arr.ndim

        self.setWindowTitle(f"N-D Array Viewer  (shape={arr.shape})")

        self._rebuild_selectors()
        self._refresh_table()

    # =========================================================
    # SELECTOR REBUILD (FULLY SAFE)
    # =========================================================
    def _rebuild_selectors(self):
        for s in self.selectors:
            s.deleteLater()
        self.selectors.clear()

        while self.selector_layout.count():
            item = self.selector_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self.selector_scroll.setVisible(self.nd > 2)

        if self.nd > 2:
            for dim in range(2, self.nd):
                sz = self.shape[dim]

                lbl = QtWidgets.QLabel(f"dim{dim} (size: {sz}):")
                spin = QtWidgets.QSpinBox()
                spin.setRange(0, sz - 1)
                spin.valueChanged.connect(self._refresh_table)

                self.selector_layout.addWidget(lbl)
                self.selector_layout.addWidget(spin)
                self.selectors.append(spin)

        self.selector_layout.addStretch()

    # =========================================================
    # SLICE N-D ARRAY TO 2D (UNCHANGED LOGIC)
    # =========================================================
    def _get_2d_slice(self):
        if self.arr is None:
            return None

        a = self.arr

        if self.nd == 1:
            return a.reshape(1, -1)

        if self.nd == 2:
            return a

        slicer = [
            slice(None),  # dim 0 → rows
            slice(None)   # dim 1 → cols
        ]

        for spin in self.selectors:
            slicer.append(spin.value())

        return a[tuple(slicer)]

    # =========================================================
    # REFRESH TABLE (UNCHANGED BEHAVIOR)
    # =========================================================
    def _refresh_table(self):
        arr2 = self._get_2d_slice()
        if arr2 is None:
            self.table.setModel(None)
            self.col_label.setText("")
            self.row_label.setText("")
            return

        rows, cols = arr2.shape

        self.col_label.setText(f"columns (dim1, size: {cols})")
        self.row_label.setText(f"rows (dim0, size: {rows})")

        # ✅ DO NOT recreate model unless shape changed
        if not hasattr(self, "_model") or self._model.arr.shape != arr2.shape:
            self._model = NDArrayModel(arr2)
            self.table.setModel(self._model)
        else:
            self._model.arr = arr2
            self._model.layoutChanged.emit()

class StyledDFModel(QAbstractTableModel):
    """DataFrame/Styler-aware model with fast, style-aware rendering."""

    def __init__(self, data: pd.DataFrame):
        super().__init__()

        # Detect whether it's a Styler or a plain DataFrame
        if isinstance(data, pd.io.formats.style.Styler):
            self.df = data.data
            self.styles = self._extract_styles(data)
        else:
            self.df = data
            self.styles = {}

        self._numeric_columns = self.df.select_dtypes(include=[np.number]).columns

    def rowCount(self, parent=None):
        if parent is not None and parent.isValid():
            return 0
        return len(self.df.index)

    def columnCount(self, parent=None):
        if parent is not None and parent.isValid():
            return 0
        return len(self.df.columns)

    def data(self, index, role=Qt.DisplayRole):
        if (
            not index.isValid()
            or index.row() < 0
            or index.column() < 0
            or index.row() >= len(self.df.index)
            or index.column() >= len(self.df.columns)
        ):
            return None

        row, col = index.row(), index.column()
        value = self.df.iat[row, col]

        if role == Qt.DisplayRole:
            # simple formatting
            return str(value)

        # --- Style roles ---
        if (row, col) in self.styles:
            style_dict = self.styles[(row, col)]
            if role == Qt.BackgroundRole and 'background-color' in style_dict:
                return QBrush(QColor(style_dict['background-color']))
            if role == Qt.ForegroundRole and 'color' in style_dict:
                return QBrush(QColor(style_dict['color']))
            if role == Qt.FontRole and 'font-weight' in style_dict:
                font = QFont()
                if style_dict['font-weight'] in ('bold', '700'):
                    font.setBold(True)
                return font

        # Default alignment
        if role == Qt.TextAlignmentRole:
            if self.df.columns[col] in self._numeric_columns:
                return Qt.AlignRight | Qt.AlignVCenter
            return Qt.AlignLeft | Qt.AlignVCenter

        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            if section < 0 or section >= len(self.df.columns):
                return None
            return str(self.df.columns[section])
        else:
            if section < 0 or section >= len(self.df.index):
                return None
            return str(self.df.index[section])

    # =========================================================
    # Style extraction from pandas Styler
    # =========================================================
    def _extract_styles(self, styler):
        """
        Converts Styler's internal ctx dict into a
        {(row, col): {'property': 'value'}} mapping.
        """
        styles = {}
        try:
            ctx = styler._compute().ctx  # {(row, col): [("color","red"),("background-color","blue")]}
            for key, css_list in ctx.items():
                styles[key] = {prop: val for prop, val in css_list}
        except Exception:
            pass
        return styles

    def sort(self, column, order=Qt.AscendingOrder):
        """Advanced stable sort with NaN handling and natural string ordering."""
        if column < 0 or column >= len(self.df.columns):
            return
        try:
            col_name = self.df.columns[column]
            ascending = (order == Qt.AscendingOrder)

            self.layoutAboutToBeChanged.emit()

            series = self.df[col_name]

            # ✅ Detect numeric vs object column
            if pd.api.types.is_numeric_dtype(series):
                # ✅ Stable numeric sort with NaN always at bottom
                self.df = self.df.sort_values(
                    by=col_name,
                    ascending=ascending,
                    na_position="last",
                    kind="mergesort"  # ✅ STABLE SORT
                )

            else:
                # ✅ NATURAL STRING SORT (item2 < item10)
                try:
                    import re

                    def natural_key(val):
                        if pd.isna(val):
                            return (1, "")
                        val = str(val)
                        return (
                            0,
                            [int(t) if t.isdigit() else t.lower()
                            for t in re.split(r"(\d+)", val)]
                        )

                    self.df = self.df.assign(
                        __sortkey__=series.map(natural_key)
                    ).sort_values(
                        "__sortkey__",
                        ascending=ascending,
                        kind="mergesort"
                    ).drop(columns="__sortkey__")

                except Exception:
                    # ✅ Fallback safe lexicographic sort
                    self.df = self.df.sort_values(
                        by=col_name,
                        ascending=ascending,
                        na_position="last",
                        kind="mergesort"
                    )

            # ✅ Rebuild numeric column cache
            self._numeric_columns = self.df.select_dtypes(include=[np.number]).columns

            # ✅ Re-map styles to new row order safely
            if self.styles:
                new_styles = {}
                for (old_row, col), style in self.styles.items():
                    if old_row < len(self.df):
                        new_styles[(old_row, col)] = style
                self.styles = new_styles

            self.layoutChanged.emit()

        except Exception as e:
            pass

def setup_table_view(table: QtWidgets.QTableView):
    table.setSortingEnabled(True)

    # ✅ User resizable columns
    h = table.horizontalHeader()
    h.setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
    h.setDefaultAlignment(Qt.AlignCenter)

    # ✅ FORCE HEADER HEIGHT FOR MULTI-LINE TEXT
    h.setMinimumHeight(80) 

    table.setAlternatingRowColors(True)
    table.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
    table.setSelectionMode(QtWidgets.QTableView.ExtendedSelection)

class OutputArea(QtWidgets.QFrame):
    _sig_display = QtCore.pyqtSignal(object, str)

    def __init__(self, instance: str, kind: str = 'any', editable=False, dockable=True, df_row_height = "", df_column_width = "", df_auto_wrap = True, allow_save=True, parent=None):
        super().__init__(parent)
        self.instance = instance
        self.kind = kind
        self.editable = editable
        self.autoscroll = True
        self._force_auto_scroll = False
        self.dockable = dockable
        self._docked = True
        self.df_row_height = df_row_height
        self.df_column_width = df_column_width
        self.df_auto_wrap = df_auto_wrap
        self.allow_save = allow_save
        self.display_gen = 0
        self.scroll_capture = True
        self.scroll_pos = 0
        self.last_content = None

        # === Widgets ===
        self._stack = QtWidgets.QStackedWidget()
        self._text = QtWidgets.QTextEdit()
        self._text.setReadOnly(not editable)

        self._table = QtWidgets.QTableView()
        setup_table_view(self._table)
        self._last_sort_column = None
        self._last_sort_order = Qt.AscendingOrder
        self._table.horizontalHeader().sortIndicatorChanged.connect(
            self._on_user_sort_changed
        )
        self._model = None

        self._widget_holder = QtWidgets.QWidget()
        self._widget_layout = QtWidgets.QVBoxLayout(self._widget_holder)
        self._widget_layout.setContentsMargins(0, 0, 0, 0)

        self._array = ArrayViewer()
        
        self._object_viewer = ObjectTreeViewer()

        # Add subwidgets
        self._stack.addWidget(self._text)
        self._stack.addWidget(self._table)
        self._stack.addWidget(self._widget_holder)
        self._stack.addWidget(self._array)
        self._stack.addWidget(self._object_viewer)

        # Layout
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(self._stack)

        # Thread-safety
        self._sig_display.connect(self._safe_display, QtCore.Qt.QueuedConnection)

        if self.kind != "widget":
            self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.customContextMenuRequested.connect(self._context_menu)

        # Context menu
        # Forward right-clicks from inner widgets too
        for child in (self._text, self._table):
            child.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            child.customContextMenuRequested.connect(self._context_menu)

    def container(self):
        return self

    # =========================================================
    # Public API (thread-safe)
    # =========================================================
    def display(self, content, mode='append'):
        """Thread-safe entry point"""
        self._sig_display.emit(content, mode)

    # =========================================================
    # Internal display logic (GUI thread)
    # =========================================================
    @QtCore.pyqtSlot(object, str)
    def _safe_display(self, content, mode='append'):
        self.display_gen +=1
        gen = self.display_gen
        self._store_scroll_state(mode)

        try:
            detected_kind = self._detect_kind(content)
            kind = self.kind if self.kind != 'any' else detected_kind

            # Validate type compatibility
            if not self._validate_kind(content, detected_kind):
                self._stack.setCurrentWidget(self._text)
                self._text.insertPlainText(
                    f"[Display Warning] '{self.instance}' expects '{self.kind}' but got '{type(content).__name__}'\n"
                )
                return

            # === TEXT / HTML / MARKDOWN ===
            if kind in ('text', 'html', 'markdown'):
                self._stack.setCurrentWidget(self._text)

                if isinstance(content, bytes):
                    content = content.decode('utf-8', errors='replace')

                # Markdown → HTML
                if kind == 'markdown':
                    try:
                        import markdown2
                        content = markdown2.markdown(content)
                        kind = 'html'
                    except Exception:
                        kind = 'text'

                # --- Append or replace ---
                if mode == 'replace':
                    if kind == 'html':
                        self._text.setHtml(content + "<br>")
                    else:
                        self._text.setPlainText(content + "\n")
                else:  # append mode
                    cursor = self._text.textCursor()
                    cursor.movePosition(QtGui.QTextCursor.End)
                    if kind == 'html':
                        cursor.insertHtml(content + "<br>")
                    else:
                        cursor.insertText(content + "\n")
                    self._text.setTextCursor(cursor)

            # === DATAFRAME ===
            elif kind == 'df' or kind == 'styled_df':
                self._stack.setCurrentWidget(self._table)

                try:
                    # ✅ Apply auto-wrap BEFORE model creation
                    if isinstance(content, pd.DataFrame):
                        df = content.copy()
                        df = self._apply_df_auto_wrap(df)
                        self._model = StyledDFModel(df)

                    elif isinstance(content, Styler):
                        orig_df = content.data.copy()
                        wrapped_df = self._apply_df_auto_wrap(orig_df)
                        new_styler = wrapped_df.style
                        try:
                            new_styler._todo = [
                                self._wrap_styler_rule_args(rule)
                                for rule in list(content._todo)
                            ]
                        except Exception as e:
                            pass

                        # ✅ 5. Use rebuilt Styler
                        self._model = StyledDFModel(new_styler)

                    else:
                        self._model = StyledDFModel(content)

                    self._table.setModel(self._model)

                    # ✅ Restore previous sort
                    if self._last_sort_column is not None:
                        self._table.sortByColumn(
                            self._last_sort_column,
                            self._last_sort_order
                        )

                    # ✅ APPLY CUSTOM COLUMN WIDTH IF PROVIDED
                    if self.df_column_width:
                        if isinstance(self.df_column_width, int):
                            for i in range(self._model.columnCount()):
                                self._table.setColumnWidth(i, self.df_column_width)

                        elif isinstance(self.df_column_width, dict):
                            for col, width in self.df_column_width.items():
                                self._table.setColumnWidth(col, width)

                    else:
                        self._table.resizeColumnsToContents()

                    # ✅ APPLY CUSTOM ROW HEIGHT IF PROVIDED
                    if self.df_row_height:
                        if isinstance(self.df_row_height, int):
                            for i in range(self._model.rowCount()):
                                self._table.setRowHeight(i, self.df_row_height)

                        elif isinstance(self.df_row_height, dict):
                            for row, height in self.df_row_height.items():
                                self._table.setRowHeight(row, height)

                    else:
                        self._table.resizeRowsToContents()

                except Exception as e:
                    self._stack.setCurrentWidget(self._text)
                    self._text.insertPlainText(f"[Display Error: {traceback.format_exc()}]")
                    return

            # === IMAGE ===
            elif kind == 'image':
                self._stack.setCurrentWidget(self._widget_holder)
                lbl = QtWidgets.QLabel()
                lbl.setAlignment(QtCore.Qt.AlignCenter)
                pix = self._to_pixmap(content)
                if pix:
                    if mode == 'replace':
                        self._clear_widget_holder()
                    lbl.setPixmap(pix)
                    self._widget_layout.addWidget(lbl)
                else:
                    self._text.insertPlainText("[Display Error] Could not render image\n")

            # === IMAGE ===
            elif kind == 'array':
                self._stack.setCurrentWidget(self._array)
                self._array.set_array(content)
            
            elif kind == "object":
                self._stack.setCurrentWidget(self._object_viewer)
                self._object_viewer.set_object(content)
            
            elif kind == "dict":
                self._stack.setCurrentWidget(self._text)

                max_width = self._text.viewport().width() // 8
                pretty = pretty_repr(content, max_width=max_width, expand_all=True)

                # --- Append or replace ---
                if mode == 'replace':
                    self._text.setPlainText(pretty + "\n")
                else:  # append mode
                    cursor = self._text.textCursor()
                    cursor.movePosition(QtGui.QTextCursor.End)
                    cursor.insertText(pretty + "\n")
                    self._text.setTextCursor(cursor)

            # === GENERIC WIDGET ===
            elif kind == "widget":
                self._stack.setCurrentWidget(self._widget_holder)
                attached = (
                    self._widget_layout.count() == 1
                    and self._widget_layout.itemAt(0).widget() is content
                    and content.parent() is self._widget_holder
                )
                needs_insert = (
                    mode == "append"
                    or content is not self.last_content
                    or not attached
                )
                if needs_insert:
                    if mode == 'replace':
                        self._clear_widget_holder()
                        self._widget_layout.addWidget(content)
                    elif not attached:
                        self._widget_layout.addWidget(content)
                content.show()

            # === UNKNOWN TYPE ===
            else:
                if self.kind == 'any' and detected_kind == 'unknown':
                    self._stack.setCurrentWidget(self._text)
                    try:
                        pretty = str(content)
                    except Exception:
                        pretty = f"<unprintable object of type {type(content).__name__}>"

                    if mode == 'append':
                        self._text.insertPlainText(pretty + "\n")
                    else:
                        self._text.setPlainText(pretty)
                else:
                    self._stack.setCurrentWidget(self._text)
                    self._text.insertPlainText(f"[Unsupported content type: {type(content).__name__}]\n")
            
            self.last_content = content
        except Exception as e:
            self._stack.setCurrentWidget(self._text)
            self._text.insertPlainText(f"[Display Error] {e}\n")
            return

        QtCore.QTimer.singleShot(0, lambda g=gen, m=mode: self._restore_scroll_state(g, m))

    # =========================================================
    # Type helpers
    # =========================================================
    def _detect_kind(self, content):

        # === STRING-LIKE CONTENT ===
        if isinstance(content, (str, bytes)):
            s = content if isinstance(content, str) else content.decode(errors='ignore')
            if self._is_markdown(s):
                return 'markdown'
            if self._is_html(s):
                return 'html'
            return 'text'

        # === PANDAS STRUCTURES ===
        if isinstance(content, Styler):
            return 'styled_df'

        if isinstance(content, pd.DataFrame):
            return 'df'

        # === VISUAL TYPES ===
        if isinstance(content, (QtGui.QPixmap, QtGui.QImage)):
            return 'image'

        if isinstance(content, np.ndarray):
            return 'array'

        # === WIDGETS ===
        if isinstance(content, QtWidgets.QWidget):
            return 'widget'
        
        if isinstance(content, dict):
            return "dict"

        if isinstance(content, object):
            return "object"

        # === FALLBACK ===
        return 'unknown'

    def _is_html(self, text: str) -> bool:
        if not text or not isinstance(text, str):
            return False
        soup = BeautifulSoup(text, "html.parser")
        # If it successfully parses and has tags, it's HTML
        return bool(soup.find()) or bool(soup.contents and any(hasattr(c, "name") for c in soup.contents))

    def _is_markdown(self, s: str) -> bool:
        """
        Heuristically detect Markdown content with minimal false positives.
        """
        if not isinstance(s, str) or len(s) < 10:
            return False

        # Markdown patterns that usually appear at line starts or strong delimiters
        md_patterns = [
            r"^#{1,6}\s",                # headings (#, ##, ### ...)
            r"(?<!\w)\*{1,2}[^*]+?\*{1,2}(?!\w)",  # bold/italic pairs
            r"(?<!\w)_[^_]+?_(?!\w)",    # italic underscore style
            r"`[^`]+`",                  # inline code
            r"^\s*[-*+]\s+",             # unordered lists
            r"^\s*\d+\.\s+",             # ordered lists
            r"\[[^\]]+\]\([^)]+\)",      # [link](url)
            r"^>\s+",                    # blockquote
            r"^\s*---+",                 # horizontal rule
        ]

        for pat in md_patterns:
            if re.search(pat, s, re.MULTILINE):
                return True
        return False

    def _validate_kind(self, content, detected_kind):
        """
        Validates that the detected kind matches the declared output_kind.
        Returns True if OK, False if incompatible.
        """
        if self.kind in ('any', 'object', detected_kind):
            return True

        valid_map = {
            'text': (str, bytes),
            'html': (str, bytes),
            'markdown': (str, bytes),
            'df': ('DataFrame', 'Styler'),
            'widget': (QtWidgets.QWidget,),
            'image': ('QImage', 'QPixmap', 'ndarray',),
            'array': ('ndarray',),
            'dict': (dict,),
            'object': (object,),
        }

        # check against expected types
        expected = valid_map.get(self.kind, ())
        typename = type(content).__name__
        is_valid = any(
            isinstance(content, t) if isinstance(t, type) else t in typename
            for t in expected
        )

        if not is_valid:
            # Thread-safe message display — queued to main thread
            def _warn():
                QtWidgets.QMessageBox.warning(
                    self,
                    "Output Type Mismatch",
                    (
                        f"⚠️ Output widget '{self.instance}' is configured as '{self.kind}', "
                        f"but received data of type '{typename}'.\n\n"
                        f"💡 Tip: Change output_kind to 'any' or use a compatible type."
                    )
                )

            QtCore.QTimer.singleShot(0, _warn)
            return False

        return True

    def _to_pixmap(self, content):
        from PyQt5 import QtGui
        import numpy as np
        if isinstance(content, QtGui.QPixmap):
            return content
        elif isinstance(content, QtGui.QImage):
            return QtGui.QPixmap.fromImage(content)
        elif isinstance(content, np.ndarray):
            h, w = content.shape[:2]
            if content.ndim == 2:
                fmt = QtGui.QImage.Format_Grayscale8
            else:
                fmt = QtGui.QImage.Format_RGB888
            img = QtGui.QImage(content.data, w, h, content.strides[0], fmt)
            return QtGui.QPixmap.fromImage(img)
        return None

    def _clear_widget_holder(self):
        while self._widget_layout.count():
            item = self._widget_layout.takeAt(0)
            if item.widget(): 
                self._widget_layout.removeWidget(item.widget())
                item.widget().setParent(None)
        
        self.last_content = None
    
    def _store_scroll_state(self, mode):
        """
        Capture scroll position and whether the user was near the bottom.
        Returns a tuple: (was_at_bottom: bool, previous_value: int)
        """

        if self.scroll_capture:
            self.scroll_capture = False
            vbar = self._text.verticalScrollBar()
            
            self.scroll_prev_val = vbar.value()
            was_at_bottom = self.scroll_prev_val >= vbar.maximum() and self.scroll_prev_val != 0

            if not was_at_bottom:
                self.autoscroll = False
            if self._force_auto_scroll:
                self.autoscroll = True
                self._force_auto_scroll = False

    def _restore_scroll_state(self, gen, mode):
        """
        Restore scroll position after widget content update.

        Behavior:
        - If autoscroll is enabled → scroll to bottom.
        - If user was near bottom before → follow new bottom.
        - Otherwise restore their previous offset safely.
        """
        if gen != self.display_gen:
            return
        
        vbar = self._text.verticalScrollBar()

        if self.autoscroll and mode == "append":
            vbar.setValue(vbar.maximum())
        else:
            vbar.setValue(min(self.scroll_prev_val, vbar.maximum()))
        
        self.scroll_capture = True

    def _on_user_sort_changed(self, logicalIndex, order):
        self._last_sort_column = logicalIndex
        self._last_sort_order = order

    # =========================================================
    # Dock / Context menu
    # =========================================================
    def _context_menu(self, pos):
        menu = QtWidgets.QMenu(self)
        if self.dockable:
            if self._docked:
                act = menu.addAction('Undock')
                act.triggered.connect(self._undock)
            else:
                act = menu.addAction('Dock')
                act.triggered.connect(self._dock)
        menu.addSeparator()
        auto_scroll = menu.addAction('Auto Scroll')
        auto_scroll.triggered.connect(self._auto_scroll)
        act_clear = menu.addAction('Clear')
        act_clear.triggered.connect(self.clear)
        
        if self.allow_save:
            act_save = menu.addAction('Save to File')
            act_save.triggered.connect(self._save_to_file)
            
        menu.exec_(self.mapToGlobal(pos))

    def clear(self):
        self._text.clear()
        self._clear_widget_holder()
        if self._model:
            self._table.setModel(None)
            self._model = None

    def _save_to_file(self):
        """Save current visible content to a user-chosen file (ALL KINDS, ALL FORMATS)."""
        current_widget = self._stack.currentWidget()
        default = f"{self.instance}_{datetime.datetime.now():%Y%m%d_%H%M%S}"

        # =====================================================
        # ✅ TEXT / HTML / MARKDOWN
        # =====================================================
        if current_widget is self._text:
            if isinstance(self.last_content, dict):
                d = self.last_content

                fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                    self,
                    "Save Dictionary",
                    default,
                    "JSON (*.json);;YAML (*.yaml);;Text Dump (*.txt);;Flattened CSV (*.csv);;"
                    "Pickle (*.pickle *.pkl);;Dill (*.dill);;PyTree (*.pytree)"
                )

                if not fn:
                    return

                try:
                    # ✅ JSON (SAFE, PORTABLE)
                    if fn.endswith(".json"):
                        with open(fn, "w", encoding="utf-8") as f:
                            json.dump(d, f, indent=2, default=str)

                    # ✅ YAML (SAFE, HUMAN-FRIENDLY)
                    elif fn.endswith(".yaml"):
                        import yaml
                        with open(fn, "w", encoding="utf-8") as f:
                            yaml.dump(d, f, allow_unicode=True)

                    # ✅ TEXT DUMP (DEBUG)
                    elif fn.endswith(".txt"):
                        try:
                            from rich.pretty import pretty_repr
                            text = pretty_repr(d, max_width=120)
                        except Exception:
                            import pprint
                            text = pprint.pformat(d, width=120, compact=False)

                        with open(fn, "w", encoding="utf-8") as f:
                            f.write(text)

                    # ✅ FLATTENED CSV (FLAT DICTS ONLY)
                    elif fn.endswith(".csv"):
                        if not all(isinstance(k, (str, int, float)) and not isinstance(v, (dict, list, tuple))
                                for k, v in d.items()):
                            raise ValueError("CSV export only supports flat dictionaries.")

                        df = pd.DataFrame(list(d.items()), columns=["Key", "Value"])
                        df.to_csv(fn, index=False)

                    # ✅ PICKLE (UNSAFE, FULL RESTORE)
                    elif fn.endswith(".pickle") or fn.endswith(".pkl"):
                        with open(fn, "wb") as f:
                            pickle.dump(d, f)

                    # ✅ DILL (FUNCTIONS, CLOSURES)
                    elif fn.endswith(".dill"):
                        import dill
                        with open(fn, "wb") as f:
                            dill.dump(d, f)

                    # ✅ PYTREE (STRUCTURE SNAPSHOT)
                    elif fn.endswith(".pytree"):
                        root = build_object_tree(d)

                        def dump_tree(item, indent=0):
                            pad = "  " * indent
                            line = f"{pad}{item.key} | {type(item.value).__name__} | {repr(item.value)}\n"
                            for c in item.children:
                                line += dump_tree(c, indent + 1)
                            return line

                        with open(fn, "w", encoding="utf-8") as f:
                            f.write(dump_tree(root))

                    QtWidgets.QMessageBox.information(self, "Saved", f"Dictionary saved to {fn}")

                except Exception as e:
                    QtWidgets.QMessageBox.critical(self, "Error", str(e))

                return
            else:
                text = self._text.toPlainText()
                if not text.strip():
                    QtWidgets.QMessageBox.information(self, "Save", "No text to save.")
                    return

                fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                    self, "Save Text", default, "Text Files (*.txt)"
                )
                if fn:
                    try:
                        with open(fn, "w", encoding="utf-8") as f:
                            f.write(text)
                        QtWidgets.QMessageBox.information(self, "Saved", f"Text saved to {fn}")
                    except Exception as e:
                        QtWidgets.QMessageBox.critical(self, "Error", str(e))
                return

        # =====================================================
        # ✅ DATAFRAME / STYLED DATAFRAME
        # =====================================================
        if current_widget is self._table and self._model:
            df = getattr(self._model, "df", None)
            if df is None:
                QtWidgets.QMessageBox.information(self, "Save", "No data to save.")
                return

            fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Save Data", default,
                "CSV Files (*.csv);;Excel Files (*.xlsx)"
            )
            if fn:
                try:
                    if fn.endswith(".xlsx"):
                        df.to_excel(fn, index=False)
                    else:
                        df.to_csv(fn, index=False)
                    QtWidgets.QMessageBox.information(self, "Saved", f"Data saved to {fn}")
                except Exception as e:
                    QtWidgets.QMessageBox.critical(self, "Error", str(e))
            return

        # =====================================================
        # ✅ GENERIC WIDGET SNAPSHOT
        # =====================================================
        if current_widget is self._widget_holder:
            if self._widget_holder.layout().count() == 0:
                QtWidgets.QMessageBox.information(self, "Save", "No widget to save.")
                return

            w = self._widget_holder.layout().itemAt(0).widget()
            if not isinstance(w, QtWidgets.QWidget):
                QtWidgets.QMessageBox.warning(self, "Save", "Unsupported widget type.")
                return

            fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Save Widget Snapshot", default, "PNG Image (*.png)"
            )
            if fn:
                try:
                    pixmap = w.grab()
                    pixmap.save(fn, "PNG")
                    QtWidgets.QMessageBox.information(self, "Saved", f"Widget snapshot saved to {fn}")
                except Exception as e:
                    QtWidgets.QMessageBox.critical(self, "Error", str(e))
            return

        # =====================================================
        # ✅ NUMPY ARRAY (ArrayViewer) — ALL FORMATS
        # =====================================================
        if current_widget is self._array:
            arr = getattr(self._array, "arr", None)
            if arr is None:
                QtWidgets.QMessageBox.information(self, "Save", "No array to save.")
                return

            fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Save Array", default,
                "NumPy (*.npy);;NumPy ZIP (*.npz);;MATLAB (*.mat);;"
                "CSV (*.csv);;Text (*.txt);;JSON (*.json);;"
                "PNG Image (*.png);;JPG Image (*.jpg)"
            )
            if fn:
                try:
                    if fn.endswith(".npy"):
                        np.save(fn, arr)

                    elif fn.endswith(".npz"):
                        np.savez_compressed(fn, arr=arr)

                    elif fn.endswith(".mat"):
                        import scipy.io
                        scipy.io.savemat(fn, {"array": arr})

                    elif fn.endswith(".csv"):
                        if arr.ndim != 2:
                            raise ValueError("CSV only supports 2D arrays.")
                        np.savetxt(fn, arr, delimiter=",")

                    elif fn.endswith(".txt"):
                        np.savetxt(fn, arr)

                    elif fn.endswith(".json"):
                        with open(fn, "w", encoding="utf-8") as f:
                            json.dump(arr.tolist(), f, indent=2)

                    elif fn.endswith(".png") or fn.endswith(".jpg"):
                        import matplotlib.pyplot as plt
                        plt.imshow(arr if arr.ndim == 2 else arr[..., 0])
                        plt.colorbar()
                        plt.savefig(fn)
                        plt.close()

                    QtWidgets.QMessageBox.information(self, "Saved", f"Array saved to {fn}")

                except Exception as e:
                    QtWidgets.QMessageBox.critical(self, "Error", str(e))
            return

        # =====================================================
        # ✅ PYTHON OBJECT (ObjectTreeViewer) — ALL FORMATS
        # =====================================================
        if hasattr(self, "_object_viewer") and current_widget is self._object_viewer:
            obj = getattr(self._object_viewer, "_current_object", None)
            if obj is None:
                QtWidgets.QMessageBox.information(self, "Save", "No object to save.")
                return

            fn, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Save Object", default,
                "JSON (*.json);;YAML (*.yaml);;Text Dump (*.txt);;"
                "Pickle (*.pickle *.pkl);;Dill (*.dill);;"
                "PyTree (*.pytree);;Flattened CSV (*.csv)"
            )
            if fn:
                try:
                    # ✅ JSON (LOSSY)
                    if fn.endswith(".json"):
                        with open(fn, "w", encoding="utf-8") as f:
                            json.dump(obj, f, indent=2, default=str)

                    # ✅ YAML (LOSSY, NICE)
                    elif fn.endswith(".yaml"):
                        import yaml
                        with open(fn, "w", encoding="utf-8") as f:
                            yaml.dump(obj, f, allow_unicode=True)

                    # ✅ TEXT REPR (ALWAYS WORKS)
                    elif fn.endswith(".txt"):
                        with open(fn, "w", encoding="utf-8") as f:
                            f.write(repr(obj))

                    # ✅ PICKLE (FULL RESTORE — TRUSTED ONLY)
                    elif fn.endswith(".pickle") or fn.endswith(".pkl"):
                        with open(fn, "wb") as f:
                            pickle.dump(obj, f)

                    # ✅ DILL (FUNCTIONS, CLOSURES)
                    elif fn.endswith(".dill"):
                        import dill
                        with open(fn, "wb") as f:
                            dill.dump(obj, f)

                    # ✅ PYTREE (STRUCTURE SNAPSHOT)
                    elif fn.endswith(".pytree"):
                        root = build_object_tree(obj)   # ✅ DIRECT CALL — NO IMPORT

                        def dump_tree(item, indent=0):
                            pad = "  " * indent
                            s = f"{pad}{item.key} | {type(item.value).__name__} | {repr(item.value)}\n"
                            for c in item.children:
                                s += dump_tree(c, indent + 1)
                            return s

                        txt = dump_tree(root)
                        with open(fn, "w", encoding="utf-8") as f:
                            f.write(txt)


                    # ✅ FLATTENED CSV (TREE → TABLE)
                    elif fn.endswith(".csv"):
                        root = build_object_tree(obj)   # ✅ DIRECT CALL — NO IMPORT
                        rows = []

                        def walk(item, path=""):
                            key = str(item.key)
                            new_path = f"{path}.{key}" if path else key
                            rows.append([new_path, type(item.value).__name__, repr(item.value)])
                            for c in item.children:
                                walk(c, new_path)

                        walk(root)
                        df = pd.DataFrame(rows, columns=["Path", "Type", "Value"])
                        df.to_csv(fn, index=False)

                    QtWidgets.QMessageBox.information(self, "Saved", f"Object saved to {fn}")

                except Exception as e:
                    QtWidgets.QMessageBox.critical(self, "Error", str(e))
            return

        # =====================================================
        # ❌ FALLBACK
        # =====================================================
        QtWidgets.QMessageBox.warning(self, "Save", "Unsupported content type for saving.")

    def _undock(self):
        if not self.dockable or not self._docked:
            return

        parent = self.parentWidget()
        if parent:
            self._original_parent = parent
            layout = parent.layout()
            self._original_layout = layout
            self._original_pos = None  # (r, c, rs, cs)
            definition_getter = getattr(layout, "widgetDefinition", None)
            self._original_canvas_definition = (
                definition_getter(self) if callable(definition_getter) else None)

            # Detect grid position
            if isinstance(layout, QtWidgets.QGridLayout):
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget() is self:
                        r, c, rs, cs = layout.getItemPosition(i)
                        self._original_pos = (r, c, rs, cs)
                        break

        # Floating window
        wnd = self.window()
        self._float = QtWidgets.QDialog(wnd)
        self._float.setWindowTitle(f"{self.instance} (Undocked)")
        self._float.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        self._float.resize(600, 400)

        # Reparent into floating dialog
        self.setParent(None)
        fl = QtWidgets.QVBoxLayout(self._float)
        fl.setContentsMargins(0, 0, 0, 0)
        fl.addWidget(self)

        self._float.show()
        self._docked = False
        self._float.finished.connect(self._dock)

    def _dock(self):
        if self._docked:
            return

        parent = getattr(self, "_original_parent", None)
        layout = getattr(self, "_original_layout", None)

        if parent is not None:
            self.setParent(parent)

            pos = getattr(self, "_original_pos", None)

            # Grid layout → restore exact position
            if isinstance(layout, QtWidgets.QGridLayout) and pos is not None:
                r, c, rs, cs = pos
                layout.addWidget(self, r, c, rs, cs)

            elif (
                getattr(self, "_original_canvas_definition", None) is not None
                and hasattr(layout, "addWidgetDefinition")
            ):
                layout.addWidgetDefinition(
                    self, self._original_canvas_definition)

            else:
                # Non-grid layout → simple add
                layout.addWidget(self)

            layout.activate()
            parent.update()

        # Destroy floating dialog if still alive
        if hasattr(self, "_float") and self._float:
            self._float.deleteLater()
            self._float = None

        self._docked = True

    def _auto_scroll(self):
        self._force_auto_scroll = True

    def _apply_df_auto_wrap(self, df: pd.DataFrame):
        """
        Replace spaces with '\\n' for:
        ✅ string cell values
        ✅ column headers
        ✅ row index values
        ✅ row index NAME
        (Fully Pandas 2.x compatible)
        """
        if not self.df_auto_wrap:
            return df

        df = df.copy()

        def wrap_val(val):
            if isinstance(val, str):
                return val.replace(" ", "\n")
            return val

        # ✅ 1. Wrap ALL CELL VALUES
        df = df.apply(lambda col: col.map(wrap_val))

        # ✅ 2. Wrap COLUMN HEADERS
        df.columns = [wrap_val(col) for col in df.columns]

        # ✅ 3. Wrap ROW INDEX VALUES
        if isinstance(df.index, pd.MultiIndex):
            df.index = pd.MultiIndex.from_tuples(
                tuple(wrap_val(v) for v in tup)
                for tup in df.index
            )
        else:
            df.index = df.index.map(wrap_val)

        # ✅ 4. Wrap ROW INDEX NAME (THIS WAS MISSING ✅)
        if df.index.name:
            df.index.name = wrap_val(df.index.name)

        return df
    
    def _wrap_styler_rule_args(self, rule):
        """
        Rewrites Styler _todo rule arguments to match wrapped
        column/index labels.
        """
        if not self.df_auto_wrap:
            return rule

        def wrap_val(val):
            if isinstance(val, str):
                return val.replace(" ", "\n")
            return val

        func, args, kwargs = rule  # Pandas stores rules like this

        # ✅ Wrap positional args
        new_args = []
        for a in args:
            if isinstance(a, (list, tuple)):
                new_args.append(type(a)(wrap_val(v) for v in a))
            else:
                new_args.append(wrap_val(a))

        # ✅ Wrap keyword args (subset=[...], axis labels, etc.)
        new_kwargs = {}
        for k, v in kwargs.items():
            if isinstance(v, (list, tuple)):
                new_kwargs[k] = type(v)(wrap_val(x) for x in v)
            else:
                new_kwargs[k] = wrap_val(v)

        return (func, tuple(new_args), new_kwargs)

# =========================================================
# Output Registry
# =========================================================
class OutputRegistry:
    def __init__(self, window):
        self.window = window
        self._by_name = {}

    def register(self, area: OutputArea):
        self._by_name[area.instance] = area

    def clear(self):
        self._by_name.clear()

    def display(self, instance: str, content, mode='append'):
        """Safe, hierarchical lookup (supports 'tab/name' form)."""
        if '/' in instance:
            instance = instance.split('/')[-1]
        area = self._by_name.get(instance)
        if not area:
            QtCore.QMetaObject.invokeMethod(
                self.window,
                lambda: QtWidgets.QMessageBox.warning(
                    self.window, 'Output', f'Unknown output instance: {instance}'
                ),
                QtCore.Qt.QueuedConnection
            )
            return
        area.display(content, mode)
