"""Shared VS Code discovery, capability, workspace, and navigation support."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


PYTHON_EXTENSION = "ms-python.python"
PYLANCE_EXTENSION = "ms-python.vscode-pylance"
ENVIRONMENTS_EXTENSION = "ms-python.vscode-python-envs"
DEBUGGER_EXTENSION = "ms-python.debugpy"
SAKIR_SUPERVISOR_EXTENSION = "sakir.sakir-supervisor"
MINIMUM_VSCODE_VERSION = (1, 72, 0)
MINIMUM_VSCODE_VERSION_TEXT = ".".join(str(part) for part in MINIMUM_VSCODE_VERSION)
REQUIRED_VSCODE_CLI_OPTIONS = ("--reuse-window", "--goto", "--install-extension")
RECOMMENDED_EXTENSIONS = (
    PYTHON_EXTENSION,
    PYLANCE_EXTENSION,
    ENVIRONMENTS_EXTENSION,
    DEBUGGER_EXTENSION,
)

MANAGED_SUPERVISOR_TASK = "SAKiR: Supervisor Host"
MANAGED_DEBUG_CHECK_TASK = "SAKiR: Validate Debug Mode"
MANAGED_TEST_TASK = "SAKiR: Test Suite"
MANAGED_ATTACH_CONFIGURATION = "SAKiR: Attach to VS Code-owned App"


@dataclass(frozen=True)
class VSCodeCapability:
    executable: str = ""
    version: str = ""
    extensions: frozenset[str] = frozenset()
    missing_cli_options: tuple[str, ...] = ()
    error: str = ""

    @property
    def available(self) -> bool:
        return bool(self.executable and self.version)

    @property
    def version_tuple(self) -> tuple[int, int, int]:
        match = re.match(r"^\s*(\d+)(?:\.(\d+))?(?:\.(\d+))?", self.version)
        if not match:
            return (0, 0, 0)
        return tuple(int(part or 0) for part in match.groups())  # type: ignore[return-value]

    @property
    def compatible(self) -> bool:
        return self.available and self.version_tuple >= MINIMUM_VSCODE_VERSION

    @property
    def editor_ready(self) -> bool:
        return self.compatible and not self.missing_cli_options

    @property
    def terminal_ready(self) -> bool:
        return self.editor_ready and {
            PYTHON_EXTENSION,
            PYLANCE_EXTENSION,
        }.issubset(self.extensions)

    @property
    def debugger_ready(self) -> bool:
        return self.terminal_ready and DEBUGGER_EXTENSION in self.extensions

    @property
    def supervisor_extension_ready(self) -> bool:
        return self.editor_ready and SAKIR_SUPERVISOR_EXTENSION in self.extensions

    @property
    def level(self) -> str:
        if not self.available:
            return "unavailable"
        if not self.compatible or not self.editor_ready:
            return "incompatible"
        if not self.terminal_ready:
            return "editor"
        if not self.debugger_ready:
            return "terminal"
        return "debugger"

    @property
    def missing_terminal_extensions(self) -> tuple[str, ...]:
        return tuple(
            extension
            for extension in (PYTHON_EXTENSION, PYLANCE_EXTENSION)
            if extension not in self.extensions
        )


def _windows_creation_flags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def clean_external_environment() -> dict[str, str]:
    """Prevent a frozen supervisor's bootloader state leaking into VS Code tasks."""
    environment = os.environ.copy()
    for key in tuple(environment):
        if key.startswith("_PYI_") or key == "_MEIPASS2":
            environment.pop(key, None)
    environment["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    return environment


def _command_text(candidate: str | os.PathLike[str]) -> str:
    text = os.fspath(candidate).strip().strip('"')
    if not text:
        return ""
    resolved = shutil.which(text)
    if resolved:
        return str(Path(resolved).resolve())
    path = Path(text).expanduser()
    if path.is_file():
        return str(path.resolve())
    return text


def _resolve_official_windows_cli(executable: str) -> tuple[str, str]:
    """Resolve official VS Code desktop binaries without executing their GUI."""
    if os.name != "nt":
        return executable, ""
    path = Path(executable)
    cli_name = {
        "code.exe": "code.cmd",
        "code - insiders.exe": "code-insiders.cmd",
    }.get(path.name.lower())
    if cli_name is None:
        return executable, ""
    cli_path = path.parent / "bin" / cli_name
    if cli_path.is_file():
        return str(cli_path.resolve()), ""
    return str(cli_path), (
        f"Cannot resolve the VS Code CLI for {path}. Expected {cli_path}. "
        "Use 'vscode-path' and select code.cmd directly."
    )


def vscode_cli_diagnostic_command(
    capability: VSCodeCapability,
    option: str = "--version",
) -> str:
    """Return a copyable probe for Windows Command Prompt."""
    if not capability.executable:
        return ""
    return subprocess.list2cmdline([capability.executable, option])


def _with_cli_example(message: str, capability: VSCodeCapability, option: str) -> str:
    command = vscode_cli_diagnostic_command(capability, option)
    return f"{message}\nTry in Command Prompt: {command}" if command else message


def validate_vscode(candidate: str | os.PathLike[str]) -> VSCodeCapability:
    executable = _command_text(candidate)
    if not executable:
        return VSCodeCapability(error="No VS Code executable was supplied.")
    executable, resolution_error = _resolve_official_windows_cli(executable)
    if resolution_error:
        return VSCodeCapability(executable=executable, error=resolution_error)
    try:
        version_result = subprocess.run(
            [executable, "--version"],
            capture_output=True,
            text=True,
            timeout=8,
            creationflags=_windows_creation_flags(),
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return VSCodeCapability(executable=executable, error=f"{executable}: {exc}")
    version_lines = (version_result.stdout or "").strip().splitlines()
    version = version_lines[0].strip() if version_lines else ""
    if version_result.returncode or not version:
        detail = (version_result.stderr or version_result.stdout or "not a VS Code CLI").strip()
        return VSCodeCapability(executable=executable, error=f"{executable}: {detail}")

    try:
        help_result = subprocess.run(
            [executable, "--help"],
            capture_output=True,
            text=True,
            timeout=8,
            creationflags=_windows_creation_flags(),
        )
        help_text = f"{help_result.stdout or ''}\n{help_result.stderr or ''}"
        missing_cli_options = tuple(
            option for option in REQUIRED_VSCODE_CLI_OPTIONS if option not in help_text
        )
    except (OSError, subprocess.SubprocessError):
        missing_cli_options = REQUIRED_VSCODE_CLI_OPTIONS

    try:
        extension_result = subprocess.run(
            [executable, "--list-extensions"],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=_windows_creation_flags(),
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return VSCodeCapability(executable=executable, version=version, error=str(exc))
    extensions = frozenset(
        line.strip().lower()
        for line in (extension_result.stdout or "").splitlines()
        if line.strip()
    )
    return VSCodeCapability(
        executable=executable,
        version=version,
        extensions=extensions,
        missing_cli_options=missing_cli_options,
        error=(extension_result.stderr or "").strip() if extension_result.returncode else "",
    )


def vscode_candidates(configured: str = "") -> Iterable[str]:
    seen: set[str] = set()

    def emit(value: str | os.PathLike[str] | None):
        if not value:
            return
        text = _command_text(value)
        key = os.path.normcase(text)
        if text and key not in seen:
            seen.add(key)
            yield text

    yield from emit(configured)
    yield from emit("code")
    yield from emit("code-insiders")

    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA", "")
        program_files = os.environ.get("ProgramFiles", "")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", "")
        for path in (
            Path(local) / "Programs" / "Microsoft VS Code" / "bin" / "code.cmd" if local else None,
            Path(local) / "Programs" / "Microsoft VS Code Insiders" / "bin" / "code-insiders.cmd" if local else None,
            Path(program_files) / "Microsoft VS Code" / "bin" / "code.cmd" if program_files else None,
            Path(program_files_x86) / "Microsoft VS Code" / "bin" / "code.cmd" if program_files_x86 else None,
            Path(local) / "Programs" / "Microsoft VS Code" / "Code.exe" if local else None,
            Path(local) / "Programs" / "Microsoft VS Code Insiders" / "Code - Insiders.exe" if local else None,
            Path(program_files) / "Microsoft VS Code" / "Code.exe" if program_files else None,
            Path(program_files_x86) / "Microsoft VS Code" / "Code.exe" if program_files_x86 else None,
        ):
            if path and path.is_file():
                yield from emit(path)


def discover_vscode(configured: str = "") -> VSCodeCapability:
    errors: list[str] = []
    incompatible: VSCodeCapability | None = None
    failed: VSCodeCapability | None = None
    for candidate in vscode_candidates(configured):
        capability = validate_vscode(candidate)
        if capability.compatible:
            return capability
        if capability.available and incompatible is None:
            incompatible = capability
        if capability.error:
            errors.append(capability.error)
            if failed is None:
                failed = capability
    if incompatible is not None:
        return incompatible
    return failed or VSCodeCapability(error=errors[0] if errors else "VS Code was not found.")


def vscode_editor_issue(capability: VSCodeCapability) -> str:
    """Return a user-facing reason editor/navigation operations are unavailable."""
    if not capability.available:
        detail = f" ({capability.error})" if capability.error else ""
        return _with_cli_example(
            f"Install VS Code {MINIMUM_VSCODE_VERSION_TEXT} or newer, then configure "
            f"its CLI with 'vscode-path'.{detail}",
            capability,
            "--version",
        )
    if not capability.compatible:
        return _with_cli_example(
            f"VS Code {capability.version} is too old. Upgrade to VS Code "
            f"{MINIMUM_VSCODE_VERSION_TEXT} or newer to use this feature.",
            capability,
            "--version",
        )
    if capability.missing_cli_options:
        return _with_cli_example(
            "The configured VS Code CLI does not support the required operations: "
            + ", ".join(capability.missing_cli_options)
            + f". Reinstall or upgrade to official VS Code {MINIMUM_VSCODE_VERSION_TEXT} or newer.",
            capability,
            "--help",
        )
    executable_path = Path(capability.executable)
    if executable_path.is_absolute() and not executable_path.is_file():
        return (
            "The configured VS Code executable is no longer available. Reinstall VS Code "
            "or select its current executable with 'vscode-path'."
        )
    return ""


def capability_from_environment() -> VSCodeCapability:
    executable = os.environ.get("SAKIR_VSCODE_EXECUTABLE", "")
    if not executable:
        return VSCodeCapability()
    extensions = frozenset(
        item.strip().lower()
        for item in os.environ.get("SAKIR_VSCODE_EXTENSIONS", "").split(";")
        if item.strip()
    )
    missing_cli_options = tuple(
        item.strip()
        for item in os.environ.get("SAKIR_VSCODE_MISSING_CLI", "").split(";")
        if item.strip()
    )
    return VSCodeCapability(
        executable=executable,
        version=os.environ.get("SAKIR_VSCODE_VERSION", "detected"),
        extensions=extensions,
        missing_cli_options=missing_cli_options,
    )


def open_vscode(
    capability: VSCodeCapability,
    project_root: Path,
    *,
    file_path: Path | None = None,
    line: int | None = None,
    column: int = 1,
    new_window: bool = False,
    workspace_path: Path | None = None,
) -> subprocess.Popen:
    issue = vscode_editor_issue(capability)
    if issue:
        raise RuntimeError(issue)
    command = [capability.executable]
    if new_window:
        command.append("--new-window")
    else:
        command.append("--reuse-window")
    command.append(str((workspace_path or project_root).resolve()))
    if file_path is not None:
        target = str(file_path.resolve())
        if line is not None:
            target = f"{target}:{max(1, int(line))}:{max(1, int(column))}"
            command.extend(("--goto", target))
        else:
            command.append(target)
    return subprocess.Popen(
        command,
        cwd=str(project_root),
        env=clean_external_environment(),
        close_fds=True,
        creationflags=_windows_creation_flags(),
    )


def bundled_supervisor_vsix(project_root: Path) -> Path | None:
    candidates = list(
        (project_root / "app" / "vscode_extention").glob("sakir-supervisor-*.vsix")
    )
    candidates = sorted(
        candidates,
        key=lambda path: path.stat().st_mtime_ns,
        reverse=True,
    )
    return candidates[0].resolve() if candidates else None


def ensure_supervisor_extension(
    capability: VSCodeCapability,
    project_root: Path,
) -> VSCodeCapability:
    """Install the bundled first-party handoff extension when terminal mode is enabled."""
    if capability.supervisor_extension_ready:
        return capability
    vsix = bundled_supervisor_vsix(project_root)
    if vsix is None:
        raise RuntimeError("The bundled SAKiR Supervisor VSIX is missing.")
    result = subprocess.run(
        [capability.executable, "--install-extension", str(vsix), "--force"],
        capture_output=True,
        text=True,
        timeout=60,
        cwd=str(project_root),
        env=clean_external_environment(),
        creationflags=_windows_creation_flags(),
    )
    if result.returncode:
        detail = (result.stderr or result.stdout or "VS Code rejected the extension").strip()
        raise RuntimeError(f"Could not install the SAKiR Supervisor extension: {detail}")
    refreshed = validate_vscode(capability.executable)
    if not refreshed.supervisor_extension_ready:
        raise RuntimeError(
            "VS Code installed the companion extension but has not activated it yet. "
            "Reload the VS Code window and retry."
        )
    return refreshed


def _read_json_object(path: Path) -> tuple[dict[str, Any] | None, str]:
    if not path.exists():
        return {}, ""
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        return None, str(exc)
    if not isinstance(payload, dict):
        return None, "the JSON root must be an object"
    return payload, ""


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=4) + "\n", encoding="utf-8")
    temp.replace(path)


def _replace_named(items: Any, managed: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    existing = [item for item in items if isinstance(item, dict)] if isinstance(items, list) else []
    names = set(managed)
    preserved = [item for item in existing if item.get("label", item.get("name")) not in names]
    return preserved + list(managed.values())


def _recommended_payload(path: Path, project_root: Path, debug_port: int) -> dict[str, Any]:
    root_text = "${workspaceFolder}"
    python_text = f"{root_text}\\designer\\.designer_env\\Scripts\\python.exe"
    designer_text = f"{root_text}\\designer.exe"
    pyi_cleanup = (
        "Get-ChildItem Env: | Where-Object { $_.Name -like '_PYI_*' -or "
        "$_.Name -eq '_MEIPASS2' } | ForEach-Object { Remove-Item -LiteralPath "
        "('Env:' + $_.Name) -ErrorAction SilentlyContinue }; "
        "$env:PYINSTALLER_RESET_ENVIRONMENT='1'; "
    )
    if path.name == "settings.json":
        return {
            "python.defaultInterpreterPath": python_text,
            "python.terminal.activateEnvironment": False,
            "debugpy.debugJustMyCode": False,
            "terminal.integrated.stickyScroll.enabled": False,
        }
    if path.name == "extensions.json":
        return {"recommendations": list(RECOMMENDED_EXTENSIONS)}
    if path.name == "tasks.json":
        return {
            "version": "2.0.0",
            "tasks": [
                {
                    "label": MANAGED_SUPERVISOR_TASK,
                    "type": "process",
                    "command": "powershell.exe",
                    "args": [
                        "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass",
                        "-Command",
                        pyi_cleanup + f"& '{designer_text}' '--vscode-terminal-host'; exit $LASTEXITCODE",
                    ],
                    "isBackground": True,
                    "problemMatcher": [],
                    "presentation": {"panel": "dedicated", "reveal": "always", "focus": True},
                    "runOptions": {"instanceLimit": 1},
                },
                {
                    "label": MANAGED_DEBUG_CHECK_TASK,
                    "type": "process",
                    "command": "powershell.exe",
                    "args": [
                        "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass",
                        "-Command",
                        pyi_cleanup + f"& '{designer_text}' '--vscode-debug-check'; exit $LASTEXITCODE",
                    ],
                    "problemMatcher": [],
                    "presentation": {"panel": "shared", "reveal": "silent"},
                },
                {
                    "label": MANAGED_TEST_TASK,
                    "type": "process",
                    "command": python_text,
                    "args": ["-m", "unittest", "discover", "-s", "tests", "-v"],
                    "problemMatcher": [],
                    "group": "test",
                    "presentation": {"panel": "dedicated", "reveal": "always"},
                },
            ],
        }
    return {
        "version": "0.2.0",
        "configurations": [
            {
                "name": MANAGED_ATTACH_CONFIGURATION,
                "type": "debugpy",
                "request": "attach",
                "connect": {"host": "127.0.0.1", "port": debug_port},
                "subProcess": True,
                "justMyCode": False,
                "autoReload": {"enable": False},
                "preLaunchTask": MANAGED_DEBUG_CHECK_TASK,
            }
        ],
    }


def _merge_payload(path: Path, existing: dict[str, Any], recommended: dict[str, Any]) -> dict[str, Any]:
    merged = dict(existing)
    if path.name == "settings.json":
        merged.update(recommended)
    elif path.name == "extensions.json":
        current = existing.get("recommendations", [])
        combined = [str(item) for item in current] if isinstance(current, list) else []
        for extension in recommended["recommendations"]:
            if extension not in combined:
                combined.append(extension)
        merged["recommendations"] = combined
    elif path.name == "tasks.json":
        managed = {item["label"]: item for item in recommended["tasks"]}
        merged["version"] = existing.get("version", recommended["version"])
        merged["tasks"] = _replace_named(existing.get("tasks"), managed)
    else:
        managed = {item["name"]: item for item in recommended["configurations"]}
        merged["version"] = existing.get("version", recommended["version"])
        merged["configurations"] = _replace_named(existing.get("configurations"), managed)
    return merged


def ensure_workspace_configuration(project_root: Path, debug_port: int = 5678) -> list[str]:
    """Merge only framework-owned workspace entries, returning warnings."""
    vscode_dir = project_root / ".vscode"
    warnings: list[str] = []
    for name in ("settings.json", "extensions.json", "tasks.json", "launch.json"):
        path = vscode_dir / name
        recommended = _recommended_payload(path, project_root, debug_port)
        existing, error = _read_json_object(path)
        if existing is None:
            sidecar = vscode_dir / f"{path.stem}.sakir-recommended.json"
            _write_json(sidecar, recommended)
            warnings.append(f"{path} is malformed ({error}); wrote {sidecar} instead.")
            continue
        _write_json(path, _merge_payload(path, existing, recommended))
    return warnings


def extension_install_commands(capability: VSCodeCapability) -> list[str]:
    if not capability.available:
        return []
    return [
        f'"{capability.executable}" --install-extension {extension}'
        for extension in capability.missing_terminal_extensions
    ]
