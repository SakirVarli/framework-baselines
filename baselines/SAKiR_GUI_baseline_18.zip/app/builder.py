import os, subprocess, shutil, re
from PyQt5 import QtWidgets, QtCore, QtGui
from app.utils import PROJECT_ROOT, BUILD_SETTINGS, CONFIG_PATH, save_json, load_json, set_widow_feature
from datetime import datetime

DEFAULT_OUTPUT_DIR = os.path.join(PROJECT_ROOT, "designer", "build", "dist")

class BuildAppDialog(QtWidgets.QDialog):
    """GUI for configuring and running PyInstaller builds (non-blocking, recursion-aware)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Builder")
        self.setMinimumWidth(700)
        self.setMinimumHeight(600)
        self.setWindowModality(QtCore.Qt.ApplicationModal)

        # === Basic options ===
        self.icon = self.parent().icon
        self.name = self.parent().title
        self.name = self.name if self.name else "App"
        self.output_edit = QtWidgets.QLineEdit(DEFAULT_OUTPUT_DIR)
        self.output_browse_btn = QtWidgets.QToolButton()
        self.output_browse_btn.setText("🔍")
        self.output_browse_btn.setToolTip("Select output directory")

        output_row = QtWidgets.QHBoxLayout()
        output_row.addWidget(self.output_edit)
        output_row.addWidget(self.output_browse_btn)
        self.rec_limit_edit = QtWidgets.QLineEdit("1000")
        self.rec_limit_edit.setValidator(QtGui.QIntValidator(1000, 20000))
        self.rec_limit_edit.setToolTip("Increase this if you get a RecursionError during build.")
        self.onefile_check = QtWidgets.QCheckBox("Bundle into single file (--onefile)")
        self.onefile_check.setChecked(False)
        self.windowed_check = QtWidgets.QCheckBox("Windowed (--windowed)")
        self.windowed_check.setChecked(True)
        self.clean_check = QtWidgets.QCheckBox("Clean Build (--clean)")
        self.clean_check.setChecked(True)
        self.make_specs = QtWidgets.QCheckBox("Make Specs (Uncheck to build without making a new specs)")
        self.make_specs.setChecked(True)
        self.build_app = QtWidgets.QCheckBox("Complete Build (Uncheck to make a specs file only)")
        self.build_app.setChecked(True)

        # === Extra folders ===
        self.extra_dirs_list = QtWidgets.QListWidget()
        self.add_extra_btn = QtWidgets.QPushButton("Add Folder…")
        self.remove_extra_btn = QtWidgets.QPushButton("Remove Selected")

        # === Excluded packages ===
        self.exclude_list = QtWidgets.QListWidget()
        self.exclude_list.addItems(["PyQt6", "PySide6", "PySide2"])
        self.add_exclude_btn = QtWidgets.QPushButton("Add Package…")
        self.remove_exclude_btn = QtWidgets.QPushButton("Remove Selected")

        # === Hidden imports ===
        self.hidden_list = QtWidgets.QListWidget()
        self.add_hidden_btn = QtWidgets.QPushButton("Add Hidden Import…")
        self.remove_hidden_btn = QtWidgets.QPushButton("Remove Selected")

        # === Output area ===
        self.output_area = QtWidgets.QPlainTextEdit()
        self.output_area.setReadOnly(True)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.hide()
        self.progress.setTextVisible(False)

        # === Buttons ===
        self.run_btn = QtWidgets.QPushButton("🚀 Build")
        self.cancel_btn = QtWidgets.QPushButton("Cancel")

        # === Layout ===
        form = QtWidgets.QFormLayout()
        form.addRow("Output Directory:", output_row)
        form.addRow("Recursion Limit:", self.rec_limit_edit)
        h1 = QtWidgets.QVBoxLayout()
        h1.addWidget(self.build_app)
        h1.addWidget(self.onefile_check)
        h1.addWidget(self.clean_check)
        h2 = QtWidgets.QVBoxLayout()
        h2.addWidget(self.make_specs)
        h2.addWidget(self.windowed_check)
        h2.addWidget(QtWidgets.QLabel(" ")) #allign
        h = QtWidgets.QHBoxLayout()
        h.addLayout(h1)
        h.addLayout(h2)
        form.addRow("Build options:", h)


        extra_box = QtWidgets.QHBoxLayout()
        extra_box.addWidget(self.add_extra_btn)
        extra_box.addWidget(self.remove_extra_btn)
        form.addRow("Extra Folders:", self.extra_dirs_list)
        form.addRow("", extra_box)

        excl_box = QtWidgets.QHBoxLayout()
        excl_box.addWidget(self.add_exclude_btn)
        excl_box.addWidget(self.remove_exclude_btn)
        form.addRow("Excluded Packages:", self.exclude_list)
        form.addRow("", excl_box)

        hidden_box = QtWidgets.QHBoxLayout()
        hidden_box.addWidget(self.add_hidden_btn)
        hidden_box.addWidget(self.remove_hidden_btn)
        form.addRow("Hidden Imports:", self.hidden_list)
        form.addRow("", hidden_box)

        out_box = QtWidgets.QVBoxLayout()
        out_box.setSpacing(2)
        out_box.addWidget(self.output_area)
        out_box.addWidget(self.progress)
        form.addRow("Build Output:", out_box)

        btn_box = QtWidgets.QHBoxLayout()
        btn_box.addWidget(self.run_btn)
        btn_box.addWidget(self.cancel_btn)
        form.addRow("", btn_box)

        self.setLayout(form)

        # === Connections ===
        self.add_extra_btn.clicked.connect(self._add_folder)
        self.remove_extra_btn.clicked.connect(self._remove_folder)
        self.add_exclude_btn.clicked.connect(self._add_exclude)
        self.remove_exclude_btn.clicked.connect(self._remove_exclude)
        self.run_btn.clicked.connect(self._run_build)
        self.cancel_btn.clicked.connect(self.reject)
        self.add_hidden_btn.clicked.connect(self._add_hidden)
        self.remove_hidden_btn.clicked.connect(self._remove_hidden)
        self.output_browse_btn.clicked.connect(self._browse_output_dir)
        self.build_thread = None

        cfg = load_json(BUILD_SETTINGS)
        self.apply_config_dict(cfg)

    def _browse_output_dir(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Select Output Directory",
            self._resolve_output_dir(self.output_edit.text()),
        )
        if path:
            self.output_edit.setText(path)

    def _resolve_output_dir(self, output_dir: str) -> str:
        """Resolve UI output paths relative to the project root, not the build cwd."""
        output_dir = os.path.expanduser((output_dir or "").strip())
        if not output_dir:
            output_dir = DEFAULT_OUTPUT_DIR
        if not os.path.isabs(output_dir):
            output_dir = os.path.join(PROJECT_ROOT, output_dir)
        return os.path.abspath(os.path.normpath(output_dir))

    # ---------------- Folder & package UI ----------------
    def _add_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Folder to Include")
        if folder:
            self.extra_dirs_list.addItem(folder)

    def _remove_folder(self):
        for item in self.extra_dirs_list.selectedItems():
            self.extra_dirs_list.takeItem(self.extra_dirs_list.row(item))

    def _add_exclude(self):
        pkg, ok = QtWidgets.QInputDialog.getText(self, "Add Excluded Package", "Package name:")
        if ok and pkg.strip():
            self.exclude_list.addItem(pkg.strip())

    def _remove_exclude(self):
        for item in self.exclude_list.selectedItems():
            self.exclude_list.takeItem(self.exclude_list.row(item))

    def _add_hidden(self):
        mod, ok = QtWidgets.QInputDialog.getText(self, "Add Hidden Import", "Module name (e.g. OpenGL.GL):")
        if ok and mod.strip():
            self.hidden_list.addItem(mod.strip())

    def _remove_hidden(self):
        for item in self.hidden_list.selectedItems():
            self.hidden_list.takeItem(self.hidden_list.row(item))

    # ---------------- Build Execution ----------------
    def _run_build(self):
        """Launch build thread."""
        self.output_area.clear()
        self.progress.show()
        self.run_btn.setEnabled(False)

        output_dir = self._resolve_output_dir(self.output_edit.text())
        self.output_edit.setText(output_dir)
        self.output_area.appendPlainText(f"Output directory: {output_dir}\n")
        extras = [self.extra_dirs_list.item(i).text() for i in range(self.extra_dirs_list.count())]
        excludes = [self.exclude_list.item(i).text() for i in range(self.exclude_list.count())]
        excludes.append("app.assistant")
        hidden_imports = [self.hidden_list.item(i).text() for i in range(self.hidden_list.count())]
        rec_limit = self.rec_limit_edit.text().strip() or "1000"

        cmd = ["pyi-makespec", fr"{PROJECT_ROOT}\app\main.py", "--name", self.name]
        if self.onefile_check.isChecked():
            cmd.append("--onefile")
        if self.windowed_check.isChecked():
            cmd.append("--windowed")
        if self.icon and os.path.exists(self.icon):
            cmd += [f"--icon={self.icon}"]
        cmd += ["--add-data", fr"{PROJECT_ROOT}\app;app", "--add-data", fr"{PROJECT_ROOT}\callbacks;callbacks", "--add-data", fr"{PROJECT_ROOT}\externals;externals"]
        for folder in extras:
            folder = os.path.abspath(folder)
            proj = os.path.abspath(PROJECT_ROOT)

            # If folder is inside project root → use relative path
            if os.path.commonpath([proj, folder]) == proj:
                rel_dest = os.path.relpath(folder, proj).replace(os.sep, '/')
            else:
                # Outside project root → use only folder name
                rel_dest = os.path.basename(folder)

            cmd += ["--add-data", f"{folder}{os.pathsep}{rel_dest}"]
        for pkg in excludes:
            cmd += ["--exclude-module", pkg]
        for mod in hidden_imports:
            cmd += ["--hidden-import", mod]

        self.build_thread = BuildThread(
            self.name, cmd, output_dir, self.make_specs.isChecked(),
            self.build_app.isChecked(), self.clean_check.isChecked(), rec_limit, hidden_imports
        )
        self.build_thread.log_signal.connect(self._append_output)
        self.build_thread.finished_signal.connect(self._build_done)
        self.build_thread.auto_exclude_signal.connect(self._auto_add_excludes)
        self.build_thread.recursion_signal.connect(self._handle_recursion_error)
        self.build_thread.start()

    def _append_output(self, text):
        self.output_area.appendPlainText(text)
        sb = self.output_area.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _build_done(self, success, out_dir):
        self.progress.hide()
        self.run_btn.setEnabled(True)
        if success:
            self.parent().build += 1
            set_widow_feature("build", self.parent().build)
            
        msg = (
            f"Build finished successfully.\nOutput folder: {out_dir}"
            if success
            else "Build failed. See output for details."
        )
        self.output_area.appendPlainText("\n" + msg)
        if success and self.build_app.isChecked():
            if os.path.isdir(out_dir):
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(out_dir))
            else:
                self.output_area.appendPlainText(
                    f"\nOutput folder was not found, so it could not be opened: {out_dir}"
                )
        QtWidgets.QMessageBox.information(self, "Build", msg)

    def _auto_add_excludes(self, pkgs, msg_type):
        if msg_type == 'fail':
            for pkg in pkgs:
                if not any(self.exclude_list.item(i).text() == pkg for i in range(self.exclude_list.count())):
                    self.exclude_list.addItem(pkg)
            QtWidgets.QMessageBox.warning(
                self,
                "Conflicting Bindings Detected",
                f"❌ Build failed due to conflicting bindings.\n"
                f"Automatically excluded: {', '.join(pkgs)}\n"
                f"Please review and rebuild."
            )
        elif msg_type == 'warn':
            QtWidgets.QMessageBox.information(
                self,
                "Duplicate Bindings Detected",
                f"⚠️ Build succeeded but duplicate Qt bindings found:\n\n"
                f"{', '.join(pkgs)}"
            )

    def _handle_recursion_error(self, suggested_limit):
        self.progress.hide()
        self.run_btn.setEnabled(True)
        QtWidgets.QMessageBox.warning(
            self,
            "Recursion Limit Exceeded",
            f"⚠️ PyInstaller hit a recursion depth error.\n\n"
            f"Increase recursion limit (current: {self.rec_limit_edit.text()}) "
            f"to at least {int(suggested_limit) * 2} and rebuild."
        )
        self.rec_limit_edit.setText(str(int(suggested_limit) * 2))

    def to_config_dict(self) -> dict:
        """Collect current UI state into a JSON-serializable dict."""
        return {
            "app": {
                "output_dir": self.output_edit.text().strip(),
                "recursion_limit": int(self.rec_limit_edit.text() or 1000),
            },
            "options": {
                "onefile": self.onefile_check.isChecked(),
                "windowed": self.windowed_check.isChecked(),
                "clean": self.clean_check.isChecked(),
                "make_specs": self.make_specs.isChecked(),
                "build_app": self.build_app.isChecked(),
            },
            "paths": {
                "extra_dirs": [
                    self.extra_dirs_list.item(i).text()
                    for i in range(self.extra_dirs_list.count())
                ]
            },
            "pyinstaller": {
                "excluded_packages": [
                    self.exclude_list.item(i).text()
                    for i in range(self.exclude_list.count())
                ],
                "hidden_imports": [
                    self.hidden_list.item(i).text()
                    for i in range(self.hidden_list.count())
                ]
            }
        }

    def apply_config_dict(self, cfg: dict):
        """Apply a configuration dict to the UI."""
        app = cfg.get("app", {})
        opts = cfg.get("options", {})
        paths = cfg.get("paths", {})
        pyi = cfg.get("pyinstaller", {})

        # --- Basic fields ---
        self.output_edit.setText(self._resolve_output_dir(app.get("output_dir", "")))
        self.rec_limit_edit.setText(str(app.get("recursion_limit", 1000)))

        # --- Checkboxes ---
        self.onefile_check.setChecked(opts.get("onefile", False))
        self.windowed_check.setChecked(opts.get("windowed", True))
        self.clean_check.setChecked(opts.get("clean", True))
        self.make_specs.setChecked(opts.get("make_specs", True))
        self.build_app.setChecked(opts.get("build_app", True))

        # --- Lists ---
        self.extra_dirs_list.clear()
        self.extra_dirs_list.addItems(paths.get("extra_dirs", []))

        self.exclude_list.clear()
        self.exclude_list.addItems(pyi.get("excluded_packages", []))

        self.hidden_list.clear()
        self.hidden_list.addItems(pyi.get("hidden_imports", []))

    def closeEvent(self, event):
        if self.build_thread and self.build_thread.isRunning():
            self.build_thread.terminate()
            self.build_thread.wait(2000)
        
        cfg = self.to_config_dict()
        save_json(BUILD_SETTINGS, cfg)
        event.accept()


# ---------------------- THREAD ----------------------
class BuildThread(QtCore.QThread):
    log_signal = QtCore.pyqtSignal(str)
    finished_signal = QtCore.pyqtSignal(bool, str)
    auto_exclude_signal = QtCore.pyqtSignal(list, str)
    recursion_signal = QtCore.pyqtSignal(str)

    def __init__(self, name, cmd, output_dir, make_specs, build_app, clean, rec_limit="1000", hidden_imports=[]):
        super().__init__()
        self.name = name
        self.cmd = cmd
        self.output_dir = output_dir
        self.make_specs = make_specs
        self.build_app = build_app
        self.clean = clean
        self.rec_limit = rec_limit
        self.hidden_imports = hidden_imports

    def _patch_spec_file(self, spec_path):
        try:
            with open(spec_path, "r", encoding="utf-8") as f:
                text = f.read()

            changed = False

            # --------------------------------------------------
            # 1) Inject recursion limit (top of file)
            # --------------------------------------------------
            if "setrecursionlimit" not in text:
                text = text.replace(
                    "\n",
                    f"\nimport sys; sys.setrecursionlimit({self.rec_limit})\n",
                    1
                )
                changed = True

            # --------------------------------------------------
            # 2) Inject externals auto-collector (after Analysis)
            # --------------------------------------------------
            inject_tag = "AUTO-INJECTED: externals submodules"
            if inject_tag not in text:
                import_block = (
                    "\n# --- AUTO-INJECTED: externals submodules ---\n"
                    "from PyInstaller.utils.hooks import collect_all\n"
                    f"a.hiddenimports += collect_all(r'{PROJECT_ROOT}/externals')\n"
                    "# --- END AUTO-INJECT ---\n"
                )

                # Inject right after Analysis(...) definition
                import re
                pattern = re.compile(r"(a\s*=\s*Analysis\s*\([\s\S]*?\)\n)", re.MULTILINE)
                match = pattern.search(text)

                if match:
                    insert_at = match.end()
                    text = text[:insert_at] + import_block + text[insert_at:]
                    changed = True
                else:
                    self.log_signal.emit(
                        "[Warning] Could not locate Analysis(...) block for externals injection."
                    )

            # --------------------------------------------------
            # Write back if changed
            # --------------------------------------------------
            privacy_tag = "# AUTO-INJECTED: exclude assistant private configuration"
            if privacy_tag not in text:
                import re
                match = re.search(r"(?m)^pyz\s*=", text)
                if match:
                    block = (privacy_tag + "\n"
                             "a.datas = [entry for entry in a.datas if not "
                             "(entry[0].replace('\\\\', '/').lower().endswith('/assistant.json') "
                             "or '/assistant/' in ('/' + entry[0].replace('\\\\', '/').lower()))]\n\n")
                    text = text[:match.start()] + block + text[match.start():]
                    changed = True
            if changed:
                with open(spec_path, "w", encoding="utf-8") as f:
                    f.write(text)

                self.log_signal.emit(
                    f"✅ Patched {spec_path} "
                    f"(recursion={self.rec_limit}, externals auto-collected)"
                )
            else:
                self.log_signal.emit(
                    f"ℹ️ Spec {spec_path} already patched."
                )

        except Exception as e:
            self.log_signal.emit(f"[Warning] Could not patch spec file: {e}")


    def run(self):
        try:
            designer_build_dir = os.path.join(PROJECT_ROOT, "designer", "build")
            os.makedirs(designer_build_dir, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            log_file_path = os.path.join(designer_build_dir, f"build_log_{timestamp}.txt")

            # Generate .spec in background
            base_cmd = self.cmd.copy()
            spec_name = f"{self.name}.spec"
            spec_path = os.path.join(designer_build_dir, spec_name)

            if self.make_specs:
                self.log_signal.emit("📄 Generating spec file...")

                makespec_cmd = self.cmd + [
                    "--specpath", designer_build_dir
                ]

                success = self._run_process_with_logging(makespec_cmd, designer_build_dir, log_file_path)
                if not success:
                    self.finished_signal.emit(False, self.output_dir)
                    return
            else:
                self.log_signal.emit(f"[Warning] Spec file {spec_name} not generated.")


            if os.path.exists(spec_path):
                self._patch_spec_file(spec_path)
            else:
                self.log_signal.emit(f"[Warning] Spec file not found: {spec_path}")
                return
            
            if self.build_app:
                build_cmd = [
                    "pyinstaller",
                    spec_path,
                    "-y",
                    "--clean" if self.clean else "",
                    "--distpath", self.output_dir,
                    "--workpath", designer_build_dir,
                    "--log-level=DEBUG"
                ]

                build_cmd = [c for c in build_cmd if c]  # remove empty entries

                self.log_signal.emit("🚀 Starting PyInstaller build...\n")
                success = self._run_process_with_logging(build_cmd, designer_build_dir, log_file_path)

                if success:
                    self._cleanup(designer_build_dir)

                self.finished_signal.emit(success, self.output_dir)
            else:
                self.log_signal.emit(f"[Warning] App not built since Complete Build not checked.")
                self.finished_signal.emit(True, self.output_dir)

        except Exception as e:
            self.log_signal.emit(f"[Error] {e}")
            self.finished_signal.emit(False, self.output_dir)

    def _run_process_with_logging(self, cmd, cwd, log_file_path):
        self.log_signal.emit(f"\n[Running] {' '.join(cmd)}\n")

        hooked_pairs = []
        recursion_hit = False

        with open(log_file_path, "a", encoding="utf-8") as logfile:
            process = subprocess.Popen(
                cmd,
                cwd=cwd,
                env={k: v for k, v in os.environ.items() if k != "PYTHONPATH"},
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )

            for line in process.stdout:
                line = line.rstrip()
                self.log_signal.emit(line)
                logfile.write(line + "\n")

                # ---- Recursion detection ----
                if "RecursionError" in line or "recursion depth exceeded" in line:
                    recursion_hit = True

                # ---- Duplicate Qt bindings hook conflict detection ----
                m = re.search(
                    r"attempt to collect multiple .* packages: attempting to run hook for '([\w\d_]+)'.*while hook for '([\w\d_]+)'",
                    line, re.IGNORECASE)
                if m:
                    hooked_pairs.append((m.group(2), m.group(1)))

            process.wait()
            success = process.returncode == 0

        # Emit recursion signal if hit
        if recursion_hit:
            self.recursion_signal.emit(self.rec_limit)

        # Emit duplicate binding detection
        if hooked_pairs:
            unique_pairs = list(set(hooked_pairs))
            to_exclude = [attempting for _, attempting in unique_pairs]
            msg_type = 'fail' if not success else 'warn'
            self.auto_exclude_signal.emit(to_exclude, msg_type)

        return success


    def _cleanup(self, designer_build_dir):
        for folder in ["build", "__pycache__"]:
            path = os.path.join(designer_build_dir, folder)
            if os.path.exists(path):
                shutil.rmtree(path, ignore_errors=True)

