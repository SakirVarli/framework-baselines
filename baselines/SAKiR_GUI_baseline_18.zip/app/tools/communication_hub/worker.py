from __future__ import annotations

import asyncio
import os
import queue
import time
import traceback
from multiprocessing.connection import Connection
from pathlib import Path

from .config import normalize_session_config
from .framing import FrameDecoder, FramingError
from .parser_runtime import Direction
from .transports import TCPServerTransport, create_transport


def copy_periodic_status(entry: dict) -> dict:
    return {
        "id": str(entry.get("id", "")),
        "enabled": bool(entry.get("enabled", True)),
        "sent_count": int(entry.get("sent_count", 0)),
        "last_sent_at": str(entry.get("last_sent_at", "")),
        "last_error": str(entry.get("last_error", "")),
        "inflight": False,
    }


class SessionWorker:
    def __init__(
        self, connection: Connection, capture_queue, config: dict, project_root: str,
    ):
        self.connection = connection
        self.capture_queue = capture_queue
        self.config = normalize_session_config(config)
        self.project_root = Path(project_root)
        self.transport = create_transport(
            self.config["protocol"], self.config["transport"], self._on_chunk, self._on_status
        )
        self.decoders: dict[str, FrameDecoder] = {}
        self.state = "starting"
        self.status_message = ""
        self.running = True
        self.last_error = ""
        self.transport_error_count = 0
        self.transport_last_error = ""
        self.transport_last_error_at = ""
        self.capture_sequence = 0
        self.capture_enqueued = 0
        self.capture_dropped = 0
        self.capture_queue_max_depth = 0
        self.capture_last_overload_error = ""
        self.capture_handoff_errors = 0
        self.periodic_messages: dict[str, dict] = {}
        self._periodic_tasks: dict[str, asyncio.Task] = {}
        self._periodic_config_revision = 0
        self._periodic_max_inflight = 16
        try:
            write_timeout = float(self.config.get("transport", {}).get("write_timeout", 1.0))
        except (TypeError, ValueError):
            write_timeout = 1.0
        # Serial drivers already enforce write_timeout themselves. Keep a
        # slightly wider worker-level guard for all transports so normal socket
        # backpressure is tolerated but a stalled drain cannot remain inflight.
        self._periodic_send_timeout = max(5.0, write_timeout)

    def _on_status(self, state: str, message: str):
        self.state, self.status_message = state, message
        if state == "error":
            self.transport_error_count += 1
            self.transport_last_error = str(message)
            self.transport_last_error_at = time.strftime("%Y-%m-%d %H:%M:%S")

    async def _enqueue_capture(self, envelope: dict) -> bool:
        """Transfer a complete RX/TX frame without invoking parser or Pandas."""
        self.capture_sequence += 1
        envelope["capture_sequence"] = self.capture_sequence
        policy = self.config["processing"].get("overload_policy", "block")
        try:
            if policy == "block":
                while self.running:
                    try:
                        await asyncio.to_thread(
                            self.capture_queue.put, envelope, True, 0.1,
                        )
                        break
                    except queue.Full:
                        self.capture_last_overload_error = (
                            "Processing queue full; I/O is waiting for capacity"
                        )
                else:
                    self.capture_dropped += 1
                    self.capture_last_overload_error = (
                        "Session stopped before a blocked capture frame could be queued"
                    )
                    return False
            else:
                self.capture_queue.put_nowait(envelope)
        except queue.Full:
            if policy == "drop_oldest":
                try:
                    self.capture_queue.get_nowait()
                    self.capture_dropped += 1
                    self.capture_queue.put_nowait(envelope)
                except (queue.Empty, queue.Full):
                    self.capture_dropped += 1
                    self.capture_last_overload_error = "Processing queue remained full while dropping oldest frame"
                    return False
            else:
                self.capture_dropped += 1
                self.capture_last_overload_error = "Processing queue full; newest frame dropped"
                return False
        self.capture_enqueued += 1
        try:
            self.capture_queue_max_depth = max(
                self.capture_queue_max_depth, int(self.capture_queue.qsize()),
            )
        except (AttributeError, NotImplementedError, OSError):
            pass
        return True

    async def _safe_enqueue_capture(self, envelope: dict) -> bool:
        """Never let processing IPC failure tear down a live transport."""
        try:
            return await self._enqueue_capture(envelope)
        except asyncio.CancelledError:
            raise
        except BaseException as error:
            self.capture_dropped += 1
            self.capture_handoff_errors += 1
            self.capture_last_overload_error = (
                f"Capture handoff failed: {type(error).__name__}: {error}"
            )[:1000]
            return False

    def _decoder(self, connection_id: str) -> FrameDecoder:
        key = connection_id or "default"
        if key not in self.decoders:
            self.decoders[key] = FrameDecoder(self.config["framing"])
        return self.decoders[key]

    async def _on_chunk(self, chunk: bytes, timestamp_ns: int, connection_id: str, peer: str):
        decoder = self._decoder(connection_id)
        try:
            frames = decoder.feed(chunk, timestamp_ns)
        except FramingError as error:
            header, partial = decoder.reset()
            await self._safe_enqueue_capture({
                "kind": "framing_error", "direction": Direction.RX.value,
                "timestamp_ns": timestamp_ns, "completed_timestamp_ns": timestamp_ns,
                "message": bytes(header) + bytes(partial or chunk), "header": bytes(header),
                "header_fields": {}, "connection_id": connection_id, "peer": peer,
                "error": str(error),
            })
            return
        for frame in frames:
            await self._safe_enqueue_capture({
                "kind": "frame", "direction": Direction.RX.value,
                "timestamp_ns": int(frame.first_byte_timestamp_ns or timestamp_ns),
                "completed_timestamp_ns": int(frame.completed_timestamp_ns or timestamp_ns),
                "message": frame.message, "header": frame.header,
                "header_fields": frame.header_fields,
                "connection_id": connection_id, "peer": peer,
            })

    async def run(self):
        try:
            await self.transport.start()
        except BaseException as error:
            self._on_status("error", f"{type(error).__name__}: {error}")
        while self.running:
            await self._process_commands()
            self._schedule_periodic_messages()
            self._check_partial_timeouts()
            await asyncio.sleep(0.01)
        pending_periodic = [
            task for task in self._periodic_tasks.values() if not task.done()
        ]
        if pending_periodic:
            await asyncio.gather(*pending_periodic, return_exceptions=True)
        await self.transport.stop()

    async def _process_commands(self):
        while self.connection.poll():
            request = self.connection.recv()
            request_id = request.get("id")
            try:
                result = await self._command(request.get("command"), request.get("payload") or {})
                self.connection.send({"id": request_id, "ok": True, "result": result})
            except BaseException as error:
                self.last_error = traceback.format_exc()
                self.connection.send({
                    "id": request_id,
                    "ok": False,
                    "error": f"{type(error).__name__}: {error}",
                })

    async def _command(self, command: str, payload: dict):
        if command == "ping":
            return self._status()
        if command == "status":
            return self._status()
        if command == "send":
            raw = payload.get("data", b"")
            if isinstance(raw, str):
                raw = bytes.fromhex(raw) if payload.get("encoding") == "hex" else raw.encode(payload.get("encoding", "utf-8"))
            # TX is intentionally transparent. Receive framing never changes bytes sent by users.
            wire = bytes(raw)
            results = await self.transport.send(wire, str(payload.get("target", "")))
            for connection_id, peer, timestamp_ns in results:
                await self._safe_enqueue_capture({
                    "kind": "frame", "direction": Direction.TX.value,
                    "timestamp_ns": timestamp_ns, "completed_timestamp_ns": timestamp_ns,
                    "message": wire, "header": b"", "header_fields": {},
                    "connection_id": connection_id, "peer": peer,
                })
            return {"sent_to": len(results), "bytes": len(wire)}
        if command == "clients":
            return self.transport.client_info() if isinstance(self.transport, TCPServerTransport) else []
        if command == "periodic_configure":
            revision = int(payload.get("revision", 0) or 0)
            if revision < self._periodic_config_revision:
                return self._periodic_status()
            self._periodic_config_revision = revision
            self._periodic_max_inflight = min(
                64, max(1, int(payload.get("maximum_inflight", 16) or 16)),
            )
            return self._configure_periodic_messages(payload.get("entries", []))
        if command == "periodic_status":
            return self._periodic_status()
        if command == "periodic_send_now":
            entry_id = str(payload.get("id", ""))
            entry = self.periodic_messages.get(entry_id)
            if entry is None:
                raise KeyError(f"Unknown periodic message: {entry_id}")
            current = self._periodic_tasks.get(entry_id)
            if current is not None and not current.done():
                await current
            await self._send_periodic_message(entry)
            return copy_periodic_status(entry)
        if command == "stop":
            barrier_queued = await self._safe_enqueue_capture({
                "kind": "barrier", "direction": Direction.RX.value,
                "timestamp_ns": time.time_ns(), "completed_timestamp_ns": time.time_ns(),
            })
            self.running = False
            return {"capture_sequence": self.capture_sequence if barrier_queued else 0}
        raise ValueError(f"Unknown worker command: {command}")

    def _configure_periodic_messages(self, entries) -> list[dict]:
        """Replace this session's worker-owned monotonic schedules."""
        now = time.monotonic()
        configured: dict[str, dict] = {}
        for value in entries if isinstance(entries, list) else []:
            if not isinstance(value, dict):
                continue
            entry_id = str(value.get("id", ""))
            if not entry_id:
                continue
            wire = value.get("data", b"")
            if isinstance(wire, str):
                wire = bytes.fromhex(wire)
            interval = max(0.05, float(value.get("interval_seconds", 1.0) or 1.0))
            previous = self.periodic_messages.get(entry_id, {})
            incoming_count = int(value.get("sent_count", 0) or 0)
            previous_count = int(previous.get("sent_count", 0) or 0)
            use_incoming_status = incoming_count > previous_count
            unchanged = (
                bytes(previous.get("data", b"")) == bytes(wire)
                and str(previous.get("target", "")) == str(value.get("target", ""))
                and float(previous.get("interval_seconds", interval)) == interval
                and bool(previous.get("enabled", True)) == bool(value.get("enabled", True))
            )
            configured[entry_id] = {
                "id": entry_id,
                "name": str(value.get("name", entry_id)),
                "data": bytes(wire),
                "target": str(value.get("target", "")),
                "interval_seconds": interval,
                "enabled": bool(value.get("enabled", True)),
                "next_due": (
                    float(previous.get("next_due", now + interval))
                    if unchanged else now + interval
                ),
                "sent_count": max(previous_count, incoming_count),
                "last_sent_at": str(
                    value.get("last_sent_at", "")
                    if use_incoming_status
                    else previous.get("last_sent_at", value.get("last_sent_at", ""))
                ),
                "last_error": str(previous.get("last_error", "")),
            }
        self.periodic_messages = configured
        return self._periodic_status()

    def _schedule_periodic_messages(self):
        """Launch due sends without catch-up bursts or GUI involvement."""
        now = time.monotonic()
        for entry_id, task in list(self._periodic_tasks.items()):
            if task.done():
                self._periodic_tasks.pop(entry_id, None)
        active = sum(not task.done() for task in self._periodic_tasks.values())
        for entry_id, entry in list(self.periodic_messages.items()):
            if active >= self._periodic_max_inflight:
                break
            task = self._periodic_tasks.get(entry_id)
            if (
                not entry.get("enabled", True)
                or task is not None
                or now < float(entry.get("next_due", now))
            ):
                continue
            interval = float(entry["interval_seconds"])
            next_due = float(entry.get("next_due", now))
            while next_due <= now:
                next_due += interval
            entry["next_due"] = next_due
            self._periodic_tasks[entry_id] = asyncio.create_task(
                self._send_periodic_message(entry),
                name=f"periodic-message-{entry_id}",
            )
            active += 1

    async def _send_periodic_message(self, entry: dict):
        try:
            wire = bytes(entry.get("data", b""))
            results = await asyncio.wait_for(
                self.transport.send(wire, str(entry.get("target", ""))),
                timeout=float(getattr(self, "_periodic_send_timeout", 1.0)),
            )
            for connection_id, peer, timestamp_ns in results:
                await self._safe_enqueue_capture({
                    "kind": "frame", "direction": Direction.TX.value,
                    "timestamp_ns": timestamp_ns, "completed_timestamp_ns": timestamp_ns,
                    "message": wire, "header": b"", "header_fields": {},
                    "connection_id": connection_id, "peer": peer,
                })
            entry["sent_count"] = int(entry.get("sent_count", 0)) + 1
            entry["last_sent_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            entry["last_error"] = ""
        except BaseException as error:
            entry["last_error"] = f"{type(error).__name__}: {error}"[:500]

    def _periodic_status(self) -> list[dict]:
        result = []
        for entry_id, entry in self.periodic_messages.items():
            status = copy_periodic_status(entry)
            task = self._periodic_tasks.get(entry_id)
            status["inflight"] = bool(task is not None and not task.done())
            result.append(status)
        return result

    def _status(self):
        try:
            queue_depth = max(0, int(self.capture_queue.qsize()))
        except (AttributeError, NotImplementedError, OSError):
            queue_depth = -1
        return {
            "state": self.state,
            "status_message": self.status_message,
            "pid": os.getpid(),
            "session_id": self.config["id"],
            "last_error": self.last_error[-2000:],
            "transport_error_count": self.transport_error_count,
            "transport_last_error": self.transport_last_error,
            "transport_last_error_at": self.transport_last_error_at,
            "periodic_messages": self._periodic_status(),
            "capture_sequence": self.capture_sequence,
            "capture_enqueued": self.capture_enqueued,
            "capture_dropped": self.capture_dropped,
            "capture_handoff_errors": self.capture_handoff_errors,
            "capture_queue_depth": queue_depth,
            "capture_queue_capacity": self.config["processing"]["queue_capacity"],
            "capture_queue_max_depth": self.capture_queue_max_depth,
            "capture_overload_policy": self.config["processing"]["overload_policy"],
            "capture_last_overload_error": self.capture_last_overload_error,
        }

    def _check_partial_timeouts(self):
        for connection_id, decoder in list(self.decoders.items()):
            partial = decoder.check_timeout()
            if partial and any(partial):
                header, payload = partial
                now_ns = time.time_ns()
                asyncio.create_task(self._safe_enqueue_capture({
                    "kind": "framing_error", "direction": Direction.RX.value,
                    "timestamp_ns": now_ns, "completed_timestamp_ns": now_ns,
                    "message": bytes(header) + bytes(payload), "header": bytes(header),
                    "header_fields": {},
                    "connection_id": connection_id if connection_id != "default" else "",
                    "peer": "", "error": "Partial frame timeout",
                }))


def session_process_entry(
    connection: Connection, capture_queue, config: dict, project_root: str,
    diagnostic_queue=None,
):
    try:
        asyncio.run(SessionWorker(connection, capture_queue, config, project_root).run())
    except BaseException as error:
        if diagnostic_queue is not None:
            try:
                diagnostic_queue.put_nowait({
                    "backend": "I/O",
                    "error": f"{type(error).__name__}: {error}",
                    "traceback": traceback.format_exc(),
                    "timestamp_ns": time.time_ns(),
                })
            except BaseException:
                pass
        raise
    finally:
        connection.close()
