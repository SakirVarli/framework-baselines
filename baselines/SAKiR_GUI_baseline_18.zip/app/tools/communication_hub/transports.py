from __future__ import annotations

import asyncio
import time
from typing import Awaitable, Callable


ChunkCallback = Callable[[bytes, int, str, str], Awaitable[None]]
StatusCallback = Callable[[str, str], None]


class BaseTransport:
    def __init__(self, config: dict, on_chunk: ChunkCallback, on_status: StatusCallback):
        self.config = config
        self.on_chunk = on_chunk
        self.on_status = on_status
        self.running = False
        self.state = "stopped"

    def _status(self, state: str, message: str = ""):
        self.state = state
        self.on_status(state, message)

    async def start(self):
        raise NotImplementedError

    async def stop(self):
        raise NotImplementedError

    async def send(self, data: bytes, target: str = "") -> list[tuple[str, str, int]]:
        raise NotImplementedError


class TCPClientTransport(BaseTransport):
    def __init__(self, config, on_chunk, on_status):
        super().__init__(config, on_chunk, on_status)
        self.reader: asyncio.StreamReader | None = None
        self.writer: asyncio.StreamWriter | None = None
        self._task: asyncio.Task | None = None

    async def start(self):
        if self.running:
            return
        self.running = True
        self._task = asyncio.create_task(self._run(), name="tcp-client-reader")

    async def _run(self):
        delay = float(self.config.get("reconnect_initial_seconds", 1.0))
        while self.running:
            try:
                self._status("connecting", "")
                self.reader, self.writer = await asyncio.wait_for(
                    asyncio.open_connection(self.config["host"], int(self.config["port"])),
                    timeout=float(self.config.get("connect_timeout", 5.0)),
                )
                peer = self.writer.get_extra_info("peername")
                peer_text = f"{peer[0]}:{peer[1]}" if peer else ""
                self._status("connected", peer_text)
                delay = float(self.config.get("reconnect_initial_seconds", 1.0))
                while self.running:
                    chunk = await self.reader.read(int(self.config.get("read_chunk_size", 65536)))
                    timestamp_ns = time.time_ns()
                    if not chunk:
                        raise ConnectionError("Remote closed the connection")
                    await self.on_chunk(chunk, timestamp_ns, "", peer_text)
            except asyncio.CancelledError:
                break
            except BaseException as error:
                self._status("error", f"{type(error).__name__}: {error}")
            finally:
                if self.writer:
                    self.writer.close()
                    try:
                        await self.writer.wait_closed()
                    except BaseException:
                        pass
                self.reader, self.writer = None, None
            if not self.running or not self.config.get("reconnect", False):
                break
            self._status("reconnecting", f"Retrying in {delay:g}s")
            await asyncio.sleep(delay)
            delay = min(delay * 2, float(self.config.get("reconnect_max_seconds", 30.0)))
        if self.running:
            self.running = False
        self._status("stopped", "")

    async def stop(self):
        self.running = False
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
        self._task = None

    async def send(self, data: bytes, target: str = "") -> list[tuple[str, str, int]]:
        if not self.writer or self.writer.is_closing():
            raise ConnectionError("TCP client is not connected")
        self.writer.write(data)
        await self.writer.drain()
        timestamp_ns = time.time_ns()
        peer = self.writer.get_extra_info("peername")
        peer_text = f"{peer[0]}:{peer[1]}" if peer else ""
        return [("", peer_text, timestamp_ns)]


class TCPServerTransport(BaseTransport):
    def __init__(self, config, on_chunk, on_status):
        super().__init__(config, on_chunk, on_status)
        self.server: asyncio.Server | None = None
        self.clients: dict[str, tuple[asyncio.StreamReader, asyncio.StreamWriter, str]] = {}
        self._client_counter = 0
        self._tasks: set[asyncio.Task] = set()

    @staticmethod
    async def _close_writer(writer: asyncio.StreamWriter):
        writer.close()
        try:
            await asyncio.wait_for(writer.wait_closed(), timeout=1.0)
        except (ConnectionError, OSError, TimeoutError, asyncio.CancelledError):
            # A peer may reset the connection while server shutdown is closing it.
            pass

    def _client_task_done(self, task: asyncio.Task):
        self._tasks.discard(task)
        if task.cancelled():
            return
        try:
            error = task.exception()
        except (asyncio.CancelledError, asyncio.InvalidStateError):
            return
        if error is not None and self.running:
            self._status("error", f"TCP server client handler failed: {type(error).__name__}: {error}")

    async def start(self):
        if self.running:
            return
        self.running = True
        self._status("starting", "")
        self.server = await asyncio.start_server(
            self._accept,
            self.config.get("bind_host", "0.0.0.0"),
            int(self.config.get("bind_port", 9000)),
            backlog=int(self.config.get("backlog", 100)),
        )
        sockets = self.server.sockets or []
        address = sockets[0].getsockname() if sockets else ""
        self._status("listening", str(address))

    async def _accept(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        if not self.running or len(self.clients) >= int(self.config.get("max_clients", 32)):
            await self._close_writer(writer)
            return
        self._client_counter += 1
        connection_id = f"client-{self._client_counter}"
        peer = writer.get_extra_info("peername")
        peer_text = f"{peer[0]}:{peer[1]}" if peer else ""
        self.clients[connection_id] = (reader, writer, peer_text)
        task = asyncio.create_task(self._read_client(connection_id), name=f"tcp-server-{connection_id}")
        self._tasks.add(task)
        task.add_done_callback(self._client_task_done)

    async def _read_client(self, connection_id: str):
        reader, writer, peer = self.clients[connection_id]
        try:
            while self.running:
                chunk = await reader.read(int(self.config.get("read_chunk_size", 65536)))
                timestamp_ns = time.time_ns()
                if not chunk:
                    break
                await self.on_chunk(chunk, timestamp_ns, connection_id, peer)
        except (ConnectionError, OSError):
            # Disconnects and resets are normal socket lifecycle events. In
            # particular, closing the server intentionally wakes pending reads.
            pass
        finally:
            self.clients.pop(connection_id, None)
            await self._close_writer(writer)

    async def stop(self):
        self.running = False
        server, self.server = self.server, None
        if server:
            # Stop accepting immediately, but do not await wait_closed yet. On
            # current Windows asyncio runtimes it may also wait for active
            # connections, which must be closed below first.
            server.close()
        for _connection_id, (_reader, writer, _peer) in list(self.clients.items()):
            writer.close()

        # Closing the writers normally wakes every reader. Bound the wait so a
        # platform-specific stream shutdown cannot keep the worker process alive.
        tasks = set(self._tasks)
        if tasks:
            _done, pending = await asyncio.wait(tasks, timeout=2.0)
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
        if server:
            try:
                await asyncio.wait_for(server.wait_closed(), timeout=2.0)
            except (ConnectionError, OSError, TimeoutError):
                pass
        self.clients.clear()
        self._tasks.clear()
        self._status("stopped", "")

    async def send(self, data: bytes, target: str = "") -> list[tuple[str, str, int]]:
        if target and target != "all":
            selected = [(target, self.clients[target])] if target in self.clients else []
        else:
            selected = list(self.clients.items())
        if not selected:
            raise ConnectionError("No matching TCP server client is connected")
        results = []
        for connection_id, (_reader, writer, peer) in selected:
            writer.write(data)
            await writer.drain()
            results.append((connection_id, peer, time.time_ns()))
        return results

    def client_info(self):
        return [{"connection_id": key, "peer": value[2]} for key, value in self.clients.items()]


class SerialTransport(BaseTransport):
    def __init__(self, config, on_chunk, on_status):
        super().__init__(config, on_chunk, on_status)
        self.serial = None
        self._task: asyncio.Task | None = None
        self._lock = asyncio.Lock()

    async def start(self):
        import serial

        if self.running:
            return
        self._status("connecting", "")

        def open_serial():
            port = self.config.get("serial_port", "")
            factory = serial.serial_for_url if "://" in port else serial.Serial
            return factory(
                port,
                baudrate=int(self.config.get("baudrate", 115200)),
                bytesize=int(self.config.get("bytesize", 8)),
                parity=self.config.get("parity", "N"),
                stopbits=float(self.config.get("stopbits", 1)),
                timeout=float(self.config.get("read_timeout", 0.05)),
                write_timeout=float(self.config.get("write_timeout", 1.0)),
                rtscts=bool(self.config.get("rtscts", False)),
                xonxoff=bool(self.config.get("xonxoff", False)),
                dsrdtr=bool(self.config.get("dsrdtr", False)),
            )

        self.serial = await asyncio.to_thread(open_serial)
        self.running = True
        self._status("connected", str(self.config.get("serial_port", "")))
        self._task = asyncio.create_task(self._read_loop(), name="serial-reader")

    async def _read_loop(self):
        try:
            while self.running:
                async with self._lock:
                    chunk = await asyncio.to_thread(self.serial.read, int(self.config.get("read_chunk_size", 65536)))
                timestamp_ns = time.time_ns()
                if chunk:
                    await self.on_chunk(chunk, timestamp_ns, "", str(self.config.get("serial_port", "")))
                else:
                    await asyncio.sleep(0.005)
        except asyncio.CancelledError:
            pass
        except BaseException as error:
            self._status("error", f"{type(error).__name__}: {error}")

    async def stop(self):
        self.running = False
        if self.serial:
            await asyncio.to_thread(self.serial.close)
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
        self._status("stopped", "")

    async def send(self, data: bytes, target: str = "") -> list[tuple[str, str, int]]:
        if not self.serial or not self.serial.is_open:
            raise ConnectionError("Serial port is not open")
        async with self._lock:
            await asyncio.to_thread(self.serial.write, data)
            await asyncio.to_thread(self.serial.flush)
        return [("", str(self.config.get("serial_port", "")), time.time_ns())]


class TelnetTransport(BaseTransport):
    def __init__(self, config, on_chunk, on_status):
        super().__init__(config, on_chunk, on_status)
        self.telnet = None
        self._task: asyncio.Task | None = None
        self._lock = asyncio.Lock()

    async def start(self):
        import telnetlib

        if self.running:
            return
        self._status("connecting", "")
        self.telnet = await asyncio.to_thread(
            telnetlib.Telnet,
            self.config["host"],
            int(self.config["port"]),
            float(self.config.get("connect_timeout", 5.0)),
        )
        self.running = True
        peer = f"{self.config['host']}:{self.config['port']}"
        self._status("connected", peer)
        self._task = asyncio.create_task(self._read_loop(), name="telnet-reader")

    async def _read_loop(self):
        peer = f"{self.config['host']}:{self.config['port']}"
        try:
            while self.running:
                async with self._lock:
                    chunk = await asyncio.to_thread(self.telnet.read_very_eager)
                timestamp_ns = time.time_ns()
                if chunk:
                    await self.on_chunk(chunk, timestamp_ns, "", peer)
                else:
                    await asyncio.sleep(0.03)
        except EOFError:
            self._status("error", "Remote closed the Telnet connection")
        except asyncio.CancelledError:
            pass
        except BaseException as error:
            self._status("error", f"{type(error).__name__}: {error}")

    async def stop(self):
        self.running = False
        if self.telnet:
            await asyncio.to_thread(self.telnet.close)
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
        self._status("stopped", "")

    async def send(self, data: bytes, target: str = "") -> list[tuple[str, str, int]]:
        if self.telnet is None:
            raise ConnectionError("Telnet session is not connected")
        async with self._lock:
            await asyncio.to_thread(self.telnet.write, data)
        return [("", f"{self.config['host']}:{self.config['port']}", time.time_ns())]


def create_transport(protocol: str, config: dict, on_chunk: ChunkCallback, on_status: StatusCallback) -> BaseTransport:
    classes = {
        "tcp_client": TCPClientTransport,
        "tcp_server": TCPServerTransport,
        "serial": SerialTransport,
        "telnet": TelnetTransport,
    }
    return classes[protocol](config, on_chunk, on_status)
