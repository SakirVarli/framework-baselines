from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any

import pandas as pd

from .parser_runtime import Direction, ParseResult
from .local_time import local_iso, local_timestamp_from_ns, local_timezone_name, timestamp_ns
from .query import QueryEngine, discover_paths, get_path, serialize_value


COLUMNS = [
    "id", "ingestion_sequence", "capture_sequence", "record_revision", "timestamp_ns", "completed_timestamp_ns", "processing_completed_ns", "processing_latency_ns", "timestamp", "timezone_name", "direction", "protocol", "protocol_label", "name", "data",
    "parsed", "size", "frame_size", "header", "header_fields", "session_id",
    "connection_id", "peer", "parse_status", "parse_error", "parse_duration_ns",
    "update_count", "first_timestamp_ns", "first_timestamp",
]
MESSAGE_TIME_SCHEMA_VERSION = 2


@dataclass(frozen=True)
class EventInput:
    timestamp_ns: int
    direction: Direction
    protocol: str
    protocol_label: str
    message: bytes
    header: bytes
    header_fields: dict[str, Any]
    session_id: str
    connection_id: str = ""
    peer: str = ""
    capture_sequence: int = 0
    completed_timestamp_ns: int | None = None


class EventStore:
    """Process-confined Pandas event table with rule-based upsert behavior."""

    def __init__(self, storage_config: dict):
        self.config = storage_config
        self.frame = pd.DataFrame(columns=COLUMNS)
        self.next_id = 1
        self.version = 0
        self.query_engine = QueryEngine()
        self._conflict_index: dict[tuple, int] = {}
        self._pending: list[dict[str, Any]] = []
        self._pending_conflicts: dict[tuple, int] = {}
        self._last_flush = time.monotonic()

    def add(self, event: EventInput, parsed: ParseResult) -> dict[str, Any] | None:
        event_time_ns = int(event.timestamp_ns)
        completed_timestamp_ns = int(event.completed_timestamp_ns or event_time_ns)
        processing_completed_ns = time.time_ns()
        timestamp = local_timestamp_from_ns(event_time_ns)
        record = {
            "id": self.next_id,
            "ingestion_sequence": self.version + 1,
            "capture_sequence": int(event.capture_sequence or self.version + 1),
            "record_revision": 1,
            "timestamp_ns": event_time_ns,
            "completed_timestamp_ns": completed_timestamp_ns,
            "processing_completed_ns": processing_completed_ns,
            "processing_latency_ns": max(0, processing_completed_ns - completed_timestamp_ns),
            "timestamp": timestamp,
            "timezone_name": local_timezone_name(event_time_ns),
            "direction": event.direction.value,
            "protocol": event.protocol,
            "protocol_label": event.protocol_label,
            "name": parsed.name,
            "data": parsed.data,
            "parsed": parsed.parsed,
            "size": len(event.message),
            "frame_size": len(event.message),
            "header": event.header,
            "header_fields": dict(event.header_fields),
            "session_id": event.session_id,
            "connection_id": event.connection_id,
            "peer": event.peer,
            "parse_status": parsed.status,
            "parse_error": parsed.error,
            "parse_duration_ns": parsed.duration_ns,
            "update_count": 1,
            "first_timestamp_ns": event_time_ns,
            "first_timestamp": timestamp,
        }
        action, key_fields = self._conflict_action(record)
        if action == "ignore":
            return None
        key = self._conflict_key(record, key_fields)
        if action == "update" and key in self._conflict_index:
            self.flush()
            row_index = self._conflict_index[key]
            old = self.frame.loc[row_index]
            record["id"] = int(old["id"])
            record["first_timestamp"] = old["first_timestamp"]
            record["first_timestamp_ns"] = int(old["first_timestamp_ns"])
            record["update_count"] = int(old["update_count"]) + 1
            record["record_revision"] = int(old.get("record_revision") or old["update_count"] or 1) + 1
            self.frame.loc[row_index, COLUMNS] = [record[column] for column in COLUMNS]
        elif action == "update" and key in self._pending_conflicts:
            pending_index = self._pending_conflicts[key]
            old = self._pending[pending_index]
            record["id"] = old["id"]
            record["first_timestamp"] = old["first_timestamp"]
            record["first_timestamp_ns"] = int(old["first_timestamp_ns"])
            record["update_count"] = int(old["update_count"]) + 1
            record["record_revision"] = int(old.get("record_revision") or old["update_count"] or 1) + 1
            self._pending[pending_index] = record
        else:
            pending_index = len(self._pending)
            self._pending.append(record)
            self.next_id += 1
            if action == "update":
                self._pending_conflicts[key] = pending_index
        self.version += 1
        if len(self._pending) >= int(self.config.get("ingest_batch_rows", 250)):
            self.flush()
        return record

    def flush_if_due(self):
        interval = float(self.config.get("ingest_flush_ms", 50)) / 1000.0
        if self._pending and time.monotonic() - self._last_flush >= interval:
            self.flush()

    def flush(self):
        if not self._pending:
            return
        start = len(self.frame)
        pending = self._pending
        pending_conflicts = self._pending_conflicts
        self.frame = pd.concat([self.frame, pd.DataFrame(pending, columns=COLUMNS)], ignore_index=True)
        for key, position in pending_conflicts.items():
            self._conflict_index[key] = start + position
        self._pending = []
        self._pending_conflicts = {}
        self._last_flush = time.monotonic()
        self._apply_retention()

    def _matches_rule(self, record: dict, rule: dict) -> bool:
        if rule.get("direction") and record["direction"] != rule["direction"]:
            return False
        if "parsed" in rule and bool(record["parsed"]) != bool(rule["parsed"]):
            return False
        matcher = rule.get("name_match") or {}
        if matcher:
            kind, value = matcher.get("type", "exact"), str(matcher.get("value", ""))
            name = record["name"]
            if kind == "exact" and name != value:
                return False
            if kind == "contains" and value not in name:
                return False
            if kind == "prefix" and not name.startswith(value):
                return False
            if kind == "regex" and not re.search(value, name):
                return False
        return True

    def _conflict_action(self, record: dict) -> tuple[str, list[str]]:
        for rule in self.config.get("conflict_rules", []):
            if self._matches_rule(record, rule):
                return rule.get("action", "append"), list(rule.get("key", ["direction", "name"]))
        action = self.config.get("default_conflict_action", "append")
        if record["name"] == "Unknown" and not record["parsed"] and action == "update":
            action = "append"
        return action, ["direction", "name"]

    def _conflict_key(self, record: dict, fields: list[str]) -> tuple:
        values = []
        for field in fields:
            values.append(get_path(record["data"], field) if field.startswith("data.") else record.get(field))
        return tuple(values)

    def _apply_retention(self):
        maximum = int(self.config.get("maximum_rows", 0) or 0)
        if maximum and len(self.frame) > maximum:
            if self.config.get("retention", "drop_oldest") == "drop_newest":
                self.frame = self.frame.iloc[:maximum].reset_index(drop=True)
            else:
                self.frame = self.frame.iloc[-maximum:].reset_index(drop=True)
            self._rebuild_conflict_index()

    def _rebuild_conflict_index(self):
        self.flush()
        self._conflict_index.clear()
        for index, row in self.frame.iterrows():
            record = row.to_dict()
            action, fields = self._conflict_action(record)
            if action == "update":
                self._conflict_index[self._conflict_key(record, fields)] = index

    def query(self, query: dict | None = None, *, page: int = 0, page_size: int = 200,
              sort_by: str = "timestamp", descending: bool = True) -> dict[str, Any]:
        self.flush()
        mask = self.query_engine.mask(self.frame, query)
        result = self.frame.loc[mask]
        effective_sort = f"{sort_by}_ns" if sort_by in {"timestamp", "first_timestamp"} else sort_by
        if effective_sort in result.columns:
            result = result.sort_values(effective_sort, ascending=not descending, kind="stable")
        total = len(result)
        start = max(0, int(page)) * max(1, int(page_size))
        selected = result.iloc[start : start + max(1, int(page_size))]
        rows = [{key: serialize_value(value) for key, value in row.items()} for row in selected.to_dict("records")]
        return {"total": total, "page": page, "page_size": page_size, "version": self.version, "rows": rows}

    def delete(self, query: dict | None, expected_version: int | None = None) -> dict[str, int]:
        self.flush()
        if expected_version is not None and int(expected_version) != self.version:
            raise RuntimeError("Table changed after deletion preview; refresh the preview")
        mask = self.query_engine.mask(self.frame, query)
        deleted = int(mask.sum())
        self.frame = self.frame.loc[~mask].reset_index(drop=True)
        if deleted:
            self.version += 1
            self._rebuild_conflict_index()
        return {"deleted": deleted, "remaining": len(self.frame), "version": self.version}

    def distinct_names(self) -> list[str]:
        self.flush()
        return sorted(str(value) for value in self.frame["name"].dropna().unique())

    def name_summary_frame(self) -> pd.DataFrame:
        """Return a persistable per-name occurrence count and latest timestamp table."""
        self.flush()
        if self.frame.empty:
            return pd.DataFrame(columns=["name", "message_count", "last_timestamp"])
        working = self.frame.loc[:, ["name", "timestamp_ns", "timestamp", "update_count"]].copy()
        working["name"] = working["name"].fillna("Unknown").astype(str)
        working["update_count"] = pd.to_numeric(working["update_count"], errors="coerce").fillna(1)
        grouped = working.groupby("name", sort=False, dropna=False).agg(
            message_count=("update_count", "sum"),
            last_timestamp_ns=("timestamp_ns", "max"),
        ).reset_index()
        grouped["last_timestamp"] = grouped["last_timestamp_ns"].map(local_timestamp_from_ns)
        return grouped.sort_values("last_timestamp_ns", ascending=False, kind="stable").reset_index(drop=True)

    def name_summary(self) -> dict[str, Any]:
        """Summarize the complete table by message name, independent of UI filters."""
        grouped = self.name_summary_frame()
        rows = [
            {
                "name": str(row["name"]),
                "message_count": int(row["message_count"]),
                "last_timestamp": local_iso(row["last_timestamp_ns"]),
                "last_timestamp_ns": int(row["last_timestamp_ns"]),
            }
            for row in grouped.to_dict("records")
        ]
        return {"rows": rows, "total_names": len(rows), "version": self.version}

    def discover_fields(self, name: str | None = None) -> dict[str, list[str]]:
        self.flush()
        frame = self.frame
        if name:
            frame = frame[frame["name"] == name]
        return discover_paths(frame.loc[frame["parsed"] == True, "data"].tolist())  # noqa: E712

    def metrics(self) -> dict[str, Any]:
        self.flush_if_due()
        return {
            "rows": len(self.frame) + len(self._pending),
            "rx": int((self.frame["direction"] == "RX").sum()),
            "tx": int((self.frame["direction"] == "TX").sum()),
            "parsed": int((self.frame["parsed"] == True).sum()),  # noqa: E712
            "parser_errors": int((self.frame["parse_status"] == "error").sum()),
            "version": self.version,
            "memory_bytes": int(self.frame.memory_usage(index=True, deep=True).sum()),
        }

    def snapshot(self) -> pd.DataFrame:
        self.flush()
        frame = self.frame.copy(deep=True)
        frame.attrs["communication_hub_time_schema"] = MESSAGE_TIME_SCHEMA_VERSION
        frame.attrs["time_representation"] = "offset-aware local"
        return frame

    def export_state(self) -> dict[str, Any]:
        """Return a picklable table state suitable for moving across a process boundary."""
        self.flush()
        return {
            "frame": self.snapshot(),
            "next_id": self.next_id,
            "version": self.version,
            "time_schema_version": MESSAGE_TIME_SCHEMA_VERSION,
        }

    def restore_state(self, state: dict[str, Any] | None):
        """Replace this store with a previously exported state."""
        if not state:
            return
        frame = state.get("frame")
        if not isinstance(frame, pd.DataFrame):
            raise TypeError("Stored communication table state does not contain a Pandas DataFrame")
        restored = frame.copy(deep=True)
        if "timestamp_ns" not in restored.columns:
            restored["timestamp_ns"] = restored.get("timestamp", pd.Series(index=restored.index)).map(
                lambda value: timestamp_ns(value) if value is not None and not pd.isna(value) else None
            )
        if "first_timestamp_ns" not in restored.columns:
            restored["first_timestamp_ns"] = restored.get("first_timestamp", restored.get("timestamp")).map(
                lambda value: timestamp_ns(value) if value is not None and not pd.isna(value) else None
            )
        restored["timestamp"] = restored["timestamp_ns"].map(
            lambda value: local_timestamp_from_ns(int(value)) if pd.notna(value) else None
        )
        restored["first_timestamp"] = restored["first_timestamp_ns"].map(
            lambda value: local_timestamp_from_ns(int(value)) if pd.notna(value) else None
        )
        if "timezone_name" not in restored.columns:
            restored["timezone_name"] = restored["timestamp_ns"].map(
                lambda value: local_timezone_name(int(value)) if pd.notna(value) else ""
            )
        for column in COLUMNS:
            if column not in restored.columns:
                restored[column] = None
        if "ingestion_sequence" not in frame.columns:
            restored["ingestion_sequence"] = range(1, len(restored) + 1)
        if "record_revision" not in frame.columns:
            restored["record_revision"] = pd.to_numeric(
                restored.get("update_count"), errors="coerce",
            ).fillna(1).astype(int)
        self.frame = restored.loc[:, COLUMNS].reset_index(drop=True)
        largest_id = int(pd.to_numeric(self.frame["id"], errors="coerce").max() or 0) if not self.frame.empty else 0
        self.next_id = max(largest_id + 1, int(state.get("next_id", largest_id + 1) or largest_id + 1))
        self.version = max(0, int(state.get("version", 0) or 0))
        self._pending = []
        self._pending_conflicts = {}
        self._apply_retention()
        self._rebuild_conflict_index()
