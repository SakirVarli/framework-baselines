from __future__ import annotations

import re
import fnmatch
from datetime import datetime
from typing import Any, Iterable

import numpy as np
import pandas as pd

from .local_time import local_iso, now_ns, timestamp_ns


def get_path(value: Any, path: str, missing: Any = None) -> Any:
    parts = path.split(".")
    if parts and parts[0] == "data":
        parts = parts[1:]
    current = value
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, (list, tuple, np.ndarray)) and part.isdigit() and int(part) < len(current):
            current = current[int(part)]
        else:
            return missing
    return current


def get_path_tokens(value: Any, tokens: Iterable[Any], missing: Any = None) -> Any:
    """Resolve an unambiguous structured path, including dotted dictionary keys."""
    current = value
    for token in tokens:
        if isinstance(current, dict) and token in current:
            current = current[token]
        elif (
            isinstance(current, (list, tuple, np.ndarray))
            and isinstance(token, int)
            and -len(current) <= token < len(current)
        ):
            current = current[token]
        else:
            return missing
    return current


def contains_value(value: Any, target: Any) -> bool:
    if isinstance(value, dict):
        return any(contains_value(item, target) for item in value.values())
    if isinstance(value, np.ndarray):
        return any(contains_value(item, target) for item in value.flat)
    if isinstance(value, (list, tuple, set)):
        return any(contains_value(item, target) for item in value)
    if isinstance(value, np.generic):
        value = value.item()
    return value == target


def discover_paths(values: Iterable[Any], maximum_samples: int = 500) -> dict[str, list[str]]:
    result: dict[str, set[str]] = {}

    def visit(value: Any, prefix: str):
        if isinstance(value, dict):
            for key, item in value.items():
                visit(item, f"{prefix}.{key}" if prefix else str(key))
        elif isinstance(value, (list, tuple, np.ndarray)):
            for index, item in enumerate(value[:20]):
                visit(item, f"{prefix}.{index}")
        else:
            if isinstance(value, np.generic):
                value = value.item()
            result.setdefault(prefix, set()).add(type(value).__name__)

    for index, value in enumerate(values):
        if index >= maximum_samples:
            break
        visit(value, "data")
    return {path: sorted(types) for path, types in sorted(result.items()) if path}


def _as_bytes(value: Any) -> bytes:
    if isinstance(value, np.ndarray):
        return value.tobytes()
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, str):
        compact = value.replace(" ", "").replace("0x", "")
        return bytes.fromhex(compact)
    if isinstance(value, int):
        return bytes([value])
    return bytes(value)


class QueryEngine:
    def mask(self, frame: pd.DataFrame, query: dict | None, now: datetime | None = None) -> pd.Series:
        if frame.empty:
            return pd.Series([], index=frame.index, dtype=bool)
        if not query:
            return pd.Series(True, index=frame.index)
        now = now if now is not None else now_ns()
        return self._node(frame, query, now)

    def matches_record(self, record: dict, query: dict | None) -> bool:
        frame = pd.DataFrame([record])
        mask = self.mask(frame, query)
        return bool(mask.iloc[0]) if len(mask) else False

    def _node(self, frame: pd.DataFrame, node: dict, now: datetime) -> pd.Series:
        if "conditions" in node:
            children = [self._node(frame, item, now) for item in node.get("conditions", [])]
            if not children:
                result = pd.Series(True, index=frame.index)
            elif str(node.get("operator", "and")).lower() == "or":
                result = children[0]
                for child in children[1:]:
                    result = result | child
            else:
                result = children[0]
                for child in children[1:]:
                    result = result & child
            return ~result if node.get("not") else result
        return self._condition(frame, node, now)

    def _series(self, frame: pd.DataFrame, field: str) -> pd.Series:
        numeric_time_field = f"{field}_ns" if field in {"timestamp", "first_timestamp", "last_timestamp"} else ""
        if numeric_time_field and numeric_time_field in frame.columns:
            return pd.to_numeric(frame[numeric_time_field], errors="coerce")
        if field.startswith("data."):
            return frame["data"].map(lambda value: get_path(value, field, None))
        if field.startswith("header_fields."):
            path = field[len("header_fields.") :]
            return frame["header_fields"].map(lambda value: get_path(value, path, None))
        if field not in frame.columns:
            return pd.Series(None, index=frame.index)
        if numeric_time_field:
            return frame[field].map(
                lambda value: timestamp_ns(value) if value is not None and not pd.isna(value) else None
            )
        return frame[field]

    def _condition(self, frame: pd.DataFrame, condition: dict, now: datetime) -> pd.Series:
        field = str(condition.get("field", ""))
        operation = str(condition.get("operation", "equals")).lower()
        value = condition.get("value")
        series = self._series(frame, field)
        is_timestamp = field in {"timestamp", "first_timestamp"}
        if is_timestamp:
            if operation != "within_last" and value is not None:
                if operation == "between" and isinstance(value, (list, tuple)):
                    value = [timestamp_ns(item) for item in value]
                else:
                    value = timestamp_ns(value)

        if operation in {"exists", "not_null"}:
            return series.notna()
        if operation in {"missing", "is_null"}:
            return series.isna()
        if operation in {"equals", "eq", "exact"}:
            return series.map(lambda item: item == value)
        if operation in {"not_equals", "ne"}:
            return series.map(lambda item: item != value)
        if operation == "in":
            values = value if isinstance(value, (list, tuple, set)) else [value]
            return series.map(lambda item: item in values)
        if operation == "contains":
            return series.map(
                lambda item: bool(np.any(item == value)) if isinstance(item, np.ndarray)
                else value in item if isinstance(item, (str, bytes, list, tuple, dict))
                else False
            )
        if operation == "contains_value":
            return series.map(lambda item: contains_value(item, value))
        if operation == "contains_bytes":
            needle = _as_bytes(value)
            return series.map(lambda item: needle in bytes(item) if isinstance(item, (bytes, bytearray)) else False)
        if operation == "starts_with":
            return series.map(lambda item: str(item).startswith(str(value)))
        if operation == "ends_with":
            return series.map(lambda item: str(item).endswith(str(value)))
        if operation == "regex":
            pattern = re.compile(str(value), 0 if condition.get("case_sensitive", True) else re.IGNORECASE)
            return series.map(lambda item: bool(pattern.search(str(item))))
        if operation == "glob":
            return series.map(lambda item: fnmatch.fnmatchcase(str(item), str(value)))
        if operation == "type_is":
            return series.map(lambda item: type(item).__name__ == str(value))
        if operation == "byte_at":
            offset, expected = value
            return series.map(lambda item: isinstance(item, (bytes, bytearray)) and -len(item) <= int(offset) < len(item) and item[int(offset)] == int(expected))
        if operation == "decoded_text_contains":
            encoding = condition.get("encoding", "utf-8")
            errors = condition.get("errors", "replace")
            return series.map(lambda item: str(value) in bytes(item).decode(encoding, errors=errors) if isinstance(item, (bytes, bytearray)) else False)
        if operation in {"gt", "greater_than", "after"}:
            return series.map(lambda item: item is not None and item > value)
        if operation in {"gte", "greater_or_equal"}:
            return series.map(lambda item: item is not None and item >= value)
        if operation in {"lt", "less_than", "before"}:
            return series.map(lambda item: item is not None and item < value)
        if operation in {"lte", "less_or_equal"}:
            return series.map(lambda item: item is not None and item <= value)
        if operation == "between":
            low, high = value
            return series.map(lambda item: item is not None and low <= item <= high)
        if operation == "within_last":
            amount = float(value)
            unit = condition.get("unit", "seconds")
            seconds = amount * {"milliseconds": 0.001, "seconds": 1, "minutes": 60, "hours": 3600}.get(unit, 1)
            reference_ns = timestamp_ns(now) if isinstance(now, datetime) else int(now)
            threshold = reference_ns - int(seconds * 1_000_000_000)
            return pd.to_numeric(series, errors="coerce") >= threshold
        raise ValueError(f"Unsupported query operation: {operation}")


def serialize_value(value: Any) -> Any:
    if isinstance(value, pd.Timestamp):
        return local_iso(value, timespec="microseconds")
    if isinstance(value, datetime):
        return local_iso(value, timespec="microseconds")
    if isinstance(value, bytes):
        return {"$bytes_hex": value.hex()}
    if isinstance(value, np.ndarray):
        return [serialize_value(item) for item in value.tolist()]
    if isinstance(value, np.generic):
        return serialize_value(value.item())
    if isinstance(value, dict):
        return {str(key): serialize_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [serialize_value(item) for item in value]
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return value
