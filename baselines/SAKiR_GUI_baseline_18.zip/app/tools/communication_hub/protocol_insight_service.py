from __future__ import annotations

"""Process-isolated Protocol Insights service and its GUI-side controller."""

import multiprocessing
import pickle
import queue
import secrets
import threading
import time
import traceback
import uuid
from multiprocessing.connection import Client, Connection, Listener
from pathlib import Path
from typing import Any

from .protocol_insight_runtime import ProtocolInsightRuntimeManager


DEFAULT_SERVICE_CONFIG = {
    "ingress_capacity": 4096,
    "publisher_capacity_per_session": 1024,
    "ingress_batch_records": 512,
    "ingress_time_slice_ms": 8,
    "idle_sleep_ms": 2,
}


def normalize_protocol_insight_service_config(value: dict | None) -> dict[str, int]:
    source = value if isinstance(value, dict) else {}
    try:
        capacity = max(16, min(1_000_000, int(source.get("ingress_capacity", 4096))))
        publisher_capacity = max(
            1, min(1_000_000, int(source.get("publisher_capacity_per_session", 1024)))
        )
        batch = max(1, min(capacity, int(source.get("ingress_batch_records", 512))))
        time_slice_ms = max(
            1, min(1000, int(source.get("ingress_time_slice_ms", 8)))
        )
        idle_ms = max(0, min(1000, int(source.get("idle_sleep_ms", 2))))
    except (TypeError, ValueError) as error:
        raise ValueError("Protocol Insight service limits must be integers") from error
    return {
        "ingress_capacity": capacity,
        "publisher_capacity_per_session": publisher_capacity,
        "ingress_batch_records": batch,
        "ingress_time_slice_ms": time_slice_ms,
        "idle_sleep_ms": idle_ms,
    }


class ProtocolInsightService:
    """Own all live Protocol Insight runtimes outside communication sessions."""

    def __init__(
        self,
        connection: Connection,
        ingress_authkey: bytes,
        project_root: str | Path,
        config: dict | None = None,
    ):
        self.connection = connection
        self.config = normalize_protocol_insight_service_config(config)
        self.ingress_queue = queue.Queue(maxsize=self.config["ingress_capacity"])
        self.ingress_authkey = bytes(ingress_authkey)
        self.ingress_listener = Listener(
            ("127.0.0.1", 0), family="AF_INET", authkey=self.ingress_authkey
        )
        self.ingress_address = tuple(self.ingress_listener.address)
        self._ingress_stop = threading.Event()
        self._ingress_clients: set[Connection] = set()
        self._ingress_clients_lock = threading.RLock()
        self._ingress_accept_thread = threading.Thread(
            target=self._accept_ingress,
            name="protocol-insight-ingress-accept",
            daemon=True,
        )
        self._ingress_accept_thread.start()
        self.project_root = Path(project_root)
        self.manager = ProtocolInsightRuntimeManager(self.project_root)
        self.running = True
        self.records_received = 0
        self.records_processed = 0
        self.processing_errors = 0
        self.last_error = ""
        self.last_record_monotonic = 0.0
        self.total_processing_ns = 0
        self.maximum_processing_ns = 0
        self.ingress_records_dropped = 0

    def _accept_ingress(self):
        while not self._ingress_stop.is_set():
            try:
                client = self.ingress_listener.accept()
            except (EOFError, OSError):
                break
            with self._ingress_clients_lock:
                self._ingress_clients.add(client)
            threading.Thread(
                target=self._read_ingress_client,
                args=(client,),
                name="protocol-insight-ingress-client",
                daemon=True,
            ).start()

    def _read_ingress_client(self, client: Connection):
        try:
            while not self._ingress_stop.is_set():
                payload = client.recv_bytes()
                try:
                    self.ingress_queue.put_nowait(payload)
                except queue.Full:
                    self.ingress_records_dropped += 1
        except (EOFError, OSError):
            pass
        finally:
            with self._ingress_clients_lock:
                self._ingress_clients.discard(client)
            try:
                client.close()
            except OSError:
                pass

    @staticmethod
    def _runtime_accepts(runtime, record: dict[str, Any]) -> bool:
        scope = runtime.config.get("runtime_scope", {})
        if not isinstance(scope, dict) or scope.get("mode") == "all":
            return True
        session_ids = {str(item) for item in scope.get("session_ids", [])}
        return str(record.get("session_id", "")) in session_ids

    def _consume(self, record: dict[str, Any]):
        self.records_received += 1
        started = time.perf_counter_ns()
        for runtime in tuple(self.manager.runtimes.values()):
            if not self._runtime_accepts(runtime, record):
                continue
            try:
                runtime.consume(record)
            except BaseException as error:
                runtime.error_count += 1
                runtime.last_error = f"{type(error).__name__}: {error}"
                self.processing_errors += 1
                self.last_error = runtime.last_error
        elapsed = time.perf_counter_ns() - started
        self.records_processed += 1
        self.total_processing_ns += elapsed
        self.maximum_processing_ns = max(self.maximum_processing_ns, elapsed)
        self.last_record_monotonic = time.monotonic()

    def _drain_ingress(self) -> int:
        drained = 0
        maximum = self.config["ingress_batch_records"]
        deadline_ns = time.perf_counter_ns() + (
            self.config["ingress_time_slice_ms"] * 1_000_000
        )
        while drained < maximum:
            # Display/configuration commands take priority over the next record.
            # A processor already executing cannot be pre-empted, but a long
            # ingress backlog must never postpone reads until capture stops.
            if drained and self.connection.poll():
                break
            if drained and time.perf_counter_ns() >= deadline_ns:
                break
            try:
                envelope = self.ingress_queue.get_nowait()
            except queue.Empty:
                break
            # Every dequeued item consumes batch budget, including malformed
            # input, so a bad producer cannot starve commands or runtime ticks.
            drained += 1
            record = None
            payload = envelope
            if isinstance(envelope, dict):
                if envelope.get("kind") != "record":
                    continue
                record = envelope.get("record")
                payload = envelope.get("payload")
            if isinstance(payload, (bytes, bytearray, memoryview)):
                try:
                    record = pickle.loads(bytes(payload))
                except BaseException as error:
                    self.processing_errors += 1
                    self.last_error = f"{type(error).__name__}: {error}"
                    continue
            if isinstance(record, dict):
                self._consume(record)
        return drained

    def _status(self) -> dict[str, Any]:
        try:
            queue_depth = max(0, int(self.ingress_queue.qsize()))
        except (AttributeError, NotImplementedError, OSError):
            queue_depth = -1
        average_ns = (
            self.total_processing_ns // self.records_processed
            if self.records_processed else 0
        )
        return {
            "state": "running" if self.running else "stopping",
            "pid": multiprocessing.current_process().pid,
            "ingress_capacity": self.config["ingress_capacity"],
            "ingress_depth": queue_depth,
            "ingress_address": list(self.ingress_address),
            "ingress_records_dropped": self.ingress_records_dropped,
            "ingress_time_slice_ms": self.config["ingress_time_slice_ms"],
            "records_received": self.records_received,
            "records_processed": self.records_processed,
            "processing_errors": self.processing_errors,
            "average_processing_ns": average_ns,
            "maximum_processing_ns": self.maximum_processing_ns,
            "last_error": self.last_error,
            "runtimes": self.manager.metrics(),
        }

    def _command(self, command: str, payload: dict) -> Any:
        command = command.removeprefix("protocol_insight_")
        if command in {"ping", "status"}:
            return self._status()
        if command == "upsert":
            self.manager.upsert(payload["config"])
            return {"id": str(payload["config"].get("id", "")), "active": True}
        if command == "ensure":
            return self.manager.ensure(payload["config"])
        if command == "delete":
            self.manager.delete(str(payload["protocol_insight_id"]))
            return True
        if command == "pause":
            return self.manager.pause(str(payload["protocol_insight_id"]))
        if command == "resume":
            return self.manager.resume(str(payload["protocol_insight_id"]))
        if command == "export":
            if not bool(payload.get("final", False)):
                raise ValueError(
                    "Non-final Protocol Insight Excel writes are no longer supported; "
                    "use final_export"
                )
            return self.manager.export(
                str(payload["protocol_insight_id"]), True
            )
        if command == "final_export":
            insight_id = str(payload["protocol_insight_id"])
            if self.manager.active(insight_id):
                result = self.manager.final_export(insight_id)
                result["source"] = "retained_dataset"
                return result
            config = payload.get("config")
            if not isinstance(config, dict):
                raise KeyError(
                    f"Protocol Insight '{insight_id}' is stopped; provide its "
                    "configuration to export from a checkpoint"
                )
            return self.manager.export_checkpoint(config, final=True)
        if command == "checkpoint_info":
            return self.manager.checkpoint_info(payload["config"])
        if command == "samples":
            return self.manager.samples(
                str(payload["protocol_insight_id"]), int(payload.get("limit", 1000))
            )
        if command == "sample_delta":
            config = payload.get("config")
            if isinstance(config, dict):
                self.manager.ensure(config)
            return self.manager.sample_delta(
                str(payload["protocol_insight_id"]),
                int(payload.get("after_version", 0)),
                int(payload.get("limit", 1000)),
            )
        if command == "event_delta":
            return self.manager.event_delta(
                str(payload["protocol_insight_id"]),
                int(payload.get("after_version", 0)),
                int(payload.get("limit", 1000)),
            )
        if command == "display_snapshot":
            return self.manager.display_snapshot(
                str(payload["protocol_insight_id"]),
                int(payload.get("sample_limit", 1000)),
                int(payload.get("event_limit", 1000)),
            )
        if command == "event_retention":
            return self.manager.set_event_retention(
                str(payload["protocol_insight_id"]),
                bool(payload.get("enabled", False)),
            )
        if command == "replay":
            insight_id = str(payload["protocol_insight_id"])
            runtime = self.manager.runtimes.get(insight_id)
            if runtime is None:
                raise KeyError(f"Protocol Insight '{insight_id}' is not active")
            records = [
                record for record in payload.get("records", [])
                if isinstance(record, dict) and self._runtime_accepts(runtime, record)
            ]
            return self.manager.replay(
                insight_id, records,
            )
        if command == "metrics":
            return self.manager.metrics()
        if command == "stop":
            self.running = False
            return True
        raise ValueError(f"Unknown Protocol Insight service command: {command}")

    def _process_commands(self) -> int:
        processed = 0
        while self.connection.poll():
            request = self.connection.recv()
            request_id = request.get("id")
            try:
                result = self._command(
                    str(request.get("command", "")), request.get("payload") or {}
                )
                self.connection.send({"id": request_id, "ok": True, "result": result})
            except BaseException as error:
                self.last_error = f"{type(error).__name__}: {error}"
                self.connection.send({
                    "id": request_id,
                    "ok": False,
                    "error": self.last_error,
                    "traceback": traceback.format_exc(),
                })
            processed += 1
        return processed

    def run(self):
        try:
            while self.running:
                commands = self._process_commands()
                if not self.running:
                    break
                drained = self._drain_ingress()
                # A command may have arrived while the current record was
                # processing. Serve it before scheduled collection/checkpoint
                # maintenance so live display remains responsive.
                commands += self._process_commands()
                if not self.running:
                    break
                self.manager.tick()
                if not commands and not drained and self.config["idle_sleep_ms"]:
                    time.sleep(self.config["idle_sleep_ms"] / 1000.0)
        finally:
            self._ingress_stop.set()
            try:
                self.ingress_listener.close()
            except OSError:
                pass
            with self._ingress_clients_lock:
                clients = tuple(self._ingress_clients)
            for client in clients:
                try:
                    client.close()
                except OSError:
                    pass
            self.manager.close()


def protocol_insight_service_entry(
    connection: Connection,
    ingress_authkey: bytes,
    project_root: str,
    config: dict | None = None,
):
    try:
        ProtocolInsightService(connection, ingress_authkey, project_root, config).run()
    except BaseException as error:
        try:
            connection.send({
                "id": "__service_fatal__",
                "ok": False,
                "fatal": True,
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(),
            })
        except BaseException:
            pass
        raise
    finally:
        connection.close()


class ProtocolInsightIngressClient:
    """Picklable producer for the service-owned loopback ingress endpoint.

    Only the endpoint and authentication key cross the spawn boundary.  The
    socket is opened lazily in each session worker's publisher thread, so no
    Windows queue locks, semaphore handles, or live connections are inherited.
    """

    def __init__(self, endpoint: dict | None = None):
        self.endpoint = dict(endpoint or {})
        self._connection: Connection | None = None
        self._lock = threading.RLock()

    def __getstate__(self):
        return {"endpoint": self.endpoint}

    def __setstate__(self, state):
        self.endpoint = dict(state.get("endpoint") or {})
        self._connection = None
        self._lock = threading.RLock()

    def cancel_join_thread(self):
        """Compatibility with the former multiprocessing.Queue producer."""

    def close(self):
        with self._lock:
            connection, self._connection = self._connection, None
            if connection is not None:
                try:
                    connection.close()
                except OSError:
                    pass

    def _connect(self) -> Connection:
        address = self.endpoint.get("address")
        authkey = self.endpoint.get("authkey")
        if not isinstance(address, (list, tuple)) or len(address) != 2 or not authkey:
            raise RuntimeError("Protocol Insights ingress endpoint is not available")
        return Client(
            (str(address[0]), int(address[1])),
            family="AF_INET",
            authkey=bytes.fromhex(str(authkey)),
        )

    def put_nowait(self, envelope):
        payload = envelope.get("payload") if isinstance(envelope, dict) else envelope
        if not isinstance(payload, (bytes, bytearray, memoryview)):
            payload = pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL)
        payload = bytes(payload)
        with self._lock:
            for attempt in range(2):
                try:
                    if self._connection is None:
                        self._connection = self._connect()
                    self._connection.send_bytes(payload)
                    return
                except (BrokenPipeError, ConnectionError, EOFError, OSError):
                    connection, self._connection = self._connection, None
                    if connection is not None:
                        try:
                            connection.close()
                        except OSError:
                            pass
                    if attempt:
                        raise


class ProtocolInsightServiceController:
    """GUI-side owner of the dedicated Protocol Insights process."""

    def __init__(self, project_root: str | Path, config: dict | None = None):
        self.project_root = str(project_root)
        self.config = normalize_protocol_insight_service_config(config)
        self._context = multiprocessing.get_context("spawn")
        self._ingress_authkey = secrets.token_bytes(32)
        self.ingress_queue = ProtocolInsightIngressClient()
        self.process: multiprocessing.Process | None = None
        self.connection = None
        self._lock = threading.RLock()

    @property
    def running(self) -> bool:
        return bool(self.process and self.process.is_alive())

    def start(self, timeout: float = 10.0) -> dict:
        with self._lock:
            if self.running:
                return self.request("status", timeout=timeout)
            parent, child = self._context.Pipe()
            self.process = self._context.Process(
                target=protocol_insight_service_entry,
                args=(child, self._ingress_authkey, self.project_root, self.config),
                name="CommunicationHub-ProtocolInsights",
                daemon=True,
            )
            self.connection = parent
            self.process.start()
            child.close()
            try:
                status = self.request("ping", timeout=timeout)
                self.ingress_queue.close()
                self.ingress_queue = ProtocolInsightIngressClient({
                    "address": status["ingress_address"],
                    "authkey": self._ingress_authkey.hex(),
                })
                return status
            except BaseException:
                self.discard_broken_process()
                raise

    def request(
        self, command: str, payload: dict | None = None, timeout: float = 30.0,
    ) -> Any:
        if not self.running or self.connection is None:
            raise RuntimeError("Protocol Insights service is not running")
        request_id = str(uuid.uuid4())
        with self._lock:
            self.connection.send({
                "id": request_id, "command": command, "payload": payload or {},
            })
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                wait = min(0.05, max(0.0, deadline - time.monotonic()))
                if self.connection.poll(wait):
                    response = self.connection.recv()
                    if response.get("fatal"):
                        detail = response.get("traceback") or response.get(
                            "error", "unknown child-process error"
                        )
                        raise RuntimeError(
                            "Protocol Insights service failed during startup:\n"
                            + str(detail).strip()
                        )
                    if response.get("id") != request_id:
                        continue
                    if not response.get("ok"):
                        raise RuntimeError(response.get("error", "Insight service command failed"))
                    return response.get("result")
            raise TimeoutError(f"Protocol Insight service command '{command}' timed out")

    def stop(self, timeout: float = 30.0):
        process = self.process
        if process is None:
            return
        if process.is_alive():
            try:
                self.request("stop", timeout=min(timeout, 10.0))
            except BaseException:
                pass
            process.join(timeout)
            if process.is_alive():
                process.terminate()
                process.join(3)
        if self.connection is not None:
            self.connection.close()
        self.connection = None
        self.process = None

    def discard_broken_process(self):
        """Discard a service whose command pipe closed unexpectedly."""
        with self._lock:
            process = self.process
            if process is not None and process.is_alive():
                process.terminate()
                process.join(3)
            if self.connection is not None:
                try:
                    self.connection.close()
                except (OSError, ValueError):
                    pass
            self.connection = None
            self.process = None

    def replace_ingress_queue(self):
        """Reset the endpoint before starting a replacement service process."""
        self.ingress_queue.close()
        self._ingress_authkey = secrets.token_bytes(32)
        self.ingress_queue = ProtocolInsightIngressClient()
        return self.ingress_queue
