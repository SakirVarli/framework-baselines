from __future__ import annotations

"""One local-time contract for Communication Hub backends and frontends.

Wall-clock values are offset-aware local timestamps.  Absolute ordering and
elapsed calculations use Unix nanoseconds; interval schedulers continue to use
``time.monotonic`` at their call sites.
"""

import time
from datetime import datetime
from typing import Any

import pandas as pd


def now_ns() -> int:
    return time.time_ns()


def local_datetime_from_ns(value: int) -> datetime:
    return datetime.fromtimestamp(int(value) / 1_000_000_000).astimezone()


def local_timestamp_from_ns(value: int) -> pd.Timestamp:
    return pd.Timestamp(local_datetime_from_ns(value))


def local_timezone_name(value_ns: int | None = None) -> str:
    value = local_datetime_from_ns(value_ns if value_ns is not None else now_ns())
    return str(value.tzname() or value.strftime("%z") or "Local")


def timestamp_ns(value: Any, *, naive_is_local: bool = True) -> int:
    if isinstance(value, bool):
        raise ValueError("Boolean values are not timestamps")
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float) and value == value:
        # Numeric X-axis values use seconds, while explicit backend fields use
        # nanoseconds. Values large enough to be nanoseconds are kept as-is.
        return int(value if abs(value) >= 100_000_000_000 else value * 1_000_000_000)
    stamp = pd.Timestamp(value)
    if pd.isna(stamp):
        raise ValueError("Timestamp is missing")
    if stamp.tzinfo is None:
        if not naive_is_local:
            raise ValueError("Timestamp must include a local numeric offset")
        local = stamp.to_pydatetime().astimezone()
        stamp = pd.Timestamp(local)
    return int(stamp.value)


def local_timestamp(value: Any) -> pd.Timestamp:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return local_timestamp_from_ns(timestamp_ns(value))
    return local_timestamp_from_ns(timestamp_ns(value))


def local_iso(value: Any, *, timespec: str = "milliseconds") -> str:
    return local_timestamp(value).to_pydatetime().isoformat(timespec=timespec)


def local_display(value: Any, *, milliseconds: bool = True, include_zone: bool = True) -> str:
    if value is None or value == "":
        return ""
    try:
        local = local_timestamp(value).to_pydatetime()
    except (TypeError, ValueError, OverflowError, OSError):
        return str(value)
    pattern = "%Y-%m-%d %H:%M:%S.%f" if milliseconds else "%Y-%m-%d %H:%M:%S"
    rendered = local.strftime(pattern)
    if milliseconds:
        rendered = rendered[:-3]
    if include_zone:
        numeric_offset = local.strftime("%z")
        if len(numeric_offset) == 5:
            numeric_offset = f"{numeric_offset[:3]}:{numeric_offset[3:]}"
        rendered += f" {numeric_offset or local.tzname() or 'local'}"
    return rendered


def excel_local_datetime(value: Any) -> datetime:
    return local_timestamp(value).to_pydatetime().replace(tzinfo=None)


def local_now() -> datetime:
    return datetime.now().astimezone()


def local_now_iso(*, timespec: str = "milliseconds") -> str:
    return local_now().isoformat(timespec=timespec)
