from __future__ import annotations

import struct
import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Frame:
    header: bytes
    payload: bytes
    header_fields: dict[str, Any]
    first_byte_timestamp_ns: int | None = None
    completed_timestamp_ns: int | None = None

    @property
    def message(self) -> bytes:
        """The exact complete message reconstructed from the receive stream."""
        return self.header + self.payload


class FramingError(ValueError):
    pass


class FrameDecoder:
    """Incremental exact-header/exact-payload decoder for arbitrary stream chunks."""

    def __init__(self, config: dict):
        self.config = config
        self.mode = config.get("mode", "raw_chunk")
        self.header_size = int(config.get("header_size", 0))
        self.maximum_payload_size = int(config.get("maximum_payload_size", 10 * 1024 * 1024))
        self.timeout_ns = int(config.get("partial_frame_timeout_ms", 5000)) * 1_000_000
        self._buffer = bytearray()
        self._expected_payload: int | None = None
        self._header = b""
        self._partial_started_ns: int | None = None

    def feed(self, chunk: bytes, now_ns: int | None = None) -> list[Frame]:
        if not chunk:
            return []
        if self.mode == "raw_chunk":
            timestamp_ns = time.time_ns() if now_ns is None else now_ns
            return [Frame(b"", bytes(chunk), {}, timestamp_ns, timestamp_ns)]
        now_ns = time.time_ns() if now_ns is None else now_ns
        if not self._buffer and self._expected_payload is None:
            self._partial_started_ns = now_ns
        self._buffer.extend(chunk)
        frames: list[Frame] = []
        while True:
            if self._expected_payload is None:
                if len(self._buffer) < self.header_size:
                    break
                self._header = bytes(self._buffer[: self.header_size])
                del self._buffer[: self.header_size]
                self._expected_payload = self._decode_payload_length(self._header)
            if len(self._buffer) < self._expected_payload:
                break
            payload = bytes(self._buffer[: self._expected_payload])
            del self._buffer[: self._expected_payload]
            frames.append(Frame(
                self._header, payload, self.decode_header_fields(self._header),
                self._partial_started_ns or now_ns, now_ns,
            ))
            self._header = b""
            self._expected_payload = None
            self._partial_started_ns = now_ns if self._buffer else None
        return frames

    def _decode_payload_length(self, header: bytes) -> int:
        field = self.config["length_field"]
        offset, size = int(field["offset"]), int(field["size"])
        declared = int.from_bytes(
            header[offset : offset + size],
            byteorder=field.get("endianness", "little"),
            signed=bool(field.get("signed", False)),
        )
        if field.get("meaning", "payload_length") == "total_frame_length":
            declared -= self.header_size
        payload_length = declared + int(field.get("adjustment", 0))
        if payload_length < 0:
            raise FramingError(f"Calculated payload length is negative: {payload_length}")
        if payload_length > self.maximum_payload_size:
            raise FramingError(
                f"Payload length {payload_length} exceeds configured maximum {self.maximum_payload_size}"
            )
        return payload_length

    def decode_header_fields(self, header: bytes) -> dict[str, Any]:
        result: dict[str, Any] = {}
        covered = [False] * self.header_size
        length = self.config.get("length_field") or {}
        if length.get("size"):
            length_offset, length_size = int(length["offset"]), int(length["size"])
            for index in range(length_offset, min(self.header_size, length_offset + length_size)):
                covered[index] = True
        for field in self.config.get("header_fields", []):
            name = str(field.get("name", "")).strip()
            if not name:
                continue
            offset, size = int(field["offset"]), int(field["size"])
            for index in range(offset, min(self.header_size, offset + size)):
                covered[index] = True
            raw = header[offset : offset + size]
            field_type = field.get("type", "uint")
            if field_type == "bytes":
                value: Any = raw
            elif field_type == "text":
                value = raw.decode(field.get("encoding", "utf-8"), errors=field.get("errors", "replace"))
            else:
                value = int.from_bytes(
                    raw,
                    byteorder=field.get("endianness", "little"),
                    signed=field_type == "int" or bool(field.get("signed", False)),
                )
            result[name] = value
        if length.get("size"):
            offset, size = int(length["offset"]), int(length["size"])
            result.setdefault(
                "declared_length",
                int.from_bytes(
                    header[offset : offset + size],
                    byteorder=length.get("endianness", "little"),
                    signed=bool(length.get("signed", False)),
                ),
            )
        offset = 0
        while offset < self.header_size:
            if covered[offset]:
                offset += 1
                continue
            start = offset
            while offset < self.header_size and not covered[offset]:
                offset += 1
            size = offset - start
            result[f"unknown_{start}_{size}"] = header[start:offset]
        return result

    def check_timeout(self, now_ns: int | None = None) -> tuple[bytes, bytes] | None:
        if self.mode == "raw_chunk" or self._partial_started_ns is None:
            return None
        now_ns = time.time_ns() if now_ns is None else now_ns
        if now_ns - self._partial_started_ns < self.timeout_ns:
            return None
        return self.reset()

    def reset(self) -> tuple[bytes, bytes]:
        header = self._header
        partial = bytes(self._buffer)
        self._buffer.clear()
        self._header = b""
        self._expected_payload = None
        self._partial_started_ns = None
        return header, partial


def build_frame(payload: bytes, config: dict, header_values: dict[str, Any] | None = None) -> Frame:
    """Explicitly construct bytes for callers that choose to do so.

    This helper is never used by the Communication Hub send path; sending is
    transparent and always writes the caller-supplied bytes unchanged.
    """
    payload = bytes(payload)
    if config.get("mode", "raw_chunk") == "raw_chunk":
        return Frame(b"", payload, {})
    header = bytearray(int(config["header_size"]))
    values = dict(header_values or {})
    for field in config.get("header_fields", []):
        name = str(field.get("name", ""))
        if name not in values and "tx_value" in field:
            values[name] = field["tx_value"]
        elif name not in values and "default" in field:
            values[name] = field["default"]
        if name not in values:
            continue
        offset, size = int(field["offset"]), int(field["size"])
        value = values[name]
        if field.get("type") == "bytes":
            encoded = bytes(value)
        elif field.get("type") == "text":
            encoded = str(value).encode(field.get("encoding", "utf-8"))
        else:
            encoded = int(value).to_bytes(
                size,
                byteorder=field.get("endianness", "little"),
                signed=field.get("type") == "int" or bool(field.get("signed", False)),
            )
        if len(encoded) != size:
            raise FramingError(f"Header field '{name}' must encode to exactly {size} bytes")
        header[offset : offset + size] = encoded

    length = config["length_field"]
    declared = len(payload)
    if length.get("meaning", "payload_length") == "total_frame_length":
        declared += len(header)
    declared -= int(length.get("adjustment", 0))
    offset, size = int(length["offset"]), int(length["size"])
    header[offset : offset + size] = int(declared).to_bytes(
        size,
        byteorder=length.get("endianness", "little"),
        signed=bool(length.get("signed", False)),
    )
    decoder = FrameDecoder(config)
    header_bytes = bytes(header)
    return Frame(header_bytes, payload, decoder.decode_header_fields(header_bytes))


def decode_numeric(raw: bytes, data_type: str, endianness: str = "little", signed: bool = False):
    if data_type in {"int", "uint"}:
        return int.from_bytes(raw, endianness, signed=signed or data_type == "int")
    prefix = "<" if endianness == "little" else ">"
    if data_type == "float32" and len(raw) == 4:
        return struct.unpack(prefix + "f", raw)[0]
    if data_type == "float64" and len(raw) == 8:
        return struct.unpack(prefix + "d", raw)[0]
    raise ValueError(f"Cannot decode {len(raw)} bytes as {data_type}")
