from __future__ import annotations

import asyncio
import multiprocessing
import os
import pickle
import queue
import threading
import time
import traceback
from multiprocessing.connection import Connection
from pathlib import Path

from .config import normalize_session_config, resolve_project_path
from .parser_runtime import Direction, ParseResult, ParserRuntime
from .store import EventInput, EventStore


class DataProcessingWorker:
    """Parser, table, persistence, query, and Insights side of one session."""

    def __init__(
        self, connection: Connection, capture_queue, config: dict,
        project_root: str, initial_store_state=None,
        protocol_insight_ingress=None, protocol_insight_publisher_capacity: int = 1024,
    ):
        self.connection = connection
        self.capture_queue = capture_queue
        self.config = normalize_session_config(config)
        self.project_root = Path(project_root)
        self.store = EventStore(self.config["storage"])
        self.store.restore_state(initial_store_state)
        self.parser = ParserRuntime(self.config["parser"])
        self.running = True
        self.last_error = ""
        self.records_processed = 0
        self.processing_errors = 0
        self.last_capture_sequence = 0
        self.sequence_gaps = 0
        self.last_persist = time.monotonic()
        self._persist_task: asyncio.Task | None = None
        self.persistence_last_error = ""
        self.protocol_insight_ingress = protocol_insight_ingress
        self.protocol_insight_publish_enabled = False
        self._publish_queue = queue.Queue(maxsize=max(1, int(protocol_insight_publisher_capacity)))
        self._publish_stop = threading.Event()
        self._publish_thread = None
        self.protocol_insight_records_published = 0
        self.protocol_insight_records_dropped = 0
        self.protocol_insight_publish_errors = 0
        self.protocol_insight_last_publish_error = ""
        if protocol_insight_ingress is not None:
            self._publish_thread = threading.Thread(
                target=self._publish_loop,
                name="protocol-insight-record-publisher",
                daemon=True,
            )
            self._publish_thread.start()

    def _publish(self, record: dict):
        if not self.protocol_insight_publish_enabled or self.protocol_insight_ingress is None:
            return
        try:
            self._publish_queue.put_nowait(record)
        except queue.Full:
            self.protocol_insight_records_dropped += 1

    def _publish_loop(self):
        while not self._publish_stop.is_set() or not self._publish_queue.empty():
            try:
                record = self._publish_queue.get(timeout=0.05)
            except queue.Empty:
                continue
            try:
                payload = pickle.dumps(record, protocol=pickle.HIGHEST_PROTOCOL)
                self.protocol_insight_ingress.put_nowait({
                    "kind": "record",
                    "session_id": str(self.config.get("id", "")),
                    "published_ns": time.time_ns(),
                    "pickle_protocol": pickle.HIGHEST_PROTOCOL,
                    "payload": payload,
                })
                self.protocol_insight_records_published += 1
            except queue.Full:
                self.protocol_insight_records_dropped += 1
            except BaseException as error:
                self.protocol_insight_publish_errors += 1
                self.protocol_insight_last_publish_error = f"{type(error).__name__}: {error}"
            finally:
                self._publish_queue.task_done()

    def _stop_publisher(self):
        self._publish_stop.set()
        if self._publish_thread is not None:
            self._publish_thread.join(timeout=2.0)
        try:
            self.protocol_insight_ingress.close()
        except (AttributeError, OSError, ValueError):
            pass

    def _consume(self, envelope: dict):
        sequence = int(envelope.get("capture_sequence", 0) or 0)
        if self.last_capture_sequence and sequence > self.last_capture_sequence + 1:
            self.sequence_gaps += sequence - self.last_capture_sequence - 1
        self.last_capture_sequence = max(self.last_capture_sequence, sequence)
        if envelope.get("kind") == "barrier":
            return
        direction = Direction(str(envelope.get("direction", "RX")))
        message = bytes(envelope.get("message", b""))
        if envelope.get("kind") == "framing_error":
            parsed = ParseResult(
                "FramingError", message, False, "error",
                error=str(envelope.get("error", "Framing error")),
            )
        else:
            parsed = self.parser.parse(message, direction)
        record = self.store.add(EventInput(
            timestamp_ns=int(envelope.get("timestamp_ns", time.time_ns())),
            completed_timestamp_ns=int(envelope.get("completed_timestamp_ns", envelope.get("timestamp_ns", time.time_ns()))),
            capture_sequence=sequence,
            direction=direction,
            protocol=self.config["protocol"],
            protocol_label=self.config.get("protocol_label", ""),
            message=message,
            header=bytes(envelope.get("header", b"")),
            header_fields=dict(envelope.get("header_fields", {})),
            session_id=self.config["id"],
            connection_id=str(envelope.get("connection_id", "")),
            peer=str(envelope.get("peer", "")),
        ), parsed)
        self.records_processed += 1
        if record is not None:
            self._publish(record)

    def _drain_capture(self, *, drain_all: bool = False) -> int:
        processing = self.config["processing"]
        maximum = int(processing["batch_records"])
        deadline = time.perf_counter_ns() + int(processing["time_slice_ms"]) * 1_000_000
        drained = 0
        while drain_all or drained < maximum:
            if not drain_all and drained and self.connection.poll():
                break
            if not drain_all and drained and time.perf_counter_ns() >= deadline:
                break
            try:
                envelope = self.capture_queue.get_nowait()
            except queue.Empty:
                break
            drained += 1
            if not isinstance(envelope, dict):
                continue
            try:
                self._consume(envelope)
            except BaseException as error:
                self.processing_errors += 1
                self.last_error = f"{type(error).__name__}: {error}"
        return drained

    def _status(self):
        result = self.store.metrics()
        try:
            depth = max(0, int(self.capture_queue.qsize()))
        except (AttributeError, NotImplementedError, OSError):
            depth = -1
        result.update({
            "processing_state": "running" if self.running else "stopping",
            "processing_pid": multiprocessing.current_process().pid,
            "processing_queue_depth": depth,
            "processing_queue_capacity": self.config["processing"]["queue_capacity"],
            "processing_records_processed": self.records_processed,
            "processing_errors": self.processing_errors,
            "processing_last_error": self.last_error,
            "processing_last_capture_sequence": self.last_capture_sequence,
            "processing_sequence_gaps": self.sequence_gaps,
            "persistence_inflight": bool(self._persist_task and not self._persist_task.done()),
            "persistence_last_error": self.persistence_last_error,
            "protocol_insight_records_published": self.protocol_insight_records_published,
            "protocol_insight_records_dropped": self.protocol_insight_records_dropped,
            "protocol_insight_publish_errors": self.protocol_insight_publish_errors,
            "protocol_insight_last_publish_error": self.protocol_insight_last_publish_error,
            "protocol_insight_publisher_enabled": self.protocol_insight_publish_enabled,
        })
        return result

    def _command(self, command: str, payload: dict):
        if command in {"ping", "data_status"}:
            return self._status()
        if command == "query":
            return self.store.query(
                payload.get("query"), page=payload.get("page", 0),
                page_size=payload.get("page_size", 200),
                sort_by=payload.get("sort_by", "timestamp"),
                descending=payload.get("descending", True),
            )
        if command == "table_state":
            return self.store.export_state()
        if command == "delete_preview":
            result = self.store.query(payload.get("query"), page=0, page_size=10)
            return {"count": result["total"], "version": result["version"], "sample": result["rows"]}
        if command == "delete":
            return self.store.delete(payload.get("query"), payload.get("expected_version"))
        if command == "names":
            return self.store.distinct_names()
        if command == "name_summary":
            return self.store.name_summary()
        if command == "fields":
            return self.store.discover_fields(payload.get("name"))
        if command == "protocol_insight_publisher":
            self.protocol_insight_publish_enabled = bool(payload.get("enabled", False))
            return {"enabled": self.protocol_insight_publish_enabled, "queued": self._publish_queue.qsize()}
        if command == "persist":
            return "persist"
        if command == "stop":
            self.running = False
            return True
        raise ValueError(f"Unknown data-processing command: {command}")

    async def _process_commands(self):
        while self.connection.poll():
            request = self.connection.recv()
            request_id = request.get("id")
            try:
                command = request.get("command")
                # A query issued after an I/O send should observe every capture
                # envelope already queued before that query is served.
                if command in {
                    "query", "table_state", "delete_preview", "delete",
                    "names", "name_summary", "fields", "persist", "stop",
                }:
                    self._drain_capture(drain_all=True)
                    self.store.flush()
                result = self._command(command, request.get("payload") or {})
                if result == "persist":
                    await self._await_current_persistence()
                    await self._persist_snapshot(final=bool((request.get("payload") or {}).get("final", False)))
                    result = True
                self.connection.send({"id": request_id, "ok": True, "result": result})
            except BaseException as error:
                self.last_error = traceback.format_exc()
                self.connection.send({
                    "id": request_id, "ok": False,
                    "error": f"{type(error).__name__}: {error}",
                })

    async def _await_current_persistence(self):
        if self._persist_task is None:
            return
        await self._persist_task
        self._persist_task = None

    async def _maybe_persist(self):
        persistence = self.config.get("persistence", {})
        if not persistence.get("enabled"):
            return
        if self._persist_task is not None and self._persist_task.done():
            try:
                await self._persist_task
                self.persistence_last_error = ""
            except BaseException as error:
                self.persistence_last_error = f"{type(error).__name__}: {error}"
            self._persist_task = None
        if (
            self._persist_task is None
            and time.monotonic() - self.last_persist >= float(persistence.get("interval_seconds", 30))
        ):
            self.last_persist = time.monotonic()
            self._persist_task = asyncio.create_task(
                self._persist_snapshot(final=False),
                name=f"data-persistence-{self.config['id']}",
            )

    async def _persist_snapshot(self, final: bool):
        frame = self.store.snapshot()
        counts = self.store.name_summary_frame()
        directory = resolve_project_path(
            self.project_root, self.config["persistence"]["directory"],
        ) / self.config["id"]
        directory.mkdir(parents=True, exist_ok=True)
        suffix = "final" if final else "latest"
        path = directory / f"messages_{suffix}.pkl"
        temporary = path.with_suffix(".tmp.pkl")
        counts_path = directory / f"message_counts_{suffix}.pkl"
        counts_temporary = counts_path.with_suffix(".tmp.pkl")

        def write():
            frame.to_pickle(temporary)
            os.replace(temporary, path)
            counts.to_pickle(counts_temporary)
            os.replace(counts_temporary, counts_path)

        await asyncio.to_thread(write)

    async def run(self):
        while self.running:
            await self._process_commands()
            self._drain_capture()
            self.store.flush_if_due()
            await self._maybe_persist()
            await asyncio.sleep(0.002)
        self._drain_capture(drain_all=True)
        self.store.flush()
        try:
            await self._await_current_persistence()
        except BaseException as error:
            self.persistence_last_error = f"{type(error).__name__}: {error}"
        if self.config.get("persistence", {}).get("enabled") and self.config["persistence"].get("save_on_stop", True):
            await self._persist_snapshot(final=True)
        self._stop_publisher()


def data_processing_process_entry(
    connection: Connection, capture_queue, config: dict, project_root: str,
    initial_store_state=None, protocol_insight_ingress=None,
    protocol_insight_publisher_capacity: int = 1024, diagnostic_queue=None,
):
    try:
        asyncio.run(DataProcessingWorker(
            connection, capture_queue, config, project_root, initial_store_state,
            protocol_insight_ingress, protocol_insight_publisher_capacity,
        ).run())
    except BaseException as error:
        if diagnostic_queue is not None:
            try:
                diagnostic_queue.put_nowait({
                    "backend": "Data-processing",
                    "error": f"{type(error).__name__}: {error}",
                    "traceback": traceback.format_exc(),
                    "timestamp_ns": time.time_ns(),
                })
            except BaseException:
                pass
        raise
    finally:
        connection.close()
