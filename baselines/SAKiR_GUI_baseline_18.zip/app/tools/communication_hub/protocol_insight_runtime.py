from __future__ import annotations

from pathlib import Path
from typing import Any
import copy
from bisect import bisect_right

from .protocol_insight_runtime_core import (
    ProtocolInsightRuntimeCore,
    default_protocol_insight_runtime_core_config,
    normalize_protocol_insight_runtime_core_config,
)
from .local_time import timestamp_ns


def default_protocol_insight_runtime_config() -> dict:
    config = default_protocol_insight_runtime_core_config()
    config["name"] = "Protocol Insight"
    return config


def normalize_protocol_insight_runtime_config(value: dict | None, *, existing=True) -> dict:
    config = normalize_protocol_insight_runtime_core_config(value, existing=existing)
    if not str(config["checkpoint"].get("directory", "")).strip():
        config["checkpoint"]["directory"] = "app/data/communication_hub/protocol_insights/checkpoints"
    if not str(config["excel"].get("directory", "")).strip():
        config["excel"]["directory"] = "app/data/communication_hub/protocol_insights/output"
    return config


class ProtocolInsightRuntime(ProtocolInsightRuntimeCore):
    """Dedicated service-process host for one Protocol Insight."""


class ProtocolInsightRuntimeManager:
    def __init__(self, project_root: str | Path):
        self.project_root = Path(project_root)
        self.runtimes: dict[str, ProtocolInsightRuntime] = {}
        self.errors: list[dict[str, str]] = []

    def consume(self, record: dict[str, Any]) -> list[dict[str, Any]]:
        samples = []
        for runtime in self.runtimes.values():
            try:
                sample = runtime.consume(record)
                if sample is not None:
                    samples.append({"protocol_insight_id": runtime.config["id"], "sample": sample})
            except BaseException as error:
                runtime.error_count += 1
                runtime.last_error = f"{type(error).__name__}: {error}"
        return samples

    def tick(self):
        for runtime in self.runtimes.values():
            try:
                runtime.tick()
            except BaseException as error:
                runtime.error_count += 1
                runtime.last_error = f"{type(error).__name__}: {error}"

    def upsert(self, config: dict):
        normalized = normalize_protocol_insight_runtime_config(config, existing=True)
        insight_id = str(normalized["id"])
        previous = self.runtimes.pop(insight_id, None)
        if previous:
            previous.close(final_outputs=False)
        self.runtimes[insight_id] = ProtocolInsightRuntime(normalized, self.project_root)

    def ensure(self, config: dict) -> dict[str, Any]:
        """Install a runtime only when it is absent, preserving live samples."""
        insight_id = str(config.get("id", "")) if isinstance(config, dict) else ""
        if insight_id and insight_id in self.runtimes:
            return {"id": insight_id, "active": True, "created": False}
        normalized = normalize_protocol_insight_runtime_config(config, existing=True)
        insight_id = str(normalized["id"])
        if insight_id not in self.runtimes:
            self.runtimes[insight_id] = ProtocolInsightRuntime(normalized, self.project_root)
            return {"id": insight_id, "active": True, "created": True}
        return {"id": insight_id, "active": True, "created": False}

    def replay(self, insight_id: str, records: list[dict[str, Any]]) -> int:
        """Feed retained records once when a newly started insight requests recovery."""
        runtime = self._runtime(insight_id)
        if runtime.checkpoint_restored:
            return 0
        ordered = sorted(
            (record for record in records if isinstance(record, dict)),
            key=lambda record: (
                int(record.get("ingestion_sequence", 0) or 0),
                int(record.get("timestamp_ns", 0) or timestamp_ns(record.get("timestamp"))),
            ),
        )
        for record in ordered:
            runtime.consume(record)
        if runtime._protocol_collection.get("mode") == "scheduled":
            runtime._flush_protocol_candidates()
        return len(ordered)

    def active(self, insight_id: str) -> bool:
        return str(insight_id) in self.runtimes

    def delete(self, insight_id: str):
        runtime = self.runtimes.pop(str(insight_id), None)
        if runtime:
            runtime.close(final_outputs=True)

    def pause(self, insight_id: str) -> dict:
        return self._runtime(insight_id).pause()

    def resume(self, insight_id: str) -> dict:
        return self._runtime(insight_id).resume()

    def export(self, insight_id: str, final: bool = False) -> dict:
        if not final:
            raise ValueError("Only final Protocol Insight workbooks are supported")
        return self._runtime(insight_id).export_and_wait(final=True)

    def final_export(self, insight_id: str) -> dict:
        return self._runtime(insight_id).export_and_wait(final=True)

    def checkpoint_info(self, config: dict) -> dict[str, Any]:
        """Inspect the selected insight's checkpoint even when it is stopped."""
        probe_config = copy.deepcopy(config)
        probe_config.setdefault("checkpoint", {})["enabled"] = False
        runtime = ProtocolInsightRuntime(probe_config, self.project_root)
        try:
            return runtime.checkpoint_info()
        finally:
            runtime.close(final_outputs=False)

    def export_checkpoint(self, config: dict, final: bool = True) -> dict[str, Any]:
        """Create a workbook directly from durable checkpoint samples.

        This path deliberately reads the saved sample list rather than starting
        collection or depending on a retained in-process dataset.  It therefore
        remains available after a crash or a completed orderly stop.
        """
        probe_config = copy.deepcopy(config)
        probe_config.setdefault("checkpoint", {})["enabled"] = False
        runtime = ProtocolInsightRuntime(probe_config, self.project_root)
        try:
            info = runtime.checkpoint_info()
            if not info.get("available"):
                raise FileNotFoundError(
                    f"No checkpoint is available for '{runtime.config['name']}'"
                )
            state = runtime._read_checkpoint_state()
            samples = copy.deepcopy(state.get("samples", []))
            if not samples:
                raise RuntimeError("The available checkpoint contains no insight samples")
            path = runtime._write_excel(samples, final=bool(final))
            return {
                "path": str(path), "samples": len(samples),
                "final": bool(final), "source": "checkpoint",
                "checkpoint": info,
            }
        finally:
            runtime.close(final_outputs=False)

    def samples(self, insight_id: str, limit: int = 1000) -> list[dict[str, Any]]:
        runtime = self.runtimes.get(str(insight_id))
        if runtime is None:
            return []
        with runtime._lock:
            return copy.deepcopy(runtime.samples[-max(1, int(limit)):])

    def sample_delta(
        self, insight_id: str, after_version: int = 0, limit: int = 1000,
    ) -> dict[str, Any]:
        """Return only samples newer than a display cursor.

        A reset is reported when retention removed part of the requested range
        or when the unseen backlog exceeds the requested page size. In either
        case the newest bounded snapshot is returned so frontend polling
        cadence cannot change the visible sample density.
        """
        runtime = self.runtimes.get(str(insight_id))
        if runtime is None:
            return {
                "samples": [], "cursor": 0, "latest_version": 0,
                "retained_from": 0, "reset": bool(after_version),
            }
        maximum = max(1, int(limit))
        requested = max(0, int(after_version))
        with runtime._lock:
            latest = int(runtime.sample_version)
            versions = runtime._sample_versions
            retained_from = int(versions[0]) if versions else latest + 1
            start = bisect_right(versions, requested) if versions else 0
            reset = (
                requested > latest
                or requested < retained_from - 1
                or len(versions) - start > maximum
            )
            if not versions or requested == latest:
                selected_samples = []
                selected_versions = []
            elif reset:
                selected_samples = runtime.samples[-maximum:]
                selected_versions = versions[-maximum:]
            else:
                selected_samples = runtime.samples[start:start + maximum]
                selected_versions = versions[start:start + maximum]
            cursor = int(selected_versions[-1]) if selected_versions else min(requested, latest)
            return {
                "samples": copy.deepcopy(selected_samples),
                "cursor": cursor,
                "latest_version": latest,
                "retained_from": retained_from,
                "reset": reset,
            }

    def event_delta(
        self, insight_id: str, after_version: int = 0, limit: int = 1000,
    ) -> dict[str, Any]:
        """Return eligible events, resetting to newest when a cursor falls behind."""
        runtime = self.runtimes.get(str(insight_id))
        if runtime is None:
            return {
                "events": [], "cursor": 0, "latest_version": 0,
                "retained_from": 0, "reset": bool(after_version),
            }
        maximum = max(1, int(limit))
        requested = max(0, int(after_version))
        with runtime._lock:
            latest = int(runtime.event_version)
            versions = runtime._event_versions
            retained_from = int(versions[0]) if versions else latest + 1
            start = bisect_right(versions, requested) if versions else 0
            reset = (
                requested > latest
                or requested < retained_from - 1
                or len(versions) - start > maximum
            )
            if not versions or requested == latest:
                selected_events = []
                selected_versions = []
            elif reset:
                selected_events = runtime.events[-maximum:]
                selected_versions = versions[-maximum:]
            else:
                selected_events = runtime.events[start:start + maximum]
                selected_versions = versions[start:start + maximum]
            cursor = int(selected_versions[-1]) if selected_versions else min(requested, latest)
            return {
                "events": copy.deepcopy(selected_events),
                "cursor": cursor,
                "latest_version": latest,
                "retained_from": retained_from,
                "reset": reset,
            }

    def display_snapshot(
        self, insight_id: str, sample_limit: int = 1000,
        event_limit: int = 1000,
    ) -> dict[str, Any]:
        """Return one atomic newest display snapshot for samples and overlays."""
        runtime = self.runtimes.get(str(insight_id))
        if runtime is None:
            return {
                "samples": [], "events": [],
                "sample_cursor": 0, "event_cursor": 0,
                "sample_latest_version": 0, "event_latest_version": 0,
            }
        sample_maximum = max(1, int(sample_limit))
        event_maximum = max(1, int(event_limit))
        with runtime._lock:
            samples = copy.deepcopy(runtime.samples[-sample_maximum:])
            events = copy.deepcopy(runtime.events[-event_maximum:])
            return {
                "samples": samples,
                "events": events,
                "sample_cursor": int(runtime.sample_version),
                "event_cursor": int(runtime.event_version),
                "sample_latest_version": int(runtime.sample_version),
                "event_latest_version": int(runtime.event_version),
            }

    def set_event_retention(self, insight_id: str, enabled: bool) -> dict[str, Any]:
        runtime = self._runtime(insight_id)
        with runtime._lock:
            runtime._retain_events = bool(enabled)
        return {
            "id": str(insight_id), "retain_events": bool(enabled),
            "event_version": int(runtime.event_version),
        }

    def metrics(self) -> list[dict]:
        return [runtime.metrics() for runtime in self.runtimes.values()] + [
            {
                "id": item["protocol_insight_id"], "name": "Invalid Protocol Insight",
                "enabled": False, "paused": False, "samples": 0,
                "sample_version": 0, "dropped_samples": 0,
                "paused_by_retention": False, "collection_mode": "",
                "export_running": False, "last_error": item["error"], "error_count": 1,
            }
            for item in self.errors
        ]

    def close(self):
        for runtime in self.runtimes.values():
            runtime.close(final_outputs=True)

    def _runtime(self, insight_id: str) -> ProtocolInsightRuntime:
        runtime = self.runtimes.get(str(insight_id))
        if runtime is None:
            raise KeyError(f"Protocol Insight '{insight_id}' is not active in this session")
        return runtime
