from __future__ import annotations

import copy
import json
import uuid
from dataclasses import dataclass

from PyQt5 import QtCore, QtGui, QtWidgets


VISUALIZATION_COLORS = [
    "#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9",
]
PLOT_STYLES = ("line", "step", "scatter", "state")


class ColorSelectionWidget(QtWidgets.QWidget):
    """Validated editable color value with a native QColorDialog swatch."""

    colorChanged = QtCore.pyqtSignal(str)

    def __init__(self, color=VISUALIZATION_COLORS[0], parent=None):
        super().__init__(parent)
        self._current_color = VISUALIZATION_COLORS[0]
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(4)
        self.value = QtWidgets.QLineEdit()
        self.value.setPlaceholderText("#RRGGBB or named color")
        self.value.setMaximumWidth(105)
        self.choose = QtWidgets.QPushButton("Choose...")
        self.choose.setMaximumWidth(78)
        self.choose.setToolTip("Choose any color using the system color dialog.")
        layout.addWidget(self.value, 1); layout.addWidget(self.choose)
        self.value.editingFinished.connect(self._text_accepted)
        self.choose.clicked.connect(self._choose_color)
        self.setColor(color)

    def color(self):
        return self._current_color

    def setColor(self, color):
        candidate = str(color or VISUALIZATION_COLORS[0])
        if not QtGui.QColor(candidate).isValid():
            candidate = VISUALIZATION_COLORS[0]
        self._current_color = candidate
        blocked = self.value.blockSignals(True)
        self.value.setText(candidate)
        self.value.blockSignals(blocked)
        self._update_swatch(candidate)

    def _update_swatch(self, color):
        qcolor = QtGui.QColor(color)
        foreground = "#000000" if qcolor.lightness() > 135 else "#FFFFFF"
        self.choose.setStyleSheet(
            f"QPushButton {{ background: {qcolor.name()}; color: {foreground}; }}"
        )

    def _text_accepted(self):
        candidate = self.value.text().strip()
        if not QtGui.QColor(candidate).isValid():
            QtWidgets.QApplication.beep()
            self.setColor(self._current_color)
            return
        self._current_color = candidate
        self._update_swatch(candidate)
        self.colorChanged.emit(candidate)

    def _choose_color(self):
        selected = QtWidgets.QColorDialog.getColor(
            QtGui.QColor(self.color()), self, "Select plot color",
            QtWidgets.QColorDialog.ShowAlphaChannel,
        )
        if not selected.isValid():
            return
        value = selected.name(QtGui.QColor.HexArgb) if selected.alpha() < 255 else selected.name()
        self.setColor(value)
        self.colorChanged.emit(value)


@dataclass(frozen=True)
class VisualizationCapabilities:
    event_lanes: bool = False
    series_filters: bool = False
    processors: bool = False
    thresholds: bool = False
    nested_binary: bool = False


PROTOCOL_INSIGHT_CAPABILITIES = VisualizationCapabilities(
    event_lanes=True, series_filters=True, processors=True,
    thresholds=True, nested_binary=True,
)
def default_insight_dataset_configuration() -> dict:
    return {
        "id": str(uuid.uuid4()),
        "enabled": False,
        "runtime": {"active": False, "paused": False},
        "threshold_details": False,
        "sampling": {
            "emit_final_on_stop": True,
        },
        "retention": {
            "maximum_samples": 100_000, "maximum_age_seconds": 0,
            "policy": "drop_oldest",
        },
        "checkpoint": {
            "enabled": False,
            "directory": "app/data/communication_hub/protocol_insights/checkpoints",
            "interval_seconds": 30, "restore_on_start": True,
            "save_on_stop": True,
        },
        "excel": {
            "enabled": False, "directory": "app/data/communication_hub/protocol_insights/output",
            "periodic_enabled": False, "period_seconds": 60,
            "periodic_mode": "rotating_snapshot", "layout": "wide_aligned",
            "keep_files": 20, "write_final_on_stop": True,
            "include_configuration": True,
            "append_path": "", "append_conflict": "reject",
            "schema_policy": "strict", "backup_before_rewrite": True,
        },
    }


class InsightDatasetSettingsEditor(QtWidgets.QGroupBox):
    """Retention, recovery, Excel-output, and runtime settings workspace."""

    configurationChanged = QtCore.pyqtSignal(object)
    actionRequested = QtCore.pyqtSignal(str)
    seriesExportChanged = QtCore.pyqtSignal(str, bool)

    def __init__(self, parent=None):
        super().__init__("Insight dataset", parent)
        self.setCheckable(False)
        self.setToolTip(
            "Configure the shared processed dataset used by live plots and optional Excel output. Use Start explicitly when it is ready."
        )
        self._loading = False
        self._config = default_insight_dataset_configuration()
        self._widgets = {}
        self._setting_rows = {}
        self._group_widgets = {}
        root = QtWidgets.QVBoxLayout(self)
        header = QtWidgets.QHBoxLayout(); root.addLayout(header)
        self.dataset_enabled = QtWidgets.QCheckBox("Enable the live insight dataset")
        self.dataset_enabled.setToolTip("Enable the shared processed dataset used by plots and Excel. Use Start explicitly when the configuration is ready.")
        self.expand_button = QtWidgets.QToolButton(); self.expand_button.setCheckable(True)
        self.expand_button.setText("Show settings"); self.expand_button.setArrowType(QtCore.Qt.RightArrow)
        self.expand_button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.expand_button.setToolTip("Show or hide dataset, recovery, and Excel settings without stopping a running insight.")
        self.compact_state = QtWidgets.QLabel("Dataset disabled"); self.compact_state.setStyleSheet("color: palette(mid);")
        header.addWidget(self.dataset_enabled); header.addStretch(1); header.addWidget(self.compact_state); header.addWidget(self.expand_button)
        guidance = QtWidgets.QLabel(
            "Excel Output is a projection of the shared insight dataset. Select workbook columns here without changing collection, retention, or plotted series."
        )
        guidance.setWordWrap(True); guidance.setStyleSheet("color: palette(mid);")
        root.addWidget(guidance)
        self.pipeline_summary = QtWidgets.QLabel("Uses the configured Source, Collection, and complete Series pipeline.")
        self.pipeline_summary.setWordWrap(True); self.pipeline_summary.setStyleSheet("font-weight: 600; color: #174EA6; padding: 3px;")
        self.pipeline_summary.setToolTip("Effective upstream data selection used by the shared insight dataset. Excel settings do not select sessions or create another source.")
        root.addWidget(self.pipeline_summary)
        self.tabs = QtWidgets.QTabWidget(); self.tabs.setMinimumHeight(300)
        self.tabs.setToolTip("Choose the Excel projection and workbook settings. Dataset collection, retention, and recovery are owned by Source and Collection.")
        root.addWidget(self.tabs, 1)
        self._build_rows()
        self.footer_widget = QtWidgets.QWidget(); footer = QtWidgets.QHBoxLayout(self.footer_widget); footer.setContentsMargins(0, 0, 0, 0); root.addWidget(self.footer_widget)
        self.runtime_state = QtWidgets.QLabel("Insight dataset disabled")
        self.runtime_state.setStyleSheet("font-weight: 600; color: palette(mid);")
        footer.addWidget(self.runtime_state, 1)
        actions = (
            ("start", "Start", QtWidgets.QStyle.SP_MediaPlay, "Start this Protocol Insight on its selected sessions and collect incoming values."),
            ("pause", "Pause", QtWidgets.QStyle.SP_MediaPause, "Pause sample collection while retaining samples, stream identity, and sampling state."),
            ("resume", "Resume", QtWidgets.QStyle.SP_MediaPlay, "Resume a paused Protocol Insight without clearing retained state."),
            ("stop", "Stop", QtWidgets.QStyle.SP_MediaStop, "Stop this Protocol Insight after pending final output and checkpoints complete."),
        )
        self.action_buttons = {}
        for action, text_value, icon, tooltip in actions:
            button = QtWidgets.QToolButton(); button.setText(text_value)
            button.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
            button.setToolTip(tooltip)
            button.setAccessibleName(f"{text_value} Protocol Insight")
            button.clicked.connect(lambda _checked=False, value=action: self.actionRequested.emit(value))
            footer.addWidget(button); self.action_buttons[action] = button
        self.action_buttons["validate"] = self.validate_workbook_button
        self.validate_workbook_button.clicked.connect(
            lambda: self.actionRequested.emit("validate")
        )
        self.dataset_enabled.toggled.connect(self._enabled_changed)
        self.expand_button.toggled.connect(self._expanded_changed)
        self._detail_widgets = [guidance, self.tabs, self.footer_widget]
        self._expanded_changed(False)
        self._update_action_state("disabled")

    def _page(self, title, introduction):
        page = QtWidgets.QWidget(); layout = QtWidgets.QVBoxLayout(page)
        note = QtWidgets.QLabel(introduction); note.setWordWrap(True); note.setStyleSheet("color: palette(mid);")
        layout.addWidget(note); self.tabs.addTab(page, title)
        return layout

    def _group(self, key, title, parent_layout):
        group = QtWidgets.QGroupBox(title); layout = QtWidgets.QVBoxLayout(group)
        parent_layout.addWidget(group); self._group_widgets[key] = group
        return layout

    def _row(self, area, setting, widget, guidance):
        container = QtWidgets.QWidget(); row = QtWidgets.QHBoxLayout(container); row.setContentsMargins(0, 0, 0, 0)
        label = QtWidgets.QLabel(setting); label.setMinimumWidth(155); label.setToolTip(guidance)
        explanation = QtWidgets.QLabel(guidance); explanation.setWordWrap(True); explanation.setStyleSheet("color: palette(mid);")
        row.addWidget(label); row.addWidget(widget, 1); row.addWidget(explanation, 2)
        self._group_layouts[area].addWidget(container)
        widget.setToolTip(guidance); self._widgets[setting] = widget
        self._setting_rows[setting] = container
        signal = (
            widget.toggled if isinstance(widget, QtWidgets.QCheckBox)
            else widget.textChanged if isinstance(widget, QtWidgets.QLineEdit)
            else widget.valueChanged if isinstance(widget, (QtWidgets.QSpinBox, QtWidgets.QDoubleSpinBox))
            else widget.currentIndexChanged
        )
        signal.connect(self._changed)

    def _build_rows(self):
        self._group_layouts = {}
        series_page = self._page("Series to export", "Choose which values from the shared insight dataset are written to Excel. This does not change collection, retention, or plots.")
        self._group_layouts["Series"] = self._group("Series", "Excel series", series_page)
        self.export_series_table = QtWidgets.QTableWidget(0, 3); self.export_series_table.setHorizontalHeaderLabels(["Export", "Series", "Source"])
        self.export_series_table.verticalHeader().setVisible(False); self.export_series_table.setAlternatingRowColors(True); self.export_series_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.export_series_table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents); self.export_series_table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch); self.export_series_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.export_series_table.setToolTip("Check each shared insight series that should be included in Excel workbooks. Plotting is controlled separately in Display settings.")
        self._group_layouts["Series"].addWidget(self.export_series_table)
        self.export_series_empty = QtWidgets.QLabel("No configured series. Add series in Series selection and processing first."); self.export_series_empty.setStyleSheet("color: palette(mid);")
        self._group_layouts["Series"].addWidget(self.export_series_empty)
        self.export_series_table.itemChanged.connect(self._export_series_item_changed)

        retention_page = self._page("Retention", "Bound the shared processed dataset kept in memory.")
        self._group_layouts["Retention"] = self._group("Retention", "In-memory retention", retention_page)
        retention_page.addStretch(1)

        recovery_page = self._page("Recovery", "Checkpoints preserve the shared retained dataset and sampling state for automatic restart recovery and stopped-insight Excel export.")
        self._group_layouts["Stop behavior"] = self._group("Stop behavior", "Orderly stop behavior", recovery_page)
        self._group_layouts["Recovery control"] = self._group("Recovery control", "Checkpoint recovery", recovery_page)
        self._group_layouts["Recovery details"] = self._group("Recovery details", "Checkpoint details", recovery_page)
        recovery_page.addStretch(1)

        output_page = self._page("Excel output", "Write selected columns only when Create Final Excel is requested or during an orderly insight/application stop. A stopped insight can export its last checkpoint.")
        self._group_layouts["Output control"] = self._group("Output control", "Excel output", output_page)
        self._group_layouts["Workbook columns"] = self._group("Workbook columns", "Workbook columns and audit details", output_page)
        self._group_layouts["Output destination"] = self._group("Output destination", "Workbook destination and format", output_page)
        self._group_layouts["Append"] = self._group("Append", "Append existing workbook", output_page)
        output_page.addStretch(1)

        emit_final = QtWidgets.QCheckBox("Flush pending latest values on stop")
        self._row("Stop behavior", "Final interval sample", emit_final, "When Source and Collection uses Latest value in each interval, flush its newest pending value during an orderly stop.")
        maximum = QtWidgets.QSpinBox(); maximum.setRange(0, 100_000_000); maximum.setSpecialValueText("Unlimited")
        self._row("Retention", "Maximum samples", maximum, "Bound memory for a long-running insight. Unlimited is appropriate only for short controlled sessions.")
        age = QtWidgets.QSpinBox(); age.setRange(0, 315_360_000); age.setSuffix(" s"); age.setSpecialValueText("Unlimited")
        self._row("Retention", "Maximum age", age, "Use a rolling age window when operational dashboards only require recent history.")
        policy = QtWidgets.QComboBox(); policy.addItem("Discard oldest", "drop_oldest"); policy.addItem("Discard new", "drop_newest"); policy.addItem("Pause when full", "pause")
        self._row("Retention", "When full", policy, "Discard oldest maintains a rolling dashboard; Pause is safest when losing any insight sample is unacceptable.")
        threshold_details = QtWidgets.QCheckBox("Add status and threshold-detail columns")
        self._row("Workbook columns", "Threshold details", threshold_details, "Add explicit missing, above-maximum, and below-minimum audit columns to Excel output.")
        checkpoint = QtWidgets.QCheckBox("Persist samples and sampling state")
        self._row("Recovery control", "Checkpoint", checkpoint, "Enable automatic restart recovery and checkpoint-backed Excel export after an unexpected shutdown.")
        checkpoint_directory = QtWidgets.QLineEdit()
        self._row("Recovery details", "Checkpoint folder", checkpoint_directory, "Project-relative or absolute folder for atomic recovery checkpoints.")
        checkpoint_interval = QtWidgets.QSpinBox(); checkpoint_interval.setRange(1, 86_400); checkpoint_interval.setSuffix(" s")
        self._row("Recovery details", "Checkpoint interval", checkpoint_interval, "Shorter intervals reduce recovery loss but increase local disk activity.")
        checkpoint_on_stop = QtWidgets.QCheckBox("Write a final checkpoint on stop")
        self._row("Recovery details", "Checkpoint on stop", checkpoint_on_stop, "Preserve the final retained samples and change-detection state during orderly shutdown.")
        output = QtWidgets.QCheckBox("Enable Excel output for this insight")
        self._row("Output control", "Excel", output, "Optional. Enable only when the shared insight dataset must be written on request or on stop.")
        output_directory = QtWidgets.QLineEdit()
        self._row("Output destination", "Output folder", output_directory, "Project-relative or absolute folder used for new, rotating, latest, and final workbooks.")
        output_mode = QtWidgets.QComboBox(); output_mode.addItem("Create a timestamped final workbook", "rotating_snapshot"); output_mode.addItem("Append formatted workbook", "append_formatted")
        self._row("Output destination", "Workbook strategy", output_mode, "Create a new timestamped final workbook, or merge recovered/final samples into a selected formatted workbook.")
        include_config = QtWidgets.QCheckBox("Include workspace configuration")
        self._row("Output destination", "Include configuration", include_config, "Include configuration JSON when auditability or later reconstruction is important.")
        append_path = QtWidgets.QLineEdit(); append_path.setPlaceholderText("Existing .xlsx workbook")
        self._row("Append", "Workbook", append_path, "Required only for Append formatted workbook; validate compatibility before unattended use.")
        self.validate_workbook_button = QtWidgets.QPushButton("Validate workbook")
        self.validate_workbook_button.setToolTip(
            "Inspect this workbook for Protocol Insight identity, schema, series, and timeline compatibility without changing it."
        )
        self._setting_rows["Workbook"].layout().insertWidget(2, self.validate_workbook_button)
        overlap = QtWidgets.QComboBox(); overlap.addItem("Reject overlap", "reject"); overlap.addItem("Skip existing", "skip"); overlap.addItem("Replace matching", "replace"); overlap.addItem("Keep both", "keep_both")
        self._row("Append", "Overlap policy", overlap, "Controls samples with the same stream identity and timestamp during formatted workbook append.")
        schema = QtWidgets.QComboBox(); schema.addItem("Strict monitor and series match", "strict"); schema.addItem("Compatible existing series", "compatible"); schema.addItem("Extend with new series", "extend")
        self._row("Append", "Schema policy", schema, "Strict is safest; Extend is useful when the workspace intentionally gains new exported series.")
        backup = QtWidgets.QCheckBox("Back up workbook before rewrite")
        self._row("Append", "Safety backup", backup, "Keep enabled for recoverability before an append merge atomically rewrites the workbook.")
        self._group_widgets["Stop behavior"].hide()

    def set_export_series(self, series_rows):
        rows = list(series_rows or [])
        self.export_series_table.blockSignals(True); self.export_series_table.setRowCount(0)
        for value in rows:
            row = self.export_series_table.rowCount(); self.export_series_table.insertRow(row)
            output = QtWidgets.QTableWidgetItem(); output.setFlags(output.flags() | QtCore.Qt.ItemIsUserCheckable); output.setCheckState(QtCore.Qt.Checked if value.get("export_enabled", True) else QtCore.Qt.Unchecked); output.setData(QtCore.Qt.UserRole, str(value.get("id", "")))
            name = QtWidgets.QTableWidgetItem(str(value.get("label", "Series"))); name.setFlags(name.flags() & ~QtCore.Qt.ItemIsEditable)
            source = QtWidgets.QTableWidgetItem(str(value.get("source_path", ""))); source.setFlags(source.flags() & ~QtCore.Qt.ItemIsEditable)
            for column, item in enumerate((output, name, source)): self.export_series_table.setItem(row, column, item)
        self.export_series_table.blockSignals(False)
        self.export_series_table.setVisible(bool(rows)); self.export_series_empty.setVisible(not rows)

    def _export_series_item_changed(self, item):
        if item.column() != 0: return
        self.seriesExportChanged.emit(str(item.data(QtCore.Qt.UserRole) or ""), item.checkState() == QtCore.Qt.Checked)

    def _set_setting_visible(self, name, visible):
        row = self._setting_rows.get(name)
        if row is not None: row.setVisible(bool(visible))

    def configuration(self):
        return copy.deepcopy(self._config)

    def set_configuration(self, config):
        defaults = default_insight_dataset_configuration(); source = copy.deepcopy(config) if isinstance(config, dict) else {}
        for key, value in source.items():
            if isinstance(value, dict) and isinstance(defaults.get(key), dict): defaults[key].update(value)
            else: defaults[key] = value
        self._config = defaults; self._loading = True
        try:
            self.dataset_enabled.setChecked(bool(defaults.get("enabled", False)))
            sampling = defaults["sampling"]; retention = defaults["retention"]
            checkpoint = defaults["checkpoint"]; excel = defaults["excel"]
            values = {
                "Threshold details": defaults.get("threshold_details", False),
                "Final interval sample": sampling.get("emit_final_on_stop", True),
                "Maximum samples": retention["maximum_samples"], "Maximum age": retention["maximum_age_seconds"], "When full": retention["policy"],
                "Checkpoint": checkpoint.get("enabled", False), "Checkpoint folder": checkpoint.get("directory", ""), "Checkpoint interval": checkpoint.get("interval_seconds", 30), "Checkpoint on stop": checkpoint.get("save_on_stop", True),
                "Excel": excel.get("enabled", False), "Output folder": excel.get("directory", ""), "Workbook strategy": excel.get("periodic_mode", "rotating_snapshot"), "Include configuration": excel.get("include_configuration", True), "Workbook": excel.get("append_path", ""), "Overlap policy": excel.get("append_conflict", "reject"), "Schema policy": excel.get("schema_policy", "strict"), "Safety backup": excel.get("backup_before_rewrite", True),
            }
            for name, value in values.items():
                widget = self._widgets[name]
                if isinstance(widget, QtWidgets.QComboBox): widget.setCurrentIndex(max(0, widget.findData(value)))
                elif isinstance(widget, QtWidgets.QCheckBox): widget.setChecked(bool(value))
                elif isinstance(widget, QtWidgets.QLineEdit): widget.setText(str(value))
                else: widget.setValue(value)
        finally: self._loading = False
        self._update_dependencies()
        self._enabled_changed(self.dataset_enabled.isChecked())

    def _enabled_changed(self, enabled):
        # Dataset lifecycle and Excel output are independent. Workbook settings
        # remain editable before the dataset is started and while it is stopped.
        self.tabs.setEnabled(True)
        self._update_dependencies()
        if not self._loading:
            self._config["enabled"] = bool(enabled); self.configurationChanged.emit(self.configuration())
        self._update_action_state("ready" if enabled else "disabled")

    def _expanded_changed(self, expanded):
        for widget in getattr(self, "_detail_widgets", []):
            widget.setVisible(bool(expanded))
        self.expand_button.setText("Hide settings" if expanded else "Show settings")
        self.expand_button.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.setMaximumHeight(720 if expanded else 64)

    def _changed(self, *_args):
        if self._loading: return
        c = self._config; sampling = c["sampling"]; retention = c["retention"]; checkpoint = c["checkpoint"]; excel = c["excel"]
        c["threshold_details"] = self._widgets["Threshold details"].isChecked()
        sampling["emit_final_on_stop"] = self._widgets["Final interval sample"].isChecked()
        retention.update({"maximum_samples": self._widgets["Maximum samples"].value(), "maximum_age_seconds": self._widgets["Maximum age"].value(), "policy": self._widgets["When full"].currentData()})
        checkpoint_enabled = self._widgets["Checkpoint"].isChecked()
        checkpoint.update({"enabled": checkpoint_enabled, "directory": self._widgets["Checkpoint folder"].text().strip(), "interval_seconds": self._widgets["Checkpoint interval"].value(), "restore_on_start": checkpoint_enabled, "save_on_stop": self._widgets["Checkpoint on stop"].isChecked()})
        excel.update({"enabled": self._widgets["Excel"].isChecked(), "directory": self._widgets["Output folder"].text().strip(), "periodic_enabled": False, "periodic_mode": self._widgets["Workbook strategy"].currentData(), "layout": "wide_aligned", "write_final_on_stop": True, "include_configuration": self._widgets["Include configuration"].isChecked(), "append_path": self._widgets["Workbook"].text().strip(), "append_conflict": self._widgets["Overlap policy"].currentData(), "schema_policy": self._widgets["Schema policy"].currentData(), "backup_before_rewrite": self._widgets["Safety backup"].isChecked()})
        self._update_dependencies()
        self._update_action_state(getattr(self, "_runtime_state_name", "ready"))
        self.configurationChanged.emit(self.configuration())

    def _update_dependencies(self):
        checkpoint_enabled = self._widgets["Checkpoint"].isChecked()
        self._group_widgets["Recovery details"].setVisible(checkpoint_enabled)
        excel_enabled = self._widgets["Excel"].isChecked()
        strategy = self._widgets["Workbook strategy"].currentData()
        append_enabled = excel_enabled and strategy == "append_formatted"
        self._group_widgets["Output destination"].setVisible(excel_enabled)
        self._group_widgets["Workbook columns"].setVisible(excel_enabled)
        self._group_widgets["Append"].setVisible(append_enabled)
        self._set_setting_visible("Output folder", excel_enabled and not append_enabled)
        self._set_setting_visible("Include configuration", False)
        if hasattr(self, "action_buttons"):
            self.action_buttons["validate"].setEnabled(append_enabled)

    def _update_action_state(self, state, detail=""):
        self._runtime_state_name = str(state)
        labels = {"disabled": "Insight dataset disabled", "ready": "Ready to start", "configured": "Insight dataset configured", "stopped": "Insight dataset stopped", "stale": "Dataset changes pending", "starting": "Starting insight dataset...", "stopping": "Stopping insight dataset...", "running": "Insight dataset running", "paused": "Insight dataset paused", "error": "Insight dataset error"}
        state_text = labels.get(state, state) + (f" - {detail}" if detail else "")
        self.runtime_state.setText(state_text)
        self.compact_state.setText(state_text)
        for button in self.action_buttons.values(): button.setEnabled(True)
        self.action_buttons["start"].setEnabled(state not in {"starting", "running", "paused"})
        self.action_buttons["pause"].setEnabled(state == "running")
        self.action_buttons["resume"].setEnabled(state == "paused")
        self.action_buttons["stop"].setEnabled(state in {"stale", "running", "paused", "starting", "error"})
        self.action_buttons["validate"].setEnabled(self._widgets["Excel"].isChecked() and self._widgets["Workbook strategy"].currentData() == "append_formatted")

    def set_runtime_state(self, state, detail=""):
        self._update_action_state(state, detail)

    def set_collection_runtime_state(self, *, active: bool, paused: bool = False):
        """Keep non-editable lifecycle state when settings emit configuration."""
        self._config.setdefault("runtime", {}).update({
            "active": bool(active),
            "paused": bool(paused) if active else False,
        })

    def set_pipeline_context(self, source, export_series_count):
        source = source if isinstance(source, dict) else {}
        collection = source.get("collection", {}) if isinstance(source.get("collection"), dict) else {}
        scope = {"current": "current session", "selected": f"{len(source.get('session_ids', []))} selected session(s)", "all": "all available sessions"}.get(source.get("scope"), "current session")
        if collection.get("mode") == "scheduled":
            policy = f"scheduled every {float(collection.get('interval_seconds', 1)):g}s"
        else:
            policy = "on eligible message arrival"
        raw_sampling_mode = str(collection.get("default_policy", "all"))
        sampling_mode = raw_sampling_mode.replace("_", " ")
        self._group_widgets["Stop behavior"].setVisible(collection.get("mode") == "scheduled")
        self.pipeline_summary.setText(
            f"{scope} · {policy} · default {sampling_mode} · "
            f"{int(export_series_count)} Excel series"
        )
        self.pipeline_summary.setStyleSheet("font-weight: 600; color: #174EA6; padding: 3px;")
        self.pipeline_summary.setToolTip("The unified Insight dataset feeds display, recovery, and Excel. Series may override the default collection policy.")


def new_subplot(title: str = "New Subplot", *, kind: str = "plot") -> dict:
    return {
        "id": str(uuid.uuid4()),
        "title": title,
        "unit": "",
        "kind": kind,
        "series": [],
    }


def new_series(label: str = "New Series") -> dict:
    return {
        "id": str(uuid.uuid4()),
        "label": label,
        "enabled": True,
        "plot_enabled": True,
        "visible": True,
        "export_enabled": True,
        "session_id": "",
        "message_names": [],
        "direction": "any",
        "source": {"kind": "parsed_field", "path": "data.Value"},
        "plot": {"type": "line", "color": VISUALIZATION_COLORS[0]},
        "transform": {"scale": 1.0, "offset": 0.0},
        "processor": {"enabled": False, "module": "", "function": "", "options": {}},
        "thresholds": {},
    }


def normalize_visualization(value: dict | None) -> dict:
    """Normalize the common subplot/series document used by both tools."""
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    result = {"subplots": []}
    for subplot_index, raw_subplot in enumerate(source.get("subplots", [])):
        if not isinstance(raw_subplot, dict):
            continue
        kind = "timeline" if raw_subplot.get("kind") == "timeline" else "plot"
        subplot = new_subplot(
            str(raw_subplot.get("title") or f"Subplot {subplot_index + 1}"), kind=kind,
        )
        subplot.update(copy.deepcopy(raw_subplot))
        subplot["id"] = str(subplot.get("id") or uuid.uuid4())
        subplot["title"] = str(subplot.get("title") or f"Subplot {subplot_index + 1}")
        subplot["unit"] = str(subplot.get("unit") or "")
        subplot["kind"] = kind
        subplot["series"] = []
        for series_index, raw_series in enumerate(raw_subplot.get("series", [])):
            if not isinstance(raw_series, dict):
                continue
            series = new_series(
                str(raw_series.get("label") or raw_series.get("name") or f"Series {series_index + 1}")
            )
            series.update(copy.deepcopy(raw_series))
            series["id"] = str(series.get("id") or uuid.uuid4())
            series["label"] = str(series.get("label") or series.get("name") or f"Series {series_index + 1}")
            series.pop("name", None)
            series["enabled"] = bool(series.get("enabled", True))
            series["plot_enabled"] = bool(series.get("plot_enabled", True))
            series["visible"] = bool(series.get("visible", series["plot_enabled"]))
            series["export_enabled"] = bool(series.get("export_enabled", True))
            series["session_id"] = str(series.get("session_id") or "")
            names = series.get("message_names", [])
            if isinstance(names, str):
                names = [item.strip() for item in names.split(",") if item.strip()]
            series["message_names"] = [str(item) for item in names]
            if series.get("direction") not in {"any", "RX", "TX"}:
                series["direction"] = "any"
            source_config = series.get("source")
            if not isinstance(source_config, dict):
                source_config = series.get("extractor", {})
            series["source"] = copy.deepcopy(source_config)
            series.pop("extractor", None)
            plot = series.get("plot") if isinstance(series.get("plot"), dict) else {}
            style = str(plot.get("type", series.get("style", "line")))
            if style not in PLOT_STYLES:
                style = "line"
            series["plot"] = {
                "type": style,
                "color": str(plot.get("color") or series.get("color") or VISUALIZATION_COLORS[series_index % len(VISUALIZATION_COLORS)]),
            }
            series.pop("style", None); series.pop("color", None)
            subplot["series"].append(series)
        result["subplots"].append(subplot)
    return result


class CommonVisualizationEditor(QtWidgets.QWidget):
    """Inline subplot and series editor for Protocol Insights."""

    configurationChanged = QtCore.pyqtSignal(object)
    advancedSeriesRequested = QtCore.pyqtSignal(str)

    def __init__(self, capabilities: VisualizationCapabilities, sessions=None, parent=None, *, presentation_only=False):
        super().__init__(parent)
        self.capabilities = capabilities
        self.sessions = list(sessions or [])
        self.presentation_only = bool(presentation_only)
        self._document = normalize_visualization(None)
        self._loading = False
        self._build_ui()

    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0)
        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal); root.addWidget(splitter)
        structure = QtWidgets.QWidget(); structure_layout = QtWidgets.QVBoxLayout(structure)
        structure_layout.setContentsMargins(0, 0, 0, 0)
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["Subplot / Series", "Source", "Style"])
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.hide()
        subplot_label = QtWidgets.QLabel("Subplots")
        subplot_label.setStyleSheet("font-weight: 600;")
        structure_layout.addWidget(subplot_label)
        self.subplot_table = QtWidgets.QTableWidget(0, 4)
        self.subplot_table.setHorizontalHeaderLabels(["Type", "Title", "Unit", "Series"])
        self.subplot_table.setAlternatingRowColors(True); self.subplot_table.verticalHeader().setVisible(False)
        self.subplot_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.subplot_table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.subplot_table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.subplot_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        self.subplot_table.horizontalHeader().setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        self.subplot_table.setToolTip("Edit subplot titles and units directly. Select a row to configure its type and event-lane details in the inspector.")
        structure_layout.addWidget(self.subplot_table, 1)
        subplot_actions = QtWidgets.QHBoxLayout(); structure_layout.addLayout(subplot_actions)
        self.add_subplot_button = QtWidgets.QToolButton(); self.add_subplot_button.setText("New subplot")
        self.delete_subplot_button = QtWidgets.QToolButton(); self.delete_subplot_button.setText("Delete subplot")
        self.move_subplot_up_button = QtWidgets.QToolButton(); self.move_subplot_up_button.setText("Move subplot up")
        self.move_subplot_down_button = QtWidgets.QToolButton(); self.move_subplot_down_button.setText("Move subplot down")
        for button, tooltip in (
            (self.add_subplot_button, "Add a data subplot. Change its Type in Show details to create an event lane."),
            (self.delete_subplot_button, "Delete only the selected subplot and the plotted series assigned to it."),
            (self.move_subplot_up_button, "Move the selected subplot one position earlier in the display."),
            (self.move_subplot_down_button, "Move the selected subplot one position later in the display."),
        ):
            button.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
            button.setToolTip(tooltip); button.setCursor(QtCore.Qt.PointingHandCursor)
            subplot_actions.addWidget(button)
        subplot_actions.addStretch(1)
        series_label = QtWidgets.QLabel("Series")
        series_label.setStyleSheet("font-weight: 600;")
        structure_layout.addWidget(series_label)
        self.series_table = QtWidgets.QTableWidget(0, 8)
        self.series_table.setHorizontalHeaderLabels(["Show", "Export", "Label", "Subplot", "Source", "Path / Field", "Style", "Color"])
        self.series_table.setAlternatingRowColors(True); self.series_table.verticalHeader().setVisible(False)
        self.series_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.series_table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.series_table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.series_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.series_table.horizontalHeader().setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        self.series_table.horizontalHeader().setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeToContents)
        self.series_table.horizontalHeader().setSectionResizeMode(5, QtWidgets.QHeaderView.Stretch)
        self.series_table.horizontalHeader().setSectionResizeMode(6, QtWidgets.QHeaderView.ResizeToContents)
        self.series_table.horizontalHeader().setSectionResizeMode(7, QtWidgets.QHeaderView.ResizeToContents)
        self.series_table.setToolTip("Edit common series settings directly. Select a row for filters, byte decoding, transforms, thresholds, and processors.")
        if self.presentation_only:
            self.series_table.setHorizontalHeaderLabels(["Plot", "Visible", "Series", "Subplot", "Source", "Path / Field", "Style", "Color"])
            self.series_table.setToolTip("Configure all plot presentation for series defined in Series selection and processing. Plot controls membership; Visible temporarily hides a plotted series.")
            for column in (4, 5): self.series_table.setColumnHidden(column, True)
        structure_layout.addWidget(self.series_table, 2)
        series_actions = QtWidgets.QHBoxLayout(); structure_layout.addLayout(series_actions)
        self.add_series_button = QtWidgets.QToolButton(); self.add_series_button.setText("New series")
        self.delete_series_button = QtWidgets.QToolButton()
        self.delete_series_button.setText("Stop plotting selected" if self.presentation_only else "Delete series")
        self.move_series_up_button = QtWidgets.QToolButton(); self.move_series_up_button.setText("Move series up")
        self.move_series_down_button = QtWidgets.QToolButton(); self.move_series_down_button.setText("Move series down")
        self.one_per_series_button = QtWidgets.QToolButton(); self.one_per_series_button.setText("Split plots")
        self.details_button = QtWidgets.QToolButton(); self.details_button.setText("Show details"); self.details_button.setCheckable(True)
        self.advanced_series_button = QtWidgets.QToolButton(); self.advanced_series_button.setText("Advanced...")
        self.advanced_series_button.setVisible(
            not self.presentation_only and (self.capabilities.series_filters or self.capabilities.processors)
        )
        if self.presentation_only: self.add_series_button.hide()
        action_specs = (
            (self.add_series_button, QtWidgets.QStyle.SP_FileIcon, "Add a value series to the selected data subplot, then edit its source directly in the table."),
            (self.delete_series_button, QtWidgets.QStyle.SP_TrashIcon, "Stop plotting the selected series without deleting it from the shared insight dataset." if self.presentation_only else "Delete only the selected series."),
            (self.move_series_up_button, QtWidgets.QStyle.SP_ArrowUp, "Move the selected series one position earlier within its subplot."),
            (self.move_series_down_button, QtWidgets.QStyle.SP_ArrowDown, "Move the selected series one position later within its subplot."),
            (self.one_per_series_button, QtWidgets.QStyle.SP_FileDialogListView, "Create one subplot per series when different value ranges need independent axes."),
            (self.details_button, QtWidgets.QStyle.SP_DesktopIcon, "Show the optional inline details inspector for the selected row. Keep it hidden when table editing is sufficient."),
            (self.advanced_series_button, QtWidgets.QStyle.SP_FileDialogDetailedView, "Configure the selected series query and processor with guided advanced editors."),
        )
        for button, icon, tooltip in action_specs:
            button.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly if self.presentation_only else QtCore.Qt.ToolButtonTextBesideIcon)
            if not self.presentation_only: button.setIcon(self.style().standardIcon(icon))
            button.setToolTip(tooltip)
            button.setCursor(QtCore.Qt.PointingHandCursor); series_actions.addWidget(button)
        series_actions.addStretch(1)
        # Compatibility aliases for integrations that inspected the old
        # selection-dependent action row. They now point to series actions.
        self.remove_button = self.delete_series_button
        self.move_up_button = self.move_series_up_button
        self.move_down_button = self.move_series_down_button
        splitter.addWidget(structure)

        self.inspector = QtWidgets.QScrollArea(); self.inspector.setWidgetResizable(True)
        inspector_page = QtWidgets.QWidget(); self.inspector_layout = QtWidgets.QFormLayout(inspector_page)
        self.inspector.setWidget(inspector_page); splitter.addWidget(self.inspector)
        self.inspector.hide()
        splitter.setStretchFactor(0, 1); splitter.setStretchFactor(1, 2)
        splitter.setSizes([360, 680])

        self.empty_note = QtWidgets.QLabel("Select a subplot or series to configure it.")
        self.empty_note.setWordWrap(True); self.inspector_layout.addRow(self.empty_note)
        self.subplot_title = QtWidgets.QLineEdit(); self.subplot_unit = QtWidgets.QLineEdit()
        self.subplot_kind = QtWidgets.QComboBox(); self.subplot_kind.addItem("Data plot", "plot")
        if self.capabilities.event_lanes:
            self.subplot_kind.addItem("Event-lane plot", "timeline")
        self.timeline_session = QtWidgets.QComboBox(); self.timeline_session.addItem("All sessions", "")
        for session in self.sessions:
            self.timeline_session.addItem(str(session.get("name", "Unnamed")), str(session.get("id", "")))
        self.timeline_names = QtWidgets.QLineEdit(); self.timeline_names.setPlaceholderText("All events, or message wildcards")
        self.timeline_direction = QtWidgets.QComboBox()
        for label, value in (("RX and TX", "any"), ("Received only", "RX"), ("Sent only", "TX")):
            self.timeline_direction.addItem(label, value)
        self.timeline_lane_by = QtWidgets.QComboBox()
        for label, value in (
            ("Session, direction, and message", "session_direction_name"),
            ("Session and message", "session_name"),
            ("Direction and message", "direction_name"), ("Message name", "name"),
        ):
            self.timeline_lane_by.addItem(label, value)
        self.series_enabled = QtWidgets.QCheckBox("Visible")
        self.series_export = QtWidgets.QCheckBox("Include in Excel output")
        self.series_label = QtWidgets.QLineEdit()
        self.series_subplot = QtWidgets.QComboBox()
        self.series_session = QtWidgets.QComboBox(); self.series_session.addItem("All sessions", "")
        for session in self.sessions:
            self.series_session.addItem(str(session.get("name", "Unnamed")), str(session.get("id", "")))
        self.series_names = QtWidgets.QLineEdit(); self.series_names.setPlaceholderText("Message names or wildcards, comma separated")
        self.series_direction = QtWidgets.QComboBox()
        for label, value in (("RX and TX", "any"), ("Received only", "RX"), ("Sent only", "TX")):
            self.series_direction.addItem(label, value)
        self.source_kind = QtWidgets.QComboBox()
        source_types = [("Parsed data field", "parsed_field")]
        if self.capabilities.nested_binary:
            source_types.append(("Nested binary field", "binary_field"))
        source_types.extend((("Decoded header field", "header_field"), ("Raw byte range", "raw_bytes"), ("Message metadata", "metadata")))
        for label, value in source_types:
            self.source_kind.addItem(label, value)
        self.source_path = QtWidgets.QLineEdit(); self.source_field = QtWidgets.QLineEdit()
        self.source_offset = QtWidgets.QSpinBox(); self.source_offset.setRange(-10_000_000, 10_000_000)
        self.source_length = QtWidgets.QSpinBox(); self.source_length.setRange(1, 1_000_000)
        self.source_type = QtWidgets.QComboBox(); self.source_type.addItems(["uint", "int", "float32", "float64", "text", "hex", "bytes"])
        self.source_endian = QtWidgets.QComboBox(); self.source_endian.addItems(["little", "big"])
        self.source_signed = QtWidgets.QCheckBox("Interpret integer as signed")
        self.source_encoding = QtWidgets.QComboBox(); self.source_encoding.setEditable(True)
        self.source_encoding.addItems(["utf-8", "ascii", "latin-1", "utf-16-le", "utf-16-be"])
        self.plot_style = QtWidgets.QComboBox(); self.plot_style.addItems(list(PLOT_STYLES))
        self.plot_color = ColorSelectionWidget(VISUALIZATION_COLORS[0])
        self.scale = QtWidgets.QDoubleSpinBox(); self.scale.setRange(-1e12, 1e12); self.scale.setDecimals(9)
        self.value_offset = QtWidgets.QDoubleSpinBox(); self.value_offset.setRange(-1e12, 1e12); self.value_offset.setDecimals(9)
        self.minimum = QtWidgets.QLineEdit(); self.maximum = QtWidgets.QLineEdit()
        self.equal = QtWidgets.QLineEdit(); self.not_equal = QtWidgets.QLineEdit()
        self.processor = QtWidgets.QPlainTextEdit(); self.processor.setMaximumHeight(120)
        self.processor.setPlaceholderText("Processor JSON")

        self._subplot_rows = [
            ("Type", self.subplot_kind), ("Title", self.subplot_title), ("Y-axis unit", self.subplot_unit),
            ("Timeline session", self.timeline_session), ("Timeline messages", self.timeline_names),
            ("Timeline direction", self.timeline_direction), ("Event lanes", self.timeline_lane_by),
        ]
        self._series_rows = [
            ("Visible", self.series_enabled), ("Excel output", self.series_export), ("Series label", self.series_label),
            ("Subplot", self.series_subplot), ("Session", self.series_session),
            ("Message names", self.series_names), ("Direction", self.series_direction),
            ("Value source", self.source_kind), ("Field path", self.source_path),
            ("Metadata field", self.source_field), ("Byte offset", self.source_offset),
            ("Byte length", self.source_length), ("Data type", self.source_type),
            ("Endianness", self.source_endian), ("Signed", self.source_signed),
            ("Text encoding", self.source_encoding), ("Plot style", self.plot_style),
            ("Color", self.plot_color), ("Numeric scale", self.scale),
            ("Numeric offset", self.value_offset), ("Value processor", self.processor), ("Minimum", self.minimum),
            ("Maximum", self.maximum), ("Equal", self.equal), ("Not equal", self.not_equal),
        ]
        for label, widget in self._subplot_rows + self._series_rows:
            self.inspector_layout.addRow(label, widget); widget.hide()
            field_label = self.inspector_layout.labelForField(widget)
            if field_label: field_label.hide()

        self.tree.currentItemChanged.connect(self._selection_changed)
        self.subplot_table.itemSelectionChanged.connect(self._subplot_table_selected)
        self.series_table.itemSelectionChanged.connect(self._series_table_selected)
        self.subplot_table.itemChanged.connect(self._subplot_table_changed)
        self.series_table.itemChanged.connect(self._series_table_changed)
        self.add_subplot_button.clicked.connect(self._add_subplot)
        self.delete_subplot_button.clicked.connect(self._remove_subplot)
        self.move_subplot_up_button.clicked.connect(lambda: self._move_subplot(-1))
        self.move_subplot_down_button.clicked.connect(lambda: self._move_subplot(1))
        self.add_series_button.clicked.connect(self._add_series)
        self.delete_series_button.clicked.connect(self._remove_series)
        self.move_series_up_button.clicked.connect(lambda: self._move_series(-1))
        self.move_series_down_button.clicked.connect(lambda: self._move_series(1))
        self.one_per_series_button.clicked.connect(self._one_per_series)
        self.advanced_series_button.clicked.connect(self._advanced_series)
        self.details_button.toggled.connect(self._set_details_visible)
        for widget in (
            self.subplot_title, self.subplot_unit, self.series_label, self.series_names,
            self.timeline_names, self.source_path, self.source_field, self.minimum, self.maximum,
            self.equal, self.not_equal,
        ):
            widget.textEdited.connect(self._apply_inspector)
        for widget in (
            self.subplot_kind, self.timeline_session, self.timeline_direction, self.timeline_lane_by,
            self.series_subplot, self.series_session, self.series_direction,
            self.source_kind, self.source_type, self.source_endian, self.plot_style,
        ):
            widget.currentIndexChanged.connect(self._apply_inspector)
        for widget in (self.source_offset, self.source_length, self.scale, self.value_offset):
            widget.valueChanged.connect(self._apply_inspector)
        self.series_enabled.toggled.connect(self._apply_inspector)
        self.series_export.toggled.connect(self._apply_inspector)
        self.source_signed.toggled.connect(self._apply_inspector)
        self.source_encoding.currentTextChanged.connect(self._apply_inspector)
        self.plot_color.colorChanged.connect(self._apply_inspector)
        self.processor.textChanged.connect(self._apply_processor)
        for widget_type in (
            QtWidgets.QAbstractButton, QtWidgets.QComboBox, QtWidgets.QLineEdit,
            QtWidgets.QSpinBox, QtWidgets.QDoubleSpinBox, QtWidgets.QPlainTextEdit,
            QtWidgets.QTreeWidget,
        ):
            for widget in self.findChildren(widget_type):
                if not widget.toolTip().strip():
                    widget.setToolTip("Configure the selected subplot or series in the shared visualization workspace.")

    def document(self) -> dict:
        return copy.deepcopy(self._document)

    def _set_details_visible(self, visible):
        self.inspector.setVisible(bool(visible))
        self.details_button.setText("Hide details" if visible else "Show details")
        if visible:
            self.inspector.setMinimumWidth(360)
            parent_splitter = self.inspector.parentWidget()
            if isinstance(parent_splitter, QtWidgets.QSplitter):
                parent_splitter.setSizes([560, 420])

    def set_document(self, document: dict | None):
        self._document = normalize_visualization(document)
        self._reload_tree()

    def _find(self, kind, item_id):
        for subplot in self._document["subplots"]:
            if kind == "subplot" and subplot["id"] == item_id:
                return subplot, None
            for series in subplot.get("series", []):
                if kind == "series" and series["id"] == item_id:
                    return subplot, series
        return None, None

    def _current(self):
        item = self.tree.currentItem()
        if item is None: return None, None, None
        kind, item_id = item.data(0, QtCore.Qt.UserRole)
        subplot, series = self._find(kind, item_id)
        return kind, subplot, series

    def _source_summary(self, series):
        source = series.get("source", {}); kind = source.get("kind", "parsed_field")
        return str(source.get("path") or source.get("field") or kind)

    def _reload_tree(self, selected=None):
        selected = selected or (self.tree.currentItem().data(0, QtCore.Qt.UserRole) if self.tree.currentItem() else None)
        self.tree.blockSignals(True); self.tree.clear()
        selected_item = None
        for subplot in self._document["subplots"]:
            parent = QtWidgets.QTreeWidgetItem([subplot["title"], subplot.get("unit", ""), subplot.get("kind", "plot")])
            parent.setData(0, QtCore.Qt.UserRole, ("subplot", subplot["id"])); self.tree.addTopLevelItem(parent)
            if selected == ("subplot", subplot["id"]): selected_item = parent
            for series in subplot.get("series", []):
                child = QtWidgets.QTreeWidgetItem([
                    series["label"], self._source_summary(series), series.get("plot", {}).get("type", "line"),
                ])
                child.setData(0, QtCore.Qt.UserRole, ("series", series["id"])); parent.addChild(child)
                if selected == ("series", series["id"]): selected_item = child
            parent.setExpanded(True)
        self.tree.blockSignals(False)
        if selected_item: self.tree.setCurrentItem(selected_item)
        elif self.tree.topLevelItemCount(): self.tree.setCurrentItem(self.tree.topLevelItem(0))
        else: self._selection_changed()
        self._reload_tables(selected)

    def _reload_tables(self, selected=None):
        self.subplot_table.blockSignals(True); self.series_table.blockSignals(True)
        try:
            self.subplot_table.setRowCount(0); self.series_table.setRowCount(0)
            for subplot in self._document["subplots"]:
                row = self.subplot_table.rowCount(); self.subplot_table.insertRow(row)
                kind = QtWidgets.QTableWidgetItem("Event lane" if subplot.get("kind") == "timeline" else "Data plot")
                kind.setFlags(kind.flags() & ~QtCore.Qt.ItemIsEditable)
                kind.setData(QtCore.Qt.UserRole, subplot["id"])
                title = QtWidgets.QTableWidgetItem(subplot["title"]); title.setData(QtCore.Qt.UserRole, subplot["id"])
                unit = QtWidgets.QTableWidgetItem(subplot.get("unit", ""))
                count = QtWidgets.QTableWidgetItem(str(len(subplot.get("series", [])))); count.setFlags(count.flags() & ~QtCore.Qt.ItemIsEditable)
                for column, item in enumerate((kind, title, unit, count)): self.subplot_table.setItem(row, column, item)
                for series in subplot.get("series", []):
                    series_row = self.series_table.rowCount(); self.series_table.insertRow(series_row)
                    visible = QtWidgets.QTableWidgetItem(); visible.setFlags(visible.flags() | QtCore.Qt.ItemIsUserCheckable)
                    plot_checked = series.get("plot_enabled", series.get("visible", True)) if self.presentation_only else series.get("visible", True)
                    visible.setCheckState(QtCore.Qt.Checked if plot_checked else QtCore.Qt.Unchecked); visible.setData(QtCore.Qt.UserRole, series["id"])
                    output = QtWidgets.QTableWidgetItem(); output.setFlags(output.flags() | QtCore.Qt.ItemIsUserCheckable)
                    second_checked = series.get("visible", True) if self.presentation_only else series.get("export_enabled", True)
                    output.setCheckState(QtCore.Qt.Checked if second_checked else QtCore.Qt.Unchecked)
                    visible.setToolTip("Include this series in plots." if self.presentation_only else "Show or hide this series without changing Excel output selection.")
                    output.setToolTip("Temporarily show or hide this plotted series." if self.presentation_only else "Include this series in Excel output.")
                    label = QtWidgets.QTableWidgetItem(series["label"]); label.setData(QtCore.Qt.UserRole, series["id"])
                    if self.presentation_only: label.setFlags(label.flags() & ~QtCore.Qt.ItemIsEditable)
                    self.series_table.setItem(series_row, 0, visible); self.series_table.setItem(series_row, 1, output); self.series_table.setItem(series_row, 2, label)
                    subplot_combo = QtWidgets.QComboBox()
                    for target in self._document["subplots"]:
                        if target.get("kind") != "timeline": subplot_combo.addItem(target["title"], target["id"])
                    subplot_combo.setCurrentIndex(max(0, subplot_combo.findData(subplot["id"])))
                    subplot_combo.setToolTip("Move this series to another data subplot.")
                    subplot_combo.currentIndexChanged.connect(lambda _index, sid=series["id"], combo=subplot_combo: self._table_combo_changed(sid, "subplot", combo.currentData()))
                    self.series_table.setCellWidget(series_row, 3, subplot_combo)
                    source_combo = QtWidgets.QComboBox()
                    source_types = [("Parsed", "parsed_field")]
                    if self.capabilities.nested_binary: source_types.append(("Nested binary", "binary_field"))
                    source_types.extend((("Header", "header_field"), ("Raw bytes", "raw_bytes"), ("Metadata", "metadata")))
                    for label_text, value in source_types: source_combo.addItem(label_text, value)
                    source_combo.setCurrentIndex(max(0, source_combo.findData(series.get("source", {}).get("kind", "parsed_field"))))
                    source_combo.setToolTip("Choose the value extractor. Detailed byte and metadata options are available in the inspector.")
                    source_combo.currentIndexChanged.connect(lambda _index, sid=series["id"], combo=source_combo: self._table_combo_changed(sid, "source", combo.currentData()))
                    self.series_table.setCellWidget(series_row, 4, source_combo)
                    source = series.get("source", {})
                    path = QtWidgets.QTableWidgetItem(str(source.get("path") or source.get("field") or ""))
                    style_combo = QtWidgets.QComboBox(); style_combo.addItems(list(PLOT_STYLES)); style_combo.setCurrentText(series.get("plot", {}).get("type", "line"))
                    style_combo.setToolTip("Line is preferred for continuous telemetry; Step or State is preferred for discrete protocol state.")
                    style_combo.currentIndexChanged.connect(lambda _index, sid=series["id"], combo=style_combo: self._table_combo_changed(sid, "style", combo.currentText()))
                    color_value = str(series.get("plot", {}).get("color", VISUALIZATION_COLORS[0]))
                    color = ColorSelectionWidget(color_value, self.series_table)
                    color.setToolTip("Enter a valid Qt color or open the full color dialog.")
                    color.colorChanged.connect(
                        lambda value, sid=series["id"]:
                        self._table_color_changed(sid, value)
                    )
                    self.series_table.setItem(series_row, 5, path); self.series_table.setCellWidget(series_row, 6, style_combo); self.series_table.setCellWidget(series_row, 7, color)
            if selected:
                kind, item_id = selected
                table = self.subplot_table if kind == "subplot" else self.series_table
                for row in range(table.rowCount()):
                    item = table.item(row, 0)
                    if item and str(item.data(QtCore.Qt.UserRole)) == str(item_id):
                        table.selectRow(row); break
        finally:
            self.subplot_table.blockSignals(False); self.series_table.blockSignals(False)

    def _select_hidden(self, kind, item_id):
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            if item.data(0, QtCore.Qt.UserRole) == (kind, item_id):
                self.tree.setCurrentItem(item); return
            iterator += 1

    def _subplot_table_selected(self):
        row = self.subplot_table.currentRow()
        item = self.subplot_table.item(row, 0) if row >= 0 else None
        if item:
            self.series_table.blockSignals(True); self.series_table.clearSelection(); self.series_table.blockSignals(False)
            self._select_hidden("subplot", str(item.data(QtCore.Qt.UserRole)))

    def _series_table_selected(self):
        row = self.series_table.currentRow()
        item = self.series_table.item(row, 0) if row >= 0 else None
        if item:
            self.subplot_table.blockSignals(True); self.subplot_table.clearSelection(); self.subplot_table.blockSignals(False)
            self._select_hidden("series", str(item.data(QtCore.Qt.UserRole)))

    def _subplot_table_changed(self, item):
        if self._loading or item.column() not in {1, 2}: return
        subplot_id = self.subplot_table.item(item.row(), 0).data(QtCore.Qt.UserRole)
        subplot, _series = self._find("subplot", str(subplot_id))
        if subplot is None: return
        if item.column() == 1: subplot["title"] = item.text().strip() or "Subplot"
        else: subplot["unit"] = item.text().strip()
        self._reload_tree(("subplot", subplot["id"])); self.configurationChanged.emit(self.document())

    def _series_table_changed(self, item):
        if self._loading: return
        series_id = self.series_table.item(item.row(), 0).data(QtCore.Qt.UserRole)
        subplot, series = self._find("series", str(series_id))
        if series is None: return
        column = item.column()
        if self.presentation_only and column not in {0, 1}: return
        if column == 0:
            if self.presentation_only: series["plot_enabled"] = item.checkState() == QtCore.Qt.Checked
            else: series["visible"] = item.checkState() == QtCore.Qt.Checked
        elif column == 1:
            if self.presentation_only: series["visible"] = item.checkState() == QtCore.Qt.Checked
            else:
                series["export_enabled"] = item.checkState() == QtCore.Qt.Checked
                if not self.capabilities.series_filters:
                    series["enabled"] = series["export_enabled"]
        elif column == 2: series["label"] = item.text().strip() or "Series"
        elif column == 5:
            source = series.setdefault("source", {})
            key = "field" if source.get("kind") == "metadata" else "path"
            source[key] = item.text().strip()
        else: return
        self._reload_tree(("series", series["id"])); self.configurationChanged.emit(self.document())

    def _table_combo_changed(self, series_id, field, value):
        if self._loading: return
        subplot, series = self._find("series", str(series_id))
        if series is None: return
        if field == "subplot" and value and str(value) != subplot["id"]:
            subplot["series"].remove(series)
            target = next(item for item in self._document["subplots"] if item["id"] == str(value))
            target["series"].append(series)
        elif field == "source" and not self.presentation_only: series.setdefault("source", {})["kind"] = str(value)
        elif field == "style": series.setdefault("plot", {})["type"] = str(value)
        self._reload_tree(("series", series["id"])); self.configurationChanged.emit(self.document())

    def _table_color_changed(self, series_id, color):
        if self._loading or not QtGui.QColor(str(color)).isValid():
            return
        _subplot, series = self._find("series", str(series_id))
        if series is None:
            return
        series.setdefault("plot", {})["color"] = str(color)
        self._reload_tree(("series", series["id"]))
        self.configurationChanged.emit(self.document())

    def _show_rows(self, rows):
        all_rows = self._subplot_rows + self._series_rows
        visible = {id(widget) for _label, widget in rows}
        for _label, widget in all_rows:
            show = id(widget) in visible
            widget.setVisible(show)
            label = self.inspector_layout.labelForField(widget)
            if label: label.setVisible(show)
        self.empty_note.setVisible(not rows)

    def _selection_changed(self, *_args):
        kind, subplot, series = self._current(); self._loading = True
        selected = kind in {"subplot", "series"}
        self.delete_subplot_button.setEnabled(kind == "subplot")
        self.move_subplot_up_button.setEnabled(kind == "subplot")
        self.move_subplot_down_button.setEnabled(kind == "subplot")
        self.delete_series_button.setEnabled(kind == "series")
        self.move_series_up_button.setEnabled(kind == "series")
        self.move_series_down_button.setEnabled(kind == "series")
        self.details_button.setEnabled(selected)
        self.advanced_series_button.setEnabled(kind == "series")
        self.one_per_series_button.setEnabled(any(
            item.get("series") for item in self._document.get("subplots", [])
        ))
        try:
            if kind == "subplot" and subplot:
                rows = list(self._subplot_rows)
                if subplot.get("kind") != "timeline":
                    rows = [row for row in rows if row[1] not in {self.timeline_session, self.timeline_names, self.timeline_direction, self.timeline_lane_by}]
                self._show_rows(rows)
                self.subplot_title.setText(subplot["title"]); self.subplot_unit.setText(subplot.get("unit", ""))
                self.subplot_kind.setCurrentIndex(max(0, self.subplot_kind.findData(subplot.get("kind", "plot"))))
                timeline = subplot.get("timeline", {})
                self.timeline_session.setCurrentIndex(max(0, self.timeline_session.findData(timeline.get("session_id", ""))))
                self.timeline_names.setText(", ".join(timeline.get("message_names", [])))
                self.timeline_direction.setCurrentIndex(max(0, self.timeline_direction.findData(timeline.get("direction", "any"))))
                self.timeline_lane_by.setCurrentIndex(max(0, self.timeline_lane_by.findData(timeline.get("lane_by", "session_direction_name"))))
                return
            if kind == "series" and series:
                rows = list(self._series_rows)
                if self.presentation_only:
                    rows = [row for row in rows if row[1] in {self.series_enabled, self.series_subplot, self.plot_style, self.plot_color}]
                if not self.capabilities.series_filters:
                    rows = [row for row in rows if row[1] not in {self.series_session, self.series_names, self.series_direction}]
                if not self.capabilities.thresholds:
                    rows = [row for row in rows if row[1] not in {self.series_export, self.minimum, self.maximum, self.equal, self.not_equal}]
                if not self.capabilities.processors:
                    rows = [row for row in rows if row[1] is not self.processor]
                self._show_rows(rows)
                self.series_enabled.setChecked(series.get("visible", series.get("enabled", True)))
                self.series_export.setChecked(series.get("export_enabled", True)); self.series_label.setText(series["label"])
                self.series_subplot.blockSignals(True); self.series_subplot.clear()
                for item in self._document["subplots"]:
                    if item.get("kind") != "timeline": self.series_subplot.addItem(item["title"], item["id"])
                self.series_subplot.setCurrentIndex(max(0, self.series_subplot.findData(subplot["id"])))
                self.series_subplot.blockSignals(False)
                self.series_session.setCurrentIndex(max(0, self.series_session.findData(series.get("session_id", ""))))
                self.series_names.setText(", ".join(series.get("message_names", [])))
                self.series_direction.setCurrentIndex(max(0, self.series_direction.findData(series.get("direction", "any"))))
                source = series.get("source", {}); self.source_kind.setCurrentIndex(max(0, self.source_kind.findData(source.get("kind", "parsed_field"))))
                self.source_path.setText(str(source.get("path", ""))); self.source_field.setText(str(source.get("field", "")))
                self.source_offset.setValue(int(source.get("offset", 0))); self.source_length.setValue(int(source.get("length", 1)))
                self.source_type.setCurrentText(str(source.get("data_type", "uint"))); self.source_endian.setCurrentText(str(source.get("endianness", "little")))
                self.source_signed.setChecked(bool(source.get("signed", False))); self.source_encoding.setCurrentText(str(source.get("encoding", "utf-8")))
                self.plot_style.setCurrentText(str(series.get("plot", {}).get("type", "line"))); self.plot_color.setColor(str(series.get("plot", {}).get("color", VISUALIZATION_COLORS[0])))
                self.scale.setValue(float(series.get("transform", {}).get("scale", 1.0))); self.value_offset.setValue(float(series.get("transform", {}).get("offset", 0.0)))
                thresholds = series.get("thresholds", {})
                self.minimum.setText(str(thresholds.get("minimum", ""))); self.maximum.setText(str(thresholds.get("maximum", "")))
                self.equal.setText(str(thresholds.get("equal", ""))); self.not_equal.setText(str(thresholds.get("not_equal", "")))
                self.processor.setPlainText(json.dumps(series.get("processor", {}), indent=2, ensure_ascii=False))
                return
            self._show_rows([])
        finally:
            self._loading = False

    @staticmethod
    def _optional_number(text):
        text = str(text).strip()
        if not text: return None
        try: return float(text)
        except ValueError: return text

    def _apply_processor(self):
        if self._loading or not self.capabilities.processors:
            return
        _kind, _subplot, series = self._current()
        if series is None:
            return
        try:
            configured = json.loads(self.processor.toPlainText() or "{}")
        except json.JSONDecodeError:
            return
        if isinstance(configured, dict):
            series["processor"] = configured
            self.configurationChanged.emit(self.document())

    def _apply_inspector(self, *_args):
        if self._loading: return
        kind, subplot, series = self._current()
        if kind == "subplot" and subplot:
            subplot["title"] = self.subplot_title.text().strip() or "Subplot"
            subplot["unit"] = self.subplot_unit.text().strip(); subplot["kind"] = self.subplot_kind.currentData()
            if subplot["kind"] == "timeline":
                subplot["unit"] = ""; subplot["series"] = []
                subplot["timeline"] = {
                    "session_id": str(self.timeline_session.currentData() or ""),
                    "message_names": [item.strip() for item in self.timeline_names.text().split(",") if item.strip()],
                    "direction": self.timeline_direction.currentData(),
                    "lane_by": self.timeline_lane_by.currentData(),
                }
            else:
                subplot.pop("timeline", None)
        elif kind == "series" and series:
            target_id = self.series_subplot.currentData()
            if target_id and target_id != subplot["id"]:
                subplot["series"].remove(series)
                target = next(item for item in self._document["subplots"] if item["id"] == target_id)
                target["series"].append(series); subplot = target
            series["visible"] = self.series_enabled.isChecked()
            if self.presentation_only:
                series["plot"] = {"type": self.plot_style.currentText(), "color": self.plot_color.color()}
                selected = (kind, series["id"])
                self._reload_tree(selected); self.configurationChanged.emit(self.document())
                return
            series["export_enabled"] = self.series_export.isChecked()
            if not self.capabilities.series_filters:
                series["enabled"] = self.series_export.isChecked()
            series["label"] = self.series_label.text().strip() or "Series"
            series["session_id"] = str(self.series_session.currentData() or "")
            series["message_names"] = [item.strip() for item in self.series_names.text().split(",") if item.strip()]
            series["direction"] = self.series_direction.currentData()
            source = {"kind": self.source_kind.currentData()}
            if source["kind"] in {"parsed_field", "binary_field", "header_field"}: source["path"] = self.source_path.text().strip()
            if source["kind"] == "metadata": source["field"] = self.source_field.text().strip()
            if source["kind"] in {"raw_bytes", "binary_field"}:
                source.update({"offset": self.source_offset.value(), "length": self.source_length.value(), "data_type": self.source_type.currentText(), "endianness": self.source_endian.currentText(), "signed": self.source_signed.isChecked(), "encoding": self.source_encoding.currentText().strip() or "utf-8"})
            series["source"] = source
            series["plot"] = {"type": self.plot_style.currentText(), "color": self.plot_color.color()}
            series["transform"] = {"scale": self.scale.value(), "offset": self.value_offset.value()}
            if self.capabilities.processors:
                try:
                    configured_processor = json.loads(self.processor.toPlainText() or "{}")
                    if isinstance(configured_processor, dict): series["processor"] = configured_processor
                except json.JSONDecodeError:
                    pass
            thresholds = {}
            for key, widget in (("minimum", self.minimum), ("maximum", self.maximum), ("equal", self.equal), ("not_equal", self.not_equal)):
                value = self._optional_number(widget.text())
                if value is not None: thresholds[key] = value
            series["thresholds"] = thresholds
        else: return
        selected = (kind, series["id"] if series else subplot["id"])
        self._reload_tree(selected); self.configurationChanged.emit(self.document())

    def _add_subplot(self):
        subplot = new_subplot(f"Subplot {len(self._document['subplots']) + 1}")
        self._document["subplots"].append(subplot); self._reload_tree(("subplot", subplot["id"])); self.configurationChanged.emit(self.document())

    def _add_series(self):
        regular = [item for item in self._document["subplots"] if item.get("kind") != "timeline"]
        if not regular:
            self._add_subplot(); regular = self._document["subplots"]
        kind, subplot, _series = self._current()
        target = subplot if subplot in regular else regular[0]
        series = new_series(f"Series {sum(len(item['series']) for item in regular) + 1}")
        target["series"].append(series); self._reload_tree(("series", series["id"])); self.configurationChanged.emit(self.document())

    def _remove_subplot(self):
        kind, subplot, _series = self._current()
        if kind != "subplot" or subplot is None:
            return
        self._document["subplots"].remove(subplot)
        self._reload_tree(); self.configurationChanged.emit(self.document())

    def _remove_series(self):
        kind, subplot, series = self._current()
        if kind != "series" or series is None:
            return
        if self.presentation_only:
            series["plot_enabled"] = False
            selected = ("series", series["id"])
            self._reload_tree(selected); self.configurationChanged.emit(self.document())
            return
        subplot["series"].remove(series)
        self._reload_tree(); self.configurationChanged.emit(self.document())

    def _move_subplot(self, delta):
        kind, subplot, _series = self._current()
        if kind != "subplot" or subplot is None:
            return
        items = self._document["subplots"]
        index = items.index(subplot); target = index + delta
        if target < 0 or target >= len(items): return
        items[index], items[target] = items[target], items[index]
        self._reload_tree(("subplot", subplot["id"])); self.configurationChanged.emit(self.document())

    def _move_series(self, delta):
        kind, subplot, series = self._current()
        if kind != "series" or series is None:
            return
        items = subplot.get("series", [])
        index = items.index(series); target = index + delta
        if target < 0 or target >= len(items): return
        items[index], items[target] = items[target], items[index]
        self._reload_tree(("series", series["id"])); self.configurationChanged.emit(self.document())

    def _one_per_series(self):
        series = [entry for subplot in self._document["subplots"] for entry in subplot.get("series", [])]
        self._document["subplots"] = []
        for entry in series:
            subplot = new_subplot(entry["label"]); subplot["series"].append(entry); self._document["subplots"].append(subplot)
        self._reload_tree(); self.configurationChanged.emit(self.document())

    def _advanced_series(self):
        kind, _subplot, series = self._current()
        if kind == "series" and series is not None:
            self.advancedSeriesRequested.emit(series["id"])
