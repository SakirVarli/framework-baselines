from __future__ import annotations

"""Workbook output and validation for Protocol Insights."""

import copy
import json
import numbers
import os
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from .local_time import (
    excel_local_datetime, local_iso, local_now, local_timestamp, local_timezone_name,
)

try:
    import openpyxl
    import xlsxwriter
except ImportError:  # pragma: no cover - callers receive an explicit runtime error.
    openpyxl = None
    xlsxwriter = None


WORKBOOK_TYPE = "communication_hub_protocol_insight"
WORKBOOK_SCHEMA_VERSION = 1
ALIGNED_TIMELINE_SHEET = "Aligned Timeline"
SAMPLE_RECORDS_SHEET = "Sample Records"
PLOTS_SHEET = "Plots"
# Kept as an import alias for callers compiled against the earlier name.
CONFIGURED_PLOTS_SHEET = PLOTS_SHEET
IDENTITY_FIELDS = ("session_id", "direction", "message", "connection_id")
BASE_SAMPLE_FIELDS = {
    "sample_time", "observed_at", "event_id", "session_id", "protocol",
    "direction", "message", "connection_id", "peer",
}


def _json_default(value):
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"$bytes_hex": bytes(value).hex()}
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if hasattr(value, "item"):
        try:
            return value.item()
        except (TypeError, ValueError):
            pass
    return str(value)


def _text(value):
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list, tuple, bytes, bytearray, memoryview)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=_json_default)
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value)


def _series_names(config: dict) -> list[str]:
    """Return every configured insight series in stable UI order.

    Current Protocol Insights configurations own series inside subplots.  The
    top-level list is accepted only for files produced during development of
    the unified tool.
    """
    configured = list(config.get("series", []))
    for subplot in config.get("subplots", []):
        if isinstance(subplot, dict):
            configured.extend(subplot.get("series", []))
    result = []
    seen = set()
    for series in configured:
        if not isinstance(series, dict):
            continue
        name = str(series.get("label") or series.get("name") or "").strip()
        if name and name not in seen:
            seen.add(name)
            result.append(name)
    return result


def _sample_time(value):
    try:
        return local_timestamp(value)
    except (TypeError, ValueError) as error:
        raise ValueError("Protocol Insight sample is missing sample_time") from error


def _local_time(value):
    return _sample_time(value)


def _excel_datetime(value):
    return excel_local_datetime(value)


def _timestamp_from_excel(value, *, local_time=False):
    try:
        return local_timestamp(value)
    except (TypeError, ValueError) as error:
        raise ValueError("Protocol Insight workbook contains an invalid sample time") from error


def _stream_key(sample: dict) -> tuple:
    return tuple(str(sample.get(field, "") or "") for field in IDENTITY_FIELDS)


def _stream_label(key: tuple) -> str:
    session, direction, message, connection = key
    parts = [part for part in (session, direction, message, connection) if part]
    return " / ".join(parts) or "Protocol Insight Values"


def _build_blocks(config: dict, samples: list[dict]) -> list[dict]:
    series = _series_names(config)
    keys = []
    seen = set()
    for sample in samples:
        key = _stream_key(sample)
        if key not in seen:
            seen.add(key); keys.append(key)
    if not keys:
        keys = [("", "", "", "")]
    blocks = []
    start = 1
    for index, key in enumerate(keys, 1):
        block = {
            "id": f"stream-{index}",
            "label": _stream_label(key),
            **dict(zip(IDENTITY_FIELDS, key)),
            "protocol": next(
                (str(sample.get("protocol", "")) for sample in samples if _stream_key(sample) == key),
                "",
            ),
            "series": series,
            "start_column": start,
            "end_column": start + len(series) - 1,
        }
        blocks.append(block)
        start += max(1, len(series))
    return blocks


def _aligned_rows(samples: list[dict], blocks: list[dict]):
    """Yield exactly one consolidated row for each global timestamp.

    The runtime stores independently-produced series samples as separate
    records.  Excel's aligned view is a pivot, so records sharing a timestamp
    and stream belong on the same row.  A later non-empty value wins only when
    the same series is emitted more than once at the identical timestamp.
    """
    grouped = defaultdict(lambda: defaultdict(dict))
    series_names = set(
        name for block in blocks for name in block.get("series", [])
    )
    for sample in samples:
        merged = grouped[_sample_time(sample.get("sample_time"))][_stream_key(sample)]
        for key, value in sample.items():
            if key in series_names:
                if value is not None and not _is_missing(value):
                    merged[key] = value
            elif key not in merged or (
                value is not None and not (isinstance(value, str) and not value)
            ):
                merged[key] = value
    for timestamp in sorted(grouped):
        yield timestamp, dict(grouped[timestamp])


def _is_missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        result = pd.isna(value)
        return bool(result) if isinstance(result, (bool, numbers.Integral)) else False
    except (TypeError, ValueError):
        return False


def _series_thresholds(config: dict) -> dict[str, dict]:
    return {
        str(series.get("name", "")): (
            series.get("thresholds", {})
            if isinstance(series.get("thresholds"), dict) else {}
        )
        for series in config.get("series", [])
        if series.get("enabled", True)
    }


def _display_plot_definitions(config: dict) -> list[dict]:
    """Resolve configured display settings into ordered subplots."""
    display = config.get("display", {}) if isinstance(config.get("display"), dict) else {}
    raw_subplots = display.get("subplots", [])
    settings = display.get("series", {}) if isinstance(display.get("series"), dict) else {}
    subplots = []
    by_id = {}
    by_title = {}
    for index, raw in enumerate(raw_subplots if isinstance(raw_subplots, list) else [], 1):
        if not isinstance(raw, dict):
            continue
        subplot = {
            "id": str(raw.get("id") or f"subplot-{index}"),
            "title": str(raw.get("title") or f"Subplot {index}"),
            "unit": str(raw.get("unit") or ""),
            "series": [],
        }
        subplots.append(subplot); by_id[subplot["id"]] = subplot
        by_title.setdefault(subplot["title"], subplot)
    palette = ("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9")
    for index, series in enumerate(config.get("series", [])):
        if not series.get("enabled", True):
            continue
        name = str(series.get("name", "")).strip()
        if not name:
            continue
        options = settings.get(name, {}) if isinstance(settings.get(name), dict) else {}
        style = str(options.get("style", "line"))
        if style == "hidden":
            continue
        subplot_id = str(options.get("subplot_id") or "")
        fallback_title = str(options.get("subplot") or name)
        subplot = by_id.get(subplot_id) or by_title.get(fallback_title)
        if subplot is None:
            subplot = {
                "id": subplot_id or f"subplot-{len(subplots) + 1}",
                "title": fallback_title, "unit": "", "series": [],
            }
            subplots.append(subplot); by_id[subplot["id"]] = subplot
            by_title.setdefault(subplot["title"], subplot)
        subplot["series"].append({
            "name": name, "style": style,
            "color": str(options.get("color") or palette[index % len(palette)]),
        })
    return [subplot for subplot in subplots if subplot["series"]]


def add_configured_protocol_insight_plots(
    workbook,
    config: dict,
    samples: list[dict],
) -> dict:
    """Add one native Excel chart for every exported insight series.

    Display subplot membership is intentionally ignored: Excel is a complete
    data output, while subplot choices only control the live UI presentation.
    Each stream is a separate line on the series chart.
    """
    series_names = _series_names(config)
    blocks = _build_blocks(config, samples)
    aligned = list(_aligned_rows(samples, blocks)) if samples else []
    plots = workbook.add_worksheet(PLOTS_SHEET)
    plots.hide_gridlines(2); plots.set_column("A:A", 3); plots.set_column("B:M", 12)
    title = workbook.add_format({
        "bold": True, "font_size": 18, "font_color": "#FFFFFF",
        "bg_color": "#17324D",
    })
    section = workbook.add_format({
        "bold": True, "font_color": "#FFFFFF", "bg_color": "#0F766E",
    })
    note = workbook.add_format({
        "font_color": "#527080", "italic": True, "text_wrap": True,
    })
    plots.merge_range("B2:M2", "Protocol Insight Series Plots", title)
    plots.merge_range(
        "B3:M4",
        f"One chart is provided for every exported series using all {len(samples):,} retained "
        "sample records. Live display visibility, subplot assignment, refresh intervals, and "
        "point limits do not restrict these charts.",
        note,
    )
    if not series_names:
        plots.merge_range("B6:M7", "No exported series are configured.", note)
        return {"series_charts": 0, "samples": len(samples), "plot_data_sheets": []}

    state_maps = {
        (name, tuple(block[field] for field in IDENTITY_FIELDS)): {}
        for name in series_names for block in blocks
    }
    data_sheet = workbook.add_worksheet("_PlotData")
    data_sheet.hide()
    plot_data_sheets = ["_PlotData"]
    datetime_format = workbook.add_format({"num_format": "yyyy-mm-dd hh:mm:ss.000"})
    columns = []
    for name in series_names:
        for block in blocks:
            key = tuple(block[field] for field in IDENTITY_FIELDS)
            columns.append((name, key, block["label"]))
    thresholds_by_name = _series_thresholds(config)
    threshold_columns = []
    for name in series_names:
        thresholds = thresholds_by_name.get(name, {})
        for key, label in (("min", "Minimum"), ("max", "Maximum"), ("eq", "Equal target"), ("noteq", "Not-equal target")):
            try:
                value = float(thresholds[key])
            except (KeyError, TypeError, ValueError):
                continue
            threshold_columns.append((name, key, label, value))
    data_sheet.write_row(0, 0, ["sample_time", *[
        f"{name} — {stream_label}" for name, _key, stream_label in columns
    ], *[
        f"{name} — {label}" for name, _key, label, _value in threshold_columns
    ]])
    for row, (timestamp, row_streams) in enumerate(aligned, 1):
        data_sheet.write_datetime(row, 0, _excel_datetime(timestamp), datetime_format)
        for column, (name, key, _label) in enumerate(columns, 1):
            value = row_streams.get(key, {}).get(name)
            if isinstance(value, bool):
                data_sheet.write_number(row, column, int(value))
            elif isinstance(value, numbers.Real):
                data_sheet.write_number(row, column, float(value))
            elif isinstance(value, str):
                mapping = state_maps[(name, key)]
                if value not in mapping:
                    mapping[value] = len(mapping)
                data_sheet.write_number(row, column, mapping[value])
            else:
                data_sheet.write_blank(row, column, None)
        for offset, (_name, _key, _label, value) in enumerate(threshold_columns, 1 + len(columns)):
            data_sheet.write_number(row, offset, value)

    top_row = 5
    palette = ("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9")
    major_unit = None
    if len(aligned) > 1:
        span_days = max(
            1.0 / 86_400.0,
            (aligned[-1][0] - aligned[0][0]).total_seconds() / 86_400.0,
        )
        major_unit = span_days / 7.0
    for series_index, name in enumerate(series_names, 1):
        plots.merge_range(
            top_row, 1, top_row, 12,
            name,
            section,
        )
        chart = workbook.add_chart({"type": "scatter", "subtype": "straight_with_markers"})
        for stream_index, block in enumerate(blocks):
            key = tuple(block[field] for field in IDENTITY_FIELDS)
            column = columns.index((name, key, block["label"])) + 1
            color = palette[stream_index % len(palette)]
            if aligned:
                chart.add_series({
                    "name": block["label"],
                    "categories": ["_PlotData", 1, 0, len(aligned), 0],
                    "values": ["_PlotData", 1, column, len(aligned), column],
                    "line": {"color": color, "width": 1.75},
                    "marker": {
                        "type": "circle", "size": 3,
                        "border": {"color": color}, "fill": {"color": color},
                    },
                })
        threshold_styles = {
            "min": ("Minimum", "#2563EB"), "max": ("Maximum", "#DC2626"),
            "eq": ("Equal target", "#059669"), "noteq": ("Not-equal target", "#D97706"),
        }
        for threshold_index, (threshold_name, key, _label, _value) in enumerate(threshold_columns):
            if threshold_name != name or not aligned:
                continue
            column = 1 + len(columns) + threshold_index
            label, color = threshold_styles[key]
            chart.add_series({
                "name": label,
                "categories": ["_PlotData", 1, 0, len(aligned), 0],
                "values": ["_PlotData", 1, column, len(aligned), column],
                "line": {"color": color, "width": 1.25, "dash_type": "dash"},
                "marker": {"type": "none"},
            })
        chart.set_title({"name": name})
        x_axis_options = {
            "name": "Sample time (local)", "date_axis": True,
            "num_format": "yyyy-mm-dd hh:mm:ss",
            "num_font": {"rotation": -45, "size": 8},
            "label_position": "low",
        }
        if major_unit is not None:
            x_axis_options["major_unit"] = major_unit
        chart.set_x_axis(x_axis_options)
        chart.set_y_axis({"name": "Value", "major_gridlines": {"visible": True}})
        chart.set_legend({"position": "bottom"})
        chart.set_size({"width": 950, "height": 380})
        chart.set_style(10)
        plots.insert_chart(top_row + 1, 1, chart)
        mapping_lines = []
        for block in blocks:
            key = tuple(block[field] for field in IDENTITY_FIELDS)
            mapping = state_maps.get((name, key), {})
            if mapping:
                mapping_lines.append(
                    f"{block['label']} states: "
                    + ", ".join(f"{number}={label}" for label, number in mapping.items())
                )
        if mapping_lines:
            plots.merge_range(top_row + 20, 1, top_row + 21, 12, "\n".join(mapping_lines), note)
            top_row += 23
        else:
            top_row += 21
    plots.freeze_panes(5, 1)
    return {
        "series_charts": len(series_names), "samples": len(samples),
        "plot_data_sheets": plot_data_sheets,
    }


def _write_value(sheet, row, column, value, formats):
    if _is_missing(value):
        sheet.write_blank(row, column, None, formats["value"])
    elif isinstance(value, bool):
        sheet.write_boolean(row, column, value, formats["value"])
    elif isinstance(value, numbers.Integral) and not isinstance(value, bool):
        sheet.write_number(row, column, int(value), formats["integer"])
    elif isinstance(value, numbers.Real) and not isinstance(value, bool):
        sheet.write_number(row, column, float(value), formats["number"])
    else:
        sheet.write_string(row, column, _text(value), formats["value"])


def _threshold_state(value: Any, thresholds: dict) -> str:
    if _is_missing(value):
        return "Missing"
    if "min" in thresholds:
        try:
            if float(value) < float(thresholds["min"]):
                return "Below minimum"
        except (TypeError, ValueError):
            pass
    if "max" in thresholds:
        try:
            if float(value) > float(thresholds["max"]):
                return "Above maximum"
        except (TypeError, ValueError):
            pass
    if "eq" in thresholds:
        return "Equal target" if value == thresholds["eq"] else "Not equal to target"
    if "noteq" in thresholds:
        return "Not equal target" if value != thresholds["noteq"] else "Equal excluded value"
    return "Within thresholds"


def _threshold_statistics(config: dict, samples: list[dict], blocks: list[dict]):
    """Build detailed threshold summaries, state occupancy, and transitions."""
    thresholds_by_name = _series_thresholds(config)
    summary_rows, state_rows, transition_rows = [], [], []
    for block in blocks:
        key = tuple(block[field] for field in IDENTITY_FIELDS)
        stream_samples = sorted(
            (sample for sample in samples if _stream_key(sample) == key),
            key=lambda sample: _sample_time(sample.get("sample_time")),
        )
        for name in block.get("series", []):
            thresholds = thresholds_by_name.get(name, {})
            pairs = [
                (_sample_time(sample.get("sample_time")), sample.get(name))
                for sample in stream_samples if name in sample
            ]
            valid = [(stamp, value) for stamp, value in pairs if not _is_missing(value)]
            numeric = pd.to_numeric(
                pd.Series([value for _stamp, value in valid], dtype=object), errors="coerce",
            ).dropna()
            elapsed = (
                (pairs[-1][0] - pairs[0][0]).total_seconds() if len(pairs) > 1 else 0.0
            )
            intervals = [
                (pairs[index][0] - pairs[index - 1][0]).total_seconds()
                for index in range(1, len(pairs))
            ]
            defined = bool(thresholds)
            states = [
                (stamp, _threshold_state(value, thresholds))
                for stamp, value in pairs
            ] if defined else []
            counts = defaultdict(int)
            durations = defaultdict(float)
            entries = defaultdict(int)
            dwell_values = defaultdict(list)
            transitions = defaultdict(list)
            previous_state = None
            episode_start = None
            for index, (stamp, state) in enumerate(states):
                counts[state] += 1
                next_stamp = states[index + 1][0] if index + 1 < len(states) else stamp
                durations[state] += max(0.0, (next_stamp - stamp).total_seconds())
                if state != previous_state:
                    entries[state] += 1
                    if previous_state is not None:
                        gap = max(0.0, (stamp - episode_start).total_seconds())
                        dwell_values[previous_state].append(gap)
                        transitions[(previous_state, state)].append(
                            max(0.0, (stamp - states[index - 1][0]).total_seconds())
                        )
                    episode_start = stamp
                    previous_state = state
            if states:
                dwell_values[states[-1][1]].append(
                    max(0.0, (states[-1][0] - episode_start).total_seconds())
                )
            breach_states = {"Below minimum", "Above maximum", "Not equal to target", "Not equal target"}
            breach_count = sum(counts.get(state, 0) for state in breach_states)
            breach_duration = sum(durations.get(state, 0.0) for state in breach_states)
            summary_rows.append([
                block["label"], name, "Defined" if defined else "Undefined",
                thresholds.get("min", "Undefined"), thresholds.get("max", "Undefined"),
                thresholds.get("eq", "Undefined"), thresholds.get("noteq", "Undefined"),
                len(pairs), len(valid), len(pairs) - len(valid),
                _local_time(pairs[0][0]).isoformat() if pairs else "",
                _local_time(pairs[-1][0]).isoformat() if pairs else "",
                elapsed, (sum(intervals) / len(intervals)) if intervals else "Undefined",
                float(numeric.min()) if not numeric.empty else "Undefined",
                float(numeric.max()) if not numeric.empty else "Undefined",
                float(numeric.mean()) if not numeric.empty else "Undefined",
                float(numeric.std(ddof=0)) if not numeric.empty else "Undefined",
                breach_count if defined else "Undefined",
                (100.0 * breach_count / len(pairs)) if defined and pairs else (0.0 if defined else "Undefined"),
                breach_duration if defined else "Undefined",
                (100.0 * breach_duration / elapsed) if defined and elapsed else (0.0 if defined else "Undefined"),
                sum(len(values) for values in transitions.values()) if defined else "Undefined",
            ])
            if defined:
                for state in sorted(counts):
                    dwells = dwell_values[state]
                    state_rows.append([
                        block["label"], name, state, counts[state],
                        100.0 * counts[state] / len(states) if states else 0.0,
                        durations[state], 100.0 * durations[state] / elapsed if elapsed else 0.0,
                        entries[state], sum(dwells) / len(dwells) if dwells else 0.0,
                        min(dwells) if dwells else 0.0, max(dwells) if dwells else 0.0,
                    ])
                for (from_state, to_state), gaps in sorted(transitions.items()):
                    transition_rows.append([
                        block["label"], name, from_state, to_state, len(gaps),
                        sum(gaps) / len(gaps), min(gaps), max(gaps),
                    ])
    return summary_rows, state_rows, transition_rows


def write_formatted_protocol_insight_workbook(
    path: str | Path,
    config: dict,
    samples: list[dict],
    *,
    append_history: list[dict] | None = None,
) -> dict:
    if xlsxwriter is None:
        raise RuntimeError("Formatted Protocol Insight Excel export requires XlsxWriter")
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.stem + ".tmp.xlsx")
    samples = copy.deepcopy(samples)
    blocks = _build_blocks(config, samples)
    aligned = list(_aligned_rows(samples, blocks)) if samples else []
    now = local_now()
    manifest = {
        "workbook_type": WORKBOOK_TYPE,
        "schema_version": WORKBOOK_SCHEMA_VERSION,
        "protocol_insight_id": str(config.get("id", "")),
        "protocol_insight_name": str(config.get("name", "")),
        "time_representation": "offset-aware local",
        "local_time_zone": local_timezone_name(),
        "header_rows": 2,
        "data_start_row": 3,
        "data_end_row": 2 + len(aligned),
        "global_time_column": 0,
        "blocks": blocks,
        "series": _series_names(config),
        "aligned_timeline_sheet": ALIGNED_TIMELINE_SHEET,
        "sample_records_sheet": SAMPLE_RECORDS_SHEET,
        "excel_time_zone": "local",
        "generated_at": now.isoformat(),
    }
    workbook = xlsxwriter.Workbook(str(temporary), {"nan_inf_to_errors": True})
    try:
        navy, teal, pale = "#17324D", "#0F766E", "#EAF2F8"
        formats = {
            "title": workbook.add_format({"bold": True, "font_size": 18, "font_color": "#FFFFFF", "bg_color": navy}),
            "section": workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": teal, "align": "center", "border": 1}),
            "header": workbook.add_format({"bold": True, "font_color": navy, "bg_color": pale, "align": "center", "border": 1}),
            "value": workbook.add_format({"border": 1, "valign": "top"}),
            "integer": workbook.add_format({"border": 1, "num_format": "#,##0", "valign": "top"}),
            "number": workbook.add_format({"border": 1, "num_format": "#,##0.000000", "valign": "top"}),
            "datetime": workbook.add_format({"border": 1, "num_format": "yyyy-mm-dd hh:mm:ss.000"}),
            "label": workbook.add_format({"bold": True, "font_color": navy, "bg_color": pale}),
            "note": workbook.add_format({
                "font_color": "#527080", "italic": True,
                "text_wrap": True, "valign": "top",
            }),
            "red": workbook.add_format({"bg_color": "#F8CBCB", "font_color": "#9C0006"}),
            "blue": workbook.add_format({"bg_color": "#DDEBF7", "font_color": "#1F4E78"}),
        }
        summary = workbook.add_worksheet("Protocol Insight Summary")
        summary.hide_gridlines(2); summary.set_column("A:A", 28); summary.set_column("B:B", 42)
        summary.write_string("A1", "Communication Hub Protocol Insight", formats["title"])
        for column in range(1, 6):
            summary.write_blank(0, column, None, formats["title"])
        rows = [
            ("Protocol Insight", config.get("name", "")), ("Protocol Insight ID", config.get("id", "")),
            ("Generated local", now.isoformat()), ("Local time zone", local_timezone_name()),
            ("Samples", len(samples)),
            ("Streams", len(blocks)), ("Series", len(_series_names(config))),
            ("First sample (local)", min((_local_time(item["sample_time"]) for item in samples), default="")),
            ("Last sample (local)", max((_local_time(item["sample_time"]) for item in samples), default="")),
        ]
        for row, (label, value) in enumerate(rows, 3):
            summary.write_string(row, 0, label, formats["label"])
            summary.write_string(row, 1, _text(value), formats["value"])

        all_logs = workbook.add_worksheet(ALIGNED_TIMELINE_SHEET)
        all_logs.freeze_panes(2, 1); all_logs.hide_gridlines(2)
        all_logs.write_string(0, 0, "GlobalTime", formats["section"])
        all_logs.write_string(1, 0, "sample_time", formats["header"])
        all_logs.set_column(0, 0, 24)
        for block in blocks:
            start, end = block["start_column"], block["end_column"]
            block_width = max(1, end - start + 1)
            header_width = (len(str(block["label"])) + 3 + block_width - 1) // block_width
            if end > start:
                all_logs.merge_range(0, start, 0, end, block["label"], formats["section"])
            else:
                all_logs.write_string(0, start, block["label"], formats["section"])
            for offset, series_name in enumerate(block["series"]):
                all_logs.write_string(1, start + offset, series_name, formats["header"])
                all_logs.set_column(
                    start + offset, start + offset,
                    min(42, max(14, len(series_name) + 3, header_width)),
                )
        block_by_key = {
            tuple(block[field] for field in IDENTITY_FIELDS): block for block in blocks
        }
        for row_index, (timestamp, row_streams) in enumerate(aligned, 2):
            all_logs.write_datetime(
                row_index, 0, _excel_datetime(timestamp), formats["datetime"]
            )
            for key, sample in row_streams.items():
                block = block_by_key[key]
                for offset, series_name in enumerate(block["series"]):
                    _write_value(
                        all_logs, row_index, block["start_column"] + offset,
                        sample.get(series_name), formats,
                    )
        if aligned:
            all_logs.autofilter(1, 0, 1 + len(aligned), max(block["end_column"] for block in blocks))
        for block in blocks:
            thresholds = {
                str(series.get("name")): series.get("thresholds", {})
                for series in config.get("series", [])
            }
            for offset, series_name in enumerate(block["series"]):
                column = block["start_column"] + offset
                rule = thresholds.get(series_name, {})
                if "max" in rule and aligned:
                    all_logs.conditional_format(2, column, 1 + len(aligned), column, {
                        "type": "cell", "criteria": ">", "value": rule["max"], "format": formats["red"],
                    })
                if "min" in rule and aligned:
                    all_logs.conditional_format(2, column, 1 + len(aligned), column, {
                        "type": "cell", "criteria": "<", "value": rule["min"], "format": formats["blue"],
                    })

        frame = pd.DataFrame(samples)
        samples_sheet = workbook.add_worksheet(SAMPLE_RECORDS_SHEET)
        samples_sheet.hide()
        samples_sheet.freeze_panes(1, 0); samples_sheet.hide_gridlines(2)
        columns = list(frame.columns)
        for column, name in enumerate(columns):
            samples_sheet.write_string(0, column, str(name), formats["header"])
            width = 24 if name in {"sample_time", "observed_at", "first_timestamp"} else (
                20 if name == "peer" else max(12, min(45, len(str(name)) + 3))
            )
            samples_sheet.set_column(column, column, width)
        for row_index, record in enumerate(frame.to_dict("records"), 1):
            for column, name in enumerate(columns):
                value = record.get(name)
                if name in {"sample_time", "observed_at"} and value not in {None, ""}:
                    timestamp = _sample_time(value)
                    samples_sheet.write_datetime(row_index, column, _excel_datetime(timestamp), formats["datetime"])
                else:
                    _write_value(samples_sheet, row_index, column, value, formats)
        if columns:
            samples_sheet.autofilter(0, 0, max(1, len(frame)), len(columns) - 1)

        statistics = workbook.add_worksheet("Statistics")
        statistics.hide_gridlines(2)
        statistics.merge_range("A1:W1", "Protocol Insight Statistics", formats["title"])
        statistics.merge_range(
            "A2:W3",
            "Threshold analysis is calculated from the complete exported insight dataset. "
            "A threshold-specific result is shown as Undefined when that series has no threshold; "
            "zero means a defined condition was evaluated and did not occur.",
            formats["note"],
        )
        summary_rows, state_rows, transition_rows = _threshold_statistics(config, samples, blocks)
        summary_headers = [
            "Stream", "Series", "Threshold status", "Minimum", "Maximum", "Equal target",
            "Not-equal target", "Samples", "Valid", "Missing", "First sample (local)",
            "Last sample (local)", "Observed duration (s)", "Mean sample interval (s)",
            "Observed minimum", "Observed maximum", "Mean", "Std deviation",
            "Breach samples", "Breach samples (%)", "Breach duration (s)",
            "Breach duration (%)", "State transitions",
        ]
        statistics.write_row(4, 0, summary_headers, formats["header"])
        for row, values in enumerate(summary_rows, 5):
            for column, value in enumerate(values):
                _write_value(statistics, row, column, value, formats)
        cursor = 6 + len(summary_rows)
        statistics.merge_range(cursor, 0, cursor, 10, "Threshold state occupancy and dwell time", formats["section"])
        cursor += 1
        state_headers = [
            "Stream", "Series", "State", "Samples", "Samples (%)", "Duration (s)",
            "Duration (%)", "Entries", "Average dwell (s)", "Minimum dwell (s)",
            "Maximum dwell (s)",
        ]
        statistics.write_row(cursor, 0, state_headers, formats["header"]); cursor += 1
        if state_rows:
            for values in state_rows:
                for column, value in enumerate(values):
                    _write_value(statistics, cursor, column, value, formats)
                cursor += 1
        else:
            statistics.merge_range(cursor, 0, cursor, 10, "Undefined — no series has a threshold.", formats["note"])
            cursor += 1
        cursor += 1
        statistics.merge_range(cursor, 0, cursor, 7, "Transitions between threshold states", formats["section"])
        cursor += 1
        transition_headers = [
            "Stream", "Series", "From state", "To state", "Transitions",
            "Average transition gap (s)", "Minimum gap (s)", "Maximum gap (s)",
        ]
        statistics.write_row(cursor, 0, transition_headers, formats["header"]); cursor += 1
        if transition_rows:
            for values in transition_rows:
                for column, value in enumerate(values):
                    _write_value(statistics, cursor, column, value, formats)
                cursor += 1
        else:
            statistics.merge_range(cursor, 0, cursor, 7, "Undefined — no threshold-state transitions occurred.", formats["note"])
        statistics.set_column("A:A", 38); statistics.set_column("B:B", 26)
        statistics.set_column("C:W", 18); statistics.freeze_panes(5, 2)

        configuration = workbook.add_worksheet("Configuration")
        configuration.hide()
        configuration.hide_gridlines(2)
        configuration.freeze_panes(1, 0)
        configuration.set_column("A:A", 28); configuration.set_column("B:B", 90)
        configuration.write_row("A1", ["Property", "Value"], formats["header"])
        configuration_rows = []
        for key, value in config.items():
            if key == "series":
                for index, series in enumerate(value if isinstance(value, list) else [], 1):
                    label = f"Series {index}: {series.get('name', 'Value')}"
                    text = json.dumps(series, indent=2, ensure_ascii=False, default=_json_default)
                    configuration_rows.append((label, text))
                continue
            text = (
                json.dumps(value, indent=2, ensure_ascii=False, default=_json_default)
                if isinstance(value, (dict, list)) else _text(value)
            )
            configuration_rows.append((str(key), text))
        for row, (label, text) in enumerate(configuration_rows, 1):
            configuration.write_string(row, 0, label, formats["label"])
            configuration.write_string(row, 1, text, formats["note"])
            line_count = max(1, text.count("\n") + 1)
            configuration.set_row(row, min(409, max(18, line_count * 13)))

        history = workbook.add_worksheet("Append History")
        history.hide()
        history_headers = [
            "Timestamp (local)", "Previous Samples", "Added", "Skipped", "Replaced",
            "Result Samples", "Mode",
        ]
        history.write_row(0, 0, history_headers, formats["header"])
        for row, item in enumerate(append_history or [], 1):
            stamp = item.get("timestamp", "")
            try:
                stamp = local_iso(stamp) if stamp else ""
            except (TypeError, ValueError):
                stamp = _text(stamp)
            history.write_row(row, 0, [
                stamp, item.get("previous", 0), item.get("added", 0),
                item.get("skipped", 0), item.get("replaced", 0),
                item.get("result", 0), item.get("mode", ""),
            ], formats["value"])
        history.set_column("A:A", 27); history.set_column("B:G", 18)

        manifest["configured_plots"] = add_configured_protocol_insight_plots(
            workbook, config, samples,
        )
        manifest_sheet = workbook.add_worksheet("_ProtocolInsightManifest")
        manifest_sheet.write_string(
            "A1", json.dumps(manifest, ensure_ascii=False, default=_json_default)
        )
        manifest_sheet.hide()
        workbook.set_properties({
            "title": f"Protocol Insight - {config.get('name', '')}",
            "subject": WORKBOOK_TYPE,
            "author": "Communication Hub",
        })
    except BaseException:
        workbook.close()
        temporary.unlink(missing_ok=True)
        raise
    workbook.close()
    os.replace(temporary, destination)
    return {
        "path": str(destination), "samples": len(samples), "streams": len(blocks),
        "series": len(_series_names(config)), "manifest": manifest,
    }


def _expanded_headers(sheet) -> list[str]:
    headers = [sheet.cell(1, column).value for column in range(1, sheet.max_column + 1)]
    for merged in sheet.merged_cells.ranges:
        if merged.min_row <= 1 <= merged.max_row:
            value = sheet.cell(merged.min_row, merged.min_col).value
            for column in range(merged.min_col, merged.max_col + 1):
                headers[column - 1] = value
    current = ""
    for index, value in enumerate(headers):
        if value not in {None, ""}:
            current = str(value)
        else:
            headers[index] = current
    return [str(value or "") for value in headers]


def read_formatted_protocol_insight_workbook(path: str | Path) -> dict:
    if openpyxl is None:
        raise RuntimeError("Formatted Protocol Insight Excel import requires OpenPyXL")
    workbook = openpyxl.load_workbook(path, data_only=True, read_only=False)
    try:
        if "_ProtocolInsightManifest" not in workbook.sheetnames:
            raise ValueError("Workbook is not a versioned Communication Hub Protocol Insight workbook")
        raw = workbook["_ProtocolInsightManifest"]["A1"].value
        manifest = json.loads(raw) if raw else None
        if not isinstance(manifest, dict) or manifest.get("workbook_type") != WORKBOOK_TYPE:
            raise ValueError("Workbook has an unsupported Protocol Insight manifest")
        if int(manifest.get("schema_version", 0)) != WORKBOOK_SCHEMA_VERSION:
            raise ValueError("Workbook uses an unsupported Protocol Insight schema version")
        timeline_sheet_name = str(manifest.get("aligned_timeline_sheet", ALIGNED_TIMELINE_SHEET))
        if timeline_sheet_name not in workbook.sheetnames:
            raise ValueError(f"Workbook does not contain {timeline_sheet_name!r}")
        sheet = workbook[timeline_sheet_name]
        blocks = manifest.get("blocks", [])
        if not isinstance(blocks, list):
            raise ValueError("Protocol Insight workbook manifest has invalid blocks")
        data_start = int(manifest.get("data_start_row", 3))
        data_end = int(manifest.get("data_end_row", 2))
        samples = []
        for row in range(data_start, data_end + 1):
            timestamp = sheet.cell(row, 1).value
            if timestamp in {None, ""}:
                continue
            timestamp = _timestamp_from_excel(
                timestamp, local_time=manifest.get("excel_time_zone") == "local",
            )
            for block in blocks:
                values = {}
                has_value = False
                start_column = int(block["start_column"]) + 1
                for offset, field in enumerate(block.get("series", [])):
                    value = sheet.cell(row, start_column + offset).value
                    values[field] = value
                    has_value = has_value or value not in {None, ""}
                if not has_value:
                    continue
                sample = {
                    "sample_time": timestamp,
                    "event_id": None,
                    "session_id": block.get("session_id", ""),
                    "protocol": block.get("protocol", ""),
                    "direction": block.get("direction", ""),
                    "message": block.get("message", block.get("label", "")),
                    "connection_id": block.get("connection_id", ""),
                    "peer": "",
                }
                sample.update(values)
                samples.append(sample)
        history = []
        if "Append History" in workbook.sheetnames:
            history_sheet = workbook["Append History"]
            for row in range(2, history_sheet.max_row + 1):
                values = [history_sheet.cell(row, column).value for column in range(1, 8)]
                if any(value is not None for value in values):
                    history.append(dict(zip(
                        ("timestamp", "previous", "added", "skipped", "replaced", "result", "mode"),
                        values,
                    )))
        return {"samples": samples, "manifest": manifest, "history": history}
    finally:
        workbook.close()


def inspect_protocol_insight_workbook(path: str | Path, config: dict) -> dict:
    imported = read_formatted_protocol_insight_workbook(path)
    expected = set(_series_names(config))
    existing = set(imported["manifest"].get("series", []))
    missing = sorted(expected - existing)
    additional = sorted(existing - expected)
    protocol_insight_id = str(imported["manifest"].get("protocol_insight_id", ""))
    same_protocol_insight = not protocol_insight_id or protocol_insight_id == str(config.get("id", ""))
    policy = str(config.get("excel", {}).get("schema_policy", "strict"))
    if policy == "extend":
        compatible = True
    elif policy == "compatible":
        compatible = not missing
    else:
        compatible = same_protocol_insight and existing == expected
    timestamps = [_sample_time(sample["sample_time"]) for sample in imported["samples"]]
    return {
        "path": str(path), "compatible": compatible,
        "same_protocol_insight": same_protocol_insight,
        "missing_series": missing,
        "additional_series": additional, "samples": len(imported["samples"]),
        "schema_policy": policy,
        "first_timestamp": local_iso(min(timestamps)) if timestamps else "",
        "last_timestamp": local_iso(max(timestamps)) if timestamps else "",
        "manifest": imported["manifest"],
    }


def _conflict_key(sample: dict):
    timestamp = local_iso(sample.get("sample_time"))
    return (*_stream_key(sample), timestamp)


def append_formatted_protocol_insight_workbook(
    path: str | Path,
    config: dict,
    new_samples: list[dict],
) -> dict:
    destination = Path(path)
    if not destination.exists():
        return write_formatted_protocol_insight_workbook(destination, config, new_samples)
    imported = read_formatted_protocol_insight_workbook(destination)
    excel = config.get("excel", {})
    policy = excel.get("append_conflict", "reject")
    schema_policy = excel.get("schema_policy", "strict")
    expected_series = set(_series_names(config))
    existing_series = set(imported["manifest"].get("series", []))
    protocol_insight_id = str(imported["manifest"].get("protocol_insight_id", ""))
    if schema_policy == "strict":
        if protocol_insight_id != str(config.get("id", "")):
            raise ValueError("Append rejected: workbook belongs to a different Protocol Insight")
        if existing_series != expected_series:
            raise ValueError(
                f"Append rejected: series mismatch; existing={sorted(existing_series)}, "
                f"configured={sorted(expected_series)}"
            )
    elif schema_policy == "compatible" and not expected_series.issubset(existing_series):
        raise ValueError(
            f"Append rejected: workbook is missing configured series "
            f"{sorted(expected_series - existing_series)}"
        )

    old_samples = imported["samples"]
    result = copy.deepcopy(old_samples)
    positions = {
        _conflict_key(sample): index
        for index, sample in enumerate(result)
    }
    added = skipped = replaced = 0
    overlaps = []
    for sample in new_samples:
        key = _conflict_key(sample)
        if key not in positions or policy == "keep_both":
            positions[key] = len(result); result.append(copy.deepcopy(sample)); added += 1
        elif policy == "skip":
            skipped += 1
        elif policy == "replace":
            result[positions[key]] = copy.deepcopy(sample); replaced += 1
        else:
            overlaps.append(key)
    if overlaps:
        raise ValueError(
            f"Append rejected: {len(overlaps):,} overlapping sample identities; "
            f"first overlap={overlaps[0]}"
        )
    history = imported.get("history", [])
    history.append({
        "timestamp": local_now().isoformat(),
        "previous": len(old_samples), "added": added, "skipped": skipped,
        "replaced": replaced, "result": len(result), "mode": policy,
    })
    backup = None
    if excel.get("backup_before_rewrite", True):
        backup = destination.with_name(
            f"{destination.stem}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        )
        shutil.copy2(destination, backup)
    exported = write_formatted_protocol_insight_workbook(
        destination, config, result, append_history=history
    )
    exported.update({
        "previous": len(old_samples), "added": added, "skipped": skipped,
        "replaced": replaced, "backup": str(backup) if backup else "",
    })
    return exported
