from __future__ import annotations

import copy
import math
import numbers
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Callable, Iterable

from .insight_processor_runtime import InsightProcessorRuntime, InsightValueContext
from .local_time import timestamp_ns
from .query import QueryEngine


ValueReader = Callable[[dict[str, Any], dict[str, Any]], Any]


@dataclass(frozen=True)
class InsightSample:
    """Engine output shared by historical display and the live insight dataset."""

    sample_time: Any
    sample_time_ns: int
    event_id: Any
    session_id: Any
    protocol: Any
    direction: Any
    message: Any
    connection_id: Any
    peer: Any
    x: float | None
    values: dict[str, Any] = field(default_factory=dict)
    labels: dict[str, Any] = field(default_factory=dict)
    statuses: dict[str, str] = field(default_factory=dict)
    matched_series: frozenset[str] = field(default_factory=frozenset)

    def dataset_record(self, *, threshold_details: bool = False) -> dict[str, Any]:
        result = {
            "sample_time": self.sample_time,
            "sample_time_ns": self.sample_time_ns,
            "event_id": self.event_id,
            "session_id": self.session_id,
            "protocol": self.protocol,
            "direction": self.direction,
            "message": self.message,
            "connection_id": self.connection_id,
            "peer": self.peer,
            "__series_values": copy.deepcopy(self.values),
            "__insights_x": self.x,
        }
        for series_id, value in self.values.items():
            label = str(self.labels.get(series_id, series_id))
            result[label] = value
            status = self.statuses.get(series_id, "")
            if status:
                result[f"{label}__status"] = status
            if threshold_details:
                result[f"{label}__missing"] = value is None
                result[f"{label}__above_max"] = status == "above_max"
                result[f"{label}__below_min"] = status == "below_min"
        return result


class ProtocolInsightEngine:
    """Pure processing runtime for both retained records and live messages.

    The engine deliberately knows nothing about Qt, session controllers, storage,
    retention, or Excel.  Callers provide a source adapter (`value_reader`) and
    consume normalized :class:`InsightSample` objects.
    """

    def __init__(
        self,
        *,
        engine_id: str,
        series: Iterable[dict[str, Any]],
        value_reader: ValueReader,
        x_axis: dict[str, Any] | None = None,
        source_query: dict[str, Any] | None = None,
    ):
        self.engine_id = str(engine_id or "")
        self.series = [copy.deepcopy(item) for item in series if item.get("enabled", True)]
        self.value_reader = value_reader
        self.x_axis = copy.deepcopy(x_axis or {"kind": "timestamp"})
        self.source_query = copy.deepcopy(source_query or {})
        self.query_engine = QueryEngine()
        self.diagnostics: dict[str, Any] = {"count": 0, "errors": []}
        self._processors = self._create_processors(self.series)
        self._x_processor = self._create_processor(
            self.x_axis.get("processor"), self.x_axis.get("label", "X processor")
        )

    def _record_error(self, label: str, error: BaseException):
        self.diagnostics["count"] += 1
        message = f"{label}: {type(error).__name__}: {error}"[:1000]
        if message not in self.diagnostics["errors"] and len(self.diagnostics["errors"]) < 20:
            self.diagnostics["errors"].append(message)

    def _create_processor(self, config, label):
        if not isinstance(config, dict) or not config.get("enabled"):
            return None
        try:
            return InsightProcessorRuntime(config)
        except BaseException as error:
            self._record_error(str(label), error)
            return False

    def _create_processors(self, series):
        return {
            str(item.get("id", "")): self._create_processor(
                item.get("processor"), item.get("label") or item.get("name") or "Y processor"
            )
            for item in series
        }

    def accepts(self, record: dict[str, Any]) -> bool:
        return not self.source_query or self.query_engine.matches_record(record, self.source_query)

    @staticmethod
    def _threshold_status(value: Any, thresholds: dict[str, Any]) -> str:
        if value is None or not thresholds:
            return ""
        try:
            minimum = thresholds.get("minimum", thresholds.get("min"))
            maximum = thresholds.get("maximum", thresholds.get("max"))
            equal = thresholds.get("equal", thresholds.get("eq"))
            not_equal = thresholds.get("not_equal", thresholds.get("noteq"))
            if minimum is not None and value < minimum:
                return "below_min"
            if maximum is not None and value > maximum:
                return "above_max"
            if equal is not None and value == equal:
                return "equal"
            if not_equal is not None and value != not_equal:
                return "not_equal"
            if minimum is not None or maximum is not None:
                return "within_range"
        except (TypeError, ValueError):
            return "threshold_error"
        return ""

    def _process_value(self, record, series, raw):
        series_id = str(series.get("id", ""))
        processor = series.get("processor", {})
        runtime = self._processors.get(series_id)
        if runtime is False:
            return None
        if runtime is not None:
            try:
                raw = runtime.process(raw, InsightValueContext(
                    axis="y", record=MappingProxyType(record), view_id=self.engine_id,
                    subplot_id=str(series.get("subplot_id")) if series.get("subplot_id") else None,
                    series_id=series_id,
                    label=str(series.get("label") or series.get("name") or ""),
                    options=MappingProxyType(processor.get("options", {})),
                ))
            except BaseException as error:
                self._record_error(str(series.get("label") or series.get("name") or "Y processor"), error)
                return None
        if raw is not None and not isinstance(raw, (bool, str, numbers.Real)):
            if runtime is not None:
                self._record_error(
                    str(series.get("label") or series.get("name") or "Y processor"),
                    TypeError(f"processor returned {type(raw).__name__}; expected scalar or None"),
                )
                return None
        if isinstance(raw, numbers.Real) and not isinstance(raw, bool):
            transform = series.get("transform", {})
            raw = float(raw) * float(transform.get("scale", 1.0)) + float(transform.get("offset", 0.0))
        return raw

    def _x_value(self, record: dict[str, Any]) -> float | None:
        config = self.x_axis
        try:
            value = record.get("timestamp_ns", record.get("timestamp")) if config.get("kind", "timestamp") == "timestamp" else self.value_reader(record, config)
        except BaseException as error:
            self._record_error(str(config.get("label", "X source")), error)
            return None
        processor = config.get("processor", {})
        if self._x_processor is False:
            return None
        if self._x_processor is not None:
            try:
                value = self._x_processor.process(value, InsightValueContext(
                    axis="x", record=MappingProxyType(record), view_id=self.engine_id,
                    label=str(config.get("label", "X")),
                    options=MappingProxyType(processor.get("options", {})),
                ))
            except BaseException as error:
                self._record_error(str(config.get("label", "X processor")), error)
                return None
        if value is None:
            return None
        # Timestamp axes always use Unix seconds at the engine/UI boundary.
        # Numeric message timestamps may be either seconds or nanoseconds, so
        # they must not pass through the generic numeric transform unchanged.
        if config.get("kind", "timestamp") == "timestamp" or config.get("value_type") == "datetime":
            try:
                numeric = timestamp_ns(value) / 1_000_000_000.0
            except (TypeError, ValueError, OverflowError, OSError):
                return None
        elif isinstance(value, numbers.Real) and not isinstance(value, bool):
            transform = config.get("transform", {})
            numeric = float(value) * float(transform.get("scale", 1.0)) + float(transform.get("offset", 0.0))
        else:
            try:
                numeric = float(value)
            except (TypeError, ValueError):
                return None
        return numeric if math.isfinite(numeric) else None

    def process_record(self, record: dict[str, Any]) -> InsightSample | None:
        if not self.accepts(record):
            return None
        values, labels, statuses, matched = {}, {}, {}, set()
        for series in self.series:
            series_id = str(series.get("id", ""))
            label = str(series.get("label") or series.get("name") or "Value")
            labels[series_id] = label
            query = series.get("query") or {}
            series_matches = not query or self.query_engine.matches_record(record, query)
            if series_matches:
                matched.add(series_id)
                try:
                    raw = self.value_reader(record, series.get("source", {}))
                except BaseException as error:
                    self._record_error(label, error)
                    raw = None
                value = self._process_value(record, series, raw)
            else:
                value = None
            values[series_id] = value
            status = self._threshold_status(value, series.get("thresholds", {}))
            if status:
                statuses[series_id] = status
        return InsightSample(
            sample_time=record.get("timestamp"), event_id=record.get("id"),
            sample_time_ns=timestamp_ns(record.get("timestamp_ns", record.get("timestamp"))),
            session_id=record.get("session_id"), protocol=record.get("protocol"),
            direction=record.get("direction"), message=record.get("name"),
            connection_id=record.get("connection_id", ""), peer=record.get("peer", ""),
            x=self._x_value(record), values=values, labels=labels,
            statuses=statuses, matched_series=frozenset(matched),
        )

    def process_records(self, records: Iterable[dict[str, Any]]) -> list[InsightSample]:
        output = []
        for record in records:
            sample = self.process_record(record)
            if sample is not None:
                output.append(sample)
        return output

    def close(self):
        for runtime in list(self._processors.values()) + [self._x_processor]:
            close = getattr(runtime, "close", None)
            if callable(close):
                close()


def insight_engine_series(view: dict[str, Any], *, export_only: bool = False) -> list[dict[str, Any]]:
    result = []
    for subplot in view.get("subplots", []):
        if subplot.get("kind") == "timeline":
            continue
        for series in subplot.get("series", []):
            if export_only and not series.get("export_enabled", True):
                continue
            item = copy.deepcopy(series)
            item["enabled"] = True
            item["subplot_id"] = subplot.get("id")
            result.append(item)
    return result
