from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .query import QueryEngine
from .local_time import (
    excel_local_datetime, local_now, local_timestamp_from_ns, local_timezone_name, timestamp_ns,
)

try:
    import xlsxwriter
except ImportError:  # pragma: no cover - runtime reports the optional dependency clearly.
    xlsxwriter = None


EXCEL_MAX_DATA_ROWS = 1_048_575
CELL_CHUNK_SIZE = 30_000

MESSAGE_COLUMNS = [
    ("id", "ID"), ("timestamp", "Timestamp (local)"), ("direction", "Direction"),
    ("protocol", "Protocol"), ("protocol_label", "Protocol Label"),
    ("session_name", "Session Name"), ("session_id", "Session ID"),
    ("name", "Message Name"), ("parsed", "Parsed"), ("data", "Data"),
    ("size", "Payload Size"), ("frame_size", "Frame Size"), ("header", "Header Hex"),
    ("header_fields", "Header Fields"), ("connection_id", "Connection ID"),
    ("peer", "Peer"), ("parse_status", "Parse Status"), ("parse_error", "Parse Error"),
    ("parse_duration_ns", "Parse Duration (µs)"), ("update_count", "Update Count"),
    ("first_timestamp", "First Timestamp (local)"),
]

NAME_COLUMNS = [
    ("name", "Message Name"), ("stored_rows", "Stored Rows"),
    ("occurrences", "Message Occurrences"), ("rx_occurrences", "RX Occurrences"),
    ("tx_occurrences", "TX Occurrences"), ("parsed_rows", "Parsed Rows"),
    ("parser_error_rows", "Parser Error Rows"), ("session_count", "Sessions"),
    ("protocols", "Protocols"), ("average_payload_size", "Average Payload Size"),
    ("maximum_payload_size", "Maximum Payload Size"),
    ("first_timestamp", "First Timestamp (local)"), ("last_timestamp", "Last Timestamp (local)"),
    ("occurrence_share", "Occurrence Share"),
]


def _json_default(value: Any):
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).hex().upper()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if hasattr(value, "item"):
        try:
            return value.item()
        except (TypeError, ValueError):
            pass
    return str(value)


def _text(value: Any) -> str:
    structured = (dict, list, tuple, np.ndarray, bytes, bytearray, memoryview)
    if value is None or (not isinstance(value, structured) and pd.isna(value)):
        return ""
    if isinstance(value, (bytes, bytearray, memoryview)):
        return "HEX: " + bytes(value).hex().upper()
    if isinstance(value, (dict, list, tuple, np.ndarray)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=_json_default)
    return str(value)


def _excel_datetime(value: Any):
    if value is None or pd.isna(value):
        return None
    return excel_local_datetime(value)


def _filtered_messages(sources: list[dict], query: dict, now: datetime) -> pd.DataFrame:
    query_engine = QueryEngine()
    frames = []
    for source in sources:
        frame = source["frame"]
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            continue
        selected = frame.loc[query_engine.mask(frame, query, now=now)].copy()
        if selected.empty:
            continue
        selected["session_name"] = str(source.get("session_name", ""))
        frames.append(selected)
    if not frames:
        return pd.DataFrame(columns=[key for key, _label in MESSAGE_COLUMNS])
    combined = pd.concat(frames, ignore_index=True, sort=False)
    sort_column = "timestamp_ns" if "timestamp_ns" in combined.columns else "timestamp"
    if sort_column in combined.columns:
        combined = combined.sort_values(sort_column, ascending=False, kind="stable")
    return combined.reset_index(drop=True)


def _messages_by_name(frame: pd.DataFrame) -> list[dict]:
    if frame.empty:
        return []
    working = frame.copy()
    working["name"] = working.get("name", pd.Series(index=working.index, dtype=object)).fillna("Unknown").astype(str)
    occurrences = working["update_count"] if "update_count" in working else pd.Series(1, index=working.index)
    sizes = working["size"] if "size" in working else pd.Series(0, index=working.index)
    parsed = working["parsed"] if "parsed" in working else pd.Series(False, index=working.index)
    parse_status = working["parse_status"] if "parse_status" in working else pd.Series("", index=working.index)
    working["_occurrences"] = pd.to_numeric(occurrences, errors="coerce").fillna(1).clip(lower=1)
    working["_size"] = pd.to_numeric(sizes, errors="coerce")
    working["_parsed"] = parsed.fillna(False).astype(bool)
    working["_parse_error"] = parse_status.fillna("").astype(str).eq("error")
    total_occurrences = float(working["_occurrences"].sum())
    result = []
    for name, group in working.groupby("name", sort=False, dropna=False):
        occurrences = float(group["_occurrences"].sum())
        directions = group.get("direction", pd.Series("", index=group.index)).astype(str)
        timestamp_values = pd.to_numeric(group.get("timestamp_ns"), errors="coerce") if "timestamp_ns" in group else group.get("timestamp").map(lambda value: timestamp_ns(value))
        first_values = pd.to_numeric(group.get("first_timestamp_ns"), errors="coerce") if "first_timestamp_ns" in group else group.get("first_timestamp", group.get("timestamp")).map(lambda value: timestamp_ns(value))
        protocols = sorted({str(value) for value in group.get("protocol", pd.Series(dtype=object)).dropna() if str(value)})
        sessions = {str(value) for value in group.get("session_id", pd.Series(dtype=object)).dropna() if str(value)}
        result.append({
            "name": str(name), "stored_rows": len(group), "occurrences": occurrences,
            "rx_occurrences": float(group.loc[directions == "RX", "_occurrences"].sum()),
            "tx_occurrences": float(group.loc[directions == "TX", "_occurrences"].sum()),
            "parsed_rows": int(group["_parsed"].sum()),
            "parser_error_rows": int(group["_parse_error"].sum()),
            "session_count": len(sessions), "protocols": ", ".join(protocols),
            "average_payload_size": float(group["_size"].mean()) if group["_size"].notna().any() else None,
            "maximum_payload_size": float(group["_size"].max()) if group["_size"].notna().any() else None,
            "first_timestamp": local_timestamp_from_ns(int(first_values.min())) if first_values.notna().any() else None,
            "last_timestamp": local_timestamp_from_ns(int(timestamp_values.max())) if timestamp_values.notna().any() else None,
            "occurrence_share": occurrences / total_occurrences if total_occurrences else 0.0,
        })
    result.sort(key=lambda row: (
        -float(row["occurrences"]),
        -(pd.Timestamp(row["last_timestamp"]).value if row["last_timestamp"] is not None else -1),
        str(row["name"]).casefold(),
    ))
    return result


def export_messages_excel(
    path: str | Path,
    sources: list[dict],
    query: dict | None,
    scope_label: str,
    *,
    generated_at: datetime | None = None,
) -> dict:
    """Export a coherent table snapshot and its active query to a styled Excel report."""
    if xlsxwriter is None:
        raise RuntimeError("Excel export requires the XlsxWriter package")
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.stem + ".tmp.xlsx")
    now = generated_at or local_now()
    if now.tzinfo is None:
        now = now.astimezone()
    active_query = query or {}
    frame = _filtered_messages(sources, active_query, now)
    name_rows = _messages_by_name(frame)

    workbook = xlsxwriter.Workbook(str(temporary), {"constant_memory": True, "nan_inf_to_errors": True})
    try:
        navy, teal, pale, grid = "#17324D", "#0F766E", "#EAF2F8", "#D8E1E8"
        title_format = workbook.add_format({
            "bold": True, "font_size": 20, "font_color": "#FFFFFF", "bg_color": navy,
            "align": "left", "valign": "vcenter",
        })
        section_format = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": teal})
        label_format = workbook.add_format({"bold": True, "font_color": navy, "bg_color": pale})
        value_format = workbook.add_format({"font_color": "#243746"})
        kpi_label = workbook.add_format({"bold": True, "font_color": "#527080", "align": "center"})
        kpi_value = workbook.add_format({"bold": True, "font_size": 16, "font_color": navy, "align": "center", "num_format": "#,##0"})
        header_format = workbook.add_format({
            "bold": True, "font_color": "#FFFFFF", "bg_color": navy, "align": "center",
            "valign": "vcenter", "border": 0,
        })
        text_format = workbook.add_format({"font_color": "#243746", "valign": "top"})
        wrap_format = workbook.add_format({"font_color": "#243746", "valign": "top", "text_wrap": True})
        number_format = workbook.add_format({"font_color": "#243746", "num_format": "#,##0", "valign": "top"})
        decimal_format = workbook.add_format({"font_color": "#243746", "num_format": "#,##0.000", "valign": "top"})
        percentage_format = workbook.add_format({"font_color": "#243746", "num_format": "0.0%", "valign": "top"})
        bool_format = workbook.add_format({"font_color": "#243746", "align": "center", "valign": "top"})
        datetime_format = workbook.add_format({"font_color": "#243746", "num_format": "yyyy-mm-dd hh:mm:ss.000", "valign": "top"})
        note_format = workbook.add_format({"font_color": "#527080", "italic": True, "text_wrap": True, "valign": "top"})
        rx_format = workbook.add_format({"bg_color": "#E8F5E9", "font_color": "#1B5E20"})
        tx_format = workbook.add_format({"bg_color": "#FFF4E5", "font_color": "#8A4B08"})
        error_format = workbook.add_format({"bg_color": "#FDECEC", "font_color": "#A12622"})

        summary = workbook.add_worksheet("Summary")
        summary.hide_gridlines(2)
        summary.set_column("A:A", 34); summary.set_column("B:B", 24)
        summary.set_column("C:E", 14); summary.set_column("F:G", 25); summary.set_column("H:H", 14)
        summary.set_row(0, 31); summary.set_row(1, 13)
        summary.write_string("A1", "Communication Hub — Message Export", title_format)
        for column in range(1, 8): summary.write_blank(0, column, None, title_format)
        for column in range(0, 8): summary.write_blank(1, column, None, title_format)
        summary.write("A4", "Export scope", label_format); summary.write_string("B4", scope_label, value_format)
        summary.write("A5", "Generated (local)", label_format)
        summary.write_datetime("B5", now.astimezone().replace(tzinfo=None), datetime_format)
        summary.write("A6", "Active query", label_format)
        summary.write_string("B6", json.dumps(active_query, ensure_ascii=False, sort_keys=True, default=_json_default), note_format)
        summary.set_row(5, 34)
        summary.write("A7", "Local time zone", label_format)
        summary.write_string("B7", local_timezone_name(), value_format)

        total = len(frame)
        directions = frame.get("direction", pd.Series(dtype=object)).astype(str)
        parsed = frame.get("parsed", pd.Series(dtype=bool)).fillna(False).astype(bool)
        statuses = frame.get("parse_status", pd.Series(dtype=object)).astype(str)
        metrics = [
            ("Exported rows", total), ("Received (RX)", int((directions == "RX").sum())),
            ("Sent (TX)", int((directions == "TX").sum())), ("Parsed rows", int(parsed.sum())),
            ("Parser errors", int((statuses == "error").sum())), ("Sessions", len(sources)),
            ("Message names", len(name_rows)),
        ]
        summary.write_row(8, 1, [label for label, _value in metrics], kpi_label)
        summary.write_row(9, 1, [value for _label, value in metrics], kpi_value)

        summary.write("A12", "Rows by session", section_format)
        summary.write_row("A13", ["Session", "Protocol", "Rows", "RX", "TX", "Last timestamp (local)"], header_format)
        session_rows = []
        if not frame.empty:
            for session_id, group in frame.groupby("session_id", dropna=False, sort=False):
                first = group.iloc[0]
                session_rows.append((
                    str(first.get("session_name", "")), str(first.get("protocol", "")), len(group),
                    int((group["direction"] == "RX").sum()), int((group["direction"] == "TX").sum()),
                    local_timestamp_from_ns(int(pd.to_numeric(group["timestamp_ns"], errors="coerce").max())) if "timestamp_ns" in group else group["timestamp"].max(), str(session_id),
                ))
        session_rows.sort(key=lambda item: pd.Timestamp(item[5]).value if pd.notna(item[5]) else -1, reverse=True)
        for row_index, row in enumerate(session_rows, 13):
            summary.write_string(row_index, 0, row[0], text_format)
            summary.write_string(row_index, 1, row[1], text_format)
            for column, value in enumerate(row[2:5], 2): summary.write_number(row_index, column, value, number_format)
            timestamp = _excel_datetime(row[5])
            if timestamp: summary.write_datetime(row_index, 5, timestamp, datetime_format)
        summary.autofilter(12, 0, max(12, 12 + len(session_rows)), 5)
        summary.freeze_panes(2, 0)

        name_summary_start = 15 + len(session_rows)
        summary.write(name_summary_start, 0, f"Top message names ({len(name_rows):,} distinct)", section_format)
        summary.write_row(
            name_summary_start + 1, 0,
            ["Message Name", "Occurrences", "Stored Rows", "RX", "TX", "Share", "Last Timestamp (local)"],
            header_format,
        )
        for offset, row in enumerate(name_rows[:10], name_summary_start + 2):
            summary.write_string(offset, 0, row["name"], text_format)
            for column, key in enumerate(("occurrences", "stored_rows", "rx_occurrences", "tx_occurrences"), 1):
                summary.write_number(offset, column, float(row[key]), number_format)
            summary.write_number(offset, 5, float(row["occurrence_share"]), percentage_format)
            timestamp = _excel_datetime(row["last_timestamp"])
            if timestamp: summary.write_datetime(offset, 6, timestamp, datetime_format)

        # The chart is directly backed by visible KPI values in C10:D10.
        if int((directions == "RX").sum()) + int((directions == "TX").sum()) > 0:
            chart = workbook.add_chart({"type": "doughnut"})
            chart.add_series({
                "name": "Traffic direction", "categories": "=Summary!$C$9:$D$9", "values": "=Summary!$C$10:$D$10",
                "points": [{"fill": {"color": "#2E7D32"}}, {"fill": {"color": "#EF8B2C"}}],
                "data_labels": {"value": True, "percentage": True},
            })
            chart.set_title({"name": "RX / TX traffic"}); chart.set_legend({"position": "bottom"})
            chart.set_style(10); chart.set_size({"width": 390, "height": 230})
            summary.insert_chart("I9", chart, {"x_offset": 8, "y_offset": 4})

        name_sheets = []
        name_rows_per_sheet = 1_048_572
        for name_index, row in enumerate(name_rows):
            sheet_number = name_index // name_rows_per_sheet + 1
            row_in_sheet = name_index % name_rows_per_sheet + 4
            if row_in_sheet == 4:
                sheet_name = "Messages by Name" if sheet_number == 1 else f"Names_{sheet_number}"
                name_sheet = workbook.add_worksheet(sheet_name); name_sheets.append(name_sheet)
                name_sheet.hide_gridlines(2); name_sheet.freeze_panes(4, 0)
                name_sheet.write_string(0, 0, "Messages by Name", title_format)
                for column in range(1, len(NAME_COLUMNS)): name_sheet.write_blank(0, column, None, title_format)
                name_sheet.write_string(
                    1, 0,
                    "Message Occurrences includes update-on-conflict replacements via update_count; Stored Rows is the current exported row count.",
                    note_format,
                )
                name_sheet.write_row(3, 0, [label for _key, label in NAME_COLUMNS], header_format)
                widths = [34, 13, 20, 16, 16, 13, 17, 11, 22, 21, 21, 24, 24, 17]
                for column, width in enumerate(widths): name_sheet.set_column(column, column, width)
            for column, (key, _label) in enumerate(NAME_COLUMNS):
                value = row[key]
                if key in {"first_timestamp", "last_timestamp"}:
                    converted = _excel_datetime(value)
                    if converted: name_sheet.write_datetime(row_in_sheet, column, converted, datetime_format)
                elif key == "occurrence_share":
                    name_sheet.write_number(row_in_sheet, column, float(value), percentage_format)
                elif key == "average_payload_size" and value is not None:
                    name_sheet.write_number(row_in_sheet, column, float(value), decimal_format)
                elif key in {
                    "stored_rows", "occurrences", "rx_occurrences", "tx_occurrences", "parsed_rows",
                    "parser_error_rows", "session_count", "maximum_payload_size",
                } and value is not None:
                    name_sheet.write_number(row_in_sheet, column, float(value), number_format)
                else:
                    name_sheet.write_string(row_in_sheet, column, _text(value), text_format)
        if not name_sheets:
            name_sheet = workbook.add_worksheet("Messages by Name"); name_sheets.append(name_sheet)
            name_sheet.hide_gridlines(2); name_sheet.freeze_panes(4, 0)
            name_sheet.write_string(0, 0, "Messages by Name", title_format)
            for column in range(1, len(NAME_COLUMNS)): name_sheet.write_blank(0, column, None, title_format)
            name_sheet.write_string(1, 0, "No message names matched the active export query.", note_format)
            name_sheet.write_row(3, 0, [label for _key, label in NAME_COLUMNS], header_format)
        for sheet_index, sheet in enumerate(name_sheets):
            rows_on_sheet = max(0, min(name_rows_per_sheet, len(name_rows) - sheet_index * name_rows_per_sheet))
            last_row = max(4, rows_on_sheet + 3)
            sheet.autofilter(3, 0, last_row, len(NAME_COLUMNS) - 1)
            sheet.conditional_format(4, 2, last_row, 2, {
                "type": "data_bar", "bar_color": "#0F766E", "bar_solid": True,
            })

        details = workbook.add_worksheet("Export Details")
        details.hide_gridlines(2); details.set_column("A:A", 24); details.set_column("B:B", 110)
        details.write_row("A1", ["Property", "Value"], header_format)
        detail_rows = [
            ("Scope", scope_label), ("Generated local", now.astimezone().isoformat()),
            ("Local time zone", local_timezone_name()),
            ("Exported rows", str(total)), ("Distinct message names", str(len(name_rows))),
            ("Source sessions", str(len(sources))),
            ("Active query JSON", json.dumps(active_query, indent=2, ensure_ascii=False, sort_keys=True, default=_json_default)),
            ("Large-cell handling", "Values exceeding Excel's cell limit are preserved as numbered chunks in the Overflow sheet."),
        ]
        for row_index, (label, value) in enumerate(detail_rows, 1):
            details.write_string(row_index, 0, label, label_format)
            details.write_string(row_index, 1, value, wrap_format)
        details.set_row(7, 90); details.freeze_panes(1, 0)

        overflow = workbook.add_worksheet("Overflow")
        overflow.hide_gridlines(2); overflow.write_row(0, 0, ["Session ID", "Message ID", "Field", "Part", "Content"], header_format)
        overflow.set_column("A:A", 38); overflow.set_column("B:B", 13); overflow.set_column("C:C", 22)
        overflow.set_column("D:D", 9); overflow.set_column("E:E", 110)
        overflow.freeze_panes(1, 0); overflow_row = 1

        data_sheets = []
        current_sheet = None
        for frame_index, record in frame.iterrows():
            sheet_number = frame_index // EXCEL_MAX_DATA_ROWS + 1
            row_in_sheet = frame_index % EXCEL_MAX_DATA_ROWS + 1
            if row_in_sheet == 1:
                sheet_name = "Messages" if sheet_number == 1 else f"Messages_{sheet_number}"
                current_sheet = workbook.add_worksheet(sheet_name); data_sheets.append(current_sheet)
                current_sheet.hide_gridlines(2); current_sheet.freeze_panes(1, 0)
                current_sheet.write_row(0, 0, [label for _key, label in MESSAGE_COLUMNS], header_format)
                current_sheet.set_row(0, 27)
                widths = [11, 24, 11, 14, 18, 24, 38, 24, 10, 52, 14, 13, 28, 42, 18, 25, 15, 40, 19, 14, 24]
                for column, width in enumerate(widths): current_sheet.set_column(column, column, width)

            session_id = _text(record.get("session_id")); message_id = record.get("id", "")
            for column, (key, _label) in enumerate(MESSAGE_COLUMNS):
                value = record.get(key)
                if key in {"timestamp", "first_timestamp"}:
                    converted = _excel_datetime(value)
                    if converted: current_sheet.write_datetime(row_in_sheet, column, converted, datetime_format)
                elif key in {"id", "size", "frame_size", "update_count"} and pd.notna(value):
                    current_sheet.write_number(row_in_sheet, column, float(value), number_format)
                elif key == "parse_duration_ns" and pd.notna(value):
                    current_sheet.write_number(row_in_sheet, column, float(value) / 1000.0, decimal_format)
                elif key == "parsed" and pd.notna(value):
                    current_sheet.write_boolean(row_in_sheet, column, bool(value), bool_format)
                else:
                    content = _text(value)
                    chunks = [content[index:index + CELL_CHUNK_SIZE] for index in range(0, len(content), CELL_CHUNK_SIZE)] or [""]
                    display = chunks[0] + ("\n[Continued in Overflow sheet]" if len(chunks) > 1 else "")
                    current_sheet.write_string(row_in_sheet, column, display, wrap_format if key in {"data", "header_fields", "parse_error"} else text_format)
                    if len(chunks) > 1:
                        for part, chunk in enumerate(chunks, 1):
                            overflow.write_string(overflow_row, 0, session_id, text_format)
                            if isinstance(message_id, (int, float)) and not pd.isna(message_id):
                                overflow.write_number(overflow_row, 1, float(message_id), number_format)
                            else:
                                overflow.write_string(overflow_row, 1, _text(message_id), text_format)
                            overflow.write_string(overflow_row, 2, key, text_format)
                            overflow.write_number(overflow_row, 3, part, number_format)
                            overflow.write_string(overflow_row, 4, chunk, wrap_format)
                            overflow_row += 1

        if not data_sheets:
            current_sheet = workbook.add_worksheet("Messages"); data_sheets.append(current_sheet)
            current_sheet.hide_gridlines(2); current_sheet.freeze_panes(1, 0)
            current_sheet.write_row(0, 0, [label for _key, label in MESSAGE_COLUMNS], header_format)
        for sheet_index, sheet in enumerate(data_sheets):
            sheet_rows = max(0, min(EXCEL_MAX_DATA_ROWS, total - sheet_index * EXCEL_MAX_DATA_ROWS))
            last_row = max(1, sheet_rows)
            sheet.autofilter(0, 0, last_row, len(MESSAGE_COLUMNS) - 1)
            sheet.conditional_format(1, 2, last_row, 2, {"type": "text", "criteria": "containing", "value": "RX", "format": rx_format})
            sheet.conditional_format(1, 2, last_row, 2, {"type": "text", "criteria": "containing", "value": "TX", "format": tx_format})
            sheet.conditional_format(1, 16, last_row, 16, {"type": "text", "criteria": "containing", "value": "error", "format": error_format})
        overflow.autofilter(0, 0, max(1, overflow_row - 1), 4)
        if overflow_row == 1:
            overflow.write_string(1, 0, "No oversized values were present in this export.", note_format)

        workbook.set_properties({
            "title": "Communication Hub Message Export", "subject": scope_label,
            "author": "Communication Hub", "comments": "Generated from the current Message Table query.",
        })
    except BaseException:
        workbook.close()
        temporary.unlink(missing_ok=True)
        raise
    workbook.close()
    os.replace(temporary, destination)
    return {
        "path": str(destination), "rows": len(frame), "names": len(name_rows),
        "sheets": len(data_sheets), "name_sheets": len(name_sheets), "overflow_parts": overflow_row - 1,
    }
