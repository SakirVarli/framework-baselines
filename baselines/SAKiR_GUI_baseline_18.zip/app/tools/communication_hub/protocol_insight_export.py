from __future__ import annotations

"""Protocol Insight workbook export."""

import io
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from .excel_export import _excel_datetime, _json_default, _text, xlsxwriter
from .local_time import local_datetime_from_ns, local_now, timestamp_ns

if xlsxwriter is not None:
    from xlsxwriter.utility import cell_autofit_width
else:  # pragma: no cover - export reports the missing optional dependency.
    cell_autofit_width = None


EXCEL_DATA_ROWS = 1_048_571


def _x_value(value: Any, x_axis: dict) -> tuple[Any, bool]:
    is_datetime = (
        x_axis.get("value_type") == "datetime"
        and x_axis.get("timestamp_mode", "exact") == "exact"
    )
    if not is_datetime:
        return value, False
    try:
        return local_datetime_from_ns(int(float(value) * 1_000_000_000)).replace(tzinfo=None), True
    except (TypeError, ValueError, OSError):
        return _text(value), False


def _record_key(record: dict) -> tuple:
    return (
        str(record.get("session_id", "")), _text(record.get("id")),
        _text(record.get("timestamp")), str(record.get("direction", "")),
    )


def _contributing_records(result: dict) -> list[dict]:
    records = {}
    for plot in result.get("plots", []):
        for series in plot.get("series", []):
            for point in series.get("points", []):
                record = point[2]
                records.setdefault(_record_key(record), record)
        for point in plot.get("timeline", {}).get("points", []):
            record = point[2]
            records.setdefault(_record_key(record), record)
    for marker in result.get("event_markers", []):
        for point in marker.get("points", []):
            record = point[1]
            records.setdefault(_record_key(record), record)
    return sorted(
        records.values(),
        key=lambda row: int(row.get("timestamp_ns") or timestamp_ns(row.get("timestamp"))),
    )


def _formats(workbook):
    navy, teal, pale = "#17324D", "#0F766E", "#EAF2F8"
    return {
        "title": workbook.add_format({
            "bold": True, "font_size": 20, "font_color": "#FFFFFF",
            "bg_color": navy, "valign": "vcenter",
        }),
        "section": workbook.add_format({
            "bold": True, "font_color": "#FFFFFF", "bg_color": teal,
        }),
        "label": workbook.add_format({
            "bold": True, "font_color": navy, "bg_color": pale,
        }),
        "value": workbook.add_format({"font_color": "#243746", "valign": "top"}),
        "wrap": workbook.add_format({
            "font_color": "#243746", "valign": "top", "text_wrap": True,
        }),
        "header": workbook.add_format({
            "bold": True, "font_color": "#FFFFFF", "bg_color": navy,
            "align": "center", "valign": "vcenter",
        }),
        "integer": workbook.add_format({
            "font_color": "#243746", "num_format": "#,##0", "valign": "top",
        }),
        "decimal": workbook.add_format({
            "font_color": "#243746", "num_format": "#,##0.000000",
            "valign": "top",
        }),
        "datetime": workbook.add_format({
            "font_color": "#243746", "num_format": "yyyy-mm-dd hh:mm:ss.000",
            "valign": "top",
        }),
        "note": workbook.add_format({
            "font_color": "#527080", "italic": True, "text_wrap": True,
            "valign": "top",
        }),
        "kpi_label": workbook.add_format({
            "bold": True, "font_color": "#527080", "align": "center",
        }),
        "kpi": workbook.add_format({
            "bold": True, "font_size": 16, "font_color": navy,
            "align": "center", "num_format": "#,##0",
        }),
    }


def _write_cell(sheet, row: int, column: int, value: Any, formats, kind: str = ""):
    if kind == "datetime":
        converted = _excel_datetime(value)
        if converted is not None:
            sheet.write_datetime(row, column, converted, formats["datetime"])
        return
    if kind == "x_datetime" and isinstance(value, datetime):
        sheet.write_datetime(row, column, value, formats["datetime"])
    elif kind == "integer" and isinstance(value, (int, float)):
        sheet.write_number(row, column, float(value), formats["integer"])
    elif kind == "number" and isinstance(value, (int, float)):
        sheet.write_number(row, column, float(value), formats["decimal"])
    else:
        sheet.write_string(row, column, _text(value), formats["wrap"] if kind == "wrap" else formats["value"])


def _write_table_sheets(
    workbook, base_name: str, headers: list[str], rows: Iterable[list[tuple[Any, str]]],
    widths: list[int], formats,
) -> tuple[int, int]:
    sheet = None
    created_sheets = []
    sheet_count = total = row_index = 0
    for values in rows:
        if sheet is None or row_index > EXCEL_DATA_ROWS + 3:
            sheet_count += 1
            name = base_name if sheet_count == 1 else f"{base_name[:27]} {sheet_count}"
            sheet = workbook.add_worksheet(name)
            sheet.hide_gridlines(2); sheet.freeze_panes(4, 0)
            sheet.write_string(0, 0, base_name, formats["title"])
            for column in range(1, len(headers)):
                sheet.write_blank(0, column, None, formats["title"])
            sheet.write_string(1, 0, "This sheet contains the exact data represented by the exported Protocol Insight snapshot.", formats["note"])
            sheet.write_row(3, 0, headers, formats["header"])
            for column, width in enumerate(widths):
                sheet.set_column(column, column, width)
            row_index = 4
            created_sheets.append([sheet, 0])
        for column, (value, kind) in enumerate(values):
            _write_cell(sheet, row_index, column, value, formats, kind)
        row_index += 1; total += 1; created_sheets[-1][1] += 1
    if sheet is None:
        sheet_count = 1
        sheet = workbook.add_worksheet(base_name)
        sheet.hide_gridlines(2); sheet.freeze_panes(4, 0)
        sheet.write_string(0, 0, base_name, formats["title"])
        for column in range(1, len(headers)):
            sheet.write_blank(0, column, None, formats["title"])
        sheet.write_string(1, 0, "No rows were present in this part of the current Protocol Insight view.", formats["note"])
        sheet.write_row(3, 0, headers, formats["header"])
        for column, width in enumerate(widths):
            sheet.set_column(column, column, width)
        created_sheets.append([sheet, 0])
    for created, row_count in created_sheets:
        created.autofilter(3, 0, max(4, row_count + 3), len(headers) - 1)
    return total, sheet_count


def export_protocol_insight_excel(
    path: str | Path,
    view: dict,
    result: dict,
    *,
    plot_image_png: bytes | None = None,
    generated_at: datetime | None = None,
) -> dict:
    """Export the exact rendered protocol-Protocol Insight snapshot to a styled workbook."""
    if xlsxwriter is None:
        raise RuntimeError("Protocol Insight Excel export requires the XlsxWriter package")
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.stem + ".tmp.xlsx")
    now = generated_at or local_now()
    if now.tzinfo is None:
        now = now.astimezone()
    x_axis = result.get("x_axis") or view.get("x_axis", {})
    plots = result.get("plots", [])
    marker_results = result.get("event_markers", [])
    series_count = sum(len(plot.get("series", [])) for plot in plots)
    timeline_count = sum(len(plot.get("timeline", {}).get("points", [])) for plot in plots)
    marker_count = sum(len(marker.get("points", [])) for marker in marker_results)
    records = _contributing_records(result)

    workbook = xlsxwriter.Workbook(str(temporary), {"constant_memory": True, "nan_inf_to_errors": True})
    try:
        formats = _formats(workbook)
        dashboard = workbook.add_worksheet("Dashboard")
        dashboard.hide_gridlines(2); dashboard.set_row(0, 31)
        dashboard.set_column("A:A", 27); dashboard.set_column("B:B", 31)
        dashboard.set_column("C:H", 16)
        dashboard.write_string("A1", "Protocol Data Insight Export", formats["title"])
        for column in range(1, 8):
            dashboard.write_blank(0, column, None, formats["title"])
        details = [
            ("Insight view", view.get("name", "")),
            ("Generated (local)", now.astimezone().isoformat()),
            ("Scope", "All available sessions" if view.get("scope") == "global" else "Current session"),
            ("Display window", (
                "All recorded" if view.get("time_window", {}).get("mode") == "all"
                else f"Last {view.get('time_window', {}).get('amount')} {view.get('time_window', {}).get('unit')}"
            )),
            ("Shared X axis", f"{x_axis.get('label', '')} ({x_axis.get('value_type', '')})"),
        ]
        for row, (label, value) in enumerate(details, 3):
            dashboard.write_string(row, 0, label, formats["label"])
            dashboard.write_string(row, 1, _text(value), formats["value"])
        metrics = [
            ("Input rows", int(result.get("records", 0))),
            ("Plotted samples", int(result.get("samples", 0))),
            ("Subplots", len(plots)), ("Series", series_count),
            ("Timeline events", timeline_count), ("Marker hits", marker_count),
            ("Omitted", int(result.get("omitted_samples", 0))),
            ("Processor errors", int(result.get("processor_diagnostics", {}).get("count", 0))),
        ]
        dashboard.write_row(10, 0, [label for label, _value in metrics], formats["kpi_label"])
        dashboard.write_row(11, 0, [value for _label, value in metrics], formats["kpi"])
        dashboard.write_string(14, 0, "Subplot summary", formats["section"])
        dashboard.write_row(15, 0, ["Subplot", "Kind", "Series", "Samples", "Categories"], formats["header"])
        for row, plot in enumerate(plots, 16):
            config = plot.get("config", {})
            samples = (
                len(plot.get("timeline", {}).get("points", []))
                if config.get("kind") == "timeline"
                else sum(len(series.get("points", [])) for series in plot.get("series", []))
            )
            dashboard.write_row(row, 0, [
                config.get("title", ""), config.get("kind", "plot"),
                len(plot.get("series", [])), samples, len(plot.get("categories", {})),
            ], formats["value"])

        if plot_image_png:
            visual = workbook.add_worksheet("Visual Snapshot")
            visual.hide_gridlines(2)
            visual_title = "Rendered Insight View"
            visual_note = (
                "Static image captured from the plot area at the moment Export Current View was selected."
            )
            visual.set_column_pixels(
                0, 0, max(cell_autofit_width(visual_title), cell_autofit_width(visual_note))
            )
            visual.write_string("A1", visual_title, formats["title"])
            visual.write_string("A3", visual_note, formats["note"])
            visual.insert_image("A5", "protocol-insight-view.png", {
                "image_data": io.BytesIO(plot_image_png), "x_scale": 0.85, "y_scale": 0.85,
            })

        def series_rows():
            for plot in plots:
                subplot = plot.get("config", {})
                for series in plot.get("series", []):
                    config = series.get("config", {})
                    for index, point in enumerate(series.get("points", []), 1):
                        x, is_datetime = _x_value(point[0], x_axis)
                        record = point[2]
                        yield [
                            (subplot.get("title", ""), ""), (config.get("label", ""), ""),
                            (index, "integer"), (x, "x_datetime" if is_datetime else "number"),
                            (point[1], "number"), (point[3], ""),
                            (record.get("timestamp"), "datetime"), (record.get("id"), "integer"),
                            (record.get("session_name", ""), ""), (record.get("session_id", ""), ""),
                            (record.get("direction", ""), ""), (record.get("name", ""), ""),
                            (record.get("protocol", ""), ""), (record.get("connection_id", ""), ""),
                            (record.get("peer", ""), ""),
                        ]

        series_total, series_sheets = _write_table_sheets(
            workbook, "Series Samples",
            ["Subplot", "Series", "Sample", "X", "Plotted Y", "Original Value",
             "Message Timestamp (local)", "Message ID", "Session", "Session ID",
             "Direction", "Message", "Protocol", "Connection", "Peer"],
            series_rows(), [25, 25, 10, 24, 16, 24, 24, 12, 24, 38, 11, 25, 15, 20, 24], formats,
        )

        def timeline_rows():
            for plot in plots:
                config = plot.get("config", {})
                for index, point in enumerate(plot.get("timeline", {}).get("points", []), 1):
                    x, is_datetime = _x_value(point[0], x_axis); record = point[2]
                    yield [
                        (config.get("title", ""), ""), (index, "integer"), (point[4], ""),
                        (point[1], "number"), (x, "x_datetime" if is_datetime else "number"),
                        (point[3], ""), (record.get("timestamp"), "datetime"),
                        (record.get("id"), "integer"), (record.get("session_name", ""), ""),
                        (record.get("direction", ""), ""), (record.get("name", ""), ""),
                        (record.get("protocol", ""), ""),
                    ]

        timeline_total, timeline_sheets = _write_table_sheets(
            workbook, "Timeline Events",
            ["Subplot", "Event", "Lane", "Lane Index", "X", "Event Text",
             "Message Timestamp (local)", "Message ID", "Session", "Direction", "Message", "Protocol"],
            timeline_rows(), [25, 10, 35, 12, 24, 40, 24, 12, 24, 11, 25, 15], formats,
        )

        def marker_rows():
            subplot_titles = {
                plot.get("config", {}).get("id"): plot.get("config", {}).get("title", "")
                for plot in plots
            }
            for marker in marker_results:
                config = marker.get("config", {})
                targets = config.get("target_subplot_ids", [])
                target_text = (
                    "All subplots" if not targets
                    else ", ".join(subplot_titles.get(item, item) for item in targets)
                )
                for index, point in enumerate(marker.get("points", []), 1):
                    x, is_datetime = _x_value(point[0], x_axis); record = point[1]
                    yield [
                        (config.get("label", ""), ""), (config.get("trigger", ""), ""),
                        (target_text, ""), (index, "integer"),
                        (x, "x_datetime" if is_datetime else "number"),
                        (point[2], ""), (point[3], ""), (record.get("timestamp"), "datetime"),
                        (record.get("id"), "integer"), (record.get("session_name", ""), ""),
                        (record.get("direction", ""), ""), (record.get("name", ""), ""),
                    ]

        marker_total, marker_sheets = _write_table_sheets(
            workbook, "Event Markers",
            ["Marker", "Trigger", "Target Subplots", "Hit", "X", "Marker Text",
             "Compared Value", "Message Timestamp (local)", "Message ID", "Session", "Direction", "Message"],
            marker_rows(), [25, 14, 35, 10, 24, 40, 22, 24, 12, 24, 11, 25], formats,
        )

        def message_rows():
            for record in records:
                yield [
                    (record.get("id"), "integer"), (record.get("timestamp"), "datetime"),
                    (record.get("session_name", ""), ""), (record.get("session_id", ""), ""),
                    (record.get("direction", ""), ""), (record.get("protocol", ""), ""),
                    (record.get("name", ""), ""), (record.get("parsed", ""), ""),
                    (record.get("data"), "wrap"), (record.get("header_fields"), "wrap"),
                    (record.get("size"), "integer"), (record.get("frame_size"), "integer"),
                    (record.get("connection_id", ""), ""), (record.get("peer", ""), ""),
                    (record.get("parse_status", ""), ""), (record.get("parse_error", ""), "wrap"),
                    (record.get("update_count"), "integer"),
                ]

        message_total, message_sheets = _write_table_sheets(
            workbook, "Contributing Messages",
            ["ID", "Timestamp (local)", "Session", "Session ID", "Direction", "Protocol",
             "Message", "Parsed", "Data", "Header Fields", "Size", "Frame Size",
             "Connection", "Peer", "Parse Status", "Parse Error", "Update Count"],
            message_rows(), [12, 24, 24, 38, 11, 15, 25, 10, 52, 42, 12, 13, 20, 24, 15, 40, 14], formats,
        )

        config_sheet = workbook.add_worksheet("View Configuration")
        config_sheet.hide_gridlines(2); config_sheet.set_column("A:A", 28); config_sheet.set_column("B:B", 115)
        config_sheet.write_row("A1", ["Property", "Value"], formats["header"])
        config_rows = [
            ("View ID", view.get("id", "")), ("View name", view.get("name", "")),
            ("Scope", view.get("scope", "")),
            ("Time window", json.dumps(view.get("time_window", {}), ensure_ascii=False, default=_json_default)),
            ("Maximum source rows", view.get("maximum_rows", "")),
            ("Refresh interval (ms)", view.get("refresh_ms", "")),
            ("Shared X axis", json.dumps(view.get("x_axis", {}), ensure_ascii=False, default=_json_default)),
            ("Complete view JSON", json.dumps(view, indent=2, ensure_ascii=False, sort_keys=True, default=_json_default)),
        ]
        for row, (label, value) in enumerate(config_rows, 1):
            config_sheet.write_string(row, 0, label, formats["label"])
            config_sheet.write_string(row, 1, _text(value), formats["wrap"])
        config_sheet.set_row(len(config_rows), 240); config_sheet.freeze_panes(1, 0)

        diagnostics = workbook.add_worksheet("Diagnostics")
        diagnostics.hide_gridlines(2); diagnostics.set_column("A:A", 18); diagnostics.set_column("B:B", 110)
        diagnostics.write_row("A1", ["Type", "Detail"], formats["header"])
        errors = result.get("processor_diagnostics", {}).get("errors", [])
        diagnostic_rows = [
            ("Processor error", error) for error in errors
        ]
        if int(result.get("omitted_samples", 0)):
            diagnostic_rows.append((
                "Row limit",
                f"{int(result['omitted_samples']):,} samples or events were omitted by the configured analysis row limit.",
            ))
        if not diagnostic_rows:
            diagnostic_rows.append(("Status", "No processor errors or row-limit omissions were reported."))
        for row, values in enumerate(diagnostic_rows, 1):
            diagnostics.write_string(row, 0, values[0], formats["label"])
            diagnostics.write_string(row, 1, values[1], formats["wrap"])
        diagnostics.freeze_panes(1, 0)

        workbook.set_properties({
            "title": f"Protocol Data Insight - {view.get('name', '')}",
            "subject": "Current rendered protocol Protocol Insight view and plotted data",
            "author": "Communication Hub",
            "comments": "Generated from the exact analysis result displayed when export was requested.",
        })
    except BaseException:
        workbook.close()
        temporary.unlink(missing_ok=True)
        raise
    workbook.close()
    os.replace(temporary, destination)
    return {
        "path": str(destination), "series_samples": series_total,
        "timeline_events": timeline_total, "marker_hits": marker_total,
        "messages": message_total,
        "sheets": 3 + series_sheets + timeline_sheets + marker_sheets + message_sheets + (1 if plot_image_png else 0),
    }
