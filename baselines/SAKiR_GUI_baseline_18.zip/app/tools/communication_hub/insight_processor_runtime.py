from __future__ import annotations

"""Sandboxed processing runtime shared by Protocol Insight axes and series."""

import importlib
import inspect
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Callable, Mapping


@dataclass(frozen=True)
class InsightValueContext:
    """Read-only context supplied to a configured insight value processor."""

    axis: str
    record: Mapping[str, Any]
    view_id: str = ""
    subplot_id: str | None = None
    series_id: str | None = None
    label: str = ""
    options: Mapping[str, Any] = field(
        default_factory=lambda: MappingProxyType({})
    )


class InsightProcessorRuntime:
    """Resolve and invoke trusted project functions used to preprocess plot values."""

    _function_cache: dict[tuple[str, str], Callable] = {}

    def __init__(self, config: dict):
        self.config = dict(config or {})
        self.function: Callable | None = None
        if not self.config.get("enabled"):
            return
        module_name = str(self.config.get("module", "")).strip()
        function_name = str(self.config.get("function", "")).strip()
        if not module_name or not function_name:
            raise ValueError("Enabled value processor requires module and function")
        cache_key = (module_name, function_name)
        function = self._function_cache.get(cache_key)
        if function is None:
            module = importlib.import_module(module_name)
            function = getattr(module, function_name)
            self._validate_callable(function)
            self._function_cache[cache_key] = function
        self.function = function

    @staticmethod
    def _validate_callable(function):
        if not callable(function):
            raise TypeError("Configured value processor is not callable")
        if inspect.iscoroutinefunction(function) or inspect.isgeneratorfunction(function):
            raise TypeError("Value processor must be a synchronous non-generator function")
        parameters = list(inspect.signature(function).parameters.values())
        if len(parameters) != 2 or any(
            parameter.kind not in {
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            }
            for parameter in parameters
        ):
            raise TypeError(
                "Value processor must accept exactly two positional parameters: "
                "value and context"
            )

    @classmethod
    def clear_cache(cls):
        cls._function_cache.clear()
        importlib.invalidate_caches()

    @classmethod
    def reload(cls, module_name: str, function_name: str):
        module_name = str(module_name).strip()
        function_name = str(function_name).strip()
        module = importlib.import_module(module_name)
        module = importlib.reload(module)
        function = getattr(module, function_name)
        cls._validate_callable(function)
        for cache_key in [
            key for key in cls._function_cache if key[0] == module_name
        ]:
            cls._function_cache.pop(cache_key, None)
        cls._function_cache[(module_name, function_name)] = function
        return function

    def process(self, value: Any, context: InsightValueContext) -> Any:
        if self.function is None:
            return value
        return self.function(value, context)


def validate_insight_processor(config: dict, *, reload_module: bool = False) -> None:
    """Raise a descriptive exception when a processor cannot be used."""
    if reload_module and config.get("enabled"):
        InsightProcessorRuntime.reload(config.get("module", ""), config.get("function", ""))
    InsightProcessorRuntime(config)
