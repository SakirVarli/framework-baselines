from __future__ import annotations

import multiprocessing
import os
import queue
import threading
import time
import uuid
from pathlib import Path
import pandas as pd

from .config import normalize_session_config, resolve_project_path
from .store import EventStore
from .worker import session_process_entry
from .processing_worker import data_processing_process_entry


DATA_COMMANDS = {
    "query", "table_state", "delete_preview", "delete", "names",
    "name_summary", "fields", "protocol_insight_publisher", "persist",
}


class SessionController:
    """GUI/callback-side owner of one spawned session worker."""

    def __init__(
        self,
        config: dict,
        project_root: str | Path,
        retained_table_state: dict | None = None,
        protocol_insight_ingress=None,
        protocol_insight_publisher_capacity: int = 1024,
    ):
        self.config = normalize_session_config(config)
        self.project_root = str(project_root)
        self.process: multiprocessing.Process | None = None
        self.connection = None
        self.processing_process: multiprocessing.Process | None = None
        self.processing_connection = None
        self.capture_queue = None
        self.diagnostic_queue = None
        self._backend_errors: list[dict] = []
        self._lock = threading.RLock()
        self._processing_lock = threading.RLock()
        self._retained_store: EventStore | None = None
        self.protocol_insight_ingress = protocol_insight_ingress
        self.protocol_insight_publisher_capacity = max(
            1, int(protocol_insight_publisher_capacity)
        )
        if retained_table_state is not None:
            self._retain_table(retained_table_state)

    @property
    def running(self) -> bool:
        return bool(
            self.process and self.process.is_alive()
            and self.processing_process and self.processing_process.is_alive()
        )

    @property
    def table_available(self) -> bool:
        return self.running or self._retained_store is not None

    def _retain_table(self, state: dict):
        store = EventStore(self.config["storage"])
        store.restore_state(state)
        self._retained_store = store

    def retained_table_state(self) -> dict | None:
        return self._retained_store.export_state() if self._retained_store is not None else None

    def table_snapshot(self, timeout: float = 60.0) -> pd.DataFrame:
        """Return a coherent copy of this session's current or retained message table."""
        if self.running:
            state = self.request("table_state", timeout=timeout)
        else:
            state = self.retained_table_state()
        frame = state.get("frame") if isinstance(state, dict) else None
        if not isinstance(frame, pd.DataFrame):
            raise RuntimeError(f"Session '{self.config['name']}' has no message table available")
        return frame.copy(deep=True)

    def _persistence_directory(self) -> Path:
        persistence = self.config.get("persistence", {})
        return resolve_project_path(self.project_root, persistence.get("directory", "app/data/communication_hub/logs")) / self.config["id"]

    def load_latest_persisted_table(self) -> dict:
        """Restore the newest final or periodic message snapshot without starting transport I/O."""
        if not self.config.get("persistence", {}).get("enabled"):
            return {"loaded": False, "path": ""}
        candidates = [
            path for path in (
                self._persistence_directory() / "messages_latest.pkl",
                self._persistence_directory() / "messages_final.pkl",
            ) if path.is_file()
        ]
        if not candidates:
            return {"loaded": False, "path": ""}
        path = max(candidates, key=lambda item: item.stat().st_mtime_ns)
        frame = pd.read_pickle(path)
        if not isinstance(frame, pd.DataFrame):
            raise TypeError(f"Persisted session snapshot is not a Pandas DataFrame: {path}")
        numeric_ids = pd.to_numeric(frame.get("id", pd.Series(dtype=float)), errors="coerce")
        largest_id = int(numeric_ids.max()) if len(numeric_ids) and pd.notna(numeric_ids.max()) else 0
        updates = pd.to_numeric(frame.get("update_count", pd.Series(dtype=float)), errors="coerce").fillna(1)
        version = max(0, int(updates.sum()))
        self._retain_table({"frame": frame, "next_id": largest_id + 1, "version": version})
        return {"loaded": True, "path": str(path), "rows": len(frame), "version": version}

    def persist_retained_table(self, final: bool = True) -> dict:
        if self._retained_store is None or not self.config.get("persistence", {}).get("enabled"):
            return {"saved": False}
        directory = self._persistence_directory(); directory.mkdir(parents=True, exist_ok=True)
        suffix = "final" if final else "latest"
        frame = self._retained_store.snapshot()
        counts = self._retained_store.name_summary_frame()
        paths = {
            directory / f"messages_{suffix}.pkl": frame,
            directory / f"message_counts_{suffix}.pkl": counts,
        }
        for path, value in paths.items():
            temporary = path.with_suffix(".tmp.pkl")
            value.to_pickle(temporary); os.replace(temporary, path)
        return {"saved": True, "rows": len(frame), "directory": str(directory)}

    def start(self, timeout: float = 10.0):
        with self._lock:
            if self.running:
                return self.status()
            if (
                (self.process is not None and self.process.is_alive())
                or (self.processing_process is not None and self.processing_process.is_alive())
            ):
                self.stop(timeout=min(timeout, 5.0))
            context = multiprocessing.get_context("spawn")
            parent, child = context.Pipe()
            processing_parent, processing_child = context.Pipe()
            retained_state = self.retained_table_state()
            processing = self.config["processing"]
            self.capture_queue = context.Queue(maxsize=int(processing["queue_capacity"]))
            self.diagnostic_queue = context.Queue(maxsize=32)
            self.processing_process = context.Process(
                target=data_processing_process_entry,
                args=(
                    processing_child, self.capture_queue, self.config, self.project_root,
                    retained_state, self.protocol_insight_ingress,
                    self.protocol_insight_publisher_capacity, self.diagnostic_queue,
                ),
                name=f"CommunicationData-{self.config['name']}", daemon=True,
            )
            self.processing_connection = processing_parent
            try:
                self.processing_process.start()
                processing_child.close()
                self._request_connection(
                    self.processing_connection, self._processing_lock,
                    "ping", {}, timeout,
                )
                self.process = context.Process(
                    target=session_process_entry,
                    args=(
                        child, self.capture_queue, self.config, self.project_root,
                        self.diagnostic_queue,
                    ),
                    name=f"CommunicationSession-{self.config['name']}",
                    daemon=True,
                )
                self.connection = parent
                self.process.start()
                child.close()
                result = self.request("ping", timeout=timeout)
                self._retained_store = None
                return result
            except BaseException:
                # A half-started session must not leave either backend alive.
                for endpoint in (child, processing_child):
                    try:
                        endpoint.close()
                    except (OSError, ValueError):
                        pass
                self._drain_backend_diagnostics()
                self.stop(timeout=min(timeout, 5.0))
                if self._backend_errors:
                    latest = self._backend_errors[-1]
                    raise RuntimeError(
                        f"{latest.get('backend', 'Session')} backend failed: "
                        f"{latest.get('error', 'unknown error')}"
                    )
                raise

    def _drain_backend_diagnostics(self):
        if self.diagnostic_queue is None:
            return
        while True:
            try:
                diagnostic = self.diagnostic_queue.get_nowait()
            except queue.Empty:
                break
            except (EOFError, OSError, ValueError):
                break
            if isinstance(diagnostic, dict):
                self._backend_errors.append(diagnostic)
                self._backend_errors = self._backend_errors[-32:]

    def _backend_failure_status(self):
        self._drain_backend_diagnostics()
        io_alive = bool(self.process and self.process.is_alive())
        processing_alive = bool(
            self.processing_process and self.processing_process.is_alive()
        )
        configured = self.process is not None or self.processing_process is not None
        result = self._retained_store.metrics() if self._retained_store is not None else {}
        if not configured:
            result.update({
                "state": "stopped",
                "status_message": "Recorded table retained in memory" if self._retained_store is not None else "",
                "session_id": self.config["id"],
            })
            return result
        exits = []
        if not io_alive:
            exits.append(f"I/O backend exited (code {getattr(self.process, 'exitcode', None)})")
        if not processing_alive:
            exits.append(
                f"data-processing backend exited (code {getattr(self.processing_process, 'exitcode', None)})"
            )
        detail = "\n\n".join(
            str(item.get("traceback") or item.get("error") or "")
            for item in self._backend_errors[-2:]
        ).strip()
        result.update({
            "state": "error",
            "status_message": "; ".join(exits),
            "session_id": self.config["id"],
            "io_backend_alive": io_alive,
            "processing_backend_alive": processing_alive,
            "backend_errors": list(self._backend_errors),
            "last_error": detail or "; ".join(exits),
        })
        return result

    def request(self, command: str, payload: dict | None = None, timeout: float = 30.0):
        payload = payload or {}
        if not self.running or self.connection is None:
            if self._retained_store is not None:
                if command == "query":
                    return self._retained_store.query(
                        payload.get("query"), page=payload.get("page", 0), page_size=payload.get("page_size", 200),
                        sort_by=payload.get("sort_by", "timestamp"), descending=payload.get("descending", True),
                    )
                if command == "delete_preview":
                    result = self._retained_store.query(payload.get("query"), page=0, page_size=10)
                    return {"count": result["total"], "version": result["version"], "sample": result["rows"]}
                if command == "delete":
                    return self._retained_store.delete(payload.get("query"), payload.get("expected_version"))
                if command == "names":
                    return self._retained_store.distinct_names()
                if command == "name_summary":
                    return self._retained_store.name_summary()
                if command == "fields":
                    return self._retained_store.discover_fields(payload.get("name"))
            raise RuntimeError(f"Session '{self.config['name']}' is not running")
        if command in DATA_COMMANDS:
            return self._request_connection(
                self.processing_connection, self._processing_lock,
                command, payload, timeout,
            )
        return self._request_connection(
            self.connection, self._lock, command, payload, timeout,
        )

    def _request_connection(self, connection, lock, command, payload, timeout):
        if connection is None:
            raise RuntimeError(f"Session '{self.config['name']}' backend is not available")
        request_id = str(uuid.uuid4())
        with lock:
            connection.send({"id": request_id, "command": command, "payload": payload})
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if connection.poll(min(0.05, max(0.0, deadline - time.monotonic()))):
                    response = connection.recv()
                    if response.get("id") != request_id:
                        continue
                    if not response.get("ok"):
                        raise RuntimeError(response.get("error", "Worker command failed"))
                    return response.get("result")
            raise TimeoutError(f"Session command '{command}' timed out")

    def status(self):
        if not self.running:
            return self._backend_failure_status()
        self._drain_backend_diagnostics()
        try:
            io_status = self.request("status", timeout=2.0)
            data_status = self._request_connection(
                self.processing_connection, self._processing_lock,
                "data_status", {}, 2.0,
            )
        except (BrokenPipeError, ConnectionError, EOFError, OSError):
            # is_alive() can remain true briefly after a Windows child closes
            # its pipe. Surface the backend exit instead of leaking IPC noise.
            deadline = time.monotonic() + 0.25
            while self.running and time.monotonic() < deadline:
                time.sleep(0.01)
            return self._backend_failure_status()
        io_status.update(data_status)
        if self._backend_errors:
            io_status["backend_errors"] = list(self._backend_errors)
        return io_status

    def send(self, data: bytes | str, *, encoding: str = "utf-8", target: str = ""):
        """Send exactly the supplied bytes; receive framing does not affect TX."""
        return self.request("send", {
            "data": data, "encoding": encoding, "target": target,
        })

    def query(self, query: dict | None = None, **options):
        payload = {"query": query or {}}
        payload.update(options)
        return self.request("query", payload)

    def stop(self, timeout: float = 15.0):
        process = self.process
        processing_process = self.processing_process
        if not process and not processing_process:
            persistence = self.config.get("persistence", {})
            if persistence.get("enabled") and persistence.get("save_on_stop", True):
                self.persist_retained_table(final=True)
            return
        if process and process.is_alive():
            try:
                stopped = self.request("stop", timeout=min(timeout, 5.0))
                required_sequence = int(
                    stopped.get("capture_sequence", 0) if isinstance(stopped, dict) else 0
                )
                deadline = time.monotonic() + min(timeout, 10.0)
                while required_sequence and time.monotonic() < deadline:
                    processing_status = self._request_connection(
                        self.processing_connection, self._processing_lock,
                        "data_status", {}, min(2.0, max(0.1, deadline - time.monotonic())),
                    )
                    if int(processing_status.get("processing_last_capture_sequence", 0)) >= required_sequence:
                        break
                    time.sleep(0.01)
                self._retain_table(self._request_connection(
                    self.processing_connection, self._processing_lock,
                    "table_state", {}, min(timeout, 10.0),
                ))
            except BaseException:
                pass
            process.join(timeout)
            if process.is_alive():
                process.terminate()
                process.join(3)
        if processing_process and processing_process.is_alive():
            try:
                self._request_connection(
                    self.processing_connection, self._processing_lock,
                    "stop", {}, min(timeout, 5.0),
                )
            except BaseException:
                pass
            processing_process.join(timeout)
            if processing_process.is_alive():
                processing_process.terminate(); processing_process.join(3)
        if self.connection:
            self.connection.close()
        self.connection = None
        self.process = None
        if self.processing_connection:
            self.processing_connection.close()
        self.processing_connection = None
        self.processing_process = None
        if self.capture_queue is not None:
            try: self.capture_queue.close()
            except (AttributeError, OSError, ValueError): pass
        self.capture_queue = None
        if self.diagnostic_queue is not None:
            self._drain_backend_diagnostics()
            try: self.diagnostic_queue.close()
            except (AttributeError, OSError, ValueError): pass
        self.diagnostic_queue = None

    restart = lambda self: (self.stop(), self.start())[-1]
