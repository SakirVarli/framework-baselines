from __future__ import annotations

"""Protocol Insights configuration, collection, result building, and Qt workspace."""

import copy
import fnmatch
import json
import math
import numbers
import re
import shutil
import threading
import time
import uuid
from bisect import bisect_left
from datetime import datetime
from pathlib import Path
from types import MappingProxyType
from typing import Any

import pandas as pd
from PyQt5 import QtCore, QtGui, QtWidgets

from app.utils import PROJECT_ROOT

from .local_time import local_datetime_from_ns, timestamp_ns

from .insight_processor_runtime import (
    InsightProcessorRuntime, InsightValueContext, validate_insight_processor,
)
from .protocol_insight_runtime_core import extract_value
from .query import QueryEngine, get_path, get_path_tokens, serialize_value
from .visualization import (
    PROTOCOL_INSIGHT_CAPABILITIES, ColorSelectionWidget,
    InsightDatasetSettingsEditor, CommonVisualizationEditor,
    default_insight_dataset_configuration, new_series, new_subplot,
)

try:
    import pyqtgraph as pg
except ImportError:  # pragma: no cover - the panel reports the missing optional dependency.
    pg = None


INSIGHT_COLORS = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9"]
METADATA_FIELDS = [
    "id", "size", "frame_size", "parse_duration_ns", "update_count",
    "direction", "protocol", "name", "connection_id", "peer", "parse_status",
]
X_METADATA_FIELDS = [
    "id", "timestamp", "first_timestamp", "size", "frame_size",
    "parse_duration_ns", "update_count",
]
_PROCESSOR_UNSET = object()
_SERIES_QUERY_ENGINE = QueryEngine()
AUTOMATIC_STREAM_IDENTITY_FIELDS = [
    "session_id", "connection_id", "direction", "name",
]
SCHEDULED_COLLECTION_POLICIES = {
    "all", "first", "last", "changed", "last_changed",
}
ON_ARRIVAL_COLLECTION_POLICIES = {"all", "changed"}


def default_insight_processor() -> dict:
    return {
        "enabled": False, "module": "", "function": "", "options": {},
    }


def normalize_insight_processor(value: dict | None) -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    options = source.get("options") if isinstance(source.get("options"), dict) else {}
    return {
        "enabled": bool(source.get("enabled", False)),
        "module": str(source.get("module") or "").strip(),
        "function": str(source.get("function") or "").strip(),
        "options": copy.deepcopy(options),
    }


def _insight_processor_config(value: dict | None) -> dict:
    if isinstance(value, dict) and {
        "enabled", "module", "function", "options",
    }.issubset(value):
        return value
    return normalize_insight_processor(value)


class InsightViewBox(pg.ViewBox if pg is not None else object):
    """ViewBox with insight-focused navigation choices."""

    def __init__(self, *args, **kwargs):
        if pg is None:  # pragma: no cover - instantiated only when PyQtGraph is available.
            raise RuntimeError("Protocol plots require the PyQtGraph package.")
        super().__init__(*args, **kwargs)
        self._insight_menu = QtWidgets.QMenu()
        self._interaction_group = QtWidgets.QActionGroup(self._insight_menu)
        self._interaction_group.setExclusive(True)

        self.rectangle_action = self._insight_menu.addAction("Rectangle zoom (drag)")
        self.rectangle_action.setCheckable(True)
        self.rectangle_action.triggered.connect(self.use_rectangle_zoom)
        self._interaction_group.addAction(self.rectangle_action)

        self.pan_action = self._insight_menu.addAction("Pan / reposition (drag)")
        self.pan_action.setCheckable(True)
        self.pan_action.triggered.connect(self.use_pan_mode)
        self._interaction_group.addAction(self.pan_action)

        self._insight_menu.addSeparator()
        self.reset_action = self._insight_menu.addAction("Reset View (auto-range / A)")
        self.reset_action.triggered.connect(self.reset_view)
        self._insight_menu.addSeparator()
        self.pin_action = self._insight_menu.addAction("Pin current hover")
        self.pin_action.triggered.connect(self.pin_hover)
        self.clear_pins_action = self._insight_menu.addAction("Clear pinned hovers")
        self.clear_pins_action.triggered.connect(self.clear_pinned_hovers)
        self._plot_item = None
        self._reset_all = None
        self._pin_hover = None
        self._clear_pins = None
        self._can_pin = None
        self._has_pins = None
        self.use_pan_mode()

    def bind_plot_item(
        self, plot_item, reset_all=None, pin_hover=None, clear_pins=None,
        can_pin=None, has_pins=None,
    ):
        """Bind the owning PlotItem and panel-wide interaction operations."""
        self._plot_item = plot_item
        self._reset_all = reset_all
        self._pin_hover = pin_hover
        self._clear_pins = clear_pins
        self._can_pin = can_pin
        self._has_pins = has_pins

    def use_rectangle_zoom(self, _checked=True):
        self.setMouseMode(self.RectMode)
        self.rectangle_action.setChecked(True)

    def use_pan_mode(self, _checked=True):
        self.setMouseMode(self.PanMode)
        self.pan_action.setChecked(True)

    def reset_view(self, _checked=False):
        if self._reset_all is not None:
            self._reset_all()
            return
        if self._plot_item is not None:
            self._plot_item.autoBtn.mode = "auto"
            self._plot_item.autoBtnClicked()
            return
        self.enableAutoRange(axis=self.XYAxes, enable=True)

    def pin_hover(self, _checked=False):
        if self._pin_hover is not None:
            self._pin_hover()

    def clear_pinned_hovers(self, _checked=False):
        if self._clear_pins is not None:
            self._clear_pins()

    def mouseClickEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            event.accept()
            self.pin_action.setEnabled(bool(self._can_pin and self._can_pin()))
            self.clear_pins_action.setEnabled(bool(self._has_pins and self._has_pins()))
            screen_pos = event.screenPos()
            self._insight_menu.popup(QtCore.QPoint(int(screen_pos.x()), int(screen_pos.y())))
            return
        super().mouseClickEvent(event)


def default_insight_x_axis() -> dict:
    return {
        "kind": "timestamp", "label": "Time (local)", "value_type": "datetime",
        "timestamp_mode": "exact",
        "transform": {"scale": 1.0, "offset": 0.0},
        "processor": default_insight_processor(),
    }


def default_protocol_insight_source() -> dict:
    return {
        "scope": "current", "session_ids": [],
        "saved_query_id": "", "data_filter": {},
        "history": {"mode": "last", "amount": 60.0, "unit": "seconds"},
        "preview": {"maximum_rows": 10_000},
        "collection": {
            "mode": "on_arrival", "interval_seconds": 1.0,
            "default_policy": "all", "start_position": "new_messages",
            "maximum_candidates_per_cycle": 10_000,
            "overflow_policy": "drop_oldest",
        },
    }


def normalize_protocol_insight_source(value: dict | None, configured_scope="current") -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    result = default_protocol_insight_source()
    for key, item in source.items():
        if isinstance(item, dict) and isinstance(result.get(key), dict):
            result[key].update(copy.deepcopy(item))
        else:
            result[key] = copy.deepcopy(item)
    if not source:
        result["scope"] = "all" if configured_scope == "global" else "current"
    if result.get("scope") not in {"current", "selected", "all"}:
        result["scope"] = "current"
    result["session_ids"] = [str(item) for item in result.get("session_ids", []) if item]
    result["saved_query_id"] = str(result.get("saved_query_id") or "")
    if not isinstance(result.get("data_filter"), dict): result["data_filter"] = {}
    history = result.get("history") if isinstance(result.get("history"), dict) else {}
    history["mode"] = "all" if history.get("mode") == "all" else "last"
    try: history["amount"] = max(.001, float(history.get("amount", 60.0)))
    except (TypeError, ValueError): history["amount"] = 60.0
    if history.get("unit") not in {"milliseconds", "seconds", "minutes", "hours"}: history["unit"] = "seconds"
    result["history"] = history
    preview = result.get("preview") if isinstance(result.get("preview"), dict) else {}
    try:
        preview["maximum_rows"] = max(
            1, min(1_000_000, int(preview.get("maximum_rows", 10_000)))
        )
    except (TypeError, ValueError):
        preview["maximum_rows"] = 10_000
    result["preview"] = preview
    collection = result.get("collection") if isinstance(result.get("collection"), dict) else {}
    defaults = default_protocol_insight_source()["collection"]
    merged = {**copy.deepcopy(defaults), **{
        key: copy.deepcopy(item) for key, item in collection.items()
        if key in defaults
    }}
    if merged.get("mode") not in {"on_arrival", "scheduled"}:
        merged["mode"] = "on_arrival"
    try: merged["interval_seconds"] = max(.05, float(merged.get("interval_seconds", 1.0)))
    except (TypeError, ValueError): merged["interval_seconds"] = 1.0
    valid_policies = (
        SCHEDULED_COLLECTION_POLICIES
        if merged["mode"] == "scheduled" else ON_ARRIVAL_COLLECTION_POLICIES
    )
    if merged.get("default_policy") not in valid_policies:
        merged["default_policy"] = "all"
    merged["start_position"] = (
        "retained_then_new"
        if merged.get("start_position") == "retained_then_new" else "new_messages"
    )
    try:
        merged["maximum_candidates_per_cycle"] = max(
            1, min(1_000_000, int(merged.get("maximum_candidates_per_cycle", 10_000)))
        )
    except (TypeError, ValueError):
        merged["maximum_candidates_per_cycle"] = 10_000
    if merged.get("overflow_policy") not in {"drop_oldest", "drop_newest", "pause"}:
        merged["overflow_policy"] = "drop_oldest"
    result["collection"] = merged
    return result


def normalize_insight_x_axis(value: dict | None) -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    result = default_insight_x_axis()
    result.update(source)
    kind = str(result.get("kind", "timestamp"))
    if kind not in {"timestamp", "parsed_field", "header_field", "raw_bytes", "metadata"}:
        kind = "timestamp"
    result["kind"] = kind
    timestamp_mode = str(source.get("timestamp_mode", "exact"))
    if timestamp_mode not in {"exact", "elapsed"}:
        timestamp_mode = "exact"
    result["timestamp_mode"] = timestamp_mode
    result["value_type"] = (
        "datetime" if kind == "timestamp" and timestamp_mode == "exact"
        else "numeric" if kind == "timestamp"
        else "datetime" if source.get("value_type") == "datetime"
        else "numeric"
    )
    default_label = (
        "Time (local)" if kind == "timestamp" and timestamp_mode == "exact"
        else "Elapsed time (s)" if kind == "timestamp"
        else "X value"
    )
    result["label"] = str(source.get("label") or default_label)
    transform = result.get("transform") if isinstance(result.get("transform"), dict) else {}
    try: scale = float(transform.get("scale", 1.0))
    except (TypeError, ValueError): scale = 1.0
    try: offset = float(transform.get("offset", 0.0))
    except (TypeError, ValueError): offset = 0.0
    result["transform"] = {"scale": scale, "offset": offset}
    result["processor"] = normalize_insight_processor(source.get("processor"))
    return result


def normalize_series_stream_identity(value: dict | None) -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    mode = str(source.get("mode", "automatic"))
    if mode not in {"automatic", "custom", "combined"}:
        mode = "automatic"
    fields = []
    for item in source.get("additional_fields", []):
        field = str(item).strip()
        if field and field not in fields:
            fields.append(field)
    missing = str(source.get("missing_field_policy", "reject"))
    if missing not in {"reject", "missing", "fallback"}:
        missing = "reject"
    return {
        "mode": mode, "additional_fields": fields,
        "missing_field_policy": missing,
        "fallback_value": copy.deepcopy(source.get("fallback_value", "")),
    }


def normalize_series_collection(value: dict | None) -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    policy = str(source.get("policy", "inherit"))
    if policy not in {"inherit", *SCHEDULED_COLLECTION_POLICIES}:
        policy = "inherit"
    return {"policy": policy}


def protocol_insight_series_signature(series: dict) -> str:
    """Return a stable semantic signature used to reject exact duplicates."""
    payload = {
        "session_id": str(series.get("session_id", "")),
        "message_names": sorted(str(item) for item in series.get("message_names", [])),
        "direction": str(series.get("direction", "any")),
        "source": copy.deepcopy(series.get("source", {})),
        "transform": copy.deepcopy(series.get("transform", {})),
        "processor": normalize_insight_processor(series.get("processor")),
        "stream_identity": normalize_series_stream_identity(series.get("stream_identity")),
        "collection": normalize_series_collection(series.get("collection")),
    }
    return json.dumps(serialize_value(payload), sort_keys=True, separators=(",", ":"))


def default_protocol_insight_config(name: str = "Protocol Insight") -> dict:
    return {
        "schema_version": 10,
        "id": str(uuid.uuid4()), "name": name, "scope": "current",
        "autostart": False,
        "lifecycle": {"scope": "window", "restore_last_state": True},
        "source": default_protocol_insight_source(),
        "series_discovery": {
            "history": {"mode": "last", "amount": 60.0, "unit": "seconds"},
            "maximum_rows": 10_000,
        },
        "time_window": {"mode": "last", "amount": 60.0, "unit": "seconds"},
        "maximum_rows": 10_000, "refresh_ms": 1000, "live": True,
        "display": {
            "window": {"mode": "last", "amount": 60.0, "unit": "seconds"},
            "maximum_points": 10_000, "refresh_ms": 1000,
            "live": True, "follow_latest": True,
        },
        "x_axis": default_insight_x_axis(),
        "dataset": default_insight_dataset_configuration(),
        "event_markers": [],
        "subplots": [],
    }


def normalize_insight_event_marker(value: dict | None) -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    trigger = str(source.get("trigger", "appearance"))
    if trigger not in {"appearance", "condition", "becomes"}:
        trigger = "appearance"
    direction = str(source.get("direction", "any"))
    if direction not in {"any", "RX", "TX"}:
        direction = "any"
    names = source.get("message_names", [])
    if isinstance(names, str):
        names = [item.strip() for item in names.split(",") if item.strip()]
    extractor = source.get("source") if isinstance(source.get("source"), dict) else {}
    kind = str(extractor.get("kind", "parsed_field"))
    if kind not in {"parsed_field", "header_field", "metadata"}:
        kind = "parsed_field"
    extractor["kind"] = kind
    operator = str(source.get("operator", "equals"))
    if operator not in {
        "equals", "not_equals", "greater", "greater_equal",
        "less", "less_equal", "contains",
    }:
        operator = "equals"
    targets = source.get("target_subplot_ids", [])
    if not isinstance(targets, list):
        targets = []
    symbol = str(source.get("symbol", "d"))
    if symbol not in {"o", "s", "d", "t", "t1", "t2", "t3", "+", "x", "star"}:
        symbol = "d"
    return {
        "id": str(source.get("id") or uuid.uuid4()),
        "label": str(source.get("label") or "Event"),
        "session_id": str(source.get("session_id") or ""),
        "message_names": [str(item) for item in names if str(item)],
        "direction": direction,
        "trigger": trigger,
        "source": extractor,
        "operator": operator,
        "comparison": str(source.get("comparison", "")),
        "target_subplot_ids": [str(item) for item in targets if str(item)],
        "color": str(source.get("color") or "#E69F00"),
        "symbol": symbol,
    }


def normalize_protocol_insight_config(value: dict | None) -> dict:
    source = copy.deepcopy(value) if isinstance(value, dict) else {}
    result = default_protocol_insight_config(str(source.get("name") or "Protocol Insight"))
    result.update({
        key: copy.deepcopy(item) for key, item in source.items()
        if key not in {"subplots", "event_markers"}
    })
    result["id"] = str(result.get("id") or uuid.uuid4())
    result["schema_version"] = 10
    result["name"] = str(result.get("name") or "Protocol Insight")
    result["autostart"] = bool(result.get("autostart", False))
    lifecycle = source.get("lifecycle") if isinstance(source.get("lifecycle"), dict) else {}
    result["lifecycle"] = {
        "scope": "application" if lifecycle.get("scope") == "application" else "window",
        "restore_last_state": bool(lifecycle.get("restore_last_state", True)),
    }
    result["scope"] = "global" if result.get("scope") == "global" else "current"
    result["source"] = normalize_protocol_insight_source(source.get("source"), result["scope"])
    result["scope"] = "global" if result["source"]["scope"] == "all" else "current"
    raw_discovery = source.get("series_discovery") if isinstance(source.get("series_discovery"), dict) else {}
    discovery_history = raw_discovery.get("history") if isinstance(raw_discovery.get("history"), dict) else copy.deepcopy(result["source"].get("history", {}))
    discovery_mode = "all" if discovery_history.get("mode") == "all" else "last"
    try: discovery_amount = max(.001, float(discovery_history.get("amount", 60.0)))
    except (TypeError, ValueError): discovery_amount = 60.0
    discovery_unit = str(discovery_history.get("unit", "seconds"))
    if discovery_unit not in {"milliseconds", "seconds", "minutes", "hours"}: discovery_unit = "seconds"
    try: discovery_rows = max(1, min(250_000, int(raw_discovery.get("maximum_rows", result["source"].get("preview", {}).get("maximum_rows", 10_000)))))
    except (TypeError, ValueError): discovery_rows = 10_000
    result["series_discovery"] = {
        "history": {"mode": discovery_mode, "amount": discovery_amount, "unit": discovery_unit},
        "maximum_rows": discovery_rows,
    }
    window = result.get("time_window") if isinstance(result.get("time_window"), dict) else {}
    mode = "all" if window.get("mode") == "all" else "last"
    try: amount = max(0.001, float(window.get("amount", 60) or 60))
    except (TypeError, ValueError): amount = 60.0
    unit = str(window.get("unit", "seconds"))
    if unit not in {"milliseconds", "seconds", "minutes", "hours"}: unit = "seconds"
    result["time_window"] = {"mode": mode, "amount": amount, "unit": unit}
    if not isinstance(source.get("source"), dict) or "history" not in source.get("source", {}):
        result["source"]["history"] = copy.deepcopy(result["time_window"])
    try: result["maximum_rows"] = min(250_000, max(100, int(result.get("maximum_rows", 10_000))))
    except (TypeError, ValueError): result["maximum_rows"] = 10_000
    try: result["refresh_ms"] = min(60_000, max(200, int(result.get("refresh_ms", 1000))))
    except (TypeError, ValueError): result["refresh_ms"] = 1000
    result["live"] = bool(result.get("live", True))
    raw_display = source.get("display") if isinstance(source.get("display"), dict) else {}
    display_window = raw_display.get("window") if isinstance(raw_display.get("window"), dict) else result["time_window"]
    display_mode = "all" if display_window.get("mode") == "all" else "last"
    try: display_amount = max(.001, float(display_window.get("amount", 60.0)))
    except (TypeError, ValueError): display_amount = 60.0
    display_unit = str(display_window.get("unit", "seconds"))
    if display_unit not in {"milliseconds", "seconds", "minutes", "hours"}: display_unit = "seconds"
    try: display_points = min(250_000, max(100, int(raw_display.get("maximum_points", result["maximum_rows"]))))
    except (TypeError, ValueError): display_points = result["maximum_rows"]
    try: display_refresh = min(60_000, max(200, int(raw_display.get("refresh_ms", result["refresh_ms"]))))
    except (TypeError, ValueError): display_refresh = result["refresh_ms"]
    result["display"] = {"window": {"mode": display_mode, "amount": display_amount, "unit": display_unit}, "maximum_points": display_points, "refresh_ms": display_refresh, "live": bool(raw_display.get("live", result["live"])), "follow_latest": bool(raw_display.get("follow_latest", True))}
    dataset = default_insight_dataset_configuration()
    raw_dataset = source.get("dataset") if isinstance(source.get("dataset"), dict) else {}
    for key, value in raw_dataset.items():
        if isinstance(value, dict) and isinstance(dataset.get(key), dict):
            dataset[key].update(copy.deepcopy(value))
        else:
            dataset[key] = copy.deepcopy(value)
    raw_runtime = dataset.get("runtime", {}) if isinstance(dataset.get("runtime"), dict) else {}
    dataset["runtime"] = {
        "active": bool(raw_runtime.get("active", False)),
        "paused": bool(raw_runtime.get("paused", False)),
        "last_active_on_close": bool(raw_runtime.get(
            "last_active_on_close", raw_runtime.get("active", False),
        )),
    }
    raw_sampling = dataset.get("sampling", {}) if isinstance(dataset.get("sampling"), dict) else {}
    dataset["sampling"] = {"emit_final_on_stop": bool(raw_sampling.get("emit_final_on_stop", True))}
    dataset.setdefault("excel", {})["layout"] = "wide_aligned"
    result["dataset"] = dataset
    result["x_axis"] = normalize_insight_x_axis(source.get("x_axis"))
    subplots = []
    for plot_index, raw_plot in enumerate(source.get("subplots", [])):
        if not isinstance(raw_plot, dict): continue
        subplot_kind = "timeline" if raw_plot.get("kind") == "timeline" else "plot"
        plot = {
            "id": str(raw_plot.get("id") or uuid.uuid4()),
            "title": str(raw_plot.get("title") or f"Subplot {plot_index + 1}"),
            "unit": str(raw_plot.get("unit") or ""), "kind": subplot_kind,
            "series": [],
        }
        if subplot_kind == "timeline":
            raw_timeline = (
                raw_plot.get("timeline")
                if isinstance(raw_plot.get("timeline"), dict) else {}
            )
            lane_by = str(raw_timeline.get("lane_by", "session_direction_name"))
            if lane_by not in {
                "name", "direction_name", "session_name",
                "session_direction_name",
            }:
                lane_by = "session_direction_name"
            names = raw_timeline.get("message_names", [])
            if isinstance(names, str):
                names = [item.strip() for item in names.split(",") if item.strip()]
            direction = str(raw_timeline.get("direction", "any"))
            if direction not in {"any", "RX", "TX"}:
                direction = "any"
            plot["timeline"] = {
                "session_id": str(raw_timeline.get("session_id") or ""),
                "message_names": [str(item) for item in names if str(item)],
                "direction": direction,
                "lane_by": lane_by,
            }
        for series_index, raw_series in enumerate(raw_plot.get("series", [])):
            if not isinstance(raw_series, dict): continue
            series = copy.deepcopy(raw_series)
            series["id"] = str(series.get("id") or uuid.uuid4())
            series["label"] = str(series.get("label") or f"Series {series_index + 1}")
            series["plot_enabled"] = bool(series.get("plot_enabled", True))
            series["visible"] = bool(series.get("visible", series["plot_enabled"]))
            series["export_enabled"] = bool(series.get("export_enabled", True))
            series["session_id"] = str(series.get("session_id") or "")
            names = series.get("message_names", [])
            if isinstance(names, str): names = [item.strip() for item in names.split(",") if item.strip()]
            series["message_names"] = [str(item) for item in names if str(item)]
            series["direction"] = str(series.get("direction", "any"))
            if series["direction"] not in {"any", "RX", "TX"}: series["direction"] = "any"
            extractor = series.get("source") if isinstance(series.get("source"), dict) else {}
            kind = str(extractor.get("kind", "parsed_field"))
            if kind not in {"parsed_field", "header_field", "raw_bytes", "binary_field", "metadata"}: kind = "parsed_field"
            extractor["kind"] = kind; series["source"] = extractor
            plot_options = series.get("plot") if isinstance(series.get("plot"), dict) else {}
            plot_type = str(plot_options.get("type", "line"))
            if plot_type not in {"line", "step", "scatter", "state"}: plot_type = "line"
            plot_options.update({
                "type": plot_type,
                "color": str(plot_options.get("color") or INSIGHT_COLORS[series_index % len(INSIGHT_COLORS)]),
            })
            series["plot"] = plot_options
            transform = series.get("transform") if isinstance(series.get("transform"), dict) else {}
            try: scale = float(transform.get("scale", 1.0))
            except (TypeError, ValueError): scale = 1.0
            try: offset = float(transform.get("offset", 0.0))
            except (TypeError, ValueError): offset = 0.0
            series["transform"] = {"scale": scale, "offset": offset}
            series["processor"] = normalize_insight_processor(
                raw_series.get("processor")
            )
            series["stream_identity"] = normalize_series_stream_identity(
                raw_series.get("stream_identity")
            )
            series["collection"] = normalize_series_collection(
                raw_series.get("collection")
            )
            plot["series"].append(series)
        subplots.append(plot)
    result["subplots"] = subplots
    result["event_markers"] = [
        normalize_insight_event_marker(item)
        for item in source.get("event_markers", [])
        if isinstance(item, dict)
    ]
    return result


def protocol_insight_query(view: dict) -> dict:
    source = normalize_protocol_insight_source(view.get("source"), view.get("scope", "current"))
    window = source.get("history", view.get("time_window", {}))
    parts = []
    if window.get("mode") == "last":
        parts.append({
            "field": "timestamp", "operation": "within_last",
            "value": float(window.get("amount", 60)), "unit": str(window.get("unit", "seconds")),
        })
    data_filter = source.get("data_filter", {})
    if data_filter:
        parts.append(copy.deepcopy(data_filter))
    if not parts: return {}
    return parts[0] if len(parts) == 1 else {"operator": "and", "conditions": parts}


def protocol_insight_select_records(view: dict, records: list[dict]) -> tuple[list[dict], list[dict]]:
    """Select eligible retained rows for a read-only source preview."""
    source = normalize_protocol_insight_source(view.get("source"), view.get("scope", "current"))
    data_filter = source.get("data_filter", {})
    engine = QueryEngine()
    data_rows = [row for row in records if not data_filter or engine.matches_record(row, data_filter)]
    return data_rows, []


def discover_protocol_insight_series(records: list[dict], *, maximum_depth=8, maximum_items=32) -> list[dict]:
    """Catalog scalar and structured paths observed in message-table rows."""
    catalog = {}

    def type_name(value):
        if value is None: return "null"
        module = type(value).__module__
        if module.startswith("numpy"):
            if hasattr(value, "shape") and getattr(value, "shape", ()):
                return "numpy_array"
            return "numpy_scalar"
        if isinstance(value, bool): return "boolean"
        if isinstance(value, numbers.Integral): return "integer"
        if isinstance(value, numbers.Real): return "float"
        if isinstance(value, (bytes, bytearray, memoryview)): return "bytes"
        if isinstance(value, dict): return "dictionary"
        if isinstance(value, (list, tuple)): return "array"
        if isinstance(value, str): return "string"
        return type(value).__name__

    def display_path(tokens):
        text = ""
        for token in tokens:
            if isinstance(token, int): text += f"[{token}]"
            elif not text: text = str(token)
            elif re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", str(token)): text += "." + str(token)
            else: text += "[" + json.dumps(str(token), ensure_ascii=False) + "]"
        return text

    def add(tokens, value, message_name, session_id):
        path = display_path(tokens); observed = type_name(value)
        entry = catalog.setdefault(path, {
            "id": str(uuid.uuid5(uuid.NAMESPACE_URL, "protocol-insight-series:" + path)),
            "path": path, "path_tokens": copy.deepcopy(tokens), "types": set(),
            "examples": [], "messages": set(), "sessions": set(), "occurrences": 0,
        })
        entry["types"].add(observed); entry["messages"].add(str(message_name or "")); entry["sessions"].add(str(session_id or "")); entry["occurrences"] += 1
        if len(entry["examples"]) < 3:
            preview = serialize_value(value)
            entry["examples"].append(str(preview)[:160])

    def walk(tokens, value, depth, message_name, session_id):
        add(tokens, value, message_name, session_id)
        if depth >= maximum_depth: return
        if isinstance(value, dict):
            for key, child in list(value.items())[:maximum_items]: walk(tokens + [str(key)], child, depth + 1, message_name, session_id)
        elif isinstance(value, (list, tuple)):
            for index, child in enumerate(value[:maximum_items]): walk(tokens + [index], child, depth + 1, message_name, session_id)
        elif type(value).__module__.startswith("numpy") and hasattr(value, "tolist"):
            converted = value.tolist()
            if isinstance(converted, list):
                for index, child in enumerate(converted[:maximum_items]): walk(tokens + [index], child, depth + 1, message_name, session_id)

    roots = (
        "timestamp", "session_id", "protocol", "direction", "name", "connection_id",
        "peer", "size", "parsed", "parse_status", "parse_error", "update_count",
        "header_fields", "data",
    )
    for record in records:
        for root in roots:
            if root in record: walk([root], record.get(root), 0, record.get("name"), record.get("session_id"))
    result = []
    total = max(1, len(records))
    for entry in catalog.values():
        types = sorted(entry.pop("types")); entry["types"] = types
        entry["messages"] = sorted(item for item in entry["messages"] if item)
        entry["sessions"] = sorted(item for item in entry["sessions"] if item)
        entry["availability"] = min(100.0, entry["occurrences"] * 100.0 / total)
        root = entry["path_tokens"][0]
        if root == "data": entry["source"] = {"kind": "parsed_field", "path": ".".join(map(str, entry["path_tokens"])), "path_tokens": entry["path_tokens"][1:]}
        elif root == "header_fields": entry["source"] = {"kind": "header_field", "path": ".".join(map(str, entry["path_tokens"])), "path_tokens": entry["path_tokens"][1:]}
        else: entry["source"] = {"kind": "metadata", "field": str(root)}
        if "bytes" in types and root == "data":
            entry["source"].update({"kind": "binary_field", "offset": 0, "length": 1, "data_type": "uint", "endianness": "little", "signed": False})
        entry["plottable"] = bool(set(types) & {"boolean", "integer", "float", "numpy_scalar", "string"})
        result.append(entry)
    return sorted(result, key=lambda item: item["path"])


def _raw_bytes(value: Any) -> bytes | None:
    if isinstance(value, (bytes, bytearray)): return bytes(value)
    if isinstance(value, dict) and set(value) == {"$bytes_hex"}:
        try: return bytes.fromhex(str(value["$bytes_hex"]))
        except ValueError: return None
    return None


def _matches_series(record: dict, series: dict) -> bool:
    if record.get("__events_only"):
        return False
    if record.get("__insight_sample"):
        return str(series.get("id")) in record.get("__insight_values", {})
    if series.get("query") and not _SERIES_QUERY_ENGINE.matches_record(
        record, series.get("query")
    ):
        return False
    if series.get("session_id") and str(record.get("session_id", "")) != str(series["session_id"]): return False
    if series.get("direction") in {"RX", "TX"} and record.get("direction") != series["direction"]: return False
    names = series.get("message_names", [])
    if names and not any(fnmatch.fnmatchcase(str(record.get("name", "")), pattern) for pattern in names): return False
    return True


def _matches_timeline(record: dict, timeline: dict) -> bool:
    if timeline.get("session_id") and str(record.get("session_id", "")) != str(timeline["session_id"]):
        return False
    if timeline.get("direction") in {"RX", "TX"} and record.get("direction") != timeline["direction"]:
        return False
    names = timeline.get("message_names", [])
    return not names or any(
        fnmatch.fnmatchcase(str(record.get("name", "")), pattern)
        for pattern in names
    )


def _timeline_lane(record: dict, lane_by: str) -> str:
    name = str(record.get("name") or "(unnamed)")
    direction = str(record.get("direction") or "?")
    session = str(record.get("session_name") or record.get("session_id") or "(session)")
    if lane_by == "name":
        return name
    if lane_by == "direction_name":
        return f"{direction} · {name}"
    if lane_by == "session_name":
        return f"{session} · {name}"
    return f"{session} · {direction} · {name}"


def _timeline_event_text(record: dict) -> str:
    name = str(record.get("name") or "(unnamed)")
    direction = str(record.get("direction") or "?")
    session = str(record.get("session_name") or record.get("session_id") or "(session)")
    size = record.get("frame_size", record.get("size"))
    size_text = f" · {size} B" if size is not None else ""
    return f"{direction} {name} · {session}{size_text}"


def _event_rule_matches_record(record: dict, rule: dict) -> bool:
    # Event records are intentionally tagged ``__events_only`` so they cannot
    # be re-extracted as data-series samples. That tag must not suppress the
    # overlay matcher itself.
    if rule.get("query") and not _SERIES_QUERY_ENGINE.matches_record(
        record, rule.get("query")
    ):
        return False
    if rule.get("session_id") and str(record.get("session_id", "")) != str(rule["session_id"]):
        return False
    if rule.get("direction") in {"RX", "TX"} and record.get("direction") != rule["direction"]:
        return False
    names = rule.get("message_names", [])
    return not names or any(
        fnmatch.fnmatchcase(str(record.get("name", "")), pattern)
        for pattern in names
    )


def _event_comparison_matches(value: Any, operator: str, comparison: str) -> bool:
    if value is None or isinstance(value, (dict, list, tuple, bytes, bytearray)):
        return False
    if operator == "contains":
        return comparison in str(value)
    expected: Any = comparison
    if isinstance(value, bool):
        lowered = comparison.strip().lower()
        if lowered in {"true", "1", "yes", "on"}:
            expected = True
        elif lowered in {"false", "0", "no", "off"}:
            expected = False
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            expected = float(comparison)
        except (TypeError, ValueError):
            return False
    if operator == "equals":
        return value == expected
    if operator == "not_equals":
        return value != expected
    try:
        if operator == "greater":
            return value > expected
        if operator == "greater_equal":
            return value >= expected
        if operator == "less":
            return value < expected
        if operator == "less_equal":
            return value <= expected
    except TypeError:
        return False
    return False


def _event_rule_value(record: dict, rule: dict) -> Any:
    return extract_insight_value(record, {
        "source": rule.get("source", {}),
        "transform": {"scale": 1.0, "offset": 0.0},
    })


def _event_marker_text(rule: dict, record: dict, value: Any = None) -> str:
    message = str(record.get("name") or "(unnamed)")
    direction = str(record.get("direction") or "?")
    text = f"{direction} {message}"
    if rule.get("trigger") != "appearance":
        text += f" · value={value}"
    return text


def _extract_insight_raw_value(record: dict, source: dict) -> Any:
    kind = source.get("kind", "parsed_field")
    if kind in {"parsed_field", "binary_field"}:
        tokens = source.get("path_tokens")
        if isinstance(tokens, list):
            value = get_path_tokens(record.get("data"), tokens, None)
        else:
            path = str(source.get("path", ""))
            if path.startswith("data."): path = path[len("data."):]
            value = get_path(record.get("data"), path, None)
        if kind == "binary_field":
            extractor = copy.deepcopy(source); extractor["type"] = "binary_field"
            value = extract_value(record.get("data"), extractor, record)
    elif kind == "header_field":
        tokens = source.get("path_tokens")
        if isinstance(tokens, list):
            value = get_path_tokens(record.get("header_fields"), tokens, None)
        else:
            path = str(source.get("path", ""))
            if path.startswith("header_fields."): path = path[len("header_fields."):]
            value = get_path(record.get("header_fields"), path, None)
    elif kind == "metadata":
        value = record.get(str(source.get("field", "size")))
    else:
        raw = _raw_bytes(record.get("data"))
        extractor = copy.deepcopy(source); extractor["type"] = "raw_bytes"
        value = extract_value(raw, extractor) if raw is not None else None
    return value


def _record_processor_error(diagnostics, label, error):
    if diagnostics is None:
        return
    diagnostics["count"] = int(diagnostics.get("count", 0)) + 1
    errors = diagnostics.setdefault("errors", [])
    message = f"{label}: {type(error).__name__}: {error}"[:1000]
    if message not in errors and len(errors) < 20:
        errors.append(message)


def _resolve_insight_processor(config, diagnostics=None, label="Value processor"):
    processor = normalize_insight_processor(config)
    if not processor["enabled"]:
        return False
    try:
        return InsightProcessorRuntime(processor)
    except BaseException as error:
        _record_processor_error(diagnostics, label, error)
        return None


def _insight_value_context(
    *, axis, record, processor, view_id="", subplot_id=None,
    series_id=None, label="",
):
    return InsightValueContext(
        axis=axis,
        record=MappingProxyType(record),
        view_id=str(view_id or ""),
        subplot_id=str(subplot_id) if subplot_id else None,
        series_id=str(series_id) if series_id else None,
        label=str(label or ""),
        options=MappingProxyType(processor.get("options", {})),
    )


def extract_insight_value(
    record: dict, series: dict, *, processor_runtime=_PROCESSOR_UNSET,
    context: InsightValueContext | None = None, diagnostics=None,
) -> Any:
    if record.get("__insight_sample"):
        retained_values = record.get("__insight_values", {})
        series_id = str(series.get("id"))
        if series_id in retained_values:
            return retained_values.get(series_id)
    value = _extract_insight_raw_value(record, series.get("source", {}))
    processor = _insight_processor_config(series.get("processor"))
    if processor["enabled"]:
        if processor_runtime is _PROCESSOR_UNSET:
            processor_runtime = _resolve_insight_processor(
                processor, diagnostics, series.get("label", "Y processor"),
            )
        if processor_runtime is None:
            return None
        if processor_runtime is not False:
            if context is None:
                context = _insight_value_context(
                    axis="y", record=record, processor=processor,
                    series_id=series.get("id"), label=series.get("label", ""),
                )
            try:
                value = processor_runtime.process(value, context)
            except BaseException as error:
                _record_processor_error(
                    diagnostics, series.get("label", "Y processor"), error,
                )
                return None
            if value is not None and not isinstance(
                value, (bool, str, numbers.Real)
            ):
                _record_processor_error(
                    diagnostics, series.get("label", "Y processor"),
                    TypeError(
                        f"processor returned {type(value).__name__}; expected "
                        "number, boolean, string, or None"
                    ),
                )
                return None
    if isinstance(value, bool): return value
    if isinstance(value, numbers.Real) and not isinstance(value, bool):
        transform = series.get("transform", {})
        value = float(value) * float(transform.get("scale", 1.0)) + float(transform.get("offset", 0.0))
    return value


def extract_insight_x_value(
    record: dict, x_axis: dict, *, processor_runtime=_PROCESSOR_UNSET,
    context: InsightValueContext | None = None, diagnostics=None,
) -> float | None:
    config = (
        x_axis
        if isinstance(x_axis, dict) and {
            "kind", "value_type", "timestamp_mode", "transform", "processor",
        }.issubset(x_axis)
        else normalize_insight_x_axis(x_axis)
    )
    if record.get("__insight_sample") and record.get("__insight_x") is not None:
        retained_x = record.get("__insight_x")
        try:
            if config["value_type"] == "datetime":
                # Repair older/current buffered samples whose engine emitted a
                # numeric nanosecond value instead of canonical Unix seconds.
                return timestamp_ns(retained_x) / 1_000_000_000.0
            return float(retained_x)
        except (TypeError, ValueError, OverflowError, OSError):
            return None
    if config["kind"] == "timestamp":
        value = record.get("timestamp")
    else:
        value = _extract_insight_raw_value(record, config)
    processor = config["processor"]
    if processor["enabled"]:
        if processor_runtime is _PROCESSOR_UNSET:
            processor_runtime = _resolve_insight_processor(
                processor, diagnostics, config.get("label", "X processor"),
            )
        if processor_runtime is None:
            return None
        if processor_runtime is not False:
            if context is None:
                context = _insight_value_context(
                    axis="x", record=record, processor=processor,
                    label=config.get("label", ""),
                )
            try:
                value = processor_runtime.process(value, context)
            except BaseException as error:
                _record_processor_error(
                    diagnostics, config.get("label", "X processor"), error,
                )
                return None
    if value is None:
        return None
    if isinstance(value, (dict, list, tuple, bytes, bytearray)):
        if processor["enabled"]:
            _record_processor_error(
                diagnostics, config.get("label", "X processor"),
                TypeError(
                    f"processor returned {type(value).__name__}; expected "
                    "a numeric or datetime-compatible value, or None"
                ),
            )
        return None
    if isinstance(value, numbers.Real) and not isinstance(value, bool):
        transform = config.get("transform", {})
        value = (
            float(value) * float(transform.get("scale", 1.0))
            + float(transform.get("offset", 0.0))
        )
    if config["kind"] == "timestamp" or config["value_type"] == "datetime":
        try:
            value_ns = timestamp_ns(value)
        except (TypeError, ValueError) as error:
            if processor["enabled"]:
                _record_processor_error(
                    diagnostics, config.get("label", "X processor"), error,
                )
            return None
        return value_ns / 1_000_000_000.0
    try:
        numeric = float(value)
    except (TypeError, ValueError) as error:
        if processor["enabled"]:
            _record_processor_error(
                diagnostics, config.get("label", "X processor"), error,
            )
        return None
    if not math.isfinite(numeric):
        if processor["enabled"]:
            _record_processor_error(
                diagnostics, config.get("label", "X processor"),
                ValueError("processor returned a non-finite numeric value"),
            )
        return None
    return numeric


def _downsample(samples: list[tuple[float, Any, dict]], maximum: int) -> list[tuple[float, Any, dict]]:
    if len(samples) <= maximum: return samples
    step = len(samples) / maximum
    return [samples[min(len(samples) - 1, int(index * step))] for index in range(maximum)]


def build_protocol_insight_result(view: dict, records: list[dict]) -> dict:
    display = view.get("display") if isinstance(view.get("display"), dict) else {}
    maximum = max(100, int(display.get("maximum_points", view.get("maximum_rows", 10_000))))
    display_window = display.get("window") if isinstance(display.get("window"), dict) else {}
    rolling_window_seconds = None
    if display_window.get("mode") == "last" and records:
        seconds = float(display_window.get("amount", 60.0)) * {
            "milliseconds": .001, "seconds": 1, "minutes": 60, "hours": 3600,
        }.get(display_window.get("unit", "seconds"), 1)
        rolling_window_seconds = max(0.001, seconds)
        timestamps = []
        for record in records:
            try: timestamps.append(int(record.get("timestamp_ns") or timestamp_ns(record.get("timestamp"))))
            except (TypeError, ValueError): pass
        if timestamps:
            cutoff_ns = max(timestamps) - int(seconds * 1_000_000_000)
            records = [
                record for record in records
                if int(record.get("timestamp_ns") or timestamp_ns(record.get("timestamp"))) >= cutoff_ns
            ]
    x_axis = normalize_insight_x_axis(view.get("x_axis"))
    diagnostics = {"count": 0, "errors": []}
    x_runtime = _resolve_insight_processor(
        x_axis["processor"], diagnostics, x_axis.get("label", "X processor"),
    )
    x_values = {}
    for record in records:
        x_context = (
            _insight_value_context(
                axis="x", record=record, processor=x_axis["processor"],
                view_id=view.get("id"), label=x_axis.get("label", ""),
            )
            if x_axis["processor"]["enabled"] else None
        )
        x_values[id(record)] = extract_insight_x_value(
            record, x_axis, processor_runtime=x_runtime,
            context=x_context, diagnostics=diagnostics,
        )
    if x_axis["kind"] == "timestamp" and x_axis["timestamp_mode"] == "elapsed":
        valid_timestamps = [value for value in x_values.values() if value is not None]
        origin = min(valid_timestamps) if valid_timestamps else None
        if origin is not None:
            x_values = {
                record_id: value - origin if value is not None else None
                for record_id, value in x_values.items()
            }
        x_axis["relative_origin"] = origin
    suggested_x_range = None
    if rolling_window_seconds is not None and x_axis["kind"] == "timestamp":
        valid_x_values = [value for value in x_values.values() if value is not None]
        if valid_x_values:
            newest_x = max(valid_x_values)
            suggested_x_range = [
                newest_x - rolling_window_seconds,
                newest_x,
            ]
    plots, total_samples, omitted_samples = [], 0, 0
    event_results = []
    ordered_records = sorted(
        (record for record in records if x_values[id(record)] is not None),
        key=lambda record: x_values[id(record)],
    )
    for raw_rule in view.get("event_markers", []):
        rule = normalize_insight_event_marker(raw_rule)
        points = []
        previous_conditions = {}
        for record in ordered_records:
            if record.get("__insight_sample"):
                continue
            if not _event_rule_matches_record(record, rule):
                continue
            trigger = rule["trigger"]
            value = None
            matched = trigger == "appearance"
            if trigger != "appearance":
                value = _event_rule_value(record, rule)
                condition = _event_comparison_matches(
                    value, rule["operator"], rule["comparison"],
                )
                if trigger == "condition":
                    matched = condition
                else:
                    stream_key = (
                        str(record.get("session_id", "")),
                        str(record.get("name", "")),
                        str(record.get("direction", "")),
                    )
                    previous = previous_conditions.get(stream_key)
                    matched = previous is False and condition
                    previous_conditions[stream_key] = condition
            if matched:
                points.append((
                    x_values[id(record)], record,
                    _event_marker_text(rule, record, value), value,
                ))
        if len(points) > maximum:
            omitted_samples += len(points) - maximum
            points = points[-maximum:]
        total_samples += len(points)
        event_results.append({"config": rule, "points": points})
    for subplot in view.get("subplots", []):
        if subplot.get("kind") == "timeline":
            timeline = subplot.get("timeline", {})
            samples = []
            for record in records:
                if record.get("__insight_sample"):
                    continue
                if not _matches_timeline(record, timeline):
                    continue
                x_value = x_values[id(record)]
                if x_value is None:
                    continue
                lane = _timeline_lane(record, timeline.get("lane_by", "session_direction_name"))
                samples.append((x_value, lane, record, _timeline_event_text(record)))
            samples.sort(key=lambda item: item[0])
            if len(samples) > maximum:
                omitted_samples += len(samples) - maximum
                samples = samples[-maximum:]
            lanes = sorted({sample[1] for sample in samples})
            category_map = {lane: index for index, lane in enumerate(lanes)}
            points = [
                (x_value, category_map[lane], record, event_text, lane)
                for x_value, lane, record, event_text in samples
            ]
            total_samples += len(points)
            plots.append({
                "config": subplot, "series": [], "categories": category_map,
                "timeline": {
                    "points": points,
                    "last": points[-1] if points else None,
                },
            })
            continue
        prepared, categories = [], set()
        per_series_max = max(100, maximum // max(1, len(subplot.get("series", []))))
        raw_series = []
        for series in subplot.get("series", []):
            if not series.get("plot_enabled", series.get("visible", True)) or not series.get("visible", True):
                continue
            samples = []
            y_processor = normalize_insight_processor(series.get("processor"))
            y_runtime = _resolve_insight_processor(
                y_processor, diagnostics,
                series.get("label", "Y processor"),
            )
            for record in records:
                if not _matches_series(record, series): continue
                x_value = x_values[id(record)]
                if x_value is None: continue
                y_context = (
                    _insight_value_context(
                        axis="y", record=record, processor=y_processor,
                        view_id=view.get("id"), subplot_id=subplot.get("id"),
                        series_id=series.get("id"), label=series.get("label", ""),
                    )
                    if y_processor["enabled"] else None
                )
                value = extract_insight_value(
                    record, series, processor_runtime=y_runtime,
                    context=y_context, diagnostics=diagnostics,
                )
                if value is None or isinstance(value, (dict, list, tuple, bytes, bytearray)): continue
                if isinstance(value, bool): value = 1.0 if value else 0.0
                elif isinstance(value, numbers.Real):
                    value = float(value)
                    if not math.isfinite(value): continue
                else:
                    value = str(value); categories.add(value)
                samples.append((x_value, value, record))
            samples.sort(key=lambda item: item[0]); raw_series.append((series, _downsample(samples, per_series_max)))
        category_map = {value: index for index, value in enumerate(sorted(categories))}
        for series, samples in raw_series:
            points = [(timestamp, category_map.get(value, value), record, value) for timestamp, value, record in samples]
            total_samples += len(points)
            prepared.append({"config": series, "points": points, "last": points[-1] if points else None})
        plots.append({"config": subplot, "series": prepared, "categories": category_map})
    return {
        "plots": plots, "records": len(records), "samples": total_samples,
        "event_markers": event_results,
        "processor_diagnostics": diagnostics,
        "omitted_samples": omitted_samples,
        "generated_at": time.time(), "x_axis": x_axis,
        "suggested_x_range": suggested_x_range,
    }


def _source_label(series: dict) -> str:
    source = series.get("source", {}); kind = source.get("kind", "parsed_field")
    if kind in {"parsed_field", "header_field"}: detail = source.get("path", "")
    elif kind == "metadata": detail = source.get("field", "")
    else: detail = f"bytes {source.get('offset', 0)}:{source.get('length', 1)} {source.get('data_type', 'uint')}"
    processor = normalize_insight_processor(series.get("processor"))
    if processor["enabled"]:
        detail += f" -> {processor['module']}.{processor['function']}"
    names = ", ".join(series.get("message_names", [])) or "all messages"
    return f"{names} | {detail}"


class InsightProcessorEditor(QtWidgets.QGroupBox):
    """Reusable module/function configuration for X- and Y-value processing."""

    def __init__(self, processor=None, parent=None, *, axis="y"):
        super().__init__("Optional value processor", parent)
        self.axis = "x" if axis == "x" else "y"
        self.config = normalize_insight_processor(processor)
        layout = QtWidgets.QFormLayout(self)
        self.enabled = QtWidgets.QCheckBox(
            "Process extracted values with a trusted project function"
        )
        self.enabled.setChecked(self.config["enabled"])
        self.module = QtWidgets.QLineEdit(self.config["module"])
        self.module.setPlaceholderText("externals.insight_processors_example")
        self.function = QtWidgets.QLineEdit(self.config["function"])
        self.function.setPlaceholderText("clamp_numeric")
        self.options = QtWidgets.QPlainTextEdit()
        self.options.setMaximumHeight(90)
        self.options.setPlainText(json.dumps(
            self.config["options"], indent=2, sort_keys=True,
        ))
        buttons = QtWidgets.QHBoxLayout()
        self.validate_button = QtWidgets.QPushButton("Reload and Validate")
        self.test_button = QtWidgets.QPushButton("Test Sample Value...")
        self.example_button = QtWidgets.QPushButton("Create Example Processor Module...")
        buttons.addWidget(self.validate_button); buttons.addWidget(self.test_button)
        buttons.addWidget(self.example_button)
        buttons.addStretch(1)
        layout.addRow("", self.enabled)
        layout.addRow("Python module", self.module)
        layout.addRow("Function", self.function)
        layout.addRow("Options JSON", self.options)
        layout.addRow("", buttons)
        self.note = QtWidgets.QLabel(
            "Expected signature: function(value, context) -> one plottable value "
            "or None. Processing occurs before numeric scale and offset."
        )
        self.note.setWordWrap(True); self.note.setStyleSheet("color: palette(mid);")
        layout.addRow("", self.note)
        tooltips = {
            self.enabled: "Enable custom preprocessing for this X axis or Y series.",
            self.module: "Importable dotted Python module containing the processor.",
            self.function: "Synchronous callable accepting exactly value and context.",
            self.options: "Optional JSON object exposed as context.options.",
            self.validate_button: "Reload the module and validate the callable signature.",
            self.test_button: "Run the configured function against a JSON sample value.",
            self.example_button: (
                "Create a documented processor module under PROJECT_ROOT/externals "
                "and optionally use it in this configuration."
            ),
        }
        for widget, text in tooltips.items():
            widget.setToolTip(text)
            label = layout.labelForField(widget)
            if label is not None:
                label.setToolTip(text)
        self.enabled.toggled.connect(self._update_enabled)
        self.validate_button.clicked.connect(self._validate_clicked)
        self.test_button.clicked.connect(self._test_sample_value)
        self.example_button.clicked.connect(self._create_example_processor_module)
        self._update_enabled()

    def _update_enabled(self, _checked=None):
        enabled = self.enabled.isChecked()
        for widget in (
            self.module, self.function, self.options, self.validate_button,
            self.test_button,
        ):
            widget.setEnabled(enabled)

    @staticmethod
    def _example_processor_source():
        return '''\
"""Example Communication Hub insight value processor.

Processor contract
==================

``process_value`` is called synchronously as::

    process_value(value: Any, context: InsightValueContext) -> Any

Inputs
------
value:
    The raw value extracted from the configured timestamp, parsed field,
    decoded header field, raw bytes, or message metadata source. The processor
    runs before numeric scale and offset.

    Common input types are ``None``, ``bool``, ``int``, ``float``, ``str``,
    and datetime-compatible values for X axes. Treat the supplied value as
    read-only.

context:
    A frozen ``InsightValueContext`` with these attributes:

    * ``context.axis``: ``"x"`` for the shared X axis or ``"y"`` for a series.
    * ``context.record``: read-only mapping containing the complete stored row.
    * ``context.view_id``: current insight-view ID.
    * ``context.subplot_id``: target subplot ID for Y, otherwise ``None``.
    * ``context.series_id``: target series ID for Y, otherwise ``None``.
    * ``context.label``: configured X-axis or series label.
    * ``context.options``: read-only mapping from the Options JSON field.

Output
------
Return exactly one value:

* ``int`` or finite ``float`` for numeric plotting.
* ``bool`` for binary/state plotting.
* ``str`` for categorical Y plotting or a datetime-compatible X value.
* A Python ``datetime``/pandas-compatible value for a datetime X axis.
* ``None`` to intentionally omit this sample without reporting an error.

Do not return dictionaries, lists, tuples, bytes, generators, or coroutines.
After this function returns, numeric scale and offset are applied, followed by
the configured numeric/datetime/categorical plot conversion.

Errors and performance
----------------------
Raising an exception omits only the affected sample. The insight status shows
the processor error count and its tooltip contains representative errors.
Functions should be deterministic, stateless, and fast because they may run
once for every visible message and series during each live refresh.

Example options
---------------

Use this JSON in the configuration window to exercise the example:

    {
      "mode": "clamp",
      "minimum": 0,
      "maximum": 100
    }

Supported example modes are ``identity``, ``absolute``, ``clamp``,
``omit_below``, and ``mapping``.
"""

from __future__ import annotations

from typing import Any

from app.tools.communication_hub.insight_processor_runtime import InsightValueContext


def process_value(value: Any, context: InsightValueContext) -> Any:
    """Process one extracted X or Y value according to ``context.options``."""
    if value is None:
        return None

    mode = str(context.options.get("mode", "identity"))
    if mode == "identity":
        return value

    if mode == "mapping":
        mapping = context.options.get("mapping", {})
        if not isinstance(mapping, dict):
            raise TypeError("mapping option must be a JSON object")
        return str(mapping.get(str(value), value))

    numeric = float(value)
    if mode == "absolute":
        return abs(numeric)
    if mode == "clamp":
        minimum = context.options.get("minimum")
        maximum = context.options.get("maximum")
        if minimum is not None:
            numeric = max(float(minimum), numeric)
        if maximum is not None:
            numeric = min(float(maximum), numeric)
        return numeric
    if mode == "omit_below":
        minimum = float(context.options.get("minimum", 0))
        return numeric if numeric >= minimum else None

    raise ValueError(f"Unsupported processor mode: {mode}")
'''

    def _create_example_processor_module(self):
        externals_root = (Path(PROJECT_ROOT) / "externals").resolve()
        try:
            externals_root.mkdir(parents=True, exist_ok=True)
            init_file = externals_root / "__init__.py"
            if not init_file.exists():
                init_file.write_text("", encoding="utf-8")
        except BaseException as error:
            QtWidgets.QMessageBox.critical(
                self, "Could not prepare externals folder",
                f"{type(error).__name__}: {error}",
            )
            return

        default_path = externals_root / "insight_value_processor_example.py"
        selected, _filter = QtWidgets.QFileDialog.getSaveFileName(
            self, "Create example insight processor",
            str(default_path), "Python modules (*.py)",
        )
        if not selected:
            return
        target = Path(selected)
        if target.suffix.lower() != ".py":
            target = target.with_suffix(".py")
        try:
            target = target.resolve()
            relative = target.relative_to(externals_root)
        except (OSError, ValueError):
            QtWidgets.QMessageBox.warning(
                self, "Processor must be inside externals",
                "Choose a Python file inside the current project's externals folder:\n\n"
                f"{externals_root}",
            )
            return
        if target.exists():
            QtWidgets.QMessageBox.warning(
                self, "Processor module already exists",
                f"The file already exists and was not overwritten:\n\n{target}",
            )
            return
        if not all(part.isidentifier() for part in relative.with_suffix("").parts):
            QtWidgets.QMessageBox.warning(
                self, "Invalid module path",
                "Every folder and the Python filename must be a valid Python identifier.",
            )
            return
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            current = externals_root
            for part in relative.parent.parts:
                current /= part
                init_file = current / "__init__.py"
                if not init_file.exists():
                    init_file.write_text("", encoding="utf-8")
            with target.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(self._example_processor_source())
        except BaseException as error:
            QtWidgets.QMessageBox.critical(
                self, "Could not create processor module",
                f"{type(error).__name__}: {error}",
            )
            return

        module_name = ".".join(("externals", *relative.with_suffix("").parts))
        InsightProcessorRuntime.clear_cache()
        use_created = QtWidgets.QMessageBox.question(
            self, "Example processor created",
            f"Created:\n{target}\n\n"
            "Do you want to use this processor in the current configuration?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes,
        )
        if use_created != QtWidgets.QMessageBox.Yes:
            return
        self.enabled.setChecked(True)
        self.module.setText(module_name)
        self.function.setText("process_value")
        self.options.setPlainText(
            '{\n  "mode": "clamp",\n  "minimum": 0,\n  "maximum": 100\n}'
        )

    def result_config(self):
        text = self.options.toPlainText().strip() or "{}"
        options = json.loads(text)
        if not isinstance(options, dict):
            raise ValueError("Processor options must be a JSON object")
        result = normalize_insight_processor({
            "enabled": self.enabled.isChecked(),
            "module": self.module.text(),
            "function": self.function.text(),
            "options": options,
        })
        if result["enabled"] and not (result["module"] and result["function"]):
            raise ValueError("Enabled value processor requires module and function")
        return result

    def validate_config(self, *, reload_module=False):
        config = self.result_config()
        validate_insight_processor(config, reload_module=reload_module)
        return config

    def _validate_clicked(self):
        try:
            self.validate_config(reload_module=True)
        except BaseException as error:
            QtWidgets.QMessageBox.warning(
                self, "Value processor is invalid",
                f"{type(error).__name__}: {error}",
            )
            return
        QtWidgets.QMessageBox.information(
            self, "Value processor is valid",
            "The module loaded and the function accepts exactly (value, context).",
        )

    def _test_sample_value(self):
        text, accepted = QtWidgets.QInputDialog.getText(
            self, "Test processor", "JSON sample value", text="1",
        )
        if not accepted:
            return
        try:
            value = json.loads(text)
            config = self.validate_config()
            runtime = InsightProcessorRuntime(config)
            context = InsightValueContext(
                axis=self.axis, record=MappingProxyType({}),
                label="Test sample",
                options=MappingProxyType(config.get("options", {})),
            )
            result = runtime.process(value, context)
            if result is not None and isinstance(
                result, (dict, list, tuple, bytes, bytearray)
            ):
                raise TypeError(
                    f"processor returned {type(result).__name__}; expected one "
                    "plottable value or None"
                )
            if self.axis == "y" and result is not None and not isinstance(
                result, (bool, str, numbers.Real)
            ):
                raise TypeError(
                    f"Y processor returned unsupported {type(result).__name__}"
                )
        except BaseException as error:
            QtWidgets.QMessageBox.warning(
                self, "Processor sample failed",
                f"{type(error).__name__}: {error}",
            )
            return
        QtWidgets.QMessageBox.information(
            self, "Processor sample result",
            f"Returned {type(result).__name__}: {result!r}",
        )


class InsightXAxisDialog(QtWidgets.QDialog):
    """Configure the single X-axis source shared by the insight view."""

    def __init__(self, catalog, x_axis=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configure shared X axis")
        self.resize(600, 470)
        self.config = normalize_insight_x_axis(x_axis)
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout(); layout.addLayout(form)

        self.kind = QtWidgets.QComboBox()
        for title, value in (
            ("Message timestamp", "timestamp"),
            ("Parsed data field", "parsed_field"),
            ("Decoded header field", "header_field"),
            ("Raw byte range", "raw_bytes"),
            ("Message metadata", "metadata"),
        ):
            self.kind.addItem(title, value)
        self.kind.setCurrentIndex(max(0, self.kind.findData(self.config["kind"])))
        self.label = QtWidgets.QLineEdit(self.config.get("label", ""))
        self.timestamp_mode = QtWidgets.QComboBox()
        self.timestamp_mode.addItem("Exact local time", "exact")
        self.timestamp_mode.addItem("Elapsed from first displayed message", "elapsed")
        self.timestamp_mode.setCurrentIndex(max(
            0, self.timestamp_mode.findData(self.config.get("timestamp_mode", "exact"))
        ))
        self.value_type = QtWidgets.QComboBox()
        self.value_type.addItem("Numeric", "numeric")
        self.value_type.addItem("Date and time", "datetime")
        self.value_type.setCurrentIndex(max(0, self.value_type.findData(self.config["value_type"])))
        self.path = QtWidgets.QComboBox(); self.path.setEditable(True)
        field_paths = sorted({path for item in catalog.values() for path in item.get("fields", [])})
        self.path.addItems(field_paths); self.path.setCurrentText(str(self.config.get("path", "")))
        self.metadata = QtWidgets.QComboBox(); self.metadata.addItems(X_METADATA_FIELDS)
        self.metadata.setCurrentText(str(self.config.get("field", "id")))

        self.raw_box = QtWidgets.QWidget()
        raw_form = QtWidgets.QFormLayout(self.raw_box); raw_form.setContentsMargins(0, 0, 0, 0)
        self.offset = QtWidgets.QSpinBox(); self.offset.setRange(-10_000_000, 10_000_000); self.offset.setValue(int(self.config.get("offset", 0)))
        self.length = QtWidgets.QSpinBox(); self.length.setRange(1, 1_000_000); self.length.setValue(int(self.config.get("length", 1)))
        self.data_type = QtWidgets.QComboBox(); self.data_type.addItems(["uint", "int", "float32", "float64", "text"])
        self.data_type.setCurrentText(str(self.config.get("data_type", "uint")))
        self.endianness = QtWidgets.QComboBox(); self.endianness.addItems(["little", "big"]); self.endianness.setCurrentText(str(self.config.get("endianness", "little")))
        self.signed = QtWidgets.QCheckBox("Interpret integer as signed"); self.signed.setChecked(bool(self.config.get("signed", False)))
        self.encoding = QtWidgets.QComboBox(); self.encoding.setEditable(True); self.encoding.addItems(["utf-8", "ascii", "latin-1", "utf-16-le", "utf-16-be"]); self.encoding.setCurrentText(str(self.config.get("encoding", "utf-8")))
        for title, widget in (
            ("Offset", self.offset), ("Length", self.length), ("Data type", self.data_type),
            ("Endianness", self.endianness), ("", self.signed), ("Text encoding", self.encoding),
        ):
            raw_form.addRow(title, widget)

        transform = self.config.get("transform", {})
        self.scale = QtWidgets.QDoubleSpinBox(); self.scale.setRange(-1e12, 1e12); self.scale.setDecimals(9); self.scale.setValue(float(transform.get("scale", 1.0)))
        self.value_offset = QtWidgets.QDoubleSpinBox(); self.value_offset.setRange(-1e12, 1e12); self.value_offset.setDecimals(9); self.value_offset.setValue(float(transform.get("offset", 0.0)))
        for title, widget in (
            ("Source", self.kind), ("Timestamp display", self.timestamp_mode),
            ("Axis label", self.label), ("Value type", self.value_type),
            ("Field path", self.path), ("Metadata field", self.metadata),
            ("Raw extraction", self.raw_box), ("Numeric scale", self.scale),
            ("Numeric offset", self.value_offset),
        ):
            form.addRow(title, widget)
        self.processor = InsightProcessorEditor(
            self.config.get("processor"), self, axis="x",
        )
        layout.addWidget(self.processor)

        note = QtWidgets.QLabel(
            "This X definition is shared by every series and subplot. Messages without a valid "
            "value are omitted. Scale and offset apply only to custom numeric sources."
        )
        note.setWordWrap(True); note.setStyleSheet("color: palette(mid);"); layout.addWidget(note)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
        self.kind.currentIndexChanged.connect(self._update_visibility)
        self.timestamp_mode.currentIndexChanged.connect(self._timestamp_mode_changed)
        self.value_type.currentIndexChanged.connect(self._update_visibility)
        self._update_visibility()

    def _timestamp_mode_changed(self, _index=None):
        if self.kind.currentData() != "timestamp":
            return
        if self.label.text() in {"Time (local)", "Elapsed time (s)"}:
            self.label.setText(
                "Elapsed time (s)"
                if self.timestamp_mode.currentData() == "elapsed"
                else "Time (local)"
            )
        self._update_visibility()

    def _update_visibility(self, _index=None):
        kind = self.kind.currentData()
        visibility = {
            self.timestamp_mode: kind == "timestamp",
            self.path: kind in {"parsed_field", "header_field"},
            self.metadata: kind == "metadata",
            self.raw_box: kind == "raw_bytes",
            self.value_type: kind != "timestamp",
            self.scale: kind != "timestamp" and self.value_type.currentData() == "numeric",
            self.value_offset: kind != "timestamp" and self.value_type.currentData() == "numeric",
        }
        form = self.layout().itemAt(0).layout()
        for widget, visible in visibility.items():
            widget.setVisible(visible)
            label = form.labelForField(widget)
            if label is not None:
                label.setVisible(visible)
        if kind == "timestamp":
            value_type = (
                "numeric" if self.timestamp_mode.currentData() == "elapsed"
                else "datetime"
            )
            self.value_type.setCurrentIndex(self.value_type.findData(value_type))

    def accept(self):
        kind = self.kind.currentData()
        if not self.label.text().strip():
            QtWidgets.QMessageBox.warning(self, "Axis label required", "Enter a label for the X axis.")
            return
        if kind in {"parsed_field", "header_field"} and not self.path.currentText().strip():
            QtWidgets.QMessageBox.warning(self, "Field required", "Select or enter a shared X field.")
            return
        try:
            self.processor.validate_config()
        except BaseException as error:
            QtWidgets.QMessageBox.warning(
                self, "Value processor is invalid",
                f"{type(error).__name__}: {error}",
            )
            return
        super().accept()

    def result_config(self):
        kind = self.kind.currentData()
        result = {
            "kind": kind, "label": self.label.text().strip(),
            "timestamp_mode": self.timestamp_mode.currentData(),
            "value_type": (
                "numeric"
                if kind == "timestamp" and self.timestamp_mode.currentData() == "elapsed"
                else "datetime" if kind == "timestamp"
                else self.value_type.currentData()
            ),
            "transform": {"scale": self.scale.value(), "offset": self.value_offset.value()},
            "processor": self.processor.result_config(),
        }
        if kind in {"parsed_field", "header_field"}:
            result["path"] = self.path.currentText().strip()
        elif kind == "metadata":
            result["field"] = self.metadata.currentText()
        elif kind == "raw_bytes":
            result.update({
                "offset": self.offset.value(), "length": self.length.value(),
                "data_type": self.data_type.currentText(),
                "endianness": self.endianness.currentText(),
                "signed": self.signed.isChecked(),
                "encoding": self.encoding.currentText().strip() or "utf-8",
            })
        return normalize_insight_x_axis(result)


class InsightSubplotDialog(QtWidgets.QDialog):
    """Create either a value-series subplot or an event-lane subplot."""

    def __init__(self, sessions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add insight subplot")
        self.resize(580, 400)
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout(); layout.addLayout(form)
        self.title = QtWidgets.QLineEdit()
        self.title.setPlaceholderText("Subplot title")
        self.kind = QtWidgets.QComboBox()
        self.kind.addItem("Data plot", "plot")
        self.kind.addItem("Event-lane plot", "timeline")
        self.unit = QtWidgets.QLineEdit()
        self.unit.setPlaceholderText("Optional Y-axis unit")
        self.session = QtWidgets.QComboBox()
        self.session.addItem("All sessions in this view", "")
        for session in sessions:
            self.session.addItem(
                str(session.get("name", "Unnamed")), str(session.get("id", ""))
            )
        self.names = QtWidgets.QLineEdit()
        self.names.setPlaceholderText("All events, or wildcard patterns separated by commas")
        self.direction = QtWidgets.QComboBox()
        for title, value in (
            ("RX and TX", "any"), ("Received only", "RX"), ("Sent only", "TX"),
        ):
            self.direction.addItem(title, value)
        self.lane_by = QtWidgets.QComboBox()
        for title, value in (
            ("Session, direction, and message", "session_direction_name"),
            ("Session and message", "session_name"),
            ("Direction and message", "direction_name"),
            ("Message name", "name"),
        ):
            self.lane_by.addItem(title, value)
        for title, widget in (
            ("Subplot type", self.kind), ("Title", self.title),
            ("Y-axis unit", self.unit), ("Session filter", self.session),
            ("Event/message filter", self.names),
            ("Direction filter", self.direction), ("Event lanes", self.lane_by),
        ):
            form.addRow(title, widget)
        self.note = QtWidgets.QLabel()
        self.note.setWordWrap(True); self.note.setStyleSheet("color: palette(mid);")
        layout.addWidget(self.note)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.kind.currentIndexChanged.connect(self._update_visibility)
        self._update_visibility()

    def _update_visibility(self, _index=None):
        is_timeline = self.kind.currentData() == "timeline"
        form = self.layout().itemAt(0).layout()
        visibility = {
            self.unit: not is_timeline,
            self.session: is_timeline,
            self.names: is_timeline,
            self.direction: is_timeline,
            self.lane_by: is_timeline,
        }
        for widget, visible in visibility.items():
            widget.setVisible(visible)
            label = form.labelForField(widget)
            if label is not None:
                label.setVisible(visible)
        self.note.setText(
            "Event-lane plots place matching eligible messages observed while the "
            "Insight Dataset is running on categorical lanes. They freeze with the "
            "dataset on Stop and do not activate historical Message Table analysis."
            if is_timeline else
            "Data plots start empty. Add one or more series afterward to extract and "
            "plot numeric, state, header, raw-byte, or metadata values."
        )

    def accept(self):
        if not self.title.text().strip():
            QtWidgets.QMessageBox.warning(
                self, "Subplot title required", "Enter a title for the subplot."
            )
            return
        super().accept()

    def result_config(self):
        result = {
            "id": str(uuid.uuid4()),
            "title": self.title.text().strip(),
            "unit": self.unit.text().strip() if self.kind.currentData() == "plot" else "",
            "kind": self.kind.currentData(),
            "series": [],
        }
        if result["kind"] == "timeline":
            result["timeline"] = {
                "session_id": str(self.session.currentData() or ""),
                "message_names": [
                    item.strip() for item in self.names.text().split(",") if item.strip()
                ],
                "direction": self.direction.currentData(),
                "lane_by": self.lane_by.currentData(),
            }
        return result


class InsightEventMarkerDialog(QtWidgets.QDialog):
    """Configure a conditional event overlay shared by selected subplots."""

    def __init__(self, subplots, sessions, catalog, marker=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configure event marker")
        self.resize(720, 520)
        self.marker = normalize_insight_event_marker(marker)
        layout = QtWidgets.QVBoxLayout(self)
        tabs = QtWidgets.QTabWidget(); layout.addWidget(tabs, 1)
        trigger_page = QtWidgets.QWidget(); self.trigger_form = QtWidgets.QFormLayout(trigger_page)
        targets_page = QtWidgets.QWidget(); targets_form = QtWidgets.QFormLayout(targets_page)
        appearance_page = QtWidgets.QWidget(); appearance_form = QtWidgets.QFormLayout(appearance_page)
        tabs.addTab(trigger_page, "Trigger and filters")
        tabs.addTab(targets_page, "Target plots")
        tabs.addTab(appearance_page, "Appearance")
        self.label = QtWidgets.QLineEdit(self.marker["label"])
        self.session = QtWidgets.QComboBox()
        self.session.addItem("All sessions in this view", "")
        for session in sessions:
            self.session.addItem(
                str(session.get("name", "Unnamed")), str(session.get("id", ""))
            )
        self.session.setCurrentIndex(max(
            0, self.session.findData(self.marker["session_id"])
        ))
        self.names = QtWidgets.QLineEdit(", ".join(self.marker["message_names"]))
        all_names = sorted({
            name for item in catalog.values() for name in item.get("names", [])
        })
        self.names.setCompleter(QtWidgets.QCompleter(all_names, self.names))
        self.names.setPlaceholderText("All messages, or wildcard patterns")
        self.direction = QtWidgets.QComboBox()
        for title, value in (
            ("RX and TX", "any"), ("Received only", "RX"), ("Sent only", "TX"),
        ):
            self.direction.addItem(title, value)
        self.direction.setCurrentIndex(max(
            0, self.direction.findData(self.marker["direction"])
        ))
        self.trigger = QtWidgets.QComboBox()
        for title, value in (
            ("Message appears", "appearance"),
            ("Field matches on each message", "condition"),
            ("Field becomes a matching value", "becomes"),
        ):
            self.trigger.addItem(title, value)
        self.trigger.setCurrentIndex(max(
            0, self.trigger.findData(self.marker["trigger"])
        ))
        self.source_kind = QtWidgets.QComboBox()
        for title, value in (
            ("Parsed data field", "parsed_field"),
            ("Decoded header field", "header_field"),
            ("Message metadata", "metadata"),
        ):
            self.source_kind.addItem(title, value)
        source = self.marker["source"]
        self.source_kind.setCurrentIndex(max(
            0, self.source_kind.findData(source.get("kind", "parsed_field"))
        ))
        self.path = QtWidgets.QComboBox(); self.path.setEditable(True)
        field_paths = sorted({
            path for item in catalog.values() for path in item.get("fields", [])
        })
        self.path.addItems(field_paths)
        self.path.setCurrentText(str(source.get("path", "")))
        self.metadata = QtWidgets.QComboBox(); self.metadata.addItems(METADATA_FIELDS)
        self.metadata.setCurrentText(str(source.get("field", "parse_status")))
        self.operator = QtWidgets.QComboBox()
        for title, value in (
            ("Equals", "equals"), ("Does not equal", "not_equals"),
            ("Greater than", "greater"), ("Greater than or equal", "greater_equal"),
            ("Less than", "less"), ("Less than or equal", "less_equal"),
            ("Contains text", "contains"),
        ):
            self.operator.addItem(title, value)
        self.operator.setCurrentIndex(max(
            0, self.operator.findData(self.marker["operator"])
        ))
        self.comparison = QtWidgets.QLineEdit(self.marker["comparison"])
        self.all_targets = QtWidgets.QCheckBox("Show on every subplot")
        self.all_targets.setChecked(not self.marker["target_subplot_ids"])
        self.targets = QtWidgets.QListWidget()
        self.targets.setMaximumHeight(130)
        selected_targets = set(self.marker["target_subplot_ids"])
        for subplot in subplots:
            item = QtWidgets.QListWidgetItem(str(subplot.get("title", "Subplot")))
            item.setData(QtCore.Qt.UserRole, str(subplot.get("id", "")))
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            item.setCheckState(
                QtCore.Qt.Checked
                if str(subplot.get("id", "")) in selected_targets
                else QtCore.Qt.Unchecked
            )
            self.targets.addItem(item)
        self.color = ColorSelectionWidget(self.marker["color"])
        self.symbol = QtWidgets.QComboBox()
        for title, value in (
            ("Diamond", "d"), ("Circle", "o"), ("Square", "s"),
            ("Triangle", "t"), ("Plus", "+"), ("Cross", "x"), ("Star", "star"),
        ):
            self.symbol.addItem(title, value)
        self.symbol.setCurrentIndex(max(
            0, self.symbol.findData(self.marker["symbol"])
        ))
        for title, widget in (
            ("Hover label", self.label), ("Session filter", self.session),
            ("Message filter", self.names), ("Direction filter", self.direction),
            ("Trigger", self.trigger), ("Field source", self.source_kind),
            ("Field path", self.path), ("Metadata field", self.metadata),
            ("Condition", self.operator), ("Comparison value", self.comparison),
        ):
            self.trigger_form.addRow(title, widget)
        targets_form.addRow("Apply to", self.all_targets)
        targets_form.addRow("Selected subplots", self.targets)
        target_note = QtWidgets.QLabel(
            "Use every subplot for protocol-wide milestones. Select specific plots when the event is meaningful only beside related values."
        )
        target_note.setWordWrap(True); target_note.setStyleSheet("color: palette(mid);")
        targets_form.addRow("", target_note)
        appearance_form.addRow("Marker color", self.color)
        appearance_form.addRow("Marker shape", self.symbol)
        note = QtWidgets.QLabel(
            "A transition trigger fires only when a previous matching message in the "
            "displayed data had a non-matching value. Hovering a marker participates in "
            "the synchronized hover, and Pin current hover preserves its labels."
        )
        note.setWordWrap(True); note.setStyleSheet("color: palette(mid);")
        appearance_form.addRow("Guidance", note)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.trigger.currentIndexChanged.connect(self._update_visibility)
        self.source_kind.currentIndexChanged.connect(self._update_visibility)
        self.all_targets.toggled.connect(self.targets.setDisabled)
        self.targets.setDisabled(self.all_targets.isChecked())
        self._update_visibility()

    def _update_visibility(self, _index=None):
        has_condition = self.trigger.currentData() != "appearance"
        source_kind = self.source_kind.currentData()
        visibility = {
            self.source_kind: has_condition,
            self.path: has_condition and source_kind in {"parsed_field", "header_field"},
            self.metadata: has_condition and source_kind == "metadata",
            self.operator: has_condition,
            self.comparison: has_condition,
        }
        for widget, visible in visibility.items():
            widget.setVisible(visible)
            label = self.trigger_form.labelForField(widget)
            if label is not None:
                label.setVisible(visible)

    def accept(self):
        if not self.label.text().strip():
            QtWidgets.QMessageBox.warning(
                self, "Event label required", "Enter a hover label for this event."
            )
            return
        if self.trigger.currentData() != "appearance":
            if (
                self.source_kind.currentData() in {"parsed_field", "header_field"}
                and not self.path.currentText().strip()
            ):
                QtWidgets.QMessageBox.warning(
                    self, "Field required", "Select or enter a field path."
                )
                return
            if not self.comparison.text():
                QtWidgets.QMessageBox.warning(
                    self, "Comparison required", "Enter the value that triggers the event."
                )
                return
        if not self.all_targets.isChecked() and not self._selected_targets():
            QtWidgets.QMessageBox.warning(
                self, "Target required", "Select at least one target subplot."
            )
            return
        super().accept()

    def _selected_targets(self):
        return [
            str(self.targets.item(index).data(QtCore.Qt.UserRole))
            for index in range(self.targets.count())
            if self.targets.item(index).checkState() == QtCore.Qt.Checked
        ]

    def result_config(self):
        source_kind = self.source_kind.currentData()
        source = (
            {"kind": "metadata", "field": self.metadata.currentText()}
            if source_kind == "metadata"
            else {"kind": source_kind, "path": self.path.currentText().strip()}
        )
        return normalize_insight_event_marker({
            "id": self.marker["id"],
            "label": self.label.text().strip(),
            "session_id": str(self.session.currentData() or ""),
            "message_names": [
                item.strip() for item in self.names.text().split(",") if item.strip()
            ],
            "direction": self.direction.currentData(),
            "trigger": self.trigger.currentData(),
            "source": source,
            "operator": self.operator.currentData(),
            "comparison": self.comparison.text(),
            "target_subplot_ids": (
                [] if self.all_targets.isChecked() else self._selected_targets()
            ),
            "color": self.color.color(),
            "symbol": self.symbol.currentData(),
        })


class InsightEventMarkerManagerDialog(QtWidgets.QDialog):
    """Compact table manager that keeps marker complexity out of the canvas."""

    def __init__(self, subplots, sessions, catalog, markers, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Manage event markers")
        self.resize(980, 520)
        self.subplots = copy.deepcopy(subplots)
        self.sessions = copy.deepcopy(sessions)
        self.catalog = copy.deepcopy(catalog)
        self._markers = [normalize_insight_event_marker(item) for item in markers]
        layout = QtWidgets.QVBoxLayout(self)
        intro = QtWidgets.QLabel(
            "Markers annotate protocol events across one or more plots. Keep simple message appearances for milestones; use conditions or transitions only when a field value defines the event."
        )
        intro.setWordWrap(True); intro.setStyleSheet("color: palette(mid);")
        layout.addWidget(intro)
        self.table = QtWidgets.QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels([
            "Label", "Trigger", "Messages", "Direction", "Target plots", "Style",
        ])
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True); self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        for column in range(6):
            header.setSectionResizeMode(column, QtWidgets.QHeaderView.Stretch)
        self.table.doubleClicked.connect(self._edit)
        self.table.itemSelectionChanged.connect(self._update_actions)
        self.table.setToolTip("Double-click a marker to edit its trigger, filters, target plots, and appearance.")
        layout.addWidget(self.table, 1)
        actions = QtWidgets.QHBoxLayout(); layout.addLayout(actions)
        self.add_button = QtWidgets.QPushButton("New marker...")
        self.edit_button = QtWidgets.QPushButton("Edit selected...")
        self.remove_button = QtWidgets.QPushButton("Delete selected")
        self.add_button.clicked.connect(self._add); self.edit_button.clicked.connect(self._edit)
        self.remove_button.clicked.connect(self._remove)
        self.add_button.setToolTip("Create a new message appearance, field condition, or field transition marker.")
        self.edit_button.setToolTip("Edit every option for the selected marker in a focused dialog.")
        self.remove_button.setToolTip("Delete the selected marker from this insight view when Save is pressed.")
        actions.addWidget(self.add_button); actions.addWidget(self.edit_button); actions.addWidget(self.remove_button); actions.addStretch(1)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._reload()

    def _reload(self, selected_id=None):
        titles = {str(item.get("id")): str(item.get("title", "Subplot")) for item in self.subplots}
        trigger_labels = {"appearance": "Message appears", "condition": "Field matches", "becomes": "Field becomes value"}
        self.table.setRowCount(0)
        selected_row = -1
        for marker in self._markers:
            row = self.table.rowCount(); self.table.insertRow(row)
            targets = marker.get("target_subplot_ids", [])
            target_text = "Every subplot" if not targets else ", ".join(titles.get(str(item), str(item)) for item in targets)
            values = (
                marker.get("label", "Event"), trigger_labels.get(marker.get("trigger"), marker.get("trigger", "")),
                ", ".join(marker.get("message_names", [])) or "All messages",
                marker.get("direction", "any"), target_text,
                f"{marker.get('symbol', 'd')}  {marker.get('color', '')}",
            )
            for column, value in enumerate(values):
                item = QtWidgets.QTableWidgetItem(str(value)); item.setData(QtCore.Qt.UserRole, marker["id"])
                self.table.setItem(row, column, item)
            self.table.item(row, 5).setBackground(QtGui.QColor(marker.get("color", "#E69F00")))
            if marker["id"] == selected_id: selected_row = row
        if selected_row >= 0: self.table.selectRow(selected_row)
        elif self.table.rowCount(): self.table.selectRow(0)
        self._update_actions()

    def _selected_index(self):
        row = self.table.currentRow()
        if row < 0: return -1
        marker_id = self.table.item(row, 0).data(QtCore.Qt.UserRole)
        return next((index for index, item in enumerate(self._markers) if item["id"] == marker_id), -1)

    def _update_actions(self):
        selected = self._selected_index() >= 0
        self.edit_button.setEnabled(selected); self.remove_button.setEnabled(selected)

    def _add(self):
        dialog = InsightEventMarkerDialog(
            self.subplots, self.sessions, self.catalog, parent=self,
        )
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            marker = dialog.result_config(); self._markers.append(marker)
            self._reload(marker["id"])

    def _edit(self, *_args):
        index = self._selected_index()
        if index < 0: return
        dialog = InsightEventMarkerDialog(
            self.subplots, self.sessions, self.catalog, self._markers[index], self,
        )
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            marker = dialog.result_config(); self._markers[index] = marker
            self._reload(marker["id"])

    def _remove(self):
        index = self._selected_index()
        if index < 0: return
        del self._markers[index]; self._reload()

    def result_markers(self):
        return copy.deepcopy(self._markers)


class InsightTimelineDialog(QtWidgets.QDialog):
    """Configure a message-event timeline subplot."""

    def __init__(self, sessions, timeline=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configure message timeline")
        self.resize(560, 330)
        self.timeline = copy.deepcopy(timeline) if isinstance(timeline, dict) else {}
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout(); layout.addLayout(form)
        self.title = QtWidgets.QLineEdit(str(self.timeline.get("title") or "Message Timeline"))
        config = (
            self.timeline.get("timeline")
            if isinstance(self.timeline.get("timeline"), dict) else {}
        )
        self.session = QtWidgets.QComboBox()
        self.session.addItem("All sessions in this view", "")
        for session in sessions:
            self.session.addItem(
                str(session.get("name", "Unnamed")), str(session.get("id", ""))
            )
        self.session.setCurrentIndex(max(
            0, self.session.findData(str(config.get("session_id", "")))
        ))
        self.names = QtWidgets.QLineEdit(", ".join(config.get("message_names", [])))
        self.names.setPlaceholderText("All messages, or wildcard patterns separated by commas")
        self.direction = QtWidgets.QComboBox()
        for title, value in (
            ("RX and TX", "any"), ("Received only", "RX"), ("Sent only", "TX"),
        ):
            self.direction.addItem(title, value)
        self.direction.setCurrentIndex(max(
            0, self.direction.findData(config.get("direction", "any"))
        ))
        self.lane_by = QtWidgets.QComboBox()
        for title, value in (
            ("Session, direction, and message", "session_direction_name"),
            ("Session and message", "session_name"),
            ("Direction and message", "direction_name"),
            ("Message name", "name"),
        ):
            self.lane_by.addItem(title, value)
        self.lane_by.setCurrentIndex(max(
            0, self.lane_by.findData(config.get("lane_by", "session_direction_name"))
        ))
        for title, widget in (
            ("Title", self.title), ("Session filter", self.session),
            ("Message filter", self.names), ("Direction filter", self.direction),
            ("Timeline lanes", self.lane_by),
        ):
            form.addRow(title, widget)
        note = QtWidgets.QLabel(
            "Each retained message is shown as an event marker. Wildcards such as Status* "
            "are supported. Use the shared X-axis settings to switch between exact and "
            "elapsed time."
        )
        note.setWordWrap(True); note.setStyleSheet("color: palette(mid);")
        layout.addWidget(note)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def accept(self):
        if not self.title.text().strip():
            QtWidgets.QMessageBox.warning(
                self, "Timeline title required", "Enter a title for the timeline."
            )
            return
        super().accept()

    def result_config(self):
        return {
            "id": str(self.timeline.get("id") or uuid.uuid4()),
            "title": self.title.text().strip(),
            "unit": "",
            "kind": "timeline",
            "timeline": {
                "session_id": str(self.session.currentData() or ""),
                "message_names": [
                    item.strip() for item in self.names.text().split(",") if item.strip()
                ],
                "direction": self.direction.currentData(),
                "lane_by": self.lane_by.currentData(),
            },
            "series": [],
        }


class InsightSeriesDialog(QtWidgets.QDialog):
    def __init__(self, subplots, sessions, catalog, series=None, subplot_id=None, collection=None, parent=None):
        super().__init__(parent); self.setWindowTitle("Configure Protocol Insight series"); self.resize(720, 720)
        self.series = copy.deepcopy(series) if isinstance(series, dict) else {}
        self.target_subplot = subplot_id or self.series.get("subplot_id")
        layout = QtWidgets.QVBoxLayout(self)
        tabs = QtWidgets.QTabWidget(); tabs.setToolTip("Separate extraction choices from processing and thresholds. Plot presentation is configured in Display settings."); layout.addWidget(tabs, 1)
        basic_page = QtWidgets.QWidget(); basic_layout = QtWidgets.QVBoxLayout(basic_page); form = QtWidgets.QFormLayout(); basic_layout.addLayout(form); basic_layout.addStretch(1)
        processing_page = QtWidgets.QWidget(); processing_layout = QtWidgets.QVBoxLayout(processing_page); processing_form = QtWidgets.QFormLayout(); processing_layout.addLayout(processing_form)
        identity_page = QtWidgets.QWidget(); identity_layout = QtWidgets.QVBoxLayout(identity_page); identity_form = QtWidgets.QFormLayout(); identity_layout.addLayout(identity_form)
        tabs.addTab(basic_page, "Source extraction"); tabs.setTabToolTip(0, "Choose the value path, message restrictions, and byte decoding.")
        tabs.addTab(processing_page, "Processing and thresholds"); tabs.setTabToolTip(1, "Apply scale and offset, configure threshold markers, or run a validated processing module.")
        tabs.addTab(identity_page, "Collection and stream identity"); tabs.setTabToolTip(2, "Choose how this series reduces unused values and how independent source streams are distinguished.")
        self._basic_form = form; self._processing_form = processing_form
        self.label = QtWidgets.QLineEdit(str(self.series.get("label", "")))
        self.session = QtWidgets.QComboBox(); self.session.addItem("All sessions in this view", "")
        for config in sessions: self.session.addItem(str(config.get("name", "Unnamed")), str(config.get("id", "")))
        self.session.setCurrentIndex(max(0, self.session.findData(str(self.series.get("session_id", "")))))
        self.names = QtWidgets.QLineEdit(", ".join(self.series.get("message_names", [])))
        all_names = sorted({name for item in catalog.values() for name in item.get("names", [])})
        self.names.setCompleter(QtWidgets.QCompleter(all_names, self.names)); self.names.setPlaceholderText("Message names or wildcard patterns, comma separated")
        self.direction = QtWidgets.QComboBox()
        for title, value in (("RX and TX", "any"), ("Received only", "RX"), ("Sent only", "TX")): self.direction.addItem(title, value)
        self.direction.setCurrentIndex(max(0, self.direction.findData(self.series.get("direction", "any"))))
        self.kind = QtWidgets.QComboBox()
        for title, value in (("Parsed data field", "parsed_field"), ("Byte range inside a field", "binary_field"), ("Decoded header field", "header_field"), ("Raw message byte range", "raw_bytes"), ("Message metadata", "metadata")): self.kind.addItem(title, value)
        source = self.series.get("source", {})
        self.kind.setCurrentIndex(max(0, self.kind.findData(source.get("kind", "parsed_field"))))
        self.path = QtWidgets.QComboBox(); self.path.setEditable(True)
        field_paths = sorted({path for item in catalog.values() for path in item.get("fields", [])})
        self.path.addItems(field_paths); self.path.setCurrentText(str(source.get("path", "")))
        self.metadata = QtWidgets.QComboBox(); self.metadata.addItems(METADATA_FIELDS); self.metadata.setCurrentText(str(source.get("field", "size")))
        self.raw_box = QtWidgets.QWidget(); raw_form = QtWidgets.QFormLayout(self.raw_box); raw_form.setContentsMargins(0, 0, 0, 0)
        self.offset = QtWidgets.QSpinBox(); self.offset.setRange(-10_000_000, 10_000_000); self.offset.setValue(int(source.get("offset", 0)))
        self.length = QtWidgets.QSpinBox(); self.length.setRange(1, 1_000_000); self.length.setValue(int(source.get("length", 1)))
        self.data_type = QtWidgets.QComboBox(); self.data_type.addItems(["uint", "int", "float32", "float64", "text", "hex", "bytes"]); self.data_type.setCurrentText(str(source.get("data_type", "uint")))
        self.endianness = QtWidgets.QComboBox(); self.endianness.addItems(["little", "big"]); self.endianness.setCurrentText(str(source.get("endianness", "little")))
        self.signed = QtWidgets.QCheckBox("Interpret integer as signed"); self.signed.setChecked(bool(source.get("signed", False)))
        self.encoding = QtWidgets.QComboBox(); self.encoding.setEditable(True); self.encoding.addItems(["utf-8", "ascii", "latin-1", "utf-16-le", "utf-16-be"]); self.encoding.setCurrentText(str(source.get("encoding", "utf-8")))
        for label, widget in (("Offset", self.offset), ("Length", self.length), ("Data type", self.data_type), ("Endianness", self.endianness), ("", self.signed), ("Text encoding", self.encoding)): raw_form.addRow(label, widget)
        self.scale = QtWidgets.QDoubleSpinBox(); self.scale.setRange(-1e12, 1e12); self.scale.setDecimals(9); self.scale.setValue(float(self.series.get("transform", {}).get("scale", 1.0)))
        self.value_offset = QtWidgets.QDoubleSpinBox(); self.value_offset.setRange(-1e12, 1e12); self.value_offset.setDecimals(9); self.value_offset.setValue(float(self.series.get("transform", {}).get("offset", 0.0)))
        thresholds = self.series.get("thresholds", {})
        self.minimum = QtWidgets.QLineEdit(str(thresholds.get("minimum", thresholds.get("min", "")))); self.maximum = QtWidgets.QLineEdit(str(thresholds.get("maximum", thresholds.get("max", ""))))
        self.equal = QtWidgets.QLineEdit(str(thresholds.get("equal", thresholds.get("eq", "")))); self.not_equal = QtWidgets.QLineEdit(str(thresholds.get("not_equal", thresholds.get("noteq", ""))))
        for label, widget in (("Series name", self.label), ("Session", self.session), ("Message names", self.names), ("Direction", self.direction), ("Value source", self.kind), ("Field path", self.path), ("Metadata field", self.metadata), ("Raw extraction", self.raw_box)): form.addRow(label, widget)
        for label, widget in (("Numeric scale", self.scale), ("Numeric offset", self.value_offset), ("Minimum threshold", self.minimum), ("Maximum threshold", self.maximum), ("Equal-to marker", self.equal), ("Not-equal marker", self.not_equal)): processing_form.addRow(label, widget)
        self.processor = InsightProcessorEditor(
            self.series.get("processor"), self,
        )
        processing_layout.addWidget(self.processor, 1)
        collection = collection if isinstance(collection, dict) else {}
        series_collection = normalize_series_collection(self.series.get("collection"))
        identity = normalize_series_stream_identity(self.series.get("stream_identity"))
        self.series_policy = QtWidgets.QComboBox()
        self.series_policy.addItem("Use insight default", "inherit")
        policy_options = [
            ("Every unused value", "all"), ("Only changed values", "changed")
        ]
        if collection.get("mode") == "scheduled":
            policy_options = [
                ("Every unused value", "all"), ("First unused value", "first"),
                ("Last unused value", "last"), ("Every changed value", "changed"),
                ("Last value, only if changed", "last_changed"),
            ]
        for title, value in policy_options: self.series_policy.addItem(title, value)
        self.series_policy.setCurrentIndex(max(0, self.series_policy.findData(series_collection["policy"])))
        self.identity_mode = QtWidgets.QComboBox()
        self.identity_mode.addItem("Automatic source stream", "automatic")
        self.identity_mode.addItem("Automatic plus custom fields", "custom")
        self.identity_mode.addItem("Combine all accepted sources", "combined")
        self.identity_mode.setCurrentIndex(max(0, self.identity_mode.findData(identity["mode"])))
        self.identity_fields = QtWidgets.QTableWidget(0, 1)
        self.identity_fields.setHorizontalHeaderLabels(["Additional row or data-field path"])
        self.identity_fields.horizontalHeader().setStretchLastSection(True)
        self.identity_fields.setMinimumHeight(150)
        for field in identity.get("additional_fields", []):
            row = self.identity_fields.rowCount(); self.identity_fields.insertRow(row)
            self.identity_fields.setItem(row, 0, QtWidgets.QTableWidgetItem(str(field)))
        field_actions = QtWidgets.QHBoxLayout()
        add_field = QtWidgets.QPushButton("Insert field"); remove_field = QtWidgets.QPushButton("Remove selected")
        field_actions.addWidget(add_field); field_actions.addWidget(remove_field); field_actions.addStretch(1)
        fields_box = QtWidgets.QWidget(); fields_layout = QtWidgets.QVBoxLayout(fields_box); fields_layout.setContentsMargins(0, 0, 0, 0); fields_layout.addWidget(self.identity_fields); fields_layout.addLayout(field_actions)
        add_field.clicked.connect(lambda: self.identity_fields.insertRow(self.identity_fields.rowCount()))
        remove_field.clicked.connect(lambda: [self.identity_fields.removeRow(row.row()) for row in reversed(self.identity_fields.selectionModel().selectedRows())])
        self.missing_identity = QtWidgets.QComboBox()
        self.missing_identity.addItem("Reject sample when a field is missing", "reject")
        self.missing_identity.addItem("Use an explicit missing marker", "missing")
        self.missing_identity.addItem("Use a fallback value", "fallback")
        self.missing_identity.setCurrentIndex(max(0, self.missing_identity.findData(identity["missing_field_policy"])))
        self.identity_fallback = QtWidgets.QLineEdit(str(identity.get("fallback_value", "")))
        self.identity_note = QtWidgets.QLabel(
            "Automatic identity uses session, connection, direction, and message name. Add fields such as data.device_id when one message source carries multiple logical devices."
        ); self.identity_note.setWordWrap(True); self.identity_note.setStyleSheet("color: palette(mid);")
        identity_form.addRow("Series collection policy", self.series_policy)
        identity_form.addRow("Stream identity", self.identity_mode)
        identity_form.addRow("Additional identity fields", fields_box)
        identity_form.addRow("Missing custom field", self.missing_identity)
        identity_form.addRow("Fallback value", self.identity_fallback)
        identity_layout.addWidget(self.identity_note); identity_layout.addStretch(1)
        self.series_policy.setToolTip("Override the insight's default reduction only for this series. Inherit keeps collection behavior centralized.")
        self.identity_mode.setToolTip("Automatic identity separates session, connection, direction, and message name. Add custom fields for logical devices carried by the same source.")
        self.identity_fields.setToolTip("Editable paths such as data.device_id. Each value becomes part of this series' stream key.")
        self.missing_identity.setToolTip("Choose what happens when an additional identity path cannot be read from an otherwise eligible message.")
        self.identity_fallback.setToolTip("Stable value used in the stream key when a custom identity field is missing.")
        self.identity_mode.currentIndexChanged.connect(self._update_identity_visibility)
        self.missing_identity.currentIndexChanged.connect(self._update_identity_visibility)
        tooltips = {
            self.label: "Stable series name used by the Insight dataset, Excel output, and display configuration.",
            self.session: "Optionally restrict this series to one session. The view scope still controls which tables are queried.",
            self.names: "Restrict values to comma-separated message names or wildcard patterns such as Status*; leave empty for every name.",
            self.direction: "Plot received messages, sent messages, or both transport directions.",
            self.kind: "Choose parsed data, a byte range nested inside parsed data, decoded header fields, raw message bytes, or a message-table column.",
            self.path: "Nested path such as data.temperature, data.channels.0, or header_fields.message_id.",
            self.metadata: "Message-table column used as the plotted value.",
            self.raw_box: "Extract a value directly from unparsed message bytes using the byte controls below.",
            self.offset: "Zero-based byte offset. Negative offsets count backward from the end of the message.",
            self.length: "Number of consecutive bytes used for this value.",
            self.data_type: "Interpret the selected bytes as an integer, float, text, hexadecimal text, or raw bytes.",
            self.endianness: "Byte order used for multi-byte numeric values.",
            self.signed: "Allow integer byte ranges to represent negative values.",
            self.encoding: "Character encoding used only when the raw data type is text.",
            self.scale: "Multiply numeric extracted values by this amount before plotting.",
            self.value_offset: "Add this amount after numeric scaling.",
            self.minimum: "Flag and optionally display values below this JSON-compatible number or value; leave blank to disable.",
            self.maximum: "Flag and optionally display values above this JSON-compatible number or value; leave blank to disable.",
            self.equal: "Mark values equal to this JSON-compatible value; strings may be entered without JSON quotes.",
            self.not_equal: "Mark values different from this JSON-compatible value; strings may be entered without JSON quotes.",
        }
        for widget, text in tooltips.items():
            widget.setToolTip(text)
            owner_form = processing_form if widget in {self.scale, self.value_offset, self.minimum, self.maximum, self.equal, self.not_equal} else form
            label = owner_form.labelForField(widget)
            if label is not None:
                label.setToolTip(text)
        for widget in (self.offset, self.length, self.data_type, self.endianness, self.signed, self.encoding):
            label = raw_form.labelForField(widget)
            if label is not None:
                label.setToolTip(widget.toolTip())
        note = QtWidgets.QLabel("Wildcards such as Status* are supported. Parsed paths may use data.temperature or nested array indexes such as data.channels.0."); note.setWordWrap(True); note.setStyleSheet("color: palette(mid);"); basic_layout.insertWidget(basic_layout.count() - 1, note)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
        self.kind.currentIndexChanged.connect(self._update_source_visibility); self._update_source_visibility(); self._update_identity_visibility()

    def _update_source_visibility(self):
        kind = self.kind.currentData()
        visibility = {
            self.path: kind in {"parsed_field", "binary_field", "header_field"},
            self.metadata: kind == "metadata", self.raw_box: kind in {"raw_bytes", "binary_field"},
        }
        form = self._basic_form
        for widget, visible in visibility.items():
            widget.setVisible(visible)
            label = form.labelForField(widget)
            if label: label.setVisible(visible)

    def _update_identity_visibility(self):
        custom = self.identity_mode.currentData() == "custom"
        self.identity_fields.setEnabled(custom)
        self.missing_identity.setEnabled(custom)
        self.identity_fallback.setVisible(custom and self.missing_identity.currentData() == "fallback")

    def accept(self):
        if not self.label.text().strip(): QtWidgets.QMessageBox.warning(self, "Series label required", "Enter a label for the plotted series."); return
        kind = self.kind.currentData()
        if kind in {"parsed_field", "binary_field", "header_field"} and not self.path.currentText().strip(): QtWidgets.QMessageBox.warning(self, "Field required", "Select or enter a field path."); return
        try:
            self.processor.validate_config()
        except BaseException as error:
            QtWidgets.QMessageBox.warning(
                self, "Value processor is invalid",
                f"{type(error).__name__}: {error}",
            )
            return
        super().accept()

    def result_config(self):
        kind = self.kind.currentData()
        if kind in {"parsed_field", "header_field"}: source = {"kind": kind, "path": self.path.currentText().strip()}
        elif kind == "binary_field":
            source = {"kind": kind, "path": self.path.currentText().strip(), "offset": self.offset.value(), "length": self.length.value(), "data_type": self.data_type.currentText(), "endianness": self.endianness.currentText(), "signed": self.signed.isChecked(), "encoding": self.encoding.currentText().strip() or "utf-8"}
        elif kind == "metadata": source = {"kind": kind, "field": self.metadata.currentText()}
        else:
            source = {"kind": kind, "offset": self.offset.value(), "length": self.length.value(), "data_type": self.data_type.currentText(), "endianness": self.endianness.currentText(), "signed": self.signed.isChecked(), "encoding": self.encoding.currentText().strip() or "utf-8"}
        previous_source = self.series.get("source", {})
        if source.get("path") == previous_source.get("path") and isinstance(previous_source.get("path_tokens"), list):
            source["path_tokens"] = copy.deepcopy(previous_source["path_tokens"])
        thresholds = {}
        for key, editor in (("minimum", self.minimum), ("maximum", self.maximum), ("equal", self.equal), ("not_equal", self.not_equal)):
            text = editor.text().strip()
            if not text: continue
            try: thresholds[key] = json.loads(text)
            except json.JSONDecodeError: thresholds[key] = text
        return self.target_subplot, {
            "id": str(self.series.get("id") or uuid.uuid4()), "label": self.label.text().strip(),
            "enabled": bool(self.series.get("enabled", True)),
            "visible": bool(self.series.get("visible", True)),
            "plot_enabled": bool(self.series.get("plot_enabled", True)),
            "export_enabled": bool(self.series.get("export_enabled", True)),
            "session_id": str(self.session.currentData() or ""),
            "message_names": [item.strip() for item in self.names.text().split(",") if item.strip()],
            "direction": self.direction.currentData(), "source": source,
            "plot": copy.deepcopy(self.series.get("plot", {"type": "line", "color": INSIGHT_COLORS[0]})),
            "transform": {"scale": self.scale.value(), "offset": self.value_offset.value()},
            "processor": self.processor.result_config(),
            "thresholds": thresholds,
            "collection": {"policy": self.series_policy.currentData() or "inherit"},
            "stream_identity": {
                "mode": self.identity_mode.currentData(),
                "additional_fields": [
                    self.identity_fields.item(row, 0).text().strip()
                    for row in range(self.identity_fields.rowCount())
                    if self.identity_fields.item(row, 0) is not None
                    and self.identity_fields.item(row, 0).text().strip()
                ],
                "missing_field_policy": self.missing_identity.currentData(),
                "fallback_value": self.identity_fallback.text(),
            },
        }


class InsightSeriesDiscoveryDialog(QtWidgets.QDialog):
    """Focused settings for scanning retained messages for candidate series."""

    def __init__(self, configuration, scope_summary, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Find Available Series")
        self.setMinimumWidth(720)
        config = copy.deepcopy(configuration) if isinstance(configuration, dict) else {}
        history = config.get("history", {}) if isinstance(config.get("history"), dict) else {}
        layout = QtWidgets.QVBoxLayout(self)
        introduction = QtWidgets.QLabel(
            "Inspect retained messages only to find field paths, observed types, and availability for Add from available. "
            "This scan does not preview rows, start the insight, add dataset samples, or affect live collection."
        )
        introduction.setWordWrap(True); introduction.setStyleSheet("color: palette(mid);")
        layout.addWidget(introduction)
        source_group = QtWidgets.QGroupBox("Discovery source")
        form = QtWidgets.QFormLayout(source_group); layout.addWidget(source_group)
        scope = QtWidgets.QLabel(str(scope_summary)); scope.setWordWrap(True)
        form.addRow("Sessions", scope)
        self.history_mode = QtWidgets.QComboBox()
        self.history_mode.addItem("Recent retained messages", "last")
        self.history_mode.addItem("All retained messages", "all")
        self.history_mode.setCurrentIndex(max(0, self.history_mode.findData(history.get("mode", "last"))))
        form.addRow("Messages to inspect", self.history_mode)
        self.period_widget = QtWidgets.QWidget(); period = QtWidgets.QHBoxLayout(self.period_widget); period.setContentsMargins(0, 0, 0, 0)
        self.amount = QtWidgets.QDoubleSpinBox(); self.amount.setRange(.001, 1_000_000); self.amount.setDecimals(3); self.amount.setValue(float(history.get("amount", 60.0)))
        self.unit = QtWidgets.QComboBox(); self.unit.addItems(["milliseconds", "seconds", "minutes", "hours"]); self.unit.setCurrentText(str(history.get("unit", "seconds")))
        period.addWidget(self.amount); period.addWidget(self.unit); period.addStretch(1)
        form.addRow("Look back", self.period_widget)
        self.maximum_rows = QtWidgets.QSpinBox(); self.maximum_rows.setRange(1, 250_000); self.maximum_rows.setSingleStep(1_000); self.maximum_rows.setValue(int(config.get("maximum_rows", 10_000)))
        form.addRow("Maximum messages inspected", self.maximum_rows)
        guidance = QtWidgets.QLabel(
            "Use a recent, representative period for faster discovery. Choose all retained messages only when fields occur rarely or message schemas changed over time."
        )
        guidance.setWordWrap(True); guidance.setStyleSheet("color: palette(mid);")
        layout.addWidget(guidance)
        self.history_mode.currentIndexChanged.connect(
            lambda _index: self.period_widget.setVisible(self.history_mode.currentData() == "last")
        )
        self.period_widget.setVisible(self.history_mode.currentData() == "last")
        for widget, tooltip in (
            (self.history_mode, "Choose how much retained message history is scanned for possible series fields."),
            (self.amount, "Length of recent retained history inspected during discovery."),
            (self.unit, "Time unit for the discovery look-back period."),
            (self.maximum_rows, "Hard limit on retained messages inspected so discovery remains responsive."),
        ):
            widget.setToolTip(tooltip)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Cancel)
        discover = buttons.addButton("Find Available Series", QtWidgets.QDialogButtonBox.AcceptRole)
        discover.setToolTip("Scan retained eligible messages using these limits, then show the available-series picker.")
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def configuration(self):
        return {
            "history": {
                "mode": self.history_mode.currentData(),
                "amount": self.amount.value(), "unit": self.unit.currentText(),
            },
            "maximum_rows": self.maximum_rows.value(),
        }


class InsightSourcePreviewDialog(QtWidgets.QDialog):
    """Message-table style preview for filtered and eligible rows."""

    def __init__(self, result, parent=None):
        super().__init__(parent); self.setWindowTitle("Protocol Insight source preview"); self.resize(1180, 720)
        self.result = result if isinstance(result, dict) else {}; self.page = 0; self._page_rows = []
        layout = QtWidgets.QVBoxLayout(self)
        counts = (
            f"{len(self.result.get('records', [])):,} filtered source row(s) · "
            f"{len(self.result.get('selected', [])):,} resulting insight row(s) · "
            "eligible series input"
        )
        summary = QtWidgets.QLabel(counts); summary.setWordWrap(True); summary.setStyleSheet("font-weight: 600; color: #174EA6; padding: 4px;")
        summary.setToolTip("Filtered source rows pass the Message filter. Eligible rows can feed the configured series extractors.")
        layout.addWidget(summary)
        note = QtWidgets.QLabel("This preview is read-only and uses the same primary columns as Message Table / Query. Double-click a row to inspect its complete nested record.")
        note.setWordWrap(True); note.setStyleSheet("color: palette(mid);"); layout.addWidget(note)
        controls = QtWidgets.QHBoxLayout(); layout.addLayout(controls)
        controls.addWidget(QtWidgets.QLabel("Show"))
        self.dataset = QtWidgets.QComboBox(); self.dataset.addItem("Eligible insight rows", "selected"); self.dataset.addItem("Filtered source rows", "records")
        self.dataset.setToolTip("Switch between rows that can feed series and all rows accepted by the source query.")
        controls.addWidget(self.dataset)
        self.previous_button = QtWidgets.QPushButton("Previous"); self.next_button = QtWidgets.QPushButton("Next")
        controls.addWidget(self.previous_button); controls.addWidget(self.next_button)
        self.page_size = QtWidgets.QComboBox()
        for size in (100, 200, 500, 1000): self.page_size.addItem(f"{size} rows/page", size)
        self.page_size.setCurrentIndex(max(0, self.page_size.findData(200))); controls.addWidget(self.page_size)
        self.page_label = QtWidgets.QLabel(); controls.addWidget(self.page_label); controls.addStretch(1)
        self.table = QtWidgets.QTableWidget(); self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers); self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows); self.table.setAlternatingRowColors(True)
        self.table.setToolTip("Double-click a row to inspect every message field, raw value, decoded header, and nested parser value available in the retained record.")
        self.table.verticalHeader().setVisible(False); self.table.cellDoubleClicked.connect(self._open_detail)
        layout.addWidget(self.table, 1)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
        self.dataset.currentIndexChanged.connect(self._reset_page); self.page_size.currentIndexChanged.connect(self._reset_page)
        self.previous_button.clicked.connect(lambda: self._change_page(-1)); self.next_button.clicked.connect(lambda: self._change_page(1))
        self._render()

    def _rows(self):
        rows = self.result.get(str(self.dataset.currentData() or "selected"), [])
        return rows if isinstance(rows, list) else []

    def _reset_page(self, *_args):
        self.page = 0; self._render()

    def _change_page(self, amount):
        self.page = max(0, self.page + int(amount)); self._render()

    @staticmethod
    def _cell_text(value):
        if isinstance(value, (dict, list, tuple, bytes, bytearray, memoryview)) or type(value).__module__.startswith("numpy"):
            return json.dumps(serialize_value(value), ensure_ascii=False, default=str)
        return str(value if value is not None else "")

    def _render(self):
        rows = self._rows(); size = int(self.page_size.currentData() or 200); maximum_page = max(0, (len(rows) - 1) // size)
        self.page = min(self.page, maximum_page); start = self.page * size; self._page_rows = rows[start:start + size]
        show_session = len({str(row.get("session_id", "")) for row in rows if isinstance(row, dict)}) > 1
        columns = ["id", "timestamp"] + (["session_id"] if show_session else []) + ["direction", "protocol", "name", "data", "size", "peer", "parse_status"]
        headers = ["Timestamp (local)" if column == "timestamp" else column for column in columns]
        self.table.setColumnCount(len(columns)); self.table.setHorizontalHeaderLabels(headers); self.table.setRowCount(len(self._page_rows))
        for row_index, record in enumerate(self._page_rows):
            for column_index, column in enumerate(columns):
                value = record.get(column, "")
                if column == "timestamp":
                    try:
                        value = local_datetime_from_ns(int(record.get("timestamp_ns") or timestamp_ns(value))).isoformat(timespec="milliseconds")
                    except (TypeError, ValueError, OverflowError, OSError):
                        pass
                self.table.setItem(row_index, column_index, QtWidgets.QTableWidgetItem(self._cell_text(value)))
        self.table.resizeColumnsToContents()
        for column in range(self.table.columnCount()): self.table.setColumnWidth(column, min(340, self.table.columnWidth(column)))
        self.page_label.setText(f"{len(rows):,} rows · page {self.page + 1} of {maximum_page + 1}")
        self.previous_button.setEnabled(self.page > 0); self.next_button.setEnabled(self.page < maximum_page)

    def _open_detail(self, row, _column=0):
        if row < 0 or row >= len(self._page_rows): return
        dialog = QtWidgets.QDialog(self); dialog.setWindowTitle("Protocol message details"); dialog.resize(780, 620)
        layout = QtWidgets.QVBoxLayout(dialog)
        explanation = QtWidgets.QLabel("Complete read-only retained message record, including nested decoded fields and byte values."); explanation.setWordWrap(True); explanation.setStyleSheet("color: palette(mid);"); layout.addWidget(explanation)
        content = QtWidgets.QPlainTextEdit(); content.setReadOnly(True); content.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont)); content.setPlainText(json.dumps(serialize_value(self._page_rows[row]), indent=2, ensure_ascii=False, default=str)); layout.addWidget(content, 1)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close); buttons.rejected.connect(dialog.reject); layout.addWidget(buttons); dialog.exec_()


class _VerticalWorkspacePage(QtWidgets.QWidget):
    """Scrollable page that never requests horizontal overflow."""

    def minimumSizeHint(self):
        hint = super().minimumSizeHint()
        return QtCore.QSize(0, hint.height())

    def sizeHint(self):
        hint = super().sizeHint()
        return QtCore.QSize(0, hint.height())


class ProtocolInsightsPanel(QtWidgets.QWidget):
    def __init__(self, hub, parent=None):
        super().__init__(parent); self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True); self.hub = hub; self._refreshing = False; self._plots = []
        self._refresh_pending = False
        self._refresh_revision = 0
        self._dataset_cursors = {}
        self._dataset_sample_buffers = {}
        self._dataset_event_buffers = {}
        self._dataset_snapshot_required = set()
        self._dataset_state_lock = threading.RLock()
        self._last_autorange_monotonic = 0.0
        self._display_x_bounds = None
        self._global_x_autorange = True
        self._applying_global_x_range = False
        self._last_result = None
        self._plot_signature = None
        self._plot_widgets = {}
        self._series_items = {}
        self._threshold_items = []
        self._timeline_items = {}
        self._event_items = {}
        self._event_points = {}
        self._category_maps = {}
        self._hover_proxies = []
        self._hover_series = {}
        self._hover_labels = {}
        self._hover_markers = {}
        self._hover_lines = {}
        self._active_hover_x = None
        self._pinned_hovers = []
        self._hover_event_sources = set()
        self._x_axis_config = default_insight_x_axis()
        self._normalize_settings(); self._build_ui()
        self._apply_startup_section_state()
        self.timer = QtCore.QTimer(self); self.timer.timeout.connect(self._tick)
        self._reload_views()
        if self._runtime_active(self._view()):
            self.timer.start(self._view().get("refresh_ms", 1000))

    def _normalize_settings(self):
        raw = self.hub.config.get("protocol_insights", [])
        views = [normalize_protocol_insight_config(item) for item in raw if isinstance(item, dict)]
        if not views: views = [default_protocol_insight_config()]
        self.hub.config["protocol_insights"] = views
        current = str(self.hub.config.get("active_protocol_insight_id", ""))
        if not any(view["id"] == current for view in views): current = views[0]["id"]
        self.hub.config["active_protocol_insight_id"] = current

    def _add_section(self, layout, title, panel, *, visible=True, stretch=0, tooltip=""):
        button = QtWidgets.QToolButton(self)
        button.setCheckable(True); button.setChecked(bool(visible))
        button.setArrowType(QtCore.Qt.DownArrow if visible else QtCore.Qt.RightArrow)
        button.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        button.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        button.setStyleSheet("QToolButton { text-align: left; font-weight: 600; padding: 4px 6px; }")
        if tooltip: button.setToolTip(tooltip)
        button.toggled.connect(
            lambda shown, control=button, content=panel, name=title:
            self._set_section_visible(control, content, name, shown)
        )
        layout.addWidget(button)
        layout.addWidget(panel, stretch)
        self._set_section_visible(button, panel, title, visible)
        return button

    @staticmethod
    def _set_section_visible(button, panel, title, visible):
        panel.setVisible(bool(visible))
        button.setArrowType(QtCore.Qt.DownArrow if visible else QtCore.Qt.RightArrow)
        button.setText(("Hide " if visible else "Show ") + title.lower())

    def _display_section_toggled(self, visible):
        if not hasattr(self, "workspace_bottom_spacer"):
            return
        self.workspace_bottom_spacer.changeSize(
            0, 0, QtWidgets.QSizePolicy.Minimum,
            QtWidgets.QSizePolicy.Fixed if visible else QtWidgets.QSizePolicy.Expanding,
        )
        self.workspace_page.layout().invalidate()

    def _apply_startup_section_state(self):
        """Start compact; reserve the canvas only when an insight will run."""
        restore_ids = set(getattr(self.hub, "_protocol_insight_restore_ids", set()))
        any_running = any(
            self._runtime_active(view)
            or bool(view.get("autostart", False))
            or str(view.get("id", "")) in restore_ids
            for view in self.hub.config.get("protocol_insights", [])
            if isinstance(view, dict)
        )
        for toggle in (
            self.source_toggle, self.series_toggle, self.dataset_toggle,
            self.display_settings_toggle,
        ):
            toggle.setChecked(False)
        self.display_toggle.setChecked(any_running)

    def _build_ui(self):
        outer = QtWidgets.QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        self.workspace_scroll = QtWidgets.QScrollArea(self)
        self.workspace_scroll.setWidgetResizable(True)
        self.workspace_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.workspace_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.workspace_page = _VerticalWorkspacePage()
        self.workspace_page.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.MinimumExpanding)
        root = QtWidgets.QVBoxLayout(self.workspace_page); root.setSpacing(6)
        root.setSizeConstraint(QtWidgets.QLayout.SetNoConstraint)
        self.workspace_scroll.setWidget(self.workspace_page); outer.addWidget(self.workspace_scroll)
        top = QtWidgets.QHBoxLayout(); self.insight_selection_row = top; root.addLayout(top)
        self.view_combo = QtWidgets.QComboBox(); self.view_combo.currentIndexChanged.connect(self._view_changed)
        self.new_button = QtWidgets.QPushButton("New"); self.save_button = QtWidgets.QPushButton("Rename"); self.delete_button = QtWidgets.QPushButton("Delete")
        self.export_button = QtWidgets.QPushButton("Create Final Excel...")
        self.transfer_outputs_button = QtWidgets.QPushButton("Export Outputs")
        self.export_button.setEnabled(False)
        self.new_button.clicked.connect(self._new_view); self.save_button.clicked.connect(self._save_view); self.delete_button.clicked.connect(self._delete_view)
        self.export_button.clicked.connect(self._export_current_view)
        self.transfer_outputs_button.clicked.connect(self._transfer_available_outputs)
        top.addWidget(QtWidgets.QLabel("Protocol Insight")); top.addWidget(self.view_combo, 1)
        top.addWidget(self.new_button); top.addWidget(self.save_button)
        top.addWidget(self.delete_button); top.addWidget(self.export_button)
        top.addWidget(self.transfer_outputs_button)
        self.insight_summary_frame = QtWidgets.QFrame()
        self.insight_summary_frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        insight_summary_layout = QtWidgets.QHBoxLayout(self.insight_summary_frame)
        insight_summary_layout.setContentsMargins(8, 5, 8, 5)
        insight_summary_heading = QtWidgets.QLabel("Insight summary")
        insight_summary_heading.setStyleSheet("font-weight: 600;")
        self.insight_summary = QtWidgets.QLabel("No insight configuration loaded.")
        self.insight_summary.setWordWrap(True)
        self.insight_summary.setStyleSheet("color: #174EA6;")
        self.insight_summary.setToolTip(
            "A concise description of the selected insight's sources, collection policy, series outputs, and Excel status."
        )
        insight_summary_layout.addWidget(insight_summary_heading)
        insight_summary_layout.addWidget(self.insight_summary, 1)
        root.addWidget(self.insight_summary_frame)
        self.source_group = QtWidgets.QGroupBox()
        source_layout = QtWidgets.QVBoxLayout(self.source_group)
        self.source_toggle = self._add_section(
            root, "Source and collection", self.source_group, visible=True,
            tooltip="Choose which message tables are searched, select a saved Message Table filter, and define how matching rows become insight data.",
        )
        source_intro = QtWidgets.QLabel(
            "Choose the sessions and a message filter saved in Message Table / Query, then define when values are collected. The default reduction policy can be overridden independently by each series. Historical preview limits do not constrain live collection."
        )
        source_intro.setWordWrap(True); source_intro.setStyleSheet("color: palette(mid); padding: 0 2px 4px 2px;")
        source_layout.addWidget(source_intro)

        source_label_width = 168
        source_control_width = 360
        def source_field_label(text):
            label = QtWidgets.QLabel(text)
            label.setFixedWidth(source_label_width)
            label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
            return label
        def source_explanation(text=""):
            label = QtWidgets.QLabel(text)
            label.setWordWrap(True)
            label.setMinimumWidth(0)
            label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
            label.setStyleSheet("color: palette(mid);")
            return label

        self.insight_lifecycle_group = QtWidgets.QGroupBox("Lifecycle")
        lifecycle_layout = QtWidgets.QGridLayout(self.insight_lifecycle_group)
        lifecycle_layout.setColumnStretch(1, 1)
        self.insight_autostart = QtWidgets.QCheckBox(
            "Start this insight when Communication Hub opens"
        )
        self.insight_application_lifetime = QtWidgets.QCheckBox(
            "Keep this insight running when the Communication Hub window closes"
        )
        self.insight_restore_last_state = QtWidgets.QCheckBox(
            "Restore the running state from the previous Hub close"
        )
        lifecycle_layout.addWidget(self.insight_autostart, 0, 0)
        lifecycle_layout.addWidget(source_explanation(
            "Starts the insight backend after saved session tables and session autostart have been initialized."
        ), 0, 1)
        lifecycle_layout.addWidget(self.insight_application_lifetime, 1, 0)
        lifecycle_layout.addWidget(source_explanation(
            "Keeps collection, retention, and checkpoints active while the hub window is hidden. Excel is written only on request or orderly stop. Source sessions must also use application lifetime to keep supplying live messages."
        ), 1, 1)
        lifecycle_layout.addWidget(self.insight_restore_last_state, 2, 0)
        lifecycle_layout.addWidget(source_explanation(
            "If this insight was running when Communication Hub last closed, starts it on the next open even when automatic start is disabled. A deliberately stopped insight remains stopped."
        ), 2, 1)
        source_layout.addWidget(self.insight_lifecycle_group)
        self.insight_autostart.toggled.connect(self._lifecycle_controls_changed)
        self.insight_application_lifetime.toggled.connect(
            self._lifecycle_controls_changed
        )
        self.insight_restore_last_state.toggled.connect(
            self._lifecycle_controls_changed
        )

        self.source_sessions_group = QtWidgets.QGroupBox("Data sources")
        sessions_layout = QtWidgets.QVBoxLayout(self.source_sessions_group)
        source_layout.addWidget(self.source_sessions_group)
        sessions_grid = QtWidgets.QGridLayout(); sessions_grid.setContentsMargins(0, 0, 0, 0); sessions_grid.setHorizontalSpacing(10); sessions_grid.setVerticalSpacing(8); sessions_grid.setColumnStretch(2, 1); sessions_layout.addLayout(sessions_grid)
        self.source_scope = QtWidgets.QComboBox(); self.source_scope.addItem("Current session", "current"); self.source_scope.addItem("Choose sessions...", "selected"); self.source_scope.addItem("All available sessions", "all")
        self.source_scope.setFixedWidth(source_control_width)
        self.source_scope_explanation = source_explanation()
        sessions_grid.addWidget(source_field_label("Read from"), 0, 0); sessions_grid.addWidget(self.source_scope, 0, 1); sessions_grid.addWidget(self.source_scope_explanation, 0, 2)
        self.collection_interval = QtWidgets.QDoubleSpinBox(); self.collection_interval.setRange(.05, 86_400); self.collection_interval.setDecimals(3); self.collection_interval.setSuffix(" s")
        self.source_session_table = QtWidgets.QTableWidget(0, 4); self.source_session_table.setHorizontalHeaderLabels(["Use", "Session", "Protocol", "Availability"])
        self.source_session_table.verticalHeader().setVisible(False); self.source_session_table.setAlternatingRowColors(True); self.source_session_table.setMaximumHeight(120)
        self.source_session_table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents); self.source_session_table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch); self.source_session_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents); self.source_session_table.horizontalHeader().setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        sessions_layout.addWidget(self.source_session_table)

        self.source_messages_group = QtWidgets.QGroupBox("Eligible messages")
        messages_layout = QtWidgets.QVBoxLayout(self.source_messages_group)
        source_layout.addWidget(self.source_messages_group)
        self.source_history_controls = QtWidgets.QWidget()
        history_row = QtWidgets.QGridLayout(self.source_history_controls); history_row.setContentsMargins(0, 0, 0, 0); history_row.setHorizontalSpacing(10); history_row.setVerticalSpacing(8); history_row.setColumnStretch(2, 1)
        self.source_history_mode = QtWidgets.QComboBox(); self.source_history_mode.addItem("Recent retained messages", "last"); self.source_history_mode.addItem("All retained messages", "all")
        self.source_history_amount = QtWidgets.QDoubleSpinBox(); self.source_history_amount.setRange(.001, 1_000_000); self.source_history_amount.setDecimals(3)
        self.source_history_unit = QtWidgets.QComboBox(); self.source_history_unit.addItems(["milliseconds", "seconds", "minutes", "hours"])
        self.maximum_cycle_rows = QtWidgets.QSpinBox(); self.maximum_cycle_rows.setRange(1, 250_000); self.maximum_cycle_rows.setSingleStep(1000)
        preview_range_control = QtWidgets.QWidget(); preview_range_layout = QtWidgets.QHBoxLayout(preview_range_control); preview_range_layout.setContentsMargins(0, 0, 0, 0); preview_range_layout.setSpacing(6); preview_range_control.setFixedWidth(source_control_width)
        preview_range_layout.addWidget(self.source_history_mode)
        self.source_history_period_widget = QtWidgets.QWidget(); history_period = QtWidgets.QHBoxLayout(self.source_history_period_widget); history_period.setContentsMargins(0, 0, 0, 0); history_period.addWidget(self.source_history_amount); history_period.addWidget(self.source_history_unit)
        preview_range_layout.addWidget(self.source_history_period_widget)
        history_row.addWidget(source_field_label("Messages to preview"), 0, 0); history_row.addWidget(preview_range_control, 0, 1); history_row.addWidget(source_explanation("Limits only the read-only past-message preview."), 0, 2)
        self.maximum_cycle_rows.setFixedWidth(source_control_width)
        history_row.addWidget(source_field_label("Maximum preview rows"), 1, 0); history_row.addWidget(self.maximum_cycle_rows, 1, 1); history_row.addWidget(source_explanation("Keeps large retained tables responsive while previewing."), 1, 2)
        filter_row = QtWidgets.QGridLayout(); filter_row.setContentsMargins(0, 0, 0, 0); filter_row.setHorizontalSpacing(10); filter_row.setColumnStretch(2, 1); messages_layout.addLayout(filter_row)
        self.message_filter_combo = QtWidgets.QComboBox()
        self.message_filter_combo.setFixedWidth(source_control_width)
        filter_row.addWidget(source_field_label("Message filter"), 0, 0)
        filter_row.addWidget(self.message_filter_combo, 0, 1)
        filter_row.addWidget(source_explanation("Choose All messages or a filter created and saved in Message Table / Query. Only matching messages are offered to the configured series extractors."), 0, 2)

        self.source_collection_group = QtWidgets.QGroupBox("Collection mode")
        collection_layout = QtWidgets.QVBoxLayout(self.source_collection_group)
        source_layout.addWidget(self.source_collection_group)
        collection_grid = QtWidgets.QGridLayout(); collection_grid.setContentsMargins(0, 0, 0, 0); collection_grid.setHorizontalSpacing(10); collection_grid.setVerticalSpacing(8); collection_grid.setColumnStretch(2, 1); collection_layout.addLayout(collection_grid)
        self.collection_mode = QtWidgets.QComboBox(); self.collection_mode.addItem("When an eligible message arrives", "on_arrival"); self.collection_mode.addItem("At scheduled intervals", "scheduled")
        self.collection_mode.setFixedWidth(source_control_width)
        self.collection_mode_explanation = source_explanation()
        collection_grid.addWidget(source_field_label("Collect data"), 0, 0); collection_grid.addWidget(self.collection_mode, 0, 1); collection_grid.addWidget(self.collection_mode_explanation, 0, 2)
        self.collection_interval_widget = QtWidgets.QWidget(); interval_layout = QtWidgets.QGridLayout(self.collection_interval_widget); interval_layout.setContentsMargins(0, 0, 0, 0); interval_layout.setHorizontalSpacing(10); interval_layout.setColumnStretch(2, 1)
        interval_help = source_explanation("Eligible values accumulate without rescanning complete message tables; the reducer drains them at this interval.")
        self.collection_interval.setFixedWidth(source_control_width)
        interval_layout.addWidget(source_field_label("Collection interval"), 0, 0); interval_layout.addWidget(self.collection_interval, 0, 1); interval_layout.addWidget(interval_help, 0, 2)
        collection_layout.addWidget(self.collection_interval_widget)
        policy_row = QtWidgets.QGridLayout(); policy_row.setContentsMargins(0, 0, 0, 0); policy_row.setHorizontalSpacing(10); policy_row.setColumnStretch(2, 1); collection_layout.addLayout(policy_row)
        self.collection_policy = QtWidgets.QComboBox()
        self.collection_policy.setFixedWidth(source_control_width)
        self.collection_policy_explanation = source_explanation()
        policy_row.addWidget(source_field_label("Default series policy"), 0, 0); policy_row.addWidget(self.collection_policy, 0, 1); policy_row.addWidget(self.collection_policy_explanation, 0, 2)
        capacity_row = QtWidgets.QGridLayout(); capacity_row.setContentsMargins(0, 0, 0, 0); capacity_row.setHorizontalSpacing(10); capacity_row.setColumnStretch(2, 1); collection_layout.addLayout(capacity_row)
        self.collection_start_position = QtWidgets.QComboBox(); self.collection_start_position.addItem("New messages after Start", "new_messages"); self.collection_start_position.addItem("Retained eligible messages, then new messages", "retained_then_new")
        self.collection_start_position.setFixedWidth(source_control_width)
        capacity_row.addWidget(source_field_label("Start with"), 0, 0); capacity_row.addWidget(self.collection_start_position, 0, 1); capacity_row.addWidget(source_explanation("Choose whether Start begins at the live edge or first recovers currently retained eligible messages."), 0, 2)
        self.pending_capacity_widget = QtWidgets.QWidget(); pending_capacity = QtWidgets.QGridLayout(self.pending_capacity_widget); pending_capacity.setContentsMargins(0, 0, 0, 0); pending_capacity.setHorizontalSpacing(10); pending_capacity.setVerticalSpacing(8); pending_capacity.setColumnStretch(2, 1)
        self.maximum_candidates = QtWidgets.QSpinBox(); self.maximum_candidates.setRange(1, 1_000_000); self.maximum_candidates.setSingleStep(1_000)
        self.collection_overflow = QtWidgets.QComboBox(); self.collection_overflow.addItem("Discard oldest pending", "drop_oldest"); self.collection_overflow.addItem("Discard newest pending", "drop_newest"); self.collection_overflow.addItem("Pause collection", "pause")
        self.maximum_candidates.setFixedWidth(source_control_width); self.collection_overflow.setFixedWidth(source_control_width)
        pending_capacity.addWidget(source_field_label("Pending-value limit"), 0, 0); pending_capacity.addWidget(self.maximum_candidates, 0, 1); pending_capacity.addWidget(source_explanation("Bounds memory used between scheduled reductions."), 0, 2)
        pending_capacity.addWidget(source_field_label("When the limit is reached"), 1, 0); pending_capacity.addWidget(self.collection_overflow, 1, 1); pending_capacity.addWidget(source_explanation("Choose whether older or newer pending values are discarded, or collection pauses."), 1, 2)
        collection_layout.addWidget(self.pending_capacity_widget)

        self.source_preview_group = QtWidgets.QGroupBox("Preview results")
        preview_layout = QtWidgets.QVBoxLayout(self.source_preview_group)
        source_actions = QtWidgets.QHBoxLayout(); preview_layout.addLayout(source_actions)
        self.preview_source_button = QtWidgets.QPushButton("Preview past messages")
        self.preview_source_button.clicked.connect(self._preview_source_data)
        self.source_preview_status = QtWidgets.QLabel("Preview to verify the session scope and eligible-message filter. Use Add from available for series discovery."); self.source_preview_status.setStyleSheet("color: palette(mid);")
        source_actions.addWidget(self.preview_source_button); source_actions.addWidget(self.source_preview_status, 1)

        self.historical_preview_group = QtWidgets.QGroupBox("Preview past messages")
        historical_layout = QtWidgets.QVBoxLayout(self.historical_preview_group)
        self.historical_preview_toggle = QtWidgets.QToolButton()
        self.historical_preview_toggle.setCheckable(True)
        self.historical_preview_toggle.setChecked(False)
        self.historical_preview_toggle.setText("Show past-message preview settings")
        self.historical_preview_toggle.setArrowType(QtCore.Qt.RightArrow)
        self.historical_preview_toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.historical_preview_toggle.setToolTip(
            "Show retained-message preview limits and controls. These settings do not affect discovery or live dataset retention."
        )
        historical_layout.addWidget(self.historical_preview_toggle)
        historical_note = QtWidgets.QLabel(
            "Temporarily inspect previously retained messages. These controls do not affect series discovery, live collection, dataset retention, Excel output, or the visible plot window."
        )
        historical_note.setWordWrap(True); historical_note.setStyleSheet("color: palette(mid);")
        historical_layout.addWidget(historical_note)
        historical_layout.addWidget(self.source_history_controls)
        historical_layout.addWidget(self.source_preview_group)
        self.historical_preview_content = [historical_note, self.source_history_controls, self.source_preview_group]
        self.historical_preview_toggle.toggled.connect(self._update_historical_preview_visibility)
        for widget in self.historical_preview_content: widget.hide()
        source_layout.addWidget(self.historical_preview_group)
        for widget in (self.source_scope, self.message_filter_combo, self.collection_mode, self.collection_interval, self.collection_policy, self.collection_start_position, self.maximum_candidates, self.collection_overflow, self.source_history_mode, self.source_history_amount, self.source_history_unit, self.maximum_cycle_rows):
            signal = widget.toggled if isinstance(widget, QtWidgets.QCheckBox) else widget.valueChanged if isinstance(widget, (QtWidgets.QSpinBox, QtWidgets.QDoubleSpinBox)) else widget.textEdited if isinstance(widget, QtWidgets.QLineEdit) else widget.currentIndexChanged
            signal.connect(self._source_controls_changed)
        self.source_session_table.itemChanged.connect(self._source_session_selection_changed)

        self.series_group = QtWidgets.QGroupBox()
        series_layout = QtWidgets.QVBoxLayout(self.series_group)
        self.series_toggle = self._add_section(
            root, "Series selection and processing", self.series_group, visible=False,
            tooltip="Add extracted values and configure processing, per-series collection, and stream identity. Plot presentation is managed in Display settings.",
        )
        self.series_group.setMinimumHeight(350)
        series_note = QtWidgets.QLabel("Add a value discovered in the selected messages, or define a custom extractor. Every configured series belongs to the shared insight dataset. Excel membership is selected in Excel Output; plotting and presentation are selected in Display Settings.")
        series_note.setWordWrap(True); series_note.setStyleSheet("color: palette(mid);"); series_layout.addWidget(series_note)
        self.insight_series_table = QtWidgets.QTableWidget(0, 5); self.insight_series_table.setHorizontalHeaderLabels(["Series name", "Source path", "Observed type", "Availability", "Processing"])
        self.insight_series_table.verticalHeader().setVisible(False); self.insight_series_table.setAlternatingRowColors(True); self.insight_series_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        header = self.insight_series_table.horizontalHeader()
        for column in range(5): header.setSectionResizeMode(column, QtWidgets.QHeaderView.Stretch if column in {0, 1, 4} else QtWidgets.QHeaderView.ResizeToContents)
        self.insight_series_table.itemChanged.connect(self._insight_series_changed); self.insight_series_table.cellDoubleClicked.connect(lambda *_args: self._configure_selected_insight_series())
        self.insight_series_table.itemSelectionChanged.connect(self._insight_series_table_selection_changed)
        series_layout.addWidget(self.insight_series_table, 1)
        series_actions = QtWidgets.QHBoxLayout(); series_layout.addLayout(series_actions)
        self.add_available_series_button = QtWidgets.QPushButton("Add from available...")
        self.add_custom_series_button = QtWidgets.QPushButton("Add custom series...")
        self.series_selector = QtWidgets.QComboBox(); self.series_selector.setMinimumWidth(180)
        self.configure_series_button = QtWidgets.QPushButton("Configure...")
        self.remove_series_button = QtWidgets.QPushButton("Remove selected")
        self.discover_series_button = self.add_available_series_button
        self.add_available_series_button.clicked.connect(self._add_available_insight_series)
        self.add_custom_series_button.clicked.connect(self._add_custom_insight_series)
        self.configure_series_button.clicked.connect(self._configure_selected_insight_series)
        self.remove_series_button.clicked.connect(self._remove_selected_insight_series)
        self.series_selector.currentIndexChanged.connect(self._insight_series_selector_changed)
        self.series_catalog_status = QtWidgets.QLabel("Add a discovered or custom series to begin."); self.series_catalog_status.setStyleSheet("color: palette(mid);")
        series_actions.addWidget(self.add_available_series_button); series_actions.addWidget(self.add_custom_series_button)
        series_actions.addSpacing(12); series_actions.addWidget(QtWidgets.QLabel("Configure series")); series_actions.addWidget(self.series_selector)
        series_actions.addWidget(self.configure_series_button); series_actions.addWidget(self.remove_series_button); series_actions.addWidget(self.series_catalog_status, 1)
        self._insight_series_catalog = []

        self.dataset_editor = InsightDatasetSettingsEditor(self)
        self.dataset_editor.setTitle("Excel output")
        self.dataset_editor.expand_button.setChecked(True)
        self.dataset_editor.expand_button.hide()
        self.dataset_editor.configurationChanged.connect(self._dataset_configuration_changed)
        self.dataset_editor.actionRequested.connect(self._dataset_action_requested)
        self.dataset_editor.seriesExportChanged.connect(self._export_series_changed)
        self.dataset_toggle = self._add_section(
            root, "Excel output", self.dataset_editor, visible=False,
            tooltip="Choose which values from the shared insight dataset are written and configure workbook output. This does not change the data used by plots.",
        )

        lifecycle_separator = QtWidgets.QFrame()
        lifecycle_separator.setFrameShape(QtWidgets.QFrame.VLine)
        lifecycle_separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        top.insertWidget(top.indexOf(self.export_button), lifecycle_separator)
        self.dataset_editor.runtime_state.setToolTip(
            "Current state of the selected Protocol Insight dataset across its configured sessions."
        )
        top.insertWidget(top.indexOf(self.export_button), self.dataset_editor.runtime_state)
        for action in ("start", "pause", "resume", "stop"):
            button = self.dataset_editor.action_buttons[action]
            top.insertWidget(top.indexOf(self.export_button), button)
        self.dataset_editor.action_buttons["start"].setToolTip(
            "Start the selected Protocol Insight dataset on its configured sessions. Excel Output remains optional."
        )
        self.dataset_editor.action_buttons["pause"].setToolTip(
            "Temporarily pause dataset collection without discarding retained samples."
        )
        self.dataset_editor.action_buttons["resume"].setToolTip(
            "Resume collection into the existing retained insight dataset."
        )
        self.dataset_editor.action_buttons["stop"].setToolTip(
            "Stop this Protocol Insight dataset. Excel is written only when Excel Output is enabled."
        )

        excel_control = QtWidgets.QWidget()
        excel_control_layout = QtWidgets.QHBoxLayout(excel_control)
        excel_control_layout.setContentsMargins(0, 0, 0, 0)
        excel_control_layout.addWidget(self.dataset_editor._widgets["Excel"])
        excel_control_note = QtWidgets.QLabel(
            "Optional. Leave disabled to collect and display insight data without creating workbooks."
        )
        excel_control_note.setWordWrap(True); excel_control_note.setStyleSheet("color: palette(mid);")
        excel_control_layout.addWidget(excel_control_note, 1)
        self.dataset_editor.layout().insertWidget(1, excel_control)
        self.dataset_editor._setting_rows["Excel"].hide()
        self.dataset_editor._group_widgets["Output control"].hide()
        self.excel_output_enabled = self.dataset_editor._widgets["Excel"]

        # The editor owns one configuration object, but its controls are placed
        # according to responsibility: dataset lifecycle/storage upstream and
        # Excel projection/output downstream. Reparenting preserves one source
        # of truth and the existing signal wiring.
        self.dataset_group = QtWidgets.QGroupBox("Insight dataset")
        dataset_layout = QtWidgets.QVBoxLayout(self.dataset_group)
        self.dataset_editor.dataset_enabled.hide()
        self.dataset_editor.pipeline_summary.hide()
        self.dataset_editor.compact_state.hide()
        self.dataset_groups = {}
        for title in ("Retention", "Recovery"):
            index = self.dataset_editor.tabs.indexOf(next(
                (self.dataset_editor.tabs.widget(i) for i in range(self.dataset_editor.tabs.count())
                 if self.dataset_editor.tabs.tabText(i) == title), None
            ))
            if index >= 0:
                page = self.dataset_editor.tabs.widget(index)
                self.dataset_editor.tabs.removeTab(index)
                page.layout().setContentsMargins(0, 0, 0, 0)
                group = QtWidgets.QGroupBox(title)
                group_layout = QtWidgets.QVBoxLayout(group)
                group_layout.addWidget(page)
                page.show()
                dataset_layout.addWidget(group)
                self.dataset_groups[title] = group
        source_layout.insertWidget(source_layout.indexOf(self.historical_preview_group), self.dataset_group)

        self.display_settings_group = QtWidgets.QGroupBox()
        self.display_settings_layout = QtWidgets.QVBoxLayout(self.display_settings_group)
        controls = QtWidgets.QHBoxLayout(); self.display_settings_layout.addLayout(controls)
        self.window_mode = QtWidgets.QComboBox(); self.window_mode.addItem("Last period", "last"); self.window_mode.addItem("All recorded", "all")
        self.amount = QtWidgets.QDoubleSpinBox(); self.amount.setRange(0.001, 1_000_000); self.amount.setDecimals(3)
        self.unit = QtWidgets.QComboBox(); self.unit.addItems(["milliseconds", "seconds", "minutes", "hours"])
        self.maximum_rows = QtWidgets.QSpinBox(); self.maximum_rows.setRange(100, 250_000); self.maximum_rows.setSingleStep(1000)
        self.refresh_interval = QtWidgets.QSpinBox(); self.refresh_interval.setRange(200, 60_000); self.refresh_interval.setSingleStep(100); self.refresh_interval.setSuffix(" ms")
        self.live = QtWidgets.QCheckBox("Live refresh")
        self.follow_latest = QtWidgets.QCheckBox("Follow latest")
        self.refresh_button = QtWidgets.QPushButton("Refresh Now"); self.refresh_button.clicked.connect(self.refresh)
        for widget, width in (
            (self.window_mode, 120), (self.amount, 75),
            (self.unit, 100), (self.maximum_rows, 95), (self.refresh_interval, 100),
        ):
            widget.setMaximumWidth(width)
        controls.addWidget(QtWidgets.QLabel("Window")); controls.addWidget(self.window_mode)
        controls.addWidget(QtWidgets.QLabel("Period")); controls.addWidget(self.amount); controls.addWidget(self.unit)
        controls.addWidget(QtWidgets.QLabel("Plot points")); controls.addWidget(self.maximum_rows)
        controls.addWidget(QtWidgets.QLabel("Refresh")); controls.addWidget(self.refresh_interval)
        controls.addStretch(1)
        controls.addWidget(self.follow_latest)
        controls.addWidget(self.live)
        controls.addWidget(self.refresh_button)
        for widget in (self.window_mode, self.amount, self.unit, self.maximum_rows, self.refresh_interval, self.follow_latest, self.live):
            signal = widget.toggled if isinstance(widget, QtWidgets.QCheckBox) else (widget.valueChanged if isinstance(widget, (QtWidgets.QSpinBox, QtWidgets.QDoubleSpinBox)) else widget.currentIndexChanged)
            signal.connect(self._controls_changed)
        x_axis_row = QtWidgets.QHBoxLayout(); self.display_settings_layout.addLayout(x_axis_row)
        x_axis_row.addWidget(QtWidgets.QLabel("Shared X axis"))
        self.x_axis_summary = QtWidgets.QLabel(); self.x_axis_summary.setStyleSheet("color: palette(mid);"); self.x_axis_summary.setMinimumWidth(180)
        x_axis_row.addWidget(self.x_axis_summary, 1)
        self.x_axis_button = QtWidgets.QPushButton("Configure X axis..."); self.x_axis_button.clicked.connect(self._configure_x_axis)
        x_axis_row.addWidget(self.x_axis_button)
        self.visualization_editor = CommonVisualizationEditor(
            PROTOCOL_INSIGHT_CAPABILITIES, self.hub.config.get("sessions", []), self,
            presentation_only=True,
        )
        display_guidance = QtWidgets.QLabel(
            "All plot presentation is configured here: plot ownership, temporary visibility, shared X axis, subplot layout, units, style, and color. Extraction, processing, export selection, and thresholds remain in Series selection and processing."
        )
        display_guidance.setWordWrap(True); display_guidance.setStyleSheet("color: palette(mid); padding: 2px 4px;")
        self.display_settings_layout.addWidget(display_guidance)
        self.visualization_editor.configurationChanged.connect(self._visualization_changed)
        self.visualization_editor.advancedSeriesRequested.connect(
            self._advanced_series_requested
        )
        self.tree = self.visualization_editor.tree
        self.visualization_editor.setMinimumHeight(310)
        self.display_settings_layout.addWidget(self.visualization_editor)
        self.marker_group = QtWidgets.QGroupBox("Event overlays (0)")
        self.marker_group.setCheckable(False)
        marker_layout = QtWidgets.QVBoxLayout(self.marker_group)
        marker_note = QtWidgets.QLabel(
            "Markers are always evaluated and displayed when configured. Add message appearances, field conditions, or transitions, then choose which subplots receive each marker."
        )
        marker_note.setWordWrap(True); marker_note.setStyleSheet("color: palette(mid);")
        marker_layout.addWidget(marker_note)
        self.event_marker_list = QtWidgets.QListWidget(); self.event_marker_list.setMaximumHeight(90)
        self.event_marker_list.setToolTip("Double-click a marker for a focused edit dialog, or use Manage markers for the complete table.")
        marker_layout.addWidget(self.event_marker_list)
        marker_actions = QtWidgets.QHBoxLayout(); marker_layout.addLayout(marker_actions)
        self.add_event_marker_button = QtWidgets.QPushButton("New overlay...")
        self.edit_event_marker_button = QtWidgets.QPushButton("Edit selected...")
        self.delete_event_marker_button = QtWidgets.QPushButton("Delete selected")
        self.manage_event_markers_button = QtWidgets.QPushButton("Open overlay table...")
        self.add_event_marker_button.clicked.connect(self._add_event_marker)
        self.edit_event_marker_button.clicked.connect(self._edit_selected_marker)
        self.delete_event_marker_button.clicked.connect(self._remove_selected_marker)
        self.manage_event_markers_button.clicked.connect(self._manage_event_markers)
        self.add_event_marker_button.setToolTip("Create an event overlay and select the subplots where it should be drawn.")
        self.edit_event_marker_button.setToolTip("Edit the selected overlay's trigger, filters, target subplots, color, and symbol.")
        self.delete_event_marker_button.setToolTip("Delete only the selected event overlay.")
        self.manage_event_markers_button.setToolTip("Open the complete event-overlay table for bulk review and editing.")
        for button in (self.add_event_marker_button, self.edit_event_marker_button, self.delete_event_marker_button, self.manage_event_markers_button):
            marker_actions.addWidget(button)
        marker_actions.addStretch(1)
        self.event_marker_list.itemDoubleClicked.connect(lambda _item: self._edit_selected_marker())
        self.event_marker_list.itemSelectionChanged.connect(self._update_event_marker_actions)
        self.display_settings_layout.addWidget(self.marker_group)
        self.visualization_group = self.display_settings_group
        self.display_settings_toggle = self._add_section(
            root, "Display settings", self.display_settings_group, visible=False,
            tooltip="Show or hide the display window, refresh behavior, subplot presentation, and display event overlays.",
        )

        self.display_group = QtWidgets.QGroupBox()
        display_layout = QtWidgets.QVBoxLayout(self.display_group)
        splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical); self.workspace_splitter = splitter
        display_layout.addWidget(splitter, 1)
        right = QtWidgets.QWidget(); right_layout = QtWidgets.QVBoxLayout(right); right_layout.setContentsMargins(0, 0, 0, 0)
        self.status = QtWidgets.QLabel("Add a subplot and series to begin insight."); self.status.setStyleSheet("color: palette(mid);"); right_layout.addWidget(self.status)
        self.plot_scroll = QtWidgets.QScrollArea(); self.plot_scroll.setWidgetResizable(True); self.plot_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.plot_scroll.setMinimumHeight(540)
        self.plot_container = QtWidgets.QWidget(); self.plot_layout = QtWidgets.QVBoxLayout(self.plot_container); self.plot_layout.setContentsMargins(0, 0, 0, 0); self.plot_layout.addStretch(1); self.plot_scroll.setWidget(self.plot_container); right_layout.addWidget(self.plot_scroll, 1)
        self.latest_group = QtWidgets.QGroupBox("Latest values")
        self.latest_group.setCheckable(False)
        latest_layout = QtWidgets.QVBoxLayout(self.latest_group)
        self.latest = QtWidgets.QTableWidget(0, 5); self.latest.setHorizontalHeaderLabels(["Subplot", "Series", "Latest time", "Latest value", "Samples"]); self.latest.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers); self.latest.setMinimumHeight(145); self.latest.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch); latest_layout.addWidget(self.latest)
        splitter.addWidget(right); splitter.addWidget(self.latest_group)
        splitter.setStretchFactor(0, 1); splitter.setStretchFactor(1, 0); splitter.setSizes([590, 170])
        self.display_group.setMinimumHeight(780)
        self.display_group.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.display_toggle = self._add_section(
            root, "Display", self.display_group, visible=True, stretch=1,
            tooltip="Show or hide the plot canvas and latest-values table together. The canvas expands into all unused workspace space.",
        )
        self.workspace_bottom_spacer = QtWidgets.QSpacerItem(
            0, 0, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed,
        )
        root.addItem(self.workspace_bottom_spacer)
        self.display_toggle.toggled.connect(self._display_section_toggled)
        tooltips = {
            self.view_combo: "Select a saved insight layout. Views retain their scope, time window, subplots, series, and refresh settings.",
            self.new_button: "Create a new empty insight view without changing existing saved views.",
            self.save_button: "Rename the current insight view. Other changes are saved automatically.",
            self.delete_button: "Delete the current insight view after confirmation. At least one view must remain.",
            self.export_button: (
                "Create and finish a complete aligned-timeline Excel workbook from the retained "
                "Protocol Insight dataset. Success is shown only after the file is written."
            ),
            self.transfer_outputs_button: (
                "Manage existing Excel outputs: select, open, delete, copy, move, or open their "
                "file location without changing the running insight."
            ),
            self.window_mode: "Limit plotted Insight Dataset samples to a rolling period, or show every sample retained by the display buffer.",
            self.amount: "Amount of time included when Window is set to Last period.",
            self.unit: "Time unit used by the rolling insight window.",
            self.maximum_rows: "Maximum points rendered across each plotted series after collection. This does not discard retained Insight samples.",
            self.refresh_interval: "Delay between live data refreshes. Lower values increase table-query and plotting CPU usage.",
            self.live: "Refresh automatically while this tab is visible. Manual Refresh Now remains available when disabled.",
            self.follow_latest: "Keep the visible display window anchored to the newest plotted sample without changing the retained insight dataset.",
            self.refresh_button: "Query the selected message tables now and update existing plot data without rebuilding the plots.",
            self.x_axis_summary: "One X-axis source is enforced for every series and subplot in this insight view.",
            self.x_axis_button: "Choose the timestamp, parsed field, decoded header, raw bytes, or metadata used as X for every message.",
            self.tree: "Saved subplot and series structure. Double-click an item to edit it.",
            self.latest: "Latest extracted value and plotted sample count for every configured series.",
            self.insight_autostart: "Automatically start this configured Protocol Insight whenever Communication Hub is created.",
            self.insight_application_lifetime: "Keep an active insight backend running after the Communication Hub window closes. It stops when the application exits or you explicitly select Stop.",
            self.insight_restore_last_state: "Restore this insight only when it was running at the previous Hub close. This is independent from automatic start and application lifetime.",
            self.source_scope: "Choose one current session, an explicit checked set, or every session with an available retained message table.",
            self.collection_mode: "Process each eligible arrival immediately, or accumulate per-series candidates and reduce them at scheduled intervals.",
            self.collection_interval: "Scheduled reducer interval. Incoming records are delivered directly by session workers; complete message tables are not repeatedly scanned.",
            self.collection_policy: "Default per-series reduction. Each series can inherit this policy or select an override in its configuration dialog.",
            self.collection_start_position: "Choose whether Start observes only new arrivals or first replays currently retained eligible messages.",
            self.maximum_candidates: "Bound pending scheduled candidates so sustained high input cannot grow memory without limit.",
            self.collection_overflow: "Choose how scheduled collection behaves if pending candidates reach their configured bound.",
            self.maximum_cycle_rows: "Maximum retained rows read from each session table by Preview past messages. Series discovery has its own limit.",
            self.source_history_mode: "Choose a recent time window or every retained message for Preview past messages only.",
            self.source_history_amount: "Length of retained history read by Preview past messages.",
            self.source_history_unit: "Time unit for the past-message preview period.",
            self.source_session_table: "For Selected sessions scope, check each retained or running message table that should contribute data.",
            self.message_filter_combo: "Choose All messages or a saved filter. Create and edit filters only in Message Table / Query.",
            self.preview_source_button: "Temporarily read retained messages and show matching rows. This does not configure or run series discovery.",
            self.insight_series_table: "Configured extraction and processing pipeline. Edit Series name directly; double-click a row to configure extraction, transforms, thresholds, and processors. Excel selection is in Excel Output.",
            self.add_available_series_button: "Open dedicated discovery settings, scan eligible retained messages for scalar, byte, dictionary, list, and array paths, then choose one series to add.",
            self.add_custom_series_button: "Define one series manually when its source path is absent from retained sample data or requires custom byte extraction.",
            self.series_selector: "Select which configured series the Configure and Remove selected actions operate on.",
            self.configure_series_button: "Configure source extraction, message restrictions, numeric transforms, thresholds, and processing for the selected series.",
            self.remove_series_button: "Remove the selected series from the insight dataset, Excel projection, and display configuration after confirmation.",
        }
        for widget, text in tooltips.items():
            widget.setToolTip(text)

    def _set_visualization_section_expanded(self, expanded):
        if hasattr(self, "display_settings_toggle"):
            self.display_settings_toggle.setChecked(bool(expanded))

    def _set_latest_section_expanded(self, expanded):
        if hasattr(self, "latest_group"):
            self.latest_group.setVisible(True)

    def _view(self):
        active = str(self.hub.config.get("active_protocol_insight_id", ""))
        return next((view for view in self.hub.config["protocol_insights"] if view["id"] == active), self.hub.config["protocol_insights"][0])

    def _reload_views(self):
        active = self._view()["id"]; self.view_combo.blockSignals(True); self.view_combo.clear()
        for view in self.hub.config["protocol_insights"]: self.view_combo.addItem(view["name"], view["id"])
        self.view_combo.setCurrentIndex(max(0, self.view_combo.findData(active))); self.view_combo.blockSignals(False); self._load_controls(); self._reload_tree(); self._show_selected_display_structure(); self.refresh()
        if hasattr(self.hub, "_refresh_insights_status"):
            self.hub._refresh_insights_status()

    def _load_controls(self):
        view = self._view(); display = view.get("display", {}); window = display.get("window", view["time_window"])
        display_widgets = (self.window_mode, self.amount, self.unit, self.maximum_rows, self.refresh_interval, self.follow_latest, self.live)
        for widget in display_widgets: widget.blockSignals(True)
        self.window_mode.setCurrentIndex(max(0, self.window_mode.findData(window["mode"]))); self.amount.setValue(window["amount"]); self.unit.setCurrentText(window["unit"]); self.maximum_rows.setValue(display.get("maximum_points", view["maximum_rows"])); self.refresh_interval.setValue(display.get("refresh_ms", view["refresh_ms"])); self.follow_latest.setChecked(display.get("follow_latest", True)); self.live.setChecked(display.get("live", view["live"]))
        for widget in display_widgets: widget.blockSignals(False)
        enabled = window["mode"] == "last"; self.amount.setEnabled(enabled); self.unit.setEnabled(enabled); self.timer.setInterval(display.get("refresh_ms", view["refresh_ms"]))
        self.x_axis_summary.setText(self._x_axis_summary(view.get("x_axis")))
        self.dataset_editor.set_configuration(view.get("dataset"))
        self.insight_autostart.blockSignals(True)
        self.insight_application_lifetime.blockSignals(True)
        self.insight_restore_last_state.blockSignals(True)
        self.insight_autostart.setChecked(bool(view.get("autostart", False)))
        self.insight_application_lifetime.setChecked(
            view.get("lifecycle", {}).get("scope", "window") == "application"
        )
        self.insight_restore_last_state.setChecked(
            bool(view.get("lifecycle", {}).get("restore_last_state", True))
        )
        self.insight_autostart.blockSignals(False)
        self.insight_application_lifetime.blockSignals(False)
        self.insight_restore_last_state.blockSignals(False)
        self._update_insight_summary(view)
        state_getter = getattr(self.hub, "_protocol_insight_state", None)
        if state_getter is not None:
            state, detail = state_getter(view)
            self.dataset_editor.set_runtime_state(state, detail)
        self.refresh_button.setEnabled(self._runtime_active(view))
        if hasattr(self, "timer"):
            if (
                self._runtime_active(view)
                and getattr(self.hub, "_ui_attached", True)
                and self._tab_is_active()
            ):
                self.timer.start(display.get("refresh_ms", view["refresh_ms"]))
            else:
                self.timer.stop()
        self._load_source_controls(view)
        self._reload_insight_series_table()

    def _lifecycle_controls_changed(self, *_args):
        view = self._view()
        view["autostart"] = self.insight_autostart.isChecked()
        view["lifecycle"] = {
            "scope": (
                "application" if self.insight_application_lifetime.isChecked()
                else "window"
            ),
            "restore_last_state": self.insight_restore_last_state.isChecked(),
        }
        self._update_insight_summary(view)
        self.hub._save()

    @staticmethod
    def _filter_summary(query):
        if not query: return "All messages"
        def count(node):
            if not isinstance(node, dict) or not node: return 0
            return sum(count(item) for item in node.get("conditions", [])) if "conditions" in node else 1
        amount = count(query)
        return f"{amount} condition{'s' if amount != 1 else ''}"

    def _update_insight_summary(self, view=None):
        if not hasattr(self, "insight_summary"):
            return
        view = view or self._view()
        source = normalize_protocol_insight_source(
            view.get("source"), view.get("scope", "current")
        )
        collection = source["collection"]
        scope = source.get("scope", "current")
        scope_text = {
            "current": "current selected session",
            "selected": f"{len(source.get('session_ids', []))} selected session(s)",
            "all": "all configured sessions",
        }.get(scope, "current selected session")
        collection_text = (
            f"scheduled every {float(collection.get('interval_seconds', 1)):g}s"
            if collection.get("mode") == "scheduled"
            else "on eligible message arrival"
        )
        sampling_text = str(collection.get("default_policy", "all")).replace("_", " ")
        series = [
            item for subplot in view.get("subplots", [])
            if subplot.get("kind") != "timeline"
            for item in subplot.get("series", [])
        ]
        plotted = sum(1 for item in series if item.get("plot_enabled", item.get("visible", True)))
        exported = sum(1 for item in series if item.get("export_enabled", True))
        dataset = view.get("dataset", {}) if isinstance(view.get("dataset"), dict) else {}
        excel_enabled = bool(dataset.get("excel", {}).get("enabled", False))
        excel_text = (
            f"Excel enabled for {exported} series"
            if excel_enabled else "Excel disabled"
        )
        lifecycle_text = (
            "application lifetime"
            if view.get("lifecycle", {}).get("scope") == "application"
            else "window lifetime"
        )
        if view.get("autostart"):
            lifecycle_text += ", starts automatically"
        if view.get("lifecycle", {}).get("restore_last_state", True):
            lifecycle_text += ", restores previous running state"
        self.insight_summary.setText(
            f"{scope_text} · {collection_text} · {sampling_text} · "
            f"{len(series)} dataset series · {plotted} plotted · {excel_text} · "
            f"{lifecycle_text}"
        )

    def _reload_collection_policy_options(self, mode, selected=None):
        options = [
            ("Every unused value", "all"),
            ("Only changed values", "changed"),
        ]
        if mode == "scheduled":
            options = [
                ("Every unused value", "all"),
                ("First unused value", "first"),
                ("Last unused value", "last"),
                ("Every changed value", "changed"),
                ("Last value, only if changed", "last_changed"),
            ]
        selected = selected or self.collection_policy.currentData() or "all"
        self.collection_policy.blockSignals(True)
        self.collection_policy.clear()
        for label, value in options:
            self.collection_policy.addItem(label, value)
        index = self.collection_policy.findData(selected)
        self.collection_policy.setCurrentIndex(index if index >= 0 else 0)
        self.collection_policy.blockSignals(False)

    def _reload_message_filter_options(self, source):
        selected_id = str(source.get("saved_query_id") or "")
        self.message_filter_combo.blockSignals(True)
        self.message_filter_combo.clear()
        self.message_filter_combo.addItem("All messages", "")
        for entry in self.hub.config.get("saved_queries", []):
            if not isinstance(entry, dict) or not entry.get("id"):
                continue
            query_id = str(entry["id"])
            self.message_filter_combo.addItem(
                str(entry.get("name") or "Unnamed filter"), query_id,
            )
            count = self._filter_summary(entry.get("query", {}))
            self.message_filter_combo.setItemData(
                self.message_filter_combo.count() - 1,
                f"Saved in Message Table / Query · {count}",
                QtCore.Qt.ToolTipRole,
            )
        index = self.message_filter_combo.findData(selected_id)
        self.message_filter_combo.setCurrentIndex(index if index >= 0 else 0)
        self.message_filter_combo.blockSignals(False)

    def reload_saved_message_filters(self):
        """Refresh the Insight filter picker after Message Table saves change."""
        if not hasattr(self, "message_filter_combo"):
            return
        self._load_source_controls()
        self._update_insight_summary()

    def _load_source_controls(self, view=None):
        view = view or self._view()
        source = normalize_protocol_insight_source(view.get("source"), view.get("scope", "current"))
        collection = source["collection"]
        history = source.get("history", {})
        self._reload_collection_policy_options(collection["mode"], collection.get("default_policy"))
        self._reload_message_filter_options(source)
        widgets = (
            self.source_scope, self.collection_mode, self.collection_interval,
            self.collection_policy, self.collection_start_position,
            self.maximum_candidates, self.collection_overflow,
            self.source_history_mode, self.source_history_amount,
            self.source_history_unit, self.maximum_cycle_rows,
        )
        for widget in widgets: widget.blockSignals(True)
        self.source_scope.setCurrentIndex(max(0, self.source_scope.findData(source["scope"])))
        self.collection_mode.setCurrentIndex(max(0, self.collection_mode.findData(collection["mode"])))
        self.collection_interval.setValue(collection["interval_seconds"])
        self.collection_policy.setCurrentIndex(max(0, self.collection_policy.findData(collection["default_policy"])))
        self.collection_start_position.setCurrentIndex(max(0, self.collection_start_position.findData(collection["start_position"])))
        self.maximum_candidates.setValue(collection["maximum_candidates_per_cycle"])
        self.collection_overflow.setCurrentIndex(max(0, self.collection_overflow.findData(collection["overflow_policy"])))
        self.source_history_mode.setCurrentIndex(max(0, self.source_history_mode.findData(history.get("mode", "last"))))
        self.source_history_amount.setValue(history.get("amount", 60.0))
        self.source_history_unit.setCurrentText(history.get("unit", "seconds"))
        self.maximum_cycle_rows.setValue(source.get("preview", {}).get("maximum_rows", 10_000))
        for widget in widgets: widget.blockSignals(False)
        self.source_session_table.blockSignals(True); self.source_session_table.setRowCount(0)
        selected = set(source.get("session_ids", []))
        for session in self.hub.config.get("sessions", []):
            row = self.source_session_table.rowCount(); self.source_session_table.insertRow(row)
            use = QtWidgets.QTableWidgetItem(); use.setFlags(use.flags() | QtCore.Qt.ItemIsUserCheckable); use.setCheckState(QtCore.Qt.Checked if str(session.get("id")) in selected else QtCore.Qt.Unchecked); use.setData(QtCore.Qt.UserRole, str(session.get("id", "")))
            controller = self.hub.controllers.get(session.get("id")); available = bool(controller and getattr(controller, "table_available", controller.running))
            values = (use, QtWidgets.QTableWidgetItem(str(session.get("name", "Unnamed"))), QtWidgets.QTableWidgetItem(str(session.get("protocol", ""))), QtWidgets.QTableWidgetItem("Available" if available else "No retained table"))
            for column, item in enumerate(values): self.source_session_table.setItem(row, column, item)
        self.source_session_table.blockSignals(False)
        self._update_source_control_visibility(source)

    def _update_source_control_visibility(self, source=None):
        source = source or normalize_protocol_insight_source(
            self._view().get("source"), self._view().get("scope", "current"),
        )
        collection = source["collection"]
        history = source.get("history", {}); scope = source.get("scope", "current")
        scheduled = collection.get("mode") == "scheduled"
        scope_text = {
            "current": "Uses the session selected in Communication Hub when this insight is started or previewed.",
            "selected": "Only the checked sessions contribute retained or live messages.",
            "all": "Uses every configured session. Running sessions feed live data; retained tables remain available for preview and discovery.",
        }
        self.source_scope_explanation.setText(scope_text.get(scope, ""))
        self.source_session_table.setVisible(scope == "selected")
        self.source_session_table.setEnabled(scope == "selected")
        self.source_history_period_widget.setVisible(history.get("mode") == "last")
        self.collection_interval_widget.setVisible(scheduled)
        self.pending_capacity_widget.setVisible(scheduled)
        self.collection_mode_explanation.setText(
            "Eligible messages are buffered and reduced independently for each series at every interval."
            if scheduled else
            "Each eligible message is processed as it arrives; each series may keep every value or only changes."
        )
        explanations = {
            "all": "Keeps every unused value for each series and stream.",
            "first": "Keeps the first unused value for each series and stream in an interval.",
            "last": "Keeps the last unused value for each series and stream in an interval.",
            "changed": "Keeps each value that differs from the previous value in the same series stream.",
            "last_changed": "Keeps the interval's last value only when it differs from the previously retained value.",
        }
        self.collection_policy_explanation.setText(
            explanations.get(collection.get("default_policy", "all"), "")
        )
        self._update_historical_preview_visibility(
            self.historical_preview_toggle.isChecked()
        )

    def _update_historical_preview_visibility(self, expanded):
        expanded = bool(expanded)
        if hasattr(self, "historical_preview_toggle"):
            self.historical_preview_toggle.setText(
                "Hide past-message preview settings" if expanded
                else "Show past-message preview settings"
            )
            self.historical_preview_toggle.setArrowType(
                QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow
            )
        for widget in getattr(self, "historical_preview_content", []):
            widget.setVisible(expanded)

    def _source_controls_changed(self, *_args):
        source = normalize_protocol_insight_source(self._view().get("source"), self._view().get("scope", "current"))
        collection = source["collection"]
        new_mode = self.collection_mode.currentData()
        if new_mode != collection.get("mode"):
            self._reload_collection_policy_options(new_mode, collection.get("default_policy"))
        source["scope"] = self.source_scope.currentData()
        saved_query_id = str(self.message_filter_combo.currentData() or "")
        saved_query = next((
            entry for entry in self.hub.config.get("saved_queries", [])
            if isinstance(entry, dict) and str(entry.get("id", "")) == saved_query_id
        ), None)
        source["saved_query_id"] = saved_query_id if saved_query is not None else ""
        source["data_filter"] = (
            copy.deepcopy(saved_query.get("query", {}))
            if saved_query is not None else {}
        )
        collection.update({
            "mode": new_mode,
            "interval_seconds": self.collection_interval.value(),
            "default_policy": self.collection_policy.currentData() or "all",
            "start_position": self.collection_start_position.currentData(),
            "maximum_candidates_per_cycle": self.maximum_candidates.value(),
            "overflow_policy": self.collection_overflow.currentData(),
        })
        source["preview"] = {"maximum_rows": self.maximum_cycle_rows.value()}
        source["history"] = {"mode": self.source_history_mode.currentData(), "amount": self.source_history_amount.value(), "unit": self.source_history_unit.currentText()}
        self._view()["source"] = source; self._view()["scope"] = "global" if source["scope"] == "all" else "current"
        self._update_insight_summary()
        self._update_source_control_visibility(source)
        self._clear_dataset_display_cache(self._view().get("id"))
        self._mark_runtime_stale("Source or collection settings changed")
        self.hub._save(); self.refresh()

    def _source_session_selection_changed(self, item):
        if item.column() != 0: return
        selected = [str(self.source_session_table.item(row, 0).data(QtCore.Qt.UserRole)) for row in range(self.source_session_table.rowCount()) if self.source_session_table.item(row, 0).checkState() == QtCore.Qt.Checked]
        source = normalize_protocol_insight_source(self._view().get("source"), self._view().get("scope", "current")); source["session_ids"] = selected; self._view()["source"] = source; self._clear_dataset_display_cache(self._view().get("id")); self._mark_runtime_stale("Session selection changed"); self.hub._save(); self.refresh()

    def _source_preview_operation(self, view=None):
        view = copy.deepcopy(view if isinstance(view, dict) else self._view()); records = []
        maximum = view.get("source", {}).get("preview", {}).get("maximum_rows", 10_000)
        for config, controller in self._sources(view):
            result = controller.query(protocol_insight_query(view), page=0, page_size=maximum, sort_by="timestamp", descending=True)
            for row in result.get("rows", []): row.setdefault("session_name", config.get("name", "")); records.append(row)
        records.sort(key=lambda row: int(row.get("timestamp_ns") or timestamp_ns(row.get("timestamp"))))
        selected, _unused = protocol_insight_select_records(view, records)
        return {"records": records, "selected": selected}

    def _preview_source_data(self):
        self.preview_source_button.setEnabled(False); self.source_preview_status.setText("Querying selected message tables...")
        call = self.hub._run_async(self._source_preview_operation, self._source_preview_ready, quiet=True, failure=lambda error: self.source_preview_status.setText(str(error).splitlines()[-1]))
        call.finished.connect(lambda: self.preview_source_button.setEnabled(True))

    def _source_preview_ready(self, result):
        self._last_source_preview = result
        self.source_preview_status.setText(f"{len(result['records']):,} filtered row(s); {len(result['selected']):,} eligible row(s).")
        InsightSourcePreviewDialog(result, self).exec_()

    def _discover_insight_series(self, discovery_configuration):
        self.discover_series_button.setEnabled(False); self.series_catalog_status.setText("Discovering nested fields and value types...")
        discovery_view = copy.deepcopy(self._view())
        discovery = copy.deepcopy(discovery_configuration)
        discovery_view.setdefault("source", {})["history"] = copy.deepcopy(discovery["history"])
        discovery_view["source"]["preview"] = {"maximum_rows": int(discovery["maximum_rows"])}
        def operation():
            result = self._source_preview_operation(discovery_view)
            source = normalize_protocol_insight_source(discovery_view.get("source"), discovery_view.get("scope", "current"))
            engine = QueryEngine(); data_filter = source.get("data_filter", {})
            candidates = [row for row in result["records"] if not data_filter or engine.matches_record(row, data_filter)]
            return result, discover_protocol_insight_series(candidates)
        call = self.hub._run_async(operation, self._insight_series_discovery_ready, quiet=True, failure=lambda error: self.series_catalog_status.setText(str(error).splitlines()[-1]))
        call.finished.connect(lambda: self.discover_series_button.setEnabled(True))

    def _insight_series_discovery_ready(self, payload):
        result, catalog = payload; self._last_source_preview = result; self._insight_series_catalog = catalog
        self.series_catalog_status.setText(f"{len(catalog):,} possible series path(s) discovered from {len(result['records']):,} filtered row(s).")
        self.source_toggle.setChecked(False); self.series_toggle.setChecked(True); self._reload_insight_series_table()
        if getattr(self, "_choose_available_after_discovery", False):
            self._choose_available_after_discovery = False
            self._show_available_series_picker()

    def _add_available_insight_series(self):
        source = normalize_protocol_insight_source(
            self._view().get("source"), self._view().get("scope", "current")
        )
        scope_text = {
            "current": "Session selected in Communication Hub",
            "selected": f"{len(source.get('session_ids', []))} explicitly selected session(s)",
            "all": "All configured sessions with retained message tables",
        }.get(source.get("scope"), "Session selected in Communication Hub")
        dialog = InsightSeriesDiscoveryDialog(
            self._view().get("series_discovery", {}), scope_text, self,
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        discovery = dialog.configuration()
        self._view()["series_discovery"] = copy.deepcopy(discovery)
        self._insight_series_catalog = []
        self.hub._save()
        self._choose_available_after_discovery = True
        self._discover_insight_series(discovery)

    def _show_available_series_picker(self):
        configured_paths = {self._series_source_path(series) for _subplot, series in self._configured_insight_series()}
        candidates = [item for item in self._insight_series_catalog if str(item.get("path", "")) not in configured_paths]
        if not candidates:
            QtWidgets.QMessageBox.information(self, "No additional available series", "Every discovered value is already configured. Use Add custom series to define another extractor or adjust the source filter.")
            return
        labels = [f"{item.get('path', 'Value')}  ({', '.join(item.get('types', [])) or 'unknown'})" for item in candidates]
        selected, accepted = QtWidgets.QInputDialog.getItem(self, "Add available series", "Available value", labels, 0, False)
        if not accepted: return
        candidate = candidates[labels.index(selected)]
        regular = [item for item in self._view().setdefault("subplots", []) if item.get("kind") != "timeline"]
        if not regular:
            regular.append(new_subplot("Values")); self._view()["subplots"].append(regular[0])
        series = new_series(str(candidate.get("path", "Value")).split(".")[-1])
        series["id"] = str(candidate.get("id") or uuid.uuid4()); series["source"] = copy.deepcopy(candidate.get("source", {}))
        series["export_enabled"] = True; series["plot_enabled"] = True; series["visible"] = True
        regular[0].setdefault("series", []).append(series)
        self._mark_runtime_stale("Series added"); self.hub._save(); self._reload_tree(); self._select_insight_series(series["id"]); self.refresh()

    def _add_custom_insight_series(self):
        regular = [item for item in self._view().setdefault("subplots", []) if item.get("kind") != "timeline"]
        if not regular:
            regular.append(new_subplot("Values")); self._view()["subplots"].append(regular[0])
        series = new_series("Custom series"); series["export_enabled"] = True; series["plot_enabled"] = True; series["visible"] = True
        self._show_series_dialog(self._insight_series_catalog_by_message(), series, regular[0]["id"], adding=True)

    def _insight_series_catalog_by_message(self):
        result = {}
        for item in self._insight_series_catalog:
            for name in item.get("messages", item.get("names", [])):
                entry = result.setdefault(str(name), {"fields": [], "names": []})
                entry["fields"].append(str(item.get("path", ""))); entry["names"].append(str(name))
        return result

    def _configured_insight_series(self):
        return [(subplot, series) for subplot in self._view().get("subplots", []) if subplot.get("kind") != "timeline" for series in subplot.get("series", [])]

    @staticmethod
    def _series_source_path(series):
        source = series.get("source", {})
        return str(source.get("path") or source.get("field") or source.get("kind", ""))

    def _reload_insight_series_table(self):
        if not hasattr(self, "insight_series_table"): return
        catalog = {str(item.get("id")): copy.deepcopy(item) for item in self._insight_series_catalog}
        catalog_by_path = {str(item.get("path", "")): copy.deepcopy(item) for item in self._insight_series_catalog}
        configured = self._configured_insight_series()
        self.insight_series_table.blockSignals(True); self.insight_series_table.setRowCount(0)
        for subplot, series in configured:
            series_id = str(series.get("id")); source_path = self._series_source_path(series)
            candidate = catalog.get(series_id) or catalog_by_path.get(source_path) or {"id": series_id, "path": source_path, "types": ["custom"], "availability": 0.0}
            row = self.insight_series_table.rowCount(); self.insight_series_table.insertRow(row)
            label = QtWidgets.QTableWidgetItem(str(series.get("label", "Series"))); label.setData(QtCore.Qt.UserRole, series_id); path = QtWidgets.QTableWidgetItem(str(source_path)); path.setFlags(path.flags() & ~QtCore.Qt.ItemIsEditable)
            observed = QtWidgets.QTableWidgetItem(", ".join(candidate.get("types", []))); observed.setFlags(observed.flags() & ~QtCore.Qt.ItemIsEditable)
            availability = QtWidgets.QTableWidgetItem(f"{float(candidate.get('availability', 0.0)):.1f}%"); availability.setFlags(availability.flags() & ~QtCore.Qt.ItemIsEditable)
            processor = series.get("processor", {}); transform = series.get("transform", {})
            summary = "Direct"; summary = "Processor" if processor.get("enabled") else summary; summary += f"; scale {transform.get('scale', 1):g}, offset {transform.get('offset', 0):g}" if transform and (transform.get("scale", 1) != 1 or transform.get("offset", 0) != 0) else ""
            processing = QtWidgets.QTableWidgetItem(summary); processing.setFlags(processing.flags() & ~QtCore.Qt.ItemIsEditable)
            for column, item in enumerate((label, path, observed, availability, processing)): self.insight_series_table.setItem(row, column, item)
        self._displayed_series_catalog = catalog
        self.insight_series_table.blockSignals(False)
        self._reload_insight_series_selector()
        if hasattr(self, "dataset_editor"):
            self.dataset_editor.set_export_series([{
                "id": series.get("id"), "label": series.get("label", "Series"),
                "source_path": self._series_source_path(series),
                "export_enabled": series.get("export_enabled", True),
            } for _subplot, series in self._configured_insight_series()])
            self._update_insight_summary()

    def _ensure_insight_series(self, candidate_id):
        for subplot, series in self._configured_insight_series():
            if str(series.get("id")) == str(candidate_id): return subplot, series
        candidate = getattr(self, "_displayed_series_catalog", {}).get(str(candidate_id))
        if candidate is None: return None, None
        regular = [item for item in self._view().setdefault("subplots", []) if item.get("kind") != "timeline"]
        if not regular:
            regular.append(new_subplot("Values")); self._view()["subplots"].append(regular[0])
        series = new_series(str(candidate.get("path", "Value")).split(".")[-1]); series["id"] = str(candidate["id"]); series["source"] = copy.deepcopy(candidate.get("source", {})); series["export_enabled"] = False; series["plot_enabled"] = False; series["visible"] = True
        regular[0]["series"].append(series); return regular[0], series

    def _insight_series_changed(self, item):
        if item.column() != 0: return
        candidate_id = self.insight_series_table.item(item.row(), 0).data(QtCore.Qt.UserRole); subplot, series = self._ensure_insight_series(candidate_id)
        if series is None: return
        series["label"] = self.insight_series_table.item(item.row(), 0).text().strip() or "Series"
        self._clear_dataset_display_cache(self._view().get("id"))
        self._mark_runtime_stale("Series selection or processing changed")
        self.hub._save(); self._reload_tree(); self.refresh()

    def _export_series_changed(self, series_id, enabled):
        _subplot, series = self._find_series(str(series_id))
        if series is None: return
        series["export_enabled"] = bool(enabled)
        self._update_insight_summary()
        self._mark_runtime_stale("Excel series selection changed"); self.hub._save()

    def _insight_series_subplot_changed(self, candidate_id, target_id):
        if not target_id: return
        subplot, series = self._ensure_insight_series(candidate_id)
        if series is None or str(subplot.get("id")) == str(target_id): return
        subplot["series"].remove(series); target = next((item for item in self._view().get("subplots", []) if str(item.get("id")) == str(target_id)), None)
        if target is not None: target.setdefault("series", []).append(series); self._mark_runtime_stale("Series subplot changed"); self.hub._save(); self._reload_tree(); self.refresh()

    def _reload_insight_series_selector(self):
        if not hasattr(self, "series_selector"): return
        selected = str(self.series_selector.currentData() or "")
        self.series_selector.blockSignals(True); self.series_selector.clear()
        for _subplot, series in self._configured_insight_series():
            self.series_selector.addItem(str(series.get("label", "Series")), str(series.get("id", "")))
        if selected: self.series_selector.setCurrentIndex(max(0, self.series_selector.findData(selected)))
        self.series_selector.blockSignals(False)
        enabled = self.series_selector.count() > 0
        self.configure_series_button.setEnabled(enabled); self.remove_series_button.setEnabled(enabled)

    def _select_insight_series(self, series_id):
        series_id = str(series_id)
        index = self.series_selector.findData(series_id)
        if index >= 0:
            self.series_selector.setCurrentIndex(index)
        for row in range(self.insight_series_table.rowCount()):
            item = self.insight_series_table.item(row, 0)
            if item and str(item.data(QtCore.Qt.UserRole)) == series_id:
                self.insight_series_table.selectRow(row); break

    def _insight_series_table_selection_changed(self):
        row = self.insight_series_table.currentRow()
        item = self.insight_series_table.item(row, 0) if row >= 0 else None
        if item is None: return
        index = self.series_selector.findData(str(item.data(QtCore.Qt.UserRole)))
        if index >= 0:
            self.series_selector.blockSignals(True); self.series_selector.setCurrentIndex(index); self.series_selector.blockSignals(False)

    def _insight_series_selector_changed(self, _index):
        series_id = str(self.series_selector.currentData() or "")
        if series_id: self._select_insight_series(series_id)

    def _configure_selected_insight_series(self):
        candidate_id = str(self.series_selector.currentData() or "")
        if not candidate_id:
            row = self.insight_series_table.currentRow()
            if row < 0: return
            candidate_id = str(self.insight_series_table.item(row, 0).data(QtCore.Qt.UserRole))
        _subplot, series = self._ensure_insight_series(candidate_id)
        if series is not None: self._advanced_series_requested(series["id"])

    def _remove_selected_insight_series(self):
        series_id = str(self.series_selector.currentData() or "")
        if not series_id: return
        subplot, series = self._find_series(series_id)
        if series is None: return
        if QtWidgets.QMessageBox.question(self, "Remove series?", f"Remove '{series.get('label', 'Series')}' from this Protocol Insight?", QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes: return
        subplot["series"] = [item for item in subplot.get("series", []) if str(item.get("id")) != series_id]
        self._mark_runtime_stale("Series removed"); self.hub._save(); self._reload_tree(); self.refresh()

    def _dataset_configuration_changed(self, dataset):
        self._view()["dataset"] = copy.deepcopy(dataset)
        self._update_source_control_visibility()
        self._update_insight_summary()
        self._clear_dataset_display_cache(self._view().get("id"))
        self._mark_runtime_stale("Dataset or Excel settings changed")
        self.hub._save()
        if hasattr(self.hub, "_refresh_insights_status"):
            self.hub._refresh_insights_status()
        self.refresh()

    def _mark_runtime_stale(self, detail):
        marker = getattr(self.hub, "_mark_protocol_insight_runtime_stale", None)
        if marker is not None:
            marker(self._view(), detail)

    def _dataset_action_requested(self, action):
        handler = getattr(self.hub, "_handle_protocol_insight_action", None)
        if handler is None:
            self.dataset_editor.set_runtime_state("error", "Protocol Insight runtime is unavailable")
            return
        handler(str(action), self._view(), self.dataset_editor)

    @staticmethod
    def _x_axis_summary(value):
        config = normalize_insight_x_axis(value)
        kind = config["kind"]
        if kind == "timestamp":
            source = (
                "message timestamp, elapsed from first displayed message"
                if config.get("timestamp_mode") == "elapsed"
                else "message timestamp, exact local time"
            )
        elif kind in {"parsed_field", "header_field"}:
            source = str(config.get("path", ""))
        elif kind == "metadata":
            source = str(config.get("field", ""))
        else:
            source = f"bytes {config.get('offset', 0)}:{config.get('length', 1)}"
        processor = config["processor"]
        if processor["enabled"]:
            source += f" -> {processor['module']}.{processor['function']}"
        return f"{config['label']} — {source} ({config['value_type']})"

    def _configure_x_axis(self):
        self.status.setText("Discovering fields for the shared X axis...")
        self.hub._run_async(
            self._catalog_operation, self._show_x_axis_dialog, quiet=True,
            failure=lambda error: self.status.setText(str(error).splitlines()[-1]),
        )

    def _show_x_axis_dialog(self, catalog):
        dialog = InsightXAxisDialog(catalog, self._view().get("x_axis"), self)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            self.status.setText("X-axis editing cancelled.")
            return
        self._view()["x_axis"] = dialog.result_config()
        self._clear_dataset_display_cache(self._view().get("id"))
        self._clear_pinned_hovers()
        self._mark_runtime_stale("Shared X axis changed")
        self.hub._save()
        self._load_controls()
        self.refresh()

    def _controls_changed(self, *_args):
        view = self._view()
        previous_live = bool(view.get("display", {}).get("live", view.get("live", True)))
        display = {
            "window": {
                "mode": self.window_mode.currentData(),
                "amount": self.amount.value(),
                "unit": self.unit.currentText(),
            },
            "maximum_points": self.maximum_rows.value(),
            "refresh_ms": self.refresh_interval.value(),
            "live": self.live.isChecked(),
            "follow_latest": self.follow_latest.isChecked(),
        }
        view["display"] = display
        view["time_window"] = copy.deepcopy(display["window"])
        view["maximum_rows"] = display["maximum_points"]
        view["refresh_ms"] = display["refresh_ms"]
        view["live"] = display["live"]
        self.amount.setEnabled(display["window"]["mode"] == "last")
        self.unit.setEnabled(self.amount.isEnabled())
        self.timer.setInterval(display["refresh_ms"])
        if display["live"] and not previous_live:
            self._dataset_snapshot_required.add(str(view.get("id", "")))
        self._last_result = None; self.export_button.setEnabled(self._checkpoint_available())
        self.hub._save(); self.refresh()

    def _view_changed(self, _index):
        view_id = self.view_combo.currentData()
        if view_id:
            self._last_result = None; self.export_button.setEnabled(self._checkpoint_available())
            self._dataset_snapshot_required.add(str(view_id))
            self.hub.config["active_protocol_insight_id"] = view_id; self.hub._save()
            self._load_controls(); self._reload_tree(); self._show_selected_display_structure(); self.refresh()

    def _show_selected_display_structure(self):
        """Never leave another insight's plots in the selected workspace."""
        view = copy.deepcopy(self._view())
        empty = build_protocol_insight_result(view, [])
        empty["view_id"] = view.get("id")
        self._render(empty)
        if view.get("subplots"):
            self.status.setText(
                "Configured display ready. Start the insight to collect data."
                if not self._runtime_active(view)
                else "Configured display ready. Loading current insight data..."
            )
        else:
            self.status.setText("Add a subplot and series to begin insight.")

    def _new_view(self):
        name, accepted = QtWidgets.QInputDialog.getText(self, "New Protocol Insight", "Configuration name", text=f"Protocol Insight {len(self.hub.config['protocol_insights']) + 1}")
        if not accepted or not name.strip(): return
        view = default_protocol_insight_config(name.strip()); self.hub.config["protocol_insights"].append(view); self.hub.config["active_protocol_insight_id"] = view["id"]; self.hub._save(); self._reload_views()

    def _save_view(self):
        name, accepted = QtWidgets.QInputDialog.getText(self, "Rename Protocol Insight", "Configuration name", text=self._view()["name"])
        if accepted and name.strip(): self._view()["name"] = name.strip(); self.hub._save(); self._reload_views()

    def _delete_view(self):
        if len(self.hub.config["protocol_insights"]) <= 1: QtWidgets.QMessageBox.information(self, "Cannot delete configuration", "At least one Protocol Insight configuration must remain."); return
        if QtWidgets.QMessageBox.question(self, "Delete Protocol Insight?", f"Delete '{self._view()['name']}'?", QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes: return
        current = self._view(); self._clear_dataset_display_cache(current.get("id")); self.hub.config["protocol_insights"].remove(current); self.hub.config["active_protocol_insight_id"] = self.hub.config["protocol_insights"][0]["id"]; self.hub._save(); self._reload_views()

    def _visualization_changed(self, document):
        view = self._view()
        previous_subplots = view.get("subplots", [])
        updated_subplots = copy.deepcopy(document.get("subplots", []))
        previous_lane_ids = {
            str(item.get("id")) for item in previous_subplots
            if item.get("kind") == "timeline"
        }
        updated_lane_ids = {
            str(item.get("id")) for item in updated_subplots
            if item.get("kind") == "timeline"
        }
        remaining_subplot_ids = {
            str(item.get("id")) for item in updated_subplots
        }
        retained_markers = []
        for marker in view.get("event_markers", []):
            targets = list(marker.get("target_subplot_ids", []))
            if targets:
                remaining_targets = [
                    target for target in targets
                    if str(target) in remaining_subplot_ids
                ]
                if not remaining_targets:
                    continue
                marker = copy.deepcopy(marker)
                marker["target_subplot_ids"] = remaining_targets
            retained_markers.append(marker)
        view["subplots"] = updated_subplots
        view["event_markers"] = retained_markers
        self._update_insight_summary()
        self._clear_dataset_display_cache(self._view().get("id"))
        self._clear_pinned_hovers()
        self.hub._save()
        self._reload_tree()
        if hasattr(self.hub, "_refresh_insights_status"):
            self.hub._refresh_insights_status()
        if previous_lane_ids != updated_lane_ids and self._runtime_active(view):
            retain_events = bool(view.get("event_markers")) or bool(updated_lane_ids)
            runtime_id = self.hub._protocol_insight_runtime_config(view).get("id", "")
            self.hub._run_async(
                lambda: self.hub._protocol_insight_service_request(
                    "event_retention",
                    {"protocol_insight_id": runtime_id, "enabled": retain_events},
                    timeout=10,
                ),
                lambda _result: self.refresh(),
                quiet=True,
                failure=lambda error: self.status.setText(
                    f"Event-lane update failed: {str(error).splitlines()[-1]}"
                ),
            )
            return
        self.refresh()

    def _advanced_series_requested(self, series_id):
        subplot, series = self._find_series(str(series_id))
        if series is None:
            return
        self.status.setText("Discovering messages and fields for the advanced series editor...")
        self.hub._run_async(
            self._catalog_operation,
            lambda catalog: self._show_series_dialog(
                catalog, series, subplot["id"],
            ),
            quiet=True,
            failure=lambda error: self.status.setText(str(error).splitlines()[-1]),
        )

    def _reload_tree(self):
        self.visualization_editor.set_document({"subplots": self._view().get("subplots", [])})
        self._reload_insight_series_table()
        self.event_marker_list.clear()
        subplot_titles = {
            subplot["id"]: subplot["title"]
            for subplot in self._view().get("subplots", [])
        }
        for marker in self._view().get("event_markers", []):
            targets = marker.get("target_subplot_ids", [])
            target_text = "all subplots" if not targets else ", ".join(
                subplot_titles.get(item, item) for item in targets
            )
            item = QtWidgets.QListWidgetItem(f"{marker['label']}  —  {target_text}")
            item.setData(QtCore.Qt.UserRole, marker["id"])
            self.event_marker_list.addItem(item)
        count = len(self._view().get("event_markers", []))
        self.marker_group.setTitle(f"Event overlays ({count})")
        self._update_event_marker_actions()

    def _update_event_marker_actions(self):
        selected = self._selected_marker() is not None
        if hasattr(self, "edit_event_marker_button"):
            self.edit_event_marker_button.setEnabled(selected)
            self.delete_event_marker_button.setEnabled(selected)

    def _manage_event_markers(self):
        if not self._view().get("subplots"):
            QtWidgets.QMessageBox.information(
                self, "Add a subplot first",
                "Create at least one subplot before configuring event overlays.",
            )
            return
        self.status.setText("Preparing the event-marker manager...")
        self.hub._run_async(
            self._catalog_operation, self._show_event_marker_manager,
            quiet=True,
            failure=lambda error: self.status.setText(str(error).splitlines()[-1]),
        )

    def _show_event_marker_manager(self, catalog):
        dialog = InsightEventMarkerManagerDialog(
            self._view().get("subplots", []),
            self.hub.config.get("sessions", []), catalog,
            self._view().get("event_markers", []), self,
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            self.status.setText("Event-marker management cancelled.")
            return
        self._view()["event_markers"] = dialog.result_markers()
        self._event_configuration_changed()

    def _selected_marker(self):
        item = self.event_marker_list.currentItem()
        return self._find_event_marker(item.data(QtCore.Qt.UserRole)) if item else None

    def _edit_selected_marker(self):
        marker = self._selected_marker()
        if marker is None:
            return
        self.status.setText("Discovering messages and fields for the event marker...")
        self.hub._run_async(
            self._catalog_operation,
            lambda catalog: self._show_event_marker_dialog(catalog, marker),
            quiet=True,
            failure=lambda error: self.status.setText(str(error).splitlines()[-1]),
        )

    def _remove_selected_marker(self):
        marker = self._selected_marker()
        if marker is None:
            return
        self._view()["event_markers"] = [
            item for item in self._view().get("event_markers", [])
            if item["id"] != marker["id"]
        ]
        self._event_configuration_changed()

    def _add_subplot(self):
        dialog = InsightSubplotDialog(
            self.hub.config.get("sessions", []), parent=self,
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        configured = dialog.result_config()
        self._view()["subplots"].append(configured)
        if configured.get("kind") == "timeline":
            self._event_configuration_changed()
        else:
            self.hub._save(); self._reload_tree(); self.refresh()

    def _catalog_operation(self):
        def walk(value, prefix="header_fields"):
            paths = []
            if isinstance(value, dict):
                for key, child in value.items(): paths.extend(walk(child, f"{prefix}.{key}"))
            elif isinstance(value, list):
                for index, child in enumerate(value[:20]): paths.extend(walk(child, f"{prefix}.{index}"))
            elif prefix:
                paths.append(prefix)
            return paths

        catalog = {}
        for config, controller in self.hub._available_table_controllers():
            try:
                names = controller.request("names", {})
                fields = controller.request("fields", {})
                field_paths = list(fields) if isinstance(fields, list) else list(fields.keys())
                recent = controller.query({}, page=0, page_size=200)
                header_paths = sorted({path for row in recent.get("rows", []) for path in walk(row.get("header_fields", {}))})
                catalog[config["id"]] = {"names": names, "fields": sorted(set(field_paths + header_paths))}
            except BaseException:
                catalog[config["id"]] = {"names": [], "fields": []}
        return catalog

    def _selected_subplot_id(self):
        item = self.tree.currentItem()
        if item is None: return self._view()["subplots"][0]["id"] if self._view()["subplots"] else None
        kind, item_id = item.data(0, QtCore.Qt.UserRole)
        if kind == "subplot": return item_id
        parent = item.parent(); return parent.data(0, QtCore.Qt.UserRole)[1] if parent else None

    def _add_series(self):
        regular_subplots = [
            subplot for subplot in self._view()["subplots"]
            if subplot.get("kind") != "timeline"
        ]
        if not regular_subplots:
            QtWidgets.QMessageBox.information(
                self, "Add a data subplot first",
                "Create a regular subplot before adding a data series.",
            )
            return
        selected_id = self._selected_subplot_id()
        if not any(subplot["id"] == selected_id for subplot in regular_subplots):
            selected_id = regular_subplots[0]["id"]
        self.status.setText("Discovering recorded message names and fields...")
        self.hub._run_async(self._catalog_operation, lambda catalog: self._show_series_dialog(catalog, None, selected_id), quiet=True, failure=lambda error: self.status.setText(str(error).splitlines()[-1]))

    def _find_series(self, series_id):
        for subplot in self._view()["subplots"]:
            for series in subplot["series"]:
                if series["id"] == series_id: return subplot, series
        return None, None

    def _find_event_marker(self, marker_id):
        return next((
            marker for marker in self._view().get("event_markers", [])
            if marker["id"] == marker_id
        ), None)

    def _add_event_marker(self):
        if not self._view().get("subplots"):
            QtWidgets.QMessageBox.information(
                self, "Add a subplot first",
                "Create at least one subplot before adding an event marker.",
            )
            return
        self.status.setText("Discovering messages and fields for the event marker...")
        self.hub._run_async(
            self._catalog_operation,
            lambda catalog: self._show_event_marker_dialog(catalog),
            quiet=True,
            failure=lambda error: self.status.setText(str(error).splitlines()[-1]),
        )

    def _show_event_marker_dialog(self, catalog, marker=None):
        dialog = InsightEventMarkerDialog(
            self._view()["subplots"], self.hub.config.get("sessions", []),
            catalog, marker, self,
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            self.status.setText("Event-marker editing cancelled.")
            return
        configured = dialog.result_config()
        markers = self._view().setdefault("event_markers", [])
        if marker is None:
            markers.append(configured)
        else:
            index = next(
                index for index, item in enumerate(markers)
                if item["id"] == marker["id"]
            )
            markers[index] = configured
        self._event_configuration_changed()

    def _event_configuration_changed(self):
        """Apply overlay/timeline retention without restarting the insight."""
        view = self._view()
        view_id = str(view.get("id", ""))
        retain_events = bool(view.get("event_markers")) or any(
            subplot.get("kind") == "timeline"
            for subplot in view.get("subplots", [])
        )
        self._clear_dataset_display_cache(view_id)
        self._clear_pinned_hovers()
        self.hub._save()
        self._reload_tree()
        if not self._runtime_active(view):
            self.refresh()
            return
        runtime_id = self.hub._protocol_insight_runtime_config(view).get("id", "")
        self.status.setText("Applying event-overlay settings...")
        self.hub._run_async(
            lambda: self.hub._protocol_insight_service_request(
                "event_retention",
                {"protocol_insight_id": runtime_id, "enabled": retain_events},
                timeout=10,
            ),
            lambda _result: self.refresh(),
            quiet=True,
            failure=lambda error: self.status.setText(
                f"Event-overlay settings failed: {str(error).splitlines()[-1]}"
            ),
        )

    def _edit_selected(self):
        item = self.tree.currentItem()
        if item is None: return
        kind, item_id = item.data(0, QtCore.Qt.UserRole)
        if kind == "event_group":
            return
        if kind == "event":
            marker = self._find_event_marker(item_id)
            if marker is None:
                return
            self.status.setText("Discovering messages and fields for the event marker...")
            self.hub._run_async(
                self._catalog_operation,
                lambda catalog: self._show_event_marker_dialog(catalog, marker),
                quiet=True,
                failure=lambda error: self.status.setText(str(error).splitlines()[-1]),
            )
            return
        if kind == "subplot":
            subplot = next((plot for plot in self._view()["subplots"] if plot["id"] == item_id), None)
            if subplot is None: return
            if subplot.get("kind") == "timeline":
                dialog = InsightTimelineDialog(
                    self.hub.config.get("sessions", []), subplot, self,
                )
                if dialog.exec_() != QtWidgets.QDialog.Accepted:
                    return
                subplot.update(dialog.result_config())
                self._event_configuration_changed()
                return
            title, accepted = QtWidgets.QInputDialog.getText(self, "Edit subplot", "Subplot title", text=subplot["title"])
            if not accepted or not title.strip(): return
            unit, accepted = QtWidgets.QInputDialog.getText(self, "Edit subplot", "Y-axis unit", text=subplot.get("unit", ""))
            if accepted: subplot.update({"title": title.strip(), "unit": unit.strip()}); self.hub._save(); self._reload_tree(); self.refresh()
            return
        subplot, series = self._find_series(item_id)
        if series is None: return
        self.status.setText("Discovering recorded message names and fields...")
        self.hub._run_async(self._catalog_operation, lambda catalog: self._show_series_dialog(catalog, series, subplot["id"]), quiet=True, failure=lambda error: self.status.setText(str(error).splitlines()[-1]))

    def _show_series_dialog(self, catalog, series, subplot_id, adding=False):
        regular_subplots = [
            subplot for subplot in self._view()["subplots"]
            if subplot.get("kind") != "timeline"
        ]
        source = normalize_protocol_insight_source(self._view().get("source"), self._view().get("scope", "current"))
        dialog = InsightSeriesDialog(
            regular_subplots, self.hub.config.get("sessions", []), catalog,
            series, subplot_id, source.get("collection"), self,
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted: self.status.setText("Series editing cancelled."); return
        target_id, configured = dialog.result_config()
        existing = [
            item for plot in self._view().get("subplots", [])
            for item in plot.get("series", [])
            if str(item.get("id")) != str(configured.get("id"))
        ]
        signature = protocol_insight_series_signature(configured)
        if any(protocol_insight_series_signature(item) == signature for item in existing):
            QtWidgets.QMessageBox.warning(
                self, "Duplicate series definition",
                "An existing series already uses the same source restrictions, extraction, processing, collection policy, and stream identity. Edit that series or change the identity/source definition.",
            )
            return
        if series is not None:
            old_plot, _old_series = self._find_series(series["id"])
            if old_plot: old_plot["series"] = [item for item in old_plot["series"] if item["id"] != series["id"]]
        target = next((plot for plot in self._view()["subplots"] if plot["id"] == target_id), None)
        if target is None:
            target = next((plot for plot in self._view()["subplots"] if plot.get("kind") != "timeline"), None)
        if target is None:
            target = new_subplot("Values"); self._view()["subplots"].append(target)
        target["series"].append(configured)
        self._mark_runtime_stale("Series extraction or processing changed")
        self.hub._save(); self._reload_tree(); self._select_insight_series(configured["id"]); self.refresh()

    def _remove_selected(self):
        item = self.tree.currentItem()
        if item is None: return
        kind, item_id = item.data(0, QtCore.Qt.UserRole)
        if kind == "event_group":
            return
        if kind == "event":
            self._view()["event_markers"] = [
                marker for marker in self._view().get("event_markers", [])
                if marker["id"] != item_id
            ]
            self._event_configuration_changed()
            return
        if kind == "subplot":
            removed_subplot = next(
                (
                    plot for plot in self._view()["subplots"]
                    if plot["id"] == item_id
                ),
                None,
            )
            self._view()["subplots"] = [
                plot for plot in self._view()["subplots"] if plot["id"] != item_id
            ]
            retained_markers = []
            for marker in self._view().get("event_markers", []):
                targets = marker.get("target_subplot_ids", [])
                if targets and item_id in targets:
                    remaining = [target for target in targets if target != item_id]
                    if not remaining:
                        continue
                    marker["target_subplot_ids"] = remaining
                retained_markers.append(marker)
            self._view()["event_markers"] = retained_markers
            if (removed_subplot or {}).get("kind") == "timeline":
                self._event_configuration_changed()
                return
        else:
            subplot, _series = self._find_series(item_id)
            if subplot: subplot["series"] = [series for series in subplot["series"] if series["id"] != item_id]
        self.hub._save(); self._reload_tree(); self.refresh()

    def _sources(self, view):
        source = normalize_protocol_insight_source(view.get("source"), view.get("scope", "current"))
        if source.get("scope") == "all": return self.hub._available_table_controllers()
        if source.get("scope") == "selected":
            selected = set(source.get("session_ids", []))
            return [
                (config, controller)
                for config, controller in self.hub._available_table_controllers()
                if str(config.get("id")) in selected
            ]
        config = self.hub._selected_config(); controller = self.hub._selected_controller()
        if config and controller and bool(getattr(controller, "table_available", controller.running)): return [(config, controller)]
        return []

    def _clear_dataset_display_cache(self, view_id=None):
        with self._dataset_state_lock:
            if view_id is None:
                self._dataset_cursors.clear()
                self._dataset_sample_buffers.clear()
                self._dataset_event_buffers.clear()
                self._dataset_snapshot_required.update(
                    str(item.get("id", ""))
                    for item in self.hub.config.get("protocol_insights", [])
                    if isinstance(item, dict)
                )
                return
            key = str(view_id)
            self._dataset_sample_buffers.pop(key, None)
            self._dataset_event_buffers.pop(key, None)
            self._dataset_snapshot_required.add(key)
            for cursor_key in [item for item in self._dataset_cursors if item[0] == key]:
                self._dataset_cursors.pop(cursor_key, None)

    def _collect(self, view, sources=None):
        # ``sources`` is resolved on the GUI thread. Current-session resolution
        # reads Qt selection state and must not happen inside the async worker.
        sources = list(sources if sources is not None else self._sources(view))
        dataset = view.get("dataset", {}) if isinstance(view.get("dataset"), dict) else {}
        dataset_active = bool(dataset.get("runtime", {}).get("active", False))
        needs_raw_records = (
            bool(view.get("event_markers"))
            or any(plot.get("kind") == "timeline" for plot in view.get("subplots", []))
        )
        records = []
        runtime_sessions_ready = []
        view_id = str(view.get("id", ""))
        if needs_raw_records:
            with self._dataset_state_lock:
                records = copy.deepcopy(self._dataset_event_buffers.get(view_id, []))

        monitor_config = self.hub._protocol_insight_runtime_config(view)
        display = view.get("display", {}) if isinstance(view.get("display"), dict) else {}
        display_limit = max(100, int(display.get("maximum_points", view.get("maximum_rows", 10_000))))
        cursor_key = (view_id, "service")
        with self._dataset_state_lock:
            buffers = self._dataset_sample_buffers.setdefault(view_id, {})
            cursor = int(self._dataset_cursors.get(cursor_key, 0))
            snapshot_required = (
                view_id in self._dataset_snapshot_required or cursor == 0
            )
        delta = {}
        snapshot = {}
        if dataset_active:
            if snapshot_required:
                snapshot = self.hub._protocol_insight_service_request(
                    "display_snapshot",
                    {
                        "protocol_insight_id": monitor_config["id"],
                        "sample_limit": display_limit,
                        "event_limit": display_limit,
                    },
                    timeout=10,
                ) or {}
                delta = {
                    "samples": snapshot.get("samples", []),
                    "cursor": snapshot.get("sample_cursor", 0),
                    "latest_version": snapshot.get("sample_latest_version", 0),
                    "reset": True,
                }
                with self._dataset_state_lock:
                    self._dataset_snapshot_required.discard(view_id)
            else:
                delta = self.hub._protocol_insight_service_request(
                    "sample_delta",
                    {
                        "protocol_insight_id": monitor_config["id"],
                        "after_version": cursor,
                        "limit": display_limit,
                    },
                    timeout=10,
                ) or {}
            runtime_sessions_ready.extend(
                str(session.get("id", ""))
                for session, controller in sources if controller.running
            )
        session_names = {
            str(session.get("id", "")): str(session.get("name", ""))
            for session, _controller in sources
        }
        incoming = list(delta.get("samples", []))
        for sample in incoming:
            sample.setdefault(
                "session_name", session_names.get(str(sample.get("session_id", "")), "")
            )
        with self._dataset_state_lock:
            service_buffer = buffers.setdefault("service", [])
            if delta.get("reset"):
                service_buffer[:] = incoming[-display_limit:]
            elif incoming:
                service_buffer.extend(incoming)
                del service_buffer[:-display_limit]
            if "cursor" in delta:
                self._dataset_cursors[cursor_key] = int(delta["cursor"])
        if needs_raw_records and dataset_active:
            event_cursor_key = (view_id, "events")
            with self._dataset_state_lock:
                event_cursor = int(self._dataset_cursors.get(event_cursor_key, 0))
            if snapshot_required:
                event_delta = {
                    "events": snapshot.get("events", []),
                    "cursor": snapshot.get("event_cursor", 0),
                    "latest_version": snapshot.get("event_latest_version", 0),
                    "reset": True,
                }
            else:
                event_delta = self.hub._protocol_insight_service_request(
                    "event_delta",
                    {
                        "protocol_insight_id": monitor_config["id"],
                        "after_version": event_cursor,
                        "limit": display_limit,
                    },
                    timeout=10,
                ) or {}
            incoming_events = list(event_delta.get("events", []))
            for event in incoming_events:
                event.setdefault(
                    "session_name",
                    session_names.get(str(event.get("session_id", "")), ""),
                )
            with self._dataset_state_lock:
                event_buffer = self._dataset_event_buffers.setdefault(view_id, [])
                if event_delta.get("reset"):
                    event_buffer[:] = incoming_events[-display_limit:]
                elif incoming_events:
                    event_buffer.extend(incoming_events)
                    del event_buffer[:-display_limit]
                if "cursor" in event_delta:
                    self._dataset_cursors[event_cursor_key] = int(
                        event_delta["cursor"]
                    )
                records = copy.deepcopy(event_buffer)
        with self._dataset_state_lock:
            dataset_samples = [
                copy.deepcopy(sample)
                for session_buffer in buffers.values()
                for sample in session_buffer
            ]
        event_records = []
        for record in records:
            copied = copy.deepcopy(record); copied["__events_only"] = True
            event_records.append(copied)
        sample_records = []
        series_by_name = {
            str(item.get("name")): str(item.get("id"))
            for item in monitor_config.get("series", [])
        }
        for sample in dataset_samples:
            values = sample.get("__series_values")
            if not isinstance(values, dict):
                values = {
                    series_id: sample.get(name)
                    for name, series_id in series_by_name.items()
                    if name in sample
                }
            sample_records.append({
                "timestamp": sample.get("sample_time"),
                "timestamp_ns": sample.get("sample_time_ns"),
                "id": sample.get("event_id"),
                "session_id": sample.get("session_id"),
                "session_name": sample.get("session_name", ""),
                "protocol": sample.get("protocol"),
                "direction": sample.get("direction"),
                "name": sample.get("message"),
                "connection_id": sample.get("connection_id", ""),
                "peer": sample.get("peer", ""),
                "data": {}, "__insight_sample": True,
                "__insight_values": values,
                "__insight_x": sample.get("__insights_x"),
            })
        records = event_records + sample_records
        records.sort(key=lambda row: int(row.get("timestamp_ns") or timestamp_ns(row.get("timestamp"))))
        result = build_protocol_insight_result(view, records)
        result["view_id"] = view.get("id")
        if dataset_active:
            result["protocol_insight_runtime_id"] = monitor_config.get("id", "")
            result["runtime_sessions_ready"] = runtime_sessions_ready
        return result

    @staticmethod
    def _runtime_active(view):
        dataset = view.get("dataset", {}) if isinstance(view, dict) else {}
        runtime = dataset.get("runtime", {}) if isinstance(dataset, dict) else {}
        # Runtime activity is authoritative. ``enabled`` is configuration
        # readiness owned by the editor and must never suppress a backend that
        # Start has already activated.
        return bool(runtime.get("active", False))

    def _checkpoint_path(self, view=None):
        selected = view if isinstance(view, dict) else self._view()
        dataset = selected.get("dataset", {}) if isinstance(selected, dict) else {}
        checkpoint = dataset.get("checkpoint", {}) if isinstance(dataset, dict) else {}
        raw_directory = str(checkpoint.get("directory", "")).strip()
        insight_id = str(dataset.get("id", "")).strip()
        if not raw_directory or not insight_id:
            return None
        directory = Path(raw_directory)
        if not directory.is_absolute():
            directory = Path(PROJECT_ROOT) / directory
        return directory / f"{insight_id}.pkl"

    def _checkpoint_available(self, view=None):
        path = self._checkpoint_path(view)
        return bool(path and path.is_file())

    def stop_runtime_frontend(self, view_id=None):
        """Cancel pending display work and leave the last render static."""
        if view_id is None or str(view_id) == str(self._view().get("id", "")):
            self._refresh_revision += 1
            self._refresh_pending = False
            self._refreshing = False
            self.timer.stop()
            self.refresh_button.setEnabled(False)
            self.export_button.setEnabled(
                self._last_result is not None or self._checkpoint_available()
            )
            self.status.setText(
                "Display polling stopped. Completing enabled final checkpoint and Excel output..."
            )

    def complete_runtime_stop(self, view_id=None):
        if view_id is None or str(view_id) == str(self._view().get("id", "")):
            self.status.setText(
                "Protocol Insight stopped. Final enabled outputs completed; no recurring backend or display work remains."
            )

    def start_runtime_frontend(self, view_id=None):
        if view_id is None or str(view_id) == str(self._view().get("id", "")):
            self._dataset_snapshot_required.add(
                str(view_id or self._view().get("id", ""))
            )
            self.refresh_button.setEnabled(True)
            if getattr(self.hub, "_ui_attached", True) and self._tab_is_active():
                self.timer.start(self._view().get("refresh_ms", 1000))

    def request_authoritative_snapshot(self, view_id=None):
        """Make the next refresh independent of an old frontend cursor."""
        self._dataset_snapshot_required.add(
            str(view_id or self._view().get("id", ""))
        )

    def refresh(self):
        if not self._tab_is_active(): return
        if not self._runtime_active(self._view()):
            self.refresh_button.setEnabled(False)
            return
        if self._refreshing:
            self._refresh_pending = True
            return
        view = copy.deepcopy(self._view())
        if not view.get("subplots"):
            self._render({
                "plots": [], "records": 0, "samples": 0, "view_id": view.get("id"),
                "x_axis": view.get("x_axis"), "event_markers": [],
                "processor_diagnostics": {"count": 0, "errors": []},
            })
            return
        sources = self._sources(view)
        dataset_active = bool(
            view.get("dataset", {}).get("runtime", {}).get("active", False)
        )
        if not sources and dataset_active:
            self.status.setText(
                "No configured session is currently available for live collection."
            )
            return
        if view.get("dataset", {}).get("runtime", {}).get("active", False):
            try:
                self.hub._ensure_protocol_insight_service()
            except BaseException as error:
                self._refresh_failed(error)
                return
        self._refresh_revision += 1
        revision = self._refresh_revision
        self._refreshing = True; self.refresh_button.setEnabled(False); self.export_button.setEnabled(False)
        self.status.setText("Loading protocol data...")
        call = self.hub._run_async(
            lambda: self._collect(view, sources),
            lambda result: self._render_if_current(result, revision),
            quiet=True,
            failure=lambda error: self._refresh_failed_if_current(error, revision),
        )
        call.finished.connect(lambda: self._refresh_finished(revision))

    def _render_if_current(self, result, revision):
        if revision == self._refresh_revision:
            ready = getattr(self.hub, "_mark_protocol_insight_sessions_ready", None)
            if ready is not None and result.get("protocol_insight_runtime_id"):
                ready(
                    result.get("protocol_insight_runtime_id"),
                    result.get("runtime_sessions_ready", []),
                )
            self._render(result)

    def _refresh_failed_if_current(self, error, revision):
        if revision == self._refresh_revision:
            self._refresh_failed(error)

    def _refresh_failed(self, error):
        if getattr(self.hub, "_ui_attached", True):
            self.status.setText(f"Insight refresh failed: {str(error).splitlines()[-1]}")
    def _refresh_finished(self, revision=None):
        if revision is not None and revision != self._refresh_revision:
            return
        self._refreshing = False
        self.refresh_button.setEnabled(self._runtime_active(self._view()))
        self.export_button.setEnabled(
            self._last_result is not None or self._checkpoint_available()
        )
        if self._refresh_pending:
            self._refresh_pending = False
            QtCore.QTimer.singleShot(0, self.refresh)
    def _tick(self):
        view = self._view()
        if self._tab_is_active() and self._runtime_active(view) and view.get("live", True):
            self.refresh()

    def _tab_is_active(self):
        active = getattr(self.hub, "_protocol_insights_active", None)
        return bool(active("explore")) if callable(active) else self.isVisible()

    def set_tab_active(self, active):
        """Suspend only frontend polling; the isolated engine keeps running."""
        if not active:
            self.timer.stop()
            self._refresh_revision += 1
            self._refresh_pending = False
            self._refreshing = False
            return
        if self._runtime_active(self._view()):
            self.request_authoritative_snapshot()
            if self._view().get("live", True):
                self.timer.start(self._view().get("refresh_ms", 1000))

    def _plot_snapshot_png(self):
        pixmap = self.plot_container.grab()
        if pixmap.isNull():
            return None
        output = QtCore.QByteArray()
        buffer = QtCore.QBuffer(output)
        if not buffer.open(QtCore.QIODevice.WriteOnly):
            return None
        try:
            return bytes(output) if pixmap.save(buffer, "PNG") else None
        finally:
            buffer.close()

    def _export_current_view(self):
        dataset = self._view().get("dataset", {})
        if not dataset.get("excel", {}).get("enabled", False):
            QtWidgets.QMessageBox.information(
                self, "Create Final Excel", "Enable Excel output for this insight first."
            )
            return
        self.export_button.setEnabled(False)
        self.status.setText("Creating the final aligned-timeline workbook...")
        self._dataset_action_requested("final_export")

    def _protocol_insight_exported(self, exported):
        path = str(exported.get("path", ""))
        checkpoint = exported.get("checkpoint", {})
        recovered = exported.get("source") == "checkpoint"
        source_text = "checkpoint samples" if recovered else "retained samples"
        self.status.setText(
            f"Final Excel created with {int(exported.get('samples', 0)):,} {source_text}."
        )
        self.export_button.setEnabled(
            self._last_result is not None or self._checkpoint_available()
        )
        QtWidgets.QMessageBox.information(
            self, "Final Excel created",
            "The aligned-timeline workbook was created successfully."
            + (
                "\n\nRecovered checkpoint saved: "
                + str(checkpoint.get("saved_at") or checkpoint.get("modified_at") or "unknown")
                if recovered else ""
            )
            + f"\n\n{path}",
        )

    def _protocol_insight_export_failed(self, error):
        self.export_button.setEnabled(
            self._last_result is not None or self._checkpoint_available()
        )
        self.status.setText("Final Excel creation failed")
        QtWidgets.QMessageBox.critical(self, "Final Excel failed", str(error))

    def _available_excel_outputs(self):
        excel = self._view().get("dataset", {}).get("excel", {})
        candidates = []
        raw_directory = str(excel.get("directory", "")).strip()
        if raw_directory:
            directory = Path(raw_directory)
            if not directory.is_absolute():
                directory = Path(PROJECT_ROOT) / directory
            if directory.is_dir():
                candidates.extend(directory.glob("*.xlsx"))
        raw_append = str(excel.get("append_path", "")).strip()
        if raw_append:
            append_path = Path(raw_append)
            if not append_path.is_absolute():
                append_path = Path(PROJECT_ROOT) / append_path
            if append_path.is_file():
                candidates.append(append_path)
        return sorted({path.resolve() for path in candidates}, key=lambda path: path.stat().st_mtime, reverse=True)

    def _transfer_available_outputs(self):
        paths = self._available_excel_outputs()
        if not paths:
            QtWidgets.QMessageBox.information(
                self, "Available Excel outputs", "No Excel workbooks were found in this insight's configured output locations."
            )
            return
        dialog = QtWidgets.QDialog(self); dialog.setWindowTitle("Export Protocol Insight outputs")
        dialog.resize(900, 520); layout = QtWidgets.QVBoxLayout(dialog)
        explanation = QtWidgets.QLabel(
            "Select one or more completed workbooks. Copy keeps the originals; Move relocates them. "
            "Existing destination names are preserved by adding a numeric suffix."
        )
        explanation.setWordWrap(True); layout.addWidget(explanation)
        table = QtWidgets.QTableWidget(len(paths), 4)
        table.setHorizontalHeaderLabels(["Select", "Workbook", "Modified", "Location"])
        table.verticalHeader().setVisible(False); table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        for row, path in enumerate(paths):
            selected = QtWidgets.QTableWidgetItem(); selected.setFlags(selected.flags() | QtCore.Qt.ItemIsUserCheckable)
            selected.setCheckState(QtCore.Qt.Unchecked); selected.setData(QtCore.Qt.UserRole, str(path))
            table.setItem(row, 0, selected)
            table.setItem(row, 1, QtWidgets.QTableWidgetItem(path.name))
            table.setItem(row, 2, QtWidgets.QTableWidgetItem(datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")))
            table.setItem(row, 3, QtWidgets.QTableWidgetItem(str(path.parent)))
        table.clearSelection()
        table.setCurrentCell(-1, -1)
        layout.addWidget(table, 1)

        def checked_paths():
            return [
                Path(table.item(row, 0).data(QtCore.Qt.UserRole))
                for row in range(table.rowCount())
                if table.item(row, 0).checkState() == QtCore.Qt.Checked
            ]

        def set_all_checked(checked):
            state = QtCore.Qt.Checked if checked else QtCore.Qt.Unchecked
            table.blockSignals(True)
            try:
                for row in range(table.rowCount()):
                    table.item(row, 0).setCheckState(state)
            finally:
                table.blockSignals(False)
            update_actions()

        def open_paths(selected_paths):
            if not selected_paths:
                QtWidgets.QMessageBox.information(
                    dialog, "Open outputs", "Select at least one workbook first."
                )
                return
            missing = []
            for selected_path in selected_paths:
                if selected_path.is_file():
                    QtGui.QDesktopServices.openUrl(
                        QtCore.QUrl.fromLocalFile(str(selected_path))
                    )
                else:
                    missing.append(selected_path.name)
            if missing:
                QtWidgets.QMessageBox.warning(
                    dialog, "Output unavailable",
                    "These output files no longer exist:\n\n" + "\n".join(missing),
                )

        def open_locations(selected_paths):
            locations = []
            for selected_path in selected_paths:
                parent = selected_path.parent
                if parent.is_dir() and parent not in locations:
                    locations.append(parent)
            if not locations:
                QtWidgets.QMessageBox.information(
                    dialog, "Open file location", "No available file location was found."
                )
                return
            for location in locations:
                QtGui.QDesktopServices.openUrl(
                    QtCore.QUrl.fromLocalFile(str(location))
                )

        def delete_paths(selected_paths):
            existing = [path for path in selected_paths if path.is_file()]
            if not existing:
                QtWidgets.QMessageBox.information(
                    dialog, "Delete outputs", "Select at least one existing workbook first."
                )
                return
            if QtWidgets.QMessageBox.question(
                dialog, "Delete selected outputs?",
                f"Permanently delete {len(existing):,} selected workbook(s)?\n\n"
                + "\n".join(path.name for path in existing),
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No,
            ) != QtWidgets.QMessageBox.Yes:
                return
            failures = []
            deleted = set()
            for selected_path in existing:
                try:
                    selected_path.unlink()
                    deleted.add(selected_path.resolve())
                except OSError as error:
                    failures.append(f"{selected_path.name}: {error}")
            for row in range(table.rowCount() - 1, -1, -1):
                row_path = Path(table.item(row, 0).data(QtCore.Qt.UserRole))
                if row_path.resolve() in deleted:
                    table.removeRow(row)
            table.clearSelection()
            table.setCurrentCell(-1, -1)
            update_actions()
            if failures:
                QtWidgets.QMessageBox.critical(
                    dialog, "Some outputs could not be deleted", "\n".join(failures)
                )

        action_row = QtWidgets.QHBoxLayout()
        select_all = QtWidgets.QPushButton("Select All")
        clear_selection = QtWidgets.QPushButton("Clear Selection")
        open_selected = QtWidgets.QPushButton("Open Selected")
        delete_selected = QtWidgets.QPushButton("Delete Selected")
        select_all.setToolTip("Check every listed workbook for an action.")
        clear_selection.setToolTip("Uncheck every listed workbook.")
        open_selected.setToolTip("Open every checked workbook in its default application.")
        delete_selected.setToolTip("Permanently delete the checked workbooks after confirmation.")
        select_all.clicked.connect(lambda: set_all_checked(True))
        clear_selection.clicked.connect(lambda: set_all_checked(False))
        open_selected.clicked.connect(lambda: open_paths(checked_paths()))
        delete_selected.clicked.connect(lambda: delete_paths(checked_paths()))
        for button in (select_all, clear_selection, open_selected, delete_selected):
            action_row.addWidget(button)
        action_row.addStretch(1)
        layout.addLayout(action_row)

        table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)

        def show_output_menu(position):
            item = table.itemAt(position)
            if item is None:
                return
            row = item.row()
            clicked_path = Path(table.item(row, 0).data(QtCore.Qt.UserRole))
            menu = QtWidgets.QMenu(table)
            open_one = menu.addAction("Open Output")
            open_location = menu.addAction("Open File Location")
            menu.addSeparator()
            open_many = menu.addAction("Open Selected")
            delete_many = menu.addAction("Delete Selected")
            menu.addSeparator()
            select_everything = menu.addAction("Select All")
            clear_everything = menu.addAction("Clear Selection")
            has_checked = bool(checked_paths())
            open_many.setEnabled(has_checked)
            delete_many.setEnabled(has_checked)
            selected_action = menu.exec_(table.viewport().mapToGlobal(position))
            if selected_action == open_one:
                open_paths([clicked_path])
            elif selected_action == open_location:
                open_locations([clicked_path])
            elif selected_action == open_many:
                open_paths(checked_paths())
            elif selected_action == delete_many:
                delete_paths(checked_paths())
            elif selected_action == select_everything:
                set_all_checked(True)
            elif selected_action == clear_everything:
                set_all_checked(False)

        table.customContextMenuRequested.connect(show_output_menu)
        table.cellDoubleClicked.connect(
            lambda row, _column: open_paths([
                Path(table.item(row, 0).data(QtCore.Qt.UserRole))
            ])
        )
        mode_row = QtWidgets.QHBoxLayout(); copy_radio = QtWidgets.QRadioButton("Copy selected files"); move_radio = QtWidgets.QRadioButton("Move selected files")
        copy_radio.setChecked(True); mode_row.addWidget(copy_radio); mode_row.addWidget(move_radio); mode_row.addStretch(1); layout.addLayout(mode_row)
        destination_row = QtWidgets.QHBoxLayout(); destination = QtWidgets.QLineEdit(); destination.setPlaceholderText("Destination folder")
        browse = QtWidgets.QPushButton("Browse...")
        destination.setToolTip("Existing folder that will receive copied or moved workbooks.")
        browse.setToolTip("Choose the destination folder for copied or moved workbooks.")
        browse.clicked.connect(lambda: destination.setText(QtWidgets.QFileDialog.getExistingDirectory(dialog, "Select destination folder", destination.text() or str(Path.home())) or destination.text()))
        destination_row.addWidget(QtWidgets.QLabel("Destination")); destination_row.addWidget(destination, 1); destination_row.addWidget(browse); layout.addLayout(destination_row)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.button(QtWidgets.QDialogButtonBox.Ok).setText("Copy selected")
        move_radio.toggled.connect(lambda checked: buttons.button(QtWidgets.QDialogButtonBox.Ok).setText("Move selected" if checked else "Copy selected"))
        def update_actions(*_args):
            count = len(checked_paths())
            open_selected.setEnabled(bool(count))
            delete_selected.setEnabled(bool(count))
            clear_selection.setEnabled(bool(count))
            select_all.setEnabled(table.rowCount() > 0 and count < table.rowCount())
            buttons.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(bool(count))

        table.itemChanged.connect(update_actions)
        update_actions()
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); layout.addWidget(buttons)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        selected_paths = checked_paths()
        target_directory = Path(destination.text().strip())
        if not selected_paths or not target_directory.is_dir():
            QtWidgets.QMessageBox.warning(self, "Copy or move outputs", "Select at least one workbook and an existing destination folder.")
            return
        move = move_radio.isChecked()
        self.hub._run_async(
            lambda: self._copy_or_move_outputs(selected_paths, target_directory, move),
            lambda result: QtWidgets.QMessageBox.information(
                self, "Outputs moved" if move else "Outputs copied",
                f"{len(result):,} workbook(s) were {'moved' if move else 'copied'} successfully to:\n\n{target_directory}",
            ),
            quiet=True,
            failure=lambda error: QtWidgets.QMessageBox.critical(self, "Output transfer failed", str(error)),
        )

    @staticmethod
    def _copy_or_move_outputs(paths, destination, move):
        completed = []
        for source in paths:
            target = destination / source.name; suffix = 2
            while target.exists():
                target = destination / f"{source.stem}_{suffix}{source.suffix}"; suffix += 1
            completed.append(Path(shutil.move(str(source), str(target))) if move else Path(shutil.copy2(source, target)))
        return completed

    def _clear_plots(self):
        self._threshold_items = []
        while self.plot_layout.count():
            item = self.plot_layout.takeAt(0); widget = item.widget()
            if widget: widget.deleteLater()
        self._plots = []
        self._plot_widgets = {}
        self._series_items = {}
        self._threshold_items = []
        self._timeline_items = {}
        self._event_items = {}
        self._event_points = {}
        self._category_maps = {}
        self._hover_proxies = []
        self._hover_series = {}
        self._hover_labels = {}
        self._hover_markers = {}
        self._hover_lines = {}
        self._active_hover_x = None
        self._pinned_hovers = []
        self._hover_event_sources = set()
        self._x_axis_config = default_insight_x_axis()
        self._plot_signature = None

    @staticmethod
    def _structure_signature(result):
        plots = []
        for plot_result in result.get("plots", []):
            config = plot_result["config"]
            series = []
            for series_result in plot_result.get("series", []):
                value = series_result["config"]
                plot_options = value.get("plot", {})
                series.append((
                    value.get("id"), value.get("label"),
                    plot_options.get("type", "line"),
                    plot_options.get("color", INSIGHT_COLORS[0]),
                    tuple(sorted(value.get("thresholds", {}).items())),
                ))
            plots.append((
                config.get("id"), config.get("title", "Subplot"),
                config.get("unit", ""), config.get("kind", "plot"),
                tuple(sorted(config.get("timeline", {}).items())),
                tuple(series),
            ))
        x_axis = normalize_insight_x_axis(result.get("x_axis"))
        transform = x_axis.get("transform", {})
        x_signature = (
            x_axis.get("kind"), x_axis.get("label"), x_axis.get("value_type"),
            x_axis.get("timestamp_mode"),
            x_axis.get("path"), x_axis.get("field"), x_axis.get("offset"),
            x_axis.get("length"), x_axis.get("data_type"), x_axis.get("endianness"),
            x_axis.get("signed"), x_axis.get("encoding"),
            transform.get("scale"), transform.get("offset"),
        )
        event_signature = []
        for event_result in result.get("event_markers", []):
            marker = event_result["config"]
            source = marker.get("source", {})
            event_signature.append((
                marker.get("id"), marker.get("label"), marker.get("session_id"),
                tuple(marker.get("message_names", [])), marker.get("direction"),
                marker.get("trigger"), source.get("kind"), source.get("path"),
                source.get("field"), marker.get("operator"),
                marker.get("comparison"),
                tuple(marker.get("target_subplot_ids", [])),
                marker.get("color"), marker.get("symbol"),
            ))
        return (
            result.get("view_id"), x_signature, tuple(plots),
            tuple(event_signature),
        )

    @staticmethod
    def _event_targets_plot(marker, plot_id):
        targets = marker.get("target_subplot_ids", [])
        return not targets or plot_id in targets

    @staticmethod
    def _series_plot_options(series):
        color = series.get("plot", {}).get("color", INSIGHT_COLORS[0])
        style = series.get("plot", {}).get("type", "line")
        options = {
            "name": series["label"],
            "pen": None if style == "scatter" else pg.mkPen(color, width=2),
            "symbol": "o" if style == "scatter" else None,
            "symbolSize": 6,
            "symbolBrush": color,
        }
        if style in {"step", "state"}:
            options["stepMode"] = "left"
        return options

    def _rebuild_plot_structure(self, result, signature):
        self._clear_plots()
        self._global_x_autorange = True
        if pg is None:
            label = QtWidgets.QLabel("Protocol plots require the PyQtGraph package.")
            self.plot_layout.addWidget(label)
            self._plot_signature = signature
            return
        self._x_axis_config = normalize_insight_x_axis(result.get("x_axis"))
        first_plot = None
        for plot_result in result.get("plots", []):
            config = plot_result["config"]
            plot_id = config.get("id")
            axis = (
                pg.DateAxisItem(orientation="bottom")
                if self._x_axis_config["value_type"] == "datetime"
                else pg.AxisItem(orientation="bottom")
            )
            view_box = InsightViewBox()
            plot = pg.PlotWidget(axisItems={"bottom": axis}, viewBox=view_box)
            plot_item = plot.getPlotItem()
            view_box.bind_plot_item(
                plot_item,
                reset_all=self._reset_all_plot_ranges,
                pin_hover=self._pin_current_hover,
                clear_pins=self._clear_pinned_hovers,
                can_pin=lambda: self._active_hover_x is not None,
                has_pins=lambda: bool(self._pinned_hovers),
            )
            plot_item.autoBtn.clicked.connect(self._reset_all_plot_ranges)
            plot.installEventFilter(self)
            plot.viewport().installEventFilter(self)
            self._hover_event_sources.update((plot, plot.viewport()))
            plot.setMinimumHeight(260)
            plot.showGrid(x=True, y=True, alpha=0.25)
            plot.addLegend()
            plot.setTitle(config.get("title", "Subplot"))
            if config.get("kind") == "timeline":
                plot.setLabel("left", "Message lane")
            else:
                plot.setLabel("left", config.get("title", "Value"), units=config.get("unit", "") or None)
            plot.setLabel("bottom", self._x_axis_config["label"])
            if first_plot is None:
                first_plot = plot
            else:
                plot.setXLink(first_plot)
            for series_result in plot_result.get("series", []):
                series = series_result["config"]
                item = plot.plot([], [], **self._series_plot_options(series))
                self._series_items[series.get("id")] = item
                thresholds = series.get("thresholds", {})
                color = series.get("plot", {}).get("color", INSIGHT_COLORS[0])
                for key in ("minimum", "min", "maximum", "max"):
                    if key not in thresholds:
                        continue
                    try: boundary = float(thresholds[key])
                    except (TypeError, ValueError): continue
                    line = pg.PlotDataItem(
                        [], [],
                        pen=pg.mkPen(color, width=1, style=QtCore.Qt.DashLine),
                    )
                    line.setToolTip(
                        f"{series.get('label', 'Series')} {key}: {boundary:g}"
                    )
                    plot.addItem(line)
                    self._threshold_items.append((str(series.get("id")), boundary, line))
            if config.get("kind") == "timeline":
                timeline_item = pg.ScatterPlotItem(
                    name="Messages", symbol="s", size=9, pen=None,
                )
                plot.addItem(timeline_item)
                self._timeline_items[plot_id] = timeline_item
            for event_result in result.get("event_markers", []):
                marker = event_result["config"]
                if not self._event_targets_plot(marker, plot_id):
                    continue
                event_item = pg.ScatterPlotItem(
                    name=marker["label"], symbol=marker["symbol"], size=12,
                    pen=pg.mkPen("#FFFFFF", width=1),
                    brush=pg.mkBrush(marker["color"]),
                )
                event_item.setZValue(9_800)
                plot.addItem(event_item, ignoreBounds=True)
                self._event_items[(marker["id"], plot_id)] = event_item
            hover_label = pg.TextItem(
                anchor=(0, 1), color="#FFFFFF",
                fill=pg.mkBrush(32, 35, 42, 230),
                border=pg.mkPen(145, 150, 165, 220),
            )
            hover_label.setZValue(10_000)
            hover_label.hide()
            plot.addItem(hover_label, ignoreBounds=True)
            hover_marker = pg.ScatterPlotItem(
                size=10, pen=pg.mkPen("#FFFFFF", width=2),
                brush=pg.mkBrush(0, 114, 178, 180),
            )
            hover_marker.setZValue(9_999)
            hover_marker.hide()
            plot.addItem(hover_marker, ignoreBounds=True)
            hover_line = pg.PlotDataItem(
                [], [], pen=pg.mkPen(0, 114, 178, 190, width=1),
            )
            hover_line.setZValue(9_998)
            hover_line.hide()
            plot.addItem(hover_line, ignoreBounds=True)
            proxy = pg.SignalProxy(
                plot.scene().sigMouseMoved, rateLimit=45,
                slot=lambda event, current_id=plot_id: self._hover_moved(current_id, event),
            )
            self.plot_layout.addWidget(plot)
            self._plots.append(plot)
            self._plot_widgets[plot_id] = plot
            self._category_maps[plot_id] = {}
            self._hover_proxies.append(proxy)
            self._hover_series[plot_id] = []
            self._hover_labels[plot_id] = hover_label
            self._hover_markers[plot_id] = hover_marker
            self._hover_lines[plot_id] = hover_line
            plot.getViewBox().sigYRangeChanged.connect(
                lambda _view_box, _y_range, current_id=plot_id:
                self._position_event_markers(current_id)
            )
            view_box.sigRangeChangedManually.connect(
                self._plot_range_changed_manually
            )
        self.plot_layout.addStretch(1)
        if first_plot is not None:
            first_plot.getViewBox().sigXRangeChanged.connect(self._pinned_x_range_changed)
        self._plot_signature = signature

    def _position_event_markers(self, plot_id):
        plot = self._plot_widgets.get(plot_id)
        if plot is None:
            return
        y_min, y_max = plot.getViewBox().viewRange()[1]
        for (marker_id, current_id), item in self._event_items.items():
            if current_id != plot_id:
                continue
            marker_y = self._event_marker_y(plot_id, marker_id, y_min, y_max)
            xs = self._event_points.get((marker_id, plot_id), [])
            item.setData(
                x=xs, y=[marker_y] * len(xs),
                symbol=item.opts.get("symbol", "d"),
                size=item.opts.get("size", 12),
                pen=item.opts.get("pen"),
                brush=item.opts.get("brush"),
            )
            for series in self._hover_series.get(plot_id, []):
                if series.get("event_marker_id") == marker_id:
                    series["y"] = [marker_y] * len(series["x"])

    def _event_marker_y(self, plot_id, marker_id, y_min=None, y_max=None):
        plot = self._plot_widgets.get(plot_id)
        if plot is None:
            return 0.0
        if y_min is None or y_max is None:
            y_min, y_max = plot.getViewBox().viewRange()[1]
        marker_ids = [
            current_marker_id
            for current_marker_id, current_plot_id in self._event_items
            if current_plot_id == plot_id
        ]
        try:
            index = marker_ids.index(marker_id)
        except ValueError:
            index = 0
        offset = 0.04 + min(index, 8) * 0.055
        return y_max - max(1e-12, y_max - y_min) * offset

    def _reset_all_plot_ranges(self, *_args):
        """Apply the built-in A-button operation to every insight subplot."""
        self._global_x_autorange = True
        for plot in self._plots:
            plot_item = plot.getPlotItem()
            plot_item.autoBtn.mode = "auto"
            view_box = plot.getViewBox()
            view_box.enableAutoRange(axis=view_box.YAxis, enable=True)
            view_box.updateAutoRange()
            plot_item.autoBtn.hide()
        self._apply_global_data_range()
        self._update_all_auto_ranges()
        # A manual reset also requests one unthrottled follow-latest update
        # after the next data batch has been applied.
        self._last_autorange_monotonic = 0.0

    def _plot_range_changed_manually(self, axes):
        """Stop global X autoranging only after a real user X interaction."""
        try:
            x_changed = bool(axes[0])
        except (TypeError, IndexError):
            x_changed = True
        if x_changed and not self._applying_global_x_range:
            self._global_x_autorange = False

    def _apply_global_data_range(self):
        """Apply the union of every subplot's data to the shared X owner."""
        if not self._plots or self._display_x_bounds is None:
            return False
        left, right = self._display_x_bounds
        if not all(math.isfinite(value) for value in (left, right)) or right <= left:
            return False
        self._applying_global_x_range = True
        try:
            first_view = self._plots[0].getViewBox()
            first_view.disableAutoRange(axis=first_view.XAxis)
            first_view.setXRange(left, right, padding=0.02)
            # Linked subplots follow this one authoritative range. Assigning
            # every linked view in sequence causes feedback and range drift.
            for plot in self._plots[1:]:
                plot.getViewBox().disableAutoRange(axis=plot.getViewBox().XAxis)
        finally:
            self._applying_global_x_range = False
        return True

    def _update_all_auto_ranges(self):
        """Flush enabled auto ranges even for plots clipped by the scroll area."""
        for plot in self._plots:
            plot.getViewBox().updateAutoRange()

    def _apply_follow_latest_range(self, result):
        """Anchor the shared timestamp axis to the configured full window."""
        suggested = result.get("suggested_x_range")
        if not self._plots or not isinstance(suggested, (list, tuple)) or len(suggested) != 2:
            return False
        left, right = float(suggested[0]), float(suggested[1])
        if not math.isfinite(left) or not math.isfinite(right) or right <= left:
            return False
        first_view = self._plots[0].getViewBox()
        first_view.setXRange(left, right, padding=0)
        for plot in self._plots:
            view_box = plot.getViewBox()
            view_box.enableAutoRange(axis=view_box.YAxis, enable=True)
            view_box.updateAutoRange()
        return True

    def eventFilter(self, watched, event):
        if watched in self._hover_event_sources and event.type() == QtCore.QEvent.Leave:
            QtCore.QTimer.singleShot(0, self._hide_transient_hover_if_outside)
        return super().eventFilter(watched, event)

    def _hide_transient_hover_if_outside(self, global_pos=None):
        global_pos = QtGui.QCursor.pos() if global_pos is None else global_pos
        for plot in self._plots:
            local_pos = plot.mapFromGlobal(global_pos)
            if plot.rect().contains(local_pos):
                return
        self._hide_all_hover()

    def _hide_hover(self, plot_id):
        label = self._hover_labels.get(plot_id)
        marker = self._hover_markers.get(plot_id)
        line = self._hover_lines.get(plot_id)
        if label is not None:
            label.hide()
        if marker is not None:
            marker.hide()
        if line is not None:
            line.hide()

    def _hide_all_hover(self):
        for plot_id in self._plot_widgets:
            self._hide_hover(plot_id)

    def _position_hover_label(self, label, plot, cursor_x, vertical_index=0):
        x_min, x_max = plot.getViewBox().viewRange()[0]
        y_min, y_max = plot.getViewBox().viewRange()[1]
        x_span = max(1e-12, x_max - x_min)
        y_span = max(1e-12, y_max - y_min)
        cursor_at_right = cursor_x > (x_min + x_max) / 2.0
        label.setAnchor((1, 0) if cursor_at_right else (0, 0))
        label_x = cursor_x - x_span * 0.015 if cursor_at_right else cursor_x + x_span * 0.015
        label_x = min(x_max - x_span * 0.01, max(x_min + x_span * 0.01, label_x))
        vertical_offset = 0.03 + min(4, max(0, vertical_index)) * 0.14
        label.setPos(label_x, y_max - y_span * vertical_offset)

    def _pin_current_hover(self):
        cursor_x = self._active_hover_x
        if cursor_x is None:
            return
        if any(abs(item["x"] - cursor_x) <= 0.0005 for item in self._pinned_hovers):
            return
        pinned = {"x": cursor_x, "items": {}}
        for plot_id, plot in self._plot_widgets.items():
            y_min, y_max = plot.getViewBox().viewRange()[1]
            line = pg.PlotDataItem(
                [cursor_x, cursor_x], [y_min, y_max],
                pen=pg.mkPen(230, 159, 0, 220, width=1, style=QtCore.Qt.DashLine),
            )
            line.setZValue(9_900)
            plot.addItem(line, ignoreBounds=True)
            label = pg.TextItem(
                anchor=(0, 0), color="#FFFFFF",
                fill=pg.mkBrush(55, 43, 15, 235),
                border=pg.mkPen(230, 159, 0, 230),
            )
            label.setZValue(9_902)
            plot.addItem(label, ignoreBounds=True)
            marker = pg.ScatterPlotItem(
                size=9, pen=pg.mkPen(230, 159, 0, width=2),
                brush=pg.mkBrush(230, 159, 0, 150),
            )
            marker.setZValue(9_901)
            plot.addItem(marker, ignoreBounds=True)
            pinned["items"][plot_id] = {"line": line, "label": label, "marker": marker}
        self._pinned_hovers.append(pinned)
        self._refresh_pinned_hovers()

    def _remove_pinned_hover(self, pinned):
        for plot_id, items in pinned["items"].items():
            plot = self._plot_widgets.get(plot_id)
            if plot is None:
                continue
            for item in items.values():
                plot.removeItem(item)
        if pinned in self._pinned_hovers:
            self._pinned_hovers.remove(pinned)

    def _clear_pinned_hovers(self):
        for pinned in list(self._pinned_hovers):
            self._remove_pinned_hover(pinned)

    def _hover_time_available(self, cursor_x):
        for series_list in self._hover_series.values():
            for series in series_list:
                xs = series["x"]
                if not xs:
                    continue
                insertion = bisect_left(xs, cursor_x)
                for index in {max(0, insertion - 1), min(len(xs) - 1, insertion)}:
                    if abs(xs[index] - cursor_x) <= 0.0005:
                        return True
        return False

    def _pinned_x_range_changed(self, _view_box, x_range):
        self._prune_pinned_hovers(x_range=x_range)

    def _prune_pinned_hovers(self, x_range=None, require_data=False):
        if not self._pinned_hovers:
            return
        if x_range is None and self._plots:
            x_range = self._plots[0].getViewBox().viewRange()[0]
        for pinned in list(self._pinned_hovers):
            cursor_x = pinned["x"]
            outside = x_range is not None and not (x_range[0] <= cursor_x <= x_range[1])
            missing = require_data and not self._hover_time_available(cursor_x)
            if outside or missing:
                self._remove_pinned_hover(pinned)
        self._refresh_pinned_hovers()

    def _refresh_pinned_hovers(self):
        for pinned_index, pinned in enumerate(self._pinned_hovers):
            cursor_x = pinned["x"]
            for plot_id, plot in self._plot_widgets.items():
                items = pinned["items"].get(plot_id)
                if items is None:
                    continue
                y_min, y_max = plot.getViewBox().viewRange()[1]
                items["line"].setData(
                    [cursor_x, cursor_x], [y_min, y_max],
                )
                samples = self._hover_samples_at_time(plot_id, cursor_x)
                if not samples:
                    items["label"].hide()
                    items["marker"].hide()
                    continue
                items["label"].setText(self._hover_summary_text(cursor_x, samples))
                self._position_hover_label(
                    items["label"], plot, cursor_x, vertical_index=pinned_index,
                )
                items["label"].show()
                items["marker"].setData(
                    [sample["x"] for sample in samples],
                    [sample["y"] for sample in samples],
                )
                items["marker"].show()

    def _nearest_hover_time(self, plot_id, cursor_x):
        nearest_x = None
        nearest_distance = float("inf")
        for series in self._hover_series.get(plot_id, []):
            xs = series["x"]
            if not xs:
                continue
            insertion = bisect_left(xs, cursor_x)
            for index in {max(0, insertion - 1), min(len(xs) - 1, insertion)}:
                distance = abs(xs[index] - cursor_x)
                if distance < nearest_distance:
                    nearest_distance = distance
                    nearest_x = xs[index]
        return nearest_x

    def _hover_samples_at_time(self, plot_id, cursor_x):
        samples = []
        for series in self._hover_series.get(plot_id, []):
            xs = series["x"]
            if not xs:
                continue
            insertion = bisect_left(xs, cursor_x)
            candidates = {max(0, insertion - 1), min(len(xs) - 1, insertion)}
            index = min(candidates, key=lambda candidate: abs(xs[candidate] - cursor_x))
            if (
                (series.get("timeline") or series.get("event"))
                and abs(xs[index] - cursor_x) > 0.0005
            ):
                continue
            samples.append({
                "label": series["label"], "x": xs[index], "y": series["y"][index],
                "value": series["values"][index],
            })
        return samples

    def _nearest_hover_sample(self, plot_id, scene_pos, maximum_distance=18.0):
        plot = self._plot_widgets.get(plot_id)
        if plot is None or not plot.sceneBoundingRect().contains(scene_pos):
            return None
        view_box = plot.getViewBox()
        mouse_x = view_box.mapSceneToView(scene_pos).x()
        nearest = None
        nearest_distance = float("inf")
        for series in self._hover_series.get(plot_id, []):
            xs = series["x"]
            if not xs:
                continue
            insertion = bisect_left(xs, mouse_x)
            for index in {max(0, insertion - 1), min(len(xs) - 1, insertion)}:
                point = view_box.mapViewToScene(QtCore.QPointF(xs[index], series["y"][index]))
                distance = math.hypot(point.x() - scene_pos.x(), point.y() - scene_pos.y())
                if distance < nearest_distance:
                    nearest_distance = distance
                    nearest = {
                        "label": series["label"], "x": xs[index], "y": series["y"][index],
                        "value": series["values"][index], "distance": distance,
                    }
        return nearest if nearest is not None and nearest_distance <= maximum_distance else None

    @staticmethod
    def _hover_text(sample):
        timestamp = local_datetime_from_ns(int(sample["x"] * 1_000_000_000)).strftime(
            "%Y-%m-%d %H:%M:%S.%f"
        )[:-3]
        return f"{sample['label']}\n{timestamp}\nValue: {sample['value']}"

    def _format_x_value(self, value, compact=False):
        if self._x_axis_config.get("value_type") == "datetime":
            pattern = "%H:%M:%S.%f" if compact else "%Y-%m-%d %H:%M:%S.%f"
            return local_datetime_from_ns(int(value * 1_000_000_000)).strftime(pattern)[:-3]
        return f"{float(value):.9g}"

    def _hover_summary_text(self, cursor_x, samples):
        lines = [f"{self._x_axis_config['label']}: {self._format_x_value(cursor_x)}"]
        for sample in samples:
            value = sample["value"]
            if abs(sample["x"] - cursor_x) <= 0.0005:
                lines.append(f"{sample['label']}: {value}")
            else:
                sample_x = self._format_x_value(sample["x"], compact=True)
                lines.append(f"{sample['label']}: {value}  (nearest {sample_x})")
        return "\n".join(lines)

    def _hover_moved(self, plot_id, event):
        scene_pos = event[0] if isinstance(event, tuple) else event
        source_plot = self._plot_widgets.get(plot_id)
        if source_plot is None or not source_plot.sceneBoundingRect().contains(scene_pos):
            self._hide_all_hover()
            return
        cursor_x = source_plot.getViewBox().mapSceneToView(scene_pos).x()
        cursor_x = self._nearest_hover_time(plot_id, cursor_x)
        if cursor_x is None:
            self._active_hover_x = None
            self._hide_all_hover()
            return
        self._active_hover_x = cursor_x

        for current_id, plot in self._plot_widgets.items():
            line = self._hover_lines.get(current_id)
            if line is not None:
                y_min, y_max = plot.getViewBox().viewRange()[1]
                line.setData([cursor_x, cursor_x], [y_min, y_max])
                line.show()
            samples = self._hover_samples_at_time(current_id, cursor_x)
            label = self._hover_labels.get(current_id)
            marker = self._hover_markers.get(current_id)
            if not samples or label is None or marker is None:
                if label is not None:
                    label.hide()
                if marker is not None:
                    marker.hide()
                continue
            label.setText(self._hover_summary_text(cursor_x, samples))
            self._position_hover_label(label, plot, cursor_x)
            label.show()
            marker.setData(
                [sample["x"] for sample in samples],
                [sample["y"] for sample in samples],
            )
            marker.show()

    def _update_category_axis(self, plot_result):
        plot_id = plot_result["config"].get("id")
        category_map = self._category_maps.setdefault(plot_id, {})
        discovered = set(plot_result.get("categories", {}))
        for label in sorted(discovered - set(category_map)):
            category_map[label] = len(category_map)
        plot = self._plot_widgets.get(plot_id)
        if plot is not None and category_map:
            ticks = [(value, label) for label, value in category_map.items()]
            plot.getAxis("left").setTicks([ticks])
        return category_map

    def _update_latest_table(self, rows):
        self.latest.setHorizontalHeaderItem(
            2, QtWidgets.QTableWidgetItem(f"Latest {self._x_axis_config['label']}")
        )
        self.latest.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            display = [
                row[0], row[1],
                self._format_x_value(row[2]) if row[2] is not None else "",
                str(row[3]) if row[3] is not None else "",
                f"{row[4]:,}",
            ]
            for column, value in enumerate(display):
                item = self.latest.item(row_index, column)
                if item is None:
                    item = QtWidgets.QTableWidgetItem()
                    self.latest.setItem(row_index, column, item)
                if item.text() != value:
                    item.setText(value)

    def _render(self, result):
        if not getattr(self.hub, "_ui_attached", True):
            return
        result_view_id = result.get("view_id")
        if result_view_id and result_view_id != self._view().get("id"):
            return
        self._last_result = result
        if not self._refreshing:
            self.export_button.setEnabled(True)
        self._x_axis_config = normalize_insight_x_axis(result.get("x_axis"))
        signature = self._structure_signature(result)
        structure_changed = signature != self._plot_signature
        if structure_changed:
            self._rebuild_plot_structure(result, signature)
        if pg is None:
            return
        self._event_points = {}
        all_x_values = []
        latest_rows = []
        for plot_result in result.get("plots", []):
            config = plot_result["config"]
            plot_id = config.get("id")
            categories = self._update_category_axis(plot_result)
            hover_series = []
            if config.get("kind") == "timeline":
                timeline_result = plot_result.get("timeline", {})
                points = timeline_result.get("points", [])
                xs = [point[0] for point in points]
                all_x_values.extend(xs)
                ys = [categories.get(point[4], point[1]) for point in points]
                brushes = [
                    pg.mkBrush(
                        "#0072B2" if point[2].get("direction") == "RX"
                        else "#D55E00" if point[2].get("direction") == "TX"
                        else "#999999"
                    )
                    for point in points
                ]
                item = self._timeline_items.get(plot_id)
                if item is not None:
                    item.setData(
                        x=xs, y=ys, brush=brushes, pen=None,
                        symbol="s", size=9,
                    )
                lane_points = {}
                for point, y_value in zip(points, ys):
                    lane_points.setdefault(point[4], []).append((point, y_value))
                for lane, samples in lane_points.items():
                    hover_series.append({
                        "label": lane,
                        "x": [sample[0][0] for sample in samples],
                        "y": [sample[1] for sample in samples],
                        "values": [sample[0][3] for sample in samples],
                        "timeline": True,
                    })
                last = timeline_result.get("last")
                latest_rows.append((
                    config.get("title", ""), "Messages",
                    last[0] if last else None,
                    last[3] if last else None,
                    len(points),
                ))
            for series_result in plot_result.get("series", []):
                series = series_result["config"]; points = series_result["points"]
                xs = [point[0] for point in points]
                all_x_values.extend(xs)
                ys = [
                    categories.get(point[3], point[1])
                    if isinstance(point[3], str) else point[1]
                    for point in points
                ]
                item = self._series_items.get(series.get("id"))
                if item is not None:
                    item.setData(xs, ys)
                for threshold_series_id, boundary, threshold_item in self._threshold_items:
                    if threshold_series_id != str(series.get("id")):
                        continue
                    if xs:
                        threshold_item.setData(
                            [min(xs), max(xs)], [boundary, boundary],
                        )
                    else:
                        threshold_item.setData([], [])
                hover_series.append({
                    "label": series["label"], "x": xs, "y": ys,
                    "values": [point[3] for point in points],
                })
                last = series_result.get("last")
                latest_rows.append((config.get("title", ""), series["label"], last[0] if last else None, last[3] if last else None, len(points)))
            self._hover_series[plot_id] = hover_series
        for event_result in result.get("event_markers", []):
            marker = event_result["config"]
            points = event_result.get("points", [])
            xs = [point[0] for point in points]
            all_x_values.extend(xs)
            last = points[-1] if points else None
            latest_rows.append((
                "Event overlay", marker["label"],
                last[0] if last else None,
                last[2] if last else None,
                len(points),
            ))
            for plot_id, plot in self._plot_widgets.items():
                if not self._event_targets_plot(marker, plot_id):
                    continue
                marker_y = self._event_marker_y(plot_id, marker["id"])
                item = self._event_items.get((marker["id"], plot_id))
                if item is not None:
                    item.setData(
                        x=xs, y=[marker_y] * len(xs),
                        symbol=marker["symbol"], size=12,
                        pen=pg.mkPen("#FFFFFF", width=1),
                        brush=pg.mkBrush(marker["color"]),
                    )
                self._event_points[(marker["id"], plot_id)] = xs
                self._hover_series.setdefault(plot_id, []).append({
                    "label": marker["label"],
                    "x": xs,
                    "y": [marker_y] * len(xs),
                    "values": [point[2] for point in points],
                    "event": True,
                    "event_marker_id": marker["id"],
                })
        finite_x = [float(value) for value in all_x_values if math.isfinite(float(value))]
        if finite_x:
            left, right = min(finite_x), max(finite_x)
            if right <= left:
                span = 0.5 if self._x_axis_config.get("value_type") == "datetime" else max(0.5, abs(left) * 0.01)
                left -= span; right += span
            self._display_x_bounds = (left, right)
        else:
            self._display_x_bounds = None
        display = self._view().get("display", {})
        now = time.monotonic()
        follow_latest_due = (
            display.get("follow_latest", True)
            and now - self._last_autorange_monotonic >= 1.0
        )
        following = bool(display.get("follow_latest", True))
        should_range = (
            structure_changed or follow_latest_due
            if following else self._global_x_autorange
        )
        if should_range:
            if following:
                ranged = self._apply_follow_latest_range(result)
            elif self._global_x_autorange:
                ranged = self._apply_global_data_range()
            else:
                ranged = False
            if not ranged:
                self._update_all_auto_ranges()
            self._last_autorange_monotonic = now
        self._prune_pinned_hovers(require_data=True)
        self._update_latest_table(latest_rows)
        omitted = int(result.get("omitted_samples", 0))
        omitted_text = f" | {omitted:,} events omitted by row limit" if omitted else ""
        diagnostics = result.get("processor_diagnostics", {})
        processor_errors = int(diagnostics.get("count", 0))
        processor_text = (
            f" | {processor_errors:,} processor errors" if processor_errors else ""
        )
        self.status.setText(
            f"{int(result.get('records', 0)):,} message rows | "
            f"{int(result.get('samples', 0)):,} plotted samples"
            f"{omitted_text}{processor_text} | synchronized X axis"
        )
        self.status.setToolTip("\n".join(diagnostics.get("errors", [])))
        state_getter = getattr(self.hub, "_protocol_insight_state", None)
        if state_getter is not None:
            state, detail = state_getter(self._view())
            if self._view().get("dataset", {}).get("preview"):
                detail = (detail + "; " if detail else "") + "retained-data preview shown"
            self.dataset_editor.set_runtime_state(state, detail)

    def suspend(self):
        self.timer.stop()

    def resume(self):
        if self._runtime_active(self._view()) and self._tab_is_active():
            self.request_authoritative_snapshot()
            self.timer.start(self._view().get("refresh_ms", 1000))

    def shutdown(self):
        self.suspend()
