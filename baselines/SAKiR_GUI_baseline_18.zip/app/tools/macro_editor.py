import copy
from PyQt5 import QtCore, QtWidgets

from app.path_utils import abs_to_rel_project, is_abs_path, norm_slash, rel_to_abs_project
from app.tools.macro_engine import DEFAULT_MACRO_CONFIG, normalize_macro_config, safe_get
from app.utils import PROJECT_ROOT


class FilePathRow(QtWidgets.QWidget):
    def __init__(self, path="", relative=False, parent=None):
        super().__init__(parent)
        self.path_edit = QtWidgets.QLineEdit(norm_slash(path))
        self.browse_btn = QtWidgets.QToolButton()
        self.browse_btn.setText("...")
        self.browse_btn.setFixedWidth(24)
        self.relative_cb = QtWidgets.QCheckBox("Relative to Project Root")
        self.relative_cb.setChecked(bool(relative))
        self.relative_cb.setToolTip(
            "If enabled, this file is stored relative to PROJECT_ROOT.\n"
            "This matches the FTP server home-directory path behavior.\n\n"
            f"Current PROJECT_ROOT:\n{PROJECT_ROOT}"
        )

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        layout.addWidget(self.path_edit, 1)
        layout.addWidget(self.browse_btn)
        layout.addWidget(self.relative_cb)

        self.browse_btn.clicked.connect(self._browse)
        self.relative_cb.toggled.connect(self._refresh_display)
        QtCore.QTimer.singleShot(0, self._refresh_display)

    def path(self):
        return norm_slash(self.path_edit.text())

    def is_relative(self):
        return self.relative_cb.isChecked()

    def _browse(self):
        start = self.path()
        if self.is_relative() and start and not is_abs_path(start):
            start = rel_to_abs_project(start)
        if not start:
            start = PROJECT_ROOT

        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", start, "All Files (*.*)")
        if not file_path:
            return

        file_path = norm_slash(file_path)
        if self.is_relative():
            rel = abs_to_rel_project(file_path)
            if is_abs_path(rel):
                self.relative_cb.setChecked(False)
                self.path_edit.setText(rel)
            else:
                self.path_edit.setText(rel)
        else:
            self.path_edit.setText(file_path)

    def _refresh_display(self):
        text = self.path()
        if not text:
            return
        if self.is_relative():
            if is_abs_path(text):
                self.path_edit.setText(abs_to_rel_project(text))
        else:
            if not is_abs_path(text):
                self.path_edit.setText(norm_slash(rel_to_abs_project(text)))


class PreprocessStepWidget(QtWidgets.QWidget):
    def __init__(self, data=None, parent=None):
        super().__init__(parent)
        self.setObjectName("MacroStep")
        data = data or {}
        self.file_row = FilePathRow(data.get("file", ""), data.get("file_relative", False))
        self.key_edit = QtWidgets.QLineEdit(data.get("key", ""))
        self.key_edit.setPlaceholderText("XML tag or attribute name")
        self.value_edit = QtWidgets.QLineEdit(data.get("value", ""))
        self.value_edit.setPlaceholderText("Replacement value")
        self.remove_btn = QtWidgets.QToolButton()
        self.remove_btn.setText("X")
        self.remove_btn.setToolTip("Remove this preprocessing step")
        self.remove_btn.setFixedSize(24, 24)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 10)
        layout.setSpacing(8)

        header_widget = QtWidgets.QWidget()
        header_widget.setObjectName("MacroStepHeader")
        header = QtWidgets.QHBoxLayout(header_widget)
        header.setContentsMargins(10, 6, 8, 6)
        title = QtWidgets.QLabel("XML replacement")
        title.setStyleSheet("font-weight: bold;")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.remove_btn)
        layout.addWidget(header_widget)

        body = QtWidgets.QWidget()
        body.setObjectName("MacroStepBody")
        form = QtWidgets.QFormLayout()
        form.setContentsMargins(10, 2, 10, 0)
        form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        form.setLabelAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        form.setHorizontalSpacing(8)
        form.setVerticalSpacing(6)
        form.addRow("File", self.file_row)

        pair = QtWidgets.QWidget()
        pair_layout = QtWidgets.QHBoxLayout(pair)
        pair_layout.setContentsMargins(0, 0, 0, 0)
        pair_layout.setSpacing(8)
        pair_layout.addWidget(self.key_edit, 1)
        pair_layout.addWidget(self.value_edit, 1)
        form.addRow("Key / Value", pair)
        body.setLayout(form)
        layout.addWidget(body)

    def get_data(self):
        return {
            "file": self.file_row.path(),
            "file_relative": self.file_row.is_relative(),
            "key": self.key_edit.text().strip(),
            "value": self.value_edit.text().strip()
        }


class PrecheckStepWidget(QtWidgets.QWidget):
    def __init__(self, data=None, parent=None):
        super().__init__(parent)
        self.setObjectName("MacroStep")
        data = data or {}
        self.type_combo = QtWidgets.QComboBox()
        self.type_combo.addItems(["xml", "binary"])
        self.type_combo.setCurrentText(data.get("type", "xml"))

        self.file_row = FilePathRow(data.get("file", ""), data.get("file_relative", False))
        self.key_edit = QtWidgets.QLineEdit(data.get("key", ""))
        self.key_edit.setPlaceholderText("XML tag name")
        self.index_spin = QtWidgets.QSpinBox()
        self.index_spin.setRange(0, 10_000_000)
        self.index_spin.setValue(int(data.get("index", 0) or 0))
        self.length_spin = QtWidgets.QSpinBox()
        self.length_spin.setRange(1, 1024)
        self.length_spin.setValue(int(data.get("length", 1) or 1))
        self.endian_combo = QtWidgets.QComboBox()
        self.endian_combo.addItems(["little", "big"])
        self.endian_combo.setCurrentText(data.get("endianness", "little"))
        self.dtype_combo = QtWidgets.QComboBox()
        self.dtype_combo.addItems(["uint", "int", "float"])
        self.dtype_combo.setCurrentText(data.get("dtype", "uint"))
        self.expected_edit = QtWidgets.QLineEdit(str(data.get("expected", "")))
        self.expected_edit.setPlaceholderText("Optional expected value")
        self.remove_btn = QtWidgets.QToolButton()
        self.remove_btn.setText("X")
        self.remove_btn.setToolTip("Remove this precheck step")
        self.remove_btn.setFixedSize(24, 24)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 10)
        layout.setSpacing(8)

        header_widget = QtWidgets.QWidget()
        header_widget.setObjectName("MacroStepHeader")
        header = QtWidgets.QHBoxLayout(header_widget)
        header.setContentsMargins(10, 6, 8, 6)
        title = QtWidgets.QLabel("Inspection")
        title.setStyleSheet("font-weight: bold;")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(QtWidgets.QLabel("Type"))
        header.addWidget(self.type_combo)
        header.addWidget(self.remove_btn)
        layout.addWidget(header_widget)

        body = QtWidgets.QWidget()
        body.setObjectName("MacroStepBody")
        form = QtWidgets.QFormLayout()
        form.setContentsMargins(10, 2, 10, 0)
        form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        form.setLabelAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        form.setHorizontalSpacing(8)
        form.setVerticalSpacing(6)
        form.addRow("File", self.file_row)

        self.detail_stack = QtWidgets.QStackedWidget()
        self.xml_page = QtWidgets.QWidget()
        xml_form = QtWidgets.QFormLayout(self.xml_page)
        xml_form.setContentsMargins(0, 0, 0, 0)
        xml_form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        xml_form.addRow("XML Key", self.key_edit)

        self.binary_page = QtWidgets.QWidget()
        binary_grid = QtWidgets.QGridLayout(self.binary_page)
        binary_grid.setContentsMargins(0, 0, 0, 0)
        binary_grid.setHorizontalSpacing(8)
        binary_grid.setVerticalSpacing(6)
        binary_grid.addWidget(QtWidgets.QLabel("Offset"), 0, 0)
        binary_grid.addWidget(self.index_spin, 0, 1)
        binary_grid.addWidget(QtWidgets.QLabel("Length"), 0, 2)
        binary_grid.addWidget(self.length_spin, 0, 3)
        binary_grid.addWidget(QtWidgets.QLabel("Endian"), 1, 0)
        binary_grid.addWidget(self.endian_combo, 1, 1)
        binary_grid.addWidget(QtWidgets.QLabel("Data Type"), 1, 2)
        binary_grid.addWidget(self.dtype_combo, 1, 3)
        binary_grid.setColumnStretch(1, 1)
        binary_grid.setColumnStretch(3, 1)

        self.detail_stack.addWidget(self.xml_page)
        self.detail_stack.addWidget(self.binary_page)
        form.addRow("Read", self.detail_stack)
        form.addRow("Expected", self.expected_edit)
        body.setLayout(form)
        layout.addWidget(body)

        self.type_combo.currentTextChanged.connect(self._update_visibility)
        self._update_visibility(self.type_combo.currentText())

    def _update_visibility(self, type_):
        self.detail_stack.setCurrentWidget(self.xml_page if type_ == "xml" else self.binary_page)

    def get_data(self):
        data = {
            "type": self.type_combo.currentText(),
            "file": self.file_row.path(),
            "file_relative": self.file_row.is_relative(),
        }
        if data["type"] == "xml":
            data["key"] = self.key_edit.text().strip()
        else:
            data["index"] = int(self.index_spin.value())
            data["length"] = int(self.length_spin.value())
            data["endianness"] = self.endian_combo.currentText()
            data["dtype"] = self.dtype_combo.currentText()
        expected = self.expected_edit.text().strip()
        if expected:
            data["expected"] = expected
        return data


class MacroEditorDialog(QtWidgets.QDialog):
    macros_saved = QtCore.pyqtSignal(object, bool)

    def __init__(self, macros_config=None, parent=None, transport_name="Telnet"):
        super().__init__(parent)
        self.transport_name = transport_name
        self.setWindowTitle(f"{self.transport_name} Macro Editor")
        self.resize(1050, 650)
        self.config = normalize_macro_config(copy.deepcopy(macros_config or DEFAULT_MACRO_CONFIG))
        self.current_item = None
        self.preprocess_steps_widgets = []
        self.precheck_steps_widgets = []
        self._build_ui()

    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        board_group = QtWidgets.QGroupBox("Macro Board")
        board_layout = QtWidgets.QFormLayout(board_group)
        board_layout.setContentsMargins(10, 10, 10, 10)
        self.board_layout_edit = QtWidgets.QLineEdit(self.config.get("layout", "3x3"))
        self.board_layout_edit.setPlaceholderText("Rows x columns, for example 3x3")
        self.board_layout_edit.editingFinished.connect(self._sync_board_layout)
        board_layout.addRow("Layout (rxc)", self.board_layout_edit)
        root.addWidget(board_group)

        split = QtWidgets.QHBoxLayout()
        split.setSpacing(10)

        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setMinimumWidth(250)
        self.tree.itemClicked.connect(self._on_item_selected)
        split.addWidget(self.tree, 2)

        self.editor_scroll = QtWidgets.QScrollArea()
        self.editor_scroll.setWidgetResizable(True)
        self.editor_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.editor = QtWidgets.QWidget()
        self.editor.setObjectName("MacroEditor")
        self.form = QtWidgets.QFormLayout(self.editor)
        self.form.setContentsMargins(8, 0, 8, 8)
        self.form.setSpacing(8)
        self.form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self.editor_scroll.setWidget(self.editor)
        split.addWidget(self.editor_scroll, 5)

        root.addLayout(split, 1)

        buttons = QtWidgets.QHBoxLayout()
        for text, handler in [
            ("Add Button", self._add_button),
            ("Add Command", self._add_command),
            ("Delete Selected", self._delete_selected),
        ]:
            btn = QtWidgets.QPushButton(text)
            btn.clicked.connect(handler)
            buttons.addWidget(btn)

        buttons.addStretch()
        apply_btn = QtWidgets.QPushButton("Apply")
        save_btn = QtWidgets.QPushButton("Save")
        close_btn = QtWidgets.QPushButton("Close")
        apply_btn.clicked.connect(lambda: self._emit_save(True, close=False))
        save_btn.clicked.connect(lambda: self._emit_save(True, close=True))
        close_btn.clicked.connect(self.reject)
        buttons.addWidget(apply_btn)
        buttons.addWidget(save_btn)
        buttons.addWidget(close_btn)
        root.addLayout(buttons)
        self.setStyleSheet("""
            QWidget#MacroEditor QGroupBox {
                font-weight: bold;
                border: 1px solid #c8ced6;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 10px;
                background: #fafbfc;
            }
            QWidget#MacroEditor QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }
            QWidget#MacroStep {
                border: 1px solid #b8c2cc;
                border-radius: 8px;
                background: #ffffff;
                margin-top: 8px;
            }
            QWidget#MacroCommand {
                border: 1px solid #b8c2cc;
                border-radius: 8px;
                background: #ffffff;
                margin-top: 8px;
            }
            QWidget#MacroStepHeader {
                background: #eef2f6;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                border-bottom: 1px solid #d4dbe3;
            }
            QWidget#MacroStepBody {
                background: #ffffff;
                border-bottom-left-radius: 8px;
                border-bottom-right-radius: 8px;
            }
            QTreeWidget {
                border: 1px solid #c8ced6;
                border-radius: 6px;
            }
        """)

        self._populate_tree()

    def _populate_tree(self):
        self.tree.clear()
        for button in self.config.get("buttons", []):
            button_item = QtWidgets.QTreeWidgetItem([button.get("name", "Macro")])
            button_item.setData(0, QtCore.Qt.UserRole, button)
            self.tree.addTopLevelItem(button_item)
            for command in button.get("commands", []):
                command_item = QtWidgets.QTreeWidgetItem([command.get("command", "command")])
                command_item.setData(0, QtCore.Qt.UserRole, command)
                button_item.addChild(command_item)
        self.tree.expandAll()
        self._show_empty_form()

    def _clear_form(self):
        while self.form.rowCount():
            self.form.removeRow(0)
        self.preprocess_steps_widgets = []
        self.precheck_steps_widgets = []

    def _on_item_selected(self, item):
        self._sync_current_item()
        self.current_item = item
        self._clear_form()
        parent = item.parent()
        data = item.data(0, QtCore.Qt.UserRole) or {}
        if parent is None:
            self._build_button_form(data)
        else:
            self._build_command_form(data)

    def _show_empty_form(self):
        self.current_item = None
        self._clear_form()
        hint = QtWidgets.QLabel("Select a macro button or command to edit its details.")
        hint.setStyleSheet("color: #667085; padding: 12px;")
        hint.setWordWrap(True)
        self.form.addRow(hint)

    def _sync_board_layout(self):
        self.config["layout"] = self.board_layout_edit.text().strip() or "3x3"

    def _build_button_form(self, data):
        style = data.get("style", {}) or {}
        self.name_edit = QtWidgets.QLineEdit(data.get("name", "Macro"))
        self.position_edit = QtWidgets.QLineEdit(data.get("position", ""))
        self.width_spin = QtWidgets.QSpinBox()
        self.width_spin.setRange(10, 1000)
        self.width_spin.setValue(int(style.get("width", 100) or 100))
        self.height_spin = QtWidgets.QSpinBox()
        self.height_spin.setRange(10, 1000)
        self.height_spin.setValue(int(style.get("height", 40) or 40))
        self.color_edit = QtWidgets.QLineEdit(style.get("color", ""))
        self.text_color_edit = QtWidgets.QLineEdit(style.get("text_color", ""))
        self.icon_edit = QtWidgets.QLineEdit(style.get("icon", ""))
        self.password_edit = QtWidgets.QLineEdit(data.get("password", ""))
        self.password_edit.setEchoMode(QtWidgets.QLineEdit.Password)

        general = QtWidgets.QGroupBox("Button")
        general_form = QtWidgets.QFormLayout(general)
        general_form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        general_form.addRow("Name", self.name_edit)
        general_form.addRow("Position (rxc)", self.position_edit)
        general_form.addRow("Width", self.width_spin)
        general_form.addRow("Height", self.height_spin)
        general_form.addRow("Background Color", self.color_edit)
        general_form.addRow("Text Color", self.text_color_edit)
        general_form.addRow("Icon Path", self.icon_edit)
        general_form.addRow("Password", self.password_edit)
        self.form.addRow(general)

        preprocessing = data.get("preprocessing", {"enabled": False, "steps": []}) or {}
        self.preprocess_box = self._steps_box(
            "XML Preprocessing",
            "Add Preprocess Step",
            self._add_preprocess_step,
            bool(preprocessing.get("enabled", False))
        )
        self.form.addRow(self.preprocess_box)
        for step in preprocessing.get("steps", []):
            self._add_preprocess_step(step)

        precheck = data.get("precheck", {"enabled": False, "steps": []}) or {}
        self.precheck_box = self._steps_box(
            "Precheck",
            "Add Precheck Step",
            self._add_precheck_step,
            bool(precheck.get("enabled", False))
        )
        self.form.addRow(self.precheck_box)
        for step in precheck.get("steps", []):
            self._add_precheck_step(step)

    def _steps_box(self, title, button_text, handler, checked):
        box = QtWidgets.QGroupBox(title)
        box.setCheckable(True)
        box.setChecked(bool(checked))
        layout = QtWidgets.QVBoxLayout(box)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(6)
        steps = QtWidgets.QVBoxLayout()
        steps.setContentsMargins(0, 0, 0, 0)
        steps.setSpacing(6)
        steps.addStretch()
        add_btn = QtWidgets.QPushButton(button_text)
        add_btn.clicked.connect(lambda: handler())
        layout.addLayout(steps)
        layout.addWidget(add_btn)
        box.steps_layout = steps
        box.add_button = add_btn
        box.toggled.connect(add_btn.setEnabled)
        add_btn.setEnabled(box.isChecked())
        return box

    def _add_preprocess_step(self, data=None):
        widget = PreprocessStepWidget(data)
        self.preprocess_box.steps_layout.insertWidget(self.preprocess_box.steps_layout.count() - 1, widget)
        self.preprocess_steps_widgets.append(widget)
        widget.remove_btn.clicked.connect(lambda: self._remove_step(widget, self.preprocess_steps_widgets))

    def _add_precheck_step(self, data=None):
        widget = PrecheckStepWidget(data)
        self.precheck_box.steps_layout.insertWidget(self.precheck_box.steps_layout.count() - 1, widget)
        self.precheck_steps_widgets.append(widget)
        widget.remove_btn.clicked.connect(lambda: self._remove_step(widget, self.precheck_steps_widgets))

    def _remove_step(self, widget, collection):
        if widget in collection:
            collection.remove(widget)
        widget.setParent(None)
        widget.deleteLater()

    def _build_command_form(self, data):
        self.command_edit = QtWidgets.QLineEdit(data.get("command", ""))
        self.command_edit.setPlaceholderText(f"Command to send over the active {self.transport_name} connection")
        self.expected_edit = QtWidgets.QLineEdit(data.get("expected_return", ""))
        self.expected_edit.setPlaceholderText("Optional response to wait for")
        self.match_combo = QtWidgets.QComboBox()
        self.match_combo.addItems(["substring", "regex", "binary"])
        self.match_combo.setCurrentText(data.get("match_type", "substring"))
        self.timeout_spin = QtWidgets.QSpinBox()
        self.timeout_spin.setRange(1, 120)
        self.timeout_spin.setValue(int(data.get("timeout", 3) or 3))

        card = QtWidgets.QWidget()
        card.setObjectName("MacroCommand")
        card_layout = QtWidgets.QVBoxLayout(card)
        card_layout.setContentsMargins(0, 0, 0, 10)
        card_layout.setSpacing(8)

        header = QtWidgets.QWidget()
        header.setObjectName("MacroStepHeader")
        header_layout = QtWidgets.QHBoxLayout(header)
        header_layout.setContentsMargins(10, 6, 8, 6)
        title = QtWidgets.QLabel(f"{self.transport_name} command")
        title.setStyleSheet("font-weight: bold;")
        header_layout.addWidget(title)
        header_layout.addStretch()
        card_layout.addWidget(header)

        body = QtWidgets.QWidget()
        body.setObjectName("MacroStepBody")
        body_form = QtWidgets.QFormLayout(body)
        body_form.setContentsMargins(10, 2, 10, 0)
        body_form.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        body_form.setLabelAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        body_form.setHorizontalSpacing(8)
        body_form.setVerticalSpacing(6)
        body_form.addRow("Command", self.command_edit)
        body_form.addRow("Expected", self.expected_edit)

        match_row = QtWidgets.QWidget()
        match_layout = QtWidgets.QHBoxLayout(match_row)
        match_layout.setContentsMargins(0, 0, 0, 0)
        match_layout.setSpacing(8)
        match_layout.addWidget(self.match_combo, 1)
        match_layout.addWidget(QtWidgets.QLabel("Timeout"))
        match_layout.addWidget(self.timeout_spin)
        match_layout.addWidget(QtWidgets.QLabel("seconds"))
        body_form.addRow("Match", match_row)

        card_layout.addWidget(body)
        self.form.addRow(card)

    def _sync_current_item(self):
        item = self.current_item
        if item is None:
            self._sync_board_layout()
            return
        self._sync_board_layout()
        parent = item.parent()
        data = item.data(0, QtCore.Qt.UserRole) or {}
        if parent is None and hasattr(self, "name_edit"):
            data["name"] = self.name_edit.text().strip() or "Macro"
            data["position"] = self.position_edit.text().strip()
            data["style"] = {
                "width": int(self.width_spin.value()),
                "height": int(self.height_spin.value()),
                "color": self.color_edit.text().strip(),
                "text_color": self.text_color_edit.text().strip(),
                "icon": self.icon_edit.text().strip(),
            }
            data["password"] = self.password_edit.text().strip()
            data["preprocessing"] = {
                "enabled": self.preprocess_box.isChecked(),
                "steps": [data for w in self.preprocess_steps_widgets for data in [w.get_data()] if data.get("file") and data.get("key")]
            }
            data["precheck"] = {
                "enabled": self.precheck_box.isChecked(),
                "steps": [data for w in self.precheck_steps_widgets for data in [w.get_data()] if data.get("file")]
            }
            item.setText(0, data["name"])
        elif parent is not None and hasattr(self, "command_edit"):
            data["command"] = self.command_edit.text()
            data["expected_return"] = self.expected_edit.text()
            data["match_type"] = self.match_combo.currentText()
            data["timeout"] = int(self.timeout_spin.value())
            item.setText(0, data["command"] or "command")
        item.setData(0, QtCore.Qt.UserRole, data)

    def _tree_to_config(self):
        self._sync_current_item()
        self._sync_board_layout()
        config = {"layout": self.config.get("layout", "3x3"), "buttons": []}
        for i in range(self.tree.topLevelItemCount()):
            button_item = self.tree.topLevelItem(i)
            button_data = button_item.data(0, QtCore.Qt.UserRole) or {}
            button = {
                "name": safe_get(button_data, "name", button_item.text(0)),
                "position": safe_get(button_data, "position", ""),
                "style": safe_get(button_data, "style", {}),
                "password": safe_get(button_data, "password", ""),
                "preprocessing": safe_get(button_data, "preprocessing", {"enabled": False, "steps": []}),
                "precheck": safe_get(button_data, "precheck", {"enabled": False, "steps": []}),
                "commands": []
            }
            for j in range(button_item.childCount()):
                command_item = button_item.child(j)
                command_data = command_item.data(0, QtCore.Qt.UserRole) or {}
                button["commands"].append({
                    "command": safe_get(command_data, "command", command_item.text(0)),
                    "expected_return": safe_get(command_data, "expected_return", ""),
                    "match_type": safe_get(command_data, "match_type", "substring"),
                    "timeout": safe_get(command_data, "timeout", 3),
                })
            config["buttons"].append(button)
        return normalize_macro_config(config)

    def _emit_save(self, apply_now, close):
        self.config = self._tree_to_config()
        self.macros_saved.emit(self.config, apply_now)
        if close:
            self.accept()

    def _add_button(self):
        self._sync_current_item()
        data = {"name": "new_button", "style": {"width": 100, "height": 40}, "commands": []}
        item = QtWidgets.QTreeWidgetItem([data["name"]])
        item.setData(0, QtCore.Qt.UserRole, data)
        self.tree.addTopLevelItem(item)
        self.tree.setCurrentItem(item)
        self._on_item_selected(item)

    def _add_command(self):
        self._sync_current_item()
        item = self.tree.currentItem()
        if item is None:
            return
        if item.parent() is not None:
            item = item.parent()
        data = {"command": "echo hello", "expected_return": "", "match_type": "substring", "timeout": 3}
        child = QtWidgets.QTreeWidgetItem([data["command"]])
        child.setData(0, QtCore.Qt.UserRole, data)
        item.addChild(child)
        item.setExpanded(True)
        self.tree.setCurrentItem(child)
        self._on_item_selected(child)

    def _delete_selected(self):
        item = self.tree.currentItem()
        if item is None:
            return
        parent = item.parent()
        if parent is None:
            self.tree.takeTopLevelItem(self.tree.indexOfTopLevelItem(item))
        else:
            parent.removeChild(item)
        self.current_item = None
        self._show_empty_form()


MacroConfigEditorDialog = MacroEditorDialog
