"""Out-of-process Application Globals explorer.

The main process owns live Python objects.  The spawned Qt process receives
only bounded primitive descriptors and requests data lazily through a duplex
pipe.  This module intentionally has no callback-facing public API.
"""

from __future__ import annotations

import hashlib
import multiprocessing
import os
import threading
import time
import traceback
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np
import pandas as pd
from pandas.io.formats.style import Styler
from PyQt5 import QtCore, QtGui, QtWidgets

from app.runtime_globals import RuntimeGlobals
from app.startup import apply_app_icon, set_windows_app_id
from app.tools.variable_explorer import (
    DEFAULT_ADAPTERS,
    MAX_REPR,
    PAGE_SIZE,
    EditConflictError,
    ExplorerError,
    PathStep,
    ValuePath,
    apply_copy_on_write,
    can_edit_value,
    editable_text,
    human_size,
    is_editable_path,
    parse_edited_value,
    resolve_path,
    safe_attributes,
    safe_details_repr,
    safe_repr,
    value_fingerprint,
    value_info,
    value_summary,
    _safe_len,
    _safe_size,
)


PROTOCOL_VERSION = 1
MAX_MESSAGE_BYTES = 2 * 1024 * 1024
MAX_TABLE_CELLS = 2_000
MAX_HANDLES = 8_000
REQUESTS_PER_TICK = 16
DISPLAY_ROLE = QtCore.Qt.UserRole + 50


def _fingerprint_token(value: Any) -> str:
    """Return a bounded primitive token without collapsing fingerprint tuples."""
    fingerprint = value_fingerprint(value)
    payload = repr(fingerprint).encode("utf-8", "backslashreplace")
    return hashlib.blake2b(payload, digest_size=16).hexdigest()


def _primitive(value: Any, *, depth: int = 0, items: list[int] | None = None) -> bool:
    """Validate that IPC data contains no live/user-defined Python objects."""
    if items is None:
        items = [0]
    items[0] += 1
    if depth > 16 or items[0] > 50_000:
        return False
    if value is None or isinstance(value, (bool, int, float, str)):
        return True
    if isinstance(value, bytes):
        return len(value) <= MAX_MESSAGE_BYTES
    if isinstance(value, (list, tuple)):
        return all(_primitive(item, depth=depth + 1, items=items) for item in value)
    if isinstance(value, dict):
        return all(
            isinstance(key, str)
            and _primitive(item, depth=depth + 1, items=items)
            for key, item in value.items()
        )
    return False


def _message_size(value: Any) -> int:
    """Cheap upper-bound-oriented size estimate for validated messages."""
    if value is None:
        return 4
    if isinstance(value, (bool, int, float)):
        return 32
    if isinstance(value, str):
        return len(value.encode("utf-8", "replace"))
    if isinstance(value, bytes):
        return len(value)
    if isinstance(value, (list, tuple)):
        return 16 + sum(_message_size(item) for item in value)
    if isinstance(value, dict):
        return 32 + sum(len(key) + _message_size(item) for key, item in value.items())
    return MAX_MESSAGE_BYTES + 1


def validate_message(message: Any) -> dict[str, Any]:
    if not isinstance(message, dict) or not _primitive(message):
        raise ValueError("Variable Explorer IPC accepts primitive messages only")
    if message.get("version") != PROTOCOL_VERSION:
        raise ValueError("Unsupported Variable Explorer IPC version")
    if _message_size(message) > MAX_MESSAGE_BYTES:
        raise ValueError("Variable Explorer IPC message exceeds 2 MiB")
    return message


@dataclass
class _Handle:
    path: ValuePath
    generation: int
    root_identity: int
    fingerprint: Any
    ancestors: tuple[int, ...] = ()


class GlobalsExplorerBroker:
    """Main-thread broker that translates live Globals into wire descriptors."""

    def __init__(self, runtime=None):
        self.runtime = runtime
        self._handles: dict[str, _Handle] = {}
        self._root_handles: dict[str, str] = {}
        self._object_handles: dict[int, str] = {}
        self._path_handles: dict[str, str] = {}
        self._next_handle = 1
        self._generation = RuntimeGlobals.generation

    def _reset_for_generation(self) -> None:
        generation = RuntimeGlobals.generation
        if generation != self._generation:
            self._handles.clear()
            self._root_handles.clear()
            self._object_handles.clear()
            self._path_handles.clear()
            self._next_handle = 1
            self._generation = generation

    def _new_handle(self, path: ValuePath, value: Any, ancestors=()) -> str:
        if len(self._handles) >= MAX_HANDLES:
            # Root descriptors are cheap to recreate; bound retained key/path objects.
            self._handles.clear()
            self._root_handles.clear()
            self._object_handles.clear()
            self._path_handles.clear()
        token = f"h{self._next_handle:x}"
        self._next_handle += 1
        root = RuntimeGlobals.get(path.root, None)
        self._handles[token] = _Handle(
            path=path,
            generation=RuntimeGlobals.generation,
            root_identity=id(root),
            fingerprint=value_fingerprint(value),
            ancestors=tuple(ancestors),
        )
        self._path_handles[path.key()] = token
        try:
            if DEFAULT_ADAPTERS.for_value(value).child_count(value) > 0:
                self._object_handles.setdefault(id(value), token)
        except Exception:
            pass
        return token

    def _handle_for_path(self, path: ValuePath, value: Any, ancestors=()) -> str:
        token = self._path_handles.get(path.key(), "")
        entry = self._handles.get(token)
        root = RuntimeGlobals.get(path.root, None)
        if (
            entry is not None
            and entry.generation == RuntimeGlobals.generation
            and entry.root_identity == id(root)
        ):
            entry.fingerprint = value_fingerprint(value)
            entry.ancestors = tuple(ancestors)
            try:
                if DEFAULT_ADAPTERS.for_value(value).child_count(value) > 0:
                    self._object_handles.setdefault(id(value), token)
            except Exception:
                pass
            return token
        return self._new_handle(path, value, ancestors)

    def _root_handle(self, name: str, value: Any) -> str:
        token = self._root_handles.get(name)
        entry = self._handles.get(token or "")
        if entry is not None and entry.root_identity == id(value):
            entry.fingerprint = value_fingerprint(value)
            return token
        token = self._new_handle(ValuePath(name), value, (id(value),))
        self._root_handles[name] = token
        return token

    def _resolve(self, token: str) -> tuple[_Handle, Any, Any]:
        self._reset_for_generation()
        entry = self._handles.get(str(token))
        if entry is None:
            raise EditConflictError("This explorer path expired; refresh and try again")
        if entry.generation != RuntimeGlobals.generation:
            raise EditConflictError("Globals reloaded; refresh and try again")
        root = RuntimeGlobals.get(entry.path.root, None)
        if id(root) != entry.root_identity:
            raise EditConflictError("The root Global was replaced; refresh and try again")
        return entry, root, resolve_path(root, entry.path.steps)

    def _metadata(self, name: str) -> dict[str, Any]:
        globals_class = getattr(self.runtime, "current_globals_class", None)
        try:
            spec = globals_class.definitions().get(name) if globals_class else None
        except Exception:
            spec = None
        if spec is None:
            return {"declaration": "dynamic"}
        return {
            "declaration": str(spec.kind),
            "label": str(spec.label or ""),
            "reload": str(getattr(spec.reload, "value", spec.reload)),
            "timeout": spec.timeout,
        }

    def _descriptor(
        self,
        name: str,
        value: Any,
        token: str,
        *,
        path: ValuePath,
        reference: str = "",
    ) -> dict[str, Any]:
        adapter = DEFAULT_ADAPTERS.for_value(value)
        try:
            children = int(adapter.child_count(value))
        except Exception:
            children = 0
        shape = ""
        try:
            if isinstance(value, np.ndarray):
                shape = " × ".join(str(item) for item in value.shape) or "0-D"
            elif isinstance(value, (pd.DataFrame, pd.Series)):
                shape = " × ".join(str(item) for item in value.shape)
            else:
                length = _safe_len(value)
                shape = f"len={length}" if length is not None else ""
        except Exception:
            shape = ""
        editable = False
        try:
            root = RuntimeGlobals.get(path.root, None)
            editable = bool(can_edit_value(value) and is_editable_path(root, path))
        except Exception:
            pass
        return {
            "handle": token,
            "root": path.root,
            "name": str(name),
            "path": path.display(),
            "type": type(value).__name__,
            "module": type(value).__module__,
            "summary": value_summary(value),
            "info": value_info(value),
            "shape": shape,
            "size": human_size(_safe_size(value)) or "unknown",
            "children": max(0, children),
            "editable": editable,
            "edit_text": editable_text(value)[:4000] if editable else "",
            "fingerprint": _fingerprint_token(value),
            "reference": reference,
            "table": self._table_kind(value),
        }

    @staticmethod
    def _table_kind(value: Any) -> str:
        if isinstance(value, np.ndarray):
            return "array"
        if isinstance(value, Styler):
            return "dataframe"
        if isinstance(value, pd.DataFrame):
            return "dataframe"
        if isinstance(value, pd.Series):
            return "series"
        if isinstance(value, pd.Index):
            return "index"
        return ""

    def _roots(self) -> dict[str, Any]:
        self._reset_for_generation()
        snapshot = RuntimeGlobals.snapshot()
        roots = []
        for name, value in sorted(snapshot.items(), key=lambda item: str(item[0]).lower()):
            token = self._root_handle(str(name), value)
            descriptor = self._descriptor(str(name), value, token, path=ValuePath(str(name)))
            descriptor["metadata"] = self._metadata(str(name))
            roots.append(descriptor)
        return {
            "state": str(RuntimeGlobals.state),
            "generation": int(RuntimeGlobals.generation),
            "roots": roots,
            "sampled": True,
        }

    def _children(self, payload: dict[str, Any]) -> dict[str, Any]:
        entry, _root, value = self._resolve(payload.get("handle", ""))
        offset = max(0, int(payload.get("offset", 0)))
        limit = min(PAGE_SIZE, max(1, int(payload.get("limit", PAGE_SIZE))))
        page = DEFAULT_ADAPTERS.for_value(value).children(value, offset, limit)
        descriptors = []
        ancestor_ids = entry.ancestors + (id(value),)
        for child in page.entries:
            path = entry.path.child(child.step)
            path_handle = self._path_handles.get(path.key(), "")
            previous_handle = self._object_handles.get(id(child.value), "")
            reference = (
                "cycle" if id(child.value) in ancestor_ids
                else f"shared:{previous_handle}"
                if previous_handle and previous_handle != path_handle else ""
            )
            token = self._handle_for_path(path, child.value, ancestor_ids)
            descriptors.append(
                self._descriptor(
                    str(child.name), child.value, token, path=path, reference=reference
                )
            )
        return {
            "items": descriptors,
            "offset": offset,
            "total": int(page.total),
            "error": str(page.error or ""),
        }

    def _detail(self, payload: dict[str, Any]) -> dict[str, Any]:
        entry, _root, value = self._resolve(payload.get("handle", ""))
        attributes = []
        for name, item in list((safe_attributes(value) or {}).items())[:100]:
            attributes.append(
                {"name": str(name), "type": type(item).__name__, "value": safe_repr(item, 500)}
            )
        return {
            "descriptor": self._descriptor(
                entry.path.display(), value, payload["handle"], path=entry.path
            ),
            "summary": (
                f"Path: {entry.path.display()}\n"
                f"Type: {type(value).__module__}.{type(value).__qualname__}\n"
                f"Identity: 0x{id(value):x}\n"
                f"Summary: {value_summary(value)}\n"
                f"Info: {value_info(value)}\n"
                f"Approximate size: {human_size(_safe_size(value)) or 'unknown'}"
            ),
            "representation": safe_details_repr(value)[:MAX_REPR],
            "attributes": attributes,
            "table": self._table_meta(value),
        }

    def _table_meta(self, value: Any) -> dict[str, Any]:
        if isinstance(value, Styler):
            value = value.data
        if isinstance(value, np.ndarray):
            rows = 1 if value.ndim <= 1 else int(value.shape[0])
            columns = (
                1 if value.ndim == 0 else int(value.shape[0])
                if value.ndim == 1 else int(value.shape[1])
            )
            return {
                "kind": "array", "rows": rows, "columns": columns,
                "shape": [int(item) for item in value.shape],
                "selectors": [0] * max(0, value.ndim - 2),
                "editable": bool(value.flags.writeable),
            }
        if isinstance(value, pd.DataFrame):
            return {
                "kind": "dataframe", "rows": int(value.shape[0]),
                "columns": int(value.shape[1]), "editable": True,
            }
        if isinstance(value, pd.Series):
            return {"kind": "series", "rows": len(value), "columns": 1, "editable": True}
        if isinstance(value, pd.Index):
            return {"kind": "index", "rows": len(value), "columns": 1, "editable": False}
        return {"kind": "", "rows": 0, "columns": 0, "editable": False}

    def _table_page(self, payload: dict[str, Any]) -> dict[str, Any]:
        entry, _root, value = self._resolve(payload.get("handle", ""))
        if isinstance(value, Styler):
            value = value.data
            entry = _Handle(
                entry.path.child(PathStep("styler_data", None)), entry.generation,
                entry.root_identity, entry.fingerprint, entry.ancestors,
            )
        meta = self._table_meta(value)
        row0 = max(0, int(payload.get("row", 0)))
        col0 = max(0, int(payload.get("column", 0)))
        rows = min(max(1, int(payload.get("rows", 40))), max(0, meta["rows"] - row0))
        columns = min(max(1, int(payload.get("columns", 20))), max(0, meta["columns"] - col0))
        if rows * columns > MAX_TABLE_CELLS:
            rows = max(1, MAX_TABLE_CELLS // max(1, columns))
        selectors = tuple(max(0, int(item)) for item in payload.get("selectors", []))
        cells = []
        horizontal = []
        vertical = []
        for column in range(col0, col0 + columns):
            try:
                if isinstance(value, pd.DataFrame):
                    horizontal.append(safe_repr(value.columns[column], 160))
                elif isinstance(value, (pd.Series, pd.Index)):
                    horizontal.append(str(getattr(value, "name", "value") or "value"))
                else:
                    horizontal.append(str(column))
            except Exception:
                horizontal.append(str(column))
        for row in range(row0, row0 + rows):
            try:
                vertical.append(
                    safe_repr(value.index[row], 160)
                    if isinstance(value, (pd.DataFrame, pd.Series)) else str(row)
                )
            except Exception:
                vertical.append(str(row))
            line = []
            for column in range(col0, col0 + columns):
                try:
                    if isinstance(value, np.ndarray):
                        if value.ndim == 0:
                            key, item = (), value[()]
                        elif value.ndim == 1:
                            key, item = (column,), value[column]
                        else:
                            clamped = tuple(
                                min(selectors[pos] if pos < len(selectors) else 0, value.shape[pos + 2] - 1)
                                for pos in range(max(0, value.ndim - 2))
                            )
                            key, item = (row, column) + clamped, value[(row, column) + clamped]
                        step = PathStep("array_index", key)
                    elif isinstance(value, pd.DataFrame):
                        item, step = value.iat[row, column], PathStep("df_iat", (row, column))
                    elif isinstance(value, pd.Series):
                        item, step = value.iloc[row], PathStep("series_iat", row)
                    else:
                        item, step = value[row], PathStep("index", row)
                    path = entry.path.child(step)
                    token = self._new_handle(path, item, entry.ancestors + (id(value),))
                    line.append(self._descriptor("", item, token, path=path))
                except Exception as error:
                    line.append({
                        "handle": "", "root": entry.path.root, "name": "", "path": "",
                        "type": "error", "summary": f"<{type(error).__name__}: {error}>",
                        "info": "", "shape": "", "size": "", "children": 0,
                        "editable": False, "edit_text": "", "fingerprint": "",
                        "reference": "", "table": "",
                    })
            cells.append(line)
        return {
            "row": row0, "column": col0, "rows": rows, "columns": columns,
            "cells": cells, "horizontal": horizontal, "vertical": vertical,
            "meta": meta,
        }

    def _commit(self, payload: dict[str, Any]) -> dict[str, Any]:
        edits_payload = payload.get("edits") or []
        if not isinstance(edits_payload, list) or not edits_payload:
            raise ExplorerError("No pending edits")
        expected_generation = int(payload.get("generation", -1))
        if expected_generation != RuntimeGlobals.generation:
            raise EditConflictError("Globals generation changed while edits were pending")
        resolved = []
        root_name = ""
        root_identity = None
        for wire_edit in edits_payload:
            entry, root, leaf = self._resolve(wire_edit.get("handle", ""))
            if root_name and entry.path.root != root_name:
                raise ExplorerError("One edit batch may target only one root Global")
            root_name = entry.path.root
            root_identity = id(root) if root_identity is None else root_identity
            if id(root) != root_identity:
                raise EditConflictError("The root Global changed")
            if _fingerprint_token(leaf) != wire_edit.get("fingerprint"):
                raise EditConflictError(f"{entry.path.display()} changed after staging")
            if not can_edit_value(leaf) or not is_editable_path(root, entry.path):
                raise ExplorerError(f"{entry.path.display()} is read-only")
            new_value = parse_edited_value(str(wire_edit.get("text", "")), leaf)
            resolved.append((entry.path.steps, new_value, value_fingerprint(leaf), entry.path.display()))

        def operation(current):
            if RuntimeGlobals.generation != expected_generation or id(current) != root_identity:
                raise EditConflictError("The edited root changed before commit")
            for steps, _new, fingerprint, display in resolved:
                if value_fingerprint(resolve_path(current, steps)) != fingerprint:
                    raise EditConflictError(f"{display} changed before commit")
            return apply_copy_on_write(current, [(steps, new) for steps, new, _fp, _display in resolved])

        RuntimeGlobals.mutate(root_name, operation)
        self._handles.clear()
        self._root_handles.clear()
        self._object_handles.clear()
        self._path_handles.clear()
        return {"applied": len(resolved), "root": root_name}

    def dispatch(self, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
        if operation == "hello":
            return {"protocol": PROTOCOL_VERSION, "capabilities": [
                "roots", "children", "details", "table-pages", "atomic-edits"
            ]}
        if operation == "roots":
            return self._roots()
        if operation == "children":
            return self._children(payload)
        if operation == "detail":
            return self._detail(payload)
        if operation == "table_page":
            return self._table_page(payload)
        if operation == "commit":
            return self._commit(payload)
        if operation == "ping":
            return {"state": str(RuntimeGlobals.state), "generation": RuntimeGlobals.generation}
        raise ValueError(f"Unknown Variable Explorer operation {operation!r}")


class _PipeReader(QtCore.QThread):
    received = QtCore.pyqtSignal(object)
    disconnected = QtCore.pyqtSignal(str)

    def __init__(self, connection, parent=None):
        super().__init__(parent)
        self.connection = connection

    def run(self):
        try:
            while not self.isInterruptionRequested():
                message = self.connection.recv()
                self.received.emit(message)
        except (EOFError, OSError, BrokenPipeError) as error:
            self.disconnected.emit(str(error))
        except Exception:
            self.disconnected.emit(traceback.format_exc())


class ChildBridge(QtCore.QObject):
    command = QtCore.pyqtSignal(str)
    disconnected = QtCore.pyqtSignal(str)

    def __init__(self, connection, parent=None):
        super().__init__(parent)
        self.connection = connection
        self._next = 1
        self._callbacks: dict[int, Callable[[dict[str, Any]], None]] = {}
        self._send_lock = threading.Lock()
        self.reader = _PipeReader(connection, self)
        self.reader.received.connect(self._received)
        self.reader.disconnected.connect(self.disconnected)
        self.reader.start()

    def request(self, operation: str, payload: dict[str, Any], callback=None) -> int:
        request_id = self._next
        self._next += 1
        message = {
            "version": PROTOCOL_VERSION, "kind": "request", "id": request_id,
            "operation": str(operation), "payload": payload,
        }
        validate_message(message)
        if callback is not None:
            self._callbacks[request_id] = callback
        try:
            with self._send_lock:
                self.connection.send(message)
        except Exception as error:
            self.disconnected.emit(str(error))
        return request_id

    @QtCore.pyqtSlot(object)
    def _received(self, raw):
        try:
            message = validate_message(raw)
        except Exception as error:
            self.disconnected.emit(str(error))
            return
        if message.get("kind") == "command":
            self.command.emit(str(message.get("operation", "")))
            return
        callback = self._callbacks.pop(int(message.get("id", -1)), None)
        if callback is not None:
            callback(message)

    def close(self):
        self.reader.requestInterruption()
        try:
            self.connection.close()
        except Exception:
            pass
        self.reader.wait(500)


class RemoteTableModel(QtCore.QAbstractTableModel):
    editRequested = QtCore.pyqtSignal(dict, str)

    def __init__(self, bridge: ChildBridge, handle: str, meta: dict, parent=None):
        super().__init__(parent)
        self.bridge = bridge
        self.handle = handle
        self.meta = dict(meta)
        self.selectors = list(meta.get("selectors", []))
        self.pages: dict[tuple[int, int, tuple[int, ...]], dict] = {}
        self.pending_pages: set[tuple[int, int, tuple[int, ...]]] = set()
        self.pending_texts: dict[str, str] = {}
        self.pending_path_texts: dict[str, str] = {}
        self.pending_error = False

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else int(self.meta.get("rows", 0))

    def columnCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else int(self.meta.get("columns", 0))

    def _page_key(self, row, column):
        return row // 20 * 20, column // 10 * 10, tuple(self.selectors)

    def _cell(self, index):
        key = self._page_key(index.row(), index.column())
        page = self.pages.get(key)
        if page is None:
            if key not in self.pending_pages:
                self.pending_pages.add(key)
                self.bridge.request(
                    "table_page",
                    {"handle": self.handle, "row": key[0], "column": key[1],
                     "rows": 20, "columns": 10, "selectors": list(key[2])},
                    lambda message, page_key=key: self._page_received(page_key, message),
                )
            return None
        row = index.row() - page["row"]
        column = index.column() - page["column"]
        try:
            return page["cells"][row][column]
        except Exception:
            return None

    def _page_received(self, key, message):
        self.pending_pages.discard(key)
        if not message.get("ok"):
            return
        page = message.get("result", {})
        self.pages[key] = page
        if page.get("meta") != self.meta:
            self.beginResetModel()
            self.meta = dict(page.get("meta") or self.meta)
            self.endResetModel()
        row1 = min(self.rowCount() - 1, page.get("row", 0) + page.get("rows", 0) - 1)
        col1 = min(self.columnCount() - 1, page.get("column", 0) + page.get("columns", 0) - 1)
        if row1 >= 0 and col1 >= 0:
            self.dataChanged.emit(self.index(page["row"], page["column"]), self.index(row1, col1))
            self.headerDataChanged.emit(QtCore.Qt.Horizontal, page["column"], col1)
            self.headerDataChanged.emit(QtCore.Qt.Vertical, page["row"], row1)

    def refresh_meta(self, meta):
        old_shape = (self.rowCount(), self.columnCount())
        new_shape = (int(meta.get("rows", 0)), int(meta.get("columns", 0)))
        if old_shape != new_shape:
            self.beginResetModel()
            self.meta = dict(meta)
            self.pages.clear()
            self.pending_pages.clear()
            self.endResetModel()
        else:
            self.meta = dict(meta)
            self.pages.clear()
            self.pending_pages.clear()
            if self.rowCount() and self.columnCount():
                self.dataChanged.emit(self.index(0, 0), self.index(self.rowCount() - 1, self.columnCount() - 1))

    def set_selectors(self, selectors):
        self.selectors = list(selectors)
        self.pages.clear()
        self.pending_pages.clear()
        if self.rowCount() and self.columnCount():
            self.dataChanged.emit(self.index(0, 0), self.index(self.rowCount() - 1, self.columnCount() - 1))

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        cell = self._cell(index)
        if cell is None:
            return "…" if role == QtCore.Qt.DisplayRole else None
        if role == QtCore.Qt.DisplayRole:
            pending_text = self.pending_texts.get(cell.get("handle"))
            if pending_text is None:
                pending_text = self.pending_path_texts.get(cell.get("path"))
            if pending_text is not None:
                return pending_text
            return cell.get("summary", "")
        if role == QtCore.Qt.EditRole:
            return cell.get("edit_text", cell.get("summary", ""))
        if role == DISPLAY_ROLE:
            return cell
        if (role == QtCore.Qt.BackgroundRole
                and (cell.get("handle") in self.pending_texts
                     or cell.get("path") in self.pending_path_texts)):
            return QtGui.QBrush(QtGui.QColor("#ffd6d6" if self.pending_error else "#cfe8ff"))
        if role == QtCore.Qt.ToolTipRole:
            return f"{cell.get('path', '')}\n{cell.get('type', '')}\n{cell.get('summary', '')}"
        return None

    def setData(self, index, value, role=QtCore.Qt.EditRole):
        cell = self._cell(index)
        if role != QtCore.Qt.EditRole or not cell or not cell.get("editable"):
            return False
        self.editRequested.emit(cell, str(value))
        self.dataChanged.emit(index, index)
        return True

    def flags(self, index):
        flags = QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable
        cell = self._cell(index)
        if cell and cell.get("editable") and self.meta.get("editable"):
            flags |= QtCore.Qt.ItemIsEditable
        return flags

    def set_pending(self, edits, *, error=False):
        self.pending_texts = {item["handle"]: item["text"] for item in edits}
        self.pending_path_texts = {
            item.get("path", ""): item["text"] for item in edits if item.get("path")
        }
        self.pending_error = bool(error)
        if self.rowCount() and self.columnCount():
            self.dataChanged.emit(
                self.index(0, 0),
                self.index(self.rowCount() - 1, self.columnCount() - 1),
                [QtCore.Qt.DisplayRole, QtCore.Qt.BackgroundRole],
            )

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role != QtCore.Qt.DisplayRole:
            return None
        if orientation == QtCore.Qt.Horizontal:
            key = self._page_key(0, section)
            page = self.pages.get(key)
            try:
                return page["horizontal"][section - page["column"]]
            except Exception:
                return str(section)
        key = self._page_key(section, 0)
        page = self.pages.get(key)
        try:
            return page["vertical"][section - page["row"]]
        except Exception:
            return str(section)


class RemoteExplorerWindow(QtWidgets.QMainWindow):
    def __init__(self, bridge: ChildBridge):
        super().__init__()
        self.bridge = bridge
        self.generation = 0
        self.current_descriptor: dict[str, Any] | None = None
        self.pending: list[dict[str, Any]] = []
        self.pending_root = ""
        self.pending_error = ""
        self._commit_in_flight = False
        self._fingerprints: dict[str, tuple[str, str]] = {}
        self._history_records: list[tuple[str, str, str, str, str, str, str]] = []
        self._modified_items: dict[str, tuple[float, str, QtWidgets.QTreeWidgetItem]] = {}
        self._baseline_ready = False
        self._last_generation = 0
        self._closing_from_parent = False
        self.setWindowTitle("Variable Explorer — Application Globals")
        self.resize(1300, 820)
        self._build_ui()
        self.bridge.command.connect(self._command)
        self.bridge.disconnected.connect(self._disconnected)
        self.live_timer = QtCore.QTimer(self)
        self.live_timer.setInterval(750)
        self.live_timer.timeout.connect(self.refresh)
        self.live_timer.start()
        self.highlight_timer = QtCore.QTimer(self)
        self.highlight_timer.setInterval(500)
        self.highlight_timer.timeout.connect(self._expire_highlights)
        self.highlight_timer.start()
        self.bridge.request("hello", {}, self._hello)

    def _build_ui(self):
        central = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(central)
        controls = QtWidgets.QHBoxLayout()
        self.live = QtWidgets.QCheckBox("Live")
        self.live.setChecked(True)
        self.live.toggled.connect(lambda enabled: self.live_timer.start(self.interval.value()) if enabled else self.live_timer.stop())
        controls.addWidget(self.live)
        refresh = QtWidgets.QPushButton("Refresh")
        refresh.clicked.connect(self.refresh)
        controls.addWidget(refresh)
        self.interval = QtWidgets.QSpinBox()
        self.interval.setRange(250, 10_000)
        self.interval.setValue(750)
        self.interval.setSuffix(" ms")
        self.interval.valueChanged.connect(lambda value: self.live_timer.setInterval(value))
        controls.addWidget(self.interval)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Search loaded variables…")
        self.search.textChanged.connect(self._filter_tree)
        controls.addWidget(self.search, 1)
        self.edit_button = QtWidgets.QPushButton("Edit selected…")
        self.edit_button.setToolTip(
            "Edit a selected scalar or table cell. Global names and collection structure are fixed."
        )
        self.edit_button.clicked.connect(self.edit_selected)
        controls.addWidget(self.edit_button)
        self.apply_button = QtWidgets.QPushButton("Apply")
        self.apply_button.clicked.connect(self.apply_edits)
        self.discard_button = QtWidgets.QPushButton("Discard")
        self.discard_button.clicked.connect(self.discard_edits)
        controls.addWidget(self.apply_button)
        controls.addWidget(self.discard_button)
        outer.addLayout(controls)
        self.status = QtWidgets.QLabel("Connecting…")
        outer.addWidget(self.status)
        edit_help = QtWidgets.QLabel(
            "Editing: select a scalar and double-click/Edit selected, or edit a Data "
            "cell; then use Apply. Global names and collection structure are read-only."
        )
        edit_help.setStyleSheet("color: #5b6472;")
        edit_help.setWordWrap(True)
        outer.addWidget(edit_help)
        splitter = QtWidgets.QSplitter()
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setColumnCount(6)
        self.tree.setHeaderLabels(["Name", "Type", "Value", "Shape/Length", "Size", "Modified"])
        self.tree.itemExpanded.connect(self._expanded)
        self.tree.currentItemChanged.connect(self._selected)
        self.tree.itemDoubleClicked.connect(self._edit_tree_item)
        self.tree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._tree_menu)
        splitter.addWidget(self.tree)
        self.tabs = QtWidgets.QTabWidget()
        self.summary = QtWidgets.QPlainTextEdit(); self.summary.setReadOnly(True)
        self.tabs.addTab(self.summary, "Summary")
        data_widget = QtWidgets.QWidget(); data_layout = QtWidgets.QVBoxLayout(data_widget)
        data_layout.setContentsMargins(0, 0, 0, 0)
        self.slice_bar = QtWidgets.QWidget(); self.slice_layout = QtWidgets.QHBoxLayout(self.slice_bar)
        self.slice_layout.setContentsMargins(2, 2, 2, 2)
        data_layout.addWidget(self.slice_bar)
        self.table = QtWidgets.QTableView()
        self.table.setSortingEnabled(True); self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.table.doubleClicked.connect(self._table_drill)
        data_layout.addWidget(self.table)
        self.tabs.addTab(data_widget, "Data")
        self.representation = QtWidgets.QPlainTextEdit(); self.representation.setReadOnly(True)
        self.tabs.addTab(self.representation, "Representation")
        self.attributes = QtWidgets.QTableWidget(0, 3)
        self.attributes.setHorizontalHeaderLabels(["Name", "Type", "Value"])
        self.attributes.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.attributes, "Attributes")
        self.history = QtWidgets.QTableWidget(0, 7)
        self.history.setHorizontalHeaderLabels(
            ["Time", "Path", "Kind", "Old", "New", "Generation", "Origin"]
        )
        self.history.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.history, "Changes")
        splitter.addWidget(self.tabs); splitter.setStretchFactor(1, 2)
        outer.addWidget(splitter, 1)
        self.setCentralWidget(central)
        self._pending_ui()

    def _hello(self, message):
        if not message.get("ok"):
            self._disconnected(message.get("error", "Handshake failed")); return
        self.refresh()

    def refresh(self):
        self.bridge.request("roots", {}, self._roots_received)
        if self.current_descriptor:
            self.bridge.request("detail", {"handle": self.current_descriptor["handle"]}, self._detail_received)

    def _roots_received(self, message):
        if not message.get("ok"):
            self.status.setText("Refresh failed: " + message.get("error", "unknown error")); return
        result = message["result"]
        new_generation = int(result.get("generation", 0))
        self.generation = new_generation
        existing = {self.tree.topLevelItem(i).data(0, QtCore.Qt.UserRole).get("root"): self.tree.topLevelItem(i)
                    for i in range(self.tree.topLevelItemCount())}
        seen = set()
        for descriptor in result.get("roots", []):
            name = descriptor["root"]; seen.add(name)
            item = existing.get(name) or QtWidgets.QTreeWidgetItem(self.tree)
            self._set_item(item, descriptor)
            self._track_descriptor(descriptor, item, added=name not in existing)
            if (
                self.current_descriptor
                and self.current_descriptor.get("path") == descriptor.get("path")
                and self.current_descriptor.get("handle") != descriptor.get("handle")
            ):
                self.current_descriptor = descriptor
                self.bridge.request("detail", {"handle": descriptor["handle"]}, self._detail_received)
        for name, item in existing.items():
            if name not in seen:
                descriptor = item.data(0, QtCore.Qt.UserRole) or {}
                self._record_change(descriptor.get("path", name), "removed", descriptor.get("summary", ""), "")
                self._fingerprints.pop(descriptor.get("path", name), None)
                self.tree.takeTopLevelItem(self.tree.indexOfTopLevelItem(item))
        if self._baseline_ready and self._last_generation and new_generation != self._last_generation:
            self._record_change("<Globals generation>", "generation", str(self._last_generation), str(new_generation))
        self._last_generation = new_generation
        self._baseline_ready = True
        self.status.setText(
            f"State: {result.get('state')}  |  Generation: {self.generation}  |  "
            f"{len(result.get('roots', []))} variables  |  separate process"
        )
        for index in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(index)
            if item.isExpanded():
                self._refresh_loaded_children(item)
        self._pending_ui()
        self._filter_tree(self.search.text())

    def _set_item(self, item, descriptor):
        item.setData(0, QtCore.Qt.UserRole, descriptor)
        values = [descriptor.get("name", ""), descriptor.get("type", ""),
                  descriptor.get("summary", ""), descriptor.get("shape", ""),
                  descriptor.get("size", "")]
        for column, value in enumerate(values): item.setText(column, str(value))
        if descriptor.get("children") and not descriptor.get("reference") and item.childCount() == 0:
            dummy = QtWidgets.QTreeWidgetItem(item, ["Loading…"])
            dummy.setData(0, QtCore.Qt.UserRole, {"dummy": True, "offset": 0})

    def _decorate_item(self, item, path, *, timestamp=None, change=""):
        """Apply durable change decoration after descriptor refreshes."""
        if timestamp is None:
            item.setText(5, "")
            for column in range(self.tree.columnCount()):
                item.setBackground(column, QtGui.QBrush())
                item.setForeground(column, QtGui.QBrush())
            return
        color = "#d8f5d0" if change == "added" else "#fff0b3"
        item.setText(
            5,
            f"● {time.strftime('%H:%M:%S', time.localtime(timestamp))} {change}",
        )
        for column in range(self.tree.columnCount()):
            item.setBackground(column, QtGui.QBrush(QtGui.QColor(color)))
            item.setForeground(column, QtGui.QBrush(QtGui.QColor("#172033")))
        self._modified_items[path] = (timestamp, change, item)

    def _track_descriptor(self, descriptor, item=None, *, added=False):
        path = descriptor.get("path", "")
        current = (descriptor.get("fingerprint", ""), descriptor.get("summary", ""))
        previous = self._fingerprints.get(path)
        change = ""
        if self._baseline_ready and added:
            change = "added"
            self._record_change(path, change, "", current[1])
        elif self._baseline_ready and previous is not None and previous[0] != current[0]:
            change = "changed"
            self._record_change(path, change, previous[1], current[1])
        self._fingerprints[path] = current
        if item is not None and change:
            self._decorate_item(item, path, timestamp=time.time(), change=change)
        elif item is not None:
            modified = self._modified_items.get(path)
            if modified and time.time() - modified[0] < 5.0:
                self._decorate_item(
                    item, path, timestamp=modified[0], change=modified[1]
                )

    def _record_change(self, path, change, old, new, *, origin="runtime"):
        record = (
            time.strftime("%H:%M:%S"), str(path), str(change), str(old)[:240],
            str(new)[:240], str(self.generation), str(origin),
        )
        self._history_records.append(record)
        self._history_records = self._history_records[-500:]
        self.history.setRowCount(len(self._history_records))
        row = len(self._history_records) - 1
        for column, value in enumerate(record):
            self.history.setItem(row, column, QtWidgets.QTableWidgetItem(value))
        colors = {
            "added": "#d8f5d0", "changed": "#fff0b3", "edited": "#cfe8ff",
            "removed": "#ffd6d6", "generation": "#e8def8",
        }
        color = colors.get(str(change))
        if color:
            for column in range(self.history.columnCount()):
                self.history.item(row, column).setBackground(QtGui.QColor(color))
        self.history.scrollToBottom()

    def _expire_highlights(self):
        now = time.time()
        pending_handles = {item["handle"] for item in self.pending}
        for path, (timestamp, _kind, item) in list(self._modified_items.items()):
            if now - timestamp < 5.0:
                continue
            try:
                descriptor = item.data(0, QtCore.Qt.UserRole) or {}
                if descriptor.get("handle") not in pending_handles:
                    self._decorate_item(item, path)
            except RuntimeError:
                pass
            self._modified_items.pop(path, None)

    def _expanded(self, item):
        if item.childCount() == 1 and (item.child(0).data(0, QtCore.Qt.UserRole) or {}).get("dummy"):
            descriptor = item.data(0, QtCore.Qt.UserRole)
            item.takeChildren()
            self._load_children(item, descriptor, 0)

    def _load_children(self, parent, descriptor, offset):
        self.bridge.request(
            "children", {"handle": descriptor["handle"], "offset": offset, "limit": PAGE_SIZE},
            lambda message, target=parent, source=descriptor: self._children_received(target, source, message),
        )

    def _children_received(self, parent, descriptor, message):
        if not message.get("ok"):
            QtWidgets.QTreeWidgetItem(parent, [message.get("error", "Unable to load")]); return
        result = message["result"]
        for child_descriptor in result.get("items", []):
            child = QtWidgets.QTreeWidgetItem(parent)
            self._set_item(child, child_descriptor)
        loaded = result.get("offset", 0) + len(result.get("items", []))
        if loaded < result.get("total", 0):
            more = QtWidgets.QTreeWidgetItem(parent, [f"Load next {PAGE_SIZE}…"])
            more.setData(0, QtCore.Qt.UserRole, {"more": True, "offset": loaded, "parent": descriptor})

    def _refresh_loaded_children(self, parent):
        descriptor = parent.data(0, QtCore.Qt.UserRole) or {}
        if "handle" not in descriptor:
            return
        loaded = sum(
            1 for index in range(parent.childCount())
            if not (parent.child(index).data(0, QtCore.Qt.UserRole) or {}).get("more")
            and not (parent.child(index).data(0, QtCore.Qt.UserRole) or {}).get("dummy")
        )
        if loaded <= 0:
            return
        self.bridge.request(
            "children",
            {"handle": descriptor["handle"], "offset": 0, "limit": min(PAGE_SIZE, loaded)},
            lambda message, target=parent: self._refreshed_children_received(target, message),
        )

    def _refreshed_children_received(self, parent, message):
        if not message.get("ok"):
            return
        result = message["result"]
        existing = {}
        more_items = []
        for index in range(parent.childCount()):
            item = parent.child(index)
            descriptor = item.data(0, QtCore.Qt.UserRole) or {}
            if descriptor.get("more"):
                more_items.append(item)
            elif descriptor.get("path"):
                existing[descriptor["path"]] = item
        seen = set()
        for descriptor in result.get("items", []):
            path = descriptor.get("path", ""); seen.add(path)
            item = existing.get(path)
            if item is None:
                item = QtWidgets.QTreeWidgetItem(parent)
                self._set_item(item, descriptor)
                self._track_descriptor(descriptor, item, added=True)
            else:
                was_expanded = item.isExpanded()
                self._set_item(item, descriptor)
                self._track_descriptor(descriptor, item)
                item.setExpanded(was_expanded)
                if was_expanded:
                    self._refresh_loaded_children(item)
        for path, item in existing.items():
            if path not in seen:
                old = item.data(0, QtCore.Qt.UserRole) or {}
                self._record_change(path, "removed", old.get("summary", ""), "")
                parent.removeChild(item)
                self._fingerprints.pop(path, None)

    def _selected(self, item, previous):
        if item is None: return
        descriptor = item.data(0, QtCore.Qt.UserRole) or {}
        if descriptor.get("more"):
            parent = item.parent(); parent.removeChild(item)
            self._load_children(parent, descriptor["parent"], descriptor["offset"]); return
        if "handle" not in descriptor: return
        self.current_descriptor = descriptor
        self.bridge.request("detail", {"handle": descriptor["handle"]}, self._detail_received)

    @staticmethod
    def _text_state(editor):
        cursor = editor.textCursor()
        return cursor.anchor(), cursor.position(), editor.verticalScrollBar().value(), editor.horizontalScrollBar().value()

    @staticmethod
    def _set_text(editor, text, state):
        editor.setPlainText(str(text))
        maximum = max(0, editor.document().characterCount() - 1)
        anchor, position, vertical, horizontal = state
        cursor = editor.textCursor(); cursor.setPosition(min(maximum, anchor))
        cursor.setPosition(min(maximum, position), QtGui.QTextCursor.KeepAnchor)
        editor.setTextCursor(cursor); editor.verticalScrollBar().setValue(vertical)
        editor.horizontalScrollBar().setValue(horizontal)

    def _detail_received(self, message):
        if not message.get("ok"):
            self.status.setText("Detail unavailable: " + message.get("error", "expired path")); return
        result = message["result"]
        self.current_descriptor = result.get("descriptor", self.current_descriptor)
        self._track_descriptor(self.current_descriptor)
        self._set_text(self.summary, result.get("summary", ""), self._text_state(self.summary))
        self._set_text(self.representation, result.get("representation", ""), self._text_state(self.representation))
        attributes = result.get("attributes", [])
        self.attributes.setRowCount(len(attributes))
        for row, attribute in enumerate(attributes):
            for column, key in enumerate(("name", "type", "value")):
                self.attributes.setItem(row, column, QtWidgets.QTableWidgetItem(attribute.get(key, "")))
        meta = result.get("table", {})
        if meta.get("kind"):
            model = self.table.model()
            if isinstance(model, RemoteTableModel) and model.handle == self.current_descriptor["handle"]:
                table_state = self._capture_table_state()
                model.refresh_meta(meta)
                self._restore_table_state(table_state)
            else:
                model = RemoteTableModel(self.bridge, self.current_descriptor["handle"], meta, self.table)
                model.editRequested.connect(self._stage_edit)
                self.table.setModel(model)
                self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
            self._make_slices(model, meta)
        else:
            self.table.setModel(None); self._make_slices(None, {})

    def _capture_table_state(self):
        model = self.table.model()
        current = self.table.currentIndex()
        return {
            "current": (current.row(), current.column()),
            "selected": [(index.row(), index.column()) for index in self.table.selectedIndexes()[:1000]],
            "vertical": self.table.verticalScrollBar().value(),
            "horizontal": self.table.horizontalScrollBar().value(),
            "widths": [self.table.columnWidth(column) for column in range(model.columnCount() if model else 0)],
            "sort": (
                self.table.horizontalHeader().sortIndicatorSection(),
                int(self.table.horizontalHeader().sortIndicatorOrder()),
            ),
        }

    def _restore_table_state(self, state):
        model = self.table.model()
        if model is None: return
        rows, columns = model.rowCount(), model.columnCount()
        for column, width in enumerate(state.get("widths", [])):
            if column < columns: self.table.setColumnWidth(column, width)
        row, column = state.get("current", (-1, -1))
        if 0 <= row < rows and 0 <= column < columns:
            self.table.setCurrentIndex(model.index(row, column))
        selection = self.table.selectionModel()
        if selection is not None:
            selection.clearSelection()
            for row, column in state.get("selected", []):
                if 0 <= row < rows and 0 <= column < columns:
                    selection.select(model.index(row, column), QtCore.QItemSelectionModel.Select)
        self.table.doItemsLayout()
        self.table.verticalScrollBar().setValue(state.get("vertical", 0))
        self.table.horizontalScrollBar().setValue(state.get("horizontal", 0))

    def _make_slices(self, model, meta):
        previous = [spin.value() for spin in self.slice_bar.findChildren(QtWidgets.QSpinBox)]
        while self.slice_layout.count():
            item = self.slice_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        spins = []
        for pos, maximum in enumerate(meta.get("shape", [])[2:]):
            self.slice_layout.addWidget(QtWidgets.QLabel(f"dim {pos + 2}:"))
            spin = QtWidgets.QSpinBox(); spin.setRange(0, max(0, int(maximum) - 1))
            spin.setValue(min(spin.maximum(), previous[pos] if pos < len(previous) else 0))
            self.slice_layout.addWidget(spin); spins.append(spin)
            spin.valueChanged.connect(lambda _value, controls=spins, target=model: target.set_selectors([s.value() for s in controls]))
        self.slice_layout.addStretch(); self.slice_bar.setVisible(bool(spins))

    def _table_drill(self, index):
        descriptor = index.data(DISPLAY_ROLE)
        if descriptor and descriptor.get("children"):
            self.current_descriptor = descriptor
            self.bridge.request("detail", {"handle": descriptor["handle"]}, self._detail_received)

    def _edit_tree_item(self, item, column):
        descriptor = item.data(0, QtCore.Qt.UserRole) or {}
        if not descriptor.get("editable"):
            if descriptor.get("handle"):
                QtWidgets.QMessageBox.information(
                    self,
                    "Read-only value",
                    "This value is not an editable scalar. Global names, collection "
                    "structure, resources, and read-only arrays are fixed.",
                )
            return
        text, ok = QtWidgets.QInputDialog.getText(self, "Stage value", descriptor.get("path", ""), text=descriptor.get("edit_text", ""))
        if ok: self._stage_edit(descriptor, text)

    def edit_selected(self):
        item = self.tree.currentItem()
        if item is not None:
            self._edit_tree_item(item, 0)
            return
        index = self.table.currentIndex()
        if index.isValid():
            self.table.edit(index)
            return
        QtWidgets.QMessageBox.information(
            self, "Select a value", "Select a nested scalar or Data-table cell first."
        )

    def _tree_menu(self, position):
        item = self.tree.itemAt(position)
        if item is None:
            return
        descriptor = item.data(0, QtCore.Qt.UserRole) or {}
        menu = QtWidgets.QMenu(self.tree)
        edit = menu.addAction("Edit value…")
        edit.setEnabled(bool(descriptor.get("editable")))
        edit.triggered.connect(lambda: self._edit_tree_item(item, 0))
        copy_path = menu.addAction("Copy path")
        copy_path.triggered.connect(
            lambda: QtWidgets.QApplication.clipboard().setText(descriptor.get("path", ""))
        )
        menu.exec_(self.tree.viewport().mapToGlobal(position))

    def _stage_edit(self, descriptor, text):
        if self._commit_in_flight:
            return
        root = descriptor.get("root", "")
        if self.pending and root != self.pending_root:
            reply = QtWidgets.QMessageBox.question(
                self, "Change edit root", "Pending edits target another Global. Discard them?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.Cancel,
                QtWidgets.QMessageBox.Cancel,
            )
            if reply != QtWidgets.QMessageBox.Yes: return
            self.discard_edits()
        edit = {"handle": descriptor["handle"], "fingerprint": descriptor["fingerprint"],
                "text": str(text), "path": descriptor.get("path", ""),
                "old": descriptor.get("summary", "")}
        self.pending = [item for item in self.pending if item["handle"] != edit["handle"]]
        self.pending.append(edit); self.pending_root = root; self.pending_error = ""; self._pending_ui()

    def apply_edits(self):
        if not self.pending or self._commit_in_flight: return
        self._commit_in_flight = True
        self._pending_ui()
        self.status.setText(f"Applying {len(self.pending)} staged edit(s)…")
        self.bridge.request("commit", {"generation": self.generation, "edits": self.pending}, self._commit_received)

    def _commit_received(self, message):
        self._commit_in_flight = False
        if message.get("ok"):
            committed = list(self.pending)
            for edit in committed:
                self._record_change(
                    edit.get("path", ""), "edited", edit.get("old", ""),
                    edit.get("text", ""), origin="explorer",
                )
            result = message.get("result", {})
            self.discard_edits()
            self.status.setText(
                f"Applied {result.get('applied', len(committed))} edit(s) atomically; refreshing…"
            )
            self.refresh()
        else:
            self.pending_error = message.get("error", "Commit failed")
            self._pending_ui()
            QtWidgets.QMessageBox.warning(self, "Edit conflict", message.get("error", "Commit failed"))

    def discard_edits(self):
        self.pending.clear(); self.pending_root = ""; self.pending_error = ""; self._pending_ui()

    def _pending_ui(self):
        active = bool(self.pending)
        self.apply_button.setEnabled(active and not self._commit_in_flight)
        self.discard_button.setEnabled(active and not self._commit_in_flight)
        self.apply_button.setText(
            "Applying…" if self._commit_in_flight
            else f"Apply ({len(self.pending)})" if active else "Apply"
        )
        pending_handles = {item["handle"] for item in self.pending}
        pending_paths = {item.get("path", "") for item in self.pending}

        def update_item(item):
            descriptor = item.data(0, QtCore.Qt.UserRole) or {}
            if (descriptor.get("handle") in pending_handles
                    or descriptor.get("path", "") in pending_paths
                    or (self.pending_root
                        and descriptor.get("path", "") == self.pending_root)):
                item.setText(5, "● conflict" if self.pending_error else "● pending edit")
                color = "#ffd6d6" if self.pending_error else "#cfe8ff"
                for column in range(self.tree.columnCount()):
                    item.setBackground(column, QtGui.QBrush(QtGui.QColor(color)))
                    item.setForeground(column, QtGui.QBrush(QtGui.QColor("#172033")))
            elif item.text(5) in {"pending", "conflict", "● pending edit", "● conflict"}:
                modified = self._modified_items.get(descriptor.get("path", ""))
                self._decorate_item(
                    item,
                    descriptor.get("path", ""),
                    timestamp=modified[0] if modified else None,
                    change=modified[1] if modified else "",
                )
            for index in range(item.childCount()):
                update_item(item.child(index))

        for index in range(self.tree.topLevelItemCount()):
            update_item(self.tree.topLevelItem(index))
        model = self.table.model()
        if isinstance(model, RemoteTableModel):
            model.set_pending(self.pending, error=bool(self.pending_error))

    def _filter_tree(self, text):
        needle = str(text).lower().strip()
        def visit(item):
            child_match = any(visit(item.child(i)) for i in range(item.childCount()))
            own = not needle or any(needle in item.text(c).lower() for c in range(5))
            item.setHidden(not (own or child_match)); return own or child_match
        for index in range(self.tree.topLevelItemCount()): visit(self.tree.topLevelItem(index))

    @QtCore.pyqtSlot(str)
    def _command(self, operation):
        if operation == "show": self.show(); self.raise_(); self.activateWindow()
        elif operation == "refresh": self.refresh()
        elif operation == "shutdown":
            self._closing_from_parent = True; self.close()

    @QtCore.pyqtSlot(str)
    def _disconnected(self, details):
        self.live_timer.stop(); self.apply_button.setEnabled(False)
        self.status.setText("Disconnected from application; this window is now read-only")

    def closeEvent(self, event):
        if self.pending and not self._closing_from_parent:
            reply = QtWidgets.QMessageBox.question(
                self, "Discard pending edits?", "Closing will discard pending edits. Continue?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No,
            )
            if reply != QtWidgets.QMessageBox.Yes: event.ignore(); return
        self.discard_edits(); self.live_timer.stop(); event.accept()
        QtCore.QTimer.singleShot(0, QtWidgets.QApplication.instance().quit)


def variable_explorer_process_entry(connection) -> None:
    """Spawn-safe child entry point."""
    try:
        set_windows_app_id()
        application = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
        apply_app_icon()
        bridge = ChildBridge(connection)
        window = RemoteExplorerWindow(bridge)
        apply_app_icon(window)
        window.show()
        application.exec_()
        bridge.close()
    except BaseException:
        try:
            connection.send({
                "version": PROTOCOL_VERSION, "kind": "event", "id": 0,
                "operation": "child_error", "payload": {"traceback": traceback.format_exc()[:20_000]},
            })
        except Exception:
            pass
        raise


class VariableExplorerController(QtCore.QObject):
    """Main-process singleton controller and non-blocking Globals broker."""

    def __init__(self, runtime=None, parent=None):
        super().__init__(parent)
        self.runtime = runtime
        self.process = None
        self.connection = None
        self.broker = GlobalsExplorerBroker(runtime)
        self.last_exit_code = None
        self.last_error = ""
        self._closing = False
        self.poll_timer = QtCore.QTimer(self)
        self.poll_timer.setInterval(15)
        self.poll_timer.timeout.connect(self._poll)
        self.monitor_timer = QtCore.QTimer(self)
        self.monitor_timer.setInterval(250)
        self.monitor_timer.timeout.connect(self._monitor)
        if runtime is not None:
            for signal_name in ("state_changed", "ready", "reload_finished"):
                signal = getattr(runtime, signal_name, None)
                if signal is not None:
                    signal.connect(lambda *args: self.send_command("refresh"))

    @property
    def running(self):
        return bool(self.process is not None and self.process.is_alive())

    def open(self):
        if self.running:
            self.send_command("show")
            return self
        self._cleanup_dead()
        context = multiprocessing.get_context("spawn")
        parent_connection, child_connection = context.Pipe()
        self.process = context.Process(
            target=variable_explorer_process_entry,
            args=(child_connection,),
            name="VariableExplorer",
            daemon=True,
        )
        self.connection = parent_connection
        self._closing = False
        try:
            self.process.start()
            child_connection.close()
        except BaseException:
            parent_connection.close(); child_connection.close()
            self.process = None; self.connection = None
            raise
        self.poll_timer.start(); self.monitor_timer.start()
        return self

    show = open

    def send_command(self, operation):
        if not self.running or self.connection is None: return False
        message = {"version": PROTOCOL_VERSION, "kind": "command", "id": 0,
                   "operation": str(operation), "payload": {}}
        try:
            validate_message(message); self.connection.send(message); return True
        except Exception:
            return False

    def _poll(self):
        connection = self.connection
        if connection is None: return
        tick_started = time.perf_counter()
        for _ in range(REQUESTS_PER_TICK):
            if time.perf_counter() - tick_started >= 0.020:
                break
            try:
                if not connection.poll(): break
                request = validate_message(connection.recv())
            except (EOFError, OSError, BrokenPipeError):
                self._monitor(); return
            except Exception as error:
                self.last_error = str(error); continue
            if request.get("kind") == "event":
                self.last_error = str((request.get("payload") or {}).get("traceback", ""))
                continue
            response = {"version": PROTOCOL_VERSION, "kind": "response",
                        "id": int(request.get("id", 0)), "ok": False,
                        "result": {}, "error": ""}
            started = time.perf_counter()
            try:
                response["result"] = self.broker.dispatch(
                    str(request.get("operation", "")), request.get("payload") or {}
                )
                response["ok"] = True
            except Exception as error:
                response["error"] = f"{type(error).__name__}: {error}"
            if time.perf_counter() - started > 0.020:
                response["result"]["inspection_ms"] = round((time.perf_counter() - started) * 1000, 2)
            try:
                validate_message(response); connection.send(response)
            except Exception as error:
                fallback = {"version": PROTOCOL_VERSION, "kind": "response",
                            "id": response["id"], "ok": False, "result": {},
                            "error": f"Response rejected: {error}"}
                try: connection.send(fallback)
                except Exception: break

    def _monitor(self):
        if self.process is None or self.process.is_alive(): return
        self.last_exit_code = self.process.exitcode
        self._cleanup_dead()

    def _cleanup_dead(self):
        self.poll_timer.stop(); self.monitor_timer.stop()
        if self.connection is not None:
            try: self.connection.close()
            except Exception: pass
        if self.process is not None:
            try: self.process.join(timeout=0.1)
            except Exception: pass
        self.connection = None; self.process = None
        self.broker = GlobalsExplorerBroker(self.runtime)

    def prepare_application_shutdown(self):
        self._closing = True
        self.send_command("shutdown")

    def close(self):
        process = self.process
        if process is None: return
        self.prepare_application_shutdown()
        process.join(timeout=2.0)
        if process.is_alive():
            process.terminate(); process.join(timeout=1.0)
        self.last_exit_code = process.exitcode
        self._cleanup_dead()

    def deleteLater(self):
        self.close()
        super().deleteLater()


__all__ = [
    "GlobalsExplorerBroker", "PROTOCOL_VERSION", "RemoteTableModel",
    "VariableExplorerController", "validate_message", "variable_explorer_process_entry",
]
