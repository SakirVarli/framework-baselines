# telnet_widget.py
import ast
import math
import os
import re
import socket
import telnetlib
import threading
import time
from collections import deque
from typing import Optional

from PyQt5 import QtCore, QtGui, QtWidgets

from app.splitter_grid import SplitterGrid
from app.tools.macro_engine import DEFAULT_MACRO_CONFIG, MacroWindow, normalize_macro_config
from app.utils import PROJECT_ROOT, TELNET_SETTINGS, load_json, save_json
from app.tool_api import ToolCallFuture


class _TelnetReader(QtCore.QThread):
    """Background reader thread that continuously pulls bytes from telnet."""

    data_ready = QtCore.pyqtSignal(bytes)
    error = QtCore.pyqtSignal(str)
    connected = QtCore.pyqtSignal()
    disconnected = QtCore.pyqtSignal()

    def __init__(self, host: str, port: int, timeout: float = 5.0, parent=None):
        super().__init__(parent)
        self._host = host
        self._port = port
        self._timeout = timeout
        self._tn: Optional[telnetlib.Telnet] = None
        self._stop = False
        self._queue_lock = threading.RLock()
        self._write_queue = deque()
        self._api_queue = deque()

    def run(self):
        try:
            self._tn = telnetlib.Telnet(self._host, self._port, self._timeout)
            self.connected.emit()
        except Exception as e:
            self.error.emit(f"Connect failed: {e}")
            self.disconnected.emit()
            return

        self._tn.sock.setblocking(False)
        while not self._stop:
            try:
                with self._queue_lock:
                    writes = list(self._write_queue)
                    self._write_queue.clear()
                    calls = list(self._api_queue)
                    self._api_queue.clear()
                for func, future in calls:
                    try:
                        future.set_result(func(self._tn))
                    except BaseException as error:
                        future.set_exception(error)
                for data in writes:
                    self._tn.write(data)

                chunk = self._tn.read_very_eager()
                if chunk:
                    self.data_ready.emit(chunk)
                else:
                    time.sleep(0.03)
            except EOFError:
                self.error.emit("Remote closed the connection.")
                break
            except Exception as e:
                if isinstance(e, (BlockingIOError, InterruptedError)):
                    time.sleep(0.03)
                else:
                    self.error.emit(f"Read error: {e}")
                    time.sleep(0.15)

        try:
            if self._tn is not None:
                self._tn.close()
        except Exception:
            pass
        with self._queue_lock:
            pending = list(self._api_queue)
            self._api_queue.clear()
        for _func, future in pending:
            future.set_exception(RuntimeError("Telnet connection closed"))
        self.disconnected.emit()

    def enqueue_write(self, data: bytes):
        with self._queue_lock:
            self._write_queue.append(bytes(data))

    def write(self, data: bytes):
        """Compatibility alias; writing is queued to the owner thread."""
        self.enqueue_write(data)

    def submit_raw(self, func) -> ToolCallFuture:
        future = ToolCallFuture()
        with self._queue_lock:
            self._api_queue.append((func, future))
        return future

    def stop(self):
        self._stop = True
        try:
            if self._tn is not None:
                self._tn.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass


class TelnetSessionWidget(QtWidgets.QFrame):
    line_sent = QtCore.pyqtSignal(str)
    line_recv = QtCore.pyqtSignal(str)
    select_requested = QtCore.pyqtSignal(object)
    settings_changed = QtCore.pyqtSignal()
    close_requested = QtCore.pyqtSignal(object)

    def __init__(
        self,
        settings=None,
        macros_config=None,
        save_macros_callback=None,
        name="Telnet",
        parent=None,
    ):
        super().__init__(parent)
        self._reader: Optional[_TelnetReader] = None
        self._connected = False
        self._rx_lock = threading.RLock()
        self._rx_text = ""
        self._rx_bytes = b""
        self._macro_window = None
        self._macros_config = normalize_macro_config(macros_config or DEFAULT_MACRO_CONFIG.copy())
        self._save_macros_callback = save_macros_callback
        self._loading_settings = True
        self.session_name = name

        self.setObjectName("telnetSession")
        self.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.setFrameShadow(QtWidgets.QFrame.Raised)
        self.setMinimumSize(360, 260)

        self.title_label = QtWidgets.QLabel(name)
        title_font = self.title_label.font()
        title_font.setBold(True)
        self.title_label.setFont(title_font)

        self.host_edit = QtWidgets.QLineEdit("127.0.0.1")
        self.host_edit.setPlaceholderText("Host")
        self.host_edit.setMinimumWidth(70)

        self.port_spin = QtWidgets.QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.port_spin.setValue(23)
        self.port_spin.setFixedWidth(70)

        self.encoding_combo = QtWidgets.QComboBox()
        self.encoding_combo.addItems(["utf-8", "latin-1", "cp1254", "ascii", "utf-16"])
        self.encoding_combo.setFixedWidth(90)

        self.btn_connection = QtWidgets.QPushButton("Connect")
        self.btn_connection.setFixedWidth(86)
        self.btn_macros = QtWidgets.QPushButton("Macros")
        self.btn_macros.setFixedWidth(74)
        self.btn_close = QtWidgets.QToolButton()
        self.btn_close.setText("X")
        self.btn_close.setToolTip("Close this Telnet connection")
        self.btn_close.setFixedSize(24, 24)
        self.btn_close.setAutoRaise(True)
        self.status_label = QtWidgets.QLabel("Disconnected")

        header = QtWidgets.QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.addWidget(self.title_label)
        header.addStretch(1)
        header.addWidget(self.status_label)
        header.addWidget(self.btn_macros)
        header.addWidget(self.btn_close)

        connection_row = QtWidgets.QHBoxLayout()
        connection_row.setContentsMargins(0, 0, 0, 0)
        connection_row.addWidget(QtWidgets.QLabel("Host"))
        connection_row.addWidget(self.host_edit, 2)
        connection_row.addWidget(QtWidgets.QLabel("Port"))
        connection_row.addWidget(self.port_spin)
        connection_row.addWidget(self.btn_connection)

        self.console = QtWidgets.QTextEdit()
        self.console.setReadOnly(True)
        self.console.setLineWrapMode(QtWidgets.QTextEdit.WidgetWidth)
        self.console.setFont(QtGui.QFont("Consolas", 10))

        self.input_edit = QtWidgets.QLineEdit()
        self.input_edit.setPlaceholderText("Type command and press Enter...")
        self.btn_send = QtWidgets.QPushButton("Send")
        self.btn_send.setFixedWidth(58)
        self.chk_crlf = QtWidgets.QCheckBox("CRLF")
        self.chk_crlf.setChecked(True)
        self.chk_local_echo = QtWidgets.QCheckBox("Echo")
        self.chk_autoscroll = QtWidgets.QCheckBox("Scroll")
        self.chk_autoscroll.setChecked(True)
        self.chk_timestamps = QtWidgets.QCheckBox("Time")

        bottom = QtWidgets.QHBoxLayout()
        bottom.setContentsMargins(0, 0, 0, 0)
        bottom.addWidget(self.input_edit, 1)
        bottom.addWidget(self.btn_send)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.addLayout(header)
        layout.addLayout(connection_row)
        layout.addWidget(self.console, 1)
        layout.addLayout(bottom)

        self.setStyleSheet(
            """
            QFrame#telnetSession {
                border: 1px solid #3a3f48;
                border-radius: 4px;
            }
            QFrame#telnetSession[selected="true"] {
                border: 2px solid #5aa2ff;
            }
            """
        )

        self.btn_connection.clicked.connect(self._on_connection_clicked)
        self.btn_send.clicked.connect(self._on_send_clicked)
        self.input_edit.returnPressed.connect(self._on_send_clicked)
        self.btn_macros.clicked.connect(self._open_macros)
        self.btn_close.clicked.connect(self._on_close_clicked)

        self.host_edit.textChanged.connect(self._notify_settings_changed)
        self.port_spin.valueChanged.connect(self._notify_settings_changed)
        self.encoding_combo.currentTextChanged.connect(self._notify_settings_changed)
        self.chk_crlf.toggled.connect(self._notify_settings_changed)
        self.chk_local_echo.toggled.connect(self._notify_settings_changed)
        self.chk_autoscroll.toggled.connect(self._notify_settings_changed)
        self.chk_timestamps.toggled.connect(self._notify_settings_changed)

        self.apply_settings(settings or {})
        self._loading_settings = False
        self._install_select_filters()

    def apply_settings(self, settings):
        if not isinstance(settings, dict):
            settings = {}
        self._loading_settings = True
        self.session_name = settings.get("name", self.session_name)
        self.title_label.setText(self.session_name)
        self.host_edit.setText(settings.get("host", "127.0.0.1"))
        self.port_spin.setValue(int(settings.get("port", 23)))
        encoding = settings.get("encoding", "utf-8")
        if self.encoding_combo.findText(encoding) >= 0:
            self.encoding_combo.setCurrentText(encoding)
        self.chk_crlf.setChecked(bool(settings.get("append_crlf", True)))
        self.chk_local_echo.setChecked(bool(settings.get("local_echo", False)))
        self.chk_autoscroll.setChecked(bool(settings.get("autoscroll", True)))
        self.chk_timestamps.setChecked(bool(settings.get("timestamps", False)))
        self._loading_settings = False

    def to_settings(self):
        return {
            "name": self.session_name,
            "host": self.host_edit.text().strip(),
            "port": int(self.port_spin.value()),
            "encoding": self.encoding_combo.currentText(),
            "append_crlf": self.chk_crlf.isChecked(),
            "local_echo": self.chk_local_echo.isChecked(),
            "autoscroll": self.chk_autoscroll.isChecked(),
            "timestamps": self.chk_timestamps.isChecked(),
        }

    def set_macros_config(self, macros_config):
        self._macros_config = normalize_macro_config(macros_config)
        if self._macro_window:
            self._macro_window.rebuild(self._macros_config)

    def set_selected(self, selected):
        self.setProperty("selected", bool(selected))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def connect_to_host(self, host: Optional[str] = None, port: Optional[int] = None):
        if self._connected:
            return
        host = host or self.host_edit.text().strip()
        port = int(port if port is not None else self.port_spin.value())
        if not host:
            self._append_system("Host is empty.")
            return

        self._append_system(f"Connecting to {host}:{port} ...")
        self._set_busy(True)

        self._reader = _TelnetReader(host, port, timeout=5.0, parent=self)
        self._reader.data_ready.connect(self._on_bytes)
        self._reader.error.connect(self._on_error)
        self._reader.connected.connect(self._on_connected)
        self._reader.disconnected.connect(self._on_disconnected)
        self._reader.start()
        self._update_buttons()

    def disconnect_from_host(self):
        if not self._connected and not self._reader:
            return
        self._append_system("Disconnecting ...")
        if self._reader is not None:
            self._reader.stop()
            self._reader.wait(1500)
            self._reader = None
        self._connected = False
        self._set_busy(False)
        self._update_buttons()

    def send_text(self, text: str):
        if not self._reader:
            self._append_system("Not connected.")
            return
        payload = text
        if self.chk_crlf.isChecked():
            payload += "\r\n"
        data = payload.encode(self.encoding_combo.currentText(), errors="replace")
        self._reader.write(data)
        if self.chk_local_echo.isChecked():
            self._append_out(f"> {text}")
        self.line_sent.emit(text)

    def is_connected(self) -> bool:
        return bool(self._connected and self._reader)

    def execute_macro_command(self, text: str, expected_return=None, timeout=3, match_type="substring"):
        if not self.is_connected():
            return False, "Not connected"

        expected_return = expected_return if expected_return not in (None, "") else None
        timeout = float(timeout or 3)
        match_type = match_type or "substring"

        with self._rx_lock:
            start_text = len(self._rx_text)
            start_bytes = len(self._rx_bytes)

        payload = text
        if self.chk_crlf.isChecked() and not payload.endswith(("\r", "\n")):
            payload += "\r\n"

        self._reader.write(payload.encode(self.encoding_combo.currentText(), errors="replace"))
        self._append_out(f"> {text}")
        self.line_sent.emit(text)

        if expected_return is None:
            return True, ""

        deadline = time.time() + timeout
        last_text = ""
        while time.time() < deadline:
            with self._rx_lock:
                new_text = self._rx_text[start_text:]
                new_bytes = self._rx_bytes[start_bytes:]
            last_text = new_text
            if self._match_response(new_bytes, new_text, expected_return, match_type):
                return True, new_text
            time.sleep(0.05)

        return False, last_text

    def append_text(self, text: str):
        self._append_out(text)

    def _on_connection_clicked(self):
        if self._connected or self._reader:
            self.disconnect_from_host()
        else:
            self.connect_to_host()

    def _on_send_clicked(self):
        text = self.input_edit.text()
        if not text and self.chk_crlf.isChecked():
            text = ""
        self.input_edit.clear()
        self.send_text(text)

    def _on_close_clicked(self):
        self.select_requested.emit(self)
        self.close_requested.emit(self)

    def _on_connected(self):
        self._connected = True
        self._append_system("Connected.")
        self._set_busy(False)
        self._update_buttons()

    def _on_disconnected(self):
        self._connected = False
        self._reader = None
        self._append_system("Disconnected.")
        self._set_busy(False)
        self._update_buttons()

    def _on_error(self, msg: str):
        html = f'<span style="color:#d55;">{self._escape(self._timestamp() + "[Error] " + msg)}</span>'
        self._insert_html(html)

    def _on_bytes(self, data: bytes):
        text = data.decode(self.encoding_combo.currentText(), errors="replace")
        with self._rx_lock:
            self._rx_bytes += data
            self._rx_text += text
            if len(self._rx_bytes) > 1_000_000:
                self._rx_bytes = self._rx_bytes[-500_000:]
            if len(self._rx_text) > 1_000_000:
                self._rx_text = self._rx_text[-500_000:]
        for line in text.splitlines():
            self.line_recv.emit(line)
        self._append_in(text)

    def _insert_html(self, html: str):
        cursor = self.console.textCursor()
        cursor.movePosition(QtGui.QTextCursor.End)
        if not self.console.document().isEmpty():
            cursor.insertBlock()
        cursor.insertHtml(html)
        self.console.setTextCursor(cursor)
        if self.chk_autoscroll.isChecked():
            self.console.moveCursor(QtGui.QTextCursor.End)

    def _append_in(self, text: str):
        self._append(text, in_stream=True)

    def _append_out(self, text: str):
        self._append(text, in_stream=False)

    def _append(self, text: str, in_stream: bool):
        color = "#b8f" if in_stream else "#8b8"
        html = f'<span style="color:{color}">{self._escape(self._maybe_timestamp() + text)}</span>'
        self._insert_html(html.replace("\n", "<br/>"))

    def _append_system(self, text: str):
        html = f'<span style="color:#aaa">{self._escape(self._timestamp() + text)}</span>'
        self._insert_html(html)

    def _match_response(self, buffer_bytes, buffer_text, expected_return, match_type):
        try:
            if match_type == "binary":
                if isinstance(expected_return, bytes):
                    expected_bytes = expected_return
                elif isinstance(expected_return, str) and expected_return.strip().startswith((r"b'", 'b"')):
                    expected_bytes = ast.literal_eval(expected_return.strip())
                else:
                    expected_bytes = bytes.fromhex(str(expected_return).replace(" ", ""))
                return expected_bytes in buffer_bytes
            if match_type == "regex":
                return re.search(str(expected_return), buffer_text) is not None
            return str(expected_return) in buffer_text
        except Exception as e:
            self._append_system(f"Macro match error: {e}")
            return False

    def _open_macros(self):
        self.select_requested.emit(self)
        if self._macro_window and self._macro_window.isVisible():
            self._macro_window.raise_()
            self._macro_window.activateWindow()
            return
        self._macro_window = MacroWindow(
            self,
            self._macros_config,
            self,
            title=self.macro_window_title(),
        )
        self._macro_window.show()

    def _edit_macros(self):
        self.select_requested.emit(self)
        from app.tools.macro_editor import MacroEditorDialog

        dlg = MacroEditorDialog(self._macros_config, self)

        def on_saved(macros_config, apply_now):
            self.save_macros_config(macros_config)
            if apply_now and self._macro_window:
                self._macro_window.rebuild(self._macros_config)

        dlg.macros_saved.connect(on_saved)
        dlg.exec_()

    def save_macros_config(self, macros_config):
        self._macros_config = normalize_macro_config(macros_config)
        if self._save_macros_callback:
            self._save_macros_callback(self._macros_config)

    def macro_window_title(self):
        match = re.search(r"(\d+)\s*$", self.session_name or "")
        suffix = f" {match.group(1)}" if match else f" - {self.session_name}"
        return f"Telnet Macros{suffix}"

    def _notify_settings_changed(self):
        if not self._loading_settings:
            self.settings_changed.emit()

    def _set_busy(self, busy: bool):
        self.setCursor(QtCore.Qt.WaitCursor if busy else QtCore.Qt.ArrowCursor)

    def _update_buttons(self):
        self.btn_connection.setText("Disconnect" if (self._connected or self._reader) else "Connect")
        if self._connected:
            self.status_label.setText("Connected")
        elif self._reader:
            self.status_label.setText("Connecting")
        else:
            self.status_label.setText("Disconnected")

    def _install_select_filters(self):
        self.installEventFilter(self)
        for child in self.findChildren(QtWidgets.QWidget):
            child.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.MouseButtonPress:
            self.select_requested.emit(self)
        return super().eventFilter(obj, event)

    @staticmethod
    def _escape(text: str) -> str:
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    @staticmethod
    def _timestamp() -> str:
        return time.strftime("[%H:%M:%S] ")

    def _maybe_timestamp(self) -> str:
        return self._timestamp() if self.chk_timestamps.isChecked() else ""

    def closeEvent(self, ev: QtGui.QCloseEvent):
        try:
            self.disconnect_from_host()
        finally:
            super().closeEvent(ev)


class TelnetWidget(QtWidgets.QFrame):
    """Workspace wrapper that hosts one or more standalone Telnet sessions."""

    def __init__(
        self,
        default_host: str = "127.0.0.1",
        default_port: int = 23,
        default_encoding: str = "utf-8",
        show_timestamps: bool = False,
        parent=None,
    ):
        super().__init__(parent)
        self.resize(920, 620)
        self.setWindowTitle("Telnet")
        self.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.setFrameShadow(QtWidgets.QFrame.Raised)

        self.sessions = []
        self._selected_session = None
        self._grid = None
        self._workspace_macro_window = None
        self._loading_settings = True
        self._syncing_option_menu = False
        self._macros_config = normalize_macro_config(DEFAULT_MACRO_CONFIG.copy())
        self._default_session = {
            "name": "Telnet 1",
            "host": default_host,
            "port": int(default_port),
            "encoding": default_encoding,
            "append_crlf": True,
            "local_echo": False,
            "autoscroll": True,
            "timestamps": bool(show_timestamps),
        }

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.menu_bar = QtWidgets.QMenuBar()
        file_menu = self.menu_bar.addMenu("File")
        self.act_new_connection = file_menu.addAction("New Connection")
        self.act_close_connection = file_menu.addAction("Close Selected Connection")
        self.act_close_all = file_menu.addAction("Close All Connections")

        self.options_menu = self.menu_bar.addMenu("Options")
        self._build_options_menu()

        macros_menu = self.menu_bar.addMenu("Macros")
        self.act_open_macros = macros_menu.addAction("Open Macros")
        self.act_edit_macros = macros_menu.addAction("Edit Macros")
        outer.addWidget(self.menu_bar)

        self._content = QtWidgets.QWidget()
        self._content_layout = QtWidgets.QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(6, 6, 6, 6)
        self._content_layout.setSpacing(0)
        outer.addWidget(self._content, 1)

        self.act_new_connection.triggered.connect(self._new_connection)
        self.act_close_connection.triggered.connect(self._close_selected_session)
        self.act_close_all.triggered.connect(self._close_all_sessions)
        self.act_open_macros.triggered.connect(self._open_selected_macros)
        self.act_edit_macros.triggered.connect(self._edit_selected_macros)

        settings = self._read_settings()
        self._macros_config = self._load_macros_config(settings)
        for session_settings in self._session_settings_from_data(settings):
            self._add_session(session_settings, save=False)

        if not self.sessions:
            self._add_session(dict(self._default_session), save=False)

        self._loading_settings = False
        self._sync_options_menu()

    def _build_options_menu(self):
        self.act_options_scope = self.options_menu.addAction("Options affect selected Telnet only")
        self.act_options_scope.setEnabled(False)
        self.options_menu.addSeparator()

        encoding_menu = self.options_menu.addMenu("Encoding")
        self._encoding_actions = {}
        self._encoding_group = QtWidgets.QActionGroup(self)
        self._encoding_group.setExclusive(True)
        for encoding in ["utf-8", "latin-1", "cp1254", "ascii", "utf-16"]:
            action = encoding_menu.addAction(encoding)
            action.setCheckable(True)
            action.setData(encoding)
            self._encoding_group.addAction(action)
            self._encoding_actions[encoding] = action
        self._encoding_group.triggered.connect(self._on_encoding_action)

        self.options_menu.addSeparator()
        self.act_append_crlf = self.options_menu.addAction("Append CRLF")
        self.act_local_echo = self.options_menu.addAction("Local Echo")
        self.act_autoscroll = self.options_menu.addAction("Auto-scroll")
        self.act_timestamps = self.options_menu.addAction("Timestamps")
        for action in [self.act_append_crlf, self.act_local_echo, self.act_autoscroll, self.act_timestamps]:
            action.setCheckable(True)

        self.act_append_crlf.toggled.connect(lambda checked: self._set_selected_option("crlf", checked))
        self.act_local_echo.toggled.connect(lambda checked: self._set_selected_option("echo", checked))
        self.act_autoscroll.toggled.connect(lambda checked: self._set_selected_option("scroll", checked))
        self.act_timestamps.toggled.connect(lambda checked: self._set_selected_option("timestamps", checked))

        self.options_menu.addSeparator()
        self.act_apply_options_all = self.options_menu.addAction("Apply Current Options to All")
        self.act_apply_options_all.triggered.connect(self._apply_selected_options_to_all)

    def _new_connection(self):
        settings = dict(self._default_session)
        settings["name"] = f"Telnet {len(self.sessions) + 1}"
        self._add_session(settings, save=True)

    def _add_session(self, settings=None, save=True):
        settings = dict(settings or self._default_session)
        settings.setdefault("name", f"Telnet {len(self.sessions) + 1}")
        session = TelnetSessionWidget(
            settings=settings,
            macros_config=self._macros_config,
            save_macros_callback=self._save_macros_config,
            name=settings["name"],
            parent=self,
        )
        session.select_requested.connect(self._select_session)
        session.settings_changed.connect(self._save_settings)
        session.close_requested.connect(self._remove_session)
        self.sessions.append(session)
        self._rebuild_grid()
        self._select_session(session)
        if save:
            self._save_settings()
        return session

    def _close_selected_session(self):
        if self._selected_session is None:
            return
        self._remove_session(self._selected_session)

    def _close_all_sessions(self):
        for session in list(self.sessions):
            self._remove_session(session, ensure_one=False)
        if not self.sessions:
            self._add_session(dict(self._default_session), save=False)
        self._save_settings()

    def _remove_session(self, session, ensure_one=True):
        if session not in self.sessions:
            return
        session.disconnect_from_host()
        self._detach_session_from_grid(session)
        self.sessions.remove(session)
        session.setParent(None)
        session.deleteLater()

        if not self.sessions and ensure_one:
            self._add_session(dict(self._default_session), save=False)
        else:
            self._rebuild_grid()
            self._select_session(self.sessions[-1] if self.sessions else None)
        self._save_settings()

    def _open_selected_macros(self):
        session = self._selected_or_first_session()
        if session:
            self._show_workspace_macros(session)

    def _edit_selected_macros(self):
        session = self._selected_or_first_session()
        if session:
            session._edit_macros()

    def _save_macros_config(self, macros_config):
        self._macros_config = normalize_macro_config(macros_config)
        for session in self.sessions:
            session.set_macros_config(self._macros_config)
        if self._workspace_macro_window and self._workspace_macro_window.isVisible():
            session = self._selected_or_first_session()
            if session:
                self._workspace_macro_window.set_session_widget(
                    session,
                    self._macros_config,
                    title=session.macro_window_title(),
                )
        self._save_settings()

    def _select_session(self, session):
        self._selected_session = session if session in self.sessions else None
        for item in self.sessions:
            item.set_selected(item is self._selected_session)
        self._sync_options_menu()
        if self._selected_session and self._workspace_macro_window and self._workspace_macro_window.isVisible():
            self._workspace_macro_window.set_session_widget(
                self._selected_session,
                self._macros_config,
                title=self._selected_session.macro_window_title(),
            )

    def _selected_or_first_session(self):
        if self._selected_session in self.sessions:
            return self._selected_session
        return self.sessions[0] if self.sessions else None

    def _on_encoding_action(self, action):
        if self._syncing_option_menu:
            return
        session = self._selected_or_first_session()
        if session is None:
            return
        encoding = action.data()
        if encoding and session.encoding_combo.findText(encoding) >= 0:
            session.encoding_combo.setCurrentText(encoding)

    def _set_selected_option(self, option, checked):
        if self._syncing_option_menu:
            return
        session = self._selected_or_first_session()
        if session is None:
            return
        if option == "crlf":
            session.chk_crlf.setChecked(bool(checked))
        elif option == "echo":
            session.chk_local_echo.setChecked(bool(checked))
        elif option == "scroll":
            session.chk_autoscroll.setChecked(bool(checked))
        elif option == "timestamps":
            session.chk_timestamps.setChecked(bool(checked))

    def _sync_options_menu(self):
        session = self._selected_or_first_session()
        enabled = session is not None
        self._syncing_option_menu = True
        try:
            self.options_menu.setEnabled(enabled)
            self.act_options_scope.setEnabled(False)
            for action in self._encoding_actions.values():
                action.setEnabled(enabled)
                action.setChecked(enabled and action.data() == session.encoding_combo.currentText())
            self.act_append_crlf.setEnabled(enabled)
            self.act_local_echo.setEnabled(enabled)
            self.act_autoscroll.setEnabled(enabled)
            self.act_timestamps.setEnabled(enabled)
            self.act_apply_options_all.setEnabled(enabled and len(self.sessions) > 1)
            self.act_append_crlf.setChecked(enabled and session.chk_crlf.isChecked())
            self.act_local_echo.setChecked(enabled and session.chk_local_echo.isChecked())
            self.act_autoscroll.setChecked(enabled and session.chk_autoscroll.isChecked())
            self.act_timestamps.setChecked(enabled and session.chk_timestamps.isChecked())
        finally:
            self._syncing_option_menu = False

    def _apply_selected_options_to_all(self):
        source = self._selected_or_first_session()
        if source is None:
            return

        encoding = source.encoding_combo.currentText()
        append_crlf = source.chk_crlf.isChecked()
        local_echo = source.chk_local_echo.isChecked()
        autoscroll = source.chk_autoscroll.isChecked()
        timestamps = source.chk_timestamps.isChecked()

        for session in self.sessions:
            if session.encoding_combo.findText(encoding) >= 0:
                session.encoding_combo.setCurrentText(encoding)
            session.chk_crlf.setChecked(append_crlf)
            session.chk_local_echo.setChecked(local_echo)
            session.chk_autoscroll.setChecked(autoscroll)
            session.chk_timestamps.setChecked(timestamps)

        self._sync_options_menu()
        self._save_settings()

    def _show_workspace_macros(self, session):
        if self._workspace_macro_window and self._workspace_macro_window.isVisible():
            self._workspace_macro_window.set_session_widget(
                session,
                self._macros_config,
                title=session.macro_window_title(),
            )
            self._workspace_macro_window.raise_()
            self._workspace_macro_window.activateWindow()
            return
        self._workspace_macro_window = MacroWindow(
            session,
            self._macros_config,
            self,
            title=session.macro_window_title(),
        )
        self._workspace_macro_window.show()

    def _rebuild_grid(self):
        old_grid = self._grid
        if old_grid is not None:
            for session in self.sessions:
                self._take_session_from_grid(old_grid, session)
            self._content_layout.removeWidget(old_grid)
            old_grid.deleteLater()

        rows, cols = self._grid_shape(len(self.sessions))
        self._grid = SplitterGrid(rows, cols, self)
        self._content_layout.addWidget(self._grid, 1)
        for index, session in enumerate(self.sessions):
            row = index // cols
            col = index % cols
            self._grid.addWidget(session, row, col)
        self._grid.distribute_evenly()
        QtCore.QTimer.singleShot(0, self._grid.distribute_evenly)

    def _detach_session_from_grid(self, session):
        if self._grid is None:
            return
        self._take_session_from_grid(self._grid, session)

    @staticmethod
    def _take_session_from_grid(grid, session):
        for (row, col), widget in list(grid._cells.items()):
            if widget is session:
                grid.takeWidget(row, col)
                return

    @staticmethod
    def _grid_shape(count):
        count = max(1, int(count))
        if count == 1:
            return 1, 1
        if count == 2:
            return 1, 2
        cols = min(3, math.ceil(math.sqrt(count)))
        rows = math.ceil(count / cols)
        return rows, cols

    def _read_settings(self):
        try:
            data = load_json(TELNET_SETTINGS)
        except Exception:
            data = {}
        return data if isinstance(data, dict) else {}

    def _session_settings_from_data(self, data):
        workspace = data.get("workspace") if isinstance(data, dict) else None
        sessions = workspace.get("sessions") if isinstance(workspace, dict) else None
        if isinstance(sessions, list) and sessions:
            return [item for item in sessions if isinstance(item, dict)]

        legacy_keys = {"host", "port", "encoding", "append_crlf", "local_echo", "autoscroll", "timestamps"}
        if isinstance(data, dict) and legacy_keys.intersection(data):
            settings = dict(self._default_session)
            settings.update({key: data[key] for key in legacy_keys if key in data})
            settings["name"] = data.get("name", "Telnet 1")
            return [settings]
        return [dict(self._default_session)]

    def _load_macros_config(self, settings_data=None):
        data = settings_data if isinstance(settings_data, dict) else self._read_settings()
        macros = data.get("macros") if isinstance(data, dict) else None
        if macros:
            return normalize_macro_config(macros)

        legacy_path = os.path.join(PROJECT_ROOT, "TELNET", "config", "config.json")
        legacy = load_json(legacy_path)
        if isinstance(legacy, dict) and legacy.get("tabs"):
            return normalize_macro_config({
                "last_tab_index": legacy.get("last_tab_index", 0),
                "tabs": legacy.get("tabs", []),
            })
        return normalize_macro_config(DEFAULT_MACRO_CONFIG.copy())

    def _save_settings(self):
        if self._loading_settings:
            return
        data = self._read_settings()
        data["workspace"] = {
            "sessions": [session.to_settings() for session in self.sessions],
        }
        data["macros"] = normalize_macro_config(self._macros_config)

        if self.sessions:
            data.update(self.sessions[0].to_settings())

        try:
            save_json(TELNET_SETTINGS, data)
        except Exception as e:
            print(f"Failed to save telnet settings: {e}")

    def closeEvent(self, ev: QtGui.QCloseEvent):
        try:
            for session in list(self.sessions):
                session.disconnect_from_host()
            self._save_settings()
        finally:
            super().closeEvent(ev)
