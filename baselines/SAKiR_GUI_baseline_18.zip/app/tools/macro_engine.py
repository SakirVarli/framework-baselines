import copy
import os
import re
import struct
import threading
from functools import partial

from PyQt5 import QtCore, QtGui, QtWidgets

from app.path_utils import abs_to_rel_project, is_abs_path, resolve_config_path


DEFAULT_MACRO_CONFIG = {
    "layout": "3x3",
    "buttons": []
}


def safe_get(data, key, default=None):
    if isinstance(data, dict):
        value = data.get(key)
        return default if value is None else value
    return default


def normalize_macro_config(config):
    if not isinstance(config, dict):
        config = copy.deepcopy(DEFAULT_MACRO_CONFIG)

    # Backward compatibility: old TELNET macro configs used tabs.
    if "tabs" in config and "buttons" not in config:
        flattened = []
        layout = "3x3"
        for tab in config.get("tabs", []) or []:
            if not isinstance(tab, dict):
                continue
            layout = tab.get("layout") or layout
            flattened.extend(copy.deepcopy(tab.get("buttons", []) or []))
        config = {"layout": layout, "buttons": flattened}

    config.setdefault("layout", "3x3")
    buttons = config.get("buttons")
    if not isinstance(buttons, list):
        config["buttons"] = []

    for button in config["buttons"]:
        if not isinstance(button, dict):
            continue
        button.setdefault("name", "Macro")
        button.setdefault("position", "")
        button.setdefault("style", {})
        button.setdefault("password", "")
        button.setdefault("commands", [])
        button.setdefault("preprocessing", {"enabled": False, "steps": []})
        button.setdefault("precheck", {"enabled": False, "steps": []})
        _normalize_file_steps(button["preprocessing"].get("steps", []))
        _normalize_file_steps(button["precheck"].get("steps", []))

    return config


def _normalize_file_steps(steps):
    for step in steps:
        if not isinstance(step, dict):
            continue
        if "file_relative" not in step:
            path = step.get("file", "")
            if path and is_abs_path(path):
                rel = abs_to_rel_project(path)
                if not is_abs_path(rel):
                    step["file"] = rel
                    step["file_relative"] = True
                else:
                    step["file_relative"] = False
            elif path:
                step["file_relative"] = True
            else:
                step["file_relative"] = False


class PrecheckDialog(QtWidgets.QDialog):
    def __init__(self, results, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Precheck Inspection")
        self.resize(900, 420)

        layout = QtWidgets.QVBoxLayout(self)
        title = QtWidgets.QLabel("Review Precheck Values Before Execution")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)

        self.table = QtWidgets.QTableWidget(len(results), 6)
        self.table.setHorizontalHeaderLabels([
            "Step", "File", "Type", "Field / Range", "Actual Value", "Expected Value"
        ])
        self.table.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.table.setSelectionMode(QtWidgets.QTableWidget.NoSelection)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.cellDoubleClicked.connect(self._handle_double_click)
        layout.addWidget(self.table, 1)

        for row, result in enumerate(results):
            self._populate_row(row, result)

        self.table.resizeColumnsToContents()

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok
        )
        buttons.button(QtWidgets.QDialogButtonBox.Ok).setText("Continue")
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)

    def _handle_double_click(self, row, column):
        if column != 1:
            return
        item = self.table.item(row, column)
        path = item.data(QtCore.Qt.UserRole) if item else None
        if not path:
            return
        if not os.path.exists(path):
            QtWidgets.QMessageBox.warning(self, "File Not Found", path)
            return
        if os.name == "nt":
            os.startfile(path)

    def _populate_row(self, row, result):
        full_path = result.get("full_path")
        display_name = os.path.basename(full_path) if full_path else "-"

        cells = [
            str(row + 1),
            display_name,
            result.get("type", "-"),
            result.get("field") or result.get("range") or "-",
            self._actual_text(result),
            str(result.get("expected")) if result.get("expected") is not None else "-",
        ]

        for col, text in enumerate(cells):
            item = QtWidgets.QTableWidgetItem(text)
            if col == 1 and full_path:
                item.setData(QtCore.Qt.UserRole, full_path)
            if col in (0, 2):
                item.setTextAlignment(QtCore.Qt.AlignCenter)
            self.table.setItem(row, col, item)

        color = self._row_color(result)
        if color:
            for col in (4, 5):
                item = self.table.item(row, col)
                if item:
                    item.setBackground(color)

    def _actual_text(self, result):
        if result.get("error"):
            return "Error: " + str(result.get("error"))
        actual = result.get("actual")
        return str(actual) if actual is not None else "-"

    def _row_color(self, result):
        if result.get("error"):
            return QtGui.QColor("#f6acb2")
        expected = result.get("expected")
        if expected is None:
            return None
        return QtGui.QColor("#89ea9f") if str(result.get("actual")) == str(expected) else QtGui.QColor("#f6acb2")


class MacroEngine(QtCore.QObject):
    log_requested = QtCore.pyqtSignal(str)
    button_color_requested = QtCore.pyqtSignal(object, str)
    precheck_ready = QtCore.pyqtSignal(object, object, object)

    def __init__(self, session_widget, parent=None, transport_name="Telnet"):
        super().__init__(parent)
        self.session_widget = session_widget
        self.transport_name = transport_name
        self.precheck_ready.connect(self._show_precheck_dialog)

    def log(self, message):
        self.log_requested.emit(message)

    def run_button(self, button, button_config):
        password = safe_get(button_config, "password", "")
        if password:
            entered, ok = QtWidgets.QInputDialog.getText(
                button,
                "Password Required",
                f"Enter password for '{button.text()}'",
                QtWidgets.QLineEdit.Password
            )
            if not ok or entered != password:
                self.log(f"Incorrect password for macro '{button.text()}'.")
                return

        commands = safe_get(button_config, "commands", [])
        if not commands:
            self.log(f"Macro '{button.text()}' has no commands configured.")
            return

        thread = threading.Thread(
            target=self._run_button_worker,
            args=(button, button_config),
            daemon=True
        )
        thread.start()

    def _run_button_worker(self, button, button_config):
        self.button_color_requested.emit(button, "yellow")

        preprocessing = safe_get(button_config, "preprocessing", {"enabled": False, "steps": []})
        if preprocessing.get("enabled"):
            for step in preprocessing.get("steps", []):
                if not self.apply_xml_preprocess(step):
                    self.button_color_requested.emit(button, "red")
                    return

        precheck = safe_get(button_config, "precheck", {"enabled": False, "steps": []})
        if precheck.get("enabled"):
            results = [self.execute_precheck_step(step) for step in precheck.get("steps", [])]
            self.precheck_ready.emit(button, results, button_config)
            return

        self._execute_commands(button, safe_get(button_config, "commands", []))

    def _show_precheck_dialog(self, button, results, button_config):
        dialog = PrecheckDialog(results, parent=self.session_widget)
        if dialog.exec_() == QtWidgets.QDialog.Accepted:
            thread = threading.Thread(
                target=self._execute_commands,
                args=(button, safe_get(button_config, "commands", [])),
                daemon=True
            )
            thread.start()
        else:
            self.button_color_requested.emit(button, None)
            self.log("Macro execution cancelled by user.")

    def apply_xml_preprocess(self, step):
        file_path = resolve_config_path(step.get("file", ""), bool(step.get("file_relative", False)))
        key = step.get("key", "")
        new_value = step.get("value", "")

        try:
            if not file_path or not os.path.exists(file_path):
                self.log(f"Preprocess file not found: {file_path}")
                return False

            with open(file_path, "r", encoding="utf-8") as handle:
                content = handle.read()

            modified = False

            attr_pattern = re.compile(rf'({re.escape(key)}\s*=\s*")([^"]*)(")', flags=re.MULTILINE)

            def attr_replacer(match):
                nonlocal modified
                modified = True
                return match.group(1) + new_value + match.group(3)

            content = attr_pattern.sub(attr_replacer, content)

            tag_pattern = re.compile(
                rf'(<{re.escape(key)}\b[^>]*>)(.*?)(</{re.escape(key)}>)',
                flags=re.DOTALL
            )

            def tag_replacer(match):
                nonlocal modified
                modified = True
                return match.group(1) + new_value + match.group(3)

            content = tag_pattern.sub(tag_replacer, content)

            if not modified:
                self.log(f"Preprocess key '{key}' not found in {file_path}.")
                return False

            with open(file_path, "w", encoding="utf-8") as handle:
                handle.write(content)

            self.log(f"Updated '{key}' in {file_path} as {new_value}.")
            return True
        except Exception as exc:
            self.log(f"XML preprocess error: {exc}")
            return False

    def execute_precheck_step(self, step):
        file_path = resolve_config_path(step.get("file", ""), bool(step.get("file_relative", False)))
        filename = os.path.basename(file_path) if file_path else "N/A"
        type_ = step.get("type", "xml")

        if not file_path or not os.path.exists(file_path):
            return {"file": filename, "full_path": file_path, "type": type_, "error": "File not found"}

        try:
            if type_ == "xml":
                return self._execute_xml_precheck(step, file_path, filename)
            return self._execute_binary_precheck(step, file_path, filename)
        except Exception as exc:
            return {
                "file": filename,
                "full_path": file_path,
                "type": type_,
                "error": str(exc)
            }

    def _execute_xml_precheck(self, step, file_path, filename):
        key = step.get("key", "")
        expected = step.get("expected")
        with open(file_path, "r", encoding="utf-8") as handle:
            content = handle.read()
        match = re.search(rf'<{re.escape(key)}[^>]*>(.*?)</{re.escape(key)}>', content, re.DOTALL)
        actual = match.group(1).strip() if match else None
        return {
            "file": filename,
            "full_path": file_path,
            "type": "XML",
            "field": f"<{key}>",
            "actual": actual,
            "expected": expected if expected != "" else None
        }

    def _execute_binary_precheck(self, step, file_path, filename):
        index = int(step.get("index", 0))
        length = int(step.get("length", 1))
        endian = step.get("endianness", "little")
        dtype = step.get("dtype", "uint")
        expected = self._parse_expected(step.get("expected"), dtype)

        with open(file_path, "rb") as handle:
            handle.seek(index)
            data = handle.read(length)

        if not data or len(data) != length:
            return {
                "file": filename,
                "full_path": file_path,
                "type": "Binary",
                "range": f"{index} - {index + length - 1}",
                "error": "Could not read enough bytes"
            }

        if dtype == "uint":
            actual = int.from_bytes(data, endian, signed=False)
        elif dtype == "int":
            actual = int.from_bytes(data, endian, signed=True)
        elif dtype == "float":
            if length == 4:
                actual = struct.unpack("<f" if endian == "little" else ">f", data)[0]
            elif length == 8:
                actual = struct.unpack("<d" if endian == "little" else ">d", data)[0]
            else:
                return {
                    "file": filename,
                    "full_path": file_path,
                    "type": "Binary",
                    "range": f"{index} - {index + length - 1}",
                    "error": "Float must be 4 or 8 bytes"
                }
        else:
            return {
                "file": filename,
                "full_path": file_path,
                "type": "Binary",
                "range": f"{index} - {index + length - 1}",
                "error": f"Unsupported dtype: {dtype}"
            }

        return {
            "file": filename,
            "full_path": file_path,
            "type": "Binary",
            "range": f"{index} - {index + length - 1}",
            "actual": actual,
            "expected": expected
        }

    def _parse_expected(self, value, dtype):
        if value in (None, ""):
            return None
        try:
            return float(value) if dtype == "float" else int(value)
        except Exception:
            return value

    def _execute_commands(self, button, commands):
        all_success = True
        if not self.session_widget.is_connected():
            self.log(f"Cannot run macro: {self.transport_name} widget is not connected.")
            self.button_color_requested.emit(button, "red")
            return

        for command_config in commands:
            command = safe_get(command_config, "command", "")
            expected = command_config.get("expected_return")
            timeout = safe_get(command_config, "timeout", 3)
            match_type = safe_get(command_config, "match_type", "substring")

            ok, response = self.session_widget.execute_macro_command(
                command,
                expected_return=expected,
                timeout=timeout,
                match_type=match_type
            )
            if not ok:
                all_success = False
                self.log(f"Macro command failed: {command}")
                if response:
                    self.log(f"Last response: {response}")
                break

        self.button_color_requested.emit(button, "lightgreen" if all_success else "red")


class MacroWindow(QtWidgets.QDialog):
    def __init__(self, session_widget, macros_config, parent=None, title=None, transport_name="Telnet"):
        super().__init__(parent or session_widget)
        self.macros_config = normalize_macro_config(copy.deepcopy(macros_config))
        self.engine = None
        self.session_widget = None
        self.transport_name = transport_name
        self._bind_session_widget(session_widget)

        self.setWindowTitle(title or f"{self.transport_name} Macros")

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        self.board = QtWidgets.QWidget()
        self.board_layout = QtWidgets.QGridLayout(self.board)
        self.board_layout.setContentsMargins(0, 0, 0, 0)
        self.board_layout.setSpacing(8)
        layout.addWidget(self.board, 1)
        self.rebuild(self.macros_config)

    def set_session_widget(self, session_widget, macros_config=None, title=None):
        if macros_config is not None:
            self.macros_config = normalize_macro_config(copy.deepcopy(macros_config))
        self._bind_session_widget(session_widget)
        if title:
            self.setWindowTitle(title)
        self.rebuild(self.macros_config)

    def set_telnet_widget(self, session_widget, macros_config=None, title=None):
        self.set_session_widget(session_widget, macros_config=macros_config, title=title)

    def _bind_session_widget(self, session_widget):
        if self.engine is not None:
            try:
                self.engine.log_requested.disconnect()
            except Exception:
                pass
            try:
                self.engine.button_color_requested.disconnect()
            except Exception:
                pass
        self.session_widget = session_widget
        self.engine = MacroEngine(session_widget, self, transport_name=self.transport_name)
        self.engine.log_requested.connect(self.session_widget.append_text)
        self.engine.button_color_requested.connect(self._apply_button_color)

    def rebuild(self, macros_config):
        self.macros_config = normalize_macro_config(copy.deepcopy(macros_config))
        self._clear_grid()

        rows, cols = self._parse_layout(self.macros_config.get("layout", "3x3"))
        taken = set()

        for index, button_config in enumerate(self.macros_config.get("buttons", [])):
            row, col = self._button_position(button_config, rows, cols, taken)
            if row is None:
                continue
            taken.add((row, col))

            button = QtWidgets.QPushButton(button_config.get("name", f"Macro {index + 1}"))
            self._apply_initial_style(button, button_config.get("style", {}))
            button.clicked.connect(partial(self.engine.run_button, button, button_config))
            self.board_layout.addWidget(button, row, col)

        for row in range(rows):
            self.board_layout.setRowStretch(row, 1)
        for col in range(cols):
            self.board_layout.setColumnStretch(col, 1)

        self._resize_to_board(rows, cols)

    def _clear_grid(self):
        while self.board_layout.count():
            item = self.board_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def _parse_layout(self, value):
        try:
            left, right = str(value).lower().split("x", 1)
            return max(1, int(left)), max(1, int(right))
        except Exception:
            return 3, 3

    def _button_position(self, button_config, rows, cols, taken):
        pos = button_config.get("position", "")
        if pos:
            try:
                row_s, col_s = str(pos).lower().split("x", 1)
                row, col = int(row_s) - 1, int(col_s) - 1
                if 0 <= row < rows and 0 <= col < cols:
                    return row, col
            except Exception:
                pass

        for row in range(rows):
            for col in range(cols):
                if (row, col) not in taken:
                    return row, col
        return None, None

    def _apply_initial_style(self, button, style):
        width = style.get("width")
        height = style.get("height")
        if width and height:
            button.setFixedSize(int(width), int(height))
        elif width:
            button.setFixedWidth(int(width))
        elif height:
            button.setFixedHeight(int(height))

        icon = style.get("icon")
        if icon and os.path.exists(icon):
            button.setIcon(QtGui.QIcon(icon))

        button._macro_base_color = style.get("color", "")
        button._macro_base_text_color = style.get("text_color", "")
        self._apply_button_color(button, None)

    def _apply_button_color(self, button, color, text_color=""):
        if not isinstance(button, QtWidgets.QPushButton):
            return
        if color is None or color == "":
            color = getattr(button, "_macro_base_color", "")
            text_color = getattr(button, "_macro_base_text_color", "")
        elif not text_color:
            text_color = self._contrast_text_color(color)
        style = ""
        if color:
            style += f"background-color: {color};"
        if text_color:
            style += f"color: {text_color};"
        button.setStyleSheet(style)

    def _contrast_text_color(self, color):
        qcolor = QtGui.QColor(color)
        if not qcolor.isValid():
            return ""
        brightness = (0.299 * qcolor.red() + 0.587 * qcolor.green() + 0.114 * qcolor.blue())
        return "#000000" if brightness > 160 else "#ffffff"

    def _resize_to_board(self, rows, cols):
        buttons = [
            self.board_layout.itemAt(i).widget()
            for i in range(self.board_layout.count())
            if self.board_layout.itemAt(i).widget() is not None
        ]

        if buttons:
            cell_w = max(button.sizeHint().width() for button in buttons)
            cell_h = max(button.sizeHint().height() for button in buttons)
            for button in buttons:
                if button.minimumWidth() > 0:
                    cell_w = max(cell_w, button.minimumWidth())
                if button.minimumHeight() > 0:
                    cell_h = max(cell_h, button.minimumHeight())
                if button.maximumWidth() < 16777215:
                    cell_w = max(cell_w, button.width())
                if button.maximumHeight() < 16777215:
                    cell_h = max(cell_h, button.height())
        else:
            cell_w, cell_h = 110, 42

        spacing = self.board_layout.spacing()
        margins = self.layout().contentsMargins()
        width = cols * cell_w + max(0, cols - 1) * spacing + margins.left() + margins.right() + 24
        height = rows * cell_h + max(0, rows - 1) * spacing + margins.top() + margins.bottom() + 28

        screen = QtWidgets.QApplication.primaryScreen()
        if screen:
            available = screen.availableGeometry()
            width = min(width, int(available.width() * 0.85))
            height = min(height, int(available.height() * 0.85))

        self.resize(max(260, int(width)), max(140, int(height)))
