import os
import math
import re
import ast
import time
import threading
from collections import deque
from dataclasses import dataclass
from typing import Optional

import serial
import serial.tools.list_ports

from PyQt5 import QtCore, QtGui, QtWidgets
from dataclasses import dataclass
from PyQt5.QtGui import QTextCharFormat, QColor

from app.utils import save_json, load_json, SERIAL_SETTINGS
from app.splitter_grid import SplitterGrid
from app.tools.macro_engine import DEFAULT_MACRO_CONFIG, MacroWindow, normalize_macro_config
from app.tool_api import ToolCallFuture

@dataclass
class Cell:
    ch: str
    fmt: QTextCharFormat | None = None

@dataclass
class PutText:
    text: str
    fmt: QTextCharFormat


@dataclass
class MoveCursor:
    row: int | None = None
    col: int | None = None
    dr: int = 0
    dc: int = 0


@dataclass
class EraseLine:
    mode: int   # 0 = cursor→end, 2 = whole line


@dataclass
class EraseScreen:
    mode: int   # 0 = cursor→end, 2 = whole screen

ANSI_COLORS = {
    30: QColor("#000000"),
    31: QColor("#cc0000"),
    32: QColor("#4e9a06"),
    33: QColor("#c4a000"),
    34: QColor("#3465a4"),
    35: QColor("#75507b"),
    36: QColor("#06989a"),
    37: QColor("#d3d7cf"),
    90: QColor("#555753"),
    91: QColor("#ef2929"),
    92: QColor("#8ae234"),
    93: QColor("#fce94f"),
    94: QColor("#729fcf"),
    95: QColor("#ad7fa8"),
    96: QColor("#34e2e2"),
    97: QColor("#eeeeec"),
}


class VT100State:
    def __init__(self):
        self.reset()

    def reset(self):
        self.fg = None

    def apply_sgr(self, params):
        for p in params:
            if p == 0:
                self.reset()
            elif p == 39:
                self.fg = None
            elif p in ANSI_COLORS:
                self.fg = ANSI_COLORS[p]


class VT100Parser:
    """
    Minimal VT100 / ANSI parser.
    Produces semantic actions instead of raw text.
    """

    def __init__(self):
        self.state = VT100State()
        self._esc = False
        self._csi = False
        self._params = ""
        self._text_buf = ""

    def feed(self, text: str):
        actions = []

        def flush_text():
            nonlocal actions
            if self._text_buf:
                fmt = QTextCharFormat()
                if self.state.fg:
                    fmt.setForeground(self.state.fg)
                actions.append(PutText(self._text_buf, fmt))
                self._text_buf = ""

        for ch in text:

            # ---------------- ESC handling ----------------
            if self._esc:
                if ch == "[":
                    self._csi = True
                    self._params = ""
                    self._esc = False
                else:
                    self._esc = False
                continue

            # ---------------- CSI handling ----------------
            if self._csi:
                if ch.isdigit() or ch == ";":
                    self._params += ch
                    continue

                flush_text()
                params = [int(p) for p in self._params.split(";") if p]

                # ----- SGR (colors) -----
                if ch == "m":
                    self.state.apply_sgr(params or [0])

                # ----- Cursor movement -----
                elif ch == "A":   # CUU
                    actions.append(MoveCursor(dr=-(params[0] if params else 1)))
                elif ch == "B":   # CUD
                    actions.append(MoveCursor(dr=(params[0] if params else 1)))
                elif ch == "C":   # CUF
                    actions.append(MoveCursor(dc=(params[0] if params else 1)))
                elif ch == "D":   # CUB
                    actions.append(MoveCursor(dc=-(params[0] if params else 1)))
                elif ch == "H":   # CUP
                    row = (params[0] - 1) if len(params) > 0 else 0
                    col = (params[1] - 1) if len(params) > 1 else 0
                    actions.append(MoveCursor(row=row, col=col))

                # ----- Erase operations -----
                elif ch == "K":   # EL
                    mode = params[0] if params else 0
                    actions.append(EraseLine(mode))
                elif ch == "J":   # ED
                    mode = params[0] if params else 0
                    actions.append(EraseScreen(mode))

                # Reset CSI
                self._csi = False
                self._params = ""
                continue

            # ---------------- ESC start ----------------
            if ch == "\x1b":
                flush_text()
                self._esc = True
                continue

            # ---------------- Normal text ----------------
            self._text_buf += ch

        flush_text()
        return actions


# ============================================================
#  Serial Settings Model
# ============================================================

@dataclass
class SerialConfig:
    port: str = ""
    baudrate: int = 115200
    bytesize: int = 8              # 5,6,7,8
    parity: str = "N"              # N,E,O,M,S
    stopbits: float = 1            # 1, 1.5, 2
    rtscts: bool = False
    xonxoff: bool = False
    dsrdtr: bool = False
    timeout: float = 0.05          # read timeout, seconds

    # UX / terminal behavior
    encoding: str = "utf-8"
    decode_errors: str = "replace" # "replace" or "ignore"
    local_echo: bool = False
    enter_sends: str = "CR"      # "CRLF", "CR", "LF"
    vt100_keys: bool = True        # arrows/home/end -> ANSI escapes
    hex_view: bool = False         # show bytes as hex
    timestamps: bool = False

    # Display tuning
    scrollback_lines: int = 5000


# ============================================================
#  Serial Worker Thread (owns the serial port)
# ============================================================

class SerialWorker(QtCore.QThread):
    """
    Opens and owns the serial port inside this thread.
    UI communicates via signals and a thread-safe outgoing queue.
    """
    rx_bytes = QtCore.pyqtSignal(bytes)     # incoming bytes from device
    status = QtCore.pyqtSignal(str)         # status text for status bar
    error = QtCore.pyqtSignal(str)          # errors (also for status bar)
    connected = QtCore.pyqtSignal()
    disconnected = QtCore.pyqtSignal()

    def __init__(self, cfg: SerialConfig, parent=None):
        super().__init__(parent)
        self._cfg = cfg
        self._stop = False

        self._ser: Optional[serial.Serial] = None

        self._tx_lock = QtCore.QMutex()
        self._tx_queue = deque()  # deque[bytes]
        self._api_queue = deque()

    def enqueue_write(self, data: bytes):
        if not data:
            return
        self._tx_lock.lock()
        try:
            self._tx_queue.append(data)
        finally:
            self._tx_lock.unlock()

    def submit_raw(self, func) -> ToolCallFuture:
        """Run ``func(serial.Serial)`` inside the serial owner thread."""
        future = ToolCallFuture()
        self._tx_lock.lock()
        try:
            self._api_queue.append((func, future))
        finally:
            self._tx_lock.unlock()
        return future

    def stop(self):
        self._stop = True
        # Try to unblock read quickly by closing
        try:
            if self._ser and self._ser.is_open:
                self._ser.close()
        except Exception:
            pass

    def _pop_tx(self) -> Optional[bytes]:
        self._tx_lock.lock()
        try:
            if self._tx_queue:
                return self._tx_queue.popleft()
            return None
        finally:
            self._tx_lock.unlock()

    def _pop_api_call(self):
        self._tx_lock.lock()
        try:
            return self._api_queue.popleft() if self._api_queue else None
        finally:
            self._tx_lock.unlock()

    @staticmethod
    def _pyserial_bytesize(n: int):
        return {5: serial.FIVEBITS, 6: serial.SIXBITS, 7: serial.SEVENBITS, 8: serial.EIGHTBITS}.get(n, serial.EIGHTBITS)

    @staticmethod
    def _pyserial_parity(p: str):
        return {
            "N": serial.PARITY_NONE,
            "E": serial.PARITY_EVEN,
            "O": serial.PARITY_ODD,
            "M": serial.PARITY_MARK,
            "S": serial.PARITY_SPACE,
        }.get(p.upper(), serial.PARITY_NONE)

    @staticmethod
    def _pyserial_stopbits(v: float):
        return {1: serial.STOPBITS_ONE, 1.5: serial.STOPBITS_ONE_POINT_FIVE, 2: serial.STOPBITS_TWO}.get(v, serial.STOPBITS_ONE)

    def run(self):
        cfg = self._cfg
        port = cfg.port.strip()

        if not port:
            self.error.emit("No port selected.")
            self.disconnected.emit()
            return

        try:
            serial_factory = serial.serial_for_url if "://" in port else serial.Serial
            self._ser = serial_factory(
                port,
                baudrate=cfg.baudrate,
                bytesize=self._pyserial_bytesize(cfg.bytesize),
                parity=self._pyserial_parity(cfg.parity),
                stopbits=self._pyserial_stopbits(cfg.stopbits),
                timeout=cfg.timeout,
                rtscts=cfg.rtscts,
                xonxoff=cfg.xonxoff,
                dsrdtr=cfg.dsrdtr,
                write_timeout=0.2,
            )
            self.status.emit(f"Connected: {port} @ {cfg.baudrate}")
            self.connected.emit()
        except Exception as e:
            self.error.emit(f"Open failed: {e}")
            self.disconnected.emit()
            return

        # Main I/O loop
        last_rx_time = time.time()
        while not self._stop:
            try:
                request = self._pop_api_call()
                if request:
                    func, future = request
                    try:
                        future.set_result(func(self._ser))
                    except BaseException as error:
                        future.set_exception(error)

                # 1) RX
                n = 0
                try:
                    n = self._ser.in_waiting if self._ser else 0
                except Exception:
                    n = 0

                if n:
                    data = self._ser.read(n)
                    if data:
                        last_rx_time = time.time()
                        self.rx_bytes.emit(data)

                # 2) TX
                out = self._pop_tx()
                if out and self._ser and self._ser.is_open:
                    self._ser.write(out)

                # 3) Light idle
                if not n and not out:
                    self.msleep(10)

                # Optional: status keepalive (not too chatty)
                if time.time() - last_rx_time > 10:
                    # do nothing; you may emit "idle" if you like
                    pass

            except Exception as e:
                self.error.emit(f"I/O error: {e}")
                break

        try:
            if self._ser:
                self._ser.close()
        except Exception:
            pass

        while True:
            request = self._pop_api_call()
            if request is None:
                break
            _func, future = request
            future.set_exception(RuntimeError("Serial connection closed"))

        self.status.emit("Disconnected.")
        self.disconnected.emit()


# ============================================================
#  Terminal Emulation Model (strict-ish TTY)
# ============================================================

class TerminalModel(QtCore.QObject):
    """
    A minimal TTY-ish model:
    - Maintains lines as mutable strings.
    - Supports: CR, LF, BS, TAB for display semantics.
    This is enough to make most bootlogs / CLI prompts look correct.
    """
    changed = QtCore.pyqtSignal(int, int)  # from_line, to_line inclusive

    def __init__(self, scrollback_lines: int = 5000, parent=None):
        super().__init__(parent)
        self.scrollback_lines = max(200, int(scrollback_lines))
        self.lines: list[list[Cell]] = [[ ]]
        self.row = 0
        self.col = 0

    def clear(self):
        self.lines: list[list[Cell]] = [[ ]]
        self.row = 0
        self.col = 0
        self.changed.emit(0, 0)

    def _ensure_row(self, r: int):
        while r >= len(self.lines):
            self.lines.append([])

    def _trim_scrollback(self):
        overflow = len(self.lines) - self.scrollback_lines
        if overflow > 0:
            self.lines = self.lines[overflow:]
            self.row = max(0, self.row - overflow)

    def _set_line(self, r: int, s: str):
        self.lines[r] = s

    def feed_text(self, text: str, fmt: QTextCharFormat | None = None):
        """
        Feed already-decoded text into the model, applying control chars.
        Emits 'changed' for minimal line ranges.
        """
        if not text:
            return

        start_changed = self.row
        end_changed = self.row

        for ch in text:
            if ch == "\r":
                self.col = 0
                end_changed = max(end_changed, self.row)

            elif ch == "\n":
                self.row += 1
                self.col = 0
                self._ensure_row(self.row)
                end_changed = max(end_changed, self.row)

            elif ch == "\b":
                # Backspace: move left and delete previous char visually
                if self.col > 0:
                    self.col -= 1
                end_changed = max(end_changed, self.row)

            elif ch == "\t":
                # Tab to next 8-col stop
                next_tab = ((self.col // 8) + 1) * 8
                spaces = next_tab - self.col
                self._write_chars(" " * spaces)
                end_changed = max(end_changed, self.row)

            else:
                self._write_chars(ch, fmt)
                end_changed = max(end_changed, self.row)

        self._trim_scrollback()
        self.changed.emit(start_changed, end_changed)

    def _write_chars(self, s: str, fmt: QTextCharFormat | None = None):
        self._ensure_row(self.row)
        line = self.lines[self.row]

        # pad with spaces if needed
        while len(line) < self.col:
            line.append(Cell(" "))

        for ch in s:
            if self.col < len(line):
                line[self.col] = Cell(ch, fmt)
            else:
                line.append(Cell(ch, fmt))
            self.col += 1
    
    def move_cursor(self, row=None, col=None, dr=0, dc=0):
        """
        VT100 cursor movement.
        Absolute (row/col) takes precedence.
        Relative (dr/dc) applies otherwise.
        """
        if row is not None:
            self.row = max(0, row)
        else:
            self.row = max(0, self.row + dr)

        if col is not None:
            self.col = max(0, col)
        else:
            self.col = max(0, self.col + dc)

        self._ensure_row(self.row)
        self.changed.emit(self.row, self.row)
    
    def erase_screen(self, mode: int = 0):
        """
        VT100 ED – Erase in Display
        0: cursor → end
        1: start → cursor
        2: entire screen
        """
        if mode == 2:
            self.lines: list[list[Cell]] = [[ ]]
            self.row = 0
            self.col = 0
            self.changed.emit(0, 0)
            return

        if mode == 0:
            self.lines[self.row] = self.lines[self.row][:self.col]
            for r in range(self.row + 1, len(self.lines)):
                self.lines[r] = []
            self.changed.emit(self.row, len(self.lines) - 1)

        elif mode == 1:
            for r in range(0, self.row):
                self.lines[r] = []
            line = self.lines[self.row]
            self.lines[self.row] = (
                [Cell(" ")] * self.col + line[self.col:]
            )
            self.changed.emit(0, self.row)
    
    def erase_line(self, mode: int = 0):
        """
        VT100 EL – Erase in Line
        0: cursor → end
        1: start → cursor
        2: entire line
        """
        line = self.lines[self.row]

        if mode == 2:
            self.lines[self.row] = []
        elif mode == 0:
            self.lines[self.row] = self.lines[self.row][:self.col]
        elif mode == 1:
            line = self.lines[self.row]
            self.lines[self.row] = (
                [Cell(" ")] * self.col + line[self.col:]
            )

        self.changed.emit(self.row, self.row)
    
    def _line_to_text(self, line: list[Cell]) -> str:
        return "".join(c.ch for c in line)



# ============================================================
#  Terminal View (key-event driven + selection/copy preserved)
# ============================================================

class TTYTerminalView(QtWidgets.QPlainTextEdit):
    """
    A terminal-like view:
    - Read-only for user edits (but supports selection/copy).
    - Captures key events and emits bytes_to_send.
    - Renders from TerminalModel efficiently.
    """
    bytes_to_send = QtCore.pyqtSignal(bytes)
    request_clear = QtCore.pyqtSignal()

    def __init__(self, model: TerminalModel, cfg: SerialConfig, parent=None):
        super().__init__(parent)
        self._model = model
        self._cfg = cfg

        self.setReadOnly(True)
        self.setUndoRedoEnabled(False)
        self.setWordWrapMode(QtGui.QTextOption.NoWrap)
        self.setFont(QtGui.QFont("Consolas", 10))
        self.setFrameShape(QtWidgets.QFrame.NoFrame)

        self._vt100 = VT100Parser()

        # Autoscroll behavior: disengage when user scrolls up
        self._follow_tail = True
        self.verticalScrollBar().valueChanged.connect(self._on_scroll_changed)

        self._model.changed.connect(self._on_model_changed)
        self._full_redraw()

        # Context menu extras
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_context_menu)

    def set_config(self, cfg: SerialConfig):
        self._cfg = cfg

    def _on_scroll_changed(self, value: int):
        sb = self.verticalScrollBar()
        at_bottom = (value >= sb.maximum() - 1)
        self._follow_tail = at_bottom

    def _scroll_to_bottom_if_needed(self):
        if self._follow_tail:
            sb = self.verticalScrollBar()
            sb.setValue(sb.maximum())

    def _on_context_menu(self, pos):
        menu = self.createStandardContextMenu()
        menu.addSeparator()

        act_clear = QtWidgets.QAction("Clear screen", self)
        act_clear.triggered.connect(self.request_clear.emit)
        menu.addAction(act_clear)

        menu.exec_(self.mapToGlobal(pos))

    def _full_redraw(self):
        # Render entire buffer. This is OK up to a few thousand lines.
        self.blockSignals(True)
        try:
            self.clear()
            cursor = self.textCursor()

            for line in self._model.lines:
                for cell in line:
                    if cell.fmt:
                        cursor.insertText(cell.ch, cell.fmt)
                    else:
                        cursor.insertText(cell.ch)
                cursor.insertText("\n")
        finally:
            self.blockSignals(False)
        self._scroll_to_bottom_if_needed()

    def _on_model_changed(self, from_line: int, to_line: int):
        """
        Update only changed blocks. Efficient enough for serial console usage.
        """
        doc = self.document()
        max_line = len(self._model.lines) - 1
        from_line = max(0, min(from_line, max_line))
        to_line = max(0, min(to_line, max_line))

        # If line count changed a lot or doc doesn't match, redraw
        if doc.blockCount() != len(self._model.lines):
            self._full_redraw()
            return

        cursor = QtGui.QTextCursor(doc)
        for line_idx in range(from_line, to_line + 1):
            block = doc.findBlockByNumber(line_idx)
            cursor.setPosition(block.position())
            cursor.movePosition(
                QtGui.QTextCursor.EndOfBlock,
                QtGui.QTextCursor.KeepAnchor
            )
            cursor.removeSelectedText()

            for cell in self._model.lines[line_idx]:
                if cell.fmt:
                    cursor.insertText(cell.ch, cell.fmt)
                else:
                    cursor.insertText(cell.ch)

        self._scroll_to_bottom_if_needed()

    # ---------------- Key event driven TX ----------------

    def keyPressEvent(self, e: QtGui.QKeyEvent):
        cfg = self._cfg

        # Allow copy/select shortcuts
        if e.matches(QtGui.QKeySequence.Copy):
            self._copy_from_model()
            return

        # Paste sends to device (like terminal paste)
        if e.matches(QtGui.QKeySequence.Paste):
            txt = QtWidgets.QApplication.clipboard().text()
            if txt:
                self._send_text_as_bytes(txt)
                if cfg.local_echo:
                    self._local_echo_bytes(self._encode(txt))
            return

        # Clear screen shortcut (Ctrl+L is common)
        if (e.modifiers() & QtCore.Qt.ControlModifier) and e.key() == QtCore.Qt.Key_L:
            self.request_clear.emit()
            return

        # Ctrl+C etc should be forwarded as control codes (0x03)
        if e.modifiers() & QtCore.Qt.ControlModifier:
            key = e.key()
            if QtCore.Qt.Key_A <= key <= QtCore.Qt.Key_Z:
                code = key - QtCore.Qt.Key_A + 1
                b = bytes([code])
                self.bytes_to_send.emit(b)
                if cfg.local_echo:
                    self._local_echo_bytes(b)
                return

        # Special keys
        k = e.key()
        if k in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            if cfg.enter_sends == "CR":
                b = b"\r"
            elif cfg.enter_sends == "LF":
                b = b"\n"
            else:
                b = b"\r\n"
            self.bytes_to_send.emit(b)
            if cfg.local_echo:
                self._local_echo_bytes(b)
            return

        if k == QtCore.Qt.Key_Backspace:
            # Many devices expect 0x08 or 0x7F; Tera Term lets user configure.
            # We'll use 0x08 by default.
            b = b"\x08"
            self.bytes_to_send.emit(b)
            if cfg.local_echo:
                self._local_echo_bytes(b)
            return

        if cfg.vt100_keys:
            esc = None
            if k == QtCore.Qt.Key_Up:
                esc = b"\x1b[A"
            elif k == QtCore.Qt.Key_Down:
                esc = b"\x1b[B"
            elif k == QtCore.Qt.Key_Right:
                esc = b"\x1b[C"
            elif k == QtCore.Qt.Key_Left:
                esc = b"\x1b[D"
            elif k == QtCore.Qt.Key_Home:
                esc = b"\x1b[H"
            elif k == QtCore.Qt.Key_End:
                esc = b"\x1b[F"
            elif k == QtCore.Qt.Key_Delete:
                esc = b"\x1b[3~"

            if esc is not None:
                self.bytes_to_send.emit(esc)
                if cfg.local_echo:
                    self._local_echo_bytes(esc)
                return

        # Printable text
        txt = e.text()
        if txt:
            b = self._encode(txt)
            self.bytes_to_send.emit(b)
            if cfg.local_echo:
                self._local_echo_bytes(b)
            return

        # Otherwise ignore (function keys etc)
        super().keyPressEvent(e)

    def _encode(self, s: str) -> bytes:
        enc = self._cfg.encoding
        return s.encode(enc, errors="replace")

    def _send_text_as_bytes(self, s: str):
        b = self._encode(s)
        self.bytes_to_send.emit(b)

    def _local_echo_bytes(self, b: bytes):
        """
        Local echo must look indistinguishable from device echo.
        So we inject the bytes into the same render pipeline,
        not with prefixes/colors.
        """
        # We can't decode bytes reliably as "display-only" without using current encoding;
        # this mirrors how terminal local echo behaves in practice.
        try:
            txt = b.decode(self._cfg.encoding, errors=self._cfg.decode_errors)
        except Exception:
            txt = b.decode("latin-1", errors="replace")
        self._model.feed_text(txt)
    
    def insert_ansi_spans(self, spans):
        cursor = self.textCursor()
        cursor.movePosition(QtGui.QTextCursor.End)

        for text, fmt in spans:
            if not text:
                continue
            cursor.insertText(text, fmt)

        self.setTextCursor(cursor)
        self._scroll_to_bottom_if_needed()

    def _copy_from_model(self):
        cursor = self.textCursor()
        if not cursor.hasSelection():
            return

        start = cursor.selectionStart()
        end = cursor.selectionEnd()

        doc = self.document()
        start_block = doc.findBlock(start).blockNumber()
        end_block = doc.findBlock(end).blockNumber()

        lines = []
        for i in range(start_block, end_block + 1):
            line = self._model.lines[i]
            lines.append(self._model._line_to_text(line))

        QtWidgets.QApplication.clipboard().setText("\n".join(lines))

# ============================================================
#  Main Widget
# ============================================================

class SerialSessionWidget(QtWidgets.QFrame):
    select_requested = QtCore.pyqtSignal(object)
    settings_changed = QtCore.pyqtSignal()
    close_requested = QtCore.pyqtSignal(object)

    """
    Production-ready serial terminal widget with strict TTY mode:
    - Key-event driven TX
    - Byte-stream RX (no line splitting)
    - Basic CR/LF/BS/TAB handling
    - Local echo injected into same pipeline
    - System/status out-of-band
    - Autoscroll disarms on manual scroll
    """
    def __init__(
        self,
        parent=None,
        cfg: Optional[SerialConfig] = None,
        name: str = "Serial",
        save_settings_callback=None,
        macros_config=None,
        save_macros_callback=None,
        load_settings: bool = True,
        show_menu_bar: bool = True,
    ):
        super().__init__(parent)
        self.setObjectName("serialSession")
        self.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.setFrameShadow(QtWidgets.QFrame.Raised)
        self.setMinimumSize(420, 300)
        self.setStyleSheet(
            """
            QFrame#serialSession {
                border: 1px solid #3a3f48;
                border-radius: 4px;
            }
            QFrame#serialSession[selected="true"] {
                border: 2px solid #5aa2ff;
            }
            """
        )
        self.resize(600,800)
        self.setWindowTitle(name)
        self.session_name = name
        self._save_settings_callback = save_settings_callback
        self._macros_config = normalize_macro_config(macros_config or DEFAULT_MACRO_CONFIG.copy())
        self._save_macros_callback = save_macros_callback
        self._loading_settings = True
        self._show_menu_bar = bool(show_menu_bar)

        self.cfg = cfg or SerialConfig()
        if load_settings:
            self._load_settings()

        # --- Model + View
        self.model = TerminalModel(scrollback_lines=self.cfg.scrollback_lines, parent=self)
        self.term = TTYTerminalView(self.model, self.cfg, parent=self)

        # --- Serial thread
        self.worker: Optional[SerialWorker] = None
        self._connected = False
        self._rx_lock = threading.RLock()
        self._rx_text = ""
        self._rx_bytes = b""
        self._macro_window = None

        # --- UI: top bar
        self.title_label = QtWidgets.QLabel(self.session_name)
        title_font = self.title_label.font()
        title_font.setBold(True)
        self.title_label.setFont(title_font)

        self.port_combo = QtWidgets.QComboBox()
        self.port_combo.setEditable(True)

        self.btn_refresh = QtWidgets.QPushButton("Refresh")
        self.btn_refresh.setText("🔄️")
        self.btn_refresh.setToolTip("Refresh ports")
        self.btn_refresh.setText("Refresh")
        self.btn_refresh.setFixedWidth(96)

        self.baud_combo = QtWidgets.QComboBox()
        for b in [1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600]:
            self.baud_combo.addItem(str(b))
        self.baud_combo.setCurrentText(str(self.cfg.baudrate))

        self.bytesize_combo = QtWidgets.QComboBox()
        for n in [5, 6, 7, 8]:
            self.bytesize_combo.addItem(str(n))
        self.bytesize_combo.setCurrentText(str(self.cfg.bytesize))

        self.parity_combo = QtWidgets.QComboBox()
        self.parity_combo.addItems(["N", "E", "O", "M", "S"])
        self.parity_combo.setCurrentText(self.cfg.parity)

        self.stop_combo = QtWidgets.QComboBox()
        self.stop_combo.addItems(["1", "1.5", "2"])
        self.stop_combo.setCurrentText(str(self.cfg.stopbits))

        self.encoding_combo = QtWidgets.QComboBox()
        self.encoding_combo.addItems(["utf-8", "latin-1", "cp1254", "ascii", "utf-16"])
        self.encoding_combo.setCurrentText(self.cfg.encoding)

        self.btn_connection = QtWidgets.QPushButton("Connect")
        self.btn_connection.setFixedWidth(96)
        self.btn_macros = QtWidgets.QPushButton("Macros")
        self.btn_macros.setFixedWidth(74)

        self.btn_close = QtWidgets.QToolButton()
        self.btn_close.setText("X")
        self.btn_close.setToolTip("Close this Serial connection")
        self.btn_close.setFixedSize(24, 24)
        self.btn_close.setAutoRaise(True)

        # --- UX toggles
        self.chk_local_echo = QtWidgets.QCheckBox("Local echo")
        self.chk_local_echo.setChecked(self.cfg.local_echo)

        self.enter_combo = QtWidgets.QComboBox()
        self.enter_combo.addItems(["CRLF", "CR", "LF"])
        self.enter_combo.setCurrentText(self.cfg.enter_sends)

        self.chk_vt100 = QtWidgets.QCheckBox("VT100 keys")
        self.chk_vt100.setChecked(self.cfg.vt100_keys)

        self.chk_hex = QtWidgets.QCheckBox("Hex view")
        self.chk_hex.setChecked(self.cfg.hex_view)

        self.chk_timestamps = QtWidgets.QCheckBox("Timestamps")
        self.chk_timestamps.setChecked(self.cfg.timestamps)

        # Flow control
        self.chk_rtscts = QtWidgets.QCheckBox("RTS/CTS")
        self.chk_rtscts.setChecked(self.cfg.rtscts)
        self.chk_xonxoff = QtWidgets.QCheckBox("XON/XOFF")
        self.chk_xonxoff.setChecked(self.cfg.xonxoff)
        self.chk_dsrdtr = QtWidgets.QCheckBox("DSR/DTR")
        self.chk_dsrdtr.setChecked(self.cfg.dsrdtr)

        # Logging
        self.btn_log = QtWidgets.QToolButton()
        self.btn_log.setText("Log…")
        self._log_fp = None  # file object or None

        # Status bar (out-of-band)
        self.status = QtWidgets.QLabel("Disconnected")
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.status.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.status.setStyleSheet("color: #aaa;")

        self.menu_bar = QtWidgets.QMenuBar()
        self._menu_action_groups = []
        self._build_menu_bar()

        # Layout
        top1 = QtWidgets.QHBoxLayout()
        top1.addWidget(self.title_label)
        top1.addSpacing(8)
        top1.addWidget(QtWidgets.QLabel("Port:"))
        top1.addWidget(self.port_combo, 2)
        top1.addWidget(self.btn_refresh)
        top1.addWidget(self.btn_connection)
        top1.addWidget(self.btn_macros)
        top1.addWidget(self.btn_close)

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        if self._show_menu_bar:
            outer.addWidget(self.menu_bar)

        content = QtWidgets.QWidget()
        content_layout = QtWidgets.QVBoxLayout(content)
        content_layout.setContentsMargins(8, 8, 8, 8)
        content_layout.setSpacing(6)
        content_layout.addLayout(top1)
        content_layout.addWidget(self.status)
        content_layout.addWidget(self.term, 1)
        outer.addWidget(content, 1)

        # Signals
        self.btn_refresh.clicked.connect(self.refresh_ports)
        self.btn_connection.clicked.connect(self._on_connection_clicked)
        self.btn_macros.clicked.connect(self._open_macros)
        self.btn_close.clicked.connect(self._on_close_clicked)

        # Config changes
        self.port_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.baud_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.bytesize_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.parity_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.stop_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.encoding_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.enter_combo.currentTextChanged.connect(self._pull_ui_into_cfg)
        self.chk_local_echo.toggled.connect(self._pull_ui_into_cfg)
        self.chk_vt100.toggled.connect(self._pull_ui_into_cfg)
        self.chk_hex.toggled.connect(self._pull_ui_into_cfg)
        self.chk_timestamps.toggled.connect(self._pull_ui_into_cfg)
        self.chk_rtscts.toggled.connect(self._pull_ui_into_cfg)
        self.chk_xonxoff.toggled.connect(self._pull_ui_into_cfg)
        self.chk_dsrdtr.toggled.connect(self._pull_ui_into_cfg)
        self.btn_log.clicked.connect(self._toggle_log)

        # Terminal -> serial TX
        self.term.bytes_to_send.connect(self._on_terminal_tx)
        self.term.request_clear.connect(self._on_clear_requested)

        self.refresh_ports()
        self._push_cfg_into_ui()
        self._pull_ui_into_cfg()
        self._set_tooltips()
        self._loading_settings = False
        self._install_select_filters()
        self.set_selected(False)

    def _on_connection_clicked(self):
        if self._connected or (self.worker and self.worker.isRunning()):
            self.disconnect_serial()
        else:
            self.connect_serial()

    def _on_close_clicked(self):
        self.select_requested.emit(self)
        self.close_requested.emit(self)

    def _open_macros(self):
        self.select_requested.emit(self)
        if self._macro_window and self._macro_window.isVisible():
            self._macro_window.raise_()
            self._macro_window.activateWindow()
            return
        self._macro_window = MacroWindow(
            self,
            self._macros_config,
            self,
            title=self.macro_window_title(),
            transport_name="Serial",
        )
        self._macro_window.show()

    def _build_menu_bar(self):
        connection_menu = self.menu_bar.addMenu("Connection")
        self.act_connect = connection_menu.addAction("Connect")
        self.act_disconnect = connection_menu.addAction("Disconnect")
        self.act_disconnect.setEnabled(False)
        connection_menu.addSeparator()
        self.act_refresh_ports = connection_menu.addAction("Refresh Ports")
        self.act_clear_terminal = connection_menu.addAction("Clear Terminal")
        connection_menu.addSeparator()
        self.act_log = connection_menu.addAction("Start Log...")

        settings_menu = self.menu_bar.addMenu("Settings")
        self._baud_actions = self._add_combo_menu(settings_menu, "Baud Rate", self.baud_combo)
        self._bytesize_actions = self._add_combo_menu(settings_menu, "Data Bits", self.bytesize_combo)
        self._parity_actions = self._add_combo_menu(settings_menu, "Parity", self.parity_combo)
        self._stop_actions = self._add_combo_menu(settings_menu, "Stop Bits", self.stop_combo)

        terminal_menu = self.menu_bar.addMenu("Terminal")
        self._encoding_actions = self._add_combo_menu(terminal_menu, "Encoding", self.encoding_combo)
        self._enter_actions = self._add_combo_menu(terminal_menu, "Enter Sends", self.enter_combo)
        terminal_menu.addSeparator()
        self.act_local_echo = self._add_check_action(terminal_menu, "Local Echo", self.chk_local_echo)
        self.act_vt100 = self._add_check_action(terminal_menu, "VT100 Keys", self.chk_vt100)
        self.act_hex = self._add_check_action(terminal_menu, "Hex View", self.chk_hex)
        self.act_timestamps = self._add_check_action(terminal_menu, "Timestamps", self.chk_timestamps)

        flow_menu = self.menu_bar.addMenu("Flow Control")
        self.act_rtscts = self._add_check_action(flow_menu, "RTS/CTS", self.chk_rtscts)
        self.act_xonxoff = self._add_check_action(flow_menu, "XON/XOFF", self.chk_xonxoff)
        self.act_dsrdtr = self._add_check_action(flow_menu, "DSR/DTR", self.chk_dsrdtr)

        self.act_connect.triggered.connect(self.connect_serial)
        self.act_disconnect.triggered.connect(self.disconnect_serial)
        self.act_refresh_ports.triggered.connect(self.refresh_ports)
        self.act_clear_terminal.triggered.connect(self._on_clear_requested)
        self.act_log.triggered.connect(self._toggle_log)

    def _add_combo_menu(self, parent_menu, title, combo):
        menu = parent_menu.addMenu(title)
        group = QtWidgets.QActionGroup(self)
        group.setExclusive(True)
        self._menu_action_groups.append(group)
        actions = {}
        for index in range(combo.count()):
            value = combo.itemText(index)
            action = menu.addAction(value)
            action.setCheckable(True)
            action.setData(value)
            action.triggered.connect(lambda checked, v=value, c=combo: c.setCurrentText(v))
            group.addAction(action)
            actions[value] = action
        return actions

    def _add_check_action(self, parent_menu, title, checkbox):
        action = parent_menu.addAction(title)
        action.setCheckable(True)
        action.triggered.connect(checkbox.setChecked)
        return action

    # ---------------- Settings sync ----------------

    def _push_cfg_into_ui(self):
        self.port_combo.setCurrentText(self.cfg.port)
        self.baud_combo.setCurrentText(str(self.cfg.baudrate))
        self.bytesize_combo.setCurrentText(str(self.cfg.bytesize))
        self.parity_combo.setCurrentText(self.cfg.parity)
        self.stop_combo.setCurrentText(str(self.cfg.stopbits))
        self.encoding_combo.setCurrentText(self.cfg.encoding)
        self.enter_combo.setCurrentText(self.cfg.enter_sends)

        self.chk_local_echo.setChecked(self.cfg.local_echo)
        self.chk_vt100.setChecked(self.cfg.vt100_keys)
        self.chk_hex.setChecked(self.cfg.hex_view)
        self.chk_timestamps.setChecked(self.cfg.timestamps)

        self.chk_rtscts.setChecked(self.cfg.rtscts)
        self.chk_xonxoff.setChecked(self.cfg.xonxoff)
        self.chk_dsrdtr.setChecked(self.cfg.dsrdtr)
        self._sync_menu_actions()

    def _pull_ui_into_cfg(self):
        # core serial
        self.cfg.port = self.port_combo.currentText().strip()
        try:
            self.cfg.baudrate = int(self.baud_combo.currentText())
        except Exception:
            self.cfg.baudrate = 115200

        try:
            self.cfg.bytesize = int(self.bytesize_combo.currentText())
        except Exception:
            self.cfg.bytesize = 8

        self.cfg.parity = self.parity_combo.currentText().strip() or "N"
        try:
            self.cfg.stopbits = float(self.stop_combo.currentText())
        except Exception:
            self.cfg.stopbits = 1

        self.cfg.rtscts = self.chk_rtscts.isChecked()
        self.cfg.xonxoff = self.chk_xonxoff.isChecked()
        self.cfg.dsrdtr = self.chk_dsrdtr.isChecked()

        # terminal behavior
        self.cfg.encoding = self.encoding_combo.currentText().strip() or "utf-8"
        self.cfg.enter_sends = self.enter_combo.currentText().strip() or "CRLF"
        self.cfg.local_echo = self.chk_local_echo.isChecked()
        self.cfg.vt100_keys = self.chk_vt100.isChecked()
        self.cfg.hex_view = self.chk_hex.isChecked()
        self.cfg.timestamps = self.chk_timestamps.isChecked()

        self.term.set_config(self.cfg)
        self._sync_menu_actions()

        # Hook: save settings if you want
        self._save_settings()

    def to_settings(self):
        data = {
            k: getattr(self.cfg, k)
            for k in self.cfg.__dataclass_fields__
        }
        data["name"] = self.session_name
        return data

    def _sync_menu_actions(self):
        combo_action_sets = [
            (self._baud_actions, self.baud_combo.currentText()),
            (self._bytesize_actions, self.bytesize_combo.currentText()),
            (self._parity_actions, self.parity_combo.currentText()),
            (self._stop_actions, self.stop_combo.currentText()),
            (self._encoding_actions, self.encoding_combo.currentText()),
            (self._enter_actions, self.enter_combo.currentText()),
        ]
        for actions, current in combo_action_sets:
            for value, action in actions.items():
                action.setChecked(value == current)

        check_pairs = [
            (self.act_local_echo, self.chk_local_echo),
            (self.act_vt100, self.chk_vt100),
            (self.act_hex, self.chk_hex),
            (self.act_timestamps, self.chk_timestamps),
            (self.act_rtscts, self.chk_rtscts),
            (self.act_xonxoff, self.chk_xonxoff),
            (self.act_dsrdtr, self.chk_dsrdtr),
        ]
        for action, checkbox in check_pairs:
            action.setChecked(checkbox.isChecked())

    # ---------------- Port management ----------------

    def refresh_ports(self):
        current = self.port_combo.currentText().strip()
        self.port_combo.blockSignals(True)
        try:
            self.port_combo.clear()
            ports = serial.tools.list_ports.comports()
            for p in ports:
                self.port_combo.addItem(p.device)
            # Keep editable and preserve current text if user typed custom
            if current and current not in [self.port_combo.itemText(i) for i in range(self.port_combo.count())]:
                self.port_combo.insertItem(0, current)
                self.port_combo.setCurrentIndex(0)
            elif current:
                self.port_combo.setCurrentText(current)
            elif self.port_combo.count() > 0:
                self.port_combo.setCurrentIndex(0)
        finally:
            self.port_combo.blockSignals(False)

    # ---------------- Connect / Disconnect ----------------

    def connect_serial(self):
        if self.worker and self.worker.isRunning():
            return

        self._pull_ui_into_cfg()

        if not self.cfg.port:
            self._set_status("No port selected.", is_error=True)
            return

        self._set_status(f"Connecting to {self.cfg.port}…", is_error=False)

        self.worker = SerialWorker(self.cfg, parent=self)
        self.worker.rx_bytes.connect(self._on_rx_bytes)
        self.worker.status.connect(lambda s: self._set_status(s, is_error=False))
        self.worker.error.connect(lambda s: self._set_status(s, is_error=True))
        self.worker.connected.connect(self._on_connected)
        self.worker.disconnected.connect(self._on_disconnected)
        self.worker.start()

        self._update_buttons(connecting=True)

    def disconnect_serial(self):
        if self.worker:
            self.worker.stop()
            self.worker.wait(1500)
            self.worker = None
        self._on_disconnected()

    def _on_connected(self):
        self._connected = True
        self._update_buttons()

    def _on_disconnected(self):
        self._connected = False
        self._update_buttons()
        if self._log_fp:
            try:
                self._log_fp.close()
            except Exception:
                pass
            self._log_fp = None
            self.btn_log.setText("Log...")
            self.act_log.setText("Start Log...")

    def _update_buttons(self, connecting: bool = False):
        if connecting:
            self.btn_connection.setText("Connecting")
            self.btn_connection.setEnabled(True)
            self.act_connect.setEnabled(False)
            self.act_disconnect.setEnabled(True)
            self._notify_workspace_menu_changed()
            return
        self.btn_connection.setText("Disconnect" if self._connected else "Connect")
        self.btn_connection.setEnabled(True)
        self.act_connect.setEnabled(not self._connected)
        self.act_disconnect.setEnabled(self._connected)
        self._notify_workspace_menu_changed()

    def _notify_workspace_menu_changed(self):
        parent = self.parent()
        while parent is not None:
            if hasattr(parent, "_sync_selected_session_menus"):
                parent._sync_selected_session_menus()
                return
            parent = parent.parent()

    # ---------------- Terminal RX/TX ----------------

    def _on_terminal_tx(self, b: bytes):
        if not self.worker or not self._connected:
            # No in-band system text; just status update.
            self._set_status("Not connected.", is_error=True)
            return
        self.worker.enqueue_write(b)

    def append_text(self, text: str):
        self.model.feed_text(str(text) + "\n")

    def is_connected(self) -> bool:
        return bool(self._connected and self.worker)

    def execute_macro_command(self, text: str, expected_return=None, timeout=3, match_type="substring"):
        if not self.is_connected():
            return False, "Not connected"

        expected_return = expected_return if expected_return not in (None, "") else None
        timeout = float(timeout or 3)
        match_type = match_type or "substring"

        with self._rx_lock:
            start_text = len(self._rx_text)
            start_bytes = len(self._rx_bytes)

        payload = str(text)
        if self.cfg.enter_sends == "CR":
            payload += "\r"
        elif self.cfg.enter_sends == "LF":
            payload += "\n"
        else:
            payload += "\r\n"

        data = payload.encode(self.cfg.encoding, errors="replace")
        self.worker.enqueue_write(data)
        if self.cfg.local_echo:
            self.term._local_echo_bytes(data)

        if expected_return is None:
            return True, ""

        deadline = time.time() + timeout
        last_text = ""
        while time.time() < deadline:
            with self._rx_lock:
                new_text = self._rx_text[start_text:]
                new_bytes = self._rx_bytes[start_bytes:]
            last_text = new_text
            if self._match_response(new_bytes, new_text, expected_return, match_type):
                return True, new_text
            time.sleep(0.05)

        return False, last_text

    def _match_response(self, buffer_bytes, buffer_text, expected_return, match_type):
        try:
            if match_type == "binary":
                if isinstance(expected_return, bytes):
                    expected_bytes = expected_return
                elif isinstance(expected_return, str) and expected_return.strip().startswith((r"b'", 'b"')):
                    expected_bytes = ast.literal_eval(expected_return.strip())
                else:
                    expected_bytes = bytes.fromhex(str(expected_return).replace(" ", ""))
                return expected_bytes in buffer_bytes
            if match_type == "regex":
                return re.search(str(expected_return), buffer_text) is not None
            return str(expected_return) in buffer_text
        except Exception as e:
            self._set_status(f"Macro match error: {e}", is_error=True)
            return False

    def _on_rx_bytes(self, b: bytes):
        # Optional raw logging (true wire tap)
        if self._log_fp:
            try:
                self._log_fp.write(b)
                self._log_fp.flush()
            except Exception as e:
                self._set_status(f"Log write failed: {e}", is_error=True)

        # Decode using configured encoding for display
        try:
            text = b.decode(self.cfg.encoding, errors=self.cfg.decode_errors)
        except Exception:
            text = b.decode("latin-1", errors="replace")

        self._remember_rx(b, text)

        if self.cfg.hex_view:
            # Hex view is display-only; keep wire logging above as raw.
            chunk = b.hex(" ")
            if self.cfg.timestamps:
                chunk = time.strftime("[%H:%M:%S] ") + chunk
            # Show each chunk on a new line for readability
            self.model.feed_text(chunk + "\n")
            return

        if self.cfg.timestamps:
            # Important: timestamps are NOT inserted into the wire itself in strict mode.
            # But user requested a feature; here it is display-side only.
            # To keep it minimally invasive, prefix only at line boundaries:
            # We'll do a lightweight approach: if text contains a newline, prefix each new line.
            ts = time.strftime("[%H:%M:%S] ")
            # prefix at start and after \n
            text = ts + text.replace("\n", "\n" + ts)

        actions = self.term._vt100.feed(text)
        for act in actions:
            if isinstance(act, PutText):
                self.model.feed_text(act.text, act.fmt)
            elif isinstance(act, MoveCursor):
                self.model.move_cursor(
                    row=act.row,
                    col=act.col,
                    dr=act.dr,
                    dc=act.dc,
                )
            elif isinstance(act, EraseLine):
                self.model.erase_line(act.mode)
            elif isinstance(act, EraseScreen):
                self.model.erase_screen(act.mode)

    def _remember_rx(self, data: bytes, text: str):
        with self._rx_lock:
            self._rx_bytes += data
            self._rx_text += text
            if len(self._rx_bytes) > 1_000_000:
                self._rx_bytes = self._rx_bytes[-500_000:]
            if len(self._rx_text) > 1_000_000:
                self._rx_text = self._rx_text[-500_000:]

    def _on_clear_requested(self):
        self.model.clear()

    # ---------------- Logging ----------------

    def _toggle_log(self):
        if self._log_fp:
            try:
                self._log_fp.close()
            except Exception:
                pass
            self._log_fp = None
            self._set_status("Logging stopped.", is_error=False)
            self.act_log.setText("Start Log...")
            self.btn_log.setText("Log…")
            return

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save Serial Log", self._default_log_filename(), "Log Files (*.log);;All Files (*.*)"
        )
        if not path:
            return

        try:
            # raw bytes log
            self._log_fp = open(path, "ab", buffering=0)
            self._set_status(f"Logging to: {os.path.basename(path)}", is_error=False)
            self.act_log.setText("Stop Log")
            self.btn_log.setText("Stop log")
        except Exception as e:
            self._set_status(f"Log open failed: {e}", is_error=True)

    def _default_log_filename(self):
        name = re.sub(r"[^A-Za-z0-9]+", "_", self.session_name or "serial").strip("_").lower()
        return f"{name or 'serial'}.log"

    def macro_window_title(self):
        match = re.search(r"(\d+)\s*$", self.session_name or "")
        suffix = f" {match.group(1)}" if match else f" - {self.session_name}"
        return f"Serial Macros{suffix}"

    def set_macros_config(self, macros_config):
        self._macros_config = normalize_macro_config(macros_config)
        if self._macro_window:
            self._macro_window.rebuild(self._macros_config)

    def _edit_macros(self):
        self.select_requested.emit(self)
        from app.tools.macro_editor import MacroEditorDialog

        dlg = MacroEditorDialog(self._macros_config, self, transport_name="Serial")

        def on_saved(macros_config, apply_now):
            self.save_macros_config(macros_config)
            if apply_now and self._macro_window:
                self._macro_window.rebuild(self._macros_config)

        dlg.macros_saved.connect(on_saved)
        dlg.exec_()

    def save_macros_config(self, macros_config):
        self._macros_config = normalize_macro_config(macros_config)
        if self._save_macros_callback:
            self._save_macros_callback(self._macros_config)

    # ---------------- Status ----------------
    def _set_status(self, text: str, is_error: bool = False):
        self.status.setText(text)
        self.status.setToolTip(text)
        if is_error:
            self.status.setStyleSheet(
                "color:#b42318; background:#fff1f0; border:1px solid #f3b2aa; "
                "border-radius:4px; padding:3px 6px;"
            )
        else:
            self.status.setStyleSheet(
                "color:#667085; background:transparent; border:0; padding:3px 0;"
            )

    def _save_settings(self):
        if self._loading_settings:
            return
        self.settings_changed.emit()
        if self._save_settings_callback:
            self._save_settings_callback()
            return
        try:
            data = {
                k: getattr(self.cfg, k)
                for k in self.cfg.__dataclass_fields__
            }
            save_json(SERIAL_SETTINGS, data)
        except Exception as e:
            self._set_status(f"Failed to save settings: {e}", is_error=True)
    
    def _load_settings(self):
        try:
            data = load_json(SERIAL_SETTINGS)

            for k, v in data.items():
                if hasattr(self.cfg, k):
                    setattr(self.cfg, k, v)

        except Exception as e:
            self._set_status(f"Failed to load settings: {e}", is_error=True)
    
    def _set_tooltips(self):
        tt = {
            # --- Port & connection ---
            self.port_combo:
                "Serial port device path.\n"
                "Examples: COM3, /dev/ttyUSB0, /dev/ttyACM0",

            self.btn_refresh:
                "Scan system for available serial ports.",

            self.baud_combo:
                "Baud rate (symbols per second).\n"
                "Must match the device exactly.",

            self.bytesize_combo:
                "Number of data bits per byte.\n"
                "Typical: 8",

            self.parity_combo:
                "Parity bit mode:\n"
                "N = None, E = Even, O = Odd\n"
                "Rarely used today.",

            self.stop_combo:
                "Stop bits per frame.\n"
                "Typical: 1",

            self.btn_connection:
                "Open or close the serial port using current settings.",

            self.btn_macros:
                "Open macros for this Serial connection.",

            # --- Terminal behavior ---
            self.encoding_combo:
                "Character decoding for DISPLAY ONLY.\n"
                "Does NOT affect transmitted bytes.",

            self.enter_combo:
                "What is sent when Enter is pressed:\n"
                "CRLF = \\r\\n\n"
                "CR   = \\r\n"
                "LF   = \\n",

            self.chk_local_echo:
                "Echo typed characters locally.\n"
                "Useful when device does not echo.",

            self.chk_vt100:
                "Enable VT100 escape sequences.\n"
                "Required for cursor movement, ANSI colors.",

            self.chk_hex:
                "Display incoming bytes as hexadecimal.\n"
                "Display-only, wire data unchanged.",

            self.chk_timestamps:
                "Prefix received lines with timestamps.\n"
                "Display-only, not sent to device.",

            # --- Flow control ---
            self.chk_rtscts:
                "Hardware flow control using RTS/CTS lines.",

            self.chk_xonxoff:
                "Software flow control using XON/XOFF bytes.",

            self.chk_dsrdtr:
                "Use DSR/DTR modem control lines.",

            # --- Logging ---
            self.btn_log:
                "Log raw received bytes to a file.\n"
                "Exact wire data, unmodified.",

            # --- Status ---
            self.status:
                "Connection status and system messages.",
        }

        for w, text in tt.items():
            w.setToolTip(text)

    def set_selected(self, selected):
        self.setProperty("selected", bool(selected))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def _install_select_filters(self):
        self.installEventFilter(self)
        for child in self.findChildren(QtWidgets.QWidget):
            child.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.MouseButtonPress:
            self.select_requested.emit(self)
        return super().eventFilter(obj, event)

    def closeEvent(self, ev: QtGui.QCloseEvent):
        try:
            self.disconnect_serial()
            # Hook: persist settings if you want
            self._save_settings()
        finally:
            super().closeEvent(ev)


class SerialWidget(QtWidgets.QFrame):
    """Workspace wrapper that hosts one or more standalone Serial sessions."""

    def __init__(self, parent=None, cfg: Optional[SerialConfig] = None):
        super().__init__(parent)
        self.resize(920, 620)
        self.setWindowTitle("Serial")
        self.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.setFrameShadow(QtWidgets.QFrame.Raised)

        self.sessions = []
        self._selected_session = None
        self._grid = None
        self._workspace_macro_window = None
        self._loading_settings = True
        self._default_cfg = cfg or SerialConfig()
        self._macros_config = normalize_macro_config(DEFAULT_MACRO_CONFIG.copy())

        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.menu_bar = QtWidgets.QMenuBar()
        file_menu = self.menu_bar.addMenu("File")
        self.act_new_connection = file_menu.addAction("New Connection")
        self.act_close_connection = file_menu.addAction("Close Selected Connection")
        self.act_close_all = file_menu.addAction("Close All Connections")
        self._selected_menu_action_groups = []
        self._build_selected_session_menus()
        macros_menu = self.menu_bar.addMenu("Macros")
        self.act_open_macros = macros_menu.addAction("Open Macros")
        self.act_edit_macros = macros_menu.addAction("Edit Macros")
        outer.addWidget(self.menu_bar)

        self._content = QtWidgets.QWidget()
        self._content_layout = QtWidgets.QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(6, 6, 6, 6)
        self._content_layout.setSpacing(0)
        outer.addWidget(self._content, 1)

        self.act_new_connection.triggered.connect(self._new_connection)
        self.act_close_connection.triggered.connect(self._close_selected_session)
        self.act_close_all.triggered.connect(self._close_all_sessions)
        self.act_open_macros.triggered.connect(self._open_selected_macros)
        self.act_edit_macros.triggered.connect(self._edit_selected_macros)

        settings = self._read_settings()
        self._macros_config = self._load_macros_config(settings)
        for session_settings in self._session_settings_from_data(settings):
            self._add_session(session_settings, save=False)

        if not self.sessions:
            self._add_session(self._settings_from_config(self._default_cfg, "Serial 1"), save=False)

        self._loading_settings = False
        self._save_settings()

    def _new_connection(self):
        settings = self._settings_from_config(self._default_cfg, f"Serial {len(self.sessions) + 1}")
        self._add_session(settings, save=True)

    def _add_session(self, settings=None, save=True):
        settings = dict(settings or {})
        settings.setdefault("name", f"Serial {len(self.sessions) + 1}")
        session = SerialSessionWidget(
            parent=self,
            cfg=self._config_from_settings(settings),
            name=settings["name"],
            save_settings_callback=self._save_settings,
            macros_config=self._macros_config,
            save_macros_callback=self._save_macros_config,
            load_settings=False,
            show_menu_bar=False,
        )
        session.select_requested.connect(self._select_session)
        session.settings_changed.connect(self._sync_selected_session_menus)
        session.close_requested.connect(self._remove_session)
        self.sessions.append(session)
        self._rebuild_grid()
        self._select_session(session)
        if save:
            self._save_settings()
        return session

    def _close_selected_session(self):
        if self._selected_session is not None:
            self._remove_session(self._selected_session)

    def _close_all_sessions(self):
        for session in list(self.sessions):
            self._remove_session(session, ensure_one=False)
        if not self.sessions:
            self._add_session(self._settings_from_config(self._default_cfg, "Serial 1"), save=False)
        self._save_settings()

    def _remove_session(self, session, ensure_one=True):
        if session not in self.sessions:
            return
        session.disconnect_serial()
        self._detach_session_from_grid(session)
        self.sessions.remove(session)
        session.setParent(None)
        session.deleteLater()

        if not self.sessions and ensure_one:
            self._add_session(self._settings_from_config(self._default_cfg, "Serial 1"), save=False)
        else:
            self._rebuild_grid()
            self._select_session(self.sessions[-1] if self.sessions else None)
        self._save_settings()

    def _select_session(self, session):
        self._selected_session = session if session in self.sessions else None
        for item in self.sessions:
            item.set_selected(item is self._selected_session)
        self._sync_selected_session_menus()
        if self._selected_session and self._workspace_macro_window and self._workspace_macro_window.isVisible():
            self._workspace_macro_window.set_session_widget(
                self._selected_session,
                self._macros_config,
                title=self._selected_session.macro_window_title(),
            )

    def _open_selected_macros(self):
        session = self._selected_or_first_session()
        if session:
            self._show_workspace_macros(session)

    def _edit_selected_macros(self):
        session = self._selected_or_first_session()
        if not session:
            return
        session._edit_macros()

    def _save_macros_config(self, macros_config):
        self._macros_config = normalize_macro_config(macros_config)
        for session in self.sessions:
            session.set_macros_config(self._macros_config)
        if self._workspace_macro_window and self._workspace_macro_window.isVisible():
            session = self._selected_or_first_session()
            if session:
                self._workspace_macro_window.set_session_widget(
                    session,
                    self._macros_config,
                    title=session.macro_window_title(),
                )
        self._save_settings()

    def _show_workspace_macros(self, session):
        if self._workspace_macro_window and self._workspace_macro_window.isVisible():
            self._workspace_macro_window.set_session_widget(
                session,
                self._macros_config,
                title=session.macro_window_title(),
            )
            self._workspace_macro_window.raise_()
            self._workspace_macro_window.activateWindow()
            return
        self._workspace_macro_window = MacroWindow(
            session,
            self._macros_config,
            self,
            title=session.macro_window_title(),
            transport_name="Serial",
        )
        self._workspace_macro_window.show()

    def _build_selected_session_menus(self):
        log_menu = self.menu_bar.addMenu("Log")
        self.act_log_scope = log_menu.addAction("Log starts for selected Serial only")
        self.act_log_scope.setEnabled(False)
        log_menu.addSeparator()
        self.act_session_log = log_menu.addAction("Start Log...")

        settings_menu = self.menu_bar.addMenu("Settings")
        self.act_settings_scope = settings_menu.addAction("Settings affect selected Serial only")
        self.act_settings_scope.setEnabled(False)
        settings_menu.addSeparator()
        self._session_baud_actions = self._add_workspace_combo_menu(
            settings_menu,
            "Baud Rate",
            [1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600],
            lambda s: s.baud_combo,
        )
        self._session_bytesize_actions = self._add_workspace_combo_menu(
            settings_menu,
            "Data Bits",
            [5, 6, 7, 8],
            lambda s: s.bytesize_combo,
        )
        self._session_parity_actions = self._add_workspace_combo_menu(
            settings_menu,
            "Parity",
            ["N", "E", "O", "M", "S"],
            lambda s: s.parity_combo,
        )
        self._session_stop_actions = self._add_workspace_combo_menu(
            settings_menu,
            "Stop Bits",
            ["1", "1.5", "2"],
            lambda s: s.stop_combo,
        )
        settings_menu.addSeparator()
        self.act_apply_settings_all = settings_menu.addAction("Apply Current Settings to All")
        self.act_apply_settings_all.triggered.connect(self._apply_selected_settings_to_all)

        terminal_menu = self.menu_bar.addMenu("Terminal")
        self.act_terminal_scope = terminal_menu.addAction("Terminal options affect selected Serial only")
        self.act_terminal_scope.setEnabled(False)
        terminal_menu.addSeparator()
        self._session_encoding_actions = self._add_workspace_combo_menu(
            terminal_menu,
            "Encoding",
            ["utf-8", "latin-1", "cp1254", "ascii", "utf-16"],
            lambda s: s.encoding_combo,
        )
        self._session_enter_actions = self._add_workspace_combo_menu(
            terminal_menu,
            "Enter Sends",
            ["CRLF", "CR", "LF"],
            lambda s: s.enter_combo,
        )
        terminal_menu.addSeparator()
        self.act_session_local_echo = self._add_workspace_check_action(
            terminal_menu, "Local Echo", lambda s: s.chk_local_echo
        )
        self.act_session_vt100 = self._add_workspace_check_action(
            terminal_menu, "VT100 Keys", lambda s: s.chk_vt100
        )
        self.act_session_hex = self._add_workspace_check_action(
            terminal_menu, "Hex View", lambda s: s.chk_hex
        )
        self.act_session_timestamps = self._add_workspace_check_action(
            terminal_menu, "Timestamps", lambda s: s.chk_timestamps
        )
        terminal_menu.addSeparator()
        self.act_apply_terminal_all = terminal_menu.addAction("Apply Current Terminal Options to All")
        self.act_apply_terminal_all.triggered.connect(self._apply_selected_terminal_options_to_all)

        flow_menu = self.menu_bar.addMenu("Flow Control")
        self.act_flow_scope = flow_menu.addAction("Flow control affects selected Serial only")
        self.act_flow_scope.setEnabled(False)
        flow_menu.addSeparator()
        self.act_session_rtscts = self._add_workspace_check_action(
            flow_menu, "RTS/CTS", lambda s: s.chk_rtscts
        )
        self.act_session_xonxoff = self._add_workspace_check_action(
            flow_menu, "XON/XOFF", lambda s: s.chk_xonxoff
        )
        self.act_session_dsrdtr = self._add_workspace_check_action(
            flow_menu, "DSR/DTR", lambda s: s.chk_dsrdtr
        )
        flow_menu.addSeparator()
        self.act_apply_flow_all = flow_menu.addAction("Apply Current Flow Control to All")
        self.act_apply_flow_all.triggered.connect(self._apply_selected_flow_control_to_all)

        self.act_session_log.triggered.connect(lambda: self._call_selected_session("_toggle_log"))

    def _add_workspace_combo_menu(self, parent_menu, title, values, combo_getter):
        menu = parent_menu.addMenu(title)
        group = QtWidgets.QActionGroup(self)
        group.setExclusive(True)
        self._selected_menu_action_groups.append(group)
        actions = {}
        for raw_value in values:
            value = str(raw_value)
            action = menu.addAction(value)
            action.setCheckable(True)
            action.triggered.connect(
                lambda checked, v=value, getter=combo_getter: self._set_selected_combo(getter, v)
            )
            group.addAction(action)
            actions[value] = action
        return actions

    def _add_workspace_check_action(self, parent_menu, title, checkbox_getter):
        action = parent_menu.addAction(title)
        action.setCheckable(True)
        action.triggered.connect(
            lambda checked, getter=checkbox_getter: self._set_selected_checkbox(getter, checked)
        )
        return action

    def _call_selected_session(self, method_name):
        session = self._selected_or_first_session()
        if session is None:
            return
        getattr(session, method_name)()
        self._sync_selected_session_menus()

    def _set_selected_combo(self, combo_getter, value):
        session = self._selected_or_first_session()
        if session is None:
            return
        combo_getter(session).setCurrentText(value)
        self._sync_selected_session_menus()

    def _set_selected_checkbox(self, checkbox_getter, checked):
        session = self._selected_or_first_session()
        if session is None:
            return
        checkbox_getter(session).setChecked(bool(checked))
        self._sync_selected_session_menus()

    def _selected_or_first_session(self):
        if self._selected_session in self.sessions:
            return self._selected_session
        return self.sessions[0] if self.sessions else None

    def _sync_selected_session_menus(self):
        session = self._selected_or_first_session()
        enabled = session is not None
        menu_actions = [
            self.act_session_log,
            self.act_session_local_echo,
            self.act_session_vt100,
            self.act_session_hex,
            self.act_session_timestamps,
            self.act_session_rtscts,
            self.act_session_xonxoff,
            self.act_session_dsrdtr,
            self.act_apply_settings_all,
            self.act_apply_terminal_all,
            self.act_apply_flow_all,
        ]
        combo_sets = [
            (self._session_baud_actions, session.baud_combo.currentText() if enabled else ""),
            (self._session_bytesize_actions, session.bytesize_combo.currentText() if enabled else ""),
            (self._session_parity_actions, session.parity_combo.currentText() if enabled else ""),
            (self._session_stop_actions, session.stop_combo.currentText() if enabled else ""),
            (self._session_encoding_actions, session.encoding_combo.currentText() if enabled else ""),
            (self._session_enter_actions, session.enter_combo.currentText() if enabled else ""),
        ]

        for action in menu_actions:
            action.setEnabled(enabled)
        for actions, current in combo_sets:
            for value, action in actions.items():
                action.setEnabled(enabled)
                action.setChecked(enabled and value == current)
        if not enabled:
            return

        self.act_session_log.setText("Stop Log" if session._log_fp else "Start Log...")
        apply_all_enabled = enabled
        self.act_apply_settings_all.setEnabled(apply_all_enabled)
        self.act_apply_terminal_all.setEnabled(apply_all_enabled)
        self.act_apply_flow_all.setEnabled(apply_all_enabled)
        self.act_session_local_echo.setChecked(session.chk_local_echo.isChecked())
        self.act_session_vt100.setChecked(session.chk_vt100.isChecked())
        self.act_session_hex.setChecked(session.chk_hex.isChecked())
        self.act_session_timestamps.setChecked(session.chk_timestamps.isChecked())
        self.act_session_rtscts.setChecked(session.chk_rtscts.isChecked())
        self.act_session_xonxoff.setChecked(session.chk_xonxoff.isChecked())
        self.act_session_dsrdtr.setChecked(session.chk_dsrdtr.isChecked())

    def _apply_selected_settings_to_all(self):
        source = self._selected_or_first_session()
        if source is None:
            return
        values = {
            "port": source.port_combo.currentText(),
            "baud": source.baud_combo.currentText(),
            "bytesize": source.bytesize_combo.currentText(),
            "parity": source.parity_combo.currentText(),
            "stop": source.stop_combo.currentText(),
        }
        for session in self.sessions:
            session.port_combo.setCurrentText(values["port"])
            session.baud_combo.setCurrentText(values["baud"])
            session.bytesize_combo.setCurrentText(values["bytesize"])
            session.parity_combo.setCurrentText(values["parity"])
            session.stop_combo.setCurrentText(values["stop"])
        self._sync_selected_session_menus()
        self._save_settings()

    def _apply_selected_terminal_options_to_all(self):
        source = self._selected_or_first_session()
        if source is None:
            return
        values = {
            "encoding": source.encoding_combo.currentText(),
            "enter": source.enter_combo.currentText(),
            "local_echo": source.chk_local_echo.isChecked(),
            "vt100": source.chk_vt100.isChecked(),
            "hex": source.chk_hex.isChecked(),
            "timestamps": source.chk_timestamps.isChecked(),
        }
        for session in self.sessions:
            session.encoding_combo.setCurrentText(values["encoding"])
            session.enter_combo.setCurrentText(values["enter"])
            session.chk_local_echo.setChecked(values["local_echo"])
            session.chk_vt100.setChecked(values["vt100"])
            session.chk_hex.setChecked(values["hex"])
            session.chk_timestamps.setChecked(values["timestamps"])
        self._sync_selected_session_menus()
        self._save_settings()

    def _apply_selected_flow_control_to_all(self):
        source = self._selected_or_first_session()
        if source is None:
            return
        values = {
            "rtscts": source.chk_rtscts.isChecked(),
            "xonxoff": source.chk_xonxoff.isChecked(),
            "dsrdtr": source.chk_dsrdtr.isChecked(),
        }
        for session in self.sessions:
            session.chk_rtscts.setChecked(values["rtscts"])
            session.chk_xonxoff.setChecked(values["xonxoff"])
            session.chk_dsrdtr.setChecked(values["dsrdtr"])
        self._sync_selected_session_menus()
        self._save_settings()

    def _rebuild_grid(self):
        old_grid = self._grid
        if old_grid is not None:
            for session in self.sessions:
                self._take_session_from_grid(old_grid, session)
            self._content_layout.removeWidget(old_grid)
            old_grid.deleteLater()

        rows, cols = self._grid_shape(len(self.sessions))
        self._grid = SplitterGrid(rows, cols, self)
        self._content_layout.addWidget(self._grid, 1)
        for index, session in enumerate(self.sessions):
            row = index // cols
            col = index % cols
            self._grid.addWidget(session, row, col)
        self._grid.distribute_evenly()
        QtCore.QTimer.singleShot(0, self._grid.distribute_evenly)

    def _detach_session_from_grid(self, session):
        if self._grid is None:
            return
        self._take_session_from_grid(self._grid, session)

    @staticmethod
    def _take_session_from_grid(grid, session):
        for (row, col), widget in list(grid._cells.items()):
            if widget is session:
                grid.takeWidget(row, col)
                return

    @staticmethod
    def _grid_shape(count):
        count = max(1, int(count))
        if count == 1:
            return 1, 1
        if count == 2:
            return 1, 2
        cols = min(3, math.ceil(math.sqrt(count)))
        rows = math.ceil(count / cols)
        return rows, cols

    def _read_settings(self):
        try:
            data = load_json(SERIAL_SETTINGS)
        except Exception:
            data = {}
        return data if isinstance(data, dict) else {}

    def _load_macros_config(self, settings_data=None):
        data = settings_data if isinstance(settings_data, dict) else self._read_settings()
        macros = data.get("macros") if isinstance(data, dict) else None
        if macros:
            return normalize_macro_config(macros)
        return normalize_macro_config(DEFAULT_MACRO_CONFIG.copy())

    def _session_settings_from_data(self, data):
        workspace = data.get("workspace") if isinstance(data, dict) else None
        sessions = workspace.get("sessions") if isinstance(workspace, dict) else None
        if isinstance(sessions, list) and sessions:
            return [item for item in sessions if isinstance(item, dict)]

        legacy_keys = set(SerialConfig.__dataclass_fields__.keys())
        if isinstance(data, dict) and legacy_keys.intersection(data):
            settings = self._settings_from_config(self._default_cfg, "Serial 1")
            settings.update({key: data[key] for key in legacy_keys if key in data})
            settings["name"] = data.get("name", "Serial 1")
            return [settings]
        return [self._settings_from_config(self._default_cfg, "Serial 1")]

    def _save_settings(self):
        if self._loading_settings:
            return
        data = self._read_settings()
        data["workspace"] = {
            "sessions": [session.to_settings() for session in self.sessions],
        }
        data["macros"] = normalize_macro_config(self._macros_config)
        if self.sessions:
            data.update(self.sessions[0].to_settings())

        try:
            save_json(SERIAL_SETTINGS, data)
        except Exception as e:
            print(f"Failed to save serial settings: {e}")

    @staticmethod
    def _config_from_settings(settings):
        cfg = SerialConfig()
        if isinstance(settings, dict):
            for key in cfg.__dataclass_fields__:
                if key in settings:
                    setattr(cfg, key, settings[key])
        return cfg

    @staticmethod
    def _settings_from_config(cfg, name):
        data = {
            key: getattr(cfg, key)
            for key in cfg.__dataclass_fields__
        }
        data["name"] = name
        return data

    def closeEvent(self, ev: QtGui.QCloseEvent):
        try:
            for session in list(self.sessions):
                session.disconnect_serial()
            self._save_settings()
        finally:
            super().closeEvent(ev)
