import os
import time
import threading
from dataclasses import dataclass, field
from typing import Dict, Tuple, Optional, List

from PyQt5 import QtWidgets, QtCore, QtGui
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from app.utils import load_json, save_json, FTP_SERVER_SETTINGS, PROJECT_ROOT
from app.tool_api import ToolCallFuture
import logging

import psutil
import socket

from pathlib import Path

def _norm_slash(p: str) -> str:
    return (p or "").replace("\\", "/").strip()

def _is_abs(p: str) -> bool:
    try:
        return Path(p).is_absolute()
    except Exception:
        return False

def _rel_to_abs(rel_path: str) -> str:
    rel_path = _norm_slash(rel_path)
    if _is_abs(rel_path):
        return rel_path
    return str((Path(PROJECT_ROOT) / rel_path).resolve())

def _abs_to_rel(abs_path: str) -> str:
    abs_path = str(Path(abs_path).resolve())
    try:
        rel = Path(abs_path).resolve().relative_to(Path(PROJECT_ROOT).resolve())
        return rel.as_posix()
    except Exception:
        return _norm_slash(abs_path)


def find_process_using_port(port):
    """
    Return (pid, name) of the process using `port`, or (None, None) if free.
    Requires psutil; otherwise fallback returns None.
    """
    try:
        for conn in psutil.net_connections(kind='inet'):
            if conn.laddr.port == port and conn.pid:
                try:
                    p = psutil.Process(conn.pid)
                    return conn.pid, p.name()
                except Exception:
                    return conn.pid, "Unknown"
    except Exception:
        pass

    # Fallback: check if port is bindable
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("0.0.0.0", port))
        s.close()
        return None, None
    except OSError:
        # port is in use but we don't know the PID
        return -1, "Unknown"

class QtFTPRedirectHandler(logging.Handler):
    def __init__(self, qt_logger):
        super().__init__()
        self.qt_logger = qt_logger

    def emit(self, record):
        msg = self.format(record)

        # -----------------------------
        # Color mapping by log category
        # -----------------------------
        level = record.levelname.upper()
        message = record.getMessage().upper()

        if "RESPONSE" in message:
            lvl = "INFO_RESPONSE"   # blue
        elif "COMMAND" in message:
            lvl = "INFO_COMMAND"    # purple
        elif level == "WARNING":
            lvl = "WARN"            # yellow
        elif level == "ERROR" or "ERROR" in message:
            lvl = "ERROR"           # red
        else:
            lvl = "INFO"

        self.qt_logger(lvl, msg)

class AdvancedLogWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.user_scrolled = False
        self._keep_bottom = True
        self._entries = []  # store all logs for filtering

        # ---------------- Toolbar ----------------
        toolbar = QtWidgets.QHBoxLayout()
        toolbar.setContentsMargins(0, 0, 0, 0)

        self.filter_combo = QtWidgets.QComboBox()
        self.filter_combo.addItems(["All", "Info", "Warning", "Error", "Event"])
        self.filter_combo.currentIndexChanged.connect(self._apply_filter)

        clear_btn = QtWidgets.QToolButton(text="🧹 Clear")
        clear_btn.clicked.connect(self.clear)

        save_btn = QtWidgets.QToolButton(text="💾 Save")
        save_btn.clicked.connect(self._save_to_file)

        toolbar.addWidget(QtWidgets.QLabel("Filter:"))
        toolbar.addWidget(self.filter_combo)
        toolbar.addStretch()
        toolbar.addWidget(clear_btn)
        toolbar.addWidget(save_btn)

        # ---------------- Log Output ----------------
        self.output = QtWidgets.QPlainTextEdit(readOnly=True)
        # self.output.setStyleSheet("""
        #     QPlainTextEdit {
        #         font-family: Consolas, monospace;
        #         font-size: 12px;
        #         background: #101010;
        #         color: #DDDDDD;
        #         border: 1px solid #404040;
        #     }
        # """)

        # Track scroll
        sb = self.output.verticalScrollBar()
        sb.valueChanged.connect(self._on_scroll)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addLayout(toolbar)
        layout.addWidget(self.output)

    # ---------------- Public API ----------------
    def log(self, level: str, text: str):
        """
        Level: INFO / WARN / ERROR / EVENT
        """
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        entry = (ts, level, text)
        self._entries.append(entry)

        if self._passes_filter(level):
            self._append_to_widget(entry)

    def clear(self):
        self.output.clear()

    # ---------------- Filtering ----------------
    def _apply_filter(self):
        self.output.clear()
        for entry in self._entries:
            ts, lvl, txt = entry
            if self._passes_filter(lvl):
                self._append_to_widget(entry)

    def _passes_filter(self, lvl):
        mode = self.filter_combo.currentText()
        return mode == "All" or lvl.lower().startswith(mode.lower())

    # ---------------- Append + Auto-scroll ----------------
    def _append_to_widget(self, entry):
        ts, level, text = entry

        color = {
            "INFO": "#000000",              # black
            "WARN": "#E6C229",              # yellow
            "ERROR": "#FF4C4C",             # red
            "EVENT": "#4EA1F7",             # light blue

            # pyftpdlib custom colors:
            "INFO_RESPONSE": "#1a73e8",     # bright blue
            "INFO_COMMAND":  "#9b59b6",     # purple
        }.get(level, "#000000")

        html = f"""<span style='color: #888888'> {ts}</span>
                   <span style='color:{color}'> [{level}]</span>
                   <span style='color:#000000'> {text}</span>"""

        self.output.appendHtml(html)

        QtCore.QTimer.singleShot(0, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        if not self.user_scrolled:
            bar = self.output.verticalScrollBar()
            bar.setValue(bar.maximum())

    def _on_scroll(self, value):
        bar = self.output.verticalScrollBar()
        self.user_scrolled = value < bar.maximum() - 5  # small tolerance

    # ---------------- Save to file ----------------
    def _save_to_file(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save Log", "ftp_log.txt")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                for ts, lvl, txt in self._entries:
                    f.write(f"{ts} [{lvl}] {txt}\n")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Error", f"Failed to save: {e}")

# ----------------------------- Tracking Handler ----------------------------- #
class TrackingFTPHandler(FTPHandler):
    """FTPHandler subclass that reports lifecycle + transfer stats to a manager.

    A class attribute `session_manager` is set by the server thread before use.
    """
    session_manager: "FTPServerThread" = None  # set by FTPServerThread

    # ---- Connection lifecycle ----
    def on_connect(self):
        super().on_connect()
        sm = type(self).session_manager
        if sm:
            sm._on_connect(self)

    def on_disconnect(self):
        sm = type(self).session_manager
        if sm:
            sm._on_disconnect(self)
        super().on_disconnect()

    def on_login(self, username):
        sm = type(self).session_manager
        if sm:
            sm._on_login(self, username)
        return super().on_login(username)

    def on_logout(self, username):
        sm = type(self).session_manager
        if sm:
            sm._on_logout(self, username)
        return super().on_logout(username)

    # ---- Transfers ----
    def on_file_sent(self, file):
        sm = type(self).session_manager
        if sm:
            size = os.path.getsize(file) if os.path.exists(file) else 0
            sm._on_bytes_out(self, size)
            sm._on_transfer_done(self, file, success=True)
        return super().on_file_sent(file)

    def on_file_received(self, file):
        sm = type(self).session_manager
        if sm:
            size = os.path.getsize(file) if os.path.exists(file) else 0
            sm._on_bytes_in(self, size)
            sm._on_transfer_done(self, file, success=True)
        return super().on_file_received(file)

    def on_incomplete_file_sent(self, file):
        # No size accounted; log only
        sm = type(self).session_manager
        if sm:
            sm._on_transfer_done(self, file, success=False)
        return super().on_incomplete_file_sent(file)

    def on_incomplete_file_received(self, file):
        sm = type(self).session_manager
        if sm:
            sm._on_transfer_done(self, file, success=False)
        return super().on_incomplete_file_received(file)

    def pre_process_command(self, line, cmd, arg):
        """
        Intercept FTP commands BEFORE pyftpdlib processes them.
        This method MUST call super() or the server will break.
        """
        sm = type(self).session_manager
        if sm:
            sm._on_command(self, cmd, arg)

        # VERY IMPORTANT: forward everything unchanged
        return super().pre_process_command(line, cmd, arg)

    def push_dtp_data(self, producer, *args, **kwargs):
        """
        Intercept outgoing (RETR) data.
        'producer' may be a file-like object or generator.
        """
        sm = type(self).session_manager
        if sm:
            try:
                # producer can be a file descriptor
                if hasattr(producer, "tell") and hasattr(producer, "read"):
                    # Estimate chunk size safely
                    pos = producer.tell()
                    data = producer.read(8192)
                    if data:
                        sm._on_transfer_chunk(self, len(data), outgoing=True)
                        producer.seek(pos)
            except Exception:
                pass

        return super().push_dtp_data(producer, *args, **kwargs)

    def recv(self, size):
        data = super().recv(size)
        sm = type(self).session_manager
        if sm and data:
            sm._on_transfer_chunk(self, len(data), outgoing=False)
        return data

@dataclass
class SessionInfo:
    peer: Tuple[str, int]
    username: str = ""
    status: str = "connected"

    start_ts: float = field(default_factory=time.time)
    last_ts: float = field(default_factory=time.time)
    end_ts: float = 0.0

    bytes_in: int = 0
    bytes_out: int = 0

    last_command: str = ""
    last_file: str = ""
    last_result: str = ""
    transfer_state: str = "Idle"

    # 🔥 PROGRESS
    transfer_total: int = 0
    transfer_done: int = 0

    def progress_pct(self) -> str:
        if self.transfer_total <= 0:
            return "-"
        return f"{int(self.transfer_done * 100 / self.transfer_total)}%"


    def uptime_str(self) -> str:
        end = self.end_ts if self.end_ts else time.time()
        secs = int(end - self.start_ts)
        h, rem = divmod(secs, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"
    
# ------------------------------ Server Thread ------------------------------ #
class FTPServerThread(threading.Thread):
    def __init__(self, host: str, port: int, authorizer: DummyAuthorizer, log_callback):
        super().__init__(daemon=True)
        self.host = host
        self.port = port
        self.authorizer = authorizer
        self._log_callback = log_callback

        # ---------- Redirect pyftpdlib logging ----------
        logger = logging.getLogger("pyftpdlib")
        logger.setLevel(logging.INFO)

        # 🔥 REMOVE existing QtFTPRedirectHandler(s)
        for h in list(logger.handlers):
            if isinstance(h, QtFTPRedirectHandler):
                logger.removeHandler(h)

        handler = QtFTPRedirectHandler(
            lambda lvl, msg: self._log_callback(lvl, msg)
        )
        handler.setFormatter(logging.Formatter('%(message)s'))

        logger.addHandler(handler)
        logger.propagate = False
        # -------------------------------------------------

        # Thread‑safe session map
        self._lock = threading.RLock()
        self._sessions: Dict[Tuple[str, int], SessionInfo] = {}

        # Prepare handler and server
        TrackingFTPHandler.session_manager = self  # back‑reference
        self._handler_cls = TrackingFTPHandler
        self._handler_cls.authorizer = self.authorizer
        self._handler_cls.banner = "PyQt FTP Server Ready"

        self._server: Optional[FTPServer] = None
        self._running = threading.Event()

    # ---- lifecycle ----
    def run(self):
        self._server = FTPServer((self.host, self.port), self._handler_cls)
        self._running.set()
        self._log("INFO", f"🚀 FTP Server started on {self.host}:{self.port}")
        try:
            self._server.serve_forever(timeout=1, blocking=True)
        except Exception as e:
            self._log("ERROR", f"❌ Server error: {e}")
        finally:
            self._running.clear()

    def stop(self):
        if self._server:
            self._server.close_all()
        self._running.clear()
        self._log("INFO", "🛑 FTP Server stopped")

    def is_running(self) -> bool:
        return self._running.is_set()

    def submit(self, func, future: Optional[ToolCallFuture] = None) -> ToolCallFuture:
        """Schedule ``func`` on pyftpdlib's I/O loop."""
        future = future or ToolCallFuture()

        def execute():
            try:
                future.set_result(func())
            except BaseException as error:
                future.set_exception(error)

        if threading.current_thread() is self:
            execute()
        elif self._server is None:
            future.set_exception(RuntimeError("FTP server is not running"))
        else:
            try:
                self._server.ioloop.call_later(0, execute)
            except BaseException as error:
                future.set_exception(error)
        return future

    # ---- logging helper ----
    def _log(self, level, msg):
        try:
            self._log_callback(level, msg)
        except Exception:
            pass

    # ---- event hooks from handler ----
    def _key(self, h: TrackingFTPHandler) -> Tuple[str, int]:
        return (getattr(h, "remote_ip", "?"), getattr(h, "remote_port", 0))

    def _touch(self, key):
        with self._lock:
            if key in self._sessions:
                self._sessions[key].last_ts = time.time()

    def _on_connect(self, h: TrackingFTPHandler):
        key = self._key(h)
        with self._lock:
            self._sessions[key] = SessionInfo(peer=key)
        self._log("EVENT", f"🔌 Connected: {key[0]}:{key[1]}")

    def _on_disconnect(self, h: TrackingFTPHandler):
        key = self._key(h)
        with self._lock:
            if key in self._sessions:
                sess = self._sessions[key]
                sess.status = "disconnected"
                sess.last_ts = time.time()
                sess.end_ts = time.time()    # <<< FREEZE UPTIME
        self._log("EVENT", f"❌ Disconnected: {key[0]}:{key[1]}")

    def _on_login(self, h: TrackingFTPHandler, username: str):
        key = self._key(h)
        with self._lock:
            sess = self._sessions.setdefault(key, SessionInfo(peer=key))
            sess.username = username
            sess.status = "authenticated"
            sess.last_ts = time.time()
        self._log("EVENT", f"✅ Login: {username} @ {key[0]}:{key[1]}")

    def _on_logout(self, h: TrackingFTPHandler, username: str):
        key = self._key(h)
        with self._lock:
            if key in self._sessions:
                sess = self._sessions[key]
                sess.status = "disconnected"
                sess.last_ts = time.time()
                sess.end_ts = time.time()    # <<< FREEZE HERE TOO
        self._log("EVENT", f"👋 Logout: {username} @ {key[0]}:{key[1]}")

    def _on_bytes_in(self, h: TrackingFTPHandler, nbytes: int):
        key = self._key(h)
        with self._lock:
            if key in self._sessions:
                self._sessions[key].bytes_in += max(0, nbytes)
                self._sessions[key].last_ts = time.time()

    def _on_bytes_out(self, h: TrackingFTPHandler, nbytes: int):
        key = self._key(h)
        with self._lock:
            if key in self._sessions:
                self._sessions[key].bytes_out += max(0, nbytes)
                self._sessions[key].last_ts = time.time()
    
    def _on_command(self, h, cmd, arg):
        key = self._key(h)
        with self._lock:
            sess = self._sessions.get(key)
            if not sess:
                return

            sess.last_command = cmd
            sess.last_ts = time.time()

            if cmd == "RETR" and arg:
                try:
                    path = h.fs.ftp2fs(arg)
                    sess.transfer_total = os.path.getsize(path)
                    sess.transfer_done = 0
                except Exception:
                    sess.transfer_total = 0

            elif cmd == "STOR" and arg:
                sess.transfer_total = 0   # unknown until first chunk
                sess.transfer_done = 0

            if arg:
                sess.last_file = arg

            if cmd in ("RETR", "STOR"):
                sess.transfer_state = "Transferring"
    
    def _on_transfer_chunk(self, h, nbytes: int, outgoing: bool):
        key = self._key(h)
        with self._lock:
            sess = self._sessions.get(key)
            if not sess:
                return

            sess.transfer_done += nbytes
            sess.last_ts = time.time()

            if outgoing:
                sess.bytes_out += nbytes
            else:
                sess.bytes_in += nbytes

    def _on_transfer_done(self, h, file, success: bool):
        key = self._key(h)
        with self._lock:
            sess = self._sessions.get(key)
            if not sess:
                return

            sess.last_file = file
            sess.last_result = "SUCCESS" if success else "FAILED"
            sess.transfer_state = "Idle"
            sess.last_ts = time.time()

            sess.transfer_done = sess.transfer_total

    # ---- snapshot for UI ----
    def snapshot(self) -> List[SessionInfo]:
        with self._lock:
            return [SessionInfo(**vars(v)) for v in self._sessions.values()]

# ------------------------------ Server Widget ------------------------------ #
class PasswordDelegate(QtWidgets.QStyledItemDelegate):
    def displayText(self, value, locale):
        return "•" * len(value)
    
class FTPServerWidget(QtWidgets.QWidget):
    server_event = QtCore.pyqtSignal(str, str)  # level, message

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FTP Server Manager")
        self.resize(1200,800)

        # --- Top bar ---
        self.host_edit = QtWidgets.QLineEdit("0.0.0.0")
        self.port_edit = QtWidgets.QLineEdit("2121")
        self.start_btn = QtWidgets.QPushButton("Start Server")
        self.stop_btn = QtWidgets.QPushButton("Stop Server")

        form = QtWidgets.QHBoxLayout()
        form.addWidget(QtWidgets.QLabel("Host")); form.addWidget(self.host_edit)
        form.addWidget(QtWidgets.QLabel("Port")); form.addWidget(self.port_edit)
        form.addWidget(self.start_btn); form.addWidget(self.stop_btn)

        # --- Users table ---
        self.user_table = QtWidgets.QTableWidget(0, 5)
        self.user_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.user_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.user_table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.user_table.setHorizontalHeaderLabels([
            "Username", "Password", "Home Directory", "Relative", "Permissions"
        ])
        self.user_table.horizontalHeader().setStretchLastSection(True)
        self.user_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Interactive)
        self.add_user_btn = QtWidgets.QPushButton("Add User")
        self.del_user_btn = QtWidgets.QPushButton("Remove Selected")

        # --- Context menu for user table ---
        self.user_table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.user_table.customContextMenuRequested.connect(self._on_user_context_menu)

        self.user_table.setItemDelegateForColumn(1, PasswordDelegate(self.user_table))

        user_controls = QtWidgets.QHBoxLayout()
        user_controls.addWidget(self.add_user_btn)
        user_controls.addWidget(self.del_user_btn)

        # --- Live connections ---
        self.conn_table = QtWidgets.QTableWidget(0, 10)
        self.conn_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.conn_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.conn_table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.conn_table.setHorizontalHeaderLabels([
            "Peer",
            "User",
            "Status",
            "Command",
            "File",
            "Result",
            "Bytes In",
            "Bytes Out",
            "Progress",
            "Uptime",
        ])
        self.conn_table.horizontalHeader().setStretchLastSection(True)
        self.conn_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Interactive)

        # --- Log output ---
        self.log_widget = AdvancedLogWidget(self)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(QtWidgets.QLabel("FTP Users"))
        layout.addWidget(self.user_table, 2)
        layout.addLayout(user_controls)
        layout.addWidget(QtWidgets.QLabel("Active Connections"))
        layout.addWidget(self.conn_table, 2)
        layout.addWidget(QtWidgets.QLabel("Server Log"))
        layout.addWidget(self.log_widget, 2)

        # --- Backend state ---
        self._authorizer = DummyAuthorizer()
        self._server_thread: Optional[FTPServerThread] = None
        self._load_settings()

        # --- Wire buttons ---
        self.start_btn.clicked.connect(self.start_server)
        self.stop_btn.clicked.connect(self.stop_server)
        self.add_user_btn.clicked.connect(self.add_user_dialog)
        self.del_user_btn.clicked.connect(self.remove_selected_users)
        self.stop_btn.setEnabled(False)

        # --- Polling timer for sessions ---
        self._poll = QtCore.QTimer(self)
        self._poll.setInterval(500)
        self._poll.timeout.connect(self.refresh_connections)

    # ---------------- Logging ---------------- #
    def log(self, msg: str):
        # Detect level automatically
        if "❌" in msg or "⚠️" in msg:
            level = "ERROR"
        elif "⚠" in msg:
            level = "WARN"
        elif "Connected" in msg or "Login" in msg or "Logout" in msg:
            level = "EVENT"
        else:
            level = "INFO"

        self.log_widget.log(level, msg)

    @QtCore.pyqtSlot(str, str)
    def log_threadsafe(self, level, msg):
        self.log_widget.log(level, msg)

    def _dispatch_log(self, level, msg):
        self.server_event.emit(str(level), str(msg))
        QtCore.QMetaObject.invokeMethod(
            self,
            "log_threadsafe",
            QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(str, level),
            QtCore.Q_ARG(str, msg)
        )

    # ---------------- Users ---------------- #
    def add_user_dialog(self):
        """Add new FTP user — with aligned password + home directory icons + relative home option."""
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Add FTP User")
        layout = QtWidgets.QVBoxLayout(dlg)

        form = QtWidgets.QFormLayout()
        user_edit = QtWidgets.QLineEdit()

        # --- Password field with 👁️ eye toggle ---
        pass_edit = QtWidgets.QLineEdit()
        pass_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        pass_edit.setMinimumWidth(200)

        eye_btn = QtWidgets.QToolButton()
        eye_btn.setText("👁️")
        eye_btn.setCursor(QtCore.Qt.PointingHandCursor)
        eye_btn.setToolTip("Show/Hide Password")
        eye_btn.setFixedSize(20, 20)

        def toggle_echo():
            if pass_edit.echoMode() == QtWidgets.QLineEdit.Password:
                pass_edit.setEchoMode(QtWidgets.QLineEdit.Normal)
            else:
                pass_edit.setEchoMode(QtWidgets.QLineEdit.Password)

        eye_btn.clicked.connect(toggle_echo)

        pass_container = QtWidgets.QWidget()
        pass_layout = QtWidgets.QHBoxLayout(pass_container)
        pass_layout.setContentsMargins(0, 0, 0, 0)
        pass_layout.setSpacing(0)
        pass_layout.addWidget(pass_edit)
        pass_layout.addWidget(eye_btn)

        # --- Home Directory field with 📁 browse button ---
        home_edit = QtWidgets.QLineEdit()
        home_edit.setMinimumWidth(260)
        home_edit.setText("data/ftp")  # reasonable default inside project

        browse_btn = QtWidgets.QToolButton()
        browse_btn.setText("📁")
        browse_btn.setCursor(QtCore.Qt.PointingHandCursor)
        browse_btn.setToolTip("Select Home Directory")
        browse_btn.setFixedSize(20, 20)

        home_container = QtWidgets.QWidget()
        home_layout = QtWidgets.QHBoxLayout(home_container)
        home_layout.setContentsMargins(0, 0, 0, 0)
        home_layout.setSpacing(0)
        home_layout.addWidget(home_edit)
        home_layout.addWidget(browse_btn)

        # --- Relative checkbox (MUST be near home row) ---
        relative_cb = QtWidgets.QCheckBox("Relative to Project Root")
        relative_cb.setChecked(True)
        relative_cb.setToolTip(
            "If enabled, the Home Directory is stored as a path relative to PROJECT_ROOT.\n"
            "This makes settings portable when moving the app to another PC.\n\n"
            f"Current PROJECT_ROOT:\n{PROJECT_ROOT}"
        )

        # Wrap checkbox in a small row-like container so it sits visually under Home Directory
        rel_row = QtWidgets.QWidget()
        rel_row_lay = QtWidgets.QHBoxLayout(rel_row)
        rel_row_lay.setContentsMargins(0, 0, 0, 0)
        rel_row_lay.setSpacing(6)
        rel_row_lay.addWidget(relative_cb)
        rel_row_lay.addStretch()

        def refresh_home_display():
            txt = _norm_slash(home_edit.text())
            if not txt:
                return

            if relative_cb.isChecked():
                # abs -> rel
                if _is_abs(txt):
                    home_edit.setText(_abs_to_rel(txt))
            else:
                # rel -> abs
                if not _is_abs(txt):
                    home_edit.setText(_norm_slash(_rel_to_abs(txt)))

        def select_folder():
            start = _norm_slash(home_edit.text())

            # if relative and start is relative -> interpret inside project
            if relative_cb.isChecked() and start and not _is_abs(start):
                start = _rel_to_abs(start)

            # default start folder
            if not start:
                start = str(PROJECT_ROOT)

            folder = QtWidgets.QFileDialog.getExistingDirectory(
                dlg, "Select Home Directory", start
            )
            if folder:
                folder = _norm_slash(folder)
                if relative_cb.isChecked():
                    home_edit.setText(_abs_to_rel(folder))
                else:
                    home_edit.setText(folder)

        browse_btn.clicked.connect(select_folder)
        relative_cb.toggled.connect(refresh_home_display)

        # --- Permissions checkboxes ---
        perms_group = QtWidgets.QGroupBox("Permissions")
        grid = QtWidgets.QGridLayout(perms_group)
        perm_flags = [
            ("e", "Change Directory"),
            ("l", "List Files"),
            ("r", "Retrieve (Download)"),
            ("a", "Append File"),
            ("d", "Delete File"),
            ("f", "Rename File"),
            ("m", "Make Directory"),
            ("w", "Store (Upload)"),
            ("M", "CHMOD"),
            ("T", "Modify Time"),
        ]
        checkboxes = []
        for i, (code, desc) in enumerate(perm_flags):
            cb = QtWidgets.QCheckBox(f"{code} - {desc}")
            cb.setChecked(code in "elradfmwMT")  # default perms
            checkboxes.append((code, cb))
            grid.addWidget(cb, i // 2, i % 2)

        # --- Compose layout ---
        form.addRow("Username", user_edit)
        form.addRow("Password", pass_container)
        form.addRow("Home Directory", home_container)
        form.addRow("", rel_row)  # visually directly under Home Directory

        layout.addLayout(form)
        layout.addWidget(perms_group)

        # --- OK / Cancel buttons ---
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        layout.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)

        QtCore.QTimer.singleShot(0, refresh_home_display)

        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            username = user_edit.text().strip()
            password = pass_edit.text().strip()
            home = _norm_slash(home_edit.text())
            home_relative = relative_cb.isChecked()
            perms = "".join(code for code, cb in checkboxes if cb.isChecked())

            if username and password and home:
                self.add_user(username, password, home, perms, home_relative)

    def add_user(self, username: str, password: str, home: str, perms: str, home_relative: bool = False):
        home = _norm_slash(home)

        # resolve actual home for FTP backend
        real_home = _rel_to_abs(home) if home_relative else str(Path(home).resolve())

        os.makedirs(real_home, exist_ok=True)
        self._authorizer.add_user(username, password, real_home, perm=perms)

        row = self.user_table.rowCount()
        self.user_table.insertRow(row)

        values = [username, password, home, "Yes" if home_relative else "No", perms]
        for col, val in enumerate(values):
            self.user_table.setItem(row, col, QtWidgets.QTableWidgetItem(val))

        self.log(f"👤 Added user '{username}' perms='{perms}' relative={home_relative}")
        self._save_settings()

    def remove_selected_users(self):
        rows = sorted({i.row() for i in self.user_table.selectedIndexes()}, reverse=True)
        for row in rows:
            username_item = self.user_table.item(row, 0)
            if not username_item:
                continue
            username = username_item.text()
            try:
                self._authorizer.remove_user(username)
                self.log(f"🗑️ Removed user {username}")
            except Exception as e:
                self.log(f"⚠️ Failed to remove {username}: {e}")
            self.user_table.removeRow(row)
        self._save_settings()

    def remove_user(self, username: str) -> bool:
        """Remove one configured user without depending on table selection."""
        found = False
        for row in range(self.user_table.rowCount() - 1, -1, -1):
            item = self.user_table.item(row, 0)
            if item and item.text() == username:
                self.user_table.removeRow(row)
                found = True
        if not found:
            return False
        try:
            self._authorizer.remove_user(username)
        except KeyError:
            pass
        self.log(f"Removed user {username}")
        self._save_settings()
        return True

    def list_users(self) -> List[dict]:
        users = []
        for row in range(self.user_table.rowCount()):
            values = [self.user_table.item(row, col) for col in range(5)]
            users.append({
                "username": values[0].text() if values[0] else "",
                "password": values[1].text() if values[1] else "",
                "home": values[2].text() if values[2] else "",
                "home_relative": bool(values[3] and values[3].text() == "Yes"),
                "permissions": values[4].text() if values[4] else "",
            })
        return users

    # ---------------- Server Control ---------------- #
    def start_server(self, confirm_port_owner: bool = True):
        host = self.host_edit.text().strip()
        port = int(self.port_edit.text() or 21)

        # ------------------------------
        # Check if port already in use
        # ------------------------------
        pid, pname = find_process_using_port(port)

        if pid is not None and not confirm_port_owner:
            raise OSError(f"Port {port} is already in use")

        if pid is not None and confirm_port_owner:   # port is NOT free
            if pid == -1:
                # No PID known → unknown process holding port
                msg = (
                    f"Port {port} is currently in use by another process.\n\n"
                    "The PID could not be identified.\n"
                    "Do you want to attempt starting the server anyway?"
                )
                reply = QtWidgets.QMessageBox.question(
                    self, "Port In Use", msg,
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No
                )
                if reply == QtWidgets.QMessageBox.No:
                    self.log("⚠️ Server not started. Port is busy.")
                    return
            else:
                # PID known → ask user to terminate
                msg = (
                    f"Port {port} is currently in use.\n\n"
                    f"PID: {pid}\n"
                    f"Process: {pname}\n\n"
                    "Do you want to terminate this process and restart the server?"
                )
                reply = QtWidgets.QMessageBox.question(
                    self, "Port In Use", msg,
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No
                )

                if reply == QtWidgets.QMessageBox.Yes:
                    try:
                        p = psutil.Process(pid)
                        p.terminate()
                        p.wait(3)

                        self.log(f"❗ Terminated process {pname} (PID {pid}) using port {port}.")

                    except psutil.AccessDenied:
                        QtWidgets.QMessageBox.warning(
                            self,
                            "Permission Denied",
                            f"Port {port} is used by:\n\n"
                            f"{pname} (PID {pid})\n\n"
                            "This process requires administrator privileges to terminate.\n\n"
                            "Please stop it manually or run this application as Administrator."
                        )
                        self.log(
                            f"⚠️ Cannot terminate {pname} (PID {pid}) — permission denied."
                        )
                        return

                    except psutil.NoSuchProcess:
                        # Process died between detection and kill attempt
                        pass

                    except Exception as e:
                        QtWidgets.QMessageBox.critical(
                            self,
                            "Error",
                            f"Failed to terminate process:\n{e}"
                        )
                        self.log(f"❌ Failed to terminate process {pid}: {e}")
                        return
                else:
                    self.log("⚠️ Server not started. User declined to kill process.")
                    return

        # --------------------------------
        # Normal server start
        # --------------------------------
        if self._server_thread and self._server_thread.is_alive():
            self.log("⚠️ Server already running")
            return

        self._server_thread = FTPServerThread(host, port, self._authorizer, self._dispatch_log)
        self._server_thread.start()
        self._poll.start()
        self._save_settings()
        self._set_server_running_ui(True)

    def stop_server(self, confirm: bool = True):
        if not self._server_thread:
            return

        if not confirm:
            self._poll.stop()
            self._server_thread.stop()
            self._server_thread = None
            self.conn_table.setRowCount(0)
            self._set_server_running_ui(False)
            return

        reply = QtWidgets.QMessageBox.question(
            self,
            "Stop FTP Server",
            "Are you sure you want to stop the FTP server?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No
        )

        if reply != QtWidgets.QMessageBox.Yes:
            return

        self._poll.stop()

        try:
            self._server_thread.stop()
        except Exception:
            pass

        self._server_thread = None

        self.conn_table.setRowCount(0)
        self._set_server_running_ui(False)

    def _force_stop_server(self):
        try:
            self._poll.stop()
            if self._server_thread:
                self._server_thread.stop()
        except Exception:
            pass
        self._server_thread = None

    def _set_server_running_ui(self, running: bool):
        pal = self.start_btn.palette()

        if running:
            self.start_btn.setEnabled(False)
            self.start_btn.setText("🟢 Running")

            self.stop_btn.setEnabled(True)

        else:
            self.start_btn.setEnabled(True)
            self.start_btn.setText("Start Server")

            self.stop_btn.setEnabled(False)
    
    def _apply_row_color(self, row: int, session: SessionInfo):
        """
        Color a connection row based on transfer / result state.
        """
        if session.transfer_state == "Transferring":
            color = QtGui.QColor("#E3F2FD")   # light blue
        elif session.last_result == "FAILED":
            color = QtGui.QColor("#FFEBEE")   # light red
        elif session.last_result == "SUCCESS":
            color = QtGui.QColor("#E8F5E9")   # light green
        else:
            return  # no coloring

        for col in range(self.conn_table.columnCount()):
            item = self.conn_table.item(row, col)
            if item:
                item.setBackground(color)

    # ---------------- Live Connections ---------------- #
    def refresh_connections(self):
        if not (self._server_thread and self._server_thread.is_alive()):
            return

        snap = self._server_thread.snapshot()
        self.conn_table.setRowCount(0)

        for s in snap:
            row = self.conn_table.rowCount()
            self.conn_table.insertRow(row)

            peer = f"{s.peer[0]}:{s.peer[1]}"
            cells = [
                peer,
                s.username or "-",
                s.status,
                s.last_command or "-",
                os.path.basename(s.last_file) if s.last_file else "-",
                s.last_result or "-",
                f"{s.bytes_in}",
                f"{s.bytes_out}",
                s.progress_pct(),
                s.uptime_str(),
            ]

            for col, val in enumerate(cells):
                self.conn_table.setItem(
                    row, col, QtWidgets.QTableWidgetItem(val)
                )

            # 🔥 APPLY COLOR HERE (AFTER row is filled)
            self._apply_row_color(row, s)
    
    def _load_settings(self):
        """Load host, port, and user list from FTP_SERVER_SETTINGS."""
        try:
            data = load_json(FTP_SERVER_SETTINGS)
        except Exception:
            data = {}

        # Restore host and port
        host = data.get("host", "0.0.0.0")
        port = str(data.get("port", "2121"))
        self.host_edit.setText(host)
        self.port_edit.setText(port)

        # Restore users
        users = data.get("users", [])
        for user in users:
            try:
                username = user.get("username")
                password = user.get("password")
                home = _norm_slash(user.get("home", ""))
                home_relative = bool(user.get("home_relative", False))
                perms = user.get("perms", "")

                if all([username, password, home]):
                    real_home = _rel_to_abs(home) if home_relative else str(Path(home).resolve())
                    os.makedirs(real_home, exist_ok=True)
                    self._authorizer.add_user(username, password, real_home, perm=perms)

                    row = self.user_table.rowCount()
                    self.user_table.insertRow(row)

                    values = [username, password, home, "Yes" if home_relative else "No", perms]
                    for col, val in enumerate(values):
                        self.user_table.setItem(row, col, QtWidgets.QTableWidgetItem(val))

            except Exception as e:
                self.log(f"⚠️ Failed to load user '{user}': {e}")

        self.log("✅ FTP settings loaded.")

    def _save_settings(self):
        """Save current host, port, and users to FTP_SERVER_SETTINGS."""
        try:
            users = []
            for row in range(self.user_table.rowCount()):
                username = self.user_table.item(row, 0).text()
                password = self.user_table.item(row, 1).text()
                home = _norm_slash(self.user_table.item(row, 2).text())
                home_relative = self.user_table.item(row, 3).text().strip().lower() == "yes"
                perms = self.user_table.item(row, 4).text()

                users.append({
                    "username": username,
                    "password": password,
                    "home": home,
                    "home_relative": home_relative,
                    "perms": perms
                })

            data = {
                "host": self.host_edit.text().strip(),
                "port": int(self.port_edit.text() or 21),
                "users": users
            }
            save_json(FTP_SERVER_SETTINGS, data)
            self.log(f"💾 Settings saved to {FTP_SERVER_SETTINGS}")
        except Exception as e:
            self.log(f"⚠️ Failed to save settings: {e}")

    def _on_user_context_menu(self, pos):
        """Right-click context menu for user table."""
        menu = QtWidgets.QMenu(self)
        act_edit = menu.addAction("Edit User")
        act_del = menu.addAction("Remove User")
        action = menu.exec_(self.user_table.viewport().mapToGlobal(pos))

        if action == act_edit:
            row = self.user_table.currentRow()
            if row >= 0:
                self.edit_user_dialog(row)
        elif action == act_del:
            self.remove_selected_users()
    
    def edit_user_dialog(self, row: int):
        """Edit an existing user in a dialog similar to Add User, with show/hide password toggle + relative home option."""
        username_item = self.user_table.item(row, 0)
        password_item = self.user_table.item(row, 1)
        home_item = self.user_table.item(row, 2)
        relative_item = self.user_table.item(row, 3)
        perms_item = self.user_table.item(row, 4)

        if not username_item:
            return

        old_username = username_item.text()
        old_password = password_item.text() if password_item else ""
        old_home = _norm_slash(home_item.text() if home_item else "")
        old_relative = (relative_item.text().strip().lower() == "yes") if relative_item else False
        old_perms = perms_item.text() if perms_item else ""

        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle(f"Edit FTP User: {old_username}")
        layout = QtWidgets.QVBoxLayout(dlg)
        form = QtWidgets.QFormLayout()

        user_edit = QtWidgets.QLineEdit(old_username)

        # --- Password field with eye toggle ---
        pass_edit = QtWidgets.QLineEdit(old_password)
        pass_edit.setEchoMode(QtWidgets.QLineEdit.Password)
        pass_edit.setMinimumWidth(200)

        eye_btn = QtWidgets.QToolButton()
        eye_btn.setText("👁️")
        eye_btn.setCursor(QtCore.Qt.PointingHandCursor)
        eye_btn.setToolTip("Show/Hide Password")
        eye_btn.setFixedSize(20, 20)

        def toggle_echo():
            if pass_edit.echoMode() == QtWidgets.QLineEdit.Password:
                pass_edit.setEchoMode(QtWidgets.QLineEdit.Normal)
            else:
                pass_edit.setEchoMode(QtWidgets.QLineEdit.Password)

        eye_btn.clicked.connect(toggle_echo)

        pass_container = QtWidgets.QWidget()
        pass_layout = QtWidgets.QHBoxLayout(pass_container)
        pass_layout.setContentsMargins(0, 0, 0, 0)
        pass_layout.setSpacing(0)
        pass_layout.addWidget(pass_edit)
        pass_layout.addWidget(eye_btn)

        # --- Home Directory picker ---
        home_edit = QtWidgets.QLineEdit(old_home)
        home_edit.setMinimumWidth(260)

        browse_btn = QtWidgets.QToolButton()
        browse_btn.setText("📁")
        browse_btn.setCursor(QtCore.Qt.PointingHandCursor)
        browse_btn.setToolTip("Select Home Directory")
        browse_btn.setFixedSize(20, 20)

        home_container = QtWidgets.QWidget()
        home_layout = QtWidgets.QHBoxLayout(home_container)
        home_layout.setContentsMargins(0, 0, 0, 0)
        home_layout.setSpacing(0)
        home_layout.addWidget(home_edit)
        home_layout.addWidget(browse_btn)

        # --- Relative checkbox near home row ---
        relative_cb = QtWidgets.QCheckBox("Relative to Project Root")
        relative_cb.setChecked(old_relative)
        relative_cb.setToolTip(
            "If enabled, Home Directory is stored relative to PROJECT_ROOT.\n"
            "This makes settings portable across PCs.\n\n"
            f"Current PROJECT_ROOT:\n{PROJECT_ROOT}"
        )

        rel_row = QtWidgets.QWidget()
        rel_row_lay = QtWidgets.QHBoxLayout(rel_row)
        rel_row_lay.setContentsMargins(0, 0, 0, 0)
        rel_row_lay.setSpacing(6)
        rel_row_lay.addWidget(relative_cb)
        rel_row_lay.addStretch()

        def refresh_home_display():
            txt = _norm_slash(home_edit.text())
            if not txt:
                return

            if relative_cb.isChecked():
                # abs -> rel
                if _is_abs(txt):
                    home_edit.setText(_abs_to_rel(txt))
            else:
                # rel -> abs
                if not _is_abs(txt):
                    home_edit.setText(_norm_slash(_rel_to_abs(txt)))

        def select_folder():
            start = _norm_slash(home_edit.text())
            if relative_cb.isChecked() and start and not _is_abs(start):
                start = _rel_to_abs(start)

            if not start:
                start = str(PROJECT_ROOT)

            folder = QtWidgets.QFileDialog.getExistingDirectory(
                dlg, "Select Home Directory", start
            )
            if folder:
                folder = _norm_slash(folder)
                if relative_cb.isChecked():
                    home_edit.setText(_abs_to_rel(folder))
                else:
                    home_edit.setText(folder)

        browse_btn.clicked.connect(select_folder)
        relative_cb.toggled.connect(refresh_home_display)

        # --- Permissions grid ---
        perms_group = QtWidgets.QGroupBox("Permissions")
        grid = QtWidgets.QGridLayout(perms_group)

        perm_flags = [
            ("e", "Change Directory"),
            ("l", "List Files"),
            ("r", "Retrieve (Download)"),
            ("a", "Append File"),
            ("d", "Delete File"),
            ("f", "Rename File"),
            ("m", "Make Directory"),
            ("w", "Store (Upload)"),
            ("M", "CHMOD"),
            ("T", "Modify Time"),
        ]
        checkboxes = []
        for i, (code, desc) in enumerate(perm_flags):
            cb = QtWidgets.QCheckBox(f"{code} - {desc}")
            cb.setChecked(code in old_perms)
            checkboxes.append((code, cb))
            grid.addWidget(cb, i // 2, i % 2)

        # --- Compose layout ---
        form.addRow("Username", user_edit)
        form.addRow("Password", pass_container)
        form.addRow("Home Directory", home_container)
        form.addRow("", rel_row)

        layout.addLayout(form)
        layout.addWidget(perms_group)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        layout.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)

        QtCore.QTimer.singleShot(0, refresh_home_display)

        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            username = user_edit.text().strip()
            password = pass_edit.text().strip()
            home = _norm_slash(home_edit.text())
            home_relative = relative_cb.isChecked()
            perms = "".join(code for code, cb in checkboxes if cb.isChecked())

            if username and password and home:
                # Remove old user first
                try:
                    self._authorizer.remove_user(old_username)
                except Exception:
                    pass

                # Add updated user (authorizer needs ABS path)
                real_home = _rel_to_abs(home) if home_relative else str(Path(home).resolve())
                os.makedirs(real_home, exist_ok=True)
                self._authorizer.add_user(username, password, real_home, perm=perms)

                # Update table row (store DISPLAY/CONFIG path as user typed)
                values = [username, password, home, "Yes" if home_relative else "No", perms]
                for col, val in enumerate(values):
                    self.user_table.setItem(row, col, QtWidgets.QTableWidgetItem(val))

                self.log(f"✏️ Updated user '{username}' relative={home_relative}")
                self._save_settings()

    # ---------------- Cleanup ---------------- #
    def closeEvent(self, e: QtGui.QCloseEvent):
        try:
            self._force_stop_server()
            self._save_settings()
        except Exception:
            pass
        super().closeEvent(e)
