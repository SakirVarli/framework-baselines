"""Shared array metadata, reference scopes, and initialization policies (no Qt)."""
from __future__ import annotations

import ast
import operator


ARRAY_MODES = ("fixed", "count_field", "prefixed", "greedy", "count_expression",
               "byte_prefixed", "byte_field", "byte_expression", "sentinel", "repeat_until")
PREFIX_FORMATS = ("uint8", "uint16", "uint24", "uint32", "uint64", "varint")


def prefix_expression(field):
    storage = field.get("prefix_format", "uint16")
    if storage == "varint":
        return "VarInt"
    if storage not in PREFIX_FORMATS:
        raise ValueError("Select an unsigned integer or VarInt prefix format")
    bits = int(storage[4:])
    return f"Int{bits}u{'l' if field.get('prefix_endian', 'little') == 'little' else 'b'}"


def enum_count_reference(field, manifest):
    if field.get('mode') not in {'count_field', 'byte_field'}:
        return False
    key = 'count_field' if field['mode'] == 'count_field' else 'length_field'
    definition = dict(scope_candidates(manifest, field.get('uid'))).get(field.get(key), {})
    while definition.get('kind') in {'const', 'default', 'rebuild'}:
        definition = definition.get('item', {})
    return definition.get('kind') == 'enum'


def scope_candidates(manifest, target_uid):
    """Earlier fields in the actual Struct scope, followed by ancestor scopes."""
    def visit(fields, outer=(), prior=None):
        prior = list(prior or [])
        for field in fields:
            if field.get("uid") == target_uid:
                result = [(value.get("name", ""), value) for value in prior]
                for depth, frame in enumerate(outer, 1):
                    result.extend(("_." * depth + value.get("name", ""), value) for value in frame)
                return result
            if field.get("kind") == "inline_struct":
                found = visit(field.get("fields", []), (prior, *outer))
                if found is not None:
                    return found
            nested = field.get("item")
            if isinstance(nested, dict):
                found = visit([nested], outer, prior)
                if found is not None:
                    return found
            for case in field.get("cases", []):
                if isinstance(case.get("item"), dict):
                    found = visit([case["item"]], outer, prior)
                    if found is not None:
                        return found
            prior.append(field)
        return None

    for owner in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        found = visit(owner.get("fields", []))
        if found is not None:
            return found
    return []


def walk_fields(manifest):
    def visit(fields):
        for field in fields:
            yield field
            yield from visit(field.get("fields", []))
            if isinstance(field.get("item"), dict):
                yield from visit([field["item"]])
            for case in field.get("cases", []):
                if isinstance(case.get("item"), dict):
                    yield from visit([case["item"]])
    for owner in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        yield from visit(owner.get("fields", []))


def bind_array_references(manifest):
    """Keep references attached to stable identities across renames and copies."""
    for field in walk_fields(manifest):
        if field.get("kind") != "array":
            continue
        candidates = scope_candidates(manifest, field.get("uid"))
        for key in ("count_field", "length_field"):
            identity = field.get(key + "_uid")
            if identity:
                match = next(((path, value) for path, value in candidates if value.get("uid") == identity), None)
                if match:
                    field[key] = match[0]
            elif field.get(key):
                match = next((value for path, value in candidates if path == field[key]), None)
                if match:
                    field[key + "_uid"] = match["uid"]


def array_count_expression(field):
    mode = field.get("mode", "fixed")
    if mode == "fixed":
        return str(field.get("count", 0))
    if mode in {"count_field", "byte_field"}:
        key = "count_field" if mode == "count_field" else "length_field"
        return "this." + str(field.get(key, ""))
    return str(field.get("count_expression") or "0")


def initial_count_expression(field):
    if field.get("mode") == "fixed":
        return str(field.get("count", 0))
    initial = field.get("initial_count")
    if initial is not None:
        return str(initial)
    if (field.get("mode") in {"count_field", "count_expression"}
            and not (field.get("mode") == "count_field" and field.get("rebuild_count"))
            and field.get("initial_policy") == "resolve"):
        return array_count_expression(field)
    minimum = field.get('min_count', 0)
    return str(max(minimum if type(minimum) is int else 0, 1 if field.get("mode") == "sentinel" else 0))


def literal_initial_count(field):
    try:
        value = ast.literal_eval(initial_count_expression(field))
    except (ValueError, SyntaxError):
        return None
    return value if type(value) is int else None


def expression_paths(expression):
    """Extract this.field and this._.field dependencies without executing code."""
    paths = set()
    for node in ast.walk(ast.parse(expression, mode='eval')):
        if not isinstance(node, ast.Attribute):
            continue
        parts = []
        while isinstance(node, ast.Attribute):
            parts.append(node.attr); node = node.value
        if isinstance(node, ast.Name) and node.id == 'this':
            path = '.'.join(reversed(parts))
            if path and not path.endswith('_'):
                paths.add(path)
    return {path for path in paths if not any(other.startswith(path + '.') for other in paths)}


def known_initial_count(field, manifest):
    """Resolve literals and basic arithmetic only; never evaluate custom Python."""
    expression = initial_count_expression(field)
    candidates = dict(scope_candidates(manifest, field.get('uid')))
    enums = {value['uid']: value for value in manifest.get('enums', [])}

    def reference(path):
        definition = candidates.get(path)
        if definition is None:
            raise ValueError('unresolved count')
        mode = definition.get('object_default_mode', 'required')
        if mode == 'automatic':
            if definition.get('kind') == 'enum':
                return enums[definition['enum_uid']]['values'][0]['value']
            return 0
        if mode == 'guided':
            value = definition.get('object_default_value') or {}
            if definition.get('kind') == 'enum':
                return next(member['value'] for member in enums[definition['enum_uid']]['values'] if member['uid'] == value.get('value_uid'))
            raw = value.get('value')
            return int(raw, 0) if isinstance(raw, str) else raw
        if mode == 'custom':
            return ast.literal_eval(definition.get('object_default', ''))
        raise ValueError('required count')

    def resolve(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return node.value
        if isinstance(node, ast.Attribute):
            return reference(ast.unparse(node).removeprefix('this.'))
        if isinstance(node, ast.BinOp):
            operations = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
                          ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod}
            if type(node.op) in operations:
                return operations[type(node.op)](resolve(node.left), resolve(node.right))
        raise ValueError('dynamic count expression')

    try:
        value = resolve(ast.parse(expression, mode='eval').body)
        return value if type(value) is int and value >= 0 else None
    except (KeyError, IndexError, ValueError, SyntaxError, TypeError, ArithmeticError, StopIteration):
        return None


def derived_source(manifest, target_uid):
    for field in walk_fields(manifest):
        if field.get('kind') != 'array' or field.get('mode') != 'count_field' or not field.get('rebuild_count'):
            continue
        if field.get('count_field_uid') == target_uid:
            return field
        if not field.get('count_field_uid') and any(path == field.get('count_field') and value.get('uid') == target_uid
                                                  for path, value in scope_candidates(manifest, field.get('uid'))):
            return field
    return None
