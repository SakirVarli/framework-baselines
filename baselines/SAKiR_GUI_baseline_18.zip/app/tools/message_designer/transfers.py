"""Sibling batches shared by definition-tree clipboard actions and drag/drop."""
from __future__ import annotations

import copy
from dataclasses import dataclass

from .model import new_id
from .group_moves import can_move_group


COLLECTIONS = {
    "Enum": "enums", "Structure": "structures", "Group": "groups", "Message": "messages",
    "Field": "fields", "Runtime": "runtime_attributes", "Constant": "constants", "Method": "methods",
}
OWNED_CHILD_KEYS = {"objects", "groups", "messages", "fields", "runtime_attributes", "constants", "methods",
                    "item", "members", "cases", "values", "identifiers"}


@dataclass
class ObjectLocation:
    value: dict
    kind: str
    parent_uid: str
    collection: list | None


def locations(data):
    result = {}
    root = data["library"]["uid"]

    def fields(values, parent_uid, movable=True):
        for value in values:
            result[value["uid"]] = ObjectLocation(value, "Field", parent_uid, values if movable else None)
            fields(value.get("fields", []), value["uid"])
            if isinstance(value.get("item"), dict):
                fields([value["item"]], value["uid"], False)
            for case in value.get("cases", []):
                if isinstance(case.get("item"), dict):
                    fields([case["item"]], value["uid"], False)

    for kind in ("Enum", "Structure", "Group", "Message"):
        values = data.get(COLLECTIONS[kind], [])
        for value in values:
            parent_uid = (value.get("parent_group_uid") if kind == "Group" else
                          value.get("group_uid") if kind == "Message" else root) or root
            result[value["uid"]] = ObjectLocation(value, kind, parent_uid, values)
            if kind in {"Structure", "Message"}:
                fields(value.get("fields", []), value["uid"])
            if kind == "Message":
                for member_kind in ("Runtime", "Constant", "Method"):
                    members = value.get(COLLECTIONS[member_kind], [])
                    for member in members:
                        result[member["uid"]] = ObjectLocation(member, member_kind, value["uid"], members)
    return result


def sources(data, uids, *, moving=False):
    if not uids or len(set(uids)) != len(uids):
        return []
    by_uid = locations(data)
    found = [by_uid.get(uid) for uid in uids]
    if any(item is None for item in found):
        return []
    first = found[0]
    if any(item.kind != first.kind or item.parent_uid != first.parent_uid for item in found):
        return []
    if moving and any(item.collection is None for item in found):
        return []
    # A wrapper's required slots are not an ordered sibling collection.
    if len(found) > 1 and any(item.collection is not first.collection for item in found):
        return []
    if first.collection is not None:
        order = {item["uid"]: index for index, item in enumerate(first.collection)}
        found.sort(key=lambda item: order[item.value["uid"]])
    return found


def destination(data, kind, parent_uid):
    root = data["library"]
    if parent_uid == root["uid"]:
        return (data, COLLECTIONS[kind]) if kind in {"Enum", "Structure", "Group", "Message"} else None
    parent = locations(data).get(parent_uid)
    if parent is None:
        return None
    valid = ((kind in {"Group", "Message"} and parent.kind == "Group") or
             (kind == "Field" and (parent.kind in {"Message", "Structure"} or
                                   parent.kind == "Field" and parent.value.get("kind") == "inline_struct")) or
             (kind in {"Runtime", "Constant", "Method"} and parent.kind == "Message"))
    if not valid:
        return None
    # Routing children are stored in flat manifest lists, not inside their group.
    return (data if kind in {"Group", "Message"} else parent.value, COLLECTIONS[kind])


def destination_children(data, kind, parent_uid):
    target = destination(data, kind, parent_uid)
    if target is None:
        return None
    owner, key = target
    values = owner.get(key, [])
    root = data["library"]["uid"]
    if kind == "Group":
        return [value for value in values if (value.get("parent_group_uid") or root) == parent_uid]
    if kind == "Message":
        return [value for value in values if (value.get("group_uid") or root) == parent_uid]
    return list(values)


def owned_ids(value):
    if isinstance(value, dict):
        if "uid" in value:
            yield value["uid"]
        for key, child in value.items():
            if key in OWNED_CHILD_KEYS:
                yield from owned_ids(child)
    elif isinstance(value, list):
        for child in value:
            yield from owned_ids(child)


def capture(data, uids):
    selected = sources(data, uids)
    if not selected:
        return None
    kind = selected[0].kind
    objects = [item.value for item in selected]
    groups, messages = [], []
    if kind == "Group":
        included = {item["uid"] for item in objects}
        while True:
            children = {group["uid"] for group in data.get("groups", []) if group.get("parent_group_uid") in included}
            if children <= included:
                break
            included.update(children)
        roots = {item["uid"] for item in objects}
        groups = [item for item in data.get("groups", []) if item["uid"] in included - roots]
        messages = [item for item in data.get("messages", []) if item.get("group_uid") in included]
    return copy.deepcopy({"kind": kind, "parent_uid": selected[0].parent_uid,
                          "objects": objects, "groups": groups, "messages": messages})


def _remap(value, mapping):
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            if key == "expected_values" and isinstance(child, dict):
                result[key] = {mapping.get(uid, uid): copy.deepcopy(expected) for uid, expected in child.items()}
            elif key == 'object_default_value' and value.get('object_default_mode') == 'guided':
                result[key] = _remap_guided(child, mapping)
            elif key in OWNED_CHILD_KEYS:
                result[key] = _remap(child, mapping)
            elif isinstance(child, str) and (key == "uid" or key.endswith("_uid")):
                result[key] = mapping.get(child, child)
            else:
                result[key] = copy.deepcopy(child)
        return result
    if isinstance(value, list):
        return [_remap(child, mapping) for child in value]
    return value


def _remap_guided(value, mapping):
    """Remap typed references, without rewriting literal dictionaries or values."""
    if not isinstance(value, dict):
        return copy.deepcopy(value)
    result = copy.deepcopy(value)
    kind = result.get('kind')
    if kind == 'enum':
        for key in ('enum_uid', 'value_uid'):
            if key in result: result[key] = mapping.get(result[key], result[key])
    elif kind in {'struct', 'inline_struct', 'bitfield'}:
        key, reference = ('members', 'member_uid') if kind == 'bitfield' else ('fields', 'field_uid')
        for assignment in result.get(key, []):
            if reference in assignment:
                assignment[reference] = mapping.get(assignment[reference], assignment[reference])
            if 'value' in assignment:
                assignment['value'] = _remap_guided(assignment['value'], mapping)
    elif kind == 'array':
        result['items'] = [_remap_guided(item, mapping) for item in result.get('items', [])]
    elif kind in {'conditional', 'switch', 'wrapped'} and 'value' in result:
        result['value'] = _remap_guided(result['value'], mapping)
    return result


def _insert(data, kind, parent_uid, index, objects):
    owner, key = destination(data, kind, parent_uid)
    values = owner.setdefault(key, [])
    siblings = destination_children(data, kind, parent_uid)
    insertion = (values.index(siblings[index]) if index < len(siblings) else
                 values.index(siblings[-1]) + 1 if siblings else len(values))
    values[insertion:insertion] = objects


def move_objects(data, uids, parent_uid, index):
    """Apply one validated sibling batch, with a pre-removal insertion boundary."""
    selected = sources(data, uids, moving=True)
    if not selected:
        return False
    kind = selected[0].kind
    siblings = destination_children(data, kind, parent_uid)
    if siblings is None or type(index) is not int or not 0 <= index <= len(siblings):
        return False
    blocked = set()
    if kind == "Field":
        for item in selected:
            blocked.update(owned_ids(item.value))
    elif kind == "Group":
        if any(not can_move_group(data, item.value["uid"], parent_uid, index) for item in selected):
            return False
        payload = capture(data, uids)
        blocked.update(item["uid"] for item in [*payload["objects"], *payload["groups"]])
    if parent_uid in blocked:
        return False
    moving_ids = {item.value["uid"] for item in selected}
    index -= sum(item["uid"] in moving_ids for item in siblings[:index])
    if selected[0].parent_uid == parent_uid:
        reordered = [item for item in siblings if item["uid"] not in moving_ids]
        reordered[index:index] = [item.value for item in selected]
        if [item["uid"] for item in reordered] == [item["uid"] for item in siblings]:
            return False
        if kind in {"Group", "Message"}:
            key = "parent_group_uid" if kind == "Group" else "group_uid"
            root = data["library"]["uid"]
            ordered = iter(reordered)
            selected[0].collection[:] = [next(ordered) if (item.get(key) or root) == parent_uid else item
                                         for item in selected[0].collection]
        else:
            selected[0].collection[:] = reordered
        return True
    for item in selected:
        item.collection.remove(item.value)
        if kind in {"Group", "Message"}:
            key = "parent_group_uid" if kind == "Group" else "group_uid"
            item.value[key] = "" if kind == "Group" and parent_uid == data["library"]["uid"] else parent_uid
            if item.parent_uid != parent_uid:
                item.value["expected_values"] = None
    _insert(data, kind, parent_uid, index, [item.value for item in selected])
    return True


def _unique(name, used):
    candidate, suffix = name, 1
    while candidate.casefold() in used:
        candidate = name + "Copy" + (str(suffix) if suffix > 1 else "")
        suffix += 1
    used.add(candidate.casefold())
    return candidate


def paste_copy(data, payload, parent_uid):
    """Clone captured owned objects, preserving external definition references."""
    kind = payload["kind"]
    for obj in [*payload.get('objects', []), *payload.get('messages', []), *payload.get('groups', [])]:
        for value in _owned_records(obj):
            if (value.get('kind') == 'enum' and any(key in value for key in ('width', 'endian', 'signed'))
                    or kind == 'Enum' and value is obj and 'storage' not in value):
                raise ValueError('Legacy enum clipboard payload: copy the item again from the migrated library.')
    siblings = destination_children(data, kind, parent_uid)
    if siblings is None:
        return []
    mapping = {uid: new_id() for uid in owned_ids(payload)}
    copied = _remap(copy.deepcopy(payload), mapping)
    objects = copied["objects"]
    root = data["library"]["uid"]
    if kind in {"Group", "Message"}:
        for obj in objects:
            obj["parent_group_uid" if kind == "Group" else "group_uid"] = (
                "" if kind == "Group" and parent_uid == root else parent_uid)
            # A copy must receive its own route assignment, even in the same parent.
            obj["expected_values"] = None
    all_messages = [*objects, *copied["messages"]] if kind == "Message" else copied["messages"]
    all_groups = [*objects, *copied["groups"]] if kind == "Group" else copied["groups"]
    type_names = {item["name"].casefold() for key in ("enums", "structures", "messages") for item in data.get(key, [])}
    group_names = {item["name"].casefold() for item in data.get("groups", [])}
    for group in all_groups:
        group["name"] = _unique(group["name"], group_names)
    for message in all_messages:
        message["name"] = _unique(message["name"], type_names)
        message["display_name"] = message["name"]
        message["behavior_class"] = message["name"] + "Behavior"
        message.pop("behavior_class_history", None)
        message.pop("generated_from_struct_uid", None)
        message.pop("generated_struct_field_uid", None)
    if kind in {"Enum", "Structure"}:
        for obj in objects:
            obj["name"] = _unique(obj["name"], type_names)
    elif kind in {"Field", "Runtime", "Constant", "Method"}:
        owner, _ = destination(data, kind, parent_uid)
        used = {item.get("name", "").casefold() for key in ("fields", "runtime_attributes", "constants", "methods")
                for item in owner.get(key, [])}
        renames = {}
        for obj in objects:
            old = obj.get("name", "")
            obj["name"] = _unique(old, used)
            renames[old] = obj["name"]
        # These schema references use sibling names, rather than object UIDs.
        for obj in objects:
            for key in ("count_field", "length_field"):
                if obj.get(key) in renames:
                    obj[key] = renames[obj[key]]
    _insert(data, kind, parent_uid, len(siblings), objects)
    data["groups"].extend(copied["groups"])
    data["messages"].extend(copied["messages"])
    return [item["uid"] for item in objects]


def _owned_records(value):
    if isinstance(value, dict):
        yield value
        for key in OWNED_CHILD_KEYS:
            if key in value:
                yield from _owned_records(value[key])
    elif isinstance(value, list):
        for child in value:
            yield from _owned_records(child)
