from __future__ import annotations

import copy
import ast
import re
from typing import Any
from .array_definitions import known_initial_count, PREFIX_FORMATS


INTEGER_KINDS = {"uint", "int", "bytes_integer", "varint", "zigzag", "computed"}
WRAPPER_KINDS = {"const", "default", "aligned", "rebuild", "checksum"}
MAX_GUIDED_VALUE_NODES = 10000


def array_item_owner(owner: str, field: dict[str, Any]) -> str:
    """Scope generated item classes to the array containing them."""
    return owner + "".join(part.capitalize() for part in field["name"].split("_")) + "Array"


def guided_supported(field: dict[str, Any], manifest: dict[str, Any]) -> bool:
    """Return whether the designer can describe this field's Python value."""
    kind = field.get("kind")
    if kind == "advanced":
        return False
    if kind == "struct":
        return any(item.get("uid") == field.get("struct_uid") for item in manifest.get("structures", []))
    if kind == "enum":
        return any(item.get("uid") == field.get("enum_uid") and item.get('values') for item in manifest.get("enums", []))
    if kind in WRAPPER_KINDS | {"array", "conditional"}:
        item = field.get("item")
        return isinstance(item, dict) and guided_supported(item, manifest)
    if kind == "switch":
        return bool(field.get("cases")) and all(
            isinstance(case.get("item"), dict) and guided_supported(case["item"], manifest)
            for case in field.get("cases", [])
        )
    return kind not in {"padding", None}


def create_guided_value(
    field: dict[str, Any], manifest: dict[str, Any], existing: dict[str, Any] | None = None,
    *, preserve_array_items: bool = False, _budget: list[int] | None = None, _index: int | None = None,
) -> dict[str, Any]:
    """Create/reconcile a typed default tree, preserving values by stable field/member UID."""
    if _budget is None:
        _budget = [MAX_GUIDED_VALUE_NODES]
    _budget[0] -= 1
    if _budget[0] < 0:
        raise ValueError(f"Guided defaults support at most {MAX_GUIDED_VALUE_NODES} value nodes. Use Automatic or a Python expression for larger values.")
    explicit_existing = isinstance(existing, dict)
    if existing is None and field.get("object_default_mode") == "guided":
        existing = field.get("object_default_value")
    existing = existing if isinstance(existing, dict) else {}

    def nested_value(nested, prior=None, index=None):
        return create_guided_value(nested, manifest, prior,
                                   preserve_array_items=preserve_array_items, _budget=_budget, _index=index)
    kind = field.get("kind")
    if kind in INTEGER_KINDS:
        return _scalar("integer", existing, 0)
    if kind == "float":
        return _scalar("float", existing, 0.0)
    if kind == "bool":
        return _scalar("bool", existing, False)
    if kind == "string":
        return _scalar("string", existing, "")
    if kind == "bytes":
        length = max(0, int(field.get("length", 0))) if field.get("mode") == "fixed" else 0
        if length > 65536:
            raise ValueError("Guided byte defaults support at most 65,536 bytes. Use Automatic or a Python expression for larger values.")
        value = existing.get("hex", "") if existing.get("kind") == "bytes" else "00" * length
        return {"kind": "bytes", "hex": str(value)}
    if kind == "enum":
        enum = _by_uid(manifest.get("enums", []), field.get("enum_uid"))
        values = enum.get("values", []) if enum else []
        selected = existing.get("value_uid") if existing.get("kind") == "enum" else None
        if selected is None:
            selected = values[0].get("uid") if values else ""
        return {"kind": "enum", "enum_uid": field.get("enum_uid", ""), "value_uid": selected}
    if kind == "bitfield":
        old = {item.get("member_uid"): item for item in existing.get("members", [])} if existing.get("kind") == "bitfield" else {}
        members = []
        for member in field.get("members", []):
            if member.get("kind") == "padding":
                continue
            nested_kind = "bool" if member.get("kind") == "flag" else "integer"
            prior = old.get(member.get("uid"), {}).get("value")
            members.append({
                "member_uid": member.get("uid", ""),
                "value": _scalar(nested_kind, prior if isinstance(prior, dict) else {}, False if nested_kind == "bool" else 0),
            })
        return {"kind": "bitfield", "members": members}
    if kind in {"struct", "inline_struct"}:
        if kind == "struct":
            structure = _by_uid(manifest.get("structures", []), field.get("struct_uid"))
            fields = structure.get("fields", []) if structure else []
        else:
            fields = field.get("fields", [])
        old = {item.get("field_uid"): item for item in existing.get("fields", [])} if existing.get("kind") in {"struct", "inline_struct"} else {}
        assignments = []
        for nested in fields:
            if nested.get("kind") == "padding":
                continue
            prior = old.get(nested.get("uid"), {})
            assignments.append({
                "field_uid": nested.get("uid", ""),
                "source": prior.get("source", "explicit"),
                "value": nested_value(nested, prior.get("value")),
            })
        current_uids = {nested.get("uid") for nested in fields if nested.get("kind") != "padding"}
        assignments.extend(copy.deepcopy(item) for uid, item in old.items() if uid not in current_uids)
        return {"kind": kind, "fields": assignments}
    if kind == "array":
        old_items = existing.get("items", []) if existing.get("kind") == "array" else []
        old_items = old_items + existing.get("_extra_items", [])
        count = max(0, int(field.get("count", 0))) if field.get("mode") == "fixed" else len(old_items)
        if not old_items and existing.get('kind') != 'array':
            count = known_initial_count(field, manifest) or 0
        if count > _budget[0]:
            raise ValueError(f"Guided defaults support at most {MAX_GUIDED_VALUE_NODES} value nodes. Use Automatic or a Python expression for larger arrays.")
        result = {
            "kind": "array",
            "items": [
                nested_value(field["item"], old_items[index] if index < len(old_items) else None, index)
                for index in range(count)
            ],
        }
        if field.get('mode') == 'sentinel' and result['items'] and not old_items:
            sentinel = ast.literal_eval(field.get('sentinel', '0'))
            result['items'][-1] = nested_value(field['item'], {'kind': result['items'][-1].get('kind'), 'value': sentinel})
        if preserve_array_items and len(old_items) > count:
            result["_extra_items"] = copy.deepcopy(old_items[count:])
        return result
    if kind == "conditional":
        present = bool(existing.get("present", False)) if existing.get("kind") == "conditional" else False
        return {
            "kind": "conditional", "present": present,
            "value": nested_value(field["item"], existing.get("value")),
        }
    if kind == "switch":
        cases = field.get("cases", [])
        selected = int(existing.get("case_index", 0)) if existing.get("kind") == "switch" else 0
        if _index is not None and field.get('selector') == 'this._index' and not explicit_existing:
            matching = [index for index, case in enumerate(cases) if case.get('value', '').strip() == str(_index)]
            if not matching:
                raise ValueError(f'No guided switch branch for array index {_index}')
            selected = matching[0]
        selected = min(max(0, selected), max(0, len(cases) - 1))
        case_field = cases[selected].get("item", {}) if cases else {}
        return {
            "kind": "switch", "case_index": selected,
            "value": nested_value(case_field, existing.get("value")) if case_field else {},
        }
    if kind in WRAPPER_KINDS:
        return {
            "kind": "wrapped",
            "value": nested_value(field["item"], existing.get("value")),
        }
    return {"kind": "unsupported"}


def guided_expression(
    field: dict[str, Any], value: dict[str, Any], owner: str,
    enums: dict[str, dict[str, Any]], structures: dict[str, dict[str, Any]],
) -> str:
    kind = field.get("kind")
    if kind in INTEGER_KINDS:
        return str(_int_value(value.get("value")))
    if kind == "float":
        return repr(float(value.get("value", 0.0)))
    if kind == "bool":
        return repr(bool(value.get("value", False)))
    if kind == "string":
        return repr(str(value.get("value", "")))
    if kind == "bytes":
        compact = re.sub(r"\s+", "", str(value.get("hex", "")))
        return f"bytes.fromhex({compact!r})"
    if kind == "enum":
        enum = enums[field["enum_uid"]]
        member = next(item for item in enum.get("values", []) if item.get("uid") == value.get("value_uid"))
        return f"{enum['name']}.{member['name']}"
    if kind == "bitfield":
        values = {item.get("member_uid"): item.get("value", {}) for item in value.get("members", [])}
        arguments = []
        for member in field.get("members", []):
            if member.get("kind") == "padding":
                continue
            nested = values[member.get("uid")]
            literal = repr(bool(nested.get("value"))) if member.get("kind") == "flag" else str(_int_value(nested.get("value")))
            arguments.append(f"{member['name']}={literal}")
        return f"{_bitfield_name(owner, field['name'])}({', '.join(arguments)})"
    if kind in {"struct", "inline_struct"}:
        if kind == "struct":
            nested_owner = structures[field["struct_uid"]]["name"]
            fields = structures[field["struct_uid"]].get("fields", [])
        else:
            nested_owner = _inline_name(owner, field["name"])
            fields = field.get("fields", [])
        definitions = {item.get("uid"): item for item in fields}
        arguments = []
        for assignment in value.get("fields", []):
            if assignment.get("source") == "default":
                continue
            nested = definitions[assignment["field_uid"]]
            expression = guided_expression(nested, assignment["value"], nested_owner, enums, structures)
            arguments.append(f"{nested['name']}={expression}")
        return f"{nested_owner}({', '.join(arguments)})"
    if kind == "array":
        values = [guided_expression(field["item"], item, array_item_owner(owner, field), enums, structures) for item in value.get("items", [])]
        return f"[{', '.join(values)}]"
    if kind == "conditional":
        return guided_expression(field["item"], value["value"], owner, enums, structures) if value.get("present") else "None"
    if kind == "switch":
        case = field.get("cases", [])[int(value.get("case_index", 0))]
        case_owner = owner + "".join(part.capitalize() for part in field['name'].split('_')) + f"Case{value['case_index']}"
        return guided_expression(case["item"], value["value"], case_owner, enums, structures)
    if kind in WRAPPER_KINDS:
        return guided_expression(field["item"], value["value"], owner, enums, structures)
    raise ValueError(f"Guided defaults are unavailable for {kind!r}")


def guided_errors(
    field: dict[str, Any], value: Any, manifest: dict[str, Any], path: str = "",
) -> list[str]:
    """Validate a typed default without evaluating developer code."""
    if not isinstance(value, dict):
        return [f"{path or field.get('name', 'Field')} has no guided value"]
    kind = field.get("kind")
    label = path or field.get("name", "Field")
    errors: list[str] = []
    if kind in INTEGER_KINDS:
        try:
            number = _int_value(value.get("value"))
        except (TypeError, ValueError):
            return [f"{label} must be an integer"]
        bits = _integer_bits(field)
        if bits:
            signed = kind == "int" or (kind == "bytes_integer" and bool(field.get("signed")))
            minimum = -(1 << (bits - 1)) if signed else 0
            maximum = (1 << (bits - 1)) - 1 if signed else (1 << bits) - 1
            if not minimum <= number <= maximum:
                errors.append(f"{label} must be between {minimum} and {maximum}")
    elif kind == "float":
        try: float(value.get("value"))
        except (TypeError, ValueError): errors.append(f"{label} must be a number")
    elif kind == "bool":
        if not isinstance(value.get("value"), bool): errors.append(f"{label} must be True or False")
    elif kind == "string":
        if not isinstance(value.get("value"), str): errors.append(f"{label} must be text")
    elif kind == "bytes":
        try:
            raw = bytes.fromhex(str(value.get("hex", "")))
        except ValueError:
            return [f"{label} must contain hexadecimal bytes"]
        if field.get("mode") == "fixed" and len(raw) != int(field.get("length", 0)):
            errors.append(f"{label} must contain exactly {int(field.get('length', 0))} bytes")
    elif kind == "enum":
        enum = _by_uid(manifest.get("enums", []), field.get("enum_uid"))
        if not enum or not any(item.get("uid") == value.get("value_uid") for item in enum.get("values", [])):
            errors.append(f"{label} selects a missing enum value")
    elif kind == "bitfield":
        assignments = {item.get("member_uid"): item.get("value") for item in value.get("members", [])}
        for member in field.get("members", []):
            if member.get("kind") == "padding": continue
            nested = assignments.get(member.get("uid"))
            member_path = f"{label}.{member.get('name', '?')}"
            if member.get("kind") == "flag":
                if not isinstance(nested, dict) or not isinstance(nested.get("value"), bool): errors.append(f"{member_path} must be True or False")
            else:
                pseudo = {"kind": "int" if member.get("kind") == "signed" else "uint", "width": 1}
                try:
                    number = _int_value(nested.get("value"))
                    bits = int(member.get("bits", 1)); signed = member.get("kind") == "signed"
                    low = -(1 << (bits - 1)) if signed else 0
                    high = (1 << (bits - 1)) - 1 if signed else (1 << bits) - 1
                    if not low <= number <= high: errors.append(f"{member_path} must be between {low} and {high}")
                except (AttributeError, TypeError, ValueError): errors.append(f"{member_path} must be an integer")
    elif kind in {"struct", "inline_struct"}:
        fields = (_by_uid(manifest.get("structures", []), field.get("struct_uid")) or {}).get("fields", []) if kind == "struct" else field.get("fields", [])
        definitions = {item.get("uid"): item for item in fields if item.get("kind") != "padding"}
        assignments = {item.get("field_uid"): item for item in value.get("fields", [])}
        for uid, nested in definitions.items():
            assignment = assignments.get(uid)
            nested_path = f"{label}.{nested.get('name', '?')}"
            if not assignment:
                errors.append(f"{nested_path} is missing")
            elif assignment.get("source") == "default":
                if nested.get("object_default_mode", "required") == "required": errors.append(f"{nested_path} has no nested default")
            else:
                errors.extend(guided_errors(nested, assignment.get("value"), manifest, nested_path))
        for uid in assignments.keys() - definitions.keys(): errors.append(f"{label} contains a stale field assignment")
    elif kind == "array":
        items = value.get("items", [])
        if not isinstance(items, list): return [f"{label} must be an array"]
        if field.get("mode") == "fixed" and len(items) != int(field.get("count", 0)):
            errors.append(f"{label} must contain exactly {int(field.get('count', 0))} items")
        minimum, maximum = field.get('min_count', 0), field.get('max_count')
        if type(minimum) is int and len(items) < minimum:
            errors.append(f'{label} requires at least {minimum} items')
        if type(maximum) is int and len(items) > maximum:
            errors.append(f'{label} allows at most {maximum} items')
        prefix = field.get('prefix_format', 'uint16')
        if field.get('mode') == 'prefixed' and prefix in PREFIX_FORMATS and prefix != 'varint':
            if len(items) >= 1 << int(prefix[4:]):
                errors.append(f'{label} item count exceeds {prefix} prefix capacity')
        if field.get('mode') == 'sentinel':
            try:
                sentinel = ast.literal_eval(field.get('sentinel', '0'))
                values = [item.get('value') for item in items]
                if not values or values[-1] != sentinel or sentinel in values[:-1]:
                    errors.append(f'{label} must end at its first terminating item')
            except (ValueError, SyntaxError):
                pass
        for index, item in enumerate(items):
            child = field['item']
            if child.get('kind') == 'switch' and child.get('selector') == 'this._index':
                branch = item.get('case_index')
                cases = child.get('cases', [])
                if type(branch) is int and 0 <= branch < len(cases) and cases[branch].get('value', '').strip() != str(index):
                    errors.append(f'{label}[{index}] must use the switch branch matching its index')
            errors.extend(guided_errors(child, item, manifest, f"{label}[{index}]"))
    elif kind == "conditional":
        if not isinstance(value.get("present"), bool): errors.append(f"{label} must select None or Present")
        elif value.get("present"): errors.extend(guided_errors(field["item"], value.get("value"), manifest, label))
    elif kind == "switch":
        index = value.get("case_index")
        if not isinstance(index, int) or not 0 <= index < len(field.get("cases", [])): errors.append(f"{label} selects a missing switch branch")
        else: errors.extend(guided_errors(field["cases"][index]["item"], value.get("value"), manifest, label))
    elif kind in WRAPPER_KINDS:
        errors.extend(guided_errors(field["item"], value.get("value"), manifest, label))
    else:
        errors.append(f"{label} does not support a guided default")
    return errors


def _scalar(kind: str, existing: dict[str, Any], fallback: Any) -> dict[str, Any]:
    value = existing.get("value", fallback) if existing.get("kind") == kind else fallback
    return {"kind": kind, "value": value}


def _by_uid(items, uid):
    return next((item for item in items if item.get("uid") == uid), None)


def _int_value(value: Any) -> int:
    if isinstance(value, bool):
        raise ValueError("boolean is not an integer default")
    return int(value, 0) if isinstance(value, str) else int(value)


def _integer_bits(field: dict[str, Any]) -> int:
    if field.get("kind") in {"uint", "int"}: return int(field.get("width", 1)) * 8
    if field.get("kind") == "bytes_integer": return int(field.get("length", 1)) * 8
    return 0


def _bitfield_name(owner: str, field_name: str) -> str:
    return owner + "".join(part.capitalize() for part in field_name.split("_")) + "Bits"


def _inline_name(owner: str, field_name: str) -> str:
    return owner + "".join(part.capitalize() for part in field_name.split("_")) + "Struct"
