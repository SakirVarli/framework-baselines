from __future__ import annotations

import copy
from dataclasses import fields

from app.binary_messages.compiled_routing import CompiledRoutingRegistry, Identifier
from .routing_paths import RoutingPathError, routing_field_options, routing_messages


IDENTIFIER_KEYS = {field.name for field in fields(Identifier)}


def owners_by_uid(manifest):
    return {item['uid']: item for item in [manifest['library'], *manifest.get('groups', [])]}


def parent_owner(manifest, item):
    uid = item.get('parent_group_uid') if 'parent_group_uid' in item else item.get('group_uid')
    return owners_by_uid(manifest).get(uid or manifest['library']['uid'])


def participating_message_uids(manifest):
    owners = owners_by_uid(manifest)
    root_uid = manifest['library']['uid']
    included = {root_uid: True}
    visiting = set()
    def active(item):
        uid = item['uid']
        if uid in included: return included[uid]
        if uid in visiting: return False
        visiting.add(uid)
        parent_uid = (item.get('parent_group_uid') if 'parent_group_uid' in item else item.get('group_uid')) or root_uid
        parent = owners.get(parent_uid)
        values = item.get('expected_values')
        result = parent is not None and values is not None and isinstance(values, dict)
        result = result and all(values.get(identifier['uid']) is not None for identifier in parent.get('identifiers', [])) and active(parent)
        visiting.discard(uid); included[uid] = bool(result)
        return bool(result)
    return {message['uid'] for message in manifest.get('messages', []) if active(message)}


def ancestor_assignments(manifest, item):
    result = []
    owners = owners_by_uid(manifest)
    current = item
    seen = set()
    while current is not manifest['library'] and current.get('uid') not in seen:
        seen.add(current.get('uid'))
        parent_uid = current.get('parent_group_uid') if 'parent_group_uid' in current else current.get('group_uid')
        parent = owners.get(parent_uid or manifest['library']['uid'])
        if parent is None:
            break
        values = current.get('expected_values') or {}
        result.append([(parent, definition, values.get(definition['uid']), current is item) for definition in parent.get('identifiers', [])])
        current = parent
    return [entry for level in reversed(result) for entry in level]


def resolve_definitions(manifest, owner):
    definitions = owner.get('identifiers', [])
    options = None
    has_assigned_descendants = False
    result = []
    for definition in definitions:
        resolved = copy.deepcopy(definition)
        if definition.get('source', 'raw') == 'field':
            if options is None:
                scope = None if owner['uid'] == manifest['library']['uid'] else owner
                has_assigned_descendants = bool(routing_messages(manifest, scope, active_only=True))
                options = {item['path']: item for item in routing_field_options(manifest, scope, active_only=has_assigned_descendants)}
            path = definition.get('field_path', '')
            if not path:
                raise RoutingPathError(f"{owner.get('name', 'Library')}.{definition.get('name')}: select a common message field")
            if path not in options:
                if has_assigned_descendants:
                    raise RoutingPathError(f"{owner.get('name', 'Library')}.{definition.get('name')}: field '{path}' has no common static layout for assigned descendants")
            else:
                resolved.update({key: value for key, value in options[path].items() if key != 'path'})
        resolved.setdefault('length', resolved.get('width', 1))
        resolved.setdefault('type', 'uint')
        result.append({key: value for key, value in resolved.items() if key in IDENTIFIER_KEYS})
    return result


def routing_specification(manifest):
    library = manifest['library']
    def group_spec(owner):
        return {'uid': owner['uid'], 'name': owner.get('name') or owner.get('display_name') or 'Library',
                'parent_uid': owner.get('parent_group_uid') or library['uid'],
                'identifiers': resolve_definitions(manifest, owner),
                'expected_values': copy.deepcopy(owner.get('expected_values'))}
    return {'root': group_spec(library), 'groups': [group_spec(group) for group in manifest.get('groups', [])],
            'messages': [{'uid': message['uid'], 'name': message['name'],
                          'parent_uid': message.get('group_uid') or library['uid'],
                          'direction': message.get('direction', 'ANY'),
                          'expected_values': copy.deepcopy(message.get('expected_values'))}
                         for message in manifest.get('messages', [])]}


def compile_manifest_routing(manifest):
    return CompiledRoutingRegistry({}, routing_specification(manifest))


def routing_status(manifest, item):
    owners = owners_by_uid(manifest)
    current = item
    seen = set()
    while current is not manifest['library']:
        if current.get('uid') in seen:
            return 'Invalid ancestry'
        seen.add(current.get('uid'))
        parent = owners.get((current.get('parent_group_uid') if 'parent_group_uid' in current else current.get('group_uid')) or manifest['library']['uid'])
        if parent is None:
            return 'Missing parent'
        values = current.get('expected_values')
        if values is None or any(values.get(identifier['uid']) is None for identifier in parent.get('identifiers', [])):
            return 'Excluded: unassigned values' if current is item else 'Excluded: ancestor unassigned'
        current = parent
    return 'Included in automatic decoding'
