from __future__ import annotations

import copy
import re
import uuid
from collections.abc import Callable, Iterable
from typing import Any


FORMAT_NAME = "sakir-message-library"
SCHEMA_VERSION = 10
PACKAGE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def new_id() -> str:
    return uuid.uuid4().hex


def _migration_id(library_uid: str, label: str) -> str:
    """Return a stable UID for objects introduced while migrating old manifests."""
    seed = str(library_uid or "sakir-message-library")
    return uuid.uuid5(uuid.NAMESPACE_URL, f"{seed}:{label}").hex


def new_manifest(package_name: str = "protocol_messages") -> dict[str, Any]:
    return {
        "format": FORMAT_NAME,
        "schema_version": SCHEMA_VERSION,
        "library": {
            "uid": new_id(),
            "package_name": package_name,
            "display_name": package_name.replace("_", " ").title(),
            "extra_imports": [],
            "identifiers": [],
        },
        "enums": [],
        "structures": [],
        "groups": [],
        "messages": [],
        "compatibility_history": [],
        "generated_hashes": {},
        "behavior_hash": "",
    }


def normalize_manifest(data: dict[str, Any]) -> dict[str, Any]:
    """Migrate compatible in-memory manifests to the current identity spelling."""
    source_version = data.get("schema_version", 1)
    result = copy.deepcopy(data)
    if type(source_version) is not int or not 1 <= source_version <= SCHEMA_VERSION:
        return result
    result["schema_version"] = SCHEMA_VERSION
    library = result.setdefault("library", {})
    library.setdefault("group_router", None)
    legacy_extractor = library.pop("id_extractor", None)
    groups = result.setdefault("groups", [])
    if not groups and (legacy_extractor or source_version < 8):
        group = new_group("Default")
        group["uid"] = _migration_id(library.get("uid", ""), "default-message-group")
        groups.append(group)
    for group in groups:
        group.setdefault("parent_group_uid", "")
        group.setdefault("description", "")
        group.setdefault("route_values", {})
        group.setdefault("route_signatures", [])
        group.setdefault("message_router", None)
    extractor_group_uid = ""
    if legacy_extractor and len(groups) == 1 and not groups[0].get("message_router"):
        extractor_group_uid = groups[0].get("uid", "")
        groups[0]["message_router"] = {
            "mode": "shared", "components": [{
                "uid": _migration_id(library.get("uid", ""), "legacy-message-id-component"),
                "name": "message_id", "source": "raw", "field_path": "",
                "offset": legacy_extractor.get("offset", 0), "width": legacy_extractor.get("width", 1),
                "byteorder": legacy_extractor.get("byteorder", "big"), "mask": legacy_extractor.get("mask"),
                "shift": legacy_extractor.get("shift", 0),
            }],
        }
    default_group_uid = groups[0].get("uid", "") if source_version < 8 and len(groups) == 1 else library.get("uid", "")
    _migrate_removed_metadata(result)
    for message in result.get("messages", []):
        sync_message_names(message)
        legacy_direction = message.pop("tx_rx", None)
        direction = message.get("direction", legacy_direction or "ANY")
        message["direction"] = str(direction).upper()
        if not message.get("group_uid"):
            message["group_uid"] = default_group_uid
        legacy_id = message.pop("message_id", None)
        if extractor_group_uid and message["group_uid"] == extractor_group_uid and legacy_id is not None:
            message["identity_values"] = {"message_id": legacy_id}
            message["identity_signatures"] = []
        else:
            message.setdefault("identity_values", {"message_id": legacy_id} if legacy_id is not None else {})
        message.setdefault("identity_signatures", [])
    _migrate_routing(result, source_version)
    for owner in [*result.get("structures", []), *result.get("messages", [])]:
        for field in _walk_schema_fields(owner.get("fields", [])):
            if field.get("kind") != "padding":
                field.setdefault("object_default_mode", "required")
                field.setdefault("object_default", "")
                field.setdefault("object_default_value", None)
    if source_version < 9:
        from .enum_schema import migrate_enums
        migrate_enums(result, source_version)
    from .array_definitions import bind_array_references
    for owner in [*result.get("structures", []), *result.get("messages", [])]:
        for field in _walk_schema_fields(owner.get("fields", [])):
            if field.get("kind") == "array":
                field.setdefault("initial_policy", "legacy" if source_version < 10 else "resolve")
                field.setdefault("prefix_format", "uint16")
                field.setdefault("prefix_endian", "little")
                for key, value in {'initial_count': None, 'min_count': 0, 'max_count': None, 'max_bytes': None,
                                   'length_field': '', 'count_expression': '0', 'sentinel': '0', 'predicate': 'obj == 0'}.items():
                    field.setdefault(key, value)
    bind_array_references(result)
    return result


def _migrate_routing(manifest, source_version):
    library = manifest["library"]
    groups = manifest.get("groups", [])
    owners = [library, *groups]
    group_uids = {group['uid'] for group in groups}
    legacy_routers = {}
    for owner in owners:
        key = "group_router" if owner is library else "message_router"
        router = owner.pop(key, None)
        if router and router.get('mode') == 'signatures':
            children = [child for child in [*groups, *manifest.get('messages', [])]
                        if (child.get('parent_group_uid') if child.get('uid') in group_uids else child.get('group_uid')) in {owner.get('uid'), '' if owner is library else owner.get('uid')}]
            sample = None
            compatible = True
            assignments = []
            for child in children:
                sig_key = 'route_signatures' if child.get('uid') in group_uids else 'identity_signatures'
                signatures = child.get(sig_key, [])
                if not signatures: continue
                if len(signatures) != 1 or not signatures[0].get('probes'):
                    compatible = False; break
                probes = signatures[0]['probes']
                shape = [{key: value for key, value in probe.items() if key not in {'uid', 'expected'}} for probe in probes]
                if sample is None: sample = shape
                elif shape != sample: compatible = False; break
                assignments.append((child, sig_key, {probe['name']: probe['expected'] for probe in probes}))
            if compatible and sample:
                router = {'mode': 'shared', 'components': [{**probe, 'uid': _migration_id(owner.get('uid', ''), f"signature-identifier:{index}")} for index, probe in enumerate(sample)]}
                for child, sig_key, values in assignments:
                    child[sig_key] = []
                    child['route_values' if child.get('uid') in group_uids else 'identity_values'] = values
        legacy_routers[owner.get("uid")] = router
        if router and router.get("mode") == "shared":
            identifiers = []
            for index, component in enumerate(router.get("components", [])):
                identifier = copy.deepcopy(component)
                identifier.setdefault("uid", _migration_id(owner.get("uid", ""), f"identifier:{index}"))
                identifier["length"] = identifier.pop("width", identifier.get("length", 1))
                identifier.setdefault("type", "uint")
                identifiers.append(identifier)
            if not owner.get("identifiers"):
                owner["identifiers"] = identifiers
        else:
            owner.setdefault("identifiers", [])
        if router and router.get("mode") == "signatures":
            owner["legacy_routing"] = copy.deepcopy(router)
    by_uid = {owner.get("uid"): owner for owner in owners}
    for child in [*groups, *manifest.get("messages", [])]:
        is_group = child.get("uid") in group_uids
        parent_uid = child.get("parent_group_uid") if is_group else child.get("group_uid")
        parent = by_uid.get(parent_uid or library.get("uid"), library)
        values_key = "route_values" if is_group else "identity_values"
        signatures_key = "route_signatures" if is_group else "identity_signatures"
        values = child.pop(values_key, {})
        signatures = child.pop(signatures_key, [])
        router = legacy_routers.get(parent.get("uid"))
        if router and router.get("mode") == "shared" and values:
            child["expected_values"] = {identifier["uid"]: values[identifier["name"]]
                                        for identifier in parent["identifiers"] if identifier.get("name") in values}
        else:
            child.setdefault("expected_values", None)
        if source_version < 8 and is_group and parent is library and not router and len(groups) == 1:
            child["expected_values"] = {}
        if signatures:
            child["legacy_signatures"] = signatures


def _migrate_removed_metadata(manifest):
    """Materialize legacy inherited headers as ordinary per-message fields."""
    manifest.pop("tags", None)
    library = manifest["library"]
    common = library.pop("header_layers", [])
    groups = {group.get("uid"): group for group in manifest.get("groups", [])}
    group_headers = {uid: group.pop("header_layers", []) for uid, group in groups.items()}
    default_group = next(iter(groups), "") if len(groups) == 1 else ""
    for message in manifest.get("messages", []):
        chain = []
        seen = set()
        group = groups.get(message.get("group_uid") or default_group)
        while group and group.get("uid") not in seen:
            uid = group["uid"]
            seen.add(uid)
            chain.append(uid)
            group = groups.get(group.get("parent_group_uid"))
        layers = list(common)
        for uid in reversed(chain):
            layers.extend(group_headers[uid])
        fields = []
        for index, layer in enumerate(layers):
            field = new_field(layer.get("attribute_name", "header"), "struct")
            field["uid"] = _migration_id(message.get("uid", ""), f"header-field:{index}:{layer.get('uid', '')}")
            field["struct_uid"] = layer.get("struct_uid", "")
            fields.append(field)
        if fields:
            message["fields"] = [*fields, *message.get("fields", [])]
    for definition in [*manifest.get("enums", []), *manifest.get("structures", []),
                       *groups.values(), *manifest.get("messages", [])]:
        definition.pop("tag_uids", None)


def new_group(name: str = "NewGroup", parent_group_uid: str = "") -> dict[str, Any]:
    return {
        "uid": new_id(), "name": name, "description": "",
        "parent_group_uid": parent_group_uid,
        "identifiers": [], "expected_values": None,
    }


def new_enum(name: str = "NewEnum") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "storage": {"kind": "uint", "width": 1, "endian": "big"},
        "values": [{"uid": new_id(), "name": "VALUE", "value": 0}],
    }


def new_structure(name: str = "NewStruct") -> dict[str, Any]:
    return {"uid": new_id(), "name": name, "fields": []}


def sync_message_names(message: dict[str, Any]) -> None:
    """Derive registry/mixin names, retaining old mixins for legacy source lookup."""
    name = message.get("name", "")
    if not isinstance(name, str) or not name:
        return
    message["display_name"] = name
    desired = name + "Behavior"
    previous = message.get("behavior_class")
    if previous and previous != desired:
        history = message.setdefault("behavior_class_history", [])
        if previous in history:
            history.remove(previous)
        history.append(previous)
    message["behavior_class"] = desired


def new_message(name: str = "NewMessage") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "display_name": name,
        "direction": "ANY",
        "group_uid": "",
        "expected_values": None,
        "behavior_class": f"{name}Behavior",
        "fields": [],
        "runtime_attributes": [],
        "constants": [],
        "methods": [],
    }


def new_field(name: str = "field", kind: str = "uint") -> dict[str, Any]:
    defaults: dict[str, Any] = {
        "uint": {"width": 1, "endian": "big"},
        "int": {"width": 1, "endian": "big"},
        "bytes_integer": {"length": 3, "signed": False, "endian": "big"},
        "varint": {},
        "zigzag": {},
        "float": {"width": 4, "endian": "big"},
        "bool": {},
        "enum": {"enum_uid": ""},
        "bytes": {"mode": "fixed", "length": 1, "length_field": ""},
        "string": {"mode": "fixed", "length": 1, "encoding": "utf8", "length_field": ""},
        "bitfield": {"members": [
            {"uid": new_id(), "name": "flag", "kind": "flag", "bits": 1},
            {"uid": new_id(), "name": "reserved", "kind": "padding", "bits": 7},
        ]},
        "array": {"mode": "fixed", "count": 1, "count_field": "", "rebuild_count": False,
                  "initial_policy": "resolve", "initial_count": None,
                  "prefix_format": "uint16", "prefix_endian": "little",
                  "length_field": "", "count_expression": "0", "sentinel": "0",
                  "predicate": "obj == 0", "min_count": 0, "max_count": None, "max_bytes": None},
        "struct": {"struct_uid": ""},
        "inline_struct": {"fields": []},
        "conditional": {"condition": "this.enabled"},
        "switch": {"selector": "this.kind", "cases": [], "default": "Pass"},
        "const": {"value": "0"},
        "default": {"value": "0"},
        "padding": {"length": 1},
        "aligned": {"modulus": 4},
        "computed": {"expression": "0"},
        "rebuild": {"expression": "0"},
        "checksum": {"algorithm": "crc32", "source": "this.payload"},
        "advanced": {"expression": "Int8ub"},
    }
    if kind not in defaults:
        raise ValueError(f"Unknown field kind: {kind}")
    result = {
        "uid": new_id(), "name": name, "kind": kind,
        "object_default_mode": "required", "object_default": "", "object_default_value": None,
        **copy.deepcopy(defaults[kind]),
    }
    if kind in {"array", "conditional", "const", "default", "aligned", "rebuild", "checksum"}:
        result["item"] = new_field("value" if kind != "array" else "item", "uint")
    return result


def new_runtime_attribute(name: str = "runtime_value") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "annotation": "Any",
        "default": "None",
        "repr": True,
    }


def new_constant(name: str = "CONSTANT") -> dict[str, Any]:
    return {"uid": new_id(), "name": name, "annotation": "Any", "value": "None"}


def new_method(name: str = "custom_method") -> dict[str, Any]:
    return {
        "uid": new_id(),
        "name": name,
        "kind": "instance",
    }


class MessageDesignerDocument:
    def __init__(self, data: dict[str, Any] | None = None) -> None:
        self.data = normalize_manifest(data or new_manifest())
        self.saved_snapshot = copy.deepcopy(self.data)
        self.path: str | None = None
        self._listeners: list[Callable[[str], None]] = []

    def on_change(self, callback: Callable[[str], None]) -> None:
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[str], None]) -> None:
        if callback in self._listeners:
            self._listeners.remove(callback)

    def notify(self, reason: str = "changed") -> None:
        for callback in tuple(self._listeners):
            callback(reason)

    @property
    def is_dirty(self) -> bool:
        return self.data != self.saved_snapshot or self.pending_upgrade

    @property
    def pending_upgrade(self) -> bool:
        return bool(self.data.get("enum_migration", {}).get("pending_regeneration"))

    def snapshot(self) -> dict[str, Any]:
        return copy.deepcopy(self.data)

    def replace(self, data: dict[str, Any], *, reason: str = "changed") -> None:
        self.data = normalize_manifest(data)
        self.notify(reason)

    def mark_saved(self, data: dict[str, Any] | None = None) -> None:
        if data is not None:
            self.data = copy.deepcopy(data)
        self.saved_snapshot = copy.deepcopy(self.data)
        self.notify("saved")

    def restore_saved(self) -> None:
        self.data = copy.deepcopy(self.saved_snapshot)
        self.notify("restored")

    def all_objects(self) -> Iterable[dict[str, Any]]:
        yield self.data["library"]
        yield from self.data.get("enums", [])
        yield from self.data.get("structures", [])
        yield from self.data.get("groups", [])
        for structure in self.data.get("structures", []):
            yield from walk_fields(structure.get("fields", []))
        yield from self.data.get("messages", [])
        for message in self.data.get("messages", []):
            yield from walk_fields(message.get("fields", []))
            yield from message.get("runtime_attributes", [])
            yield from message.get("constants", [])
            yield from message.get("methods", [])

    def find(self, uid: str) -> dict[str, Any] | None:
        return next((item for item in self.all_objects() if item.get("uid") == uid), None)


def walk_fields(fields: Iterable[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    for field in fields:
        yield field
        for key in ("item",):
            nested = field.get(key)
            if isinstance(nested, dict):
                yield from walk_fields([nested])
        yield from walk_fields(field.get("fields", []))
        for member in field.get("members", []):
            if isinstance(member, dict):
                yield member
        for case in field.get("cases", []):
            nested = case.get("item")
            if isinstance(nested, dict):
                yield from walk_fields([nested])


def _walk_schema_fields(fields: Iterable[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    """Walk wire fields without treating bit-group member records as fields."""
    for field in fields:
        yield field
        nested = field.get("item")
        if isinstance(nested, dict):
            yield from _walk_schema_fields([nested])
        yield from _walk_schema_fields(field.get("fields", []))
        for case in field.get("cases", []):
            nested = case.get("item")
            if isinstance(nested, dict):
                yield from _walk_schema_fields([nested])
