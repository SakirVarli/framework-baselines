"""Moves between ordered wire-field lists without detaching required child slots."""
from __future__ import annotations

from .model import walk_fields


def _field_containers(data):
    for owner in [*data.get("messages", []), *data.get("structures", [])]:
        yield owner
        for field in walk_fields(owner.get("fields", [])):
            if field.get("kind") == "inline_struct":
                yield field


def _resolve_move(data, field_uid, parent_uid, index):
    containers = list(_field_containers(data))
    destination = next((owner for owner in containers if owner.get("uid") == parent_uid), None)
    if destination is None or type(index) is not int or not 0 <= index <= len(destination.get("fields", [])):
        return None
    for owner in containers:
        source = owner.get("fields", [])
        for source_index, field in enumerate(source):
            if field.get("uid") != field_uid:
                continue
            if any(child.get("uid") == parent_uid for child in walk_fields([field])):
                return None
            if owner is destination and source_index < index:
                index -= 1
            return source, source_index, destination, index
    return None


def can_move_field(data, field_uid, parent_uid, index):
    """Index is the insertion boundary in the destination before removing the source."""
    return _resolve_move(data, field_uid, parent_uid, index) is not None


def move_field(data, field_uid, parent_uid, index):
    """Move the existing field and its subtree; return False for invalid or unchanged moves."""
    resolved = _resolve_move(data, field_uid, parent_uid, index)
    if resolved is None:
        return False
    source, source_index, destination, index = resolved
    target = destination.setdefault("fields", [])
    if source is target and source_index == index:
        return False
    target.insert(index, source.pop(source_index))
    return True
