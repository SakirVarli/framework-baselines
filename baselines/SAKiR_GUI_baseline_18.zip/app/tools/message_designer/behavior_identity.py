"""Match behavior source to stable message IDs before renaming mixin classes."""
from __future__ import annotations

import ast
import io
import json
import re
import symtable
import tokenize


UID_MARKER = "# message-designer-uid: "
_UID_RE = re.compile(r'# message-designer-uid: ("(?:[^"\\]|\\.)*")')


def behavior_marker(message):
    return UID_MARKER + json.dumps(message["uid"])


def _headers(source, tree):
    tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))
    headers = {}
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        index = next(i for i, token in enumerate(tokens)
                     if token.start[0] == node.lineno and token.string == "class")
        name_token = tokens[index + 1]
        depth = 0
        for token in tokens[index + 2:]:
            if token.string in {"(", "[", "{"}:
                depth += 1
            elif token.string in {")", "]", "}"}:
                depth -= 1
            elif token.string == ":" and depth == 0:
                headers[node.name] = (name_token, token.end[0])
                break
    return headers


def resolve_behavior_classes(source, messages):
    """Return original class nodes, refusing ambiguous ownership or collisions."""
    tree = ast.parse(source)
    classes = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            if node.name in classes:
                raise ValueError(f"Duplicate behavior source class {node.name}; resolve it in behaviors.py.")
            classes[node.name] = node
    headers = _headers(source, tree)
    lines = source.splitlines()
    owners, by_uid = {}, {}
    for name, (_, end_line) in headers.items():
        match = _UID_RE.search(lines[end_line - 1])
        if match:
            uid = json.loads(match[1])
            if uid in by_uid:
                raise ValueError(f"Multiple behavior mixins belong to message {uid}; resolve them in behaviors.py.")
            owners[name] = uid
            by_uid[uid] = classes[name]
    resolved, claimed = {}, set()
    for message in messages:
        uid, desired = message["uid"], message["behavior_class"]
        node = by_uid.get(uid)
        if node is None:
            candidates = [*reversed(message.get("behavior_class_history", [])), desired]
            node = next((classes[name] for name in candidates
                         if name in classes and owners.get(name, uid) == uid), None)
        if node is not None:
            if node.name in claimed:
                raise ValueError(f"Behavior mixin {node.name} is claimed by multiple messages.")
            claimed.add(node.name)
        resolved[desired] = node
    moving = {node.name for desired, node in resolved.items() if node and node.name != desired}
    for desired, node in resolved.items():
        occupant = classes.get(desired)
        if occupant is not None and occupant is not node and desired not in moving:
            raise ValueError(f"Cannot rename behavior mixin to {desired}: that class already exists in behaviors.py.")
    return tree, headers, resolved


def _global_name_loads(source, tree):
    """Distinguish class references from parameters and locals with the same name."""
    root = symtable.symtable(source, "behaviors.py", "exec")

    def scope(table, name, line):
        return next((child for child in table.get_children()
                     if child.get_name() == name and child.get_lineno() == line), table)

    def visit(node, table):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            try:
                is_global = table.lookup(node.id).is_global()
            except KeyError:
                # Postponed annotations need not have a symbol-table entry.
                is_global = True
            if is_global:
                yield node
            return
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            for default in [*node.args.defaults, *[value for value in node.args.kw_defaults if value is not None]]:
                yield from visit(default, table)
            if not isinstance(node, ast.Lambda):
                for expression in [*node.decorator_list, node.returns]:
                    if expression is not None:
                        yield from visit(expression, table)
                for arg in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs, node.args.vararg, node.args.kwarg]:
                    if arg is not None and arg.annotation is not None:
                        yield from visit(arg.annotation, table)
            child = scope(table, "lambda" if isinstance(node, ast.Lambda) else node.name, node.lineno)
            for statement in [node.body] if isinstance(node, ast.Lambda) else node.body:
                yield from visit(statement, child)
            return
        if isinstance(node, ast.ClassDef):
            for expression in [*node.decorator_list, *node.bases, *[keyword.value for keyword in node.keywords]]:
                yield from visit(expression, table)
            child = scope(table, node.name, node.lineno)
            for statement in node.body:
                yield from visit(statement, child)
            return
        comprehensions = {ast.ListComp: "listcomp", ast.SetComp: "setcomp", ast.DictComp: "dictcomp", ast.GeneratorExp: "genexpr"}
        if type(node) in comprehensions:
            yield from visit(node.generators[0].iter, table)
            child = scope(table, comprehensions[type(node)], node.lineno)
            for expression in ([node.key, node.value] if isinstance(node, ast.DictComp) else [node.elt]):
                yield from visit(expression, child)
            for index, generator in enumerate(node.generators):
                if index:
                    yield from visit(generator.iter, child)
                for condition in generator.ifs:
                    yield from visit(condition, child)
            return
        for child in ast.iter_child_nodes(node):
            yield from visit(child, table)

    yield from visit(tree, root)


def prepare_behavior_source(source, messages):
    """Rename matched classes and class references while retaining custom source."""
    tree, headers, resolved = resolve_behavior_classes(source, messages)
    renames = {node.name: desired for desired, node in resolved.items() if node and node.name != desired}
    lines = source.splitlines(keepends=True)
    offsets, offset = [], 0
    for line in lines:
        offsets.append(offset)
        offset += len(line)
    edits = []
    for message in messages:
        node = resolved[message["behavior_class"]]
        if node is None:
            continue
        token, end_line = headers[node.name]
        if node.name in renames:
            edits.append((offsets[token.start[0] - 1] + token.start[1],
                          offsets[token.end[0] - 1] + token.end[1], renames[node.name]))
        line = lines[end_line - 1].rstrip("\r\n")
        marker = _UID_RE.search(line)
        if marker is None:
            position = offsets[end_line - 1] + len(line)
            edits.append((position, position, "  " + behavior_marker(message)))
    for node in _global_name_loads(source, tree) if renames else ():
        if node.id in renames:
            # AST columns count UTF-8 bytes; source slicing uses characters.
            column = len(lines[node.lineno - 1].encode("utf-8")[:node.col_offset].decode("utf-8"))
            start = offsets[node.lineno - 1] + column
            edits.append((start, start + len(node.id), renames[node.id]))
    for start, end, replacement in sorted(edits, reverse=True):
        source = source[:start] + replacement + source[end:]
    return source
