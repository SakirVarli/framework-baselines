from .window import MessageDesignerWindow

__all__ = ["MessageDesignerWindow"]
