"""Reorder routing groups and reparent their complete subtrees."""
from __future__ import annotations


def _resolve_move(data, uid, parent_uid, index):
    root_uid = data["library"]["uid"]
    parent_uid = parent_uid or root_uid
    groups = data.get("groups", [])
    by_uid = {group.get("uid"): group for group in groups}
    group = by_uid.get(uid)
    if group is None:
        return None
    # Walk toward the root so neither descendants nor malformed cycles can be targets.
    cursor_uid = parent_uid
    seen = set()
    while cursor_uid != root_uid:
        if cursor_uid == uid or cursor_uid in seen or cursor_uid not in by_uid:
            return None
        seen.add(cursor_uid)
        cursor_uid = by_uid[cursor_uid].get("parent_group_uid") or root_uid
    siblings = [item for item in groups if (item.get("parent_group_uid") or root_uid) == parent_uid]
    if type(index) is not int or not 0 <= index <= len(siblings):
        return None
    return group, siblings, parent_uid


def can_move_group(data, uid, parent_uid, index):
    """Index is an insertion boundary among destination groups, excluding messages."""
    return _resolve_move(data, uid, parent_uid, index) is not None


def move_group(data, uid, parent_uid, index):
    """Move the existing group; reset only its own assignment when its parent changes."""
    resolved = _resolve_move(data, uid, parent_uid, index)
    if resolved is None:
        return False
    group, siblings, parent_uid = resolved
    groups = data["groups"]
    root_uid = data["library"]["uid"]
    if (group.get("parent_group_uid") or root_uid) == parent_uid:
        source_index = siblings.index(group)
        if source_index < index:
            index -= 1
        if source_index == index:
            return False
        siblings.insert(index, siblings.pop(source_index))
        reordered = iter(siblings)
        groups[:] = [next(reordered) if (item.get("parent_group_uid") or root_uid) == parent_uid else item
                     for item in groups]
    else:
        groups.remove(group)
        if index < len(siblings):
            insertion = groups.index(siblings[index])
        elif siblings:
            insertion = groups.index(siblings[-1]) + 1
        else:
            insertion = len(groups)
        group["parent_group_uid"] = "" if parent_uid == root_uid else parent_uid
        group["expected_values"] = None
        groups.insert(insertion, group)
    return True
