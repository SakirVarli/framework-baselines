from __future__ import annotations

import copy

from PyQt5 import QtWidgets


class ReplaceManifestCommand(QtWidgets.QUndoCommand):
    def __init__(self, document, before, after, text="Edit message library", *, merge_key=None):
        super().__init__(text)
        self.document = document
        self.before = copy.deepcopy(before)
        self.after = copy.deepcopy(after)
        self.merge_key = merge_key

    def id(self):
        return 1 if self.merge_key is not None else -1

    def mergeWith(self, other):
        if (not isinstance(other, ReplaceManifestCommand) or self.document is not other.document
                or self.merge_key != other.merge_key or self.after != other.before):
            return False
        self.after = copy.deepcopy(other.after)
        self.setObsolete(self.before == self.after)
        return True

    def redo(self):
        self.document.replace(self.after)

    def undo(self):
        self.document.replace(self.before, reason="undo")
