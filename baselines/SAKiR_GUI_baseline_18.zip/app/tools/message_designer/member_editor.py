from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtWidgets

from .model import new_id
from .enum_schema import SUBTYPES, definition_expression


class DefinitionOptionsEditor(QtWidgets.QWidget):
    """Typed editors for enums and non-wire class members."""

    changed = QtCore.pyqtSignal()
    SUPPORTED = {"Library", "Group", "Message", "Enum", "Runtime", "Constant", "Method"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._kind = ""
        self._base: dict[str, Any] = {}
        self._loading = False
        self._widgets: dict[str, QtWidgets.QWidget] = {}
        self._value_uids: list[str] = []
        self._display_name = "custom_method"
        self._layout = QtWidgets.QFormLayout(self)
        self._layout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self.changed.connect(self._update_enum_preview)

    def load_definition(self, value: dict[str, Any], kind: str, manifest: dict[str, Any] | None = None) -> None:
        self._loading = True
        self._kind = kind
        self._base = copy.deepcopy(value)
        self._clear()
        if kind == "Library":
            self._library_settings(value)
        elif kind == "Group":
            self._line("description", "Description", value)
        elif kind == "Message":
            self._combo("direction", "Direction", ["ANY", "TX", "RX"], {"direction": str(value.get("direction", "ANY")).upper()})
            self._readonly_line("display_name", "Registry display name")
            self._widgets["display_name"].setToolTip(
                "Always matches Name. Change Name to update this value."
            )
            self._readonly_line("behavior_class", "Behavior mixin")
            self._widgets["behavior_class"].setToolTip(
                "Follows Name with a Behavior suffix. Renaming preserves custom methods when saved."
            )
            self.set_message_name(value.get("name", ""))
        elif kind == "Enum":
            self._enum_storage(value)
            self._enum_values(value)
            preview = QtWidgets.QPlainTextEdit()
            preview.setReadOnly(True); preview.setMaximumHeight(90)
            self._widgets['_enum_preview'] = preview
            self._layout.addRow('Construct expression', preview)
            self._update_enum_preview()
        elif kind == "Runtime":
            self._line("annotation", "Type annotation", value)
            self._line("default", "Default expression", value)
            self._check("repr", "Include in repr", value)
        elif kind == "Constant":
            self._line("annotation", "Type annotation", value)
            self._line("value", "Value expression", value)
        elif kind == "Method":
            self._display_name = value.get("name", "custom_method")
            self._combo("kind", "Method kind", ["instance", "class", "static", "async", "property"], value)
            self._signature_label = QtWidgets.QLabel()
            self._signature_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._signature_label.setStyleSheet("font-family: Consolas, monospace; padding: 6px;")
            self._layout.addRow("Generated signature", self._signature_label)
            self._widgets["kind"].currentTextChanged.connect(self._update_signature)
            self._update_signature()
        self._loading = False

    def value(self) -> dict[str, Any]:
        result = copy.deepcopy(self._base)
        if self._kind == "Library":
            result["package_name"] = self._widgets["package_name"].text().strip()
            return result
        if self._kind == "Group":
            result["description"] = self._widgets["description"].text()
            return result
        for key, widget in self._widgets.items():
            if key.startswith('_'):
                continue
            if isinstance(widget, QtWidgets.QLineEdit):
                if not widget.isReadOnly(): result[key] = widget.text()
            elif isinstance(widget, QtWidgets.QPlainTextEdit): result[key] = widget.toPlainText()
            elif isinstance(widget, QtWidgets.QCheckBox): result[key] = widget.isChecked()
            elif isinstance(widget, QtWidgets.QComboBox): result[key] = widget.currentText()
            elif isinstance(widget, QtWidgets.QSpinBox): result[key] = widget.value()
        if self._kind == "Enum":
            result["values"] = self._read_enum_values()
            subtype = self._widgets['_enum_subtype'].currentText()
            if subtype in SUBTYPES:
                kind = 'uint' if subtype.startswith('uint') else 'int'
                width = int(subtype[len(kind):]) // 8
                result['storage'] = {'kind': kind, 'width': width,
                                     'endian': 'big' if width == 1 else self._widgets['_enum_endian'].currentText()}
        elif self._kind == "Method":
            result.pop("parameters", None)
            result.pop("return_annotation", None)
            result.pop("docstring", None)
        return result

    def set_display_name(self, name: str) -> None:
        self._display_name = name or "custom_method"
        if self._kind == "Method": self._update_signature()

    def set_message_name(self, name: str) -> None:
        if self._kind == "Message":
            self._widgets["display_name"].setText(name)
            self._widgets["behavior_class"].setText(name + "Behavior" if name else "")

    def _update_signature(self, *args) -> None:
        kind = self._widgets.get("kind").currentText() if self._widgets.get("kind") else "instance"
        decorators = {"class": "@classmethod\n", "static": "@staticmethod\n", "property": "@property\n"}
        first = "cls" if kind == "class" else ("" if kind == "static" else "self")
        async_prefix = "async " if kind == "async" else ""
        self._signature_label.setText(f"{decorators.get(kind, '')}{async_prefix}def {self._display_name}({first}):")

    def _clear(self):
        while self._layout.rowCount(): self._layout.removeRow(0)
        self._widgets.clear()

    def _emit_changed(self, *args):
        self._edit_source = self.sender()
        if not self._loading: self.changed.emit()

    def _add(self, key, label, widget):
        self._widgets[key] = widget; self._layout.addRow(label, widget)
        if isinstance(widget, QtWidgets.QLineEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QPlainTextEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QCheckBox): widget.toggled.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QComboBox): widget.currentIndexChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QSpinBox): widget.valueChanged.connect(self._emit_changed)

    def _line(self, key, label, value): self._add(key, label, QtWidgets.QLineEdit(str(value.get(key, ""))))

    def _readonly_line(self, key, label):
        widget = QtWidgets.QLineEdit()
        widget.setReadOnly(True)
        self._widgets[key] = widget
        self._layout.addRow(label, widget)

    def _check(self, key, label, value):
        widget = QtWidgets.QCheckBox(); widget.setChecked(bool(value.get(key, True))); self._add(key, label, widget)

    def _combo(self, key, label, values, value):
        widget = QtWidgets.QComboBox(); widget.addItems(values); widget.setCurrentText(str(value.get(key, values[0]))); self._add(key, label, widget)

    def _library_settings(self, value):
        self._line("package_name", "Python package name", value)

    def _table_controls(self, table, add_text, add_callback, remove_callback):
        controls = QtWidgets.QWidget(); layout = QtWidgets.QHBoxLayout(controls); layout.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton(add_text); remove = QtWidgets.QPushButton("Remove selected")
        add.clicked.connect(add_callback); remove.clicked.connect(remove_callback)
        layout.addWidget(add); layout.addWidget(remove); layout.addStretch(); return controls

    def _enum_values(self, value):
        table = QtWidgets.QTableWidget(0, 2); table.setHorizontalHeaderLabels(["Member name", "Integer value"])
        table.setMinimumHeight(110)
        table.horizontalHeader().setStretchLastSection(True); self._value_uids = []
        for member in value.get("values", []): self._append_enum_value(table, member)
        controls = self._table_controls(
            table, "Add enum value",
            lambda: self._add_enum_value(table),
            lambda: self._remove_row(table, self._value_uids),
        )
        table.itemChanged.connect(self._emit_changed)
        self._layout.addRow(table); self._layout.addRow(controls); self._widgets["_enum_values"] = table

    def _enum_storage(self, value):
        settings = value.get('storage')
        if not isinstance(settings, dict): settings = {}
        subtype = QtWidgets.QComboBox(); subtype.addItems(SUBTYPES)
        name = f"{settings.get('kind', '')}{settings.get('width', 0) * 8}" if type(settings.get('width')) is int else ''
        subtype.setCurrentIndex(subtype.findText(name))
        self._widgets['_enum_subtype'] = subtype; self._layout.addRow('Subtype', subtype)
        endian = QtWidgets.QComboBox(); endian.addItems(['big', 'little'])
        endian.setCurrentIndex(endian.findText(str(settings.get('endian', ''))))
        self._widgets['_enum_endian'] = endian; self._layout.addRow('Byte order', endian)
        subtype.currentIndexChanged.connect(self._emit_changed)
        endian.currentIndexChanged.connect(self._emit_changed)

    def _update_enum_preview(self, *args):
        if self._kind != 'Enum' or '_enum_preview' not in self._widgets:
            return
        subtype = self._widgets['_enum_subtype'].currentText()
        endian = self._widgets['_enum_endian']
        visible = subtype not in {'uint8', 'int8'}
        endian.setVisible(visible)
        label = self._layout.labelForField(endian)
        if label is not None: label.setVisible(visible)
        try:
            expression = definition_expression(self.value())
        except (KeyError, ValueError, TypeError) as error:
            expression = f'Unavailable until enum settings are complete: {error}'
        self._widgets['_enum_preview'].setPlainText(expression)

    def _append_enum_value(self, table, member):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row); self._value_uids.append(member.get("uid", new_id()))
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(member.get("name", "VALUE"))))
            table.setItem(row, 1, QtWidgets.QTableWidgetItem(str(member.get("value", 0))))
        finally:
            table.blockSignals(previous)

    def _add_enum_value(self, table):
        self._append_enum_value(table, {"uid": new_id(), "name": "VALUE", "value": 0})
        self.changed.emit()

    def _read_enum_values(self):
        table = self._widgets["_enum_values"]; result = []
        for row in range(table.rowCount()):
            text = table.item(row, 1).text().strip()
            try: number = int(text, 0)
            except ValueError: number = text
            result.append({"uid": self._value_uids[row], "name": table.item(row, 0).text(), "value": number})
        return result

    def _remove_row(self, table, uid_list):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try:
                table.removeRow(row); uid_list.pop(row)
            finally:
                table.blockSignals(previous)
            self.changed.emit()
