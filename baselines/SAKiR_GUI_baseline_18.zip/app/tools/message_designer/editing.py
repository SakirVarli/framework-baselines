"""Input checks and field-level merging shared by automatic editor commits."""
from __future__ import annotations

import ast
import copy
import keyword

from PyQt5 import QtCore, QtWidgets

from .model import PACKAGE_RE
from .object_defaults import guided_errors


def merge_edits(target, base, value):
    missing = object()
    for key in base.keys() | value.keys():
        if key == "uid" or base.get(key, missing) == value.get(key, missing):
            continue
        if key in value:
            target[key] = copy.deepcopy(value[key])
        else:
            target.pop(key, None)


def check_property_input(value, kind, manifest):
    name = value.get("name", "")
    if kind == "Group":
        if not name.strip():
            raise ValueError("Enter a group name.")
    elif kind != "Library" and not (kind == "Field" and value.get("kind") == "padding") and (
            not isinstance(name, str) or not name.isidentifier() or keyword.iskeyword(name)):
        raise ValueError("Enter a complete Python identifier for the name.")
    if kind == "Library" and not PACKAGE_RE.fullmatch(str(value.get("package_name", ""))):
        raise ValueError("Enter a complete Python package name.")
    if kind in {"Field", "Structure"}:
        if "uid" in value and not isinstance(value["uid"], str):
            raise ValueError("A stable ID must be text.")
        for key in ("fields", "cases", "members"):
            records = value.get(key, [])
            if not isinstance(records, list) or any(not isinstance(record, dict) for record in records):
                raise ValueError(f"{key} must be a JSON list of objects.")
        for child in value.get("fields", []):
            check_property_input(child, "Field", manifest)
        if "item" in value:
            if not isinstance(value["item"], dict): raise ValueError("A nested item must be a field object.")
            check_property_input(value["item"], "Field", manifest)
        for case in value.get("cases", []):
            if not isinstance(case.get("item"), dict): raise ValueError("Each switch case needs a field object.")
            check_property_input(case["item"], "Field", manifest)
        if kind == "Field":
            if not isinstance(value.get("kind"), str): raise ValueError("Enter a field kind.")
            if value.get("kind") in {"uint", "int", "float"} and type(value.get("width", 1)) is not int:
                raise ValueError("Field width must be a whole number.")
            if value.get('kind') == 'enum' and any(key in value for key in ('width', 'endian', 'signed')):
                raise ValueError('Enum storage belongs to its definition. Revert this legacy field draft, then select or create an enum definition with the required storage.')
    expressions = []
    if kind == "Field":
        field_kind = value.get("kind")
        for key in {"conditional": ("condition",), "switch": ("selector", "default"),
                    "const": ("value",), "default": ("value",), "computed": ("expression",),
                    "rebuild": ("expression",), "checksum": ("source",), "advanced": ("expression",)}.get(field_kind, ()):
            expressions.append(value.get(key, ""))
        if field_kind == "switch":
            expressions.extend(case.get("value", "") for case in value.get("cases", []))
        if field_kind == 'array':
            for key in ('count', 'min_count', 'max_count', 'initial_count', 'max_bytes'):
                number = value.get(key)
                if number is not None and (type(number) is not int or number < 0):
                    raise ValueError(f'Enter a nonnegative whole number for {key}.')
            if value.get('mode') in {'count_expression', 'byte_expression'}:
                expressions.append(value.get('count_expression', ''))
            if value.get('mode') == 'repeat_until':
                expressions.append(value.get('predicate', ''))
            if value.get('mode') == 'sentinel':
                try: ast.literal_eval(value.get('sentinel', ''))
                except (ValueError, SyntaxError): raise ValueError('Enter a literal terminating item.')
        if field_kind == "bitfield" and any(type(member.get("bits")) is not int for member in value.get("members", [])):
            raise ValueError("Enter a whole number for each bit width.")
        if value.get("object_default_mode") == "custom":
            expressions.append(value.get("object_default", ""))
        if value.get("object_default_mode") == "guided":
            errors = guided_errors(value, value.get("object_default_value"), manifest)
            if errors: raise ValueError("; ".join(errors))
    elif kind in {"Runtime", "Constant"}:
        expressions += [value.get("annotation", "Any"), value.get("default" if kind == "Runtime" else "value", "None")]
    if kind == "Enum" and any(type(member.get("value")) is not int for member in value.get("values", [])):
        raise ValueError("Enter a complete integer for each enum value.")
    for expression in expressions:
        try:
            ast.parse(str(expression), mode="eval")
        except SyntaxError as error:
            raise ValueError("Finish the expression before it can be applied: " + str(expression)) from error


def read_routing_draft(manifest, owner, draft):
    from dataclasses import replace
    from app.binary_messages.compiled_routing import Identifier
    from .routing_editor import _integer, parse_expected_text
    from .routing_model import parent_owner, resolve_definitions

    result = {}
    if "definitions" in draft:
        definitions = copy.deepcopy(draft["definitions"])
        for definition in definitions:
            name = str(definition.get("name", ""))
            if not name.isidentifier() or keyword.iskeyword(name):
                raise ValueError("Enter a complete Python identifier for the identifier name.")
            if definition.get("source", "raw") == "raw":
                for key in ("offset", "length"):
                    definition[key] = _integer(definition.get(key, 0))
        candidate = {**owner, "identifiers": definitions}
        for definition in resolve_definitions(manifest, candidate):
            Identifier(**definition)
        result["identifiers"] = definitions
    if "values" in draft:
        root_uid = manifest["library"]["uid"]
        parent_key = "parent_group_uid" if "parent_group_uid" in owner else "group_uid"
        if (draft["base"].get(parent_key) or root_uid) != (owner.get(parent_key) or root_uid):
            raise ValueError("The routing parent changed. Revert this draft and enter values for the new parent.")
        state = draft["values"]
        values = None
        if state.get("enabled"):
            parent = parent_owner(manifest, owner)
            if parent is None: raise ValueError("Select a valid routing parent.")
            raw_by_uid = {item["uid"]: item for item in parent.get("identifiers", [])}
            values = {}
            for definition in resolve_definitions(manifest, parent):
                text = state.get("texts", {}).get(definition["uid"])
                if text is None or text == "": continue
                identifier = Identifier(**definition)
                input_identifier = (identifier if raw_by_uid[identifier.uid].get("source", "raw") == "field"
                                    else replace(identifier, type="bytes", mask=None, shift=0))
                value = parse_expected_text(input_identifier, text)
                if value is None: continue
                raw = input_identifier.encode(value)
                if input_identifier.type == "bytes":
                    value = {"hex": raw.hex()} if identifier.type == "float" else identifier.decode(raw)
                    if identifier.encode(value) != raw:
                        raise ValueError("Expected bytes do not fit this identifier.")
                values[identifier.uid] = value
        result["expected_values"] = values
    return result


class EditorFocusEvents(QtCore.QObject):
    """Flush after Qt finishes a control's edit, without intercepting its keystrokes."""
    def __init__(self, window):
        super().__init__(window)
        self.window = window

    def watch(self, root):
        root.installEventFilter(self)
        for child in root.findChildren(QtWidgets.QWidget):
            child.installEventFilter(self)

    def eventFilter(self, watched, event):
        if event.type() == QtCore.QEvent.ChildPolished and isinstance(event.child(), QtWidgets.QWidget):
            self.watch(event.child())
            return False
        finished = event.type() == QtCore.QEvent.FocusOut or (
            event.type() == QtCore.QEvent.KeyPress and event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter)
            and isinstance(watched, (QtWidgets.QLineEdit, QtWidgets.QAbstractSpinBox)))
        if not finished or not isinstance(watched, QtWidgets.QWidget):
            return False
        window = self.window
        if not window._edit_events_active: return False
        if (window.common_properties_widget.isAncestorOf(watched) or window.field_options.isAncestorOf(watched)
                or window.definition_options.isAncestorOf(watched) or watched is window.details_edit
                or window.routing_studio.inspector.isAncestorOf(watched)):
            window._focus_commit_timer.start(0)
        return False
