"""Reorder messages among their siblings or move them to another routing group."""
from __future__ import annotations


def _resolve_move(data, uid, parent_uid, index):
    root_uid = data["library"]["uid"]
    if parent_uid != root_uid and not any(group.get("uid") == parent_uid for group in data.get("groups", [])):
        return None
    messages = data.get("messages", [])
    message = next((item for item in messages if item.get("uid") == uid), None)
    siblings = [item for item in messages if (item.get("group_uid") or root_uid) == parent_uid]
    if message is None or type(index) is not int or not 0 <= index <= len(siblings):
        return None
    return message, siblings


def can_move_message(data, uid, parent_uid, index):
    """Index is an insertion boundary among destination messages, excluding groups."""
    return _resolve_move(data, uid, parent_uid, index) is not None


def move_message(data, uid, parent_uid, index):
    """Move the existing message; reset routing assignments only when its parent changes."""
    resolved = _resolve_move(data, uid, parent_uid, index)
    if resolved is None:
        return False
    message, siblings = resolved
    messages = data["messages"]
    root_uid = data["library"]["uid"]
    if (message.get("group_uid") or root_uid) == parent_uid:
        source_index = siblings.index(message)
        if source_index < index:
            index -= 1
        if source_index == index:
            return False
        siblings.insert(index, siblings.pop(source_index))
        reordered = iter(siblings)
        messages[:] = [next(reordered) if (item.get("group_uid") or root_uid) == parent_uid else item
                       for item in messages]
    else:
        messages.remove(message)
        if index < len(siblings):
            insertion = messages.index(siblings[index])
        elif siblings:
            insertion = messages.index(siblings[-1]) + 1
        else:
            insertion = len(messages)
        message["group_uid"] = parent_uid
        message["expected_values"] = None
        messages.insert(insertion, message)
    return True
