"""Reusable tab-widget presentation helpers for runtime and designer previews."""

from PyQt5 import QtCore, QtGui, QtWidgets


TAB_POSITIONS = {
    "top": QtWidgets.QTabWidget.North,
    "bottom": QtWidgets.QTabWidget.South,
    "left": QtWidgets.QTabWidget.West,
    "right": QtWidgets.QTabWidget.East,
}


class HorizontalTextTabBar(QtWidgets.QTabBar):
    """Side tab bar that keeps labels horizontal instead of rotating them."""

    def tabSizeHint(self, index):
        base = super().tabSizeHint(index)
        metrics = self.fontMetrics()
        width = max(96, metrics.horizontalAdvance(self.tabText(index)) + 28)
        return QtCore.QSize(width, max(34, min(44, base.width())))

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        for index in range(self.count()):
            option = QtWidgets.QStyleOptionTab()
            self.initStyleOption(option, index)
            option.shape = QtWidgets.QTabBar.RoundedNorth
            # The standard label renderer still applies the West/East text
            # rotation from the tab bar even after the option is normalized.
            # Draw the horizontal label explicitly instead.
            label = option.text
            option.text = ""
            self.style().drawControl(
                QtWidgets.QStyle.CE_TabBarTabShape, option, painter, self)
            painter.setPen(option.palette.color(QtGui.QPalette.WindowText))
            painter.drawText(option.rect.adjusted(8, 0, -8, 0),
                             QtCore.Qt.AlignCenter, label)


def configure_tab_widget(widget, definition):
    position = str((definition or {}).get("tabPosition") or "top").lower()
    orientation = str(
        (definition or {}).get("tabTextOrientation") or "native").lower()
    if position in {"left", "right"} and orientation == "horizontal":
        widget.setTabBar(HorizontalTextTabBar(widget))
    widget.setTabPosition(TAB_POSITIONS.get(position, QtWidgets.QTabWidget.North))
    widget.setMovable(bool((definition or {}).get("movable", False)))
    widget.setDocumentMode(bool((definition or {}).get("documentMode", False)))
    return widget


def tab_header_layout(definition, labels, size, current_index=0):
    """Return real style-calculated tab and overflow-button geometry."""
    widget = configure_tab_widget(QtWidgets.QTabWidget(), definition)
    widget.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
    for label in labels:
        widget.addTab(QtWidgets.QWidget(widget), str(label))
    if widget.count():
        widget.setCurrentIndex(max(0, min(int(current_index), widget.count() - 1)))
    widget.resize(max(1, int(size.width())), max(1, int(size.height())))
    widget.ensurePolished()
    # Showing a WA_DontShowOnScreen widget performs Qt's internal tab-bar
    # layout without creating a visible window or processing application events.
    widget.show()
    bar = widget.tabBar()
    origin = bar.pos()
    rectangles = [
        QtCore.QRectF(bar.tabRect(index).translated(origin))
        for index in range(bar.count())
    ]
    previous = next_button = None
    previous_arrows = {QtCore.Qt.LeftArrow, QtCore.Qt.UpArrow}
    next_arrows = {QtCore.Qt.RightArrow, QtCore.Qt.DownArrow}
    for button in bar.findChildren(QtWidgets.QToolButton):
        if not button.isVisible():
            continue
        rectangle = QtCore.QRectF(button.geometry().translated(origin))
        if button.arrowType() in previous_arrows:
            previous = rectangle
        elif button.arrowType() in next_arrows:
            next_button = rectangle
    bar_rect = QtCore.QRectF(bar.geometry())
    widget.hide()
    widget.deleteLater()
    return {
        "tabs": rectangles,
        "bar": bar_rect,
        "previous": previous,
        "next": next_button,
        "overflow": previous is not None or next_button is not None,
    }


def tab_header_rects(definition, labels, size, current_index=0):
    """Backward-compatible tab rectangle helper."""
    return tab_header_layout(
        definition, labels, size, current_index=current_index)["tabs"]
