"""Transactional callback/external imports and editor-independent source watching."""

from __future__ import annotations

import importlib
import atexit
import json
import os
import sys
from pathlib import Path

from PyQt5 import QtCore


def automatic_source_reload_enabled(project_root) -> bool:
    """Read the supervisor preference; missing or invalid values default off."""
    path = Path(project_root) / "designer" / "settings.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return isinstance(payload, dict) and payload.get("automatic_source_reload") is True


class CallbackImportTransaction:
    """Stage callback-owned imports and publish them only after runtime success."""

    def __init__(self, project_root: Path, callbacks_path: Path, changed_paths=()):
        self.project_root = project_root.resolve()
        self.callbacks_path = callbacks_path.resolve()
        self.externals_root = (self.project_root / "externals").resolve()
        self.changed_paths = tuple(Path(path).resolve() for path in changed_paths)
        self.previous: dict[str, object] = {}
        self.candidate: dict[str, object] = {}
        self._staged = False
        self._active = False

    def _is_managed(self, name: str, module) -> bool:
        if name == "callbacks" or name == "externals" or name.startswith("externals."):
            return True
        filename = getattr(module, "__file__", "")
        if not filename:
            return False
        try:
            path = Path(filename).resolve()
        except OSError:
            return False
        return path == self.callbacks_path or path == self.externals_root or self.externals_root in path.parents

    def _managed_modules(self) -> dict[str, object]:
        return {
            name: module
            for name, module in tuple(sys.modules.items())
            if module is not None and self._is_managed(name, module)
        }

    def _clear_managed(self) -> None:
        for name, module in tuple(sys.modules.items()):
            if module is not None and self._is_managed(name, module):
                sys.modules.pop(name, None)

    def stage(self):
        from app.utils import load_callbacks

        for path in self.changed_paths:
            if path.suffix.lower() == ".py" and path.exists():
                compile(path.read_bytes(), str(path), "exec")

        # Timestamp-based pycs cannot distinguish same-size saves within a
        # second. Clear every managed source cache, including dependencies.
        sources = [self.callbacks_path]
        if self.externals_root.exists():
            sources.extend(self.externals_root.rglob("*.py"))
        for source in sources:
            cache = Path(importlib.util.cache_from_source(str(source)))
            cache.unlink(missing_ok=True)

        importlib.invalidate_caches()
        self.previous = self._managed_modules()
        self._clear_managed()
        try:
            callbacks = load_callbacks()
            self.candidate = self._managed_modules()
        except Exception:
            self._clear_managed()
            sys.modules.update(self.previous)
            raise
        self._clear_managed()
        sys.modules.update(self.previous)
        self._staged = True
        return callbacks

    def activate(self) -> None:
        """Make candidate imports available after old unload hooks finish."""
        if self._staged and not self._active:
            self._clear_managed()
            sys.modules.update(self.candidate)
            self._active = True

    def commit(self) -> None:
        if not self._staged:
            return
        if self._active:
            self.candidate = self._managed_modules()
        self._clear_managed()
        sys.modules.update(self.candidate)
        self._staged = False
        self._active = False

    def rollback(self) -> None:
        if not self._staged:
            return
        self._clear_managed()
        sys.modules.update(self.previous)
        self._staged = False
        self._active = False


class _SourceWatchWorker(QtCore.QObject):
    """Own scanning, native watches, and timers entirely in the worker thread."""

    changed = QtCore.pyqtSignal(object)
    ready = QtCore.pyqtSignal()

    def __init__(self, project_root: Path, debounce_ms: int):
        super().__init__()
        self.project_root = project_root
        self.callbacks_path = self.project_root / "callbacks" / "callbacks.py"
        self.externals_root = self.project_root / "externals"
        self._debounce_ms = debounce_ms
        self._snapshot = {}
        self._scan_queued = False
        self._pending: set[Path] = set()

    @QtCore.pyqtSlot()
    def start(self):
        if self.thread().isInterruptionRequested():
            return
        self._watcher = QtCore.QFileSystemWatcher(self)
        self._watcher.fileChanged.connect(self._filesystem_changed)
        self._watcher.directoryChanged.connect(self._filesystem_changed)
        self._debounce = QtCore.QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(self._debounce_ms)
        self._debounce.timeout.connect(self._emit_pending)
        self._poll = QtCore.QTimer(self)
        self._poll.setInterval(750)
        self._poll.timeout.connect(self._rescan)
        self._snapshot, desired = self._scan()
        if self.thread().isInterruptionRequested():
            return
        self._refresh_watches(desired)
        self._poll.start()
        self.ready.emit()

    def _scan(self):
        # A single traversal discovers both files and watchable directories.
        result = {}
        desired = {str(self.project_root)}
        if self.callbacks_path.parent.is_dir():
            desired.add(str(self.callbacks_path.parent))

        def record(path):
            try:
                stat = path.stat()
                result[path.resolve()] = (stat.st_mtime_ns, stat.st_size)
            except OSError:
                return
            desired.add(str(path))

        record(self.callbacks_path)
        for directory, subdirs, filenames in os.walk(self.externals_root):
            if self.thread().isInterruptionRequested():
                break
            subdirs[:] = [name for name in subdirs if name != "__pycache__"]
            desired.add(directory)
            for filename in filenames:
                if self.thread().isInterruptionRequested():
                    break
                if filename.lower().endswith(".py"):
                    record(Path(directory) / filename)
        return result, desired

    def _refresh_watches(self, desired) -> None:
        existing = set(self._watcher.files()) | set(self._watcher.directories())
        remove = list(existing - desired)
        add = list(desired - existing)
        if remove:
            self._watcher.removePaths(remove)
        if add:
            self._watcher.addPaths(add)

    def _filesystem_changed(self, _path: str) -> None:
        # Several native events for one save coalesce into one queued scan.
        if not self._scan_queued:
            self._scan_queued = True
            QtCore.QTimer.singleShot(0, self._rescan)

    @QtCore.pyqtSlot()
    def _rescan(self) -> None:
        self._scan_queued = False
        if self.thread().isInterruptionRequested():
            return
        current, desired = self._scan()
        if self.thread().isInterruptionRequested():
            return
        changed = {
            path for path in set(self._snapshot) | set(current)
            if self._snapshot.get(path) != current.get(path)
        }
        self._snapshot = current
        if changed:
            self._pending.update(changed)
            self._debounce.start()
        self._refresh_watches(desired)

    def _emit_pending(self) -> None:
        if not self._pending or self.thread().isInterruptionRequested():
            return
        paths = tuple(sorted(self._pending, key=lambda path: os.path.normcase(str(path))))
        self._pending.clear()
        self.changed.emit(paths)


# Threads must outlive their facade when its QObject parent is destroyed in
# the middle of a scan. Keep ownership here until the worker actually exits.
_watch_threads = set()


def _finish_watch_threads():
    threads = tuple(_watch_threads)
    for thread in threads:
        thread.requestInterruption()
        thread.quit()
    for thread in threads:
        thread.wait()


atexit.register(_finish_watch_threads)


class SourceReloadWatcher(QtCore.QObject):
    """UI-thread facade; only change notifications cross from the worker."""

    changed = QtCore.pyqtSignal(object)
    ready = QtCore.pyqtSignal()
    _scan_requested = QtCore.pyqtSignal()

    def __init__(self, project_root: Path, parent=None, debounce_ms: int = 500):
        super().__init__(parent)
        self.project_root = project_root.resolve()
        self._stopped = False
        self._thread = QtCore.QThread()
        self._thread.setObjectName("SourceReloadWatcher")
        self._worker = _SourceWatchWorker(self.project_root, debounce_ms)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.start)
        self._worker.changed.connect(self._deliver_changes, QtCore.Qt.QueuedConnection)
        self._worker.ready.connect(self.ready, QtCore.Qt.QueuedConnection)
        self._scan_requested.connect(self._worker._rescan, QtCore.Qt.QueuedConnection)
        self._thread.finished.connect(self._worker.deleteLater)
        thread = self._thread
        _watch_threads.add(thread)
        thread.finished.connect(lambda: _watch_threads.discard(thread))
        # Do not parent the running QThread to this facade: deletion can happen
        # before an in-progress filesystem call has returned.
        self.destroyed.connect(lambda: (thread.requestInterruption(), thread.quit()))
        application = QtCore.QCoreApplication.instance()
        if application is not None:
            application.aboutToQuit.connect(self.stop)
        self._thread.start()

    @QtCore.pyqtSlot(object)
    def _deliver_changes(self, paths):
        if not self._stopped:
            self.changed.emit(paths)

    def _rescan(self):
        if not self._stopped:
            self._scan_requested.emit()

    @QtCore.pyqtSlot()
    def stop(self):
        """Cancel without waiting for disk I/O on the UI thread."""
        self._stopped = True
        self._thread.requestInterruption()
        self._thread.quit()
