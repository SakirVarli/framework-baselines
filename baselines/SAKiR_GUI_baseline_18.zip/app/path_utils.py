from pathlib import Path

from app.utils import PROJECT_ROOT


def norm_slash(path: str) -> str:
    return (path or "").replace("\\", "/").strip()


def is_abs_path(path: str) -> bool:
    try:
        return Path(path).is_absolute()
    except Exception:
        return False


def rel_to_abs_project(path: str) -> str:
    path = norm_slash(path)
    if is_abs_path(path):
        return path
    return str((Path(PROJECT_ROOT) / path).resolve())


def abs_to_rel_project(path: str) -> str:
    path = str(Path(path).resolve())
    try:
        rel = Path(path).resolve().relative_to(Path(PROJECT_ROOT).resolve())
        return rel.as_posix()
    except Exception:
        return norm_slash(path)


def resolve_config_path(path: str, relative: bool = False) -> str:
    path = norm_slash(path)
    if relative:
        return rel_to_abs_project(path)
    return str(Path(path).resolve()) if path else ""
