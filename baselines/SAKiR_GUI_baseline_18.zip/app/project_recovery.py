"""Detect and optionally restore project files required during application startup."""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Iterable

from app.starter_project import starter_project_files


CORE_PROJECT_FILES = (
    "app/data/config.json",
    "callbacks/callbacks.py",
)


def missing_project_files(project_root: str | Path) -> tuple[str, ...]:
    """Return required project paths that do not currently exist."""
    root = Path(project_root).resolve()
    return tuple(relative for relative in CORE_PROJECT_FILES if not (root / relative).is_file())


def generate_missing_project_files(
    project_root: str | Path,
    missing: Iterable[str] | None = None,
) -> tuple[Path, ...]:
    """Create only absent required files from the central starter templates."""
    root = Path(project_root).resolve()
    requested = tuple(missing if missing is not None else missing_project_files(root))
    invalid = set(requested).difference(CORE_PROJECT_FILES)
    if invalid:
        raise ValueError(f"Unsupported recovery paths: {', '.join(sorted(invalid))}")

    templates = starter_project_files()
    written: list[Path] = []
    for relative in requested:
        target = (root / relative).resolve()
        if root != target and root not in target.parents:
            raise ValueError(f"Recovery path escaped the project root: {relative}")
        if target.exists():
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(templates[relative], encoding="utf-8")
        written.append(target)
    return tuple(written)


def ensure_project_files(
    project_root: str | Path,
    ask_generate: Callable[[tuple[str, ...]], bool],
    warn_degraded: Callable[[tuple[str, ...]], None],
) -> str:
    """Run decision-driven recovery and return ready, generated, or degraded."""
    missing = missing_project_files(project_root)
    if not missing:
        return "ready"
    if ask_generate(missing):
        generate_missing_project_files(project_root, missing)
        return "generated"
    warn_degraded(missing)
    return "degraded"


__all__ = [
    "CORE_PROJECT_FILES",
    "ensure_project_files",
    "generate_missing_project_files",
    "missing_project_files",
]
