from __future__ import annotations

import os
import json
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any

from app.upgrade_manager import (
    INSTALLED_MANIFEST,
    PACKAGE_FILENAME,
    STATE_DIRNAME,
    atomic_write_json,
    build_file_entries,
    create_temporary_export_root,
    make_manifest,
    inspect_archive,
    sha256_file,
    utc_now,
)
from app.project_identity import BASELINE_FAMILY_ID
from app.branding import filename_short_name
from app.utils import PROJECT_ROOT, load_json, save_json


EXPORT_ITEMS = ("app", "callbacks", "externals", "designer.exe")
RECOVERY_ARCHIVE_NAME = "recovery.zip"
RECOVERY_MANIFEST_NAME = "recovery-manifest.json"
RECOVERY_SCHEMA_VERSION = 1


def hide_folder(path: str) -> None:
    if sys.platform != "win32":
        return
    import ctypes

    file_attribute_hidden = 0x02
    attrs = ctypes.windll.kernel32.GetFileAttributesW(path)
    if attrs == -1:
        raise OSError(f"Could not read file attributes:\n{path}")
    if not ctypes.windll.kernel32.SetFileAttributesW(path, attrs | file_attribute_hidden):
        raise OSError(f"Could not hide folder:\n{path}")


def _ignore_export_files(_directory: str, names: list[str]) -> set[str]:
    is_app_data = tuple(part.lower() for part in Path(_directory).parts[-2:]) == ("app", "data")
    ignored = {
        name for name in names
        if name == "__pycache__"
        or name.endswith((".pyc", ".pyo"))
        or name in {
            "assistant.json", "assistant.json.bak", "assistant.json.tmp",
            "help.json.bak", "help.json.tmp",
        }
        or (is_app_data and name.lower() == "assistant")
    }
    return ignored


def _copy_payload(export_root: Path) -> None:
    source_root = Path(PROJECT_ROOT)
    supervisor_sources = (
        source_root / "designer_builder" / "designer.py",
        source_root / "app" / "branding.py",
        source_root / "app" / "vscode_integration.py",
    )
    supervisor_executable = source_root / "designer.exe"
    if (
        all(path.is_file() for path in supervisor_sources)
        and supervisor_executable.is_file()
        and supervisor_executable.stat().st_mtime
        < max(path.stat().st_mtime for path in supervisor_sources)
    ):
        raise RuntimeError(
            "designer.exe is older than its supervisor sources. Rebuild the supervisor executable "
            "before exporting this baseline."
        )
    for item in EXPORT_ITEMS:
        source = source_root / item
        destination = export_root / item
        if not source.exists():
            raise FileNotFoundError(f"Required export item not found:\n{source}")
        if source.is_dir():
            shutil.copytree(source, destination, ignore=_ignore_export_files)
        else:
            shutil.copy2(source, destination)

    if not any(
        (export_root / "app" / "vscode_extention").glob("sakir-supervisor-*.vsix")
    ):
        raise FileNotFoundError(
            "The bundled SAKiR Supervisor VSIX is missing. Run "
            "app/vscode_extention/build_vsix.py before exporting this baseline."
        )


def _payload_paths(export_root: Path) -> list[str]:
    paths: list[str] = []
    for item in EXPORT_ITEMS:
        root = export_root / item
        if root.is_file():
            paths.append(item)
        elif root.is_dir():
            paths.extend(path.relative_to(export_root).as_posix() for path in root.rglob("*") if path.is_file())
    return paths


def _write_source_recovery_archive(
    export_root: Path,
    *,
    baseline_number: int,
    version: str,
    build: Any,
) -> Path:
    app_root = export_root / "app"
    resolved_app_root = app_root.resolve()
    destination = app_root / RECOVERY_ARCHIVE_NAME
    temporary = destination.with_name(destination.name + ".tmp")
    source_paths = sorted(
        (path for path in app_root.rglob("*.py") if path.is_file()),
        key=lambda path: path.relative_to(export_root).as_posix().casefold(),
    )
    if not source_paths:
        raise RuntimeError("Cannot create source recovery archive because app contains no Python files.")
    for path in source_paths:
        resolved = path.resolve()
        if resolved_app_root != resolved and resolved_app_root not in resolved.parents:
            raise RuntimeError(f"Refusing to archive app source outside the app folder: {path}")

    files = [
        {
            "path": path.relative_to(export_root).as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in source_paths
    ]
    manifest = {
        "schema_version": RECOVERY_SCHEMA_VERSION,
        "baseline_family_id": BASELINE_FAMILY_ID,
        "created_by": "baseline-export",
        "created_at": utc_now(),
        "intended_phase": "development",
        "release": {
            "baseline_number": int(baseline_number),
            "version": str(version or ""),
            "build": build,
        },
        "files": files,
    }
    try:
        with zipfile.ZipFile(
            temporary,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=6,
        ) as archive:
            archive.writestr(
                RECOVERY_MANIFEST_NAME,
                json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8"),
            )
            for path in source_paths:
                archive.write(path, path.relative_to(export_root).as_posix())
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()
    return destination


def _write_zip(source_root: Path, destination: Path) -> None:
    temporary = destination.with_name(destination.name + ".tmp")
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            # Explicit directory entries let Windows-aware extractors retain the
            # hidden presentation for the framework and upgrade state folders.
            for directory in ("app/", f"{STATE_DIRNAME}/"):
                info = zipfile.ZipInfo(directory)
                info.create_system = 0
                info.external_attr = 0x10 | 0x02  # DOS directory + hidden
                archive.writestr(info, b"")
            for path in sorted(source_root.rglob("*")):
                if path.is_file():
                    relative = path.relative_to(source_root).as_posix()
                    archive.write(path, relative)
                    if relative == PACKAGE_FILENAME:
                        info = archive.getinfo(relative)
                        info.create_system = 0
                        info.external_attr = 0x20 | 0x02  # DOS archive + hidden
                    elif (
                        relative.startswith("app/")
                        or relative.startswith(f"{STATE_DIRNAME}/")
                    ):
                        # The parent directories carry the hidden presentation.
                        # Marking their children hidden prevents Python from
                        # overwriting settings JSON files on Windows.
                        info = archive.getinfo(relative)
                        info.create_system = 0
                        info.external_attr = 0x20  # DOS archive, writable and visible
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()


def create_baseline_package(
    target_parent: str,
    baseline_number: int,
    *,
    version: str = "",
    build: Any = "",
    title: str = "",
    summary: str = "",
    notes: str = "",
    minimum_baseline: int | None = None,
    output_mode: str = "zip",
) -> dict[str, str]:
    if output_mode not in {"zip", "folder", "both"}:
        raise ValueError(f"Unsupported output mode: {output_mode}")
    parent = Path(target_parent).resolve()
    parent.mkdir(parents=True, exist_ok=True)
    export_name = f"{filename_short_name()}_GUI_baseline_{int(baseline_number)}"
    folder_path = parent / export_name
    zip_path = parent / f"{export_name}.zip"
    if output_mode in {"folder", "both"} and folder_path.exists():
        raise FileExistsError(f"Export folder already exists:\n{folder_path}")
    if output_mode in {"zip", "both"} and zip_path.exists():
        raise FileExistsError(f"Export archive already exists:\n{zip_path}")

    temporary = create_temporary_export_root(parent, export_name)
    try:
        _copy_payload(temporary)
        config_path = temporary / "app" / "data" / "config.json"
        config = load_json(str(config_path))
        window = config.setdefault("window", {})
        window["phase"] = "development"
        window["baseline_number"] = int(baseline_number)
        if version:
            window["version"] = version
        if build != "":
            window["build"] = build
        save_json(str(config_path), config)

        _write_source_recovery_archive(
            temporary,
            baseline_number=baseline_number,
            version=version,
            build=build,
        )

        files = build_file_entries(temporary, _payload_paths(temporary))
        manifest = make_manifest(
            baseline_number=baseline_number,
            version=version,
            build=build,
            title=title,
            summary=summary,
            notes=notes,
            minimum_baseline=minimum_baseline,
            files=files,
        )
        atomic_write_json(temporary / PACKAGE_FILENAME, manifest)
        atomic_write_json(temporary / STATE_DIRNAME / INSTALLED_MANIFEST, manifest)

        outputs: dict[str, str] = {}
        if output_mode in {"zip", "both"}:
            _write_zip(temporary, zip_path)
            inspect_archive(zip_path, verify_payload=True)
            outputs["zip"] = str(zip_path)
        if output_mode in {"folder", "both"}:
            os.replace(temporary, folder_path)
            outputs["folder"] = str(folder_path)
            try:
                hide_folder(str(folder_path / "app"))
                hide_folder(str(folder_path / STATE_DIRNAME))
                hide_folder(str(folder_path / PACKAGE_FILENAME))
            except OSError:
                pass
        return outputs
    finally:
        if temporary.exists():
            shutil.rmtree(temporary, ignore_errors=True)


def export_baseline(target_parent: str, baseline_number: int) -> str:
    """Compatibility wrapper for callers that still expect the old API."""
    outputs = create_baseline_package(target_parent, baseline_number, output_mode="zip")
    return outputs["zip"]
