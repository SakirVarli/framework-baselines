"""Build the dependency-free SAKiR Supervisor extension as an installable VSIX."""

from __future__ import annotations

import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PACKAGE = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
OUTPUT = ROOT / f"sakir-supervisor-{PACKAGE['version']}.vsix"

CONTENT_TYPES = """<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="json" ContentType="application/json" />
  <Default Extension="js" ContentType="application/javascript" />
  <Default Extension="md" ContentType="text/markdown" />
  <Default Extension="txt" ContentType="text/plain" />
  <Default Extension="ico" ContentType="image/x-icon" />
  <Default Extension="vsixmanifest" ContentType="text/xml" />
</Types>
"""

MANIFEST = f"""<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011">
  <Metadata>
    <Identity Language="en-US" Id="{PACKAGE['name']}" Version="{PACKAGE['version']}" Publisher="{PACKAGE['publisher']}" />
    <DisplayName>{PACKAGE['displayName']}</DisplayName>
    <Description xml:space="preserve">{PACKAGE['description']}</Description>
    <Categories>Other</Categories>
    <Properties>
      <Property Id="Microsoft.VisualStudio.Code.Engine" Value="{PACKAGE['engines']['vscode']}" />
    </Properties>
  </Metadata>
  <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code" /></Installation>
  <Dependencies />
  <Assets>
    <Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Content.License" Path="extension/LICENSE" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Icons.Default" Path="extension/app.ico" Addressable="true" />
  </Assets>
</PackageManifest>
"""

with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    archive.writestr("[Content_Types].xml", CONTENT_TYPES)
    archive.writestr("extension.vsixmanifest", MANIFEST)
    for name in ("package.json", "extension.js", "README.md", "LICENSE", "app.ico"):
        archive.write(ROOT / name, f"extension/{name}")

print(OUTPUT)
