const vscode = require("vscode");
const path = require("path");

const HANDOFF_RELATIVE_PATH = "designer/vscode-handoff.json";
const SUPERVISOR_TASK_NAME = "SAKiR: Supervisor Host";
const TOKEN_PATTERN = /^[a-f0-9]{32}$/i;

/** @param {string} value */
function normalizedPath(value) {
    const resolved = path.resolve(value);
    return process.platform === "win32" ? resolved.toLowerCase() : resolved;
}

/** @param {vscode.Task} task @param {vscode.WorkspaceFolder} folder */
function taskBelongsToFolder(task, folder) {
    if (task.scope === vscode.TaskScope.Workspace) {
        return (vscode.workspace.workspaceFolders || []).length === 1;
    }
    return Boolean(
        task.scope &&
        task.scope.uri &&
        normalizedPath(task.scope.uri.fsPath) === normalizedPath(folder.uri.fsPath)
    );
}

/** @param {vscode.WorkspaceFolder} folder */
async function findSupervisorTask(folder) {
    const tasks = await vscode.tasks.fetchTasks();
    return tasks.find(
        (task) => task.name === SUPERVISOR_TASK_NAME && taskBelongsToFolder(task, folder)
    );
}

/** @param {vscode.ExtensionContext} context */
function activate(context) {
    const output = vscode.window.createOutputChannel("SAKiR Supervisor", { log: true });
    const status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 25);
    const activeTokens = new Set();
    const watchers = new Map();
    status.command = "sakir.integrationStatus";
    status.text = "$(terminal) SAKiR";
    status.tooltip = "SAKiR project-folder supervisor integration is ready";
    status.show();
    context.subscriptions.push(output, status);

    /** @param {vscode.WorkspaceFolder} folder @param {boolean} manual */
    async function startSupervisor(folder, manual = false) {
        if (!vscode.workspace.isTrusted) {
            void vscode.window.showWarningMessage("Trust this workspace before starting the SAKiR Supervisor.");
            return false;
        }
        const task = await findSupervisorTask(folder);
        if (!task) {
            const message = `${SUPERVISOR_TASK_NAME} was not found in ${folder.name}/.vscode/tasks.json.`;
            output.error(message);
            if (manual) {
                void vscode.window.showErrorMessage(message);
            }
            return false;
        }
        output.info(`Starting ${SUPERVISOR_TASK_NAME} for ${folder.uri.fsPath}`);
        await vscode.tasks.executeTask(task);
        return true;
    }

    /** @param {vscode.WorkspaceFolder} folder */
    async function processHandoff(folder) {
        const handoffUri = vscode.Uri.joinPath(folder.uri, ...HANDOFF_RELATIVE_PATH.split("/"));
        let payload;
        try {
            const bytes = await vscode.workspace.fs.readFile(handoffUri);
            payload = JSON.parse(Buffer.from(bytes).toString("utf8"));
        } catch (error) {
            if (error && error.code !== "FileNotFound") {
                output.debug(`Handoff file is not ready: ${String(error)}`);
            }
            return;
        }
        const token = typeof payload.token === "string" ? payload.token : "";
        if (
            payload.state !== "staged" ||
            !TOKEN_PATTERN.test(token) ||
            !Number.isInteger(Number(payload.old_pid)) ||
            Number(payload.old_pid) <= 0 ||
            activeTokens.has(token)
        ) {
            return;
        }
        if (
            payload.project_root &&
            normalizedPath(payload.project_root) !== normalizedPath(folder.uri.fsPath)
        ) {
            output.warn(`Ignored handoff ${token}: project root does not match this workspace folder.`);
            return;
        }

        activeTokens.add(token);
        status.text = "$(sync~spin) SAKiR handoff";
        try {
            if (!await startSupervisor(folder)) {
                activeTokens.delete(token);
            }
        } catch (error) {
            activeTokens.delete(token);
            output.error(`Could not start the supervisor task: ${String(error)}`);
            void vscode.window.showErrorMessage(`SAKiR handoff failed: ${String(error)}`);
        } finally {
            status.text = "$(terminal) SAKiR";
        }
    }

    function refreshWatchers() {
        const folders = vscode.workspace.workspaceFolders || [];
        const current = new Set(folders.map((folder) => folder.uri.toString()));
        for (const [key, watcher] of watchers) {
            if (!current.has(key)) {
                watcher.dispose();
                watchers.delete(key);
            }
        }
        for (const folder of folders) {
            const key = folder.uri.toString();
            if (!watchers.has(key)) {
                const watcher = vscode.workspace.createFileSystemWatcher(
                    new vscode.RelativePattern(folder, HANDOFF_RELATIVE_PATH)
                );
                watcher.onDidCreate(() => void processHandoff(folder), null, context.subscriptions);
                watcher.onDidChange(() => void processHandoff(folder), null, context.subscriptions);
                watchers.set(key, watcher);
                context.subscriptions.push(watcher);
            }
            void processHandoff(folder);
        }
    }

    context.subscriptions.push(
        vscode.workspace.onDidChangeWorkspaceFolders(refreshWatchers),
        vscode.commands.registerCommand("sakir.startSupervisor", async () => {
            const folders = vscode.workspace.workspaceFolders || [];
            if (!folders.length) {
                void vscode.window.showWarningMessage("Open a SAKiR project folder first.");
                return;
            }
            const folder = folders.length === 1
                ? folders[0]
                : await vscode.window.showWorkspaceFolderPick({ placeHolder: "Select the SAKiR project" });
            if (folder) {
                await startSupervisor(folder, true);
            }
        }),
        vscode.commands.registerCommand("sakir.integrationStatus", () => {
            const folderCount = (vscode.workspace.workspaceFolders || []).length;
            void vscode.window.showInformationMessage(
                `SAKiR Supervisor integration is active for ${folderCount} workspace folder${folderCount === 1 ? "" : "s"}.`
            );
        })
    );

    refreshWatchers();
    output.info("Project-folder handoff watcher is active.");
}

function deactivate() {}

module.exports = { activate, deactivate };
