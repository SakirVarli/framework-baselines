# SAKiR Supervisor

This companion extension starts the project-local `SAKiR: Supervisor Host` task when
`designer.exe` stages a terminal-ownership handoff.

It always uses the currently opened project folder. No machine-specific project path and
no generated `.code-workspace` file is stored in the extension.

The workspace must be trusted because the task runs the project's `designer.exe`.

Commands:

- `SAKiR: Start Supervisor`
- `SAKiR: Integration Status`

Debugging shortcut:

- `Ctrl+E` evaluates the selected editor text in the Debug Console while a debug
  session is active. Outside that context, the extension does not claim the shortcut.
