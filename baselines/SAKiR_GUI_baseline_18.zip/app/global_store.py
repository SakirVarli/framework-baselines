"""Process-local registry used by the callback-facing Globals API.

The registry protects its own mapping operations. It deliberately does not
claim to make mutable values, user resources, or Qt objects thread-safe.
"""

from __future__ import annotations

from contextlib import contextmanager
from threading import RLock, local
from typing import Any, Callable, Dict, Iterable, Iterator, Mapping


class AppGlobalDefinitionError(RuntimeError):
    """Raised when a global declaration or name violates the public contract."""


RESERVED_GLOBAL_NAMES = frozenset(
    {
        "clear", "get", "items", "keys",
        "mutate", "pop", "setdefault", "snapshot",
        "update", "values", "init_globals", "definitions", "state",
        "generation", "error",
    }
)


def validate_global_name(name: str) -> str:
    """Validate a user-visible registry name and return it unchanged."""
    if not isinstance(name, str) or not name:
        raise AppGlobalDefinitionError("Global names must be non-empty strings.")
    if name.startswith("_"):
        raise AppGlobalDefinitionError(
            f"Global name {name!r} is reserved; names beginning with '_' are internal."
        )
    if name in RESERVED_GLOBAL_NAMES:
        raise AppGlobalDefinitionError(
            f"Global name {name!r} conflicts with the Globals mapping API. "
            "Choose a different name."
        )
    return name


_MISSING = object()


class GlobalRegistry:
    """Constructable, process-local registry with atomic mapping operations."""

    _INTERNAL_ATTRIBUTES = frozenset(
        {
            "_values", "_specs", "_owners", "_lock", "_local",
            "_state", "_generation", "_error",
        }
    )

    def __init__(self) -> None:
        object.__setattr__(self, "_values", {})
        object.__setattr__(self, "_specs", {})
        object.__setattr__(self, "_owners", {})
        object.__setattr__(self, "_lock", RLock())
        object.__setattr__(self, "_local", local())
        object.__setattr__(self, "_state", "EMPTY")
        object.__setattr__(self, "_generation", 0)
        object.__setattr__(self, "_error", None)

    def _active_values(self) -> Dict[str, Any]:
        return getattr(self._local, "staging_values", self._values)

    @contextmanager
    def _staging_scope(self, values: Dict[str, Any]):
        previous = getattr(self._local, "staging_values", _MISSING)
        self._local.staging_values = values
        try:
            yield values
        finally:
            if previous is _MISSING:
                try:
                    del self._local.staging_values
                except AttributeError:
                    pass
            else:
                self._local.staging_values = previous

    def __getattr__(self, name: str) -> Any:
        with self._lock:
            values = self._active_values()
            if name in values:
                return values[name]
        raise AttributeError(f"Global {name!r} not found")

    def __setattr__(self, name: str, value: Any) -> None:
        if name in self._INTERNAL_ATTRIBUTES:
            object.__setattr__(self, name, value)
            return
        validate_global_name(name)
        with self._lock:
            self._active_values()[name] = value

    def __delattr__(self, name: str) -> None:
        if name in self._INTERNAL_ATTRIBUTES or name.startswith("_"):
            raise AppGlobalDefinitionError(f"Internal registry attribute {name!r} cannot be deleted.")
        self.__delitem__(name)

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            return self._active_values()[key]

    def __setitem__(self, key: str, value: Any) -> None:
        validate_global_name(key)
        with self._lock:
            self._active_values()[key] = value

    def __delitem__(self, key: str) -> None:
        validate_global_name(key)
        with self._lock:
            values = self._active_values()
            if key not in values:
                raise KeyError(key)
            del values[key]
            if values is self._values:
                self._owners.pop(key, None)

    def __contains__(self, key: object) -> bool:
        with self._lock:
            return key in self._active_values()

    def __len__(self) -> int:
        with self._lock:
            return len(self._active_values())

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def keys(self) -> list[str]:
        with self._lock:
            return list(self._active_values())

    def values(self) -> list[Any]:
        with self._lock:
            return list(self._active_values().values())

    def items(self) -> list[tuple[str, Any]]:
        with self._lock:
            return list(self._active_values().items())

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._active_values().get(key, default)

    def pop(self, key: str, default: Any = _MISSING) -> Any:
        validate_global_name(key)
        with self._lock:
            values = self._active_values()
            if values is self._values:
                self._owners.pop(key, None)
            if default is _MISSING:
                return values.pop(key)
            return values.pop(key, default)

    def setdefault(self, key: str, default: Any = None) -> Any:
        validate_global_name(key)
        with self._lock:
            return self._active_values().setdefault(key, default)

    def update(self, new_data: Mapping[str, Any] | Iterable[tuple[str, Any]]) -> None:
        incoming = dict(new_data)
        for key in incoming:
            validate_global_name(key)
        with self._lock:
            self._active_values().update(incoming)

    def clear(self) -> None:
        """Remove values while retaining declaration/runtime metadata."""
        with self._lock:
            values = self._active_values()
            values.clear()
            if values is self._values:
                self._owners.clear()

    def snapshot(self) -> Dict[str, Any]:
        """Return a locked shallow copy of all current values."""
        with self._lock:
            return dict(self._active_values())

    def _spec_snapshot(self) -> Dict[str, Any]:
        """Return a locked shallow copy of current declaration specs."""
        with self._lock:
            return dict(self._specs)

    def mutate(self, key: str, operation: Callable[[Any], Any]) -> Any:
        """Atomically replace ``key`` with ``operation(current_value)``."""
        validate_global_name(key)
        if not callable(operation):
            raise TypeError("operation must be callable")
        with self._lock:
            values = self._active_values()
            if key not in values:
                raise KeyError(key)
            value = operation(values[key])
            values[key] = value
            return value

    @property
    def state(self) -> str:
        with self._lock:
            return self._state

    @property
    def generation(self) -> int:
        with self._lock:
            return self._generation

    @property
    def error(self) -> Any:
        with self._lock:
            return self._error

    def _set_runtime_state(
        self, state: str, *, generation: int | None = None, error: Any = None
    ) -> None:
        with self._lock:
            self._state = str(state)
            if generation is not None:
                self._generation = int(generation)
            self._error = error

    def _commit_generation(
        self,
        *,
        specs: Mapping[str, Any],
        values: Mapping[str, Any],
        generation: int,
        owner: str = "callbacks",
    ) -> None:
        """Atomically replace the committed values/specifications for a generation."""
        for key in values:
            validate_global_name(key)
        with self._lock:
            self._values = dict(values)
            self._specs = dict(specs)
            self._owners = {
                key: owner for key in specs if key in self._values
            }
            self._generation = generation
            self._state = "INITIALIZING_RESOURCES"
            self._error = None

    def _owned_snapshot(self, owner: str = "callbacks") -> Dict[str, Any]:
        """Return values currently owned by one lifecycle owner."""
        with self._lock:
            return {
                key: self._values[key]
                for key, current_owner in self._owners.items()
                if current_owner == owner and key in self._values
            }

    def _restore_generation(
        self,
        *,
        values: Mapping[str, Any],
        specs: Mapping[str, Any],
        generation: int,
        state: str,
        error: Any = None,
    ) -> None:
        """Restore a coordinator snapshot after a pre-commit failure."""
        with self._lock:
            self._values = dict(values)
            self._specs = dict(specs)
            self._owners = {
                key: "callbacks" for key in specs if key in self._values
            }
            self._generation = int(generation)
            self._state = str(state)
            self._error = error

    def __dir__(self) -> list[str]:
        return sorted(set(super().__dir__()) | set(self.keys()))

    def __repr__(self) -> str:
        with self._lock:
            keys = list(self._values)
            state = self._state
            generation = self._generation
        return f"<GlobalRegistry state={state} generation={generation} keys={keys}>"


AppGlobals = GlobalRegistry()


__all__ = [
    "AppGlobalDefinitionError", "AppGlobals", "GlobalRegistry",
    "RESERVED_GLOBAL_NAMES", "validate_global_name",
]
