"""Bounded host-owned evidence for answers and factual review. No code execution."""
import re
from urllib.parse import urlsplit, parse_qs, unquote

from .policy import AssistantError
from .retrieval import tokens


def discusses_help_topic(answer, records):
    """A cited procedure is not the only way to make an installed-tool claim."""
    terms = set(tokens(answer))
    return any(row.get('kind')=='help' and len(topic := set(tokens(row.get('title',''))))>=2
               and topic <= terms for row in records)


def citation_key(reference):
    if reference.startswith('sakir-help:'):
        return ('app/data/help.json', reference.removeprefix('sakir-help:').split('#')[0])
    if reference.startswith('sakir-source:'):
        parsed = urlsplit(reference)
        return (unquote(parsed.path),None)
    match = re.fullmatch(r'([\w./-]+)(?::(\d+))?', reference)
    return (match[1], None) if match else None


def source_line_range(fragment):
    if not fragment:
        return None
    match = re.fullmatch(r'L(\d+)(?:-L?(\d+))?', unquote(fragment))
    if match is None:
        raise ValueError('Invalid source line range.')
    first, last = int(match[1]), int(match[2] or match[1])
    if not 1 <= first <= last:
        raise ValueError('Invalid source line range.')
    return first, last


def citation_matches(reference, record):
    if reference.startswith('sakir-evidence:'):
        return reference == record.get('id') and record.get('delivered', False)
    if citation_key(reference) != (record['path'],record.get('section_id')):
        return False
    if reference.startswith('sakir-source:'):
        parsed = urlsplit(reference)
        revision = parse_qs(parsed.query).get('revision',[None])[0]
        if revision and revision != record.get('content_revision'):
            return False
        try:
            bounds = source_line_range(parsed.fragment)
        except ValueError:
            return False
        if bounds:
            first = record.get('line',record.get('start_line',1))
            return first <= bounds[0] <= bounds[1] <= record.get('end_line',first)
        return True
    else:
        match = re.search(r':(\d+)$',reference)
    if match:
        first = record.get('line',record.get('start_line',1))
        last = record.get('end_line', first)
        return first <= int(match[1]) <= last
    return True


def resolve_citations(response, proofs, records):
    for reference in response.evidence:
        if not any(citation_matches(reference,r) for r in [*proofs,*records]):
            raise AssistantError('API_EVIDENCE_MISMATCH', 'Citation was not retrieved or inspected in this run: '+reference)


def review_bundle(tools, response, proofs):
    """Cited material is required. Other relevant inspected evidence is optional."""
    def required(row):
        return any(citation_matches(r,row) for r in response.evidence)
    terms = set(tokens(response.answer))
    locations = [(path, int(line)) for path, line in re.findall(
        r'([\w./-]+\.\w+)`?\s*(?::\s*(?:lines?\s+)?|[, (]+lines?\s+)(\d{1,9})\b', response.answer)]
    registry = getattr(tools, 'evidence_registry', None)
    # The verifier can receive newly inspected host evidence here. This does not
    # authorize citations in the primary answer before their own delivery gate.
    rows = registry.records(delivered=False, with_text=True) if registry is not None else list(tools.answer_evidence)
    for proof in proofs:
        record = tools.index.cache.get(proof['path'], {})
        first = max(0, proof['line']-1)
        symbols = [s for s in record.get('symbols', []) if s.get('line') == proof['line']]
        end = min((s['end_line'] for s in symbols), default=proof['line']+5)
        text = '\n'.join(record.get('text', '').splitlines()[first:end])
        rows.append({**proof, 'end_line':end, 'kind':'static_contract', 'text':text[:5000],
                     'truncated':len(text)>5000, 'basis':'static_api_contract'})
    def rank(row):
        first = row.get('line', 1)
        return (required(row),
                any(row['path'] == path and first <= line <= row.get('end_line', first)
                    for path, line in locations),
                row.get('basis') != 'retrieval_lead',
                len(terms & set(tokens(row.get('title', '') + ' ' + row.get('text', '')))))
    rows.sort(key=rank, reverse=True)
    selected, seen, omitted = [], set(), []
    for row in rows:
        key = (row['path'], row.get('section_id'), row.get('line'), row.get('end_line'), row.get('offset',0))
        if key in seen:
            continue
        seen.add(key)
        item = dict(row, required=required(row), evidence_id=row.get('id') or row['path']+':'+str(row.get('line',1)))
        if item['required'] and not item.get('text'):
            raise AssistantError('EVIDENCE_CONTENT_REQUIRED', 'Cited content is no longer in the bounded text cache; inspect it again: '+row['path'])
        if len(selected)<12 or item['required']:
            selected.append(item)
        else:
            omitted.append({'path':row['path'],'section_id':row.get('section_id'),'reason':'review_record_limit'})
    return selected, omitted


def validate_review_findings(verdict, response, records):
    """A blocker must quote a real answer claim and cite evidence actually supplied."""
    if verdict['status'] == 'supported':
        if verdict.get('findings'):
            raise AssistantError('API_REVIEW_REQUIRED', 'Supported review cannot contain blocking findings.')
        return
    findings = verdict.get('findings') or []
    if not findings:
        raise AssistantError('API_REVIEW_REQUIRED', 'Negative API review needs a quoted claim and scoped evidence, not general suggestions.')
    issues = []
    for finding in findings:
        claim, evidence, reason = (finding.get(k,'') for k in ('claim','evidence','reason'))
        if (not claim.strip() or claim not in response.answer or len(claim)>4000 or not reason.strip() or len(reason)>2000):
            raise AssistantError('API_REVIEW_REQUIRED', 'A review finding must quote an actual bounded claim from the answer.')
        if evidence:
            if not any(evidence == r.get('evidence_id') or citation_matches(evidence,r) for r in records):
                raise AssistantError('API_EVIDENCE_MISMATCH', 'Review finding cites evidence that was not supplied.')
        elif verdict['status'] == 'contradicted':
            raise AssistantError('API_EVIDENCE_MISMATCH', 'Contradictions require a supplied evidence reference.')
        issues.append(reason)
    verdict['issues'] = issues
