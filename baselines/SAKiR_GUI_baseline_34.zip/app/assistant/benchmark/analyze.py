"""Inspect exported Git report bundles without extracting or executing their contents.

python -B -m app.assistant.benchmark.analyze path/to/report.zip [another-report.zip]
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import zipfile


def load_report(path, include_chats=False):
    path = Path(path)
    names = ('manifest.json', 'summary.json', 'cases.json')
    limits = {'manifest.json': 16*1024*1024, 'summary.json': 4*1024*1024, 'cases.json': 256*1024*1024, 'chats.json': 32*1024*1024}
    if path.is_dir():
        if include_chats and (path/'chats.json').exists():
            names += ('chats.json',)
        content = {}
        for name in names:
            item = path/name
            if item.is_symlink() or item.stat().st_size > limits[name]:
                raise ValueError('Report artifact is linked or exceeds analysis size limit: '+name)
            content[name] = item.read_bytes()
    else:
        with zipfile.ZipFile(path) as archive:
            if len(archive.namelist()) != len(set(archive.namelist())):
                raise ValueError('Report has duplicate archive members.')
            if include_chats and 'chats.json' in archive.namelist():
                names += ('chats.json',)
            inventory = {}
            if 'inventory.json' in archive.namelist():
                if archive.getinfo('inventory.json').file_size > 1024*1024:
                    raise ValueError('Inventory exceeds size limit.')
                inventory = json.loads(archive.read('inventory.json'))
            content = {}
            for name in names:
                if archive.getinfo(name).file_size > limits[name]:
                    raise ValueError('Report artifact exceeds analysis size limit: '+name)
                content[name] = archive.read(name)
                if inventory and hashlib.sha256(content[name]).hexdigest() != inventory[name]['sha256']:
                    raise ValueError('Report checksum mismatch: '+name)
    values = {name: json.loads(raw) for name, raw in content.items()}
    if values['manifest.json'].get('schema_version') != 1 or values['summary.json'].get('schema_version') != 1:
        raise ValueError('Unsupported report schema.')
    result = values['manifest.json'], values['summary.json'], values['cases.json']
    return (*result, values.get('chats.json', [])) if include_chats else result


def analyze(path):
    manifest, summary, cases, chats = load_report(path, include_chats=True)
    failures, domains, errors, case_errors = Counter(), defaultdict(list), Counter(), Counter()
    usages = []
    for case in cases:
        if case.get('error_code'):
            case_errors[str(case['error_code'])] += 1
        domains[(case['mode'], case.get('domain', 'unknown'))].append(case)
        for section in ('checks', 'completion_checks', 'host_checks', 'preservation_checks'):
            for key, passed in case.get(section, {}).items():
                if not passed:
                    failures[section+'.'+key] += 1
        for turn in case.get('turns', []):
            usages.extend(turn.get('usage', []))
            if turn.get('error_code'):
                errors[str(turn['error_code'])] += 1
            for error in turn.get('tool_errors', []):
                errors[str(error.get('code', 'unknown'))] += 1
    return {'run_id': manifest['run_id'], 'suite_fingerprint': manifest['suite_fingerprint'],
        'implementation_fingerprint': manifest['implementation_fingerprint'], 'summary': summary,
        'comparison_fingerprints': manifest.get('comparison_fingerprints', {'availability':'not_recorded'}),
        'diagnostics_version': manifest.get('diagnostics_version', 1),
        'failed_checks': dict(failures.most_common()), 'error_codes': dict(errors.most_common()),
        'case_error_codes': dict(case_errors.most_common()),
        'provider_requests': summary.get('provider_requests', {'availability': 'not_recorded'}),
        'trace_status': summary.get('trace_status', {'event_stream': 'unknown',
                                                   'note': 'Legacy trace_complete combines run and capture completion.'}),
        'attached_chats': {'count': len(chats), 'scored': False,
            'snapshots': [{'attachment_id': row.get('attachment_id'), 'title': row.get('title'),
                           'messages': len(row.get('messages', [])), 'user_note': row.get('user_note'),
                           'capture_completeness': row.get('capture_completeness')}
                          for row in chats]},
        'reported_usage': {'responses_with_usage': len(usages),
                           'availability': 'partial' if usages else 'unavailable',
                           'input_tokens': sum(u.get('prompt_tokens', 0) or 0 for u in usages) if usages else None,
                           'output_tokens': sum(u.get('completion_tokens', 0) or 0 for u in usages) if usages else None,
                           'scope': 'Case responses with usage events; excludes preflight. Full preflight usage remains in events.jsonl.'},
        'by_mode_domain': {mode+'/'+domain: {'executed': len(rows), 'passed': sum(bool(r.get('passed')) for r in rows),
            'median_seconds': statistics.median(r.get('seconds', 0) for r in rows)} for (mode, domain), rows in domains.items()},
        'comparison_note': 'Compare matching suite, configuration, case matrix and cache conditions. Build changes must be identified. Partial runs and small samples do not establish general improvement.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reports', type=Path, nargs='+')
    args = parser.parse_args()
    print(json.dumps([analyze(path) for path in args.reports], ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
