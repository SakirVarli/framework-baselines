"""Turn-scoped provenance, separate from the bounded model context. No execution."""
import copy
import json
import uuid

from .policy import AssistantError, digest, redact


class EvidenceRegistry:
    def __init__(self, max_records=4096, metadata_bytes=4*1024**2, payload_bytes=8*1024**2):
        self.scope = uuid.uuid4().hex
        self.max_records, self.max_metadata, self.max_payload = max_records, metadata_bytes, payload_bytes
        self.metadata_bytes = self.payload_bytes = 0
        self.entries, self.payloads = {}, {}

    @staticmethod
    def signature(data):
        return digest({key: value for key, value in data.items() if key not in {'evidence_ref', 'citation'}})

    def register(self, data, kind):
        signature = self.signature(data)
        reference = 'sakir-evidence:'+digest([self.scope, kind, signature])
        if reference in self.entries:
            return reference
        row = {key: copy.deepcopy(data[key]) for key in (
            'path', 'content_revision', 'state', 'section_id', 'line', 'end_line', 'start_line',
            'offset', 'next_offset', 'total_characters', 'fingerprint', 'sample', 'reader_truncated',
            'truncated', 'inspection_options', 'revision_kind', 'task_id', 'task_revision', 'requirement', 'fact',
            'title', 'basis') if key in data}
        if 'start_line' in data and isinstance(data.get('text'), str):
            row['line'] = data['start_line']
            row['end_line'] = row['line']+max(0, len(data['text'].splitlines())-1)
        elif data.get('excerpt') and not data.get('text'):
            row['line'] = data.get('line', 1)
            row['end_line'] = row['line']+max(0, len(data['excerpt'].splitlines())-1)
            row['truncated'] = True
        row.update(id=reference, kind=kind, signature=signature, delivered=False)
        metadata_size = len(json.dumps(row, ensure_ascii=False).encode('utf-8'))
        if len(self.entries) >= self.max_records or self.metadata_bytes+metadata_size > self.max_metadata:
            raise AssistantError('EVIDENCE_LIMIT', 'Evidence provenance budget exhausted; existing references were retained. Narrow the task or start another turn.')
        text = data.get('text') or data.get('excerpt')
        if kind == 'data':
            text = json.dumps(redact(data), ensure_ascii=False)
        if isinstance(text, str) and text:
            body = text[:6000]
            payload_size = len(body.encode('utf-8'))
            if self.payload_bytes+payload_size <= self.max_payload:
                self.payloads[reference] = body
                self.payload_bytes += payload_size
                row['payload_truncated'] = len(text) > len(body)
        self.entries[reference] = row
        self.metadata_bytes += metadata_size
        return reference

    def acknowledge(self, messages):
        """Acknowledge exact host payloads in successful requests, never assistant text."""
        def visit(value):
            if isinstance(value, dict):
                row = self.entries.get(value.get('evidence_ref')) if isinstance(value.get('evidence_ref'), str) else None
                if row and row['signature'] == self.signature(value):
                    row['delivered'] = True
                for child in value.values():
                    if isinstance(child, (dict, list)):
                        visit(child)
            elif isinstance(value, list):
                for child in value:
                    visit(child)
        for message in messages:
            if message.get('role') == 'assistant':
                continue
            content = message.get('content')
            if not isinstance(content, str):
                continue
            positions = [0, content.rfind('\n')+1, *[i for i in (content.find('{'), content.find('[')) if i >= 0]]
            for start in dict.fromkeys(positions):
                try:
                    value = json.loads(content[start:])
                except ValueError:
                    continue
                visit(value)
                break

    def resolve(self, reference, delivered=True):
        row = self.entries.get(reference)
        if row is None or delivered and not row['delivered']:
            raise AssistantError('API_EVIDENCE_MISMATCH', 'Unknown or undelivered evidence reference: '+reference)
        return copy.deepcopy(row)

    def records(self, delivered=True, with_text=False):
        result = []
        for reference, row in self.entries.items():
            if delivered and not row['delivered']:
                continue
            item = copy.deepcopy(row)
            if with_text and reference in self.payloads:
                item['text'] = self.payloads[reference]
                item['truncated'] = item.get('truncated', False) or item.get('payload_truncated', False)
            result.append(item)
        return result
