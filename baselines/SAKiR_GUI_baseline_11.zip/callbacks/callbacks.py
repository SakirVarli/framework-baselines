"""Default application callbacks for the configuration-driven GUI.

The framework imports this module after it has generated ``app.stubs`` from
the current UI and tool configuration.  Runtime APIs including ``display``,
``spawn_input``, ``Tools``, ``GlobalsBase``, ``LifecycleManager``, ``lazy``,
``global_value``, and ``async_global`` are supplied by that generated module.

Configured button callbacks normally use the name
``btn_<sanitized_button_name>_callback``.  Startup hooks run before the UI is
built, then the configured widgets are created, and finally
lazy/async declarations finish, and synchronous ``Globals.init_globals`` runs
in the Qt main thread. Reload and close hooks run for their corresponding
generation transitions. Callback bodies and marked regions may be customized;
the import, Globals base class, and ``init_globals`` signature marked
``DO NOT CHANGE`` are required by the runtime.  Globals survive soft reloads,
so initialization must be safe to run more than once.
"""

from app.branding import FULL_NAME, SHORT_NAME
from app.stubs import *  # DO NOT CHANGE: runtime-generated callback API


def _welcome_html():
    """Build the branded HTML shown by the default welcome output."""
    return f"""
    <div style="margin:36px auto; max-width:820px; padding:44px;
                background:#ffffff; border:1px solid #dbe4f0;
                border-radius:18px; color:#172033; text-align:center;">
      <div style="font-size:13px; font-weight:700; letter-spacing:2px;
                  color:#3f6fd8; text-transform:uppercase;">{FULL_NAME}</div>
      <h1 style="margin:18px 0 10px; font-size:38px; color:#14213d;">
        Welcome to {SHORT_NAME}
      </h1>
      <p style="margin:0 auto; max-width:620px; font-size:17px;
                line-height:1.65; color:#52627a;">
        Your configuration-driven workspace is ready. Review the built-in Help
        first, then use the Config Designer to shape the interface and add
        application behavior in callbacks.py.
      </p>
      <div style="margin-top:30px; padding:16px 20px; background:#eef4ff;
                  border-radius:10px; color:#315aa8; font-size:14px;">
        Start with <b>Help &rarr; Help Contents</b> or press <b>F1</b>.<br><br>
        When ready, open <b>File &rarr; Config Designer...</b>
      </div>
    </div>
    """


# === DEFAULT GLOBALS: edit declarations and initialization body as needed. ===
class Globals(GlobalsBase):  # DO NOT CHANGE: required reload-safe base class
    """Shared reload-safe application state."""

    # --- EDITABLE: class-level values are available before startup hooks. ---
    counter = 0

    def init_globals(self):  # DO NOT CHANGE: called after the UI is built
        """Populate UI-dependent globals in the Qt main thread."""
        # --- EDITABLE: keep this method quick and safe to run after reload. ---
        display("welcome_output", _welcome_html(), mode="replace")


@LifecycleManager.on_startup(priority=0)
def application_starting(window):
    """Perform quick non-UI validation before the configured UI is built."""
    # --- EDITABLE: UI widgets are not available at this lifecycle stage. ---
    pass


@LifecycleManager.on_unload(priority=0)
def application_unloading(window):
    """Release callback-generation wiring before a soft reload."""
    pass


@LifecycleManager.on_reload(priority=0)
def application_reloaded(window):
    """Run after the replacement callback generation becomes initialized."""
    pass


@LifecycleManager.on_close(priority=0)
def application_closing(window=None):
    """Release application-owned resources before the shutdown deadline."""
    # --- EDITABLE: the argument is the main window, not a QCloseEvent. ---
    # Prefer ``async def`` for long non-Qt cleanup so the app remains responsive.
    pass
