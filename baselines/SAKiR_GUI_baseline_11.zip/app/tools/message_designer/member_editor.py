from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .model import new_id
from .routing_editor import HeaderLayersEditor, RouteAssignmentEditor, RouterEditor
from .routing_paths import routing_field_options


DEFAULT_TAG_COLOR = "#5B6ACB"


class _UppercaseHexSpinBox(QtWidgets.QSpinBox):
    def textFromValue(self, value: int) -> str:
        text = super().textFromValue(value)
        return text.upper() if self.displayIntegerBase() == 16 else text


class MessageIdEditor(QtWidgets.QWidget):
    """Integer message-ID editor with a non-persistent hexadecimal view."""

    valueChanged = QtCore.pyqtSignal(int)
    hexToggled = QtCore.pyqtSignal(bool)

    def __init__(self, value: int = 0, *, hexadecimal: bool = False, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.spin = _UppercaseHexSpinBox()
        self.spin.setRange(0, 2**31 - 1)
        self.spin.setValue(int(value))
        self.hex_checkbox = QtWidgets.QCheckBox("Hex")
        self.hex_checkbox.setToolTip(
            "Display and enter the Message ID in hexadecimal; the stored value remains an integer"
        )
        layout.addWidget(self.spin, 1)
        layout.addWidget(self.hex_checkbox)
        self.spin.valueChanged.connect(self.valueChanged)
        self.hex_checkbox.toggled.connect(self._set_hexadecimal)
        self.hex_checkbox.toggled.connect(self.hexToggled)
        self.hex_checkbox.setChecked(bool(hexadecimal))
        self._set_hexadecimal(bool(hexadecimal))

    def value(self) -> int:
        return self.spin.value()

    def setValue(self, value: int) -> None:
        """Retain the former QSpinBox-facing editor API for callers and tests."""
        self.spin.setValue(value)

    def _set_hexadecimal(self, enabled: bool) -> None:
        self.spin.setDisplayIntegerBase(16 if enabled else 10)
        self.spin.setToolTip(
            "Enter a hexadecimal ID such as A0"
            if enabled else "Enter a decimal Message ID such as 160"
        )
        self.spin.selectAll()


class TagAssignmentEditor(QtWidgets.QWidget):
    """Assign catalog tags while allowing new names to be staged as plain text."""

    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self._catalog: list[dict[str, Any]] = []
        self._assigned: list[str] = []
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.tags = QtWidgets.QListWidget(); self.tags.setMaximumHeight(92)
        self.tags.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        self.tags.itemChanged.connect(self._tag_checked)
        layout.addWidget(self.tags)
        row = QtWidgets.QHBoxLayout()
        self.input = QtWidgets.QLineEdit(); self.input.setPlaceholderText("Type a new tag, then press Enter")
        self.remove_button = QtWidgets.QPushButton("Unassign selected")
        row.addWidget(self.input, 1); row.addWidget(self.remove_button); layout.addLayout(row)
        self.input.returnPressed.connect(self._accept_input)
        self.input.textChanged.connect(self._accept_comma)
        self.remove_button.clicked.connect(self._remove_selected)

    def load_tags(self, assigned_uids, catalog):
        self._catalog = copy.deepcopy(catalog)
        valid = {tag.get("uid") for tag in self._catalog}
        self._assigned = [uid for uid in assigned_uids if uid in valid]
        self._refresh()
        completer = QtWidgets.QCompleter([tag.get("name", "") for tag in self._catalog], self)
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        completer.setFilterMode(QtCore.Qt.MatchContains)
        self.input.setCompleter(completer)

    def value(self):
        return list(self._assigned), copy.deepcopy(self._catalog)

    def _accept_comma(self, text):
        if text.endswith(","):
            self.input.setText(text[:-1])
            self._accept_input()

    def _accept_input(self):
        name = self.input.text().strip()
        if not name:
            return
        match = next((tag for tag in self._catalog if tag.get("name", "").casefold() == name.casefold()), None)
        if match is None:
            match = {"uid": new_id(), "name": name, "color": DEFAULT_TAG_COLOR, "description": ""}
            self._catalog.append(match)
        if match["uid"] not in self._assigned:
            self._assigned.append(match["uid"])
            self.changed.emit()
        self.input.clear(); self._refresh()

    def _remove_selected(self):
        item = self.tags.currentItem()
        if item is not None and item.checkState() == QtCore.Qt.Checked:
            item.setCheckState(QtCore.Qt.Unchecked)

    def _tag_checked(self, item):
        uid = item.data(QtCore.Qt.UserRole)
        if not uid:
            return
        changed = False
        if item.checkState() == QtCore.Qt.Checked and uid not in self._assigned:
            self._assigned.append(uid); changed = True
        elif item.checkState() != QtCore.Qt.Checked and uid in self._assigned:
            self._assigned.remove(uid); changed = True
        previous = self.tags.blockSignals(True)
        try:
            font = item.font(); font.setBold(item.checkState() == QtCore.Qt.Checked); item.setFont(font)
        finally:
            self.tags.blockSignals(previous)
        if changed:
            self.changed.emit()

    def _refresh(self):
        previous = self.tags.blockSignals(True)
        try:
            self.tags.clear()
            for tag in self._catalog:
                uid = tag.get("uid")
                item = QtWidgets.QListWidgetItem(tag.get("name", ""))
                item.setData(QtCore.Qt.UserRole, uid)
                item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
                assigned = uid in self._assigned
                item.setCheckState(QtCore.Qt.Checked if assigned else QtCore.Qt.Unchecked)
                font = item.font(); font.setBold(assigned); item.setFont(font)
                color = QtGui.QColor(tag.get("color", DEFAULT_TAG_COLOR))
                if not color.isValid():
                    color = QtGui.QColor(DEFAULT_TAG_COLOR)
                pixmap = QtGui.QPixmap(10, 10); pixmap.fill(color); item.setIcon(QtGui.QIcon(pixmap))
                item.setToolTip(tag.get("description", ""))
                self.tags.addItem(item)
        finally:
            self.tags.blockSignals(previous)


class TagCatalogEditor(QtWidgets.QWidget):
    """Staged editor for the library-wide managed tag catalog."""

    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._uids: list[str] = []
        self._usage: dict[str, int] = {}
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.table = QtWidgets.QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Tag name", "Color", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.table.itemChanged.connect(self._item_changed)
        layout.addWidget(self.table)
        controls = QtWidgets.QHBoxLayout()
        self.add_button = QtWidgets.QPushButton("Add tag")
        self.color_button = QtWidgets.QPushButton("Choose color")
        self.remove_button = QtWidgets.QPushButton("Delete selected tag")
        self.add_button.clicked.connect(self._add_tag)
        self.color_button.clicked.connect(self._choose_color)
        self.remove_button.clicked.connect(self._remove_tag)
        controls.addWidget(self.add_button); controls.addWidget(self.color_button)
        controls.addWidget(self.remove_button); controls.addStretch()
        layout.addLayout(controls)

    def load_tags(self, tags, usage):
        previous = self.table.blockSignals(True)
        try:
            self.table.setRowCount(0); self._uids = []; self._usage = dict(usage)
            for tag in tags:
                self._append(tag)
        finally:
            self.table.blockSignals(previous)

    def value(self):
        result = []
        for row, uid in enumerate(self._uids):
            result.append({
                "uid": uid,
                "name": self.table.item(row, 0).text().strip(),
                "color": self.table.item(row, 1).text().strip(),
                "description": self.table.item(row, 2).text(),
            })
        return result

    def _append(self, tag):
        row = self.table.rowCount(); self.table.insertRow(row); self._uids.append(tag.get("uid", new_id()))
        self.table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(tag.get("name", "New tag"))))
        color_item = QtWidgets.QTableWidgetItem(str(tag.get("color", DEFAULT_TAG_COLOR)))
        self.table.setItem(row, 1, color_item); self._style_color(color_item)
        self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(str(tag.get("description", ""))))

    def _add_tag(self):
        previous = self.table.blockSignals(True)
        try:
            self._append({"uid": new_id(), "name": "New tag", "color": DEFAULT_TAG_COLOR, "description": ""})
        finally:
            self.table.blockSignals(previous)
        self.table.setCurrentCell(self.table.rowCount() - 1, 0); self.changed.emit()

    def _item_changed(self, item):
        if item.column() == 1:
            previous = self.table.blockSignals(True)
            try:
                self._style_color(item)
            finally:
                self.table.blockSignals(previous)
        self.changed.emit()

    def _style_color(self, item):
        color = QtGui.QColor(item.text())
        item.setBackground(QtGui.QBrush(color if color.isValid() else QtGui.QColor("transparent")))
        if color.isValid():
            item.setForeground(QtGui.QBrush(QtCore.Qt.white if color.lightness() < 150 else QtCore.Qt.black))

    def _choose_color(self):
        row = self.table.currentRow()
        if row < 0:
            return
        initial = QtGui.QColor(self.table.item(row, 1).text())
        color = QtWidgets.QColorDialog.getColor(initial if initial.isValid() else QtGui.QColor(DEFAULT_TAG_COLOR), self)
        if color.isValid():
            self.table.item(row, 1).setText(color.name().upper())

    def _remove_tag(self):
        row = self.table.currentRow()
        if row < 0:
            return
        uid = self._uids[row]; count = self._usage.get(uid, 0)
        if count:
            answer = QtWidgets.QMessageBox.question(
                self, "Delete assigned tag",
                f"This tag is assigned to {count} definition{'s' if count != 1 else ''}. "
                "Delete it and remove every assignment?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No,
            )
            if answer != QtWidgets.QMessageBox.Yes:
                return
        previous = self.table.blockSignals(True)
        try:
            self.table.removeRow(row); self._uids.pop(row)
        finally:
            self.table.blockSignals(previous)
        self.changed.emit()


class DefinitionOptionsEditor(QtWidgets.QWidget):
    """Typed editors for enums and non-wire class members."""

    changed = QtCore.pyqtSignal()
    SUPPORTED = {"Library", "Group", "Message", "Enum", "Runtime", "Constant", "Method"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._kind = ""
        self._base: dict[str, Any] = {}
        self._loading = False
        self._widgets: dict[str, QtWidgets.QWidget] = {}
        self._value_uids: list[str] = []
        self._display_name = "custom_method"
        self._message_id_hex = False
        self._manifest: dict[str, Any] = {}
        self._layout = QtWidgets.QFormLayout(self)
        self._layout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)

    def load_definition(self, value: dict[str, Any], kind: str, manifest: dict[str, Any] | None = None) -> None:
        self._loading = True
        self._kind = kind
        self._base = copy.deepcopy(value)
        self._manifest = manifest or {}
        self._clear()
        if kind == "Library":
            self._library_settings(value)
        elif kind == "Group":
            self._line("description", "Description", value)
            parent = QtWidgets.QComboBox(); parent.addItem("Library (root group)", "")
            for item in self._manifest.get("groups", []):
                if item.get("uid") != value.get("uid") and not _group_descends_from(
                    self._manifest.get("groups", []), item, value.get("uid", "")
                ):
                    parent.addItem(item.get("name", "Unnamed"), item.get("uid", ""))
            parent.setCurrentIndex(max(0, parent.findData(value.get("parent_group_uid", ""))))
            self._add("parent_group_uid", "Parent group", parent)
            headers = HeaderLayersEditor(value.get("header_layers", []), self._manifest.get("structures", [])); headers.changed.connect(self._emit_changed)
            self._layout.addRow("Group header layers", headers); self._widgets["header_layers"] = headers
            parent_definition = next((item for item in self._manifest.get("groups", []) if item.get("uid") == value.get("parent_group_uid")), {})
            parent_router = parent_definition.get("message_router") if parent_definition else self._manifest.get("library", {}).get("group_router")
            assignment = RouteAssignmentEditor(
                parent_router, value.get("route_values", {}), value.get("route_signatures", []),
                routing_field_options(self._manifest, parent_definition or None),
            ); assignment.changed.connect(self._emit_changed)
            self._layout.addRow("Group identity", assignment); self._widgets["route_assignment"] = assignment
            router = RouterEditor(value.get("message_router"), routing_field_options(self._manifest, value)); router.changed.connect(self._emit_changed)
            self._layout.addRow("Child routing", router); self._widgets["message_router"] = router
            parent.currentIndexChanged.connect(self._group_parent_changed)
        elif kind == "Message":
            message_id = MessageIdEditor(
                int(value.get("message_id", 0)), hexadecimal=self._message_id_hex
            )
            message_id.hexToggled.connect(self._remember_message_id_base)
            self._add("message_id", "Message ID", message_id)
            group = QtWidgets.QComboBox()
            for item in self._manifest.get("groups", []): group.addItem(item.get("name", "Unnamed"), item.get("uid", ""))
            selected_group = value.get("group_uid") or (self._manifest.get("groups", [{}])[0].get("uid", "") if len(self._manifest.get("groups", [])) == 1 else "")
            group.setCurrentIndex(max(0, group.findData(selected_group))); self._add("group_uid", "Message group", group)
            group_definition = next((item for item in self._manifest.get("groups", []) if item.get("uid") == selected_group), {})
            assignment = RouteAssignmentEditor(
                group_definition.get("message_router"), value.get("identity_values", {}), value.get("identity_signatures", []),
                routing_field_options(self._manifest, group_definition),
            ); assignment.changed.connect(self._emit_changed)
            self._layout.addRow("Message identity", assignment); self._widgets["identity_assignment"] = assignment
            group.currentIndexChanged.connect(self._message_group_changed)
            self._combo("direction", "Direction", ["ANY", "TX", "RX"], {"direction": str(value.get("direction", "ANY")).upper()})
            self._line("display_name", "Registry display name", value)
            behavior = QtWidgets.QLabel(str(value.get("behavior_class", ""))); behavior.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._layout.addRow("Behavior mixin", behavior)
        elif kind == "Enum":
            self._enum_values(value)
        elif kind == "Runtime":
            self._line("annotation", "Type annotation", value)
            self._line("default", "Default expression", value)
            self._check("repr", "Include in repr", value)
        elif kind == "Constant":
            self._line("annotation", "Type annotation", value)
            self._line("value", "Value expression", value)
        elif kind == "Method":
            self._display_name = value.get("name", "custom_method")
            self._combo("kind", "Method kind", ["instance", "class", "static", "async", "property"], value)
            self._signature_label = QtWidgets.QLabel()
            self._signature_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            self._signature_label.setStyleSheet("font-family: Consolas, monospace; padding: 6px;")
            self._layout.addRow("Generated signature", self._signature_label)
            self._widgets["kind"].currentTextChanged.connect(self._update_signature)
            self._update_signature()
        self._loading = False

    def value(self) -> dict[str, Any]:
        result = copy.deepcopy(self._base)
        if self._kind == "Library":
            result["package_name"] = self._widgets["package_name"].text().strip()
            if self._widgets["extractor_enabled"].isChecked():
                mask_text = self._widgets["extractor_mask"].text().strip()
                mask = None if not mask_text or mask_text.lower() == "none" else int(mask_text, 0)
                result["id_extractor"] = {
                    "offset": self._widgets["extractor_offset"].value(),
                    "width": self._widgets["extractor_width"].value(),
                    "byteorder": self._widgets["extractor_byteorder"].currentText(),
                    "mask": mask,
                    "shift": self._widgets["extractor_shift"].value(),
                }
            else:
                result["id_extractor"] = None
            result["header_layers"] = self._widgets["header_layers"].value()
            result["group_router"] = self._widgets["group_router"].value()
            return result
        if self._kind == "Group":
            result["description"] = self._widgets["description"].text()
            result["parent_group_uid"] = self._widgets["parent_group_uid"].currentData() or ""
            result["header_layers"] = self._widgets["header_layers"].value()
            result["route_values"], result["route_signatures"] = self._widgets["route_assignment"].value()
            result["message_router"] = self._widgets["message_router"].value()
            return result
        for key, widget in self._widgets.items():
            if isinstance(widget, QtWidgets.QLineEdit): result[key] = widget.text()
            elif isinstance(widget, QtWidgets.QPlainTextEdit): result[key] = widget.toPlainText()
            elif isinstance(widget, QtWidgets.QCheckBox): result[key] = widget.isChecked()
            elif isinstance(widget, QtWidgets.QComboBox): result[key] = widget.currentText()
            elif isinstance(widget, QtWidgets.QSpinBox): result[key] = widget.value()
            elif isinstance(widget, MessageIdEditor): result[key] = widget.value()
        if self._kind == "Enum": result["values"] = self._read_enum_values()
        elif self._kind == "Message":
            result["group_uid"] = self._widgets["group_uid"].currentData() or ""
            result["identity_values"], result["identity_signatures"] = self._widgets["identity_assignment"].value()
        elif self._kind == "Method":
            result.pop("parameters", None)
            result.pop("return_annotation", None)
            result.pop("docstring", None)
        return result

    def set_display_name(self, name: str) -> None:
        self._display_name = name or "custom_method"
        if self._kind == "Method": self._update_signature()

    def _update_signature(self, *args) -> None:
        kind = self._widgets.get("kind").currentText() if self._widgets.get("kind") else "instance"
        decorators = {"class": "@classmethod\n", "static": "@staticmethod\n", "property": "@property\n"}
        first = "cls" if kind == "class" else ("" if kind == "static" else "self")
        async_prefix = "async " if kind == "async" else ""
        self._signature_label.setText(f"{decorators.get(kind, '')}{async_prefix}def {self._display_name}({first}):")

    def _clear(self):
        while self._layout.rowCount(): self._layout.removeRow(0)
        self._widgets.clear()

    def _emit_changed(self, *args):
        if not self._loading: self.changed.emit()

    def _remember_message_id_base(self, enabled):
        self._message_id_hex = bool(enabled)

    def _message_group_changed(self, *args):
        group_combo = self._widgets.get("group_uid")
        old_editor = self._widgets.get("identity_assignment")
        if group_combo is None or old_editor is None:
            return
        try:
            values, signatures = old_editor.value()
        except (TypeError, ValueError):
            values, signatures = {}, []
        selected = next(
            (item for item in self._manifest.get("groups", []) if item.get("uid") == group_combo.currentData()),
            {},
        )
        editor = RouteAssignmentEditor(
            selected.get("message_router"), values, signatures,
            routing_field_options(self._manifest, selected),
        )
        editor.changed.connect(self._emit_changed)
        row, role = self._layout.getWidgetPosition(old_editor)
        self._layout.removeWidget(old_editor)
        old_editor.deleteLater()
        self._layout.setWidget(row, role, editor)
        self._widgets["identity_assignment"] = editor
        self._emit_changed()

    def _group_parent_changed(self, *args):
        parent_combo = self._widgets.get("parent_group_uid")
        old_editor = self._widgets.get("route_assignment")
        if parent_combo is None or old_editor is None:
            return
        try:
            values, signatures = old_editor.value()
        except (TypeError, ValueError):
            values, signatures = {}, []
        selected = next(
            (item for item in self._manifest.get("groups", []) if item.get("uid") == parent_combo.currentData()),
            {},
        )
        router = selected.get("message_router") if selected else self._manifest.get("library", {}).get("group_router")
        editor = RouteAssignmentEditor(
            router, values, signatures, routing_field_options(self._manifest, selected or None),
        )
        editor.changed.connect(self._emit_changed)
        row, role = self._layout.getWidgetPosition(old_editor)
        self._layout.removeWidget(old_editor); old_editor.deleteLater()
        self._layout.setWidget(row, role, editor)
        self._widgets["route_assignment"] = editor
        old_router = self._widgets.get("message_router")
        if old_router is not None:
            try:
                router_value = old_router.value()
            except (TypeError, ValueError):
                router_value = None
            preview_group = copy.deepcopy(self._base)
            preview_group["parent_group_uid"] = parent_combo.currentData() or ""
            router_editor = RouterEditor(
                router_value, routing_field_options(self._manifest, preview_group),
            )
            router_editor.changed.connect(self._emit_changed)
            router_row, router_role = self._layout.getWidgetPosition(old_router)
            self._layout.removeWidget(old_router); old_router.deleteLater()
            self._layout.setWidget(router_row, router_role, router_editor)
            self._widgets["message_router"] = router_editor
        self._emit_changed()

    def _add(self, key, label, widget):
        self._widgets[key] = widget; self._layout.addRow(label, widget)
        if isinstance(widget, QtWidgets.QLineEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QPlainTextEdit): widget.textChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QCheckBox): widget.toggled.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QComboBox): widget.currentIndexChanged.connect(self._emit_changed)
        elif isinstance(widget, QtWidgets.QSpinBox): widget.valueChanged.connect(self._emit_changed)
        elif isinstance(widget, MessageIdEditor): widget.valueChanged.connect(self._emit_changed)

    def _line(self, key, label, value): self._add(key, label, QtWidgets.QLineEdit(str(value.get(key, ""))))

    def _check(self, key, label, value):
        widget = QtWidgets.QCheckBox(); widget.setChecked(bool(value.get(key, True))); self._add(key, label, widget)

    def _combo(self, key, label, values, value):
        widget = QtWidgets.QComboBox(); widget.addItems(values); widget.setCurrentText(str(value.get(key, values[0]))); self._add(key, label, widget)

    def _library_settings(self, value):
        self._line("package_name", "Python package name", value)
        extractor = value.get("id_extractor") or {}
        enabled = QtWidgets.QCheckBox("Read the message ID from a fixed byte location")
        enabled.setChecked(value.get("id_extractor") is not None)
        self._add("extractor_enabled", "Automatic decode", enabled)

        offset = QtWidgets.QSpinBox(); offset.setRange(0, 2**31 - 1); offset.setValue(int(extractor.get("offset", 0)))
        self._add("extractor_offset", "ID byte offset", offset)
        width = QtWidgets.QSpinBox(); width.setRange(1, 1024); width.setValue(int(extractor.get("width", 1)))
        self._add("extractor_width", "ID width (bytes)", width)
        byteorder = QtWidgets.QComboBox(); byteorder.addItems(["big", "little"]); byteorder.setCurrentText(extractor.get("byteorder", "big"))
        self._add("extractor_byteorder", "ID byte order", byteorder)
        mask = extractor.get("mask")
        mask_edit = QtWidgets.QLineEdit("" if mask is None else hex(mask)); mask_edit.setPlaceholderText("Optional, for example 0xF0")
        self._add("extractor_mask", "Bit mask", mask_edit)
        shift = QtWidgets.QSpinBox(); shift.setRange(0, 2**31 - 1); shift.setValue(int(extractor.get("shift", 0)))
        self._add("extractor_shift", "Right shift", shift)
        enabled.toggled.connect(self._update_extractor_enabled)
        self._update_extractor_enabled()
        headers = HeaderLayersEditor(value.get("header_layers", []), self._manifest.get("structures", [])); headers.changed.connect(self._emit_changed)
        self._layout.addRow("Common header layers", headers); self._widgets["header_layers"] = headers
        router = RouterEditor(value.get("group_router"), routing_field_options(self._manifest)); router.changed.connect(self._emit_changed)
        self._layout.addRow("Group routing", router); self._widgets["group_router"] = router

    def _update_extractor_enabled(self, *args):
        enabled = self._widgets.get("extractor_enabled")
        active = enabled.isChecked() if enabled else False
        for key in ("extractor_offset", "extractor_width", "extractor_byteorder", "extractor_mask", "extractor_shift"):
            if key in self._widgets: self._widgets[key].setEnabled(active)

    def _table_controls(self, table, add_text, add_callback, remove_callback):
        controls = QtWidgets.QWidget(); layout = QtWidgets.QHBoxLayout(controls); layout.setContentsMargins(0, 0, 0, 0)
        add = QtWidgets.QPushButton(add_text); remove = QtWidgets.QPushButton("Remove selected")
        add.clicked.connect(add_callback); remove.clicked.connect(remove_callback)
        layout.addWidget(add); layout.addWidget(remove); layout.addStretch(); return controls

    def _enum_values(self, value):
        table = QtWidgets.QTableWidget(0, 2); table.setHorizontalHeaderLabels(["Member name", "Integer value"])
        table.horizontalHeader().setStretchLastSection(True); self._value_uids = []
        for member in value.get("values", []): self._append_enum_value(table, member)
        controls = self._table_controls(
            table, "Add enum value",
            lambda: self._add_enum_value(table),
            lambda: self._remove_row(table, self._value_uids),
        )
        table.itemChanged.connect(self._emit_changed)
        self._layout.addRow("Enum values", table); self._layout.addRow("", controls); self._widgets["_enum_values"] = table

    def _append_enum_value(self, table, member):
        previous = table.blockSignals(True)
        try:
            row = table.rowCount(); table.insertRow(row); self._value_uids.append(member.get("uid", new_id()))
            table.setItem(row, 0, QtWidgets.QTableWidgetItem(str(member.get("name", "VALUE"))))
            table.setItem(row, 1, QtWidgets.QTableWidgetItem(str(member.get("value", 0))))
        finally:
            table.blockSignals(previous)

    def _add_enum_value(self, table):
        self._append_enum_value(table, {"uid": new_id(), "name": "VALUE", "value": 0})
        self.changed.emit()

    def _read_enum_values(self):
        table = self._widgets["_enum_values"]; result = []
        for row in range(table.rowCount()):
            text = table.item(row, 1).text().strip()
            try: number = int(text, 0)
            except ValueError: number = text
            result.append({"uid": self._value_uids[row], "name": table.item(row, 0).text(), "value": number})
        return result

    def _remove_row(self, table, uid_list):
        row = table.currentRow()
        if row >= 0:
            previous = table.blockSignals(True)
            try:
                table.removeRow(row); uid_list.pop(row)
            finally:
                table.blockSignals(previous)
            self.changed.emit()


def _group_descends_from(groups, candidate, ancestor_uid):
    by_uid = {item.get("uid"): item for item in groups}
    seen = set(); current = candidate
    while current and current.get("uid") not in seen:
        uid = current.get("uid")
        if uid == ancestor_uid:
            return True
        seen.add(uid)
        current = by_uid.get(current.get("parent_group_uid"))
    return False
