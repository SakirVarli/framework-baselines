from __future__ import annotations

import copy
from typing import Any

from .wire_size import WireSizeAnalyzer


class RoutingPathError(ValueError):
    pass


class RoutingMatchError(ValueError):
    pass


def routing_field_options(manifest: dict[str, Any], group: dict[str, Any] | None = None):
    structures = {item.get("uid"): item for item in manifest.get("structures", [])}
    enums = manifest.get("enums", [])
    layers = [*manifest.get("library", {}).get("header_layers", [])]
    if group is not None:
        for ancestor in _group_chain(manifest, group):
            layers.extend(ancestor.get("header_layers", []))
    result = []; base_offset = 0
    analyzer = WireSizeAnalyzer(manifest)
    for layer in layers:
        structure = structures.get(layer.get("struct_uid"))
        if structure:
            result.extend(_structure_paths(layer.get("attribute_name", "header"), structure, structures, enums, base_offset))
            size = analyzer.definition(structure)
            if size.status != "exact": break
            base_offset += int(size.bytes)
    return result


def resolve_routing_component(component, manifest, group=None):
    if component.get("source", "raw") == "raw":
        return copy.deepcopy(component)
    path = str(component.get("field_path", "")).strip()
    options = {item["path"]: item for item in routing_field_options(manifest, group)}
    if path not in options:
        raise RoutingPathError(f"Routing field '{path}' is missing or is not statically locatable")
    resolved = copy.deepcopy(component); selected = options[path]
    resolved.update({
        "offset": selected["offset"], "width": selected["width"],
        "byteorder": selected["byteorder"], "mask": selected.get("mask"),
        "shift": selected.get("shift", 0),
    })
    return resolved


def identify_manifest_route(manifest, data):
    groups = manifest.get("groups", [])
    if not groups:
        raise RoutingMatchError("The library has no message groups")
    roots = [group for group in groups if not group.get("parent_group_uid")]
    router = manifest.get("library", {}).get("group_router")
    group_matches = _matches(roots, router, "group", manifest, data, None) if router else [(roots[0], {})] if len(roots) == 1 else []
    if len(group_matches) != 1:
        raise RoutingMatchError("No unique message group matched" if not group_matches else "Multiple message groups matched")
    group, group_values = group_matches[0]
    path = [group]; value_path = [group_values]; combined = dict(group_values)
    while True:
        child_groups = [item for item in groups if item.get("parent_group_uid") == group.get("uid")]
        messages = [message for message in manifest.get("messages", []) if message.get("group_uid") == group.get("uid")]
        child_matches = _matches(child_groups, group.get("message_router"), "group", manifest, data, group)
        message_matches = _matches(messages, group.get("message_router"), "message", manifest, data, group)
        if len(child_matches) + len(message_matches) != 1:
            raise RoutingMatchError("No unique child matched in " + group.get("name", "group"))
        if message_matches:
            message, message_values = message_matches[0]
            return {
                "group": group, "group_path": path, "message": message,
                "group_values": combined, "group_value_path": value_path,
                "message_values": message_values,
            }
        group, values = child_matches[0]
        path.append(group); value_path.append(values); combined.update(values)


def _matches(candidates, router, level, manifest, data, group):
    if not router: return []
    result = []
    for candidate in candidates:
        if router.get("mode") == "shared":
            expected = candidate.get("route_values" if level == "group" else "identity_values", {})
            probes = []
            for component in router.get("components", []):
                probe = copy.deepcopy(component); probe["expected"] = expected.get(component.get("name"), -1); probes.append(probe)
            signatures = [{"probes": probes}]
        else:
            signatures = candidate.get("route_signatures" if level == "group" else "identity_signatures", [])
        for signature in signatures:
            values = {}; matched = True
            for raw_probe in signature.get("probes", []):
                probe = resolve_routing_component(raw_probe, manifest, group)
                end = int(probe.get("offset", 0)) + int(probe.get("width", 1))
                if len(data) < end: matched = False; break
                value = int.from_bytes(data[int(probe.get("offset", 0)):end], probe.get("byteorder", "big"))
                if probe.get("mask") is not None: value &= int(probe["mask"])
                value >>= int(probe.get("shift", 0)); values[probe.get("name", "id")] = value
                if value != int(probe.get("expected", -1)): matched = False
            if matched: result.append((candidate, values)); break
    return result


def _structure_paths(prefix, structure, structures, enums, base_offset=0):
    analyzer = WireSizeAnalyzer({"structures": list(structures.values()), "enums": enums})
    result, offset = [], base_offset
    for field in structure.get("fields", []):
        kind = field.get("kind")
        path = f"{prefix}.{field.get('name', 'field')}"
        if kind == "struct" and field.get("struct_uid") in structures:
            result.extend(_structure_paths(path, structures[field["struct_uid"]], structures, enums, offset))
        else:
            descriptor = _routing_descriptor(field)
            if descriptor is not None:
                result.append({"path": path, "offset": offset, **descriptor})
        size = analyzer.field(field)
        if size.status != "exact":
            break
        offset += int(size.bytes)
    return result


def _routing_descriptor(field):
    kind = field.get("kind")
    if kind in {"uint", "enum"}:
        return {"width": int(field.get("width", 1)), "byteorder": field.get("endian", "big"), "mask": None, "shift": 0}
    if kind == "bytes_integer" and not field.get("signed"):
        return {"width": int(field.get("length", 1)), "byteorder": field.get("endian", "big"), "mask": None, "shift": 0}
    if kind == "bool":
        return {"width": 1, "byteorder": "big", "mask": None, "shift": 0}
    if kind in {"const", "default", "rebuild"} and isinstance(field.get("item"), dict):
        return _routing_descriptor(field["item"])
    return None


def _group_chain(manifest, group):
    by_uid = {item.get("uid"): item for item in manifest.get("groups", [])}
    chain = []; seen = set(); current = group
    while current and current.get("uid") not in seen:
        seen.add(current.get("uid")); chain.append(current)
        current = by_uid.get(current.get("parent_group_uid"))
    return list(reversed(chain))
