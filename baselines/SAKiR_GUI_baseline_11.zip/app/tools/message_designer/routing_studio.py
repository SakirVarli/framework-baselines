from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtWidgets

from .routing_editor import RouteAssignmentEditor, RouterEditor
from .routing_paths import routing_field_options


class RoutingHierarchyTree(QtWidgets.QTreeWidget):
    reparentRequested = QtCore.pyqtSignal(str, str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderHidden(True)
        self.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
        self.setDefaultDropAction(QtCore.Qt.MoveAction)

    def dropEvent(self, event):
        item = self.currentItem()
        if item is None:
            return
        uid = item.data(0, QtCore.Qt.UserRole) or ""
        kind = item.data(0, QtCore.Qt.UserRole + 1) or ""
        super().dropEvent(event)
        parent = item.parent()
        parent_kind = parent.data(0, QtCore.Qt.UserRole + 1) if parent else ""
        parent_uid = parent.data(0, QtCore.Qt.UserRole) if parent else ""
        valid = (kind == "Group" and parent_kind in {"Library", "Group"}) or (kind == "Message" and parent_kind == "Group")
        cursor = parent
        while valid and cursor is not None:
            if cursor is item: valid = False
            cursor = cursor.parent()
        self.reparentRequested.emit(str(uid), str(parent_uid or ""), str(kind if valid else ""))


class RoutingStudio(QtWidgets.QWidget):
    """Central guided/expert editor for recursive automatic routing."""

    manifestApplied = QtCore.pyqtSignal(object, str)
    addGroupRequested = QtCore.pyqtSignal(str)
    addMessageRequested = QtCore.pyqtSignal(str)
    reparentRequested = QtCore.pyqtSignal(str, str, str)
    openDefinitionRequested = QtCore.pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._manifest: dict[str, Any] = {}; self._owner_uid = ""; self._candidate_uid = ""
        self._loading = False; self._shape = None; self._assignment_editors = {}
        outer = QtWidgets.QVBoxLayout(self)
        top = QtWidgets.QHBoxLayout(); title = QtWidgets.QLabel("Automatic message routing")
        title.setStyleSheet("font-size: 16px; font-weight: 600;"); top.addWidget(title); top.addStretch()
        top.addWidget(QtWidgets.QLabel("View")); self.view_mode = QtWidgets.QComboBox(); self.view_mode.addItems(["Guided", "Expert"]); top.addWidget(self.view_mode)
        outer.addLayout(top)
        splitter = QtWidgets.QSplitter(); splitter.setChildrenCollapsible(False); outer.addWidget(splitter, 1)
        left = QtWidgets.QWidget(); left_layout = QtWidgets.QVBoxLayout(left); left_layout.setContentsMargins(0, 0, 0, 0)
        self.search = QtWidgets.QLineEdit(); self.search.setPlaceholderText("Search routing hierarchy…"); self.search.setClearButtonEnabled(True); left_layout.addWidget(self.search)
        self.tree = RoutingHierarchyTree(); left_layout.addWidget(self.tree, 1)
        actions = QtWidgets.QHBoxLayout(); self.add_group = QtWidgets.QPushButton("Add group"); self.add_message = QtWidgets.QPushButton("Add message")
        actions.addWidget(self.add_group); actions.addWidget(self.add_message); left_layout.addLayout(actions); splitter.addWidget(left)
        right = QtWidgets.QScrollArea(); right.setWidgetResizable(True)
        self.inspector = QtWidgets.QWidget(); self.form = QtWidgets.QVBoxLayout(self.inspector); self.form.setAlignment(QtCore.Qt.AlignTop); right.setWidget(self.inspector); splitter.addWidget(right); splitter.setSizes([310, 850])
        self.heading = QtWidgets.QLabel(); self.heading.setStyleSheet("font-size: 15px; font-weight: 600;")
        self.path = QtWidgets.QLabel(); self.path.setWordWrap(True); self.path.setStyleSheet("color: palette(mid);")
        self.summary = QtWidgets.QLabel(); self.summary.setWordWrap(True)
        self.summary.setStyleSheet("padding: 8px; border-radius: 4px; background: rgba(128,128,128,0.10);")
        self.form.addWidget(self.heading); self.form.addWidget(self.path); self.form.addWidget(self.summary)
        self.header_group = QtWidgets.QGroupBox("Effective inherited headers"); header_layout = QtWidgets.QVBoxLayout(self.header_group)
        self.headers = QtWidgets.QTableWidget(0, 3); self.headers.setHorizontalHeaderLabels(["Attribute", "Structure", "Defined by"])
        self.headers.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch); self.headers.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        header_layout.addWidget(self.headers); self.form.addWidget(self.header_group)
        self.router_group = QtWidgets.QGroupBox("How this level identifies its immediate children"); self.router_layout = QtWidgets.QVBoxLayout(self.router_group); self.form.addWidget(self.router_group)
        self.identity_group = QtWidgets.QGroupBox("Immediate child identities"); self.identity_layout = QtWidgets.QVBoxLayout(self.identity_group); self.form.addWidget(self.identity_group)
        footer = QtWidgets.QHBoxLayout(); self.state = QtWidgets.QLabel("No unapplied routing changes.")
        self.open_definition = QtWidgets.QPushButton("Open in Definitions"); self.revert = QtWidgets.QPushButton("Revert"); self.apply = QtWidgets.QPushButton("Apply routing"); self.apply.setEnabled(False)
        footer.addWidget(self.state, 1); footer.addWidget(self.open_definition); footer.addWidget(self.revert); footer.addWidget(self.apply); self.form.addLayout(footer)
        self.tree.currentItemChanged.connect(self._selection_changed); self.tree.reparentRequested.connect(self.reparentRequested)
        self.search.textChanged.connect(self._filter_tree); self.view_mode.currentTextChanged.connect(self._apply_view_mode)
        self.add_group.clicked.connect(self._request_group); self.add_message.clicked.connect(self._request_message)
        self.open_definition.clicked.connect(self._open_definition); self.revert.clicked.connect(self._rebuild_editor); self.apply.clicked.connect(self._apply)

    def refresh(self, manifest, selected_uid=""):
        previous = selected_uid or self._candidate_uid or self._owner_uid; self._manifest = copy.deepcopy(manifest); self._loading = True
        try: self._build_tree(previous)
        finally: self._loading = False
        self._selection_changed(self.tree.currentItem(), None)

    def _build_tree(self, selected_uid):
        self.tree.clear(); library = self._manifest.get("library", {})
        root = self._item(library.get("display_name") or library.get("package_name", "Library"), library.get("uid", ""), "Library"); self.tree.addTopLevelItem(root)
        for group in self._manifest.get("groups", []):
            if not group.get("parent_group_uid"): self._append_group(root, group)
        root.setExpanded(True); target = self._find_item(selected_uid) or root; cursor = target.parent()
        while cursor is not None: cursor.setExpanded(True); cursor = cursor.parent()
        self.tree.setCurrentItem(target)

    def _append_group(self, parent, group):
        item = self._item(group.get("name", "Group"), group.get("uid", ""), "Group"); parent.addChild(item)
        for child in self._manifest.get("groups", []):
            if child.get("parent_group_uid") == group.get("uid"): self._append_group(item, child)
        for message in self._manifest.get("messages", []):
            if message.get("group_uid") == group.get("uid"):
                item.addChild(self._item(f"{message.get('name', 'Message')}  ·  {str(message.get('direction', 'ANY')).upper()}", message.get("uid", ""), "Message"))

    @staticmethod
    def _item(text, uid, kind):
        item = QtWidgets.QTreeWidgetItem([text]); item.setData(0, QtCore.Qt.UserRole, uid); item.setData(0, QtCore.Qt.UserRole + 1, kind)
        if kind in {"Library", "Group"}: item.setFlags(item.flags() | QtCore.Qt.ItemIsDropEnabled)
        if kind == "Library": item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDragEnabled)
        if kind == "Message": item.setFlags(item.flags() & ~QtCore.Qt.ItemIsDropEnabled)
        return item

    def _find_item(self, uid):
        iterator = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            if iterator.value().data(0, QtCore.Qt.UserRole) == uid: return iterator.value()
            iterator += 1
        return None

    def _selection_changed(self, current, previous):
        if current is None or not self._manifest: return
        kind = current.data(0, QtCore.Qt.UserRole + 1); uid = current.data(0, QtCore.Qt.UserRole) or ""; self._candidate_uid = uid if kind == "Message" else ""
        if kind == "Message":
            message = self._object(uid); self._owner_uid = message.get("group_uid", "") if message else ""
        else: self._owner_uid = uid
        self._rebuild_editor()

    def _rebuild_editor(self):
        if not self._manifest: return
        self._loading = True
        try:
            self._clear_layout(self.router_layout); self._clear_layout(self.identity_layout); owner, kind = self._owner()
            if not owner: return
            selected_message = self._object(self._candidate_uid) if self._candidate_uid else None
            if selected_message:
                self.heading.setText(f"{selected_message.get('name', 'Message')} identity")
                self.summary.setText(
                    f"This message is one immediate child of {owner.get('name', 'Group')}. "
                    "Its row below defines the wire values that select it."
                )
            elif kind == "Library":
                self.heading.setText("Library root routing")
                self.summary.setText(
                    "Read one or more values from the wire, then use them to choose one top-level group."
                )
            else:
                self.heading.setText(f"{owner.get('name', 'Group')} child routing")
                self.summary.setText(
                    "After this group's inherited headers are known, read one or more values and choose "
                    "one immediate child group or message."
                )
            display_path = self._owner_path(owner, kind)
            if selected_message:
                display_path.append(selected_message.get("name", "Message"))
            self.path.setText("Route level: " + " → ".join(display_path)); self._populate_headers(owner, kind)
            router = owner.get("group_router") if kind == "Library" else owner.get("message_router"); fields = routing_field_options(self._manifest, None if kind == "Library" else owner)
            self.router_editor = RouterEditor(router, fields); self.router_editor.changed.connect(self._router_changed); self.router_layout.addWidget(self.router_editor)
            self._shape = self._router_shape(router); self._build_identities(router, owner, kind, fields); self._apply_view_mode(); self._set_pending(False)
        finally: self._loading = False

    def _build_identities(self, router, owner, kind, fields):
        candidates = self._children(owner, kind); self._assignment_editors = {}
        if not router:
            label = QtWidgets.QLabel("Automatic routing is off. Use a concrete message class or numeric lookup."); label.setWordWrap(True); self.identity_layout.addWidget(label); return
        if router.get("mode") == "shared":
            components = router.get("components", []); table = QtWidgets.QTableWidget(len(candidates), 3 + len(components))
            table.setHorizontalHeaderLabels(["Child", "Kind", "Direction", *[item.get("name", "component") for item in components]]); self.identity_table = table
            for row, (candidate, candidate_kind) in enumerate(candidates):
                name = QtWidgets.QTableWidgetItem(candidate.get("name", "Unnamed")); name.setData(QtCore.Qt.UserRole, candidate.get("uid", "")); name.setFlags(name.flags() & ~QtCore.Qt.ItemIsEditable)
                kind_item = QtWidgets.QTableWidgetItem(candidate_kind); kind_item.setFlags(kind_item.flags() & ~QtCore.Qt.ItemIsEditable)
                direction = QtWidgets.QTableWidgetItem("—" if candidate_kind == "Group" else str(candidate.get("direction", "ANY")).upper()); direction.setFlags(direction.flags() & ~QtCore.Qt.ItemIsEditable)
                table.setItem(row, 0, name); table.setItem(row, 1, kind_item); table.setItem(row, 2, direction)
                values = candidate.get("route_values" if candidate_kind == "Group" else "identity_values", {})
                for column, component in enumerate(components, 3): table.setItem(row, column, QtWidgets.QTableWidgetItem(hex(int(values.get(component.get("name"), 0)))))
                if candidate.get("uid") == self._candidate_uid:
                    table.selectRow(row)
            table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch); table.itemChanged.connect(self._edited); self.identity_layout.addWidget(table)
        else:
            if not candidates: self.identity_layout.addWidget(QtWidgets.QLabel("This group has no immediate children.")); return
            for candidate, candidate_kind in candidates:
                title = candidate.get("name", "Unnamed") + (" — group" if candidate_kind == "Group" else f" — {str(candidate.get('direction', 'ANY')).upper()}")
                box = QtWidgets.QGroupBox(title); layout = QtWidgets.QVBoxLayout(box)
                editor = RouteAssignmentEditor(router, candidate.get("route_values" if candidate_kind == "Group" else "identity_values", {}), candidate.get("route_signatures" if candidate_kind == "Group" else "identity_signatures", []), fields)
                editor.changed.connect(self._edited); layout.addWidget(editor); self._assignment_editors[candidate.get("uid", "")] = editor; self.identity_layout.addWidget(box)

    def _router_changed(self):
        if self._loading: return
        try: router = self.router_editor.value()
        except (TypeError, ValueError): self._set_pending(True); return
        shape = self._router_shape(router)
        if shape != self._shape:
            self._shape = shape; owner, kind = self._owner(); self._clear_layout(self.identity_layout)
            self._build_identities(router, owner, kind, routing_field_options(self._manifest, None if kind == "Library" else owner)); self._apply_view_mode()
        self._set_pending(True)

    @staticmethod
    def _router_shape(router):
        return None if not router else (router.get("mode"), tuple(item.get("name") for item in router.get("components", [])))

    def _apply(self):
        try:
            after = copy.deepcopy(self._manifest); owner, kind = self._owner(after); router = self.router_editor.value()
            if kind == "Library": owner["group_router"] = router
            else: owner["message_router"] = router
            candidates = self._children(owner, kind, after)
            if router and router.get("mode") == "shared":
                components = router.get("components", []); rows = {self.identity_table.item(row, 0).data(QtCore.Qt.UserRole): row for row in range(self.identity_table.rowCount())}
                for candidate, candidate_kind in candidates:
                    row = rows[candidate.get("uid")]; values = {component.get("name"): int(self.identity_table.item(row, column).text().strip(), 0) for column, component in enumerate(components, 3)}
                    candidate["route_values" if candidate_kind == "Group" else "identity_values"] = values; candidate["route_signatures" if candidate_kind == "Group" else "identity_signatures"] = []
            elif router:
                for candidate, candidate_kind in candidates:
                    values, signatures = self._assignment_editors[candidate.get("uid", "")].value(); candidate["route_values" if candidate_kind == "Group" else "identity_values"] = values; candidate["route_signatures" if candidate_kind == "Group" else "identity_signatures"] = signatures
        except (KeyError, TypeError, ValueError, AttributeError) as error:
            QtWidgets.QMessageBox.warning(self, "Invalid routing values", str(error)); return
        self.manifestApplied.emit(after, "Edit routing")

    def _owner(self, manifest=None):
        data = manifest or self._manifest; library = data.get("library", {})
        if self._owner_uid == library.get("uid"): return library, "Library"
        return next((item for item in data.get("groups", []) if item.get("uid") == self._owner_uid), None), "Group"

    def _children(self, owner, kind, manifest=None):
        data = manifest or self._manifest
        if kind == "Library": return [(item, "Group") for item in data.get("groups", []) if not item.get("parent_group_uid")]
        uid = owner.get("uid", ""); groups = [(item, "Group") for item in data.get("groups", []) if item.get("parent_group_uid") == uid]
        return [*groups, *[(item, "Message") for item in data.get("messages", []) if item.get("group_uid") == uid]]

    def _owner_path(self, owner, kind):
        if kind == "Library": return ["Library"]
        by_uid = {item.get("uid"): item for item in self._manifest.get("groups", [])}; result = []; seen = set(); current = owner
        while current and current.get("uid") not in seen: seen.add(current.get("uid")); result.append(current.get("name", "Group")); current = by_uid.get(current.get("parent_group_uid"))
        return ["Library", *reversed(result)]

    def _populate_headers(self, owner, kind):
        layers = [(layer, "Library") for layer in self._manifest.get("library", {}).get("header_layers", [])]
        if kind == "Group":
            by_uid = {item.get("uid"): item for item in self._manifest.get("groups", [])}; chain = []; current = owner; seen = set()
            while current and current.get("uid") not in seen: seen.add(current.get("uid")); chain.append(current); current = by_uid.get(current.get("parent_group_uid"))
            for group in reversed(chain): layers.extend((layer, group.get("name", "Group")) for layer in group.get("header_layers", []))
        structures = {item.get("uid"): item.get("name", "Missing") for item in self._manifest.get("structures", [])}; self.headers.setRowCount(len(layers))
        for row, (layer, source) in enumerate(layers):
            self.headers.setItem(row, 0, QtWidgets.QTableWidgetItem(layer.get("attribute_name", "header"))); self.headers.setItem(row, 1, QtWidgets.QTableWidgetItem(structures.get(layer.get("struct_uid"), "Missing"))); self.headers.setItem(row, 2, QtWidgets.QTableWidgetItem(source))
        self.header_group.setVisible(bool(layers))

    def _apply_view_mode(self):
        expert = self.view_mode.currentText() == "Expert"
        if hasattr(self, "router_editor"):
            for column in (6, 7): self.router_editor.table.setColumnHidden(column, not expert)
        for editor in self._assignment_editors.values():
            if editor.table.columnCount() >= 10:
                for column in (7, 8): editor.table.setColumnHidden(column, not expert)

    def _filter_tree(self, text):
        terms = str(text).casefold().split()
        def visit(item):
            child_visible = any(visit(item.child(index)) for index in range(item.childCount())); own = all(term in item.text(0).casefold() for term in terms); visible = not terms or own or child_visible; item.setHidden(not visible)
            if terms and child_visible: item.setExpanded(True)
            return visible
        for index in range(self.tree.topLevelItemCount()): visit(self.tree.topLevelItem(index))

    def _request_group(self):
        item = self.tree.currentItem(); kind = item.data(0, QtCore.Qt.UserRole + 1) if item else ""; parent_uid = item.data(0, QtCore.Qt.UserRole) if kind == "Group" else ""; self.addGroupRequested.emit(str(parent_uid or ""))

    def _request_message(self):
        item = self.tree.currentItem(); kind = item.data(0, QtCore.Qt.UserRole + 1) if item else ""; uid = item.data(0, QtCore.Qt.UserRole) if item else ""
        if kind == "Message": message = self._object(uid); uid = message.get("group_uid", "") if message else ""
        if kind not in {"Group", "Message"}:
            roots = [group for group in self._manifest.get("groups", []) if not group.get("parent_group_uid")]; uid = roots[0].get("uid", "") if roots else ""
        self.addMessageRequested.emit(str(uid or ""))

    def _open_definition(self): self.openDefinitionRequested.emit(self._candidate_uid or self._owner_uid)

    def _object(self, uid):
        for key in ("groups", "messages"):
            found = next((item for item in self._manifest.get(key, []) if item.get("uid") == uid), None)
            if found: return found
        return None

    def _edited(self, *args):
        if not self._loading: self._set_pending(True)

    def _set_pending(self, pending):
        self.apply.setEnabled(bool(pending)); self.revert.setEnabled(bool(pending)); self.state.setText("Routing changes are not applied." if pending else "No unapplied routing changes."); self.state.setStyleSheet("color: #b54708; font-weight: 600;" if pending else "color: #287d3c;")

    @staticmethod
    def _clear_layout(layout):
        while layout.count():
            item = layout.takeAt(0); widget = item.widget()
            if widget is not None: widget.deleteLater()
