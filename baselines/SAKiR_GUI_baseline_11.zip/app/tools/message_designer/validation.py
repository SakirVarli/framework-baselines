from __future__ import annotations

import ast
import keyword
import re
from dataclasses import dataclass
from typing import Any

from .model import FORMAT_NAME, PACKAGE_RE, SCHEMA_VERSION, walk_fields
from .object_defaults import guided_errors, guided_supported
from .routing_paths import RoutingPathError, resolve_routing_component


RESERVED_MEMBERS = {
    "WIRE_SCHEMA", "MESSAGE_ID", "MESSAGE_NAME", "codec", "decode", "encode",
    "from_bytes", "to_bytes", "send",
}
FIELD_KINDS = {
    "uint", "int", "bytes_integer", "varint", "zigzag", "float", "bool",
    "enum", "bytes", "string", "bitfield", "array", "struct", "inline_struct", "conditional",
    "switch", "const", "default", "padding", "aligned", "computed", "rebuild",
    "checksum", "advanced",
}


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    severity: str
    code: str
    message: str
    uid: str = ""

    @property
    def blocking(self) -> bool:
        return self.severity == "error"


def _identifier(value: Any) -> bool:
    return isinstance(value, str) and value.isidentifier() and not keyword.iskeyword(value)


def _parse_expression(expression: Any) -> bool:
    if not isinstance(expression, str) or not expression.strip():
        return False
    try:
        ast.parse(expression, mode="eval")
        return True
    except SyntaxError:
        return False


def validate_manifest(data: dict[str, Any]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    if data.get("format") != FORMAT_NAME:
        issues.append(ValidationIssue("error", "format", "Not a SAKiR message-library manifest."))
    if data.get("schema_version") != SCHEMA_VERSION:
        issues.append(ValidationIssue("error", "version", f"Unsupported manifest version: {data.get('schema_version')}"))

    library = data.get("library", {})
    package_name = library.get("package_name", "")
    if not PACKAGE_RE.fullmatch(str(package_name)):
        issues.append(ValidationIssue("error", "package-name", "Package name must be a Python identifier.", library.get("uid", "")))
    for statement in library.get("extra_imports", []):
        try:
            parsed = ast.parse(statement)
            if len(parsed.body) != 1 or not isinstance(parsed.body[0], (ast.Import, ast.ImportFrom)):
                raise SyntaxError
        except (SyntaxError, TypeError):
            issues.append(ValidationIssue("error", "extra-import", f"Invalid import statement: {statement!r}.", library.get("uid", "")))

    all_uids: set[str] = set()
    for category in ("enums", "structures", "groups", "messages"):
        for item in data.get(category, []):
            uid = item.get("uid", "")
            if not uid or uid in all_uids:
                issues.append(ValidationIssue("error", "duplicate-uid", "Every definition needs a unique stable ID.", uid))
            all_uids.add(uid)

    tag_uids: set[str] = set()
    tag_names: set[str] = set()
    tag_issue_uid = library.get("uid", "")
    for tag in data.get("tags", []):
        uid = tag.get("uid", "")
        name = tag.get("name", "")
        color = tag.get("color", "")
        if not uid or uid in all_uids or uid in tag_uids:
            issues.append(ValidationIssue("error", "tag-uid", "Every tag needs a unique stable ID.", tag_issue_uid))
        tag_uids.add(uid)
        normalized_name = name.strip().casefold() if isinstance(name, str) else ""
        if not isinstance(name, str) or name != name.strip() or not (1 <= len(name) <= 64) or "," in name or "\n" in name or "\r" in name:
            issues.append(ValidationIssue("error", "tag-name", "Tag names must be trimmed, 1–64 characters, and cannot contain commas or newlines.", tag_issue_uid))
        elif normalized_name in tag_names:
            issues.append(ValidationIssue("error", "tag-name", f"Duplicate tag name '{name}'.", tag_issue_uid))
        tag_names.add(normalized_name)
        if not isinstance(color, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
            issues.append(ValidationIssue("error", "tag-color", f"Tag color for '{name}' must use #RRGGBB.", tag_issue_uid))
        if not isinstance(tag.get("description", ""), str):
            issues.append(ValidationIssue("error", "tag-description", f"Tag description for '{name}' must be text.", tag_issue_uid))

    for definition in [*data.get("enums", []), *data.get("structures", []), *data.get("groups", []), *data.get("messages", [])]:
        assigned = definition.get("tag_uids", [])
        if not isinstance(assigned, list) or len(assigned) != len(set(assigned)):
            issues.append(ValidationIssue("error", "tag-assignment", "Tag assignments must be a unique ordered list.", definition.get("uid", "")))
            continue
        for tag_uid in assigned:
            if tag_uid not in tag_uids:
                issues.append(ValidationIssue("error", "tag-reference", "Definition references a missing tag.", definition.get("uid", "")))

    enums = {item.get("uid"): item for item in data.get("enums", [])}
    structures = {item.get("uid"): item for item in data.get("structures", [])}
    groups = {item.get("uid"): item for item in data.get("groups", [])}
    type_names: dict[str, str] = {}
    for item in [*enums.values(), *structures.values(), *data.get("messages", [])]:
        name = item.get("name", "")
        uid = item.get("uid", "")
        if not _identifier(name):
            issues.append(ValidationIssue("error", "identifier", f"'{name}' is not a valid Python class name.", uid))
        elif name in type_names:
            issues.append(ValidationIssue("error", "duplicate-type", f"Duplicate type name '{name}'.", uid))
        type_names[name] = uid

    for enum in enums.values():
        names: set[str] = set()
        values: set[int] = set()
        for member in enum.get("values", []):
            name, value = member.get("name", ""), member.get("value")
            if not _identifier(name):
                issues.append(ValidationIssue("error", "enum-name", f"Invalid enum member '{name}'.", enum["uid"]))
            if name in names:
                issues.append(ValidationIssue("error", "enum-name", f"Duplicate enum member '{name}'.", enum["uid"]))
            if not isinstance(value, int) or isinstance(value, bool):
                issues.append(ValidationIssue("error", "enum-value", f"Enum value for '{name}' must be an integer.", enum["uid"]))
            elif value in values:
                issues.append(ValidationIssue("warning", "enum-alias", f"Enum value {value} is an alias.", enum["uid"]))
            names.add(name)
            values.add(value)

    if not groups:
        issues.append(ValidationIssue("error", "message-group", "At least one message group is required.", library.get("uid", "")))
    group_names: set[str] = set()
    group_route_keys: dict[tuple[str, tuple[int, ...]], str] = {}
    for group in groups.values():
        name = group.get("name", "")
        if not isinstance(name, str) or not name.strip():
            issues.append(ValidationIssue("error", "group-name", "Message groups need a name.", group.get("uid", "")))
        elif name.casefold() in group_names:
            issues.append(ValidationIssue("error", "group-name", f"Duplicate message group name '{name}'.", group.get("uid", "")))
        group_names.add(str(name).casefold())
        parent_uid = group.get("parent_group_uid", "")
        if parent_uid and parent_uid not in groups:
            issues.append(ValidationIssue("error", "group-parent", "Group references a missing parent group.", group.get("uid", "")))
        elif parent_uid == group.get("uid"):
            issues.append(ValidationIssue("error", "group-cycle", "A group cannot contain itself.", group.get("uid", "")))
        _validate_header_layers(group.get("header_layers", []), structures, issues, group.get("uid", ""))
        _validate_router(group.get("message_router"), issues, group.get("uid", ""), "child")
        parent_router = groups[parent_uid].get("message_router") if parent_uid in groups else library.get("group_router")
        _validate_route_assignment(group, parent_router, issues, "group")
        if (parent_router or {}).get("mode") == "shared":
            component_names = [item.get("name") for item in parent_router.get("components", [])]
            route_key = tuple(group.get("route_values", {}).get(name, -1) for name in component_names)
            scoped_key = (parent_uid, route_key)
            if scoped_key in group_route_keys:
                issues.append(ValidationIssue("error", "duplicate-group-route", f"Group route is already used by {group_route_keys[scoped_key]}.", group.get("uid", "")))
            group_route_keys[scoped_key] = name
    _validate_header_layers(library.get("header_layers", []), structures, issues, library.get("uid", ""))
    _validate_router(library.get("group_router"), issues, library.get("uid", ""), "group")
    root_groups = [group for group in groups.values() if not group.get("parent_group_uid")]
    if len(root_groups) > 1 and not library.get("group_router"):
        issues.append(ValidationIssue(
            "error", "group-router",
            "Libraries with more than one root message group need a group router.",
            library.get("uid", ""),
        ))
    hierarchy_enabled = bool(library.get("group_router")) or any(group.get("parent_group_uid") for group in groups.values())
    if hierarchy_enabled:
        for group in groups.values():
            has_children = any(message.get("group_uid") == group.get("uid") for message in data.get("messages", [])) or any(
                child.get("parent_group_uid") == group.get("uid") for child in groups.values()
            )
            if has_children and not group.get("message_router"):
                issues.append(ValidationIssue(
                    "error", "message-router",
                    f"Group '{group.get('name', '')}' needs a child router for automatic decoding.",
                    group.get("uid", ""),
                ))
    _validate_group_cycles(groups, issues)

    identities: dict[tuple[str, int, str], str] = {}
    directions_by_id: dict[tuple[str, int], set[str]] = {}
    behavior_names: set[str] = set()
    registry_names: set[str] = set()
    routed_message_keys: dict[tuple[str, tuple[int, ...], str], str] = {}
    for message in data.get("messages", []):
        message_id = message.get("message_id")
        group_uid = message.get("group_uid") or (next(iter(groups)) if len(groups) == 1 else "")
        if group_uid not in groups:
            issues.append(ValidationIssue("error", "message-group", "Message references a missing group.", message.get("uid", "")))
        direction = str(message.get("direction", message.get("tx_rx", "ANY"))).upper()
        if not isinstance(message_id, int) or isinstance(message_id, bool) or message_id < 0:
            issues.append(ValidationIssue("error", "message-id", "Message ID must be a non-negative integer.", message.get("uid", "")))
        elif direction not in {"TX", "RX", "ANY"}:
            issues.append(ValidationIssue("error", "message-direction", "Direction must be TX, RX, or ANY.", message.get("uid", "")))
        else:
            key = (group_uid, message_id, direction)
            prior_directions = directions_by_id.setdefault((group_uid, message_id), set())
            if key in identities:
                issues.append(ValidationIssue("error", "duplicate-message-id", f"Message identity ({message_id}, {direction}) is already used in this group by {identities[key]}.", message.get("uid", "")))
            elif prior_directions and (direction == "ANY" or "ANY" in prior_directions):
                issues.append(ValidationIssue("error", "ambiguous-message-id", f"Message ID {message_id} cannot combine ANY with TX or RX definitions.", message.get("uid", "")))
            else:
                identities[key] = message.get("name", "")
                prior_directions.add(direction)
        behavior = message.get("behavior_class", "")
        if not _identifier(behavior):
            issues.append(ValidationIssue("error", "behavior-name", f"Invalid behavior class '{behavior}'.", message.get("uid", "")))
        elif behavior in behavior_names:
            issues.append(ValidationIssue("error", "behavior-name", f"Duplicate behavior class '{behavior}'.", message.get("uid", "")))
        behavior_names.add(behavior)
        registry_name = message.get("display_name") or message.get("name")
        if registry_name in registry_names:
            issues.append(ValidationIssue("error", "registry-name", f"Duplicate message registry name '{registry_name}'.", message.get("uid", "")))
        registry_names.add(registry_name)
        group = groups.get(group_uid)
        if group is not None:
            _validate_route_assignment(message, group.get("message_router"), issues, "message")
            router = group.get("message_router") or {}
            if router.get("mode") == "shared":
                component_names = [item.get("name") for item in router.get("components", [])]
                route_values = tuple(message.get("identity_values", {}).get(name, -1) for name in component_names)
                route_key = (group_uid, route_values, direction)
                any_key = (group_uid, route_values, "ANY")
                conflicts = route_key in routed_message_keys or (direction != "ANY" and any_key in routed_message_keys)
                conflicts = conflicts or (group_uid, route_values) in group_route_keys
                if direction == "ANY":
                    conflicts = conflicts or any(key[0] == group_uid and key[1] == route_values for key in routed_message_keys)
                if conflicts:
                    issues.append(ValidationIssue("error", "duplicate-message-route", "Message byte identity is ambiguous inside its group.", message.get("uid", "")))
                routed_message_keys[route_key] = message.get("name", "")
            layer_names = [layer.get("attribute_name") for layer in library.get("header_layers", [])]
            for ancestor in _group_chain(groups, group):
                layer_names.extend(layer.get("attribute_name") for layer in ancestor.get("header_layers", []))
            field_names = [field.get("name") for field in message.get("fields", []) if field.get("kind") != "padding"]
            duplicates = set(layer_names) & set(field_names)
            if duplicates or len(layer_names) != len(set(layer_names)):
                issues.append(ValidationIssue("error", "header-field-collision", "Header layer attributes collide with message fields.", message.get("uid", "")))
        _validate_members(message, enums, structures, issues)

    for structure in structures.values():
        _validate_fields(structure.get("fields", []), enums, structures, issues, structure.get("uid", ""))
    _validate_cycles(structures, issues)
    _validate_routing_paths(data, groups, issues)
    _validate_signature_collisions(data, groups, issues)
    _validate_extractor(library.get("id_extractor"), issues, library.get("uid", ""))
    return issues


def validate_behavior_methods(source: str | None, messages: list[dict[str, Any]]) -> list[ValidationIssue]:
    """Report behavior-file drift without modifying user-owned method bodies."""
    issues: list[ValidationIssue] = []
    if source is None:
        for message in messages:
            for method in message.get("methods", []):
                issues.append(ValidationIssue(
                    "warning", "empty-method",
                    f"Method {message['behavior_class']}.{method['name']} has an empty generated stub.",
                    method.get("uid", ""),
                ))
        return issues
    try:
        tree = ast.parse(source)
    except SyntaxError as error:
        return [ValidationIssue("error", "behavior-syntax", f"behaviors.py has invalid syntax: {error}")]
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    for message in messages:
        class_name = message.get("behavior_class", "")
        class_node = classes.get(class_name)
        if class_node is None:
            issues.append(ValidationIssue(
                "warning", "missing-behavior-class",
                f"Behavior mixin {class_name} is missing from behaviors.py; it will be recreated on save.",
                message.get("uid", ""),
            ))
            continue
        methods = {
            node.name: node for node in class_node.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        if "send" in methods:
            issues.append(ValidationIssue(
                "error", "reserved-behavior-method",
                f"Method {class_name}.send overrides the BinaryMessage send API; rename it in behaviors.py.",
                message.get("uid", ""),
            ))
        for declaration in message.get("methods", []):
            label = f"{class_name}.{declaration['name']}"
            node = methods.get(declaration["name"])
            if node is None:
                issues.append(ValidationIssue(
                    "warning", "missing-method",
                    f"Method {label} is missing from behaviors.py; it will be recreated on save.",
                    declaration.get("uid", ""),
                ))
                continue
            actual_kind = _behavior_method_kind(node)
            expected_kind = declaration.get("kind", "instance")
            if actual_kind != expected_kind:
                issues.append(ValidationIssue(
                    "warning", "method-kind-drift",
                    f"Method {label} is {actual_kind} in behaviors.py but {expected_kind} in the designer; save will restore the designer kind.",
                    declaration.get("uid", ""),
                ))
            if not _behavior_signature_matches(node, expected_kind):
                issues.append(ValidationIssue(
                    "warning", "method-signature-drift",
                    f"Method {label} does not have the default {expected_kind} signature; save will restore it while preserving the body.",
                    declaration.get("uid", ""),
                ))
            if _empty_method_body(node.body):
                issues.append(ValidationIssue(
                    "warning", "empty-method", f"Method {label} is empty.", declaration.get("uid", ""),
                ))
    return issues


def _behavior_method_kind(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    if isinstance(node, ast.AsyncFunctionDef):
        return "async"
    decorators = {
        decorator.id for decorator in node.decorator_list if isinstance(decorator, ast.Name)
    }
    for kind in ("class", "static", "property"):
        decorator = "classmethod" if kind == "class" else ("staticmethod" if kind == "static" else "property")
        if decorator in decorators:
            return kind
    return "instance"


def _empty_method_body(statements: list[ast.stmt]) -> bool:
    body = list(statements)
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body.pop(0)
    return not body or all(isinstance(statement, ast.Pass) for statement in body)


def _behavior_signature_matches(node: ast.FunctionDef | ast.AsyncFunctionDef, kind: str) -> bool:
    expected = ["cls"] if kind == "class" else ([] if kind == "static" else ["self"])
    arguments = node.args
    positional = [*arguments.posonlyargs, *arguments.args]
    return (
        [argument.arg for argument in positional] == expected
        and all(argument.annotation is None for argument in positional)
        and not arguments.vararg
        and not arguments.kwarg
        and not arguments.kwonlyargs
        and not arguments.defaults
        and not arguments.kw_defaults
        and node.returns is None
    )


def _validate_members(message, enums, structures, issues):
    names: set[str] = set()
    for category in ("fields", "runtime_attributes", "constants", "methods"):
        for item in message.get(category, []):
            name = item.get("name", "")
            if not _identifier(name):
                issues.append(ValidationIssue("error", "member-name", f"Invalid member name '{name}'.", item.get("uid", "")))
            if name in names or name in RESERVED_MEMBERS:
                issues.append(ValidationIssue("error", "member-collision", f"Member name '{name}' is duplicated or reserved.", item.get("uid", "")))
            names.add(name)
    _validate_fields(message.get("fields", []), enums, structures, issues, message.get("uid", ""))
    for method in message.get("methods", []):
        if method.get("kind") not in {"instance", "class", "static", "async", "property"}:
            issues.append(ValidationIssue("error", "method-kind", "Unknown method kind.", method.get("uid", "")))
    for item in [*message.get("runtime_attributes", []), *message.get("constants", [])]:
        annotation = item.get("annotation", "")
        if annotation and not _parse_expression(annotation):
            issues.append(ValidationIssue("error", "attribute-annotation", f"Invalid annotation '{annotation}'.", item.get("uid", "")))
        expression = item.get("default") if item in message.get("runtime_attributes", []) else item.get("value")
        if expression and not _parse_expression(expression):
            issues.append(ValidationIssue("error", "attribute-default", f"Invalid value expression '{expression}'.", item.get("uid", "")))


def _validate_fields(fields, enums, structures, issues, owner_uid):
    prior_names: set[str] = set()
    prior_fields: dict[str, dict[str, Any]] = {}
    seen: set[str] = set()
    default_seen = False
    for field in fields:
        uid, name, kind = field.get("uid", owner_uid), field.get("name", ""), field.get("kind")
        if not _identifier(name):
            issues.append(ValidationIssue("error", "field-name", f"Invalid field name '{name}'.", uid))
        if name in seen:
            issues.append(ValidationIssue("error", "duplicate-field", f"Duplicate field '{name}'.", uid))
        seen.add(name)
        if kind not in FIELD_KINDS:
            issues.append(ValidationIssue("error", "field-kind", f"Unknown field kind '{kind}'.", uid))
            continue
        if kind != "padding":
            default_mode = field.get("object_default_mode", "required")
            if default_mode not in {"required", "automatic", "custom", "guided"}:
                issues.append(ValidationIssue("error", "object-default-mode", "Object default must be Required, Automatic, Guided, or Python expression.", uid))
            elif default_mode == "custom" and not _parse_expression(field.get("object_default")):
                issues.append(ValidationIssue("error", "object-default-expression", "Custom object default must be a valid Python expression.", uid))
            elif default_mode == "automatic" and not _automatic_default_available(field, enums, structures, set()):
                issues.append(ValidationIssue(
                    "error", "object-default-unavailable",
                    "An automatic object default cannot be created for this field. Add defaults to required nested fields or use a custom expression.", uid,
                ))
            elif default_mode == "guided":
                manifest_view = {"enums": list(enums.values()), "structures": list(structures.values())}
                if not guided_supported(field, manifest_view):
                    issues.append(ValidationIssue(
                        "error", "object-default-guided-unavailable",
                        "A guided object default is unavailable until this field's type references are complete.", uid,
                    ))
                else:
                    for message in guided_errors(field, field.get("object_default_value"), manifest_view):
                        issues.append(ValidationIssue("error", "object-default-guided", message, uid))
            if default_mode == "required":
                if default_seen:
                    issues.append(ValidationIssue(
                        "error", "required-after-default",
                        "Required fields must appear before fields with object defaults.", uid,
                    ))
            else:
                default_seen = True
        if kind in {"uint", "int"} and field.get("width") not in {1, 2, 3, 4, 8}:
            issues.append(ValidationIssue("error", "integer-width", "Integer width must be 1, 2, 3, 4, or 8 bytes.", uid))
        if kind == "float" and field.get("width") not in {2, 4, 8}:
            issues.append(ValidationIssue("error", "float-width", "Float width must be 2, 4, or 8 bytes.", uid))
        if field.get("endian") not in {None, "big", "little"}:
            issues.append(ValidationIssue("error", "endian", "Byte order must be big or little.", uid))
        if kind == "enum" and field.get("enum_uid") not in enums:
            issues.append(ValidationIssue("error", "enum-reference", "Enum field references a missing enum.", uid))
        if kind == "struct" and field.get("struct_uid") not in structures:
            issues.append(ValidationIssue("error", "struct-reference", "Structure field references a missing structure.", uid))
        if kind in {"bytes", "string"}:
            mode = field.get("mode")
            if mode not in {"fixed", "count_field", "greedy", "null_terminated", "pascal"}:
                issues.append(ValidationIssue("error", "data-mode", f"Unsupported {kind} mode '{mode}'.", uid))
            if mode == "count_field":
                reference = field.get("length_field")
                if reference not in prior_names:
                    issues.append(ValidationIssue("error", "length-reference", "Length field must reference an earlier field in the same structure.", uid))
                elif not _is_integer_reference(prior_fields.get(reference, {})):
                    issues.append(ValidationIssue("error", "length-reference-type", "Length field must reference an integer-compatible field.", uid))
        if kind == "array":
            mode = field.get("mode")
            if mode not in {"fixed", "count_field", "prefixed", "greedy"}:
                issues.append(ValidationIssue("error", "array-mode", f"Unsupported array mode '{mode}'.", uid))
            if mode == "count_field":
                reference = field.get("count_field")
                if reference not in prior_names:
                    issues.append(ValidationIssue("error", "count-reference", "Array count must reference an earlier field in the same structure.", uid))
                elif not _is_integer_reference(prior_fields.get(reference, {})):
                    issues.append(ValidationIssue("error", "count-reference-type", "Array count must reference an integer-compatible field.", uid))
        if kind == "bitfield":
            bit_names: set[str] = set()
            total = 0
            for member in field.get("members", []):
                member_name = member.get("name", "")
                member_kind = member.get("kind")
                bits = member.get("bits", 0)
                if member_kind not in {"flag", "signed", "unsigned", "padding"}:
                    issues.append(ValidationIssue("error", "bit-kind", f"Unknown bit member kind '{member_kind}'.", uid))
                if not isinstance(bits, int) or isinstance(bits, bool) or bits <= 0:
                    issues.append(ValidationIssue("error", "bit-width", "Bit member widths must be positive integers.", uid))
                else:
                    total += bits
                if member_kind != "padding":
                    if not _identifier(member_name) or member_name in bit_names:
                        issues.append(ValidationIssue("error", "bit-name", f"Invalid or duplicate bit member '{member_name}'.", uid))
                    bit_names.add(member_name)
            if total <= 0 or total % 8:
                issues.append(ValidationIssue("error", "bit-alignment", "A bit group must contain a positive multiple of eight bits.", uid))
        if kind in {"bytes", "string"} and field.get("mode") == "fixed":
            if not isinstance(field.get("length"), int) or isinstance(field.get("length"), bool) or field.get("length") < 0:
                issues.append(ValidationIssue("error", "fixed-length", "Fixed length must be a non-negative integer.", uid))
        if kind == "array" and field.get("mode") == "fixed":
            if not isinstance(field.get("count"), int) or isinstance(field.get("count"), bool) or field.get("count") < 0:
                issues.append(ValidationIssue("error", "array-count", "Fixed array count must be a non-negative integer.", uid))
        if kind == "switch":
            case_values: set[str] = set()
            for case in field.get("cases", []):
                value_text = str(case.get("value", "")).strip()
                if value_text in case_values:
                    issues.append(ValidationIssue("error", "switch-case", f"Duplicate switch case '{value_text}'.", uid))
                case_values.add(value_text)
            default = field.get("default", "")
            if default and not _parse_expression(default):
                issues.append(ValidationIssue("error", "switch-default", "Switch default must be a Construct expression.", uid))
            selector = str(field.get("selector", ""))
            if not default and selector.startswith("this."):
                selector_field = prior_fields.get(selector.removeprefix("this."))
                if selector_field and selector_field.get("kind") == "enum":
                    expected = {str(member["value"]) for member in enums[selector_field["enum_uid"]].get("values", [])}
                    if expected != case_values:
                        issues.append(ValidationIssue("error", "switch-coverage", "Switch cases must cover every enum value when no default is provided.", uid))
        if kind in {"const", "default"} and not _parse_expression(field.get("value")):
            issues.append(ValidationIssue("error", "field-value", f"{kind.title()} value must be an expression.", uid))
        if kind == "padding" and (not isinstance(field.get("length"), int) or isinstance(field.get("length"), bool) or field.get("length") < 0):
            issues.append(ValidationIssue("error", "padding-length", "Padding length must be a non-negative integer.", uid))
        if kind == "aligned" and (not isinstance(field.get("modulus"), int) or isinstance(field.get("modulus"), bool) or field.get("modulus") <= 0):
            issues.append(ValidationIssue("error", "alignment", "Alignment modulus must be a positive integer.", uid))
        if kind == "checksum":
            algorithm = field.get("algorithm", "")
            if algorithm not in {"crc32", "sum8", "sha256"} and not _parse_expression(algorithm):
                issues.append(ValidationIssue("error", "checksum-algorithm", "Checksum algorithm must be crc32, sum8, sha256, or a callable expression.", uid))
        for expression_key in ("expression", "condition", "selector", "source"):
            if expression_key in field and not _parse_expression(field.get(expression_key)):
                issues.append(ValidationIssue("error", "expression", f"Invalid expression in {name}.{expression_key}.", uid))
        for nested_key in ("item",):
            nested = field.get(nested_key)
            if isinstance(nested, dict):
                _validate_fields([nested], enums, structures, issues, owner_uid)
        if kind == "inline_struct":
            _validate_fields(field.get("fields", []), enums, structures, issues, owner_uid)
        for case in field.get("cases", []):
            if not _parse_expression(case.get("value")):
                issues.append(ValidationIssue("error", "switch-value", "Switch case value must be an expression.", uid))
            if isinstance(case.get("item"), dict):
                _validate_fields([case["item"]], enums, structures, issues, owner_uid)
        prior_names.add(name)
        prior_fields[name] = field


def _automatic_default_available(field, enums, structures, visiting):
    kind = field.get("kind")
    if kind == "enum":
        enum = enums.get(field.get("enum_uid"))
        return bool(enum and enum.get("values"))
    if kind == "struct":
        uid = field.get("struct_uid")
        structure = structures.get(uid)
        if structure is None or uid in visiting:
            return False
        return _fields_default_constructible(
            structure.get("fields", []), enums, structures, visiting | {uid}
        )
    if kind == "inline_struct":
        return _fields_default_constructible(field.get("fields", []), enums, structures, visiting)
    if kind == "array":
        item = field.get("item")
        return isinstance(item, dict) and _automatic_default_available(item, enums, structures, visiting)
    if kind in {"const", "default", "aligned", "rebuild", "checksum"}:
        item = field.get("item")
        return isinstance(item, dict) and _automatic_default_available(item, enums, structures, visiting)
    if kind in {"switch", "advanced"}:
        return False
    return kind in FIELD_KINDS


def _is_integer_reference(field):
    kind = field.get("kind")
    if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "enum"}:
        return True
    if kind in {"const", "default", "rebuild"} and isinstance(field.get("item"), dict):
        return _is_integer_reference(field["item"])
    return False


def _fields_default_constructible(fields, enums, structures, visiting):
    for nested in fields:
        if nested.get("kind") == "padding":
            continue
        mode = nested.get("object_default_mode", "required")
        if mode == "required":
            return False
        if mode == "automatic" and not _automatic_default_available(nested, enums, structures, visiting):
            return False
        if mode == "guided" and guided_errors(
            nested, nested.get("object_default_value"),
            {"enums": list(enums.values()), "structures": list(structures.values())},
        ):
            return False
    return True


def _validate_cycles(structures, issues):
    graph = {
        uid: {
            field.get("struct_uid")
            for field in walk_fields(structure.get("fields", []))
            if field.get("kind") == "struct" and field.get("struct_uid") in structures
        }
        for uid, structure in structures.items()
    }
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(uid: str) -> bool:
        if uid in visiting:
            return True
        if uid in visited:
            return False
        visiting.add(uid)
        cyclic = any(visit(child) for child in graph.get(uid, set()))
        visiting.remove(uid)
        visited.add(uid)
        return cyclic

    for uid in graph:
        if visit(uid):
            issues.append(ValidationIssue("error", "struct-cycle", f"Reusable structure '{structures[uid].get('name')}' is recursive.", uid))


def _validate_group_cycles(groups, issues):
    for group in groups.values():
        seen = set(); current = group
        while current and current.get("parent_group_uid"):
            uid = current.get("uid")
            if uid in seen:
                issues.append(ValidationIssue(
                    "error", "group-cycle", f"Message group '{group.get('name', '')}' has a circular parent chain.",
                    group.get("uid", ""),
                ))
                break
            seen.add(uid)
            current = groups.get(current.get("parent_group_uid"))


def _group_chain(groups, group):
    chain = []; seen = set(); current = group
    while current and current.get("uid") not in seen:
        seen.add(current.get("uid")); chain.append(current)
        current = groups.get(current.get("parent_group_uid"))
    return list(reversed(chain))


def _validate_header_layers(layers, structures, issues, owner_uid):
    if not isinstance(layers, list):
        issues.append(ValidationIssue("error", "header-layers", "Header layers must be an ordered list.", owner_uid)); return
    names: set[str] = set()
    for layer in layers:
        name = layer.get("attribute_name", "") if isinstance(layer, dict) else ""
        if not _identifier(name):
            issues.append(ValidationIssue("error", "header-layer-name", f"Invalid header attribute '{name}'.", owner_uid))
        elif name in names:
            issues.append(ValidationIssue("error", "header-layer-name", f"Duplicate header attribute '{name}'.", owner_uid))
        names.add(name)
        if not isinstance(layer, dict) or layer.get("struct_uid") not in structures:
            issues.append(ValidationIssue("error", "header-layer-structure", f"Header layer '{name}' references a missing structure.", owner_uid))


def _validate_router(router, issues, uid, label):
    if router is None:
        return
    if not isinstance(router, dict) or router.get("mode") not in {"shared", "signatures"}:
        issues.append(ValidationIssue("error", "routing-mode", f"Invalid {label} routing mode.", uid)); return
    components = router.get("components", [])
    if router.get("mode") == "shared" and not components:
        issues.append(ValidationIssue("error", "routing-components", f"Shared {label} routing needs at least one component.", uid))
    names: set[str] = set()
    for component in components:
        name = component.get("name", "") if isinstance(component, dict) else ""
        if not _identifier(name) or name in names:
            issues.append(ValidationIssue("error", "routing-component-name", f"Invalid or duplicate routing component '{name}'.", uid))
        names.add(name); _validate_probe(component, issues, uid, expected=False)


def _validate_probe(probe, issues, uid, *, expected):
    if not isinstance(probe, dict):
        issues.append(ValidationIssue("error", "routing-probe", "Routing probes must be objects.", uid)); return
    source = probe.get("source", "raw")
    if source not in {"raw", "field"}:
        issues.append(ValidationIssue("error", "routing-source", "Routing source must be raw or field.", uid))
    if expected and (not isinstance(probe.get("expected"), int) or isinstance(probe.get("expected"), bool) or probe.get("expected") < 0):
        issues.append(ValidationIssue("error", "routing-expected", "Routing expected values must be non-negative integers.", uid))
    if source == "field":
        if not str(probe.get("field_path", "")).strip():
            issues.append(ValidationIssue("error", "routing-field-path", "Field-based routing needs a field path.", uid))
        return
    if not isinstance(probe.get("offset", 0), int) or probe.get("offset", 0) < 0:
        issues.append(ValidationIssue("error", "routing-offset", "Routing offsets must be non-negative integers.", uid))
    if probe.get("width") not in {1, 2, 3, 4, 8}:
        issues.append(ValidationIssue("error", "routing-width", "Routing widths must be 1, 2, 3, 4, or 8 bytes.", uid))
    if probe.get("byteorder", "big") not in {"big", "little"}:
        issues.append(ValidationIssue("error", "routing-byteorder", "Routing byte order must be big or little.", uid))
    if not isinstance(probe.get("shift", 0), int) or probe.get("shift", 0) < 0:
        issues.append(ValidationIssue("error", "routing-shift", "Routing shifts must be non-negative integers.", uid))
    mask = probe.get("mask")
    if mask is not None and (not isinstance(mask, int) or isinstance(mask, bool) or mask < 0):
        issues.append(ValidationIssue("error", "routing-mask", "Routing masks must be non-negative integers.", uid))


def _validate_route_assignment(candidate, router, issues, label):
    if router is None:
        return
    uid = candidate.get("uid", "")
    if router.get("mode") == "shared":
        values = candidate.get("route_values" if label == "group" else "identity_values", {})
        expected_names = [component.get("name") for component in router.get("components", [])]
        if set(values) != set(expected_names):
            issues.append(ValidationIssue("error", "routing-values", f"{label.title()} routing values must define: {', '.join(expected_names)}.", uid))
        for name, value in values.items():
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                issues.append(ValidationIssue("error", "routing-value", f"Routing value '{name}' must be a non-negative integer.", uid))
    else:
        signatures = candidate.get("route_signatures" if label == "group" else "identity_signatures", [])
        if not signatures:
            issues.append(ValidationIssue("error", "routing-signatures", f"{label.title()} needs at least one routing signature.", uid))
        for signature in signatures:
            probes = signature.get("probes", []) if isinstance(signature, dict) else []
            if not probes:
                issues.append(ValidationIssue("error", "routing-signature", "Routing signatures cannot be empty.", uid))
            names: set[str] = set()
            for probe in probes:
                name = probe.get("name", "") if isinstance(probe, dict) else ""
                if not _identifier(name) or name in names:
                    issues.append(ValidationIssue("error", "routing-probe-name", f"Invalid or duplicate routing probe '{name}'.", uid))
                names.add(name); _validate_probe(probe, issues, uid, expected=True)


def _validate_routing_paths(data, groups, issues):
    library_router = data.get("library", {}).get("group_router")
    for group in groups.values():
        parent = groups.get(group.get("parent_group_uid"))
        parent_router = parent.get("message_router") if parent else library_router
        for probe in _candidate_probes(group, parent_router, "group"):
            try: resolve_routing_component(probe, data, parent)
            except RoutingPathError as error: issues.append(ValidationIssue("error", "routing-field-path", str(error), group.get("uid", "")))
        router = group.get("message_router")
        for child in groups.values():
            if child.get("parent_group_uid") != group.get("uid"): continue
            for probe in _candidate_probes(child, router, "group"):
                try: resolve_routing_component(probe, data, group)
                except RoutingPathError as error: issues.append(ValidationIssue("error", "routing-field-path", str(error), child.get("uid", "")))
        for message in data.get("messages", []):
            message_group = message.get("group_uid") or (group.get("uid") if len(groups) == 1 else "")
            if message_group != group.get("uid"): continue
            for probe in _candidate_probes(message, router, "message"):
                try: resolve_routing_component(probe, data, group)
                except RoutingPathError as error: issues.append(ValidationIssue("error", "routing-field-path", str(error), message.get("uid", "")))


def _validate_signature_collisions(data, groups, issues):
    """Reject identical candidate-specific routes; partial mask overlap remains runtime-checked."""
    library_router = data.get("library", {}).get("group_router") or {}
    if library_router.get("mode") == "signatures":
        used: dict[tuple, str] = {}
        for group in groups.values():
            if group.get("parent_group_uid"): continue
            for signature in group.get("route_signatures", []):
                key = _resolved_signature_key(signature, data)
                if key is None:
                    continue
                if key in used:
                    issues.append(ValidationIssue(
                        "error", "duplicate-group-route",
                        f"Group signature is already used by {used[key]}.", group.get("uid", ""),
                    ))
                used[key] = group.get("name", "")
    for group in groups.values():
        router = group.get("message_router") or {}
        if router.get("mode") != "signatures":
            continue
        used: dict[tuple, list[tuple[str, str]]] = {}
        candidates = [
            (child, "group") for child in groups.values()
            if child.get("parent_group_uid") == group.get("uid")
        ] + [
            (message, "message")
            for message in data.get("messages", [])
            if message.get("group_uid") == group.get("uid")
        ]
        for candidate, kind in candidates:
            direction = "ANY" if kind == "group" else str(candidate.get("direction", "ANY")).upper()
            signatures = candidate.get("route_signatures" if kind == "group" else "identity_signatures", [])
            for signature in signatures:
                key = _resolved_signature_key(signature, data, group)
                if key is None:
                    continue
                prior = used.setdefault(key, [])
                if any(direction == "ANY" or old_direction == "ANY" or old_direction == direction for old_direction, _ in prior):
                    issues.append(ValidationIssue(
                        "error", "duplicate-message-route",
                        "Child routing signature is ambiguous inside its group.", candidate.get("uid", ""),
                    ))
                prior.append((direction, candidate.get("name", "")))


def _resolved_signature_key(signature, data, group=None):
    try:
        probes = [resolve_routing_component(probe, data, group) for probe in signature.get("probes", [])]
    except (AttributeError, RoutingPathError, TypeError, ValueError):
        return None
    return tuple(sorted((
        int(probe.get("offset", 0)), int(probe.get("width", 1)), probe.get("byteorder", "big"),
        probe.get("mask"), int(probe.get("shift", 0)), probe.get("expected"),
    ) for probe in probes))


def _candidate_probes(candidate, router, level):
    if not router: return []
    if router.get("mode") == "shared": return router.get("components", [])
    signatures = candidate.get("route_signatures" if level == "group" else "identity_signatures", [])
    return [probe for signature in signatures for probe in signature.get("probes", [])]


def _validate_extractor(extractor, issues, uid):
    if extractor is None:
        return
    if not isinstance(extractor, dict):
        issues.append(ValidationIssue("error", "extractor", "Message-ID extractor must be an object.", uid))
        return
    if extractor.get("offset", -1) < 0 or extractor.get("width") not in {1, 2, 3, 4, 8}:
        issues.append(ValidationIssue("error", "extractor", "ID extractor needs a non-negative offset and supported width.", uid))
    if extractor.get("byteorder") not in {"big", "little"}:
        issues.append(ValidationIssue("error", "extractor", "ID extractor byte order must be big or little.", uid))


def blocking_issues(data: dict[str, Any]) -> list[ValidationIssue]:
    return [issue for issue in validate_manifest(data) if issue.blocking]
