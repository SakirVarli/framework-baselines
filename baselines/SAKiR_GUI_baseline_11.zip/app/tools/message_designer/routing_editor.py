from __future__ import annotations

import copy
from typing import Any

from PyQt5 import QtCore, QtWidgets

from .model import new_id


class HeaderLayersEditor(QtWidgets.QWidget):
    changed = QtCore.pyqtSignal()

    def __init__(self, layers, structures, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self._structures = copy.deepcopy(structures)
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.table = QtWidgets.QTableWidget(0, 2)
        self.table.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.table.setHorizontalHeaderLabels(["Attribute name", "Reusable structure"])
        self.table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        layout.addWidget(self.table)
        row = QtWidgets.QHBoxLayout(); add = QtWidgets.QPushButton("Add header layer"); remove = QtWidgets.QPushButton("Remove selected")
        row.addWidget(add); row.addWidget(remove); row.addStretch(); layout.addLayout(row)
        add.clicked.connect(self._add); remove.clicked.connect(self._remove); self.table.itemChanged.connect(self.changed)
        for layer in layers: self._append(layer)

    def _append(self, layer):
        previous = self.table.blockSignals(True)
        try:
            row = self.table.rowCount(); self.table.insertRow(row)
            item = QtWidgets.QTableWidgetItem(str(layer.get("attribute_name", "header"))); item.setData(QtCore.Qt.UserRole, layer.get("uid", new_id()))
            self.table.setItem(row, 0, item)
            combo = QtWidgets.QComboBox(); combo.addItem("— Select structure —", "")
            for structure in self._structures: combo.addItem(structure.get("name", "Unnamed"), structure.get("uid", ""))
            combo.setCurrentIndex(max(0, combo.findData(layer.get("struct_uid", "")))); combo.currentIndexChanged.connect(self.changed)
            self.table.setCellWidget(row, 1, combo)
        finally:
            self.table.blockSignals(previous)

    def _add(self):
        self._append({"uid": new_id(), "attribute_name": "header", "struct_uid": ""}); self.changed.emit()

    def _remove(self):
        row = self.table.currentRow()
        if row >= 0: self.table.removeRow(row); self.changed.emit()

    def value(self):
        return [{
            "uid": self.table.item(row, 0).data(QtCore.Qt.UserRole) or new_id(),
            "attribute_name": self.table.item(row, 0).text().strip(),
            "struct_uid": self.table.cellWidget(row, 1).currentData() or "",
        } for row in range(self.table.rowCount())]


class RouterEditor(QtWidgets.QWidget):
    """Edit a shared component layout or select candidate-specific signatures."""

    changed = QtCore.pyqtSignal()

    def __init__(self, router, field_paths=(), parent=None):
        super().__init__(parent)
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        router = copy.deepcopy(router)
        self._field_paths = list(field_paths)
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.enabled = QtWidgets.QCheckBox("Enable automatic routing at this level")
        self.enabled.setChecked(router is not None); layout.addWidget(self.enabled)
        self.mode = QtWidgets.QComboBox(); self.mode.addItem("Shared component locations", "shared"); self.mode.addItem("Candidate-specific signatures", "signatures")
        self.mode.setCurrentIndex(max(0, self.mode.findData((router or {}).get("mode", "shared")))); layout.addWidget(self.mode)
        self.table = QtWidgets.QTableWidget(0, 8)
        self.table.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        self.table.setHorizontalHeaderLabels(["Component", "Source", "Header field", "Offset", "Width", "Endian", "Mask", "Shift"])
        self.table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        layout.addWidget(self.table)
        controls = QtWidgets.QHBoxLayout(); add = QtWidgets.QPushButton("Add component"); remove = QtWidgets.QPushButton("Remove selected")
        controls.addWidget(add); controls.addWidget(remove); controls.addStretch(); layout.addLayout(controls)
        add.clicked.connect(self._add); remove.clicked.connect(self._remove)
        self.enabled.toggled.connect(self._visibility); self.enabled.toggled.connect(self.changed)
        self.mode.currentIndexChanged.connect(self._visibility); self.mode.currentIndexChanged.connect(self.changed)
        self.table.itemChanged.connect(self.changed)
        for component in (router or {}).get("components", []): self._append(component)
        self._visibility()

    def _append(self, component):
        previous = self.table.blockSignals(True)
        try:
            row = self.table.rowCount(); self.table.insertRow(row)
            values = [component.get("name", "component"), component.get("source", "raw"), component.get("field_path", ""), component.get("offset", 0), component.get("width", 1), component.get("byteorder", "big"), "" if component.get("mask") is None else hex(component["mask"]), component.get("shift", 0)]
            for column, value in enumerate(values): self.table.setItem(row, column, QtWidgets.QTableWidgetItem(str(value)))
            source = QtWidgets.QComboBox(); source.addItem("Raw offset", "raw"); source.addItem("Header field", "field"); source.setCurrentIndex(max(0, source.findData(component.get("source", "raw")))); source.currentIndexChanged.connect(self.changed)
            self.table.setCellWidget(row, 1, source)
            path = QtWidgets.QComboBox(); path.setEditable(True); path.addItem("", "")
            for option in self._field_paths: path.addItem(option["path"], option["path"])
            path.setCurrentText(str(component.get("field_path", ""))); path.currentTextChanged.connect(self.changed)
            self.table.setCellWidget(row, 2, path)
            self.table.item(row, 0).setData(QtCore.Qt.UserRole, component.get("uid", new_id()))
        finally:
            self.table.blockSignals(previous)

    def _add(self):
        self._append({"uid": new_id(), "name": "component", "source": "raw", "field_path": "", "offset": 0, "width": 1, "byteorder": "big", "mask": None, "shift": 0}); self.changed.emit()

    def _remove(self):
        row = self.table.currentRow()
        if row >= 0: self.table.removeRow(row); self.changed.emit()

    def _visibility(self):
        active = self.enabled.isChecked(); shared = self.mode.currentData() == "shared"
        self.mode.setEnabled(active); self.table.setVisible(active and shared)

    def value(self):
        if not self.enabled.isChecked(): return None
        result = {"mode": self.mode.currentData(), "components": []}
        if result["mode"] == "shared":
            for row in range(self.table.rowCount()):
                text = self.table.item(row, 6).text().strip()
                result["components"].append({
                    "uid": self.table.item(row, 0).data(QtCore.Qt.UserRole) or new_id(),
                    "name": self.table.item(row, 0).text().strip(), "source": self.table.cellWidget(row, 1).currentData(),
                    "field_path": self.table.cellWidget(row, 2).currentText().strip(),
                    "offset": _integer(self.table.item(row, 3).text()), "width": _integer(self.table.item(row, 4).text()),
                    "byteorder": self.table.item(row, 5).text().strip().lower(),
                    "mask": None if not text else _integer(text), "shift": _integer(self.table.item(row, 7).text()),
                })
        return result


class RouteAssignmentEditor(QtWidgets.QWidget):
    changed = QtCore.pyqtSignal()

    def __init__(self, router, values, signatures, field_paths=(), parent=None):
        super().__init__(parent)
        self.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.router = copy.deepcopy(router)
        self._field_paths = list(field_paths)
        self._signature_uids = {
            index: signature.get("uid", new_id()) for index, signature in enumerate(signatures)
        }
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.table = QtWidgets.QTableWidget()
        self.table.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Expanding)
        layout.addWidget(self.table)
        controls = QtWidgets.QHBoxLayout()
        self.add_signature = QtWidgets.QPushButton("Add signature")
        self.add = QtWidgets.QPushButton("Add probe")
        self.remove = QtWidgets.QPushButton("Remove selected")
        controls.addWidget(self.add_signature); controls.addWidget(self.add); controls.addWidget(self.remove); controls.addStretch(); layout.addLayout(controls)
        self.add_signature.clicked.connect(self._add_signature)
        self.add.clicked.connect(self._add_probe); self.remove.clicked.connect(self._remove); self.table.itemChanged.connect(self.changed)
        if not router:
            self.table.setColumnCount(1); self.table.setHorizontalHeaderLabels(["Routing disabled"]); self.table.setRowCount(1); self.table.setItem(0, 0, QtWidgets.QTableWidgetItem("No automatic route at this level"))
            self.add_signature.hide(); self.add.hide(); self.remove.hide()
        elif router.get("mode") == "shared":
            self.table.setColumnCount(2); self.table.setHorizontalHeaderLabels(["Component", "Expected value"])
            self.add_signature.hide(); self.add.hide(); self.remove.hide()
            for component in router.get("components", []):
                row = self.table.rowCount(); self.table.insertRow(row)
                name = component.get("name", ""); name_item = QtWidgets.QTableWidgetItem(name); name_item.setFlags(name_item.flags() & ~QtCore.Qt.ItemIsEditable)
                self.table.setItem(row, 0, name_item); self.table.setItem(row, 1, QtWidgets.QTableWidgetItem(hex(values.get(name, 0))))
        else:
            self.table.setColumnCount(10); self.table.setHorizontalHeaderLabels([
                "Signature", "Probe", "Source", "Header field", "Offset", "Width",
                "Endian", "Mask", "Shift", "Expected",
            ])
            for signature_index, signature in enumerate(signatures):
                for probe in signature.get("probes", []): self._append_probe(signature_index, probe)
        self.table.horizontalHeader().setSectionResizeMode(1 if self.table.columnCount() > 1 else 0, QtWidgets.QHeaderView.Stretch)

    def _append_probe(self, signature, probe):
        previous = self.table.blockSignals(True)
        try:
            row = self.table.rowCount(); self.table.insertRow(row)
            values = [
                signature, probe.get("name", "id"), probe.get("source", "raw"),
                probe.get("field_path", ""), probe.get("offset", 0), probe.get("width", 1),
                probe.get("byteorder", "big"), "" if probe.get("mask") is None else hex(probe["mask"]),
                probe.get("shift", 0), hex(probe.get("expected", 0)),
            ]
            for column, value in enumerate(values): self.table.setItem(row, column, QtWidgets.QTableWidgetItem(str(value)))
            source = QtWidgets.QComboBox(); source.addItem("Raw offset", "raw"); source.addItem("Header field", "field")
            source.setCurrentIndex(max(0, source.findData(probe.get("source", "raw")))); source.currentIndexChanged.connect(self.changed)
            self.table.setCellWidget(row, 2, source)
            path = QtWidgets.QComboBox(); path.setEditable(True); path.addItem("", "")
            for option in self._field_paths: path.addItem(option["path"], option["path"])
            path.setCurrentText(str(probe.get("field_path", ""))); path.currentTextChanged.connect(self.changed)
            self.table.setCellWidget(row, 3, path)
            self.table.item(row, 1).setData(QtCore.Qt.UserRole, probe.get("uid", new_id()))
        finally:
            self.table.blockSignals(previous)

    def _add_probe(self):
        row = self.table.currentRow()
        signature = _integer(self.table.item(row, 0).text()) if row >= 0 else 0
        self._signature_uids.setdefault(signature, new_id())
        self._append_probe(signature, {"uid": new_id(), "name": "id", "offset": 0, "width": 1, "byteorder": "big", "mask": None, "shift": 0, "expected": 0}); self.changed.emit()

    def _add_signature(self):
        signature = max(self._signature_uids, default=-1) + 1
        self._signature_uids[signature] = new_id()
        self._append_probe(signature, {"uid": new_id(), "name": "id", "offset": 0, "width": 1, "byteorder": "big", "mask": None, "shift": 0, "expected": 0})
        self.changed.emit()

    def _remove(self):
        row = self.table.currentRow()
        if row >= 0: self.table.removeRow(row); self.changed.emit()

    def value(self):
        if not self.router: return {}, []
        if self.router.get("mode") == "shared":
            return {self.table.item(row, 0).text(): _integer(self.table.item(row, 1).text()) for row in range(self.table.rowCount())}, []
        grouped: dict[int, list[dict[str, Any]]] = {}
        for row in range(self.table.rowCount()):
            index = _integer(self.table.item(row, 0).text()); mask = self.table.item(row, 7).text().strip()
            grouped.setdefault(index, []).append({
                "uid": self.table.item(row, 1).data(QtCore.Qt.UserRole) or new_id(), "name": self.table.item(row, 1).text().strip(),
                "source": self.table.cellWidget(row, 2).currentData(),
                "field_path": self.table.cellWidget(row, 3).currentText().strip(),
                "offset": _integer(self.table.item(row, 4).text()),
                "width": _integer(self.table.item(row, 5).text()), "byteorder": self.table.item(row, 6).text().strip().lower(),
                "mask": None if not mask else _integer(mask), "shift": _integer(self.table.item(row, 8).text()),
                "expected": _integer(self.table.item(row, 9).text()),
            })
        return {}, [
            {"uid": self._signature_uids.setdefault(index, new_id()), "probes": grouped[index]}
            for index in sorted(grouped)
        ]


def _integer(text):
    return int(str(text).strip(), 0)
