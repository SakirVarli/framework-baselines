"""Shipped live suite runner. Synthetic fixtures, no Apply or device dispatch."""
import copy
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
from types import SimpleNamespace
import uuid

from ..context import SourceIndex
from ..model_routing import stage_settings
from ..policy import AssistantError, ProjectPolicy, digest, file_hash
from ..provider import ChatProvider
from ..task_state import TaskLedger
from ..tools import ToolSet
from ..workflow import SequentialWorkflow
from ..workflow_protocol import capture_workflow, host_checks, completion_checks, answer_completion_checks
from ..workflow_store import WorkflowStore
from .configuration import SUITE_VERSION, registry, suite_fingerprint
from .dialogues import run_dialogue
from .reporting import (Recorder, SCHEMA_VERSION, Sanitizer, environment, resources, safe_settings,
                        summarize, render_report, utc_now, exception_details)
from .task_oracles import fixture, score
from .reliability_oracles import seed_failed_change, check_case

APPLICATION_ROOT = Path(__file__).resolve().parents[3]


def export_fixture(destination, source=APPLICATION_ROOT):
    """Copy installed framework source/help only; never user's callbacks or app data."""
    destination, source = Path(destination), Path(source)
    app = source / 'app'
    for parent, directories, names in os.walk(app, followlinks=False):
        directories[:] = [name for name in directories if name not in {'data', '__pycache__', 'benchmark'}
                          and not name.startswith('.') and not (Path(parent)/name).is_symlink()]
        for name in names:
            path = Path(parent)/name
            if path.suffix not in {'.py', '.md'} or path.is_symlink():
                continue
            target = destination / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    help_path = app / 'data/help.json'
    if help_path.is_file() and not help_path.is_symlink():
        target = destination / 'app/data/help.json'
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(help_path, target)


class RunControl:
    def __init__(self, options, cancel):
        self.deadline = time.monotonic()+options.run_seconds
        self.cancel, self.requests, self.max_requests = cancel, 0, options.max_requests
        self.reason = None
        self.failure = None
        self.provider = None

    def check(self):
        if self.reason is None and time.monotonic() >= self.deadline:
            self.reason = 'BENCHMARK_DEADLINE'
        if self.reason:
            self.cancel.set()
            message = self.failure['message'] if self.failure and self.reason == self.failure['code'] else 'Benchmark stopped: '+self.reason
            raise AssistantError(self.reason, message)
        if self.cancel.is_set():
            raise AssistantError('CANCELLED', 'Benchmark stopped by user.')

    def request(self):
        self.check()
        if self.requests >= self.max_requests:
            self.reason = 'BENCHMARK_REQUEST_LIMIT'
            self.check()
        self.requests += 1

    def recording_failed(self, exc, phase, original=None):
        if self.failure is None:
            self.failure = {**exception_details(exc), 'phase': phase}
            if self.failure['code'] not in {'BENCHMARK_RECORDING_FAILED', 'BENCHMARK_TRACE_LIMIT'}:
                self.failure['code'] = 'BENCHMARK_RECORDING_FAILED'
            if original is not None:
                self.failure['original_error'] = exception_details(original)
            if self.reason is None:
                self.reason = self.failure['code']
        self.cancel.set()

    def error(self, exc):
        original = exception_details(exc)
        if self.failure and self.reason == self.failure['code']:
            return dict(self.failure)
        if self.reason:
            result = {'code': self.reason, 'message': 'Benchmark stopped: '+self.reason,
                      'original_error': original}
            if self.failure:
                result['recording_failure'] = dict(self.failure)
            return result
        return original


class RecordingProvider(ChatProvider):
    def __init__(self, settings, key, recorder, control):
        super().__init__(settings, key)
        self.recorder, self.control = recorder, control
        self.benchmark_observer = lambda kind, value: recorder.event('provider_'+kind, value)

    def complete(self, messages, tools, cancel, emit=lambda *args: None, max_tokens=None):
        self.control.request()
        request_id = 'request-'+str(self.control.requests)
        previous_scope = dict(self.recorder.scope)
        self.recorder.scope['request_id'] = request_id
        self.control.provider = self
        old_deadline = self.request_deadline
        self.request_deadline = min(old_deadline or self.control.deadline, self.control.deadline)
        from ..reasoning import request_options
        started = time.monotonic()
        first = None
        response_received = False
        timings = {'first_chunk_seconds': None, 'first_text_seconds': None,
                   'first_reasoning_seconds': None, 'first_tool_call_seconds': None}
        previous_observer = self.benchmark_observer
        def observe(kind, value):
            elapsed = time.monotonic()-started
            if kind == 'chunk':
                if timings['first_chunk_seconds'] is None:
                    timings['first_chunk_seconds'] = elapsed
                if timings['first_tool_call_seconds'] is None and any(
                        row.get('delta', {}).get('tool_calls') for row in value.get('choices', [])):
                    timings['first_tool_call_seconds'] = elapsed
            elif kind == 'raw_response' and timings['first_tool_call_seconds'] is None and any(
                    row.get('message', {}).get('tool_calls') for row in value.get('choices', [])):
                timings['first_tool_call_seconds'] = elapsed
            self.recorder.event('provider_'+kind, value)
        self.benchmark_observer = observe
        try:
            self.recorder.event('provider_request', {'model': self.settings.model, 'messages': messages,
                'purpose': self.recorder.scope.get('request_purpose') or ('workflow' if self.recorder.scope.get('case') else 'preflight'),
                'tools': tools, 'settings': safe_settings(self.settings),
                'generation_options': request_options(self.settings, self.effective_effort),
                'effective_max_tokens': max_tokens or self.settings.max_tokens,
                'deadline_remaining_seconds_at_start': max(0, self.request_deadline-started),
                'reasoning_availability': 'Only provider-exposed fields are captured; hidden reasoning unavailable.'})
            def receive(kind, value):
                nonlocal first
                self.control.check()
                elapsed = time.monotonic()-started
                if first is None and kind in {'text_delta', 'reasoning_delta'} and value:
                    first = elapsed
                field = {'text_delta': 'first_text_seconds', 'reasoning_delta': 'first_reasoning_seconds'}.get(kind)
                if field and value and timings[field] is None:
                    timings[field] = elapsed
                self.recorder.event('provider_'+kind, value)
                emit(kind, value)
            reply = super().complete(messages, tools, cancel, receive, max_tokens)
            response_received = True
            self.recorder.event('provider_response', {'message': reply, 'seconds': time.monotonic()-started,
                                                      'first_output_seconds': first, **timings})
            return reply
        except Exception as exc:
            # Recorder/budget failures are terminal; never let model recovery hide them.
            details = exception_details(exc)
            if details['code'].startswith('BENCHMARK_'):
                if details['code'] == 'BENCHMARK_RECORDING_FAILED':
                    self.control.recording_failed(exc, 'provider_recording')
                else:
                    if self.control.reason is None:
                        self.control.reason = details['code']
                    self.control.cancel.set()
            if details['code'] != 'BENCHMARK_TRACE_LIMIT':
                try:
                    self.recorder.event('provider_error', {**details, 'seconds': time.monotonic()-started,
                        'first_output_seconds': first, **timings, 'response_complete': response_received,
                        'stop_reason': self.control.reason or ('CANCELLED' if cancel.is_set() else None)})
                except Exception as recording_exc:
                    self.control.recording_failed(recording_exc, 'provider_error', original=exc)
            raise
        finally:
            self.request_deadline = old_deadline
            self.benchmark_observer = previous_observer
            self.control.provider = None
            self.recorder.scope = previous_scope


def failure_categories(entry):
    codes = [str(t.get('error_code', '')) for t in entry.get('turns', [])]
    codes += [str(err.get('code', '')) for t in entry.get('turns', []) for err in t.get('tool_errors', [])]
    categories = set()
    for code in codes:
        if any(word in code for word in ('CONTEXT', 'OUTPUT_LIMIT', 'TASK_LIMIT', 'NO_PROGRESS')):
            categories.add('budget_or_progress')
        elif any(word in code for word in ('TOOL', 'VALIDATION', 'STAGE_PROTOCOL')):
            categories.add('tool_or_workflow_contract')
        elif any(word in code.lower() for word in ('connection', 'timeout', 'authentication', 'ratelimit')):
            categories.add('transport_or_provider')
        elif code:
            categories.add('unknown')
    if not entry.get('passed') and any(not v for v in entry.get('checks', {}).values()):
        categories.add('independent_assertion_failed')
    return {'categories': sorted(categories), 'basis': 'Observed codes/checks; causal attribution requires trace analysis.'}


def execute_case(case, row, root, settings, key, catalog, recorder, control, progress):
    snapshot = fixture(root, case.get('setup', ''))
    if case.get('repair'):
        seed_failed_change(root, snapshot)
    initial_hashes = copy.deepcopy(snapshot['hashes'])
    state = SimpleNamespace(ledger=TaskLedger(), drafts={}, history=copy.deepcopy(case.get('history', [])))
    entry = {**row, 'id': row['case'], 'domain': case.get('domain', case['family']), 'turns': [], 'checks': {}}
    store = WorkflowStore(root / 'app/data/assistant')
    initial_task = None
    last_tools = None

    def turn(request, edit, resume=None):
        nonlocal last_tools, initial_task
        control.check()
        index = len(entry['turns'])+1
        recorder.scope.update(turn=index, stage_id=None, role=None)
        recorder.event('chat_input', {'request': request, 'history': state.history, 'can_edit': edit})
        record = {'request': request, 'can_edit': edit, 'calls': [], 'tools': []}
        tools = ToolSet(ProjectPolicy(root), SourceIndex(ProjectPolicy(root)), snapshot, settings,
                        control.cancel, can_edit=edit, ledger=TaskLedger(state.ledger.export()),
                        drafts=state.drafts, resume_task_id=resume)
        last_tools = tools
        def event(kind, value):
            if kind == 'model_request':
                recorder.scope['request_purpose'] = value.get('purpose', 'workflow')
            if kind == 'workflow_stage':
                recorder.scope.update(stage_id=value.get('stage_id'), role=value.get('role'))
                progress({'kind': 'stage', 'case': row['case'], 'turn': index, **value})
            try:
                recorder.event(kind, value)
            except Exception as exc:
                control.recording_failed(exc, kind)
                raise
            capture_workflow(record, kind, value)
            if kind == 'tool_started':
                record['tools'].append(value['name'])
            elif kind == 'tool_result':
                result = value['result']
                record['calls'].append({'tool': value['tool'], 'ok': result['ok'], 'code': result.get('code')})
                if not result['ok']:
                    record.setdefault('tool_errors', []).append({'tool': value['tool'], 'code': result.get('code'), 'message': result.get('message')})
            elif kind == 'model_assignments':
                record['model_assignments'] = value
            elif kind == 'response_model':
                record.setdefault('response_models', []).append(value)
            elif kind == 'usage':
                record.setdefault('usage', []).append(value)
            elif kind == 'workflow_outcome':
                progress({'kind': 'outcome', 'case': row['case'], 'turn': index, 'outcome': value})
            recorder.sample()
        provider = RecordingProvider(settings, key, recorder, control)
        provider.model_profiles = catalog
        workflow = SequentialWorkflow(provider, tools, event, control.cancel, store, row['case'])
        started = time.monotonic()
        try:
            record['answer'] = workflow.execute(copy.deepcopy(state.history), request)
            record['response'] = workflow.run.get('response')
            record['evidence'] = workflow.run.get('evidence_manifest', [])
            record['artifact_reviewed'] = workflow.run['status'] == 'awaiting_review'
            if case.get('background') and index > 1:
                active = tools.ledger.find(initial_task)
                tools.proposal = state.drafts.get(active['id'])
                record['artifact_reviewed'] = bool(tools.proposal and store.clearance(tools.proposal, active) is None)
        except Exception as exc:
            record.update(error=str(exc), error_code=exception_details(exc)['code'], error_details=exception_details(exc))
        finally:
            provider.dispose()
            record.update(seconds=time.monotonic()-started, model_calls=workflow.budget.model_calls,
                          stages=workflow.run['stages'], outcome=workflow.run.get('outcome'),
                          answer_reviews=workflow.run.get('answer_reviews', []), action_staged=tools.action is not None)
            if tools.proposal:
                record['candidate'] = [{'path': edit.path, 'content': edit.content} for edit in tools.proposal.edits]
            record['ledger'] = tools.ledger.export()
            entry['turns'].append(record)
            try:
                recorder.event('turn_completed', record)
            except Exception as exc:
                control.recording_failed(exc, 'turn_completed')
                raise
        state.ledger = TaskLedger(tools.ledger.export())
        if tools.proposal and state.ledger.find():
            state.drafts[state.ledger.find()['id']] = tools.proposal
        if initial_task is None and state.ledger.find():
            initial_task = state.ledger.find()['id']
        state.history.append({'role': 'user', 'content': request})
        if record.get('answer'):
            state.history.append({'role': 'assistant', 'content': record['answer']})
        if record.get('error') and case['family'] == 'dialogue':
            raise AssistantError(record['error_code'], record['error'])
        control.check()
        return tools

    started = time.monotonic()
    try:
        if case['family'] == 'dialogue':
            run_dialogue(case['id'], turn, state, entry, snapshot, root)
        elif case['family'] == 'reliability':
            for index, request in enumerate(case['turns']):
                modes = case.get('turn_modes')
                turn(request, modes[index] if modes else bool(case.get('edit')))
                if entry['turns'][-1].get('error') and not case.get('repair'):
                    break
            entry['checks'] = check_case(case, entry['turns'], last_tools, initial_hashes, root, initial_task)
        else:
            tools = turn(case['request'], case['edit'])
            record = entry['turns'][-1]
            entry['checks'] = score(case, tools, record.get('answer', ''), record['calls'])
            expected = case['expected']
            if any(k in expected for k in ('node', 'function', 'manifest', 'greeting_ui')):
                entry['completion_checks'] = completion_checks(record, tools.proposal.fingerprint if tools.proposal else None)
            elif 'answer_all' in expected:
                entry['completion_checks'] = answer_completion_checks(record)
    except Exception as exc:
        entry.update(error=str(exc), error_code=exception_details(exc)['code'], error_details=exception_details(exc))
    entry['host_checks'] = host_checks(entry['turns'])
    entry['preservation_checks'] = {'no_files_applied': all(file_hash(root/p) == h for p, h in initial_hashes.items())}
    actual_models = {stage.get('model') for t in entry['turns'] for stage in t.get('stages', [])
                     if stage.get('model') and stage.get('model_calls', 0) > 0}
    entry['actual_models'] = sorted(actual_models)
    entry['multi_model_exercised'] = len(actual_models) >= 2
    entry['property_passed'] = bool(entry['checks']) and all(entry['checks'].values())
    entry['passed'] = (entry['property_passed'] and bool(entry['turns']) and not entry.get('error')
        and not any(t.get('error') for t in entry['turns'])
        and all(entry['host_checks'].values()) and all(entry['preservation_checks'].values())
        and all(entry.get('completion_checks', {}).values()))
    stop_codes = {entry.get('error_code'), *(turn.get('error_code') for turn in entry['turns'])}
    entry['status'] = ('passed' if entry['passed'] else 'interrupted' if
                       stop_codes & {'BENCHMARK_DEADLINE', 'BENCHMARK_REQUEST_LIMIT', 'BENCHMARK_TRACE_LIMIT', 'CANCELLED'} else 'failed')
    entry['seconds'] = time.monotonic()-started
    entry['failure_analysis'] = failure_categories(entry)
    return entry


def run_benchmark(settings, key, options, output, cancel=None, progress=lambda value: None, secrets=()):
    """No GUI dependency. Called only inside a dedicated subprocess by the settings panel."""
    settings = copy.deepcopy(settings)
    settings.save_history = False
    settings.usage_headers = []  # Custom response headers may contain private server data.
    settings.settings_mode = 'advanced'  # Freeze already-resolved limits instead of reapplying presets.
    settings.advanced_limits = {}
    settings.validate()
    matrix = options.matrix()
    cancel = cancel or threading.Event()
    control = RunControl(options, cancel)
    sanitizer = Sanitizer((key, *secrets), paths=(str(APPLICATION_ROOT), str(Path.home())), endpoint=settings.base_url)
    recorder = Recorder(output, sanitizer, options.trace_mib*1024*1024)
    manifest = {'schema_version': SCHEMA_VERSION, 'suite_version': SUITE_VERSION, 'suite_fingerprint': suite_fingerprint(),
        'run_id': uuid.uuid4().hex, 'created_utc': utc_now(), 'options': options.manifest_options(), 'matrix': matrix,
        'settings': safe_settings(settings), 'environment': environment(),
        'implementation_fingerprint': digest([(p.relative_to(APPLICATION_ROOT).as_posix(), file_hash(p))
            for p in sorted((APPLICATION_ROOT/'app/assistant').rglob('*.py')) if '__pycache__' not in p.parts]),
        'cache_condition': 'Sequential paired cases; server cache and loading are uncontrolled. Mode order alternates by case and repetition.',
        'ordering_policy': 'paired_modes_alternating_order; limits candidates interleaved per row',
        'capture': 'Benchmark inputs/outputs only; exposed reasoning, no transport secrets or unrelated chat history.',
        'routing_preferences': settings.agent_models.get(settings.base_url, {}),
        'token_limit': 'Per-response output limit; provider usage may be absent. Run bounded by time, requests and trace bytes.',
        'sampling': 'Process CPU/RSS and available RAM, best effort. Remote server hardware unknown.'}
    manifest['initial_resources'] = resources()
    manifest['disk_free_bytes'] = shutil.disk_usage(recorder.folder).free
    cases, status, error = [], 'running', None
    def snapshot():
        return {**summarize(manifest, cases, status, error),
            'model_requests': control.requests, 'trace_bytes': recorder.bytes,
            'usage_and_tools': dict(recorder.metrics),
            **recorder.diagnostics(control.requests, status),
            'redactions': dict(sanitizer.counts), 'trace_complete': status == 'completed'}
    def persist():
        recorder.write('cases.json', cases)
        recorder.write('summary.json', snapshot())
    def fail(exc):
        nonlocal status, error
        code = exception_details(exc)['code']
        if control.reason is None and code.startswith('BENCHMARK_'):
            control.reason = code
        error = control.error(exc)
        limits = {'BENCHMARK_DEADLINE', 'BENCHMARK_REQUEST_LIMIT', 'BENCHMARK_TRACE_LIMIT'}
        status = ('limited' if control.reason in limits else 'failed' if control.reason
                  else 'cancelled' if cancel.is_set() else 'failed')
    recorder.write('manifest.json', manifest)
    persist()
    finished = threading.Event()
    def watchdog():
        last_progress = 0
        while not finished.wait(.2):
            try:
                recorder.sample()
                if time.monotonic()-last_progress >= 5:
                    last_progress = time.monotonic()
                    progress({'kind': 'heartbeat', 'elapsed_seconds': round(time.monotonic()-recorder.started, 1),
                              'requests': control.requests, 'resources': resources()})
            except Exception as exc:
                control.recording_failed(exc, 'host_sampling')
            if control.reason is None and time.monotonic() >= control.deadline:
                control.reason = 'BENCHMARK_DEADLINE'
                cancel.set()
            if cancel.is_set() and control.provider:
                try:
                    control.provider.close()
                except Exception:
                    pass
    watcher = threading.Thread(target=watchdog, daemon=True)
    watcher.start()
    try:
        progress({'kind': 'preflight', 'scheduled': len(matrix)})
        if shutil.disk_usage(recorder.folder).free < options.trace_mib*1024*1024*5 + 100*1024*1024:
            raise AssistantError('BENCHMARK_DISK', 'Insufficient free disk headroom for trace, report and synthetic fixtures.')
        provider = RecordingProvider(settings, key, recorder, control)
        control.provider = provider
        try:
            control.check()
            provider.request_deadline = min(control.deadline, time.monotonic()+options.probe_seconds)
            provider.models(cancel)
            manifest['discovery'] = {'optional_metadata_budget_exhausted': provider.discovery_metadata_budget_exhausted}
            provider.request_deadline = None
            catalog = copy.deepcopy(provider.model_profiles)
            control.check()
            if settings.model not in catalog:
                raise AssistantError('BENCHMARK_MODEL', 'The configured model was not returned by server discovery.')
            # Probe only the selected primary and explicit roles; auto routing can use the catalog.
            preferences = settings.agent_models.get(settings.base_url, {})
            selected = {settings.model}
            if options.mode != 'single':
                selected.update(preferences.values() if preferences else catalog.keys())
            catalog = {name: profile for name, profile in catalog.items() if name in selected}
            for name, profile in catalog.items():
                provider.settings = stage_settings(settings, profile)
                if (profile.get('tool_round_trip') is False
                        and profile.get('streaming', provider.settings.streaming) == provider.settings.streaming):
                    profile['probe_skipped'] = 'Server explicitly advertises structured tools unsupported.'
                    continue
                probe_deadline = min(control.deadline, time.monotonic()+options.probe_seconds)
                provider.request_deadline = probe_deadline
                try:
                    provider.probe(cancel)
                    profile['tool_round_trip'] = True
                except Exception as exc:
                    control.check()
                    profile.update(tool_round_trip=False, probe_error=exception_details(exc))
                finally:
                    provider.request_deadline = None
                profile['streaming'] = provider.settings.streaming
        finally:
            control.provider = None
            provider.dispose()
        manifest['catalog'] = catalog
        recorder.write('manifest.json', manifest)
        eligible = [name for name, profile in catalog.items() if profile.get('tool_round_trip') is True]
        all_cases = registry()
        with tempfile.TemporaryDirectory(prefix='sakir-benchmark-') as temporary:
            sanitizer.replacements[temporary] = '<benchmark-fixture>'
            base = Path(temporary)/'template'
            export_fixture(base)
            for index, row in enumerate(matrix):
                control.check()
                recorder.scope = {'case': row['case'], 'mode': row['mode'], 'repetition': row['repetition']}
                progress({'kind': 'case_started', 'index': index+1, 'scheduled': len(matrix), **row,
                          'requests': control.requests})
                if settings.model not in eligible or row['mode'] == 'multi' and len(eligible) < 2:
                    cases.append({**row, 'id': row['case'], 'passed': False, 'status': 'unsupported', 'seconds': 0,
                                  'error': 'Structured tools unsupported for primary model or fewer than two verified models.'})
                else:
                    root = Path(temporary)/('case-'+str(index))
                    shutil.copytree(base, root)
                    effective = copy.deepcopy(settings)
                    effective.multi_model = row['mode'] == 'multi'
                    if row.get('candidate') == 'fewer_rounds':
                        effective.max_rounds = max(1, settings.max_rounds//2)
                    elif row.get('candidate') == 'more_rounds':
                        effective.max_rounds = min(40, settings.max_rounds+max(1, settings.max_rounds//2))
                    effective.capability_profile = catalog[settings.model]
                    advertised = effective.capability_profile.get('context_tokens', 0)
                    if advertised:
                        effective.context_tokens = min(effective.context_tokens, advertised) if effective.context_tokens else advertised
                    effective.validate()
                    entry = execute_case(all_cases[row['case']], row, root, effective, key,
                                         {name: catalog[name] for name in eligible}, recorder, control, progress)
                    if row.get('candidate'):
                        entry['candidate_settings'] = {'max_rounds': effective.max_rounds}
                    cases.append(entry)
                    if root.resolve().parent != Path(temporary).resolve() or root.is_symlink():
                        raise AssistantError('BENCHMARK_FIXTURE', 'Unexpected fixture cleanup path.')
                    shutil.rmtree(root)
                persist()
                progress({'kind': 'case_completed', 'id': cases[-1]['id'], 'passed': cases[-1]['passed'],
                          'status': cases[-1]['status'], 'executed': len(cases), 'scheduled': len(matrix),
                          'requests': control.requests})
                control.check()
        status = 'completed'
    except Exception as exc:
        fail(exc)
    finally:
        finished.set()
        watcher.join(timeout=1)
        if status == 'completed':
            try:
                control.check()
            except Exception as exc:
                fail(exc)
        try:
            persist()
            render_report(output)
        except Exception as exc:
            control.recording_failed(exc, 'finalization')
            fail(exc)
            try:
                persist()  # Best effort: do not leave an earlier completed summary after HTML/save failure.
            except Exception:
                pass
            raise
        progress(sanitizer.clean({'kind': 'finished', 'status': status, 'error': error, 'executed': len(cases), 'scheduled': len(matrix)}))
    return sanitizer.clean(snapshot())
