"""Versioned suite coverage and explicit run limits."""
from dataclasses import asdict, dataclass
from ..policy import AssistantError, digest
from .assistant_task_cases import task_cases, session_cases
from .assistant_reliability_cases import cases as reliability_cases

SUITE_VERSION = 2
QUICK = ('task:exact', 'task:callback_reading', 'task:data_columns', 'reliability:hello_how_are_you', 'dialogue:mode')
STANDARD = QUICK + ('task:top_right', 'task:center', 'task:data_binary', 'task:output_html',
                    'session:session_new_greeting_tab', 'session:session_retry_greeting_tab',
                    'session:session_permission_greeting_tab', 'dialogue:format', 'dialogue:optional',
                    'reliability:callback_contract', 'reliability:callback_edit')


def registry():
    result = {}
    for family, cases in (('task', task_cases()), ('session', session_cases()), ('reliability', reliability_cases())):
        for case in cases:
            result[f'{family}:{case["id"]}'] = {'family': family, **case}
    for name in ('format', 'optional', 'mode'):
        result[f'dialogue:{name}'] = {'family': 'dialogue', 'id': name, 'domain': 'dialogue'}
    return result


@dataclass
class BenchmarkOptions:
    level: str = 'quick'
    mode: str = 'single'
    repetitions: int = 1
    run_seconds: int = 600
    max_requests: int = 300
    trace_mib: int = 64
    probe_seconds: int = 60

    def validate(self):
        if self.level not in {'quick', 'standard', 'full', 'limits'} or self.mode not in {'single', 'multi', 'compare'}:
            raise AssistantError('BENCHMARK_OPTIONS', 'Choose a valid benchmark level and model mode.')
        for name, low, high in (('repetitions', 1, 10), ('run_seconds', 30, 43200),
                                ('max_requests', 1, 100000), ('trace_mib', 1, 1024), ('probe_seconds', 1, 300)):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= high:
                raise AssistantError('BENCHMARK_OPTIONS', f'Invalid {name}.')

    def matrix(self):
        self.validate()
        cases = registry()
        selected = QUICK if self.level == 'quick' else STANDARD if self.level == 'standard' else tuple(cases)
        missing = set(selected)-cases.keys()
        if missing:
            raise AssistantError('BENCHMARK_SUITE', 'Unknown preset cases: '+', '.join(sorted(missing)))
        modes = ['single', 'multi'] if self.mode == 'compare' else [self.mode]
        if self.level == 'limits':
            selected = QUICK
        matrix = [{'case': case, 'mode': mode, 'repetition': repeat}
                for repeat in range(self.repetitions)
                for index, case in enumerate(selected)
                for mode in (modes if (repeat+index) % 2 == 0 else list(reversed(modes)))]
        if self.level == 'limits':
            matrix = [{**row, 'candidate': candidate, 'partition': 'validation' if row['case'] in QUICK[-2:] else 'calibration'}
                      for index, row in enumerate(matrix)
                      for candidate in (('current', 'fewer_rounds', 'more_rounds') if index % 2 == 0 else
                                        ('more_rounds', 'fewer_rounds', 'current'))]
        return matrix

    def manifest_options(self):
        return asdict(self)


def suite_fingerprint():
    from pathlib import Path
    folder = Path(__file__).parent
    files = {p.name: digest(p.read_bytes()) for p in sorted(folder.glob('*.py'))}
    return digest(files)
