import os, json, re
import importlib.util
import keyword
import sys
import types
import warnings

def is_frozen() -> bool:
    return getattr(sys, 'frozen', False)

def get_project_root() -> str:
    """
    Root finder with required behavior:

    - Pure Python: project folder containing the app package
    - PyInstaller onefile: folder containing the .exe
    - PyInstaller onedir: <exe_dir>/_internal (or _internals if used)

    Notes:
    - In PyInstaller, sys.executable points to the exe path.
    - In onefile, sys._MEIPASS exists but we IGNORE it for root (you want exe dir).
    """
    # -------------------- PYINSTALLER --------------------
    if is_frozen():
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))

        internal = os.path.join(exe_dir, "_internal")
        internals = os.path.join(exe_dir, "_internals")

        if os.path.isdir(internal):
            return internal
        if os.path.isdir(internals):
            return internals

        # onefile
        return exe_dir

    # -------------------- PURE PYTHON --------------------
    # utils.py lives in <project_root>/app, so the project root is its parent.
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

PROJECT_ROOT = get_project_root()

HISTORY_PATH = os.path.join(PROJECT_ROOT, r'app\data\history.json')
CALLBACKS_PATH = os.path.join(PROJECT_ROOT, r'callbacks\callbacks.py')
CB_STUBS_PATH = os.path.join(PROJECT_ROOT, r'app\stubs.py')
CONFIG_PATH = os.path.join(PROJECT_ROOT, r'app\data\config.json')
FTP_SERVER_SETTINGS = os.path.join(PROJECT_ROOT, r'app\data\ftp_server.json')
FTP_CLIENT_SETTINGS = os.path.join(PROJECT_ROOT, r'app\data\ftp_client.json')
SERIAL_SETTINGS = os.path.join(PROJECT_ROOT, r'app\data\serial.json')
TELNET_SETTINGS = os.path.join(PROJECT_ROOT, r'app\data\telnet.json')
COMMUNICATION_HUB_SETTINGS = os.path.join(PROJECT_ROOT, r'app\data\communication_hub.json')
BUILD_SETTINGS = os.path.join(PROJECT_ROOT, r'app\data\build.json')
HELP_PATH = os.path.join(PROJECT_ROOT, r'app\data\help.json')
CALLBACK_DEF_RE = re.compile(
    r"^def\s+(btn_[A-Za-z0-9_]+_callback)\s*\([^)]*\):",
    flags=re.M
)

# ---------- JSON helpers ----------
def load_json(path: str):
    if not os.path.exists(path):
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except Exception:
            return {}

def save_json(path: str, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    # These persisted sources define developer-facing callback completions.
    # Import lazily to avoid a utils <-> stub_generator import cycle.
    if os.path.normcase(os.path.abspath(path)) in {
        os.path.normcase(os.path.abspath(CONFIG_PATH)),
        os.path.normcase(os.path.abspath(SERIAL_SETTINGS)),
        os.path.normcase(os.path.abspath(TELNET_SETTINGS)),
        os.path.normcase(os.path.abspath(FTP_SERVER_SETTINGS)),
        os.path.normcase(os.path.abspath(COMMUNICATION_HUB_SETTINGS)),
    }:
        try:
            from app.stub_generator import regenerate_stubs
            is_config = (
                os.path.normcase(os.path.abspath(path))
                == os.path.normcase(os.path.abspath(CONFIG_PATH))
            )
            regenerate_stubs(data if is_config else None)
        except Exception as error:
            # The primary settings write has already succeeded. Keep the last
            # valid atomic stub and reconcile again on the next save/startup.
            warnings.warn(f"Could not refresh callback stubs: {error}", RuntimeWarning)


def resolve_callback_tool_symbols():
    """Return runtime Tool objects without making their module a public boundary."""
    from app.tool_api import (
        Tools, ToolsProxy, ToolCallFuture, ToolSubscription,
        ToolUnavailableError, FTPClientAPI, FTPServerAPI, SerialAPI,
        SerialSessionAPI, TelnetAPI, TelnetSessionAPI,
        CommunicationAPI, CommunicationSessionAPI,
        ProtocolInsightAPI,
    )
    from app.tools.communication_hub.message_stream import MessageSubscription
    return {
        "Tools": Tools,
        "ToolsProxy": ToolsProxy,
        "ToolCallFuture": ToolCallFuture,
        "ToolSubscription": ToolSubscription,
        "MessageSubscription": MessageSubscription,
        "ToolUnavailableError": ToolUnavailableError,
        "FTPClientAPI": FTPClientAPI,
        "FTPServerAPI": FTPServerAPI,
        "SerialAPI": SerialAPI,
        "SerialSessionAPI": SerialSessionAPI,
        "TelnetAPI": TelnetAPI,
        "TelnetSessionAPI": TelnetSessionAPI,
        "CommunicationAPI": CommunicationAPI,
        "CommunicationSessionAPI": CommunicationSessionAPI,
        "ProtocolInsightAPI": ProtocolInsightAPI,
    }

def ensure_history():
    if not os.path.exists(HISTORY_PATH):
        with open(HISTORY_PATH, 'w', encoding='utf-8') as f:
            f.write('{"buttons": {}}')

def _empty_callbacks_module():
    """Return a no-write callback shell for explicitly degraded startup."""
    from app.globals_api import GlobalsBase
    from app.lifecycle import LifecycleManager

    module = types.ModuleType("callbacks")

    class Globals(GlobalsBase):
        def init_globals(self):
            pass

    type.__setattr__(Globals, "__module__", module.__name__)
    module.Globals = Globals
    module.__lifecycle_registration__ = LifecycleManager.registration_scope("callbacks")
    return module

def load_callbacks(*, degraded_startup: bool = False):
    if not os.path.exists(CALLBACKS_PATH):
        if degraded_startup:
            return _empty_callbacks_module()
        raise FileNotFoundError(
            f"Required callback module was not found: {CALLBACKS_PATH}"
        )
    spec = importlib.util.spec_from_file_location('callbacks', CALLBACKS_PATH)
    mod = importlib.util.module_from_spec(spec)
    from app.lifecycle import LifecycleManager
    registration = LifecycleManager.registration_scope("callbacks")
    # Match Python's normal import protocol: decorators and annotation tools
    # (notably dataclasses on Python 3.14) may resolve the module through
    # sys.modules while its body is executing.  Preserve the previous module
    # so a broken callback candidate cannot replace the last importable one.
    previous_module = sys.modules.get(spec.name)
    sys.modules[spec.name] = mod
    try:
        with registration:
            # Always execute the current source, independent of pyc timestamps.
            with open(CALLBACKS_PATH, "rb") as source:
                exec(compile(source.read(), str(CALLBACKS_PATH), "exec"), mod.__dict__)
    except Exception as e:
        if previous_module is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous_module
        raise RuntimeError(f"Error in callbacks.py: {e}")
    mod.__lifecycle_registration__ = registration
    return mod

def load_callbacks_as_file():
    if not os.path.exists(CALLBACKS_PATH):
        from app.starter_project import default_callbacks_source
        return default_callbacks_source()
    with open(CALLBACKS_PATH, "r", encoding="utf-8") as f:
        content = f.read()
    return content

def save_callbacks_as_file(content):
    with open(CALLBACKS_PATH, "w", encoding="utf-8") as f:
        f.write(content.strip() + "\n")

def safe_get(d, k, default=None):
    if isinstance(d, dict):
        v = d.get(k)
        return default if v is None else v
    return default

def sanitize_func_name(name: str) -> str:
    """
    Convert any button name into a safe Python function identifier.
    Example: 'Ask Info (v2)' -> 'btn_ask_info_v2_callback'
    """
    safe = re.sub(r'[^0-9a-zA-Z_]+', '_', name.strip())
    safe = re.sub(r'_+', '_', safe).strip('_')
    if not safe:
        safe = "unnamed"
    if keyword.iskeyword(safe):
        safe = f"{safe}_button"
    return f"btn_{safe.lower()}_callback"

def create_func_pattern(func_name, compile = True):
    safe_name = re.escape(func_name.strip())
    pattern = rf"^\s*def\s+{safe_name}\s*\(.*\)\s*:"
    if compile:
        return re.compile(pattern)
    else:
        return pattern

def set_widow_feature(key:str, value):
    cfg = load_json(CONFIG_PATH)
    cfg.setdefault("window", {})[key] = value
    save_json(CONFIG_PATH, cfg)
