"""Transactional callback/external imports and editor-independent source watching."""

from __future__ import annotations

import importlib
import atexit
import json
import os
import sys
import hashlib
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

from PyQt5 import QtCore
from app.global_store import AppGlobals, stage_values
from app.reload_effects import (
    ReloadEffects, resource_disposer, resource_widget, retained_identities, borrowed,
)


def source_manifest(project_root, callbacks_path=None):
    root = Path(project_root)
    callback = Path(callbacks_path) if callbacks_path else root / "callbacks" / "callbacks.py"
    paths = [callback, *sorted((root / "externals").rglob("*.py"))]
    result = {}
    for path in paths:
        try:
            result[path.resolve()] = hashlib.sha256(path.read_bytes()).hexdigest()
        except FileNotFoundError:
            result[path.resolve()] = None
    return result


@dataclass
class ReloadRequest:
    generation: int
    paths: set = field(default_factory=set)
    quiet: bool = False
    rebuild_ui: object = None
    waiting_since: float | None = None


class ReloadScheduler(QtCore.QObject):
    """One serial admission queue for manual, source, designer and Assistant reloads."""
    def __init__(self, runtime, start, parent=None):
        super().__init__(parent)
        self.runtime = runtime
        self.start = start
        self.active = None
        self.pending = None
        self.stopped = False
        self.serial = runtime.generation + (runtime.current_callbacks is None)
        runtime.reload_finished.connect(self._finished)
        runtime.ready.connect(lambda _: self._schedule())
        runtime.initialization_failed.connect(self._initialization_failed)

    @property
    def busy(self):
        return self.active is not None or self.pending is not None

    def submit(self, *, changed_paths=(), quiet=False, rebuild_ui=None):
        if self.stopped:
            raise RuntimeError("Application shutdown is in progress")
        if self.runtime.current_callbacks is None and self.runtime.registry.state == "FAILED":
            raise RuntimeError("Initial startup failed; fix the startup error and restart the application")
        if self.pending is None:
            self.serial = max(self.serial, self.runtime.generation) + 1
            self.pending = ReloadRequest(self.serial)
        self.pending.paths.update(changed_paths)
        self.pending.quiet = self.pending.quiet or quiet
        if rebuild_ui is not None:
            self.pending.rebuild_ui = rebuild_ui
        self._schedule()
        return self.pending.generation

    def _schedule(self):
        QtCore.QTimer.singleShot(0, self._drain)

    def _drain(self):
        if self.stopped or self.active is not None or self.pending is None:
            return
        if self.runtime._operation is not None or self.runtime._pending_start is not None:
            return
        if self.runtime.has_callback_jobs() or any(worker.isRunning() for worker in self.runtime._workers):
            if self.pending.waiting_since is None:
                self.pending.waiting_since = time.monotonic()
            if time.monotonic() - self.pending.waiting_since > 5:
                self.active, self.pending = self.pending, None
                self.runtime.initialization_failed.emit(
                    self.active.generation,
                    "Reload could not drain background work within 5 seconds. "
                    "The working runtime was retained; finish the task or restart the application.")
                self.runtime.reload_finished.emit(self.active.generation, False)
            else:
                QtCore.QTimer.singleShot(25, self._drain)
            return
        self.active, self.pending = self.pending, None
        try:
            self.start(self.active)
        except Exception:
            generation = self.active.generation
            self.runtime.initialization_failed.emit(generation, traceback.format_exc())
            self.runtime.reload_finished.emit(generation, False)

    def _finished(self, generation, succeeded):
        if self.active is not None and self.active.generation == generation:
            self.active = None
        self._schedule()

    def _initialization_failed(self, generation, details):
        if self.runtime.current_callbacks is None and self.active is None and self.pending is not None:
            pending, self.pending = self.pending, None
            self.runtime.reload_finished.emit(pending.generation, False)

    def stop(self):
        self.stopped = True
        pending, self.pending = self.pending, None
        if pending is not None:
            self.runtime.reload_finished.emit(pending.generation, False)


def automatic_source_reload_enabled(project_root) -> bool:
    """Read the supervisor preference; missing or invalid values default off."""
    path = Path(project_root) / "designer" / "settings.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return isinstance(payload, dict) and payload.get("automatic_source_reload") is True


class CallbackImportTransaction:
    """Stage callback-owned imports and publish them only after runtime success."""

    def __init__(self, project_root: Path, callbacks_path: Path, changed_paths=()):
        self.project_root = project_root.resolve()
        self.callbacks_path = callbacks_path.resolve()
        self.externals_root = (self.project_root / "externals").resolve()
        self.changed_paths = tuple(Path(path).resolve() for path in changed_paths)
        self.previous: dict[str, object] = {}
        self.candidate: dict[str, object] = {}
        self._staged = False
        self._active = False
        self.effects = ReloadEffects()
        self.allocations = []
        self.global_writes = {}
        self.global_removals = set()
        self.plain_clones = {}
        self.manifest = None

    def _is_managed(self, name: str, module) -> bool:
        if name == "callbacks" or name == "externals" or name.startswith("externals."):
            return True
        filename = getattr(module, "__file__", "")
        if not filename:
            return False
        try:
            path = Path(filename).resolve()
        except OSError:
            return False
        return path == self.callbacks_path or path == self.externals_root or self.externals_root in path.parents

    def _managed_modules(self) -> dict[str, object]:
        return {
            name: module
            for name, module in tuple(sys.modules.items())
            if module is not None and self._is_managed(name, module)
        }

    def _clear_managed(self) -> None:
        for name, module in tuple(sys.modules.items()):
            if module is not None and self._is_managed(name, module):
                sys.modules.pop(name, None)

    def stage(self):
        from app.utils import load_callbacks

        self.manifest = source_manifest(self.project_root, self.callbacks_path)
        for path in self.changed_paths:
            if path.suffix.lower() == ".py" and path.exists():
                compile(path.read_bytes(), str(path), "exec")

        # Timestamp-based pycs cannot distinguish same-size saves within a
        # second. Clear every managed source cache, including dependencies.
        sources = [self.callbacks_path]
        if self.externals_root.exists():
            sources.extend(self.externals_root.rglob("*.py"))
        for source in sources:
            cache = Path(importlib.util.cache_from_source(str(source)))
            cache.unlink(missing_ok=True)

        importlib.invalidate_caches()
        self.previous = self._managed_modules()
        self._clear_managed()
        previous_values = AppGlobals.snapshot()
        staged_values, self.plain_clones = stage_values(previous_values, AppGlobals._spec_snapshot())
        try:
            with AppGlobals._staging_scope(staged_values, self.allocations), self.effects.scope():
                callbacks = load_callbacks()
            self.candidate = self._managed_modules()
            if source_manifest(self.project_root, self.callbacks_path) != self.manifest:
                raise RuntimeError("Source changed while imports were being staged; reload again")
        except Exception as error:
            self._clear_managed()
            sys.modules.update(self.previous)
            self.effects.rollback()
            keep = retained_identities(previous_values.values())
            seen = set()
            resources = [item[1] for item in self.allocations] + self.effects.resources
            wrapped = {id(widget) for value in resources if not isinstance(value, QtCore.QObject)
                       and (widget := resource_widget(value)) is not None}
            for value in resources:
                if isinstance(value, QtCore.QObject) and id(value) in wrapped:
                    continue
                if id(value) not in keep | seen and not borrowed(value):
                    seen.add(id(value))
                    disposer = resource_disposer(value)
                    if disposer is not None:
                        try:
                            disposer(value)
                        except Exception as cleanup_error:
                            error.add_note(f"Import resource cleanup failed: {cleanup_error}")
            raise
        assigned = {name for name, _ in self.allocations}
        self.global_writes = {name: value for name, value in staged_values.items()
                              if name not in previous_values or name in assigned
                              or (id(value) in self.plain_clones and
                                  repr(value) != repr(previous_values[name]))}
        self.global_removals = set(previous_values) - set(staged_values)
        self._clear_managed()
        sys.modules.update(self.previous)
        self._staged = True
        return callbacks

    def activate(self) -> None:
        """Make candidate imports available after old unload hooks finish."""
        if self._staged and not self._active:
            self._clear_managed()
            sys.modules.update(self.candidate)
            self._active = True

    def commit(self) -> None:
        if not self._staged:
            return
        if self._active:
            self.candidate = self._managed_modules()
        self._clear_managed()
        sys.modules.update(self.candidate)
        self._staged = False
        self._active = False
        # Do not retain a linked list of every previous callback generation.
        self.previous.clear()
        self.candidate.clear()
        self.global_writes.clear()
        self.global_removals.clear()
        self.plain_clones.clear()
        self.allocations.clear()

    def rollback(self) -> None:
        if not self._staged:
            return
        self._clear_managed()
        sys.modules.update(self.previous)
        self._staged = False
        self._active = False


class _SourceWatchWorker(QtCore.QObject):
    """Own scanning, native watches, and timers entirely in the worker thread."""

    changed = QtCore.pyqtSignal(object)
    ready = QtCore.pyqtSignal()

    def __init__(self, project_root: Path, debounce_ms: int):
        super().__init__()
        self.project_root = project_root
        self.callbacks_path = self.project_root / "callbacks" / "callbacks.py"
        self.externals_root = self.project_root / "externals"
        self._debounce_ms = debounce_ms
        self._snapshot = {}
        self._scan_queued = False
        self._pending: set[Path] = set()

    @QtCore.pyqtSlot()
    def start(self):
        if self.thread().isInterruptionRequested():
            return
        self._watcher = QtCore.QFileSystemWatcher(self)
        self._watcher.fileChanged.connect(self._filesystem_changed)
        self._watcher.directoryChanged.connect(self._filesystem_changed)
        self._debounce = QtCore.QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(self._debounce_ms)
        self._debounce.timeout.connect(self._emit_pending)
        self._poll = QtCore.QTimer(self)
        self._poll.setInterval(750)
        self._poll.timeout.connect(self._rescan)
        self._snapshot, desired = self._scan()
        if self.thread().isInterruptionRequested():
            return
        self._refresh_watches(desired)
        self._poll.start()
        self.ready.emit()

    def _scan(self):
        # A single traversal discovers both files and watchable directories.
        result = {}
        desired = {str(self.project_root)}
        if self.callbacks_path.parent.is_dir():
            desired.add(str(self.callbacks_path.parent))

        def record(path):
            try:
                stat = path.stat()
                result[path.resolve()] = (stat.st_mtime_ns, stat.st_size)
            except OSError:
                return
            desired.add(str(path))

        record(self.callbacks_path)
        for directory, subdirs, filenames in os.walk(self.externals_root):
            if self.thread().isInterruptionRequested():
                break
            subdirs[:] = [name for name in subdirs if name != "__pycache__"]
            desired.add(directory)
            for filename in filenames:
                if self.thread().isInterruptionRequested():
                    break
                if filename.lower().endswith(".py"):
                    record(Path(directory) / filename)
        return result, desired

    def _refresh_watches(self, desired) -> None:
        existing = set(self._watcher.files()) | set(self._watcher.directories())
        remove = list(existing - desired)
        add = list(desired - existing)
        if remove:
            self._watcher.removePaths(remove)
        if add:
            self._watcher.addPaths(add)

    def _filesystem_changed(self, _path: str) -> None:
        # Several native events for one save coalesce into one queued scan.
        if not self._scan_queued:
            self._scan_queued = True
            QtCore.QTimer.singleShot(0, self._rescan)

    @QtCore.pyqtSlot()
    def _rescan(self) -> None:
        self._scan_queued = False
        if self.thread().isInterruptionRequested():
            return
        current, desired = self._scan()
        if self.thread().isInterruptionRequested():
            return
        changed = {
            path for path in set(self._snapshot) | set(current)
            if self._snapshot.get(path) != current.get(path)
        }
        self._snapshot = current
        if changed:
            self._pending.update(changed)
            self._debounce.start()
        self._refresh_watches(desired)

    def _emit_pending(self) -> None:
        if not self._pending or self.thread().isInterruptionRequested():
            return
        paths = tuple(sorted(self._pending, key=lambda path: os.path.normcase(str(path))))
        self._pending.clear()
        self.changed.emit(paths)


# Threads must outlive their facade when its QObject parent is destroyed in
# the middle of a scan. Keep ownership here until the worker actually exits.
_watch_threads = set()


def _finish_watch_threads():
    threads = tuple(_watch_threads)
    for thread in threads:
        thread.requestInterruption()
        thread.quit()
    for thread in threads:
        thread.wait()


atexit.register(_finish_watch_threads)


class SourceReloadWatcher(QtCore.QObject):
    """UI-thread facade; only change notifications cross from the worker."""

    changed = QtCore.pyqtSignal(object)
    ready = QtCore.pyqtSignal()
    _scan_requested = QtCore.pyqtSignal()

    def __init__(self, project_root: Path, parent=None, debounce_ms: int = 500):
        super().__init__(parent)
        self.project_root = project_root.resolve()
        self._stopped = False
        self._thread = QtCore.QThread()
        self._thread.setObjectName("SourceReloadWatcher")
        self._worker = _SourceWatchWorker(self.project_root, debounce_ms)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.start)
        self._worker.changed.connect(self._deliver_changes, QtCore.Qt.QueuedConnection)
        self._worker.ready.connect(self.ready, QtCore.Qt.QueuedConnection)
        self._scan_requested.connect(self._worker._rescan, QtCore.Qt.QueuedConnection)
        self._thread.finished.connect(self._worker.deleteLater)
        thread = self._thread
        _watch_threads.add(thread)
        thread.finished.connect(lambda: _watch_threads.discard(thread))
        # Do not parent the running QThread to this facade: deletion can happen
        # before an in-progress filesystem call has returned.
        self.destroyed.connect(lambda: (thread.requestInterruption(), thread.quit()))
        application = QtCore.QCoreApplication.instance()
        if application is not None:
            application.aboutToQuit.connect(self.stop)
        self._thread.start()

    @QtCore.pyqtSlot(object)
    def _deliver_changes(self, paths):
        if not self._stopped:
            self.changed.emit(paths)

    def _rescan(self):
        if not self._stopped:
            self._scan_requested.emit()

    @QtCore.pyqtSlot()
    def stop(self):
        """Cancel without waiting for disk I/O on the UI thread."""
        self._stopped = True
        self._thread.requestInterruption()
        self._thread.quit()
