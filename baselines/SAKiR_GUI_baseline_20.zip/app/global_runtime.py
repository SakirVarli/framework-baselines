"""Qt-aware orchestration for Globals declarations and lifecycle phases."""

from __future__ import annotations

import asyncio
import inspect
import threading
import traceback
import weakref
from contextlib import nullcontext, contextmanager
from typing import Any, Callable, Dict, Iterable, Mapping

from PyQt5 import QtCore

from app.global_store import AppGlobals, GlobalRegistry, stage_values, publish_plain_state
from app.globals_api import (
    AppGlobalDefinitionError,
    AsyncLazy,
    GlobalSpec,
    GlobalsBase,
    ReloadPolicy,
    _looks_like_widgetish,
    _normalize_declaration,
)
from app.lifecycle import HookRecord, LifecycleManager, LifecycleRegistration
from app.reload_effects import (
    ReloadEffects, borrowed, resource_disposer, resource_widget,
    retained_identities,
    execution_scope, StaleGenerationError,
)


class _AsyncCallWorker(QtCore.QThread):
    """Run one callable/awaitable on a cancellable worker-owned event loop."""

    completed = QtCore.pyqtSignal(int, object)
    failed = QtCore.pyqtSignal(int, str)
    cancelled = QtCore.pyqtSignal(int)

    def __init__(
        self,
        generation: int,
        producer: Callable[[], Any],
        *,
        cancel_on_generation: bool = True,
    ):
        super().__init__()
        self.generation = int(generation)
        self._producer = producer
        self.cancel_on_generation = bool(cancel_on_generation)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._task: asyncio.Task | None = None
        self._guard = threading.RLock()

    async def _run_value(self) -> Any:
        value = self._producer()
        return await value if inspect.isawaitable(value) else value

    def run(self) -> None:
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            with self._guard:
                self._loop = loop
            task = loop.create_task(self._run_value())
            with self._guard:
                self._task = task
            result = loop.run_until_complete(task)
            self.completed.emit(self.generation, result)
        except asyncio.CancelledError:
            self.cancelled.emit(self.generation)
        except Exception:
            self.failed.emit(self.generation, traceback.format_exc())
        finally:
            with self._guard:
                loop = self._loop
                self._loop = None
                self._task = None
            if loop is not None:
                try:
                    pending = asyncio.all_tasks(loop)
                    for task in pending:
                        task.cancel()
                    if pending:
                        loop.run_until_complete(
                            asyncio.gather(*pending, return_exceptions=True)
                        )
                finally:
                    loop.close()

    def request_cancel(self) -> None:
        self.requestInterruption()
        with self._guard:
            loop = self._loop
            task = self._task
        if loop is not None and task is not None and not task.done():
            loop.call_soon_threadsafe(task.cancel)


class _AsyncGlobalsWorker(QtCore.QThread):
    """Resolve async declarations sequentially for one runtime generation."""

    completed = QtCore.pyqtSignal(int, dict)
    failed_with_results = QtCore.pyqtSignal(int, str, dict)
    cancelled = QtCore.pyqtSignal(int)

    def __init__(self, pending_async: Mapping[str, Any], generation: int = 0):
        super().__init__()
        self._pending_async = dict(pending_async)
        self.generation = int(generation)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._task: asyncio.Task | None = None
        self._guard = threading.RLock()
        self._partial_results: Dict[str, Any] = {}
        self._staging_registry: GlobalRegistry | None = None
        self._staging_values: Dict[str, Any] | None = None
        self.effects = None
        self.allocations = None
        self.protected = set()
        self.released = {}

    def set_staging_registry(
        self, registry: GlobalRegistry, values: Dict[str, Any]
    ) -> None:
        self._staging_registry = registry
        self._staging_values = values

    async def _runner(self) -> Dict[str, Any]:
        results: Dict[str, Any] = {}
        for name, declaration in self._pending_async.items():
            if self.isInterruptionRequested():
                raise asyncio.CancelledError
            spec = (
                _normalize_declaration(declaration)
                if isinstance(declaration, AsyncLazy) else declaration
            )
            factory = getattr(spec, "factory", None)
            if not callable(factory):
                raise TypeError(f"Async global {name!r} has no callable factory")
            try:
                produced = factory()
                if inspect.isawaitable(produced):
                    timeout = getattr(spec, "timeout", None)
                    produced = (
                        await asyncio.wait_for(produced, timeout)
                        if timeout is not None else await produced
                    )
                if _looks_like_widgetish(produced):
                    raise RuntimeError(
                        "returned a Qt object or Qt-backed wrapper; use lazy(...) "
                        "for main-thread resources"
                    )
                results[name] = produced
                self._partial_results[name] = produced
            except asyncio.CancelledError:
                raise
            except Exception as error:
                label = f" ({spec.label})" if getattr(spec, "label", "") else ""
                raise RuntimeError(
                    f"Async global {name!r}{label} failed during worker "
                    f"initialization: {error}"
                ) from error
        return results

    async def _dispose_partial_results(self) -> None:
        for name, value in reversed(list(self._partial_results.items())):
            declaration = self._pending_async.get(name)
            spec = (
                _normalize_declaration(declaration)
                if isinstance(declaration, AsyncLazy) else declaration
            )
            disposer = getattr(spec, "dispose", None)
            if (not callable(disposer) or not spec.owned or borrowed(value)
                    or id(value) in self.protected or id(value) in self.released):
                continue
            self.released[id(value)] = value
            try:
                result = disposer(value)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                pass

    def run(self) -> None:
        loop = None
        try:
            loop = asyncio.new_event_loop()
            with self._guard:
                self._loop = loop
            asyncio.set_event_loop(loop)
            task = loop.create_task(self._runner())
            with self._guard:
                self._task = task
            scope = (
                self._staging_registry._staging_scope(self._staging_values, self.allocations)
                if self._staging_registry is not None
                and self._staging_values is not None
                else nullcontext()
            )
            with scope, (self.effects.scope() if self.effects is not None else nullcontext()):
                results = loop.run_until_complete(task)
            self.completed.emit(self.generation, results)
        except asyncio.CancelledError:
            if loop is not None:
                try:
                    loop.run_until_complete(self._dispose_partial_results())
                except Exception:
                    pass
            self.cancelled.emit(self.generation)
        except Exception:
            self.failed_with_results.emit(
                self.generation, traceback.format_exc(), dict(self._partial_results)
            )
        finally:
            with self._guard:
                loop = self._loop
                self._task = None
                self._loop = None
            if loop is not None:
                try:
                    pending = asyncio.all_tasks(loop)
                    for pending_task in pending:
                        pending_task.cancel()
                    if pending:
                        loop.run_until_complete(
                            asyncio.gather(*pending, return_exceptions=True)
                        )
                finally:
                    loop.close()

    def request_cancel(self) -> None:
        self.requestInterruption()
        with self._guard:
            loop = self._loop
            task = self._task
        if loop is not None and task is not None and not task.done():
            loop.call_soon_threadsafe(task.cancel)


class GlobalRuntimeCoordinator(QtCore.QObject):
    """Own initialization generations, workers, reload policy, and disposal."""

    ready = QtCore.pyqtSignal(int)
    initialization_failed = QtCore.pyqtSignal(int, str)
    initialization_warning = QtCore.pyqtSignal(int, str)
    state_changed = QtCore.pyqtSignal(str, int)
    reload_finished = QtCore.pyqtSignal(int, bool)

    def __init__(
        self,
        parent=None,
        *,
        registry: GlobalRegistry = AppGlobals,
        lifecycle=LifecycleManager,
    ):
        super().__init__(parent)
        self.registry = registry
        self.lifecycle = lifecycle
        self.generation = registry.generation
        self.current_callbacks = None
        self.current_globals_class = None
        self.current_globals_object = None
        self._workers: set[QtCore.QThread] = set()
        self._after_workers_cancelled: Callable[[], None] | None = None
        self._operation: Dict[str, Any] | None = None
        self._pending_start = None
        self._shutdown_callback: Callable[[], None] | None = None
        self._generation_resources = []
        self._resource_specs = {}
        self._callback_jobs = set()
        self._callback_guard = threading.RLock()
        object.__setattr__(self.registry, "_callback_runtime_ref", weakref.ref(self))
        self.operation_timeout_ms = 60000

    def has_callback_jobs(self):
        with self._callback_guard:
            return bool(self._callback_jobs)

    @contextmanager
    def callback_scope(self, generation):
        """Track a callback running on a subscription's existing serial worker."""
        marker = object()
        with self._callback_guard:
            self._callback_jobs.add(marker)
        try:
            with execution_scope(self.registry, generation):
                yield
        finally:
            with self._callback_guard:
                self._callback_jobs.discard(marker)

    def start_callback(self, callback, *args, **kwargs):
        """Track framework jobs before starting, so imports cannot race their execution."""
        generation = self.registry.generation
        if self.registry.state != "READY":
            raise StaleGenerationError("Runtime is not ready to start a callback")
        marker = object()
        with self._callback_guard:
            self._callback_jobs.add(marker)
        def run():
            try:
                with execution_scope(self.registry, generation):
                    callback(*args, **kwargs)
            except StaleGenerationError:
                pass
            finally:
                with self._callback_guard:
                    self._callback_jobs.discard(marker)
        worker = threading.Thread(target=run, daemon=True)
        try:
            worker.start()
        except Exception:
            with self._callback_guard:
                self._callback_jobs.discard(marker)
            raise
        return worker

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------
    def begin_initialization(
        self,
        callbacks,
        *,
        window,
        build_ui: Callable[[], None],
        inject_helpers: Callable[[Any], None],
    ) -> int:
        return self._begin_operation(
            callbacks,
            window=window,
            build_ui=build_ui,
            inject_helpers=inject_helpers,
            is_reload=False,
        )

    def begin_reload(
        self,
        callbacks,
        *,
        window,
        inject_helpers: Callable[[Any], None],
        rebuild_ui: Callable[[], None] | None = None,
        requested_generation: int | None = None,
    ) -> int:
        return self._begin_operation(
            callbacks,
            window=window,
            build_ui=rebuild_ui,
            inject_helpers=inject_helpers,
            is_reload=True,
            requested_generation=requested_generation,
        )

    def begin_shutdown(self, window, on_finished: Callable[[], None] | None = None) -> None:
        self._cancel_pending_start()
        if self._operation is not None and not self._operation.get("committed", False):
            cancelled = self._operation
            self._rollback_uncommitted(cancelled)
            self._operation = None
            if cancelled["is_reload"]:
                self.reload_finished.emit(cancelled["generation"], False)
        self.generation += 1
        generation = self.generation
        self.registry._set_runtime_state("DISPOSING")
        self._shutdown_callback = on_finished

        def start() -> None:
            self._set_state("DISPOSING", generation)
            self._run_hooks(
                self.lifecycle.records("close"),
                (window,),
                generation,
                lambda: self._dispose_all_for_shutdown(generation),
                lambda details: self._shutdown_hook_failed(generation, details),
            )

        self._cancel_workers_then(start, cancel_all=True)

    def _cancel_active_generation(self) -> None:
        self._cancel_pending_start()
        if self._operation is not None and not self._operation.get("committed", False):
            cancelled = self._operation
            self._rollback_uncommitted(cancelled)
            self._operation = None
            if cancelled["is_reload"]:
                self.reload_finished.emit(cancelled["generation"], False)
        self.generation += 1
        self._cancel_workers_then(lambda: None)

    # ------------------------------------------------------------------
    # Generation setup and validation
    # ------------------------------------------------------------------
    def _begin_operation(
        self,
        callbacks,
        *,
        window,
        build_ui,
        inject_helpers,
        is_reload: bool,
        requested_generation=None,
    ) -> int:
        self._cancel_pending_start()
        active_operation = self._operation
        if active_operation is not None and not active_operation.get("committed", False):
            self._rollback_uncommitted(active_operation)
            self._operation = None
            if active_operation["is_reload"]:
                self.reload_finished.emit(active_operation["generation"], False)
        previous_generation = self.registry.generation
        previous_state = self.registry.state
        self.generation = max(self.generation + 1, previous_generation + 1,
                              requested_generation or 0)
        generation = self.generation
        self.registry._set_runtime_state(
            "RELOADING" if is_reload else "DECLARED"
        )
        pending = {"callbacks": callbacks, "generation": generation,
                   "previous_generation": previous_generation,
                   "previous_state": previous_state, "is_reload": is_reload}
        self._pending_start = pending

        def start() -> None:
            if self._pending_start is not pending:
                return
            self._pending_start = None
            self._start_operation(
                callbacks,
                window=window,
                build_ui=build_ui,
                inject_helpers=inject_helpers,
                is_reload=is_reload,
                generation=generation,
                previous_generation=previous_generation,
                previous_state=previous_state,
            )

        self._cancel_workers_then(start)
        return generation

    def _cancel_pending_start(self):
        pending, self._pending_start = self._pending_start, None
        if pending is None:
            return
        self._discard_import_candidate(pending["callbacks"], pending["generation"])
        self.registry._set_runtime_state(pending["previous_state"],
                                         generation=pending["previous_generation"])
        if pending["is_reload"]:
            self.reload_finished.emit(pending["generation"], False)

    def _discard_import_candidate(self, callbacks, generation):
        transaction = getattr(callbacks, "__import_transaction__", None)
        if transaction is None:
            return
        transaction.rollback()
        transaction.effects.rollback()
        entries = [(name, value, GlobalSpec(kind="dynamic"))
                   for name, value in transaction.allocations]
        entries += [("import resource", value, GlobalSpec(kind="dynamic"))
                    for value in transaction.effects.resources]
        self._dispose_entries(self._release_candidates(
            entries, list(self.registry.values()) + self._generation_resources),
            generation, lambda: None, [])

    def _start_operation(
        self,
        callbacks,
        *,
        window,
        build_ui,
        inject_helpers,
        is_reload: bool,
        generation: int,
        previous_generation: int,
        previous_state: str,
    ) -> None:
        if generation != self.generation:
            return
        old_values = self.registry.snapshot()
        old_specs = self.registry._spec_snapshot()
        old_generation = previous_generation
        old_state = previous_state
        try:
            globals_class = getattr(callbacks, "Globals", None)
            if not (
                isinstance(globals_class, type)
                and issubclass(globals_class, GlobalsBase)
                and globals_class is not GlobalsBase
            ):
                raise AppGlobalDefinitionError(
                    "callbacks.py must define class Globals(GlobalsBase)."
                )
            globals_object = globals_class()
            init = getattr(globals_object, "init_globals", None)
            if not callable(init):
                raise AppGlobalDefinitionError("Globals.init_globals must be callable.")
            if inspect.iscoroutinefunction(init):
                raise AppGlobalDefinitionError(
                    "Globals.init_globals must be synchronous because it runs in the Qt "
                    "main thread. Move I/O into async_global(...)."
                )
            specs = globals_class.definitions()
            registration = getattr(callbacks, "__lifecycle_registration__", None)
            if not isinstance(registration, LifecycleRegistration):
                registration = self.lifecycle.registration_scope(
                    "callbacks"
                )
        except Exception:
            self._discard_import_candidate(callbacks, generation)
            self.registry._set_runtime_state(old_state, generation=old_generation)
            self._fail_without_operation(generation, traceback.format_exc(), is_reload)
            return

        candidate_values, plain_clones = stage_values(old_values, old_specs)
        unload_values, unload_clones = stage_values(old_values, old_specs)
        transaction = getattr(callbacks, "__import_transaction__", None)
        if transaction is not None:
            candidate_values.update(transaction.global_writes)
            for name in transaction.global_removals:
                candidate_values.pop(name, None)
        for removed_name in set(old_specs) - set(specs):
            candidate_values.pop(removed_name, None)

        operation = {
            "generation": generation,
            "is_reload": is_reload,
            "callbacks": callbacks,
            "globals_class": globals_class,
            "globals_object": globals_object,
            "init": init,
            "specs": specs,
            "registration": registration,
            "window": window,
            "build_ui": build_ui,
            "inject_helpers": inject_helpers,
            "old_values": old_values,
            "old_specs": old_specs,
            "old_generation": old_generation,
            "old_state": old_state,
            "staged": candidate_values,
            "candidate_visible": not is_reload,
            "warnings": [],
            "committed": False,
            "effects": getattr(transaction, "effects", None) or ReloadEffects(),
            "allocations": list(getattr(transaction, "allocations", ())),
            "old_resources": list(self._generation_resources),
            "old_resource_specs": dict(self._resource_specs),
            "old_retired": self.registry._retired_snapshot(),
            "unload_values": unload_values,
            "plain_clones": {**plain_clones, **unload_clones,
                             **getattr(transaction, "plain_clones", {})},
            "released": {},
        }
        self._operation = operation
        operation["effects"].token = (self.registry, generation)
        deadline = QtCore.QTimer(self)
        deadline.setSingleShot(True)
        deadline.timeout.connect(lambda: self._operation_timed_out(operation))
        operation["deadline"] = deadline
        deadline.start(min(2_147_483_647, max(self.operation_timeout_ms, int(1000 * sum(
            spec.timeout or 0 for spec in specs.values())) + self.operation_timeout_ms)))
        self._set_state("INITIALIZING_EARLY", generation)

        for name, spec in specs.items():
            if self._preserve_existing(operation, name, spec):
                continue
            if spec.kind == "plain":
                operation["staged"][name] = spec.value
            else:
                operation["staged"].pop(name, None)
        if transaction is not None:
            operation["staged"].update(transaction.global_writes)
            for name in transaction.global_removals:
                operation["staged"].pop(name, None)

        if is_reload:
            records = self.lifecycle.records("unload")
            on_hooks_done = lambda: self._publish_early_after_unload(operation)
        else:
            # Initial startup hooks intentionally see plain declarations.
            records = registration.for_stage("startup")
            on_hooks_done = lambda: self._capture_startup_plain_values(operation)
        self._set_state("RELOADING" if is_reload else "STARTUP", generation)
        self._run_hooks(
            records,
            (window,),
            generation,
            on_hooks_done,
            lambda details: self._fail_operation(operation, details, precommit=True),
        )

    def _capture_startup_plain_values(self, operation: Dict[str, Any]) -> None:
        """Retain declared-value mutations performed by startup hooks."""
        if not self._is_current(operation):
            return
        self._after_early_hooks(operation)

    @staticmethod
    def _preserve_existing(operation: Mapping[str, Any], name: str, spec: GlobalSpec) -> bool:
        old_spec = operation["old_specs"].get(name)
        return (
            operation["is_reload"]
            and spec.reload is ReloadPolicy.PRESERVE
            and old_spec is not None
            and old_spec.kind == spec.kind
            and name in operation["old_values"]
            and name in operation["staged"]
        )

    # ------------------------------------------------------------------
    # UI, lazy, and async resource phases
    # ------------------------------------------------------------------
    def _publish_early_after_unload(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        # Unload hooks see an isolated view of the working generation. Carry
        # their data changes forward only for globals whose policy preserves it.
        for name in operation["old_values"].keys() | operation["unload_values"].keys():
            spec = operation["specs"].get(name)
            if name not in operation["old_specs"] or (
                    spec is not None and self._preserve_existing(operation, name, spec)):
                if name in operation["unload_values"]:
                    operation["staged"][name] = operation["unload_values"][name]
                else:
                    operation["staged"].pop(name, None)
        transaction = getattr(operation["callbacks"], "__import_transaction__", None)
        if transaction is not None:
            operation["staged"].update(transaction.global_writes)
            for name in transaction.global_removals:
                operation["staged"].pop(name, None)
            transaction.activate()
        operation["candidate_visible"] = True
        operation["detached_parents"] = []
        for name, old_spec in operation["old_specs"].items():
            value = operation["old_values"].get(name)
            new_spec = operation["specs"].get(name)
            preserved = new_spec is not None and self._preserve_existing(operation, name, new_spec)
            widget = resource_widget(value)
            target = widget if widget is not None else value
            if (old_spec.kind == "lazy" and not preserved
                    and callable(operation["build_ui"])
                    and isinstance(target, QtCore.QObject) and not borrowed(value)):
                try:
                    parent = target.parent()
                    if parent is not None:
                        operation["detached_parents"].append((target, parent))
                        target.setParent(None)
                except RuntimeError:
                    pass
        self._after_early_hooks(operation)

    def _after_early_hooks(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        try:
            build_ui = operation["build_ui"]
            with self._candidate_scope(operation):
                if callable(build_ui):
                    self._set_state("UI_BUILD", operation["generation"])
                    operation["layout_transaction"] = build_ui()
                operation["inject_helpers"](operation["callbacks"])
                self._set_state("INITIALIZING_RESOURCES", operation["generation"])
                for name, spec in operation["specs"].items():
                    if spec.kind != "lazy" or self._preserve_existing(operation, name, spec):
                        continue
                    try:
                        value = spec.factory()
                        if inspect.isawaitable(value):
                            try:
                                value.close()
                            except Exception:
                                pass
                            raise TypeError(
                                "lazy() returned an awaitable; use async_global(...)"
                            )
                    except Exception as error:
                        label = f" ({spec.label})" if spec.label else ""
                        raise RuntimeError(
                            f"Lazy global {name!r}{label} failed: {error}"
                        ) from error
                    operation["staged"][name] = value
                    operation["allocations"].append((name, value))
        except Exception:
            self._fail_operation(operation, traceback.format_exc(), precommit=True)
            return

        pending_async = {
            name: spec
            for name, spec in operation["specs"].items()
            if spec.kind == "async" and not self._preserve_existing(operation, name, spec)
        }
        if not pending_async:
            self._commit_operation(operation)
            return

        worker = _AsyncGlobalsWorker(pending_async, operation["generation"])
        worker.set_staging_registry(self.registry, operation["staged"])
        worker.effects = operation["effects"]
        worker.allocations = operation["allocations"]
        worker.protected = retained_identities(operation["old_values"].values())
        worker.released = operation["released"]
        worker.completed.connect(
            lambda generation, results: self._async_globals_ready(
                operation, generation, results
            )
        )
        worker.failed_with_results.connect(
            lambda generation, details, partial: self._async_globals_failed(
                operation, generation, details, partial
            )
        )
        worker.cancelled.connect(lambda generation: None)
        self._track_worker(worker)
        worker.start()

    def _async_globals_ready(
        self, operation: Dict[str, Any], generation: int, results: Dict[str, Any]
    ) -> None:
        if generation != self.generation or not self._is_current(operation):
            self._dispose_stale_async_results(operation, results)
            return
        operation["staged"].update(results)
        self._commit_operation(operation)

    def _async_globals_failed(
        self,
        operation: Dict[str, Any],
        generation: int,
        details: str,
        partial: Dict[str, Any],
    ) -> None:
        if generation != self.generation or not self._is_current(operation):
            self._dispose_stale_async_results(operation, partial)
            return
        operation["staged"].update(partial)
        self._fail_operation(operation, details, precommit=True)

    def _dispose_stale_async_results(
        self, operation: Mapping[str, Any], results: Mapping[str, Any]
    ) -> None:
        """Best-effort cleanup for a cancelled factory that suppressed cancellation."""
        entries = self._resource_entries(results, operation["specs"])
        for name, value, spec in self._release_candidates(
                entries, list(self.registry.values()) + self._generation_resources):
            if id(value) in operation["released"]:
                continue
            operation["released"][id(value)] = value
            disposer = spec.dispose or resource_disposer(value)
            if not callable(disposer):
                continue
            try:
                if inspect.iscoroutinefunction(disposer):
                    worker = _AsyncCallWorker(
                        self.generation,
                        lambda disposer=disposer, value=value: disposer(value),
                        cancel_on_generation=False,
                    )
                    worker.completed.connect(lambda generation, result: None)
                    worker.failed.connect(
                        lambda generation, details, name=name: self.initialization_warning.emit(
                            generation,
                            f"Stale disposer for {name!r} failed:\n{details}",
                        )
                    )
                    self._track_worker(worker)
                    worker.start()
                    continue
                result = disposer(value)
                if inspect.isawaitable(result):
                    worker = _AsyncCallWorker(
                        self.generation, lambda result=result: result,
                        cancel_on_generation=False,
                    )
                    worker.completed.connect(lambda generation, value: None)
                    worker.failed.connect(
                        lambda generation, details, name=name: self.initialization_warning.emit(
                            generation,
                            f"Stale disposer for {name!r} failed:\n{details}",
                        )
                    )
                    self._track_worker(worker)
                    worker.start()
            except Exception:
                self.initialization_warning.emit(
                    self.generation,
                    f"Stale disposer for {name!r} failed:\n{traceback.format_exc()}",
                )

    # ------------------------------------------------------------------
    # Commit, disposal, init hook, and ready
    # ------------------------------------------------------------------
    def _commit_operation(self, operation: Dict[str, Any]) -> None:
        # Validate initialization and reload hooks against staged values before
        # replacing hooks or disposing any resources from the working runtime.
        self._run_init_hook(operation)

    def _publish_operation(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        transaction = getattr(operation["callbacks"], "__import_transaction__", None)
        if transaction is not None:
            from app.source_reload import source_manifest
            if source_manifest(transaction.project_root, transaction.callbacks_path) != transaction.manifest:
                self._fail_operation(operation, "Source changed during initialization; reload again", precommit=True)
                return
        specs = operation["specs"]
        old_specs = operation["old_specs"]
        old_values = operation["old_values"]
        effects = operation["effects"]
        try:
            effects.prepare()
        except Exception:
            self._fail_operation(operation, traceback.format_exc(), precommit=True)
            return
        operation["staged"] = publish_plain_state(operation["staged"], operation["plain_clones"])
        retained = list(operation["staged"].values()) + effects.resources
        operation["disposals"] = self._release_candidates(
            self._resource_entries(old_values, old_specs)
            + [(name, value, specs.get(name, GlobalSpec(kind="dynamic")))
               for name, value in operation["allocations"]]
            + [(name, value, spec or GlobalSpec(kind="dynamic"))
               for name, value, spec in operation["old_retired"]]
            + [("generation resource", value, operation["old_resource_specs"].get(id(value), GlobalSpec(kind="dynamic")))
               for value in operation["old_resources"]], retained,
        )
        self.registry._commit_generation(
            specs=specs,
            values=operation["staged"],
            generation=operation["generation"],
        )
        operation["registration"].commit()
        operation["committed"] = True
        keep = retained_identities(retained)
        live_entries = self._resource_entries(operation["staged"], specs)
        live_entries += [("generation resource", value,
                          operation["old_resource_specs"].get(id(value), GlobalSpec(kind="dynamic")))
                         for value in operation["old_resources"]]
        live_entries += [("generation resource", value, GlobalSpec(kind="dynamic"))
                         for value in effects.resources]
        self._resource_specs = {}
        for _, value, spec in live_entries:
            if (id(value) in keep and spec.owned and not borrowed(value)
                    and (spec.dispose is not None or resource_disposer(value) is not None)):
                if id(value) not in self._resource_specs or spec.dispose is not None:
                    self._resource_specs[id(value)] = spec
        self._generation_resources = list({id(value): value for _, value, _ in live_entries
                                           if id(value) in self._resource_specs}.values())
        from app.tools.communication_hub.message_stream import MessageSubscription
        for resource in self._generation_resources:
            if isinstance(resource, MessageSubscription):
                resource._rebind_generation(self.registry, operation["generation"])
        self.current_callbacks = operation["callbacks"]
        self.current_globals_class = operation["globals_class"]
        self.current_globals_object = operation["globals_object"]
        transaction = getattr(operation["callbacks"], "__import_transaction__", None)
        if transaction is not None:
            transaction.commit()
        try:
            operation["warnings"].extend(effects.commit())
        except Exception:
            operation["warnings"].append("UI handover failed after publication:\n" + traceback.format_exc())
        try:
            layout = operation.get("layout_transaction")
            if layout is not None:
                layout.commit()
        except Exception:
            operation["warnings"].append("UI handover failed after publication:\n" + traceback.format_exc())
        self._dispose_entries(
            operation["disposals"],
            operation["generation"],
            lambda: self._finish_ready(operation),
            operation["warnings"],
        )

    def _run_init_hook(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        self._set_state("INIT_UI", operation["generation"])
        try:
            with self._candidate_scope(operation):
                result = operation["init"]()
            if inspect.isawaitable(result):
                try:
                    result.close()
                except Exception:
                    pass
                raise AppGlobalDefinitionError(
                    "Globals.init_globals returned an awaitable. It must be synchronous; "
                    "use async_global(...) for asynchronous initialization."
                )
        except Exception:
            self._fail_operation(operation, traceback.format_exc(), precommit=True)
            return

        records = (
            operation["registration"].for_stage("reload")
            if operation["is_reload"] else []
        )
        self._run_hooks(
            records,
            (operation["window"],),
            operation["generation"],
            lambda: self._mark_ready(operation),
            lambda details: self._fail_operation(operation, details, precommit=True),
        )

    def _mark_ready(self, operation: Dict[str, Any]) -> None:
        self._publish_operation(operation)

    def _finish_ready(self, operation: Dict[str, Any]) -> None:
        if not self._is_current(operation):
            return
        generation = operation["generation"]
        operation["deadline"].stop()
        operation["deadline"].deleteLater()
        self._set_state("READY", generation)
        if operation["warnings"]:
            self.initialization_warning.emit(
                generation, "\n\n".join(operation["warnings"])
            )
        self._operation = None
        self.ready.emit(generation)
        if operation["is_reload"]:
            self.reload_finished.emit(generation, True)

    # ------------------------------------------------------------------
    # Lifecycle hook runner
    # ------------------------------------------------------------------
    def _run_hooks(
        self,
        records: list[HookRecord],
        args: tuple[Any, ...],
        generation: int,
        on_done: Callable[[], None],
        on_error: Callable[[str], None],
    ) -> None:
        records = list(records)

        def advance(index: int) -> None:
            if generation != self.generation:
                return
            if index >= len(records):
                on_done()
                return
            record = records[index]
            try:
                operation = self._operation
                use_candidate = (
                    operation is not None
                    and operation.get("generation") == generation
                    and not operation.get("committed", False)
                    and operation.get("candidate_visible", False)
                )
                scope = (
                    self._candidate_scope(operation)
                    if use_candidate else self._unload_scope(operation)
                    if operation is not None and operation["is_reload"]
                    and not operation["committed"] else nullcontext()
                )
                if inspect.iscoroutinefunction(record.callback):
                    self._start_async_call(
                        generation,
                        lambda record=record: self.lifecycle.invoke(record, *args),
                        lambda _result: advance(index + 1),
                        on_error,
                    )
                    return
                with scope:
                    result = self.lifecycle.invoke(record, *args)
                if inspect.isawaitable(result):
                    self._start_async_call(
                        generation,
                        lambda result=result: result,
                        lambda _result: advance(index + 1),
                        on_error,
                    )
                    return
            except Exception:
                on_error(traceback.format_exc())
                return
            advance(index + 1)

        advance(0)

    def _start_async_call(
        self,
        generation: int,
        producer: Callable[[], Any],
        on_result: Callable[[Any], None],
        on_error: Callable[[str], None],
    ) -> None:
        operation = self._operation
        if (
            operation is not None
            and operation.get("generation") == generation
            and not operation.get("committed", False)
        ):
            original_producer = producer

            async def producer():
                scope = (self._candidate_scope(operation) if operation["candidate_visible"]
                         else self._unload_scope(operation))
                with scope:
                    value = original_producer()
                    return await value if inspect.isawaitable(value) else value

        worker = _AsyncCallWorker(generation, producer)
        worker.completed.connect(
            lambda worker_generation, result: (
                on_result(result) if worker_generation == self.generation else None
            )
        )
        worker.failed.connect(
            lambda worker_generation, details: (
                on_error(details) if worker_generation == self.generation else None
            )
        )
        worker.cancelled.connect(lambda worker_generation: None)
        self._track_worker(worker)
        worker.start()

    # ------------------------------------------------------------------
    # Resource disposal
    # ------------------------------------------------------------------
    @contextmanager
    def _candidate_scope(self, operation):
        with self.registry._staging_scope(operation["staged"], operation["allocations"]):
            with operation["effects"].scope():
                yield

    @contextmanager
    def _unload_scope(self, operation):
        with self.registry._staging_scope(operation["unload_values"], operation["allocations"]):
            with operation["effects"].scope():
                yield

    @staticmethod
    def _resource_entries(values, specs):
        return [(name, value, specs.get(name, GlobalSpec(kind="dynamic")))
                for name, value in values.items()]

    @staticmethod
    def _release_candidates(entries, retained=()):
        keep = retained_identities(retained)
        seen = set()
        result = []
        # A wrapper owns its widget; release the wrapper instead of both.
        entries = list(entries)
        explicit = {id(value): spec for _, value, spec in entries if spec.dispose is not None}
        keep.update(retained_identities(value for _, value, spec in entries
                                        if not spec.owned or borrowed(value)))
        wrapped = {id(widget) for _, value, spec in entries
                   if spec.owned and not borrowed(value)
                   and not isinstance(value, QtCore.QObject)
                   and (widget := resource_widget(value)) is not None}
        for name, value, spec in reversed(entries):
            spec = explicit.get(id(value), spec)
            if not spec.owned or borrowed(value) or id(value) in keep | seen:
                continue
            widget = resource_widget(value)
            if widget is not None and id(widget) in keep:
                continue
            if isinstance(value, QtCore.QObject) and id(value) in wrapped:
                continue
            if spec.dispose is None and resource_disposer(value) is None:
                continue
            seen.add(id(value))
            result.append((name, value, spec))
        return result

    def _dispose_entries(
        self,
        entries: Iterable[tuple[str, Any, GlobalSpec]],
        generation: int,
        on_done: Callable[[], None],
        warnings: list[str],
    ) -> None:
        entries = self._release_candidates(entries)

        def advance(index: int) -> None:
            if generation != self.generation:
                return
            if index >= len(entries):
                on_done()
                return
            name, value, spec = entries[index]
            disposer = spec.dispose or resource_disposer(value)
            if disposer is None:
                if isinstance(value, QtCore.QObject):
                    try:
                        value.deleteLater()
                    except RuntimeError:
                        pass
                advance(index + 1)
                return
            try:
                if isinstance(value, QtCore.QObject):
                    result = disposer(value)
                    if inspect.isawaitable(result):
                        try:
                            result.close()
                        except Exception:
                            pass
                        raise RuntimeError(
                            "Qt-owned resources require a synchronous main-thread disposer."
                        )
                    advance(index + 1)
                    return
                if inspect.iscoroutinefunction(disposer):
                    self._start_async_call(
                        generation,
                        lambda disposer=disposer, value=value: disposer(value),
                        lambda _result: advance(index + 1),
                        lambda details, name=name: (
                            warnings.append(f"Disposer for {name!r} failed:\n{details}"),
                            advance(index + 1),
                        )[-1],
                    )
                    return
                result = disposer(value)
                if inspect.isawaitable(result):
                    self._start_async_call(
                        generation,
                        lambda result=result: result,
                        lambda _result: advance(index + 1),
                        lambda details, name=name: (
                            warnings.append(f"Disposer for {name!r} failed:\n{details}"),
                            advance(index + 1),
                        )[-1],
                    )
                    return
            except Exception:
                warnings.append(
                    f"Disposer for {name!r} failed:\n{traceback.format_exc()}"
                )
            advance(index + 1)

        advance(0)

    def _dispose_all_for_shutdown(self, generation: int) -> None:
        specs = self.registry._spec_snapshot()
        values = self.registry.snapshot()
        entries = self._resource_entries(values, specs) + [
            ("generation resource", value, self._resource_specs.get(id(value), GlobalSpec(kind="dynamic")))
            for value in self._generation_resources]
        entries += [(name, value, spec or GlobalSpec(kind="dynamic"))
                    for name, value, spec in self.registry._retired_snapshot()]
        warnings: list[str] = []
        self._dispose_entries(
            entries,
            generation,
            lambda: self._finish_shutdown(generation, warnings),
            warnings,
        )

    def _finish_shutdown(self, generation: int, warnings: list[str]) -> None:
        if generation != self.generation:
            return
        if warnings:
            self.initialization_warning.emit(generation, "\n\n".join(warnings))
        self.registry.clear()
        self.registry._retired = []
        self._generation_resources.clear()
        self._resource_specs.clear()
        self._set_state("CLOSED", generation)
        callback = self._shutdown_callback
        self._shutdown_callback = None
        if callback is not None:
            callback()

    def _shutdown_hook_failed(self, generation: int, details: str) -> None:
        if generation != self.generation:
            return
        self.initialization_warning.emit(
            generation, f"Close lifecycle hook failed:\n{details}"
        )
        self._dispose_all_for_shutdown(generation)

    # ------------------------------------------------------------------
    # Failure, state, and worker ownership
    # ------------------------------------------------------------------
    def _fail_without_operation(
        self, generation: int, details: str, is_reload: bool
    ) -> None:
        if generation != self.generation:
            return
        self._operation = None
        state = "READY" if is_reload and self.current_callbacks is not None else "FAILED"
        self.registry._set_runtime_state(
            state, generation=self.registry.generation if is_reload else generation, error=details
        )
        self.state_changed.emit(state, generation)
        self.initialization_failed.emit(generation, details)
        if is_reload:
            self.reload_finished.emit(generation, False)

    def _fail_operation(
        self, operation: Dict[str, Any], details: str, *, precommit: bool
    ) -> None:
        if not self._is_current(operation):
            return
        generation = operation["generation"]
        if precommit:
            self._rollback_uncommitted(operation)
            if not operation["is_reload"]:
                self.registry._set_runtime_state(
                    "FAILED", generation=generation, error=details
                )
            else:
                self.registry._set_runtime_state(
                    operation["old_state"],
                    generation=operation["old_generation"],
                    error=details,
                )
        else:
            self.registry._set_runtime_state(
                "FAILED", generation=generation, error=details
            )
        self._operation = None
        self.state_changed.emit(
            self.registry.state, self.registry.generation
        )
        self.initialization_failed.emit(generation, details)
        if operation["is_reload"]:
            self.reload_finished.emit(generation, False)

    def _set_state(self, state: str, generation: int) -> None:
        if generation != self.generation:
            return
        self.registry._set_runtime_state(state)
        self.state_changed.emit(state, generation)

    def _is_current(self, operation: Mapping[str, Any]) -> bool:
        return (
            self._operation is operation
            and operation["generation"] == self.generation
        )

    def _rollback_uncommitted(self, operation: Mapping[str, Any]) -> None:
        """Restore a staged generation and release resources it already created."""
        if operation.get("rolled_back"):
            return
        operation["rolled_back"] = True
        operation["deadline"].stop()
        operation["deadline"].deleteLater()
        operation["effects"].rollback()
        transaction = getattr(operation["callbacks"], "__import_transaction__", None)
        if transaction is not None:
            transaction.rollback()
        layout = operation.get("layout_transaction")
        if layout is not None:
            layout.rollback()
        for value, parent in operation.get("detached_parents", ()):
            try:
                value.setParent(parent)
            except RuntimeError:
                # A layout rebuild may already have deleted the old parent.
                pass
        self.registry._restore_generation(
            values=operation["old_values"],
            specs=operation["old_specs"],
            generation=operation["old_generation"],
            state=operation["old_state"],
            retired=operation["old_retired"],
        )
        old_values = operation["old_values"]
        specs = operation["specs"]
        entries = self._resource_entries(operation["staged"], specs)
        entries += [(name, value, specs.get(name, GlobalSpec(kind="dynamic")))
                    for name, value in operation["allocations"]]
        entries += [("generation resource", value, GlobalSpec(kind="dynamic"))
                    for value in operation["effects"].resources]
        for name, value, spec in self._release_candidates(
                entries, list(old_values.values()) + operation["old_resources"]):
            if id(value) in operation["released"]:
                continue
            operation["released"][id(value)] = value
            disposer = spec.dispose or resource_disposer(value)
            try:
                if disposer is not None and inspect.iscoroutinefunction(disposer):
                    worker = _AsyncCallWorker(
                        operation["generation"],
                        lambda disposer=disposer, value=value: disposer(value),
                        cancel_on_generation=False,
                    )
                    worker.failed.connect(
                        lambda _generation, details, name=name: self.initialization_warning.emit(
                            self.generation,
                            f"Staged disposer for {name!r} failed:\n{details}",
                        )
                    )
                    self._track_worker(worker)
                    worker.start()
                elif disposer is not None:
                    result = disposer(value)
                    if inspect.isawaitable(result):
                        worker = _AsyncCallWorker(
                            operation["generation"],
                            lambda result=result: result,
                            cancel_on_generation=False,
                        )
                        worker.failed.connect(
                            lambda _generation, details, name=name: self.initialization_warning.emit(
                                self.generation,
                                f"Staged disposer for {name!r} failed:\n{details}",
                            )
                        )
                        self._track_worker(worker)
                        worker.start()
                elif disposer is None and isinstance(value, QtCore.QObject):
                    value.deleteLater()
            except Exception:
                self.initialization_warning.emit(
                    operation["generation"],
                    f"Staged disposer for {name!r} failed:\n{traceback.format_exc()}",
                )

    def _track_worker(self, worker: QtCore.QThread) -> None:
        self._workers.add(worker)

        def cleanup() -> None:
            self._workers.discard(worker)
            worker.deleteLater()
            if not self._workers and self._after_workers_cancelled is not None:
                callback = self._after_workers_cancelled
                self._after_workers_cancelled = None
                QtCore.QTimer.singleShot(0, callback)

        worker.finished.connect(cleanup)

    def _operation_timed_out(self, operation):
        if not self._is_current(operation):
            return
        if operation["committed"]:
            operation["warnings"].append("Resource cleanup exceeded the reload deadline; restart may be required.")
            self._finish_ready(operation)
        else:
            self._fail_operation(operation,
                "Reload initialization exceeded its deadline. Framework changes were discarded. "
                "Uncooperative background work may require an application restart.", precommit=True)
        for worker in tuple(self._workers):
            if worker.isRunning() and getattr(worker, "cancel_on_generation", True):
                worker.request_cancel()

    def _cancel_workers_then(
        self,
        callback: Callable[[], None],
        *,
        cancel_all: bool = False,
    ) -> None:
        active = [worker for worker in self._workers if worker.isRunning()]
        if not active:
            QtCore.QTimer.singleShot(0, callback)
            return
        self._after_workers_cancelled = callback
        for worker in active:
            if not cancel_all and not getattr(worker, "cancel_on_generation", True):
                continue
            cancel = getattr(worker, "request_cancel", None)
            if callable(cancel):
                cancel()
            else:
                worker.requestInterruption()


__all__ = ["GlobalRuntimeCoordinator"]
