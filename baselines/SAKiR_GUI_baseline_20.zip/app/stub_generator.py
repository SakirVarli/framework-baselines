"""Generate the callback-facing developer API in :mod:`app.stubs`.

The generated module is intentionally the navigation boundary for callback
authors.  Runtime implementations are resolved separately so editor navigation
does not need to enter the application implementation modules.
"""

from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
import tempfile
import textwrap
import threading
from pathlib import Path
from typing import Any

from app.utils import (
    CB_STUBS_PATH,
    CONFIG_PATH,
    COMMUNICATION_HUB_SETTINGS,
    FTP_SERVER_SETTINGS,
    SERIAL_SETTINGS,
    TELNET_SETTINGS,
    load_json,
)
from app.config_designer.config_structure import (
    iter_tab_definitions,
    iter_widget_definitions,
)


STUB_SCHEMA_VERSION = 2
_WRITE_LOCK = threading.RLock()


def _unique_strings(values) -> list[str]:
    return sorted({value for value in values if isinstance(value, str) and value})


def _literal(values, fallback: str = "str") -> str:
    values = _unique_strings(values)
    if not values:
        return fallback
    return "Literal[" + ", ".join(repr(value) for value in values) + "]"


def _index_literal(count: int) -> str:
    return "Literal[" + ", ".join(str(index) for index in range(count)) + "]" if count else "int"


def _workspace_sessions(path: str) -> list[dict[str, Any]]:
    data = load_json(path)
    workspace = data.get("workspace") if isinstance(data, dict) else None
    sessions = workspace.get("sessions") if isinstance(workspace, dict) else None
    if isinstance(sessions, list):
        return [item for item in sessions if isinstance(item, dict)]
    if isinstance(data, dict) and data:
        return [data]
    return []


def _collect_ui_names(config: dict) -> tuple[list[str], list[str], list[str]]:
    tabs: list[str] = []
    outputs: list[str] = []
    infos: list[str] = []

    for tab in iter_tab_definitions(config):
        tabs.append(tab.get("name"))
    for widget in iter_widget_definitions(config):
        kind = widget.get("type")
        if kind == "output":
            outputs.append(widget.get("instance"))
        elif kind == "info":
            infos.append(widget.get("instance"))
    return _unique_strings(tabs), _unique_strings(outputs), _unique_strings(infos)


def _fingerprint(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:16]


def render_stubs(config: dict | None = None) -> str:
    """Render a complete, validated callback API module without writing it.

    Args:
        config: Optional in-memory UI configuration. When omitted, the current
            ``config.json`` is loaded. Persisted serial, Telnet, and FTP settings
            are always read so their saved names become generated literals.

    Returns:
        UTF-8-ready Python source ending with one newline.

    Raises:
        SyntaxError: A generator defect produced invalid Python. Validation is
            performed before any destination file can be replaced.
    """
    config = load_json(CONFIG_PATH) if config is None else config
    tabs, outputs, infos = _collect_ui_names(config)
    serial_sessions = _workspace_sessions(SERIAL_SETTINGS)
    telnet_sessions = _workspace_sessions(TELNET_SETTINGS)
    communication_data = load_json(COMMUNICATION_HUB_SETTINGS)
    communication_sessions = [
        item for item in communication_data.get("sessions", [])
        if isinstance(item, dict)
    ] if isinstance(communication_data, dict) else []
    communication_insights = [
        item for item in communication_data.get("protocol_insights", [])
        if isinstance(item, dict)
    ] if isinstance(communication_data, dict) else []
    ftp_data = load_json(FTP_SERVER_SETTINGS)
    ftp_users = _unique_strings(
        item.get("username")
        for item in (ftp_data.get("users", []) if isinstance(ftp_data, dict) else [])
        if isinstance(item, dict)
    )
    serial_names = _unique_strings(item.get("name") for item in serial_sessions)
    telnet_names = _unique_strings(item.get("name") for item in telnet_sessions)
    communication_names = _unique_strings(item.get("name") for item in communication_sessions)
    communication_insight_names = _unique_strings(item.get("name") for item in communication_insights)

    inputs = {
        "schema": STUB_SCHEMA_VERSION,
        "tabs": tabs,
        "outputs": outputs,
        "infos": infos,
        "serial_sessions": serial_names,
        "telnet_sessions": telnet_names,
        "ftp_users": ftp_users,
        "communication_sessions": communication_names,
        "communication_insights": communication_insight_names,
    }

    output_type = _literal(outputs)
    info_type = _literal(infos)
    tab_type = _literal(tabs, "Union[int, str]")
    serial_name_type = _literal(serial_names)
    telnet_name_type = _literal(telnet_names)
    serial_index_type = _index_literal(len(serial_sessions))
    telnet_index_type = _index_literal(len(telnet_sessions))
    ftp_user_type = _literal(ftp_users)
    communication_name_type = _literal(communication_names)
    communication_index_type = _index_literal(len(communication_sessions))
    communication_insight_name_type = _literal(communication_insight_names)
    communication_insight_index_type = _index_literal(len(communication_insights))

    source = f'''\
"""
Auto-generated callback API for editor completion, signatures, and navigation.
This file is fully owned by the generator -- DO NOT EDIT MANUALLY.

Stub schema: {STUB_SCHEMA_VERSION}
Input fingerprint: {_fingerprint(inputs)}
"""

from typing import (
    TYPE_CHECKING, Any, Callable, Dict, Generic, Iterable, Literal, Optional,
    Protocol, TypeVar, TypedDict, Union, overload,
)
from app.utils import PROJECT_ROOT, resolve_callback_tool_symbols as _resolve_tool_symbols
from app.globals_api import (
    GlobalsBase, ReloadPolicy, async_global, global_value, lazy,
)
from app.lifecycle import LifecycleManager
from PyQt5.QtWidgets import QWidget
from PyQt5.QtGui import QPixmap, QImage
from pandas import DataFrame
from pandas.io.formats.style import Styler
import numpy as np

OutputInstance = {output_type}
InfoInstance = {info_type}
TabName = {tab_type}
SerialSessionName = {serial_name_type}
SerialSessionIndex = {serial_index_type}
TelnetSessionName = {telnet_name_type}
TelnetSessionIndex = {telnet_index_type}
FTPUserName = {ftp_user_type}
CommunicationSessionName = {communication_name_type}
CommunicationSessionIndex = {communication_index_type}
ProtocolInsightName = {communication_insight_name_type}
ProtocolInsightIndex = {communication_insight_index_type}

_T = TypeVar("_T")


class SerialSettings(TypedDict, total=False):
    """Persisted options accepted by ``Tools.serial.new_session`` and ``configure``.

    Every key is optional. Unspecified values retain the session's current or
    application-default setting.

    Common fields:
        name: Workspace label used by ``session(name)``.
        port: Device name or pyserial URL such as ``COM3`` or ``loop://``.
        baudrate/bytesize/parity/stopbits: Serial framing configuration.
        rtscts/xonxoff/dsrdtr: Hardware/software flow-control switches.
        timeout: Read timeout in seconds.
        encoding/decode_errors: Text conversion behavior.
        enter_sends: Terminal Enter sequence, for example ``CRLF``.
        local_echo/hex_view/timestamps: Terminal presentation options.
        scrollback_lines: Maximum retained terminal history.
    """
    name: str
    port: str
    baudrate: int
    bytesize: int
    parity: str
    stopbits: float
    rtscts: bool
    xonxoff: bool
    dsrdtr: bool
    timeout: float
    encoding: str
    decode_errors: str
    local_echo: bool
    enter_sends: str
    vt100_keys: bool
    hex_view: bool
    timestamps: bool
    scrollback_lines: int


class TelnetSettings(TypedDict, total=False):
    """Persisted options accepted by ``Tools.telnet.new_session`` and ``configure``.

    Every key is optional. Host and port may also be supplied later to the
    session's ``connect`` method.

    Fields:
        name: Workspace label used by ``session(name)``.
        host/port: Default remote endpoint.
        encoding: Encoding used by ``send`` and received-text decoding.
        append_crlf: Append CRLF when sending text.
        local_echo: Display transmitted text locally.
        autoscroll/timestamps: Terminal presentation options.
    """
    name: str
    host: str
    port: int
    encoding: str
    append_crlf: bool
    local_echo: bool
    autoscroll: bool
    timestamps: bool


if TYPE_CHECKING:
    class ToolUnavailableError(RuntimeError):
        """Raised when a requested tool or session is unavailable."""

    class ToolCallFuture(Generic[_T]):
        """Thread-safe handle returned by asynchronous tool operations.

        The operation normally runs on a tool-owned worker thread. Calling
        ``result`` waits for completion and re-raises any worker exception.
        """
        def done(self) -> bool:
            """Return ``True`` once a result or exception has been recorded."""
            ...
        def result(self, timeout: Optional[float] = None) -> _T:
            """Wait for and return the result.

            Args:
                timeout: Maximum seconds to wait, or ``None`` to wait forever.

            Raises:
                TimeoutError: The operation did not finish before ``timeout``.
                BaseException: The original exception raised by the operation.
            """
            ...

    class ToolSubscription:
        """Disposable connection between a Qt signal and a callback."""
        def unsubscribe(self) -> None:
            """Disconnect the callback. Repeated calls are safe."""
            ...
        def close(self) -> None:
            """Alias for ``unsubscribe``; useful with generic disposable handling."""
            ...

    class MessageSubscription:
        """Disposable live message callback with bounded serial background delivery."""
        def unsubscribe(self) -> None:
            """Discard pending records and prevent new callbacks from starting."""
            ...
        def close(self) -> None:
            """Alias for unsubscribe(). An executing callback may finish."""
            ...
        def status(self) -> Dict[str, Any]:
            """Return connection state, queue depth, delivery/drop counts and errors."""
            ...

    class _ToolAPI:
        """Common lifecycle operations shared by every top-level tool API."""
        @property
        def widget(self) -> Any | None:
            """Current tool window, or ``None`` when it has not been opened.

            Reading this property never creates a window. Direct widget access
            is advanced usage and must obey Qt's main-thread rules.
            """
            ...
        @property
        def available(self) -> bool:
            """Whether this tool currently has a live window instance."""
            ...
        def open(self) -> Any:
            """Open the tool window if necessary and return its widget."""
            ...
        def show(self) -> Any:
            """Alias for ``open``."""
            ...
        def close(self) -> Any:
            """Request that the current tool window close; do nothing if absent."""
            ...
        def subscribe(self, signal_name: str, callback: Callable[..., Any]) -> ToolSubscription:
            """Connect ``callback`` to a named Qt signal and return a disposable handle.

            The tool opens automatically if required. The callback runs according
            to normal Qt signal/receiver thread-affinity rules.
            """
            ...

    class FTPClientAPI(_ToolAPI):
        """Thread-aware access to the built-in FTP client.

        High-level transfer methods coordinate with the GUI job list. Use
        ``run_raw`` or ``run_raw_async`` for direct access to the owned
        ``ftplib.FTP`` object without moving protocol work onto the GUI thread.

        Example:
            future = Tools.ftp_client.connect("ftp.example.com", user="me", password="secret")
            future.result(10)
            names = Tools.ftp_client.listdir("/incoming")
            Tools.ftp_client.upload("report.csv", "/incoming")
        """
        @property
        def backend(self) -> Any | None:
            """FTP worker/backend object, or ``None`` before the window opens.

            Prefer the documented high-level methods. This object is exposed for
            integration with backend-specific jobs and signals.
            """
            ...
        @property
        def raw(self) -> Any | None:
            """Underlying connected ``ftplib.FTP`` object, otherwise ``None``.

            Do not call it directly from arbitrary threads. Pass work to
            ``run_raw`` or ``run_raw_async`` so it runs on the FTP owner thread.
            """
            ...
        @property
        def connected(self) -> bool:
            """Whether an underlying FTP protocol object is currently connected."""
            ...
        @property
        def cwd(self) -> Optional[str]:
            """Remote directory currently shown by the FTP window, if available."""
            ...
        def connect(self, host: str, port: int = 21, user: str = "anonymous", password: str = "") -> ToolCallFuture[Any]:
            """Apply connection settings and begin connecting asynchronously.

            The returned future completes on the FTP worker. Call ``result``
            only when the caller may safely block.
            """
            ...
        def disconnect(self) -> Optional[ToolCallFuture[Any]]:
            """Begin disconnecting on the FTP worker.

            Returns a future when the client window/backend exists, otherwise
            ``None``. The window itself remains open.
            """
            ...
        def run_raw_async(self, func: Callable[[Any], _T]) -> ToolCallFuture[_T]:
            """Run ``func(ftp)`` on the FTP owner thread and return immediately."""
            ...
        def run_raw(self, func: Callable[[Any], _T], timeout: Optional[float] = 30) -> _T:
            """Run ``func(ftp)`` on the FTP owner thread and wait for its result."""
            ...
        def listdir(self, path: str = ".", timeout: Optional[float] = 30) -> list[Any]:
            """Synchronously list a remote directory without changing the displayed cwd.

            MLSD-capable servers return ``(name, facts)`` pairs; older servers
            may return a simple list of names. Requires an active connection.
            """
            ...
        def mkdir(self, path: str) -> ToolCallFuture[Any]:
            """Create a remote directory asynchronously and return its future."""
            ...
        def delete(self, path: str) -> ToolCallFuture[Any]:
            """Delete one remote file asynchronously."""
            ...
        def rmdir(self, path: str) -> ToolCallFuture[Any]:
            """Remove an empty remote directory asynchronously."""
            ...
        def rename(self, source: str, destination: str) -> ToolCallFuture[Any]:
            """Rename or move a remote path asynchronously."""
            ...
        def cancel(self, job_id: int) -> ToolCallFuture[Any]:
            """Request cancellation of a queued/running transfer job by ID."""
            ...
        def navigate(self, path: str) -> Any:
            """Open the client if needed and display ``path`` in its remote browser."""
            ...
        def refresh(self) -> Any:
            """Refresh the remote browser at its currently displayed directory."""
            ...
        def jobs(self) -> list[Any]:
            """Return snapshots of transfer jobs currently known to the FTP window."""
            ...
        def upload(self, local_paths: str | Iterable[str], remote_directory: Optional[str] = None) -> list[int]:
            """Queue files or directories for upload and return newly created job IDs.

            ``local_paths`` accepts one path or any iterable of paths. Directories
            are expanded by the client. ``remote_directory`` defaults to the
            directory currently displayed in the remote browser.
            """
            ...
        def download(self, remote_items: list[dict[str, Any]], local_directory: Optional[str] = None) -> list[int]:
            """Queue remote item dictionaries for download and return their job IDs.

            Each dictionary is a remote-browser item containing at least its
            remote name/path and directory metadata. ``local_directory`` defaults
            to the client window's current local directory.
            """
            ...
        def delete_local(self, paths: str | Iterable[str]) -> Any:
            """Delete local paths through the FTP window's normal guarded UI action."""
            ...
        def open_local_in_explorer(self, path: str) -> Any:
            """Open a local path in the operating-system file explorer."""
            ...

    class FTPServerAPI(_ToolAPI):
        """Control the built-in FTP server, users, sessions, and server thread.

        Example:
            Tools.ftp_server.add_user("operator", "secret", "shared", home_relative=True)
            Tools.ftp_server.start("0.0.0.0", 2121)
            print(Tools.ftp_server.sessions())
            Tools.ftp_server.stop()

        User-management calls open the server window if necessary and persist
        the resulting configuration. Starting/stopping is routed to the GUI
        thread; raw server callbacks run on the server's owner thread.
        """
        @property
        def thread(self) -> Any | None:
            """Current FTP server worker thread, or ``None`` before startup."""
            ...
        @property
        def raw(self) -> Any | None:
            """Underlying pyftpdlib server object while the server is running.

            Use ``run_raw`` or ``run_raw_async`` instead of invoking this object
            from callback threads.
            """
            ...
        @property
        def authorizer(self) -> Any | None:
            """Current pyftpdlib authorizer containing configured user accounts."""
            ...
        @property
        def running(self) -> bool:
            """Whether the server worker currently owns a running server loop."""
            ...
        def start(self, host: Optional[str] = None, port: Optional[int] = None) -> Any:
            """Start listening, optionally overriding the persisted host and port."""
            ...
        def stop(self, confirm: bool = False) -> Any:
            """Stop accepting connections and close active server resources.

            Set ``confirm=True`` to use the window's confirmation prompt. The
            default is suitable for programmatic shutdown from callbacks.
            """
            ...
        def add_user(self, username: str, password: str, home: str, permissions: str = "elradfmwMT", home_relative: bool = False) -> Any:
            """Add and persist an FTP account.

            ``home_relative=True`` resolves ``home`` relative to ``PROJECT_ROOT``.
            Permissions use pyftpdlib's permission-letter format.
            """
            ...
        def remove_user(self, username: FTPUserName) -> bool:
            """Remove and persist a configured account; return whether it existed."""
            ...
        def update_user(self, username: FTPUserName, *, new_username: Optional[str] = None, password: str, home: str, permissions: str = "elradfmwMT", home_relative: bool = False) -> Any:
            """Replace an existing account with the supplied values.

            All account fields except ``new_username`` are required because the
            update is implemented as a validated remove-and-add operation.
            Raises ``KeyError`` when ``username`` does not exist.
            """
            ...
        def users(self) -> list[dict[str, Any]]:
            """Return persisted account dictionaries, opening the window if needed."""
            ...
        def sessions(self) -> list[Any]:
            """Return a thread-safe snapshot of currently connected FTP sessions."""
            ...
        def logs(self) -> list[Any]:
            """Return a copy of entries currently displayed in the server log."""
            ...
        def clear_logs(self) -> Any:
            """Clear displayed server log entries without stopping the server."""
            ...
        def run_raw_async(self, func: Callable[[Any], _T]) -> ToolCallFuture[_T]:
            """Schedule ``func(server)`` on the running server thread."""
            ...
        def run_raw(self, func: Callable[[Any], _T], timeout: Optional[float] = 30) -> _T:
            """Schedule ``func(server)`` and wait for its return value."""
            ...

    class SerialSessionAPI:
        """Stable callback facade for one serial workspace session.

        Text writes use the configured encoding. Raw callbacks execute on the
        serial worker, which is the safe place to access the underlying port.

        Example:
            session = Tools.serial.session("Local Loopback")
            session.connect()
            session.write("STATUS?\\r\\n")
            raw_bytes, decoded_text = session.buffers()
        """
        @property
        def widget(self) -> Any:
            """Live serial session widget.

            This is advanced Qt access; manipulate it only from the GUI thread.
            The facade raises ``ToolUnavailableError`` after the session closes.
            """
            ...
        @property
        def name(self) -> str:
            """Current human-readable session name."""
            ...
        @property
        def connected(self) -> bool:
            """Whether the session currently has an active serial worker/port."""
            ...
        @property
        def worker(self) -> Any | None:
            """Serial owner worker, or ``None`` while disconnected."""
            ...
        @property
        def raw(self) -> Any | None:
            """Underlying ``serial.Serial``-compatible object while connected.

            Use the raw runner methods to execute operations on its owner thread.
            """
            ...
        @property
        def terminal(self) -> Any:
            """Terminal data/model object used by the session's visual terminal."""
            ...
        def settings(self) -> SerialSettings:
            """Return a thread-safe snapshot of the session's persisted settings."""
            ...
        def connect(self) -> Any:
            """Connect using current settings; the request is routed to the GUI thread."""
            ...
        def disconnect(self) -> Any:
            """Disconnect the serial port while keeping the workspace session."""
            ...
        def configure(self, **settings: Any) -> SerialSettings:
            """Apply supported serial settings, persist them, and return the snapshot.

            Accepted keys are documented by ``SerialSettings``. Changing ``name``
            updates the workspace label; connection fields take effect through
            the session UI/worker configuration.
            """
            ...
        def write(self, data: str | bytes) -> None:
            """Queue bytes for transmission without blocking.

            Strings are encoded using the session encoding. This does not append
            configured Enter/line-ending bytes automatically.
            """
            ...
        def send(self, data: str | bytes) -> None:
            """Alias for ``write``."""
            ...
        def execute(self, text: str, expected: Optional[str] = None, timeout: float = 3, match_type: str = "substring") -> Any:
            """Send a macro command and optionally wait for matching received text.

            Args:
                text: Command text passed to the session macro engine.
                expected: Response pattern; omit to send without response matching.
                timeout: Maximum response wait in seconds.
                match_type: Macro matcher mode, commonly ``substring``.
            """
            ...
        def buffers(self) -> tuple[bytes, str]:
            """Return copies of accumulated receive data as ``(bytes, decoded_text)``."""
            ...
        def run_raw_async(self, func: Callable[[Any], _T]) -> ToolCallFuture[_T]:
            """Run ``func(serial_object)`` on the serial worker and return a future."""
            ...
        def run_raw(self, func: Callable[[Any], _T], timeout: Optional[float] = 30) -> _T:
            """Run ``func(serial_object)`` on the serial worker and wait for its result."""
            ...
        def subscribe(self, signal_name: str, callback: Callable[..., Any]) -> ToolSubscription:
            """Subscribe to a signal exposed by the session or its active worker.

            Raises ``AttributeError`` when neither object exposes ``signal_name``.
            """
            ...

    class TelnetSessionAPI:
        """Stable callback facade for one Telnet workspace session.

        ``send`` applies the session's text and line-ending configuration;
        ``write`` sends bytes directly through the reader's owner thread.

        Example:
            session = Tools.telnet.session("Local Echo")
            session.connect()
            session.send("PING")
            result = session.execute("VERSION", expected="Version:", timeout=5)
        """
        @property
        def widget(self) -> Any:
            """Live Telnet session widget; direct Qt use requires the GUI thread."""
            ...
        @property
        def name(self) -> str:
            """Current human-readable session name."""
            ...
        @property
        def connected(self) -> bool:
            """Whether the session currently owns a connected Telnet reader."""
            ...
        @property
        def reader(self) -> Any | None:
            """Telnet owner reader/worker, or ``None`` while disconnected."""
            ...
        @property
        def raw(self) -> Any | None:
            """Underlying Telnet protocol object while connected.

            Use ``run_raw`` or ``run_raw_async`` for owner-thread access.
            """
            ...
        @property
        def socket(self) -> Any | None:
            """Socket owned by the underlying protocol object, otherwise ``None``."""
            ...
        def settings(self) -> TelnetSettings:
            """Return a thread-safe snapshot of current persisted session settings."""
            ...
        def connect(self, host: Optional[str] = None, port: Optional[int] = None) -> Any:
            """Connect using optional host/port overrides or the persisted values."""
            ...
        def disconnect(self) -> Any:
            """Disconnect the network connection while retaining the session."""
            ...
        def configure(self, **settings: Any) -> TelnetSettings:
            """Merge, apply, and persist settings, returning the resulting snapshot.

            Accepted keys are documented by ``TelnetSettings``. Existing fields
            not supplied by the caller are preserved.
            """
            ...
        def send(self, text: str) -> Any:
            """Send text using configured encoding and line-ending behavior."""
            ...
        def write(self, data: bytes) -> None:
            """Queue exact bytes without applying text encoding or line endings."""
            ...
        def execute(self, text: str, expected: Optional[str] = None, timeout: float = 3, match_type: str = "substring") -> Any:
            """Send a macro command and optionally wait for matching received text.

            Args:
                text: Command text passed to the session macro engine.
                expected: Response pattern; omit to send without response matching.
                timeout: Maximum response wait in seconds.
                match_type: Macro matcher mode, commonly ``substring``.
            """
            ...
        def buffers(self) -> tuple[bytes, str]:
            """Return copies of accumulated receive data as ``(bytes, decoded_text)``."""
            ...
        def run_raw_async(self, func: Callable[[Any], _T]) -> ToolCallFuture[_T]:
            """Run ``func(protocol_object)`` on the Telnet reader and return a future."""
            ...
        def run_raw(self, func: Callable[[Any], _T], timeout: Optional[float] = 30) -> _T:
            """Run ``func(protocol_object)`` on the Telnet reader and wait for its result."""
            ...
        def subscribe(self, signal_name: str, callback: Callable[..., Any]) -> ToolSubscription:
            """Subscribe to a named signal exposed by the Telnet session widget."""
            ...

    class SerialAPI(_ToolAPI):
        """Manage the serial workspace and its persisted named sessions.

        Session annotations are regenerated from serial.json while the general
        overloads continue to accept sessions created dynamically at runtime.
        """
        @property
        def sessions(self) -> list[SerialSessionAPI]:
            """Facade objects for all currently open serial workspace sessions.

            Returns an empty list until the serial tool is opened. Use ``open``
            or ``new_session`` when the callback must create the workspace.
            """
            ...
        @property
        def selected(self) -> Optional[SerialSessionAPI]:
            """Currently selected serial session, or ``None`` if none is open."""
            ...
        @overload
        def session(self, name_or_index: SerialSessionName) -> SerialSessionAPI:
            """Find an open session by persisted name or zero-based index.

            This lookup does not open the serial window. It raises
            ``ToolUnavailableError`` when no matching open session exists.
            """
            ...
        @overload
        def session(self, name_or_index: SerialSessionIndex = 0) -> SerialSessionAPI:
            """Find an open serial session by a generated persisted index."""
            ...
        @overload
        def session(self, name_or_index: str | int = 0) -> SerialSessionAPI:
            """Find an open serial session by name or zero-based index.

            Generated overloads suggest persisted values, while this overload
            accepts runtime-created sessions. Lookup does not open the tool and
            raises ``ToolUnavailableError`` when no matching open session exists.
            """
            ...
        def new_session(self, settings: Optional[SerialSettings] = None) -> SerialSessionAPI:
            """Create, persist, and return a session initialized from ``settings``."""
            ...
        def close_session(self, name_or_index: SerialSessionName | SerialSessionIndex | str | int = 0) -> Any:
            """Remove the identified session from the workspace and persist the change."""
            ...
        def select(self, name_or_index: SerialSessionName | SerialSessionIndex | str | int = 0) -> SerialSessionAPI:
            """Select the identified session in the workspace and return its facade."""
            ...
        def ports(self) -> list[Any]:
            """Return pyserial port descriptors discovered on the local machine."""
            ...

    class TelnetAPI(_ToolAPI):
        """Manage the Telnet workspace and its persisted named sessions.

        Session annotations are regenerated from telnet.json while the general
        overloads continue to accept sessions created dynamically at runtime.
        """
        @property
        def sessions(self) -> list[TelnetSessionAPI]:
            """Facade objects for all currently open Telnet workspace sessions.

            Returns an empty list until the Telnet tool is opened. Use ``open``
            or ``new_session`` when the callback must create the workspace.
            """
            ...
        @property
        def selected(self) -> Optional[TelnetSessionAPI]:
            """Currently selected Telnet session, or ``None`` if none is open."""
            ...
        @overload
        def session(self, name_or_index: TelnetSessionName) -> TelnetSessionAPI:
            """Find an open session by persisted name or zero-based index.

            This lookup does not open the Telnet window. It raises
            ``ToolUnavailableError`` when no matching open session exists.
            """
            ...
        @overload
        def session(self, name_or_index: TelnetSessionIndex = 0) -> TelnetSessionAPI:
            """Find an open Telnet session by a generated persisted index."""
            ...
        @overload
        def session(self, name_or_index: str | int = 0) -> TelnetSessionAPI:
            """Find an open Telnet session by name or zero-based index.

            Generated overloads suggest persisted values, while this overload
            accepts runtime-created sessions. Lookup does not open the tool and
            raises ``ToolUnavailableError`` when no matching open session exists.
            """
            ...
        def new_session(self, settings: Optional[TelnetSettings] = None) -> TelnetSessionAPI:
            """Create, persist, and return a Telnet session from ``settings``."""
            ...
        def close_session(self, name_or_index: TelnetSessionName | TelnetSessionIndex | str | int = 0) -> Any:
            """Remove the identified session from the workspace and persist the change."""
            ...
        def select(self, name_or_index: TelnetSessionName | TelnetSessionIndex | str | int = 0) -> TelnetSessionAPI:
            """Select the identified session in the workspace and return its facade."""
            ...

    class CommunicationSessionAPI:
        """One persisted, process-isolated Communication Hub session.

        The facade is valid whether the Hub window is visible, hidden, or has
        never been opened. Starting through this API uses the same controller,
        retained message table, periodic schedules, and Protocol Insight
        publishers that the UI attaches to later.
        """
        session_id: str
        def subscribe(self, signal_name: Literal["message"], callback: Callable[[Dict[str, Any]], Any], *, query: Optional[Dict[str, Any]] = None, queue_size: int = 1024, overflow: Literal["drop_oldest", "drop_newest"] = "drop_oldest") -> MessageSubscription:
            """Subscribe to new stored RX/TX records without starting the session.

            Uses the Hub query format. Callbacks run serially in a background
            thread, with best-effort delivery and a bounded pending queue.
            """
            ...
        @property
        def name(self) -> str: ...
        @property
        def protocol(self) -> str: ...
        @property
        def lifecycle_scope(self) -> str: ...
        @property
        def application_lifetime(self) -> bool: ...
        @property
        def restore_last_state(self) -> bool: ...
        @property
        def running(self) -> bool: ...
        def config(self) -> Dict[str, Any]:
            """Return a deep copy of the normalized persisted session configuration.

            Editing the returned dictionary has no effect until it is passed to
            ``configure``. The result includes transport, framing, parser,
            processing, storage, persistence, autostart, and lifecycle settings.
            """
            ...
        def set_application_lifetime(self, enabled: bool = True) -> str:
            """Persist whether this worker may outlive a closed Hub window.

            Returns ``"application"`` when enabled and ``"window"`` otherwise.
            This controls window detachment only; application shutdown always
            performs an orderly stop.
            """
            ...
        def set_restore_last_state(self, enabled: bool = True) -> bool:
            """Persist whether a previously running session is restored on reopen."""
            ...
        def start(self) -> Dict[str, Any]:
            """Start both isolated worker processes and synchronize Hub features.

            The call waits for backend startup, then installs periodic schedules
            and connects active Protocol Insight publishers. It is idempotent for
            an already-running session and returns the current worker status.
            """
            ...
        def stop(self) -> Dict[str, Any]:
            """Drain captures, retain the final table, and return stopped status.

            Incomplete drains or forced termination return state="error" with
            shutdown_errors; status() retains those diagnostics after cleanup.
            """
            ...
        def restart(self) -> Dict[str, Any]:
            """Orderly stop and then start this same persisted session."""
            ...
        def status(self) -> Dict[str, Any]:
            """Return transport, processing, table, persistence, and error metrics."""
            ...
        def send(self, data: str | bytes, encoding: str = "utf-8", target: str = "") -> Dict[str, Any]:
            """Send exact bytes through the running transport.

            ``str`` data is encoded with ``encoding``. ``bytes`` is transmitted
            unchanged. Receive framing is never added to outbound data. For a
            TCP server, ``target`` is ``"all"`` or a client connection id.
            """
            ...
        def query(self, query: Optional[Dict[str, Any]] = None, **options: Any) -> Dict[str, Any]:
            """Query the current or retained message table with Hub query JSON.

            Options include ``page``, ``page_size``, ``sort_by``, and
            ``descending``. The result contains rows, total count, and table
            version. An empty query matches every retained row.
            """
            ...
        def delete_preview(self, query: Optional[Dict[str, Any]] = None) -> Dict[str, Any]: ...
        def delete(self, query: Optional[Dict[str, Any]] = None, expected_version: Optional[int] = None) -> Dict[str, Any]: ...
        def names(self) -> list[str]: ...
        def fields(self, name: Optional[str] = None) -> Dict[str, list[str]]: ...
        def clients(self) -> list[Dict[str, Any]]: ...
        def configure(self, config: Optional[Dict[str, Any]] = None, **changes: Any) -> Dict[str, Any]:
            """Normalize and persist configuration for this stopped session.

            With no ``config``, keyword changes are merged into the current
            configuration. With ``config``, that dictionary is the replacement
            base. The session id is preserved. Stop the session before calling.
            """
            ...
        def duplicate(self, name: Optional[str] = None) -> CommunicationSessionAPI:
            """Create a stopped copy with a fresh id and optional replacement name."""
            ...
        def select(self) -> CommunicationSessionAPI:
            """Select this session in the shared UI workspace and return this facade."""
            ...
        def remove(self) -> bool:
            """Remove this stopped configuration and disable schedules targeting it."""
            ...
        def export_messages(self, path: str, query: Optional[Dict[str, Any]] = None, scope_label: Optional[str] = None) -> Dict[str, Any]:
            """Export matching current or retained rows to a verified XLSX workbook."""
            ...
        def apply_protocol_insight(self, config: Dict[str, Any]) -> Dict[str, Any]:
            """Persist and start a session-scoped insight (compatibility wrapper)."""
            ...
        def export_protocol_insight(self, protocol_insight_id: str, final: bool = True, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]: ...
        def protocol_insight_checkpoint_info(self, config: Dict[str, Any]) -> Dict[str, Any]: ...
        def pause_protocol_insight(self, protocol_insight_id: str) -> Dict[str, Any]: ...
        def resume_protocol_insight(self, protocol_insight_id: str) -> Dict[str, Any]: ...
        def remove_protocol_insight(self, protocol_insight_id: str) -> bool: ...

    class ProtocolInsightAPI:
        """One persisted Protocol Insight backed by the Hub's shared service.

        API and UI operations address the same configuration and runtime id.
        Starting headlessly therefore appears as running when the Hub window is
        opened later, including retained samples, checkpoints, and Excel state.
        """
        insight_id: str
        @property
        def name(self) -> str: ...
        @property
        def active(self) -> bool: ...
        @property
        def paused(self) -> bool: ...
        def config(self) -> Dict[str, Any]:
            """Return a deep copy of the full normalized visual/dataset configuration."""
            ...
        def configure(self, config: Optional[Dict[str, Any]] = None, **changes: Any) -> Dict[str, Any]:
            """Normalize and persist a stopped insight while preserving its id."""
            ...
        def set_application_lifetime(self, enabled: bool = True) -> str:
            """Persist whether an active insight may continue after its window closes."""
            ...
        def set_restore_last_state(self, enabled: bool = True) -> bool:
            """Persist whether prior active intent is restored when the Hub opens."""
            ...
        def duplicate(self, name: Optional[str] = None) -> ProtocolInsightAPI:
            """Create a stopped copy with fresh view/runtime ids and optional name."""
            ...
        def runtime_config(self) -> Dict[str, Any]:
            """Compile the persisted visual configuration into service input."""
            ...
        def start(self, start_source_sessions: bool = False) -> Dict[str, Any]:
            """Start collection and connect publishers for all in-scope sessions.

            Set ``start_source_sessions=True`` to start stopped source sessions;
            otherwise only already-running sessions publish new records. A
            ``retained_then_new`` source replays available retained tables first.
            Returns the service result, replay count, and publisher session ids.
            """
            ...
        def status(self) -> Dict[str, Any]:
            """Return persisted active/paused intent plus service runtime metrics."""
            ...
        def pause(self) -> Dict[str, Any]:
            """Pause dataset collection/checkpoint/output maintenance without deleting it."""
            ...
        def resume(self) -> Dict[str, Any]:
            """Ensure the shared runtime exists and resume collection."""
            ...
        def stop(self) -> bool:
            """Orderly delete the runtime and persist deliberately-stopped intent."""
            ...
        def samples(self, limit: int = 1000) -> list[Dict[str, Any]]:
            """Return up to ``limit`` retained dataset samples from the service."""
            ...
        def display_snapshot(self, sample_limit: int = 1000, event_limit: int = 1000) -> Dict[str, Any]:
            """Return the same bounded samples/events snapshot consumed by the UI."""
            ...
        def checkpoint_info(self) -> Dict[str, Any]:
            """Inspect checkpoint availability and timestamps for this configuration."""
            ...
        def export(self, final: bool = True) -> Dict[str, Any]:
            """Create the configured Excel output from live data or a stopped checkpoint."""
            ...
        def remove(self) -> bool:
            """Stop if needed and remove the persisted insight configuration."""
            ...

    class CommunicationAPI(_ToolAPI):
        """Manage the shared Communication Hub without requiring its window.

        Reading or mutating this API invisibly acquires one retained Hub owner.
        ``open()`` merely attaches and displays the UI for that same owner; it
        does not create a second interface or duplicate running backends.
        """
        def subscribe(self, signal_name: str, callback: Callable[..., Any], *, query: Optional[Dict[str, Any]] = None, queue_size: int = 1024, overflow: Literal["drop_oldest", "drop_newest"] = "drop_oldest") -> MessageSubscription | ToolSubscription:
            """Subscribe to 'message' across current and future sessions.

            Other signal names retain generic Qt signal subscription behavior.
            """
            ...
        @property
        def sessions(self) -> list[CommunicationSessionAPI]:
            """Return facades for every persisted session, creating no windows."""
            ...
        @property
        def selected(self) -> Optional[CommunicationSessionAPI]:
            """Return the session currently selected by the shared Hub workspace."""
            ...
        @overload
        def session(self, name_or_index: CommunicationSessionName) -> CommunicationSessionAPI: ...
        @overload
        def session(self, name_or_index: CommunicationSessionIndex = 0) -> CommunicationSessionAPI: ...
        @overload
        def session(self, name_or_index: str | int = 0) -> CommunicationSessionAPI:
            """Find a persisted session by name, id, or zero-based index."""
            ...
        def new_session(self, config: Optional[Dict[str, Any]] = None) -> CommunicationSessionAPI:
            """Normalize, persist, and return a new TCP, Serial, or Telnet session.

            Omitted fields receive Communication Hub defaults. Important keys
            include ``protocol``, ``transport``, ``framing``, ``parser``,
            ``processing``, ``storage``, ``persistence``, and ``lifecycle``.
            """
            ...
        def select(self, name_or_index: CommunicationSessionName | CommunicationSessionIndex | str | int = 0) -> CommunicationSessionAPI:
            """Select a persisted session in the shared workspace and return it."""
            ...
        @property
        def protocol_insights(self) -> list[ProtocolInsightAPI]:
            """Return facades for every persisted Protocol Insight."""
            ...
        @overload
        def protocol_insight(self, name_or_index: ProtocolInsightName) -> ProtocolInsightAPI: ...
        @overload
        def protocol_insight(self, name_or_index: ProtocolInsightIndex = 0) -> ProtocolInsightAPI: ...
        @overload
        def protocol_insight(self, name_or_index: str | int = 0) -> ProtocolInsightAPI:
            """Find a persisted insight by name, id, or zero-based index."""
            ...
        def new_protocol_insight(self, config: Optional[Dict[str, Any]] = None) -> ProtocolInsightAPI:
            """Normalize and persist a visual/dataset insight configuration.

            Configuration covers source scope/filter/history, x-axis, subplots,
            series extractors/processors/thresholds, event markers, retention,
            checkpoints, Excel output, autostart, and lifecycle. Call ``start``
            on the returned facade after defining at least one value series.
            """
            ...
        def query(self, query: Optional[Dict[str, Any]] = None, page: int = 0, page_size: int = 200) -> Dict[str, Any]:
            """Query every running or retained session table as one time-sorted table.

            The response matches the UI's Global table and contains ``rows``,
            ``total``, pagination fields, and a version per contributing session.
            """
            ...
        def delete_preview(self, query: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
            """Count matching rows per session and globally without deleting."""
            ...
        def delete(self, query: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
            """Delete matching rows from every available table and return the total."""
            ...
        def export_messages(self, path: str, query: Optional[Dict[str, Any]] = None, scope_label: str = "Global Communication Hub table") -> Dict[str, Any]:
            """Export the filtered global table through the UI's XLSX exporter."""
            ...
        @property
        def saved_messages(self) -> list[Dict[str, Any]]:
            """Return copies of reusable payloads shown in the Send workspace."""
            ...
        def save_message(self, name: str, content: str, encoding: str = "utf-8", message_id: Optional[str] = None) -> Dict[str, Any]:
            """Create or replace a reusable payload after validating its exact bytes.

            Use encoding ``"hex"`` for whitespace-tolerant hexadecimal content;
            otherwise ``content`` is validated with the named text encoding.
            Passing ``message_id`` replaces that entry. Without it, a matching
            name is replaced or a fresh id is created.
            """
            ...
        def remove_saved_message(self, name_or_id: str) -> bool:
            """Remove a saved payload by its exact name or id."""
            ...
        @property
        def saved_queries(self) -> list[Dict[str, Any]]:
            """Return copies of reusable Advanced/Guided query definitions."""
            ...
        def save_query(self, name: str, query: Dict[str, Any], query_id: Optional[str] = None) -> Dict[str, Any]:
            """Validate and create or replace reusable Hub query JSON."""
            ...
        def remove_saved_query(self, name_or_id: str) -> bool:
            """Remove a saved query by its exact name or id."""
            ...
        @property
        def periodic_messages(self) -> list[Dict[str, Any]]:
            """Return copies of all persisted worker-owned send schedules."""
            ...
        def schedule_periodic(
            self, session: CommunicationSessionAPI | CommunicationSessionName | CommunicationSessionIndex | str | int,
            name: str, content: str, interval_seconds: float, *, encoding: str = "utf-8",
            target: str = "", enabled: bool = True, auto_start: bool = True,
            start_with_session: bool = True, schedule_id: Optional[str] = None,
        ) -> Dict[str, Any]:
            """Create or replace a periodic send owned by the session worker.

            The minimum interval is 0.05 seconds. ``auto_start`` permits a
            one-shot send to start a stopped session; ``start_with_session``
            resumes a schedule previously paused by session stop. For TCP
            servers, ``target`` is ``"all"`` or a client connection id.
            Supplying ``schedule_id`` updates that schedule and retains counts.
            """
            ...
        def set_periodic_enabled(self, schedule_id: str, enabled: bool = True) -> Dict[str, Any]:
            """Pause or resume a persisted schedule and update a running worker."""
            ...
        def remove_periodic(self, schedule_id: str) -> bool:
            """Remove a schedule and update its running worker synchronously."""
            ...
        def send_periodic_now(self, schedule_id: str) -> Dict[str, Any]:
            """Synchronously send one scheduled payload and update its counters."""
            ...

    class ToolsProxy:
        """Stable callback entry point for all built-in connection tools.

        Tool windows are opened lazily. The ``Tools`` object remains stable when
        windows are opened, hidden, or reattached, making it safe to retain in
        callbacks and global declarations. Communication Hub APIs can acquire
        their shared runtime invisibly; ``open`` only attaches the UI.

        Attributes:
            ftp_client: FTP client transfers and raw protocol access.
            ftp_server: FTP server lifecycle, users, sessions, and logs.
            serial: Named serial sessions and serial-port discovery.
            telnet: Named Telnet sessions.
            communication: Process-isolated TCP client/server, Serial, and Telnet sessions.
        """
        ftp_client: FTPClientAPI
        ftp_server: FTPServerAPI
        serial: SerialAPI
        telnet: TelnetAPI
        communication: CommunicationAPI

    Tools: ToolsProxy
else:
    globals().update(_resolve_tool_symbols())


class InfoProgress(Protocol):
    """Progress controller returned by ``info_tqdm``.

    It supports manual updates, context-manager use, and iterable wrapping while
    routing progress state and messages to the selected InfoWidget.
    """
    def update(self, n: int = 1) -> None: ...
    def write(self, msg: str, level: str = "info") -> None: ...
    def set_description(self, desc: str) -> None: ...
    def close(self, state: str = "done") -> None: ...


def display(
    instance: OutputInstance,
    content: Union[str, bytes, QWidget, QPixmap, QImage, np.ndarray, DataFrame, Styler, Dict[str, Any]],
    mode: Literal["append", "replace"] = "append",
) -> None:
    """Display content in a configured OutputArea instance.

    Args:
        instance: Generated name of the destination OutputArea.
        content: Text, bytes, tabular data, an image, array, or live Qt widget.
        mode: Append to the current content or replace it entirely.

    The call is thread-safe; GUI changes are queued onto the Qt main thread.
    Rendering mode is selected from the value and OutputArea configuration.
    """


def spawn_input(
    helper: Callable[[Dict[str, Any]], None],
    input_widgets: Dict[str, Any],
    helper_on_thread: bool = True,
) -> None:
    """Show an inline input form and call ``helper`` with submitted values.

    ``input_widgets`` maps field labels to definition dictionaries. Supported
    ``type`` values and their options are:

    - ``str``: Single-line text input.
    - ``int``: Single-line input intended for an integer.
    - ``float``: Single-line input intended for a floating-point number.
    - ``dropdown``: Dropdown populated from ``options``.
    - ``radiobuttons``: Radio buttons populated from ``options``.
    - ``checkbox``: Boolean checkbox.
    - ``file selector``: File or folder picker.

    Common definition keys:

    - ``type``: Widget type string.
    - ``default``: Initial value. Defaults to ``None``.
    - ``placeholder``: Placeholder for ``str``, ``int``, and ``float`` inputs.
    - ``use_historical``: Restore the last submitted value for this button.
      Defaults to ``True`` and overrides ``default`` when history exists.

    Example containing every input type:

        spawn_input(
            helper=handle_input,
            input_widgets={{
                "Name": {{
                    "type": "str",
                    "default": "Sample",
                    "placeholder": "Enter a name",
                    "use_historical": True,
                }},
                "Count": {{
                    "type": "int",
                    "default": 10,
                    "placeholder": "Enter a whole number",
                }},
                "Threshold": {{
                    "type": "float",
                    "default": 0.75,
                    "placeholder": "Enter a decimal number",
                }},
                "Mode": {{
                    "type": "dropdown",
                    "options": ["fast", "balanced", "accurate"],
                    "default": "balanced",
                }},
                "Priority": {{
                    "type": "radiobuttons",
                    "options": ["low", "normal", "high"],
                    "default": "normal",
                }},
                "Enabled": {{
                    "type": "checkbox",
                    "default": True,
                }},
                "Input file": {{
                    "type": "file selector",
                    "default": "",
                    "allowed file extensions": [".txt", ".csv"],
                    "allow_multiple": False,
                }},
                "Input files": {{
                    "type": "file selector",
                    "allowed file extensions": [".png", ".jpg"],
                    "allow_multiple": True,
                }},
                "Output folder": {{
                    "type": "file selector",
                    "allowed file extensions": "only folder",
                    "allow_multiple": False,
                }},
            }},
            helper_on_thread=True,
        )

    ``options`` is required by ``dropdown`` and ``radiobuttons``. For a
    ``file selector``, ``allowed file extensions`` accepts a list such as
    ``[".txt", ".csv"]`` or the special value ``"only folder"``.
    ``allow_multiple`` defaults to ``False``.

    Submitted values are collected into one dictionary keyed by the labels and
    the helper is invoked as ``helper(inp=values)``. Text-like values are parsed
    when possible, so input such as ``"10"``, ``"2.5"``, ``"True"``, or a list
    literal may be returned as the corresponding Python value.

    When ``helper_on_thread`` is ``True``, the helper runs on a background
    thread and must not manipulate Qt widgets directly. Use the thread-safe
    callback APIs for UI updates. When it is ``False``, the helper runs directly
    on the GUI thread.
    """


def info_set_state(instance: InfoInstance, state: Literal["waiting", "running", "done", "failed", "reset", "aborted"] = "reset") -> None:
    """Set an InfoWidget's visual state and corresponding progress-bar color."""
    ...
def info_start(instance: InfoInstance) -> None:
    """Start elapsed-time tracking and switch the InfoWidget to ``running``."""
    ...
def info_stop(instance: InfoInstance) -> None:
    """Stop elapsed-time tracking and switch the InfoWidget to ``done``."""
    ...
def info_reset(instance: InfoInstance) -> None:
    """Reset progress, ETA, elapsed time, and state while retaining log text."""
    ...
def info_clear(instance: InfoInstance) -> None:
    """Clear the InfoWidget's text log without changing its progress state."""
    ...
def info_show(instance: InfoInstance) -> None:
    """Make the configured InfoWidget visible."""
    ...
def info_hide(instance: InfoInstance) -> None:
    """Hide the configured InfoWidget without deleting it."""
    ...
def info_set_progress(instance: InfoInstance, value: int, total: Optional[int] = None) -> None:
    """Update progress using an absolute value and optional total for percentage/ETA."""
    ...
def info_set_text(instance: InfoInstance, msg: str, popup: bool = False, append: bool = True, level: Literal["info", "warning", "error", "success"] = "info") -> None:
    """Write a severity-colored log message and optionally show the same text in a popup.

    Set ``append=False`` to replace existing log text. This call is thread-safe
    and queues widget updates onto the Qt main thread.
    """
    ...
def info_tqdm(instance: InfoInstance, iterable: Optional[Iterable[_T]] = None, total: Optional[int] = None, desc: Optional[str] = None) -> InfoProgress:
    """Create a GUI-native progress controller attached to an InfoWidget.

    Supply an iterable for automatic advancement, or ``total`` for manual calls
    to ``update``. Context-manager exit marks success or failure automatically.
    """
    ...
def route_prints(tab: TabName, instance: InfoInstance) -> None:
    """Route stdout and stderr to ``instance`` whenever ``tab`` is active.

    A later call for the same tab replaces its previous routing destination.
    """
    ...
'''
    source = textwrap.dedent(source).strip() + "\n"
    ast.parse(source, filename=CB_STUBS_PATH)
    return source


def regenerate_stubs(config: dict | None = None, path: str = CB_STUBS_PATH) -> bool:
    """Validate and atomically update the generated callback API.

    The destination is replaced only when its content changes. Source is first
    written and flushed to a temporary file in the same directory, then moved
    into place with ``os.replace`` so readers never observe a partial module.

    Args:
        config: Optional current UI configuration passed to ``render_stubs``.
        path: Destination path, primarily overridable for tests.

    Returns:
        ``True`` when a new file was installed, otherwise ``False``. Frozen
        builds return ``False`` because their imported module lives in the app
        bundle and cannot be updated by writing beside the executable.
    """
    # In frozen builds app.stubs is imported from the bundle; writing a second
    # copy beside the executable would not affect navigation or runtime imports.
    if getattr(sys, "frozen", False) and os.path.abspath(path) == os.path.abspath(CB_STUBS_PATH):
        return False
    source = render_stubs(config)
    destination = Path(path)
    with _WRITE_LOCK:
        try:
            if destination.read_text(encoding="utf-8") == source:
                return False
        except FileNotFoundError:
            pass
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(
            prefix=f".{destination.name}.", suffix=".tmp", dir=str(destination.parent)
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                stream.write(source)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, destination)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
    return True
