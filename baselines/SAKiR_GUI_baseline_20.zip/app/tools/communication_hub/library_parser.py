"""Validation and session-local loading of Message Designer parser packages."""
from __future__ import annotations

import importlib.util
from importlib.abc import MetaPathFinder
from importlib.machinery import PathFinder, SourceFileLoader
import inspect
import json
import sys
import uuid
import weakref
from pathlib import Path

from .config import resolve_project_path


AFTER_DECODE_MODES = ("dict", "object", "none")


class LibraryParserError(ValueError):
    pass


def validate_parser_library(directory: str | Path):
    """Check designer metadata and generated files without importing user code.

    This verifies package compatibility and consistency, not code trust. Behavior
    mixins and custom schema expressions execute when the session loads/decodes.
    """
    from ..message_designer.generation import content_hash
    from ..message_designer.persistence import MANAGED_FILES, load_library
    from ..message_designer.routing_model import participating_message_uids
    from ..message_designer.validation import blocking_issues

    try:
        loaded = load_library(directory)
        manifest = loaded.manifest
        issues = blocking_issues(manifest)
        if issues:
            raise LibraryParserError("Invalid library definitions: " + "; ".join(issue.message for issue in issues[:5]))
        if loaded.package_dir.name != manifest["library"]["package_name"]:
            raise LibraryParserError("Select the generated package folder matching the manifest's package name")
        hashes = manifest.get("generated_hashes")
        if not isinstance(hashes, dict) or not MANAGED_FILES.issubset(hashes):
            raise LibraryParserError("Generated-file hashes are missing. Save the library in Message Designer first.")
        # Only fixed generated filenames are read; manifest keys are never paths.
        for name in sorted(MANAGED_FILES):
            path = loaded.package_dir / name
            if not path.is_file():
                raise LibraryParserError(f"Required library file is missing: {name}")
            if content_hash(path.read_bytes()) != hashes[name]:
                raise LibraryParserError(f"Generated file differs from the designer manifest: {name}. Save the library in Message Designer again.")
        for name in ("__init__.py", "models.py", "registry.py", "behaviors.py"):
            path = loaded.package_dir / name
            if not path.is_file():
                raise LibraryParserError(f"Required library file is missing: {name}")
            compile(path.read_bytes(), str(path), "exec")
        if not participating_message_uids(manifest):
            raise LibraryParserError("The library has no messages included in automatic decoding. Assign routing values in Message Designer first.")
        return loaded
    except LibraryParserError:
        raise
    except Exception as error:
        raise LibraryParserError(f"Not a compatible Message Designer library: {error}") from error


class _LibrarySourceLoader(SourceFileLoader):
    def get_code(self, fullname):
        # Designer saves can replace same-sized sources within one timestamp
        # tick. Always read current source rather than a stale timestamp pyc.
        return self.source_to_code(self.get_data(self.path), self.path)


class _LibrarySourceFinder(MetaPathFinder):
    def __init__(self, namespace):
        self.namespace = namespace

    def find_spec(self, fullname, path=None, target=None):
        if fullname.startswith(self.namespace + "."):
            spec = PathFinder.find_spec(fullname, path)
            if spec is not None and isinstance(spec.loader, SourceFileLoader):
                spec.loader = _LibrarySourceLoader(fullname, spec.origin)
            return spec
        return None


def _remove_package(namespace, finder):
    if finder in sys.meta_path:
        sys.meta_path.remove(finder)
    for name in list(sys.modules):
        if name == namespace or name.startswith(namespace + "."):
            sys.modules.pop(name, None)


class LibraryMessageParser:
    """One decoder per runtime, imported from an explicit directory, not sys.path."""

    def __init__(self, config: dict, project_root: str | Path):
        from app.binary_messages import BinaryMessage, CompiledRoutingRegistry
        from ..message_designer.routing_model import routing_specification

        self.after_decode = config.get("after_decode", "dict")
        if self.after_decode not in AFTER_DECODE_MODES:
            raise LibraryParserError("Library after_decode must be dict, object, or none")
        directory = str(config.get("library_path", "")).strip()
        if not directory:
            raise LibraryParserError("A Message Designer library folder is required")
        loaded = validate_parser_library(resolve_project_path(project_root, directory))
        # Relative imports work under this private package name. A library with
        # the same public name already imported elsewhere cannot be reused here.
        namespace = "_hub_message_library_" + uuid.uuid4().hex
        finder = _LibrarySourceFinder(namespace)
        spec = importlib.util.spec_from_file_location(
            namespace, loaded.package_dir / "__init__.py",
            loader=_LibrarySourceLoader(namespace, str(loaded.package_dir / "__init__.py")),
            submodule_search_locations=[str(loaded.package_dir)],
        )
        try:
            package = importlib.util.module_from_spec(spec)
            sys.modules[namespace] = package
            sys.meta_path.insert(0, finder)
            spec.loader.exec_module(package)
            if Path(package.__file__).resolve() != loaded.package_dir / "__init__.py":
                raise LibraryParserError("The decoder was not loaded from the selected library")
            registry = package.REGISTRY
            decoder = package.decode_auto
            if (not isinstance(registry, CompiledRoutingRegistry)
                    or getattr(decoder, "__self__", None) is not registry
                    or getattr(decoder, "__func__", None) is not CompiledRoutingRegistry.decode_auto):
                raise LibraryParserError("The library does not expose the supported designer decode_auto API. Save it in Message Designer again.")
            registry_module = sys.modules[namespace + ".registry"]
            # Generated routing is JSON-backed; enum tuples become lists there.
            if json.dumps(registry_module.ROUTING_SPECIFICATION, sort_keys=True) != json.dumps(routing_specification(loaded.manifest), sort_keys=True):
                raise LibraryParserError("Generated routing differs from the designer manifest. Save the library in Message Designer again.")
            messages = loaded.manifest["messages"]
            if set(registry.message_types) != {item["uid"] for item in messages}:
                raise LibraryParserError("Generated message types differ from the designer manifest")
            inspect.signature(decoder).bind(b"", direction="RX", return_mode="dict", after_decode=self.after_decode)
            for item in messages:
                message_type = registry.message_types[item["uid"]]
                if not inspect.isclass(message_type) or not issubclass(message_type, BinaryMessage):
                    raise LibraryParserError("The library contains an unsupported message type")
                if message_type.__name__ != item["name"]:
                    raise LibraryParserError("Generated message names differ from the designer manifest")
                inspect.signature(message_type.decode).bind(b"", return_mode="dict", after_decode=self.after_decode)
            self.decode_auto = decoder
        except BaseException as error:
            _remove_package(namespace, finder)
            if isinstance(error, LibraryParserError):
                raise
            raise LibraryParserError(f"Could not load Message Designer library: {type(error).__name__}: {error}") from error
        self._cleanup = weakref.finalize(self, _remove_package, namespace, finder)

    def parse_message(self, message: bytes, direction):
        return self.decode_auto(message, direction=direction, return_mode="dict", after_decode=self.after_decode)
