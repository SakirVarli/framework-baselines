"""Explain dictionary decoding and explicitly select a library's hook mode."""
from PyQt5 import QtCore, QtWidgets


HOOK_OPTIONS = (
    ("dict", "Dictionary hook (recommended)",
     "Decode directly into a dictionary, then run after_decode_dict. Skips message object "
     "construction, from_wire, field initialization, and object validate. Use this for "
     "dictionary-based behavior and lower decoding overhead."),
    ("object", "Object hook",
     "Construct and validate the message object, run its after_decode hook, then export "
     "a dictionary with to_dict. Use this when existing behavior depends on message objects. "
     "Runtime attributes are excluded from the export by default."),
    ("none", "No hook",
     "Decode directly into a dictionary without running after_decode_dict or after_decode. "
     "Skips message object construction and object validation. Use this for decoded wire fields "
     "without after-decode customization."),
)


def hook_label(mode):
    return next(label for value, label, _ in HOOK_OPTIONS if value == mode)


class LibraryParserSetupDialog(QtWidgets.QDialog):
    def __init__(self, library_name, directory, mode="dict", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Use Message Designer library as parser")
        self.setWindowFlag(QtCore.Qt.WindowContextHelpButtonHint, False)
        self.resize(600, 430)
        layout = QtWidgets.QVBoxLayout(self)
        for text in (
            f"Library: {library_name}\nFolder: {directory}",
            "The hub will use this library's decode_auto for complete RX and TX messages, "
            "with return_mode=\"dict\" and the message's direction. The returned Name identifies "
            "the message in the table. Loading and decoding execute the library's Python code.",
            "Choose which after-decode behavior to run. Schema checks, expressions, and custom "
            "Construct adapters still run in every mode. Hook errors are reported as parser errors.",
        ):
            label = QtWidgets.QLabel(text)
            label.setTextFormat(QtCore.Qt.PlainText)
            label.setWordWrap(True)
            label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            layout.addWidget(label)
        self.mode = QtWidgets.QComboBox()
        for value, label, _ in HOOK_OPTIONS:
            self.mode.addItem(label, value)
        self.mode.setCurrentIndex(max(0, self.mode.findData(mode)))
        layout.addWidget(self.mode)
        # Keep all three explanations visible so users can compare before proceeding.
        for _, label, explanation in HOOK_OPTIONS:
            text = QtWidgets.QLabel(f"{label}: {explanation}")
            text.setWordWrap(True)
            layout.addWidget(text)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.button(QtWidgets.QDialogButtonBox.Ok).setText("Use library")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_mode(self):
        return self.mode.currentData()
