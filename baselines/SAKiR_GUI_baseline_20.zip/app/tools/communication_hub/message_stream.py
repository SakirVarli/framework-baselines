"""Bounded, independent delivery of stored messages to application callbacks."""
from __future__ import annotations

import copy
import inspect
import pickle
import queue
import threading
import uuid
import weakref
from collections import deque
from contextlib import nullcontext

from app.reload_effects import (
    current_effects, execution_token, execution_scope, StaleGenerationError,
    track_resource,
)
from .query import QueryEngine


class MessagePublisher:
    """Worker-side publisher. A blocked pipe never blocks parsing or Insights."""

    def __init__(self, connection, recipients=(), capacity=1024):
        self.connection = connection
        self.recipients = tuple(recipients)
        self.queue = queue.Queue(maxsize=capacity)
        self.stop = threading.Event()
        self.sequence = self.published = self.dropped = self.errors = 0
        self.last_error = ""
        self.thread = None
        if connection is not None:
            self.thread = threading.Thread(target=self._run, daemon=True, name="message-api-publisher")
            self.thread.start()

    def publish(self, record):
        if self.connection is None or not self.recipients:
            return
        self.sequence += 1
        try:
            # Freeze both the record and recipients at publication time.
            self.queue.put_nowait((self.sequence, self.recipients, copy.deepcopy(record)))
        except queue.Full:
            self.dropped += 1
        except Exception as error:
            self.errors += 1
            self.last_error = f"{type(error).__name__}: {error}"

    def _run(self):
        try:
            while not self.stop.is_set() or not self.queue.empty():
                try:
                    envelope = self.queue.get(timeout=.05)
                except queue.Empty:
                    continue
                try:
                    self.connection.send_bytes(pickle.dumps(envelope, protocol=pickle.HIGHEST_PROTOCOL))
                    self.published += 1
                except Exception as error:
                    self.errors += 1
                    self.last_error = f"{type(error).__name__}: {error}"
                finally:
                    self.queue.task_done()
        finally:
            self.connection.close()

    def status(self):
        return {"enabled": bool(self.recipients), "queued": self.queue.qsize(),
                "published": self.published, "dropped": self.dropped,
                "errors": self.errors, "last_error": self.last_error}

    def close(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=2)


class MessageStream:
    """Hub-owned router. No user callbacks run on pipe reader threads."""

    def __init__(self):
        self._lock = threading.RLock()
        self._control_lock = threading.RLock()
        self._subscriptions = {}
        self._controllers = weakref.WeakValueDictionary()
        self._readers = {}
        self._transport_stats = {}
        self._closed = False

    def register_controller(self, controller):
        with self._lock:
            self._controllers[str(controller.config["id"])] = controller

    def recipients(self, session_id):
        with self._lock:
            return tuple(key for key, sub in self._subscriptions.items()
                         if sub.session_id is None or sub.session_id == str(session_id))

    def _sync(self):
        with self._lock:
            controllers = list(self._controllers.values())
        for controller in controllers:
            if controller.running:
                controller.request("message_subscriptions", {
                    "recipients": self.recipients(controller.config["id"]),
                }, timeout=5)

    def add(self, subscription):
        with self._control_lock:
            with self._lock:
                if self._closed:
                    raise RuntimeError("Communication Hub message stream is closed")
                self._subscriptions[subscription.id] = subscription
            try:
                self._sync()
            except Exception:
                self.remove(subscription)
                raise

    def remove(self, subscription):
        with self._control_lock:
            with self._lock:
                self._subscriptions.pop(subscription.id, None)
                closed = self._closed
            if closed:
                return
            # Cleanup must succeed even when a backend has already failed.
            try:
                self._sync()
            except (RuntimeError, TimeoutError, OSError, EOFError):
                pass

    def open_reader(self, session_id, connection):
        self.close_reader(session_id)
        state = {"stop": threading.Event(), "connection": connection,
                 "received": 0, "dropped": 0, "last_error": ""}
        session_id = str(session_id)
        with self._lock:
            self._readers[session_id] = state
            stats = self._transport_stats.setdefault(session_id, {"dropped": 0, "last_error": ""})

        def read():
            last_sequence = 0
            try:
                while not state["stop"].is_set():
                    if not connection.poll(.05):
                        continue
                    sequence, recipients, record = pickle.loads(connection.recv_bytes())
                    gap = max(0, sequence - last_sequence - 1)
                    state["dropped"] += gap
                    with self._lock:
                        stats["dropped"] += gap
                    last_sequence = sequence
                    state["received"] += 1
                    with self._lock:
                        targets = [self._subscriptions[key] for key in recipients
                                   if key in self._subscriptions]
                    for subscription in targets:
                        subscription._offer(record)
            except (EOFError, OSError):
                pass
            except Exception as error:
                state["last_error"] = f"{type(error).__name__}: {error}"
                with self._lock:
                    stats["last_error"] = state["last_error"]
            finally:
                state["stop"].set()
                connection.close()

        state["thread"] = threading.Thread(target=read, daemon=True, name=f"message-api-reader-{session_id}")
        state["thread"].start()

    def close_reader(self, session_id, *, drain=False):
        with self._lock:
            state = self._readers.pop(str(session_id), None)
        if state is not None:
            if drain:
                # The worker has exited and closed its writer. Allow buffered
                # records to reach subscribers before stopping the reader.
                state["thread"].join(timeout=.5)
            state["stop"].set()
            state["thread"].join(timeout=.5)

    def connection_status(self, session_id):
        with self._lock:
            controllers = [(key, controller) for key, controller in self._controllers.items()
                           if session_id is None or key == session_id]
            states = {key: self._readers.get(key) for key, _ in controllers}
            stats = {key: dict(value) for key, value in self._transport_stats.items()
                     if session_id is None or key == session_id}
        connected = [key for key, controller in controllers if controller.running
                     and states[key] is not None and not states[key]["stop"].is_set()]
        return {"connection_state": "connected" if connected else "waiting",
                "connected_sessions": connected,
                "transport_dropped": sum(value["dropped"] for value in stats.values()),
                "transport_errors": {key: value["last_error"] for key, value in stats.items()
                                     if value["last_error"]}}

    def remove_session(self, session_id):
        with self._lock:
            subscriptions = [sub for sub in self._subscriptions.values() if sub.session_id == str(session_id)]
            self._controllers.pop(str(session_id), None)
        for subscription in subscriptions:
            subscription.unsubscribe()
        self.close_reader(session_id)

    def close(self):
        with self._lock:
            self._closed = True
            subscriptions = list(self._subscriptions.values())
            readers = list(self._readers)
        for subscription in subscriptions:
            subscription.unsubscribe()
        for session_id in readers:
            self.close_reader(session_id)


class MessageSubscription:
    """Generation-owned, serial callback delivery with a bounded pending queue."""

    def __init__(self, stream, callback, *, session_id=None, query=None,
                 queue_size=1024, overflow="drop_oldest"):
        if not callable(callback):
            raise TypeError("Message callback must be callable")
        if inspect.iscoroutinefunction(callback) or inspect.iscoroutinefunction(getattr(callback, "__call__", None)):
            raise TypeError("Message callbacks must be synchronous functions")
        if isinstance(queue_size, bool) or not isinstance(queue_size, int) or queue_size < 1:
            raise ValueError("queue_size must be a positive integer")
        if overflow not in {"drop_oldest", "drop_newest"}:
            raise ValueError("overflow must be drop_oldest or drop_newest")
        if query is not None and not isinstance(query, dict):
            raise TypeError("query must be a Hub query dictionary or None")
        self.id = str(uuid.uuid4())
        self.session_id = str(session_id) if session_id is not None else None
        self._stream = stream
        self._callback = callback
        self._query = copy.deepcopy(query)
        self._engine = QueryEngine()
        self._capacity = queue_size
        self._overflow = overflow
        self._condition = threading.Condition(threading.RLock())
        self._lifecycle_lock = threading.RLock()
        self._pending = deque()
        self._closed = self._active = self._in_callback = False
        self._delivered = self._dropped = self._errors = self._filter_errors = 0
        self._last_error = ""
        self._thread = None
        effects = current_effects()
        self._token = execution_token() or (effects.token if effects is not None else None)
        self._effects_ref = weakref.ref(effects) if effects is not None else None
        if effects is not None:
            effects.track(self)
            effects.subscriptions.append(self)
        else:
            track_resource(self)
            self._activate()

    def _activate(self):
        with self._lifecycle_lock:
            self._activate_locked()

    def _activate_locked(self):
        with self._condition:
            if self._closed or self._active:
                return
            effects = self._effects_ref() if self._effects_ref is not None else None
            if self._token is None and effects is not None:
                # Import transactions receive their generation after module
                # execution, before staged subscriptions are activated.
                self._token = effects.token
            self._effects_ref = None
            self._active = True
        try:
            self._stream.add(self)
            with self._condition:
                if not self._closed:
                    self._thread = threading.Thread(target=self._run, daemon=True, name=f"message-callback-{self.id}")
                    self._thread.start()
        except Exception:
            self.unsubscribe()
            raise

    def _offer(self, record):
        try:
            if self._query and not self._engine.matches_record(record, self._query):
                return
            record = copy.deepcopy(record)
        except Exception as error:
            with self._condition:
                self._filter_errors += 1
                self._last_error = f"{type(error).__name__}: {error}"
            return
        with self._condition:
            if self._closed or not self._active:
                return
            if len(self._pending) >= self._capacity:
                self._dropped += 1
                if self._overflow == "drop_newest":
                    return
                self._pending.popleft()
            self._pending.append(record)
            self._condition.notify()

    def _rebind_generation(self, registry, generation):
        """A retained resource joins a new generation only after its commit."""
        with self._condition:
            if not self._closed and self._token is not None and self._token[0] is registry:
                self._token = (registry, generation)

    def _run(self):
        while True:
            with self._condition:
                self._condition.wait_for(lambda: self._closed or self._pending)
                if self._closed:
                    return
                record = self._pending.popleft()
                self._in_callback = True
            try:
                scope = nullcontext()
                if self._token is not None:
                    registry, generation = self._token
                    runtime_ref = getattr(registry, "_callback_runtime_ref", None)
                    runtime = runtime_ref() if runtime_ref is not None else None
                    scope = runtime.callback_scope(generation) if runtime is not None else execution_scope(registry, generation)
                with scope:
                    self._callback(record)
                with self._condition:
                    self._delivered += 1
            except StaleGenerationError:
                # A reload may temporarily quiesce a preserved subscription.
                with self._condition:
                    self._dropped += 1
            except BaseException as error:
                with self._condition:
                    self._errors += 1
                    self._last_error = f"{type(error).__name__}: {error}"
            finally:
                with self._condition:
                    self._in_callback = False

    def status(self):
        with self._condition:
            result = {"active": self._active, "closed": self._closed,
                      "session_id": self.session_id, "queue_depth": len(self._pending),
                      "queue_size": self._capacity, "overflow": self._overflow,
                      "delivered": self._delivered, "dropped": self._dropped,
                      "callback_errors": self._errors, "filter_errors": self._filter_errors,
                      "last_error": self._last_error, "callback_running": self._in_callback}
        result.update(self._stream.connection_status(self.session_id))
        if result["closed"]:
            result["connection_state"] = "closed"
        elif not result["active"]:
            result["connection_state"] = "staged"
        return result

    def unsubscribe(self):
        with self._lifecycle_lock:
            self._unsubscribe_locked()

    def _unsubscribe_locked(self):
        with self._condition:
            if self._closed:
                return
            self._closed = True
            active, self._active = self._active, False
            self._dropped += len(self._pending)
            self._pending.clear()
            self._condition.notify_all()
        if active:
            self._stream.remove(self)

    close = unsubscribe
    __reload_dispose__ = unsubscribe
