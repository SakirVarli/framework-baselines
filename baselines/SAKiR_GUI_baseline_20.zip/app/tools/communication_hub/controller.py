from __future__ import annotations

import multiprocessing
import os
import queue
import threading
import time
import uuid
from pathlib import Path
import pandas as pd

from .config import normalize_session_config, resolve_project_path
from .store import EventStore
from .worker import session_process_entry
from .processing_worker import data_processing_process_entry


DATA_COMMANDS = {
    "query", "table_state", "delete_preview", "delete", "names",
    "name_summary", "fields", "protocol_insight_publisher", "persist", "message_subscriptions",
}


class SessionController:
    """GUI/callback-side owner of one spawned session worker."""

    def __init__(
        self,
        config: dict,
        project_root: str | Path,
        retained_table_state: dict | None = None,
        protocol_insight_ingress=None,
        protocol_insight_publisher_capacity: int = 1024,
        message_stream=None,
    ):
        self.config = normalize_session_config(config)
        self.project_root = str(project_root)
        self.process: multiprocessing.Process | None = None
        self.connection = None
        self.processing_process: multiprocessing.Process | None = None
        self.processing_connection = None
        self.capture_queue = None
        self.diagnostic_queue = None
        self._backend_errors: list[dict] = []
        self._shutdown_errors: list[str] = []
        self._stopped_io_status: dict = {}
        self.status_generation = 0
        self._poll_pending: dict = {}
        self._poll_completed: dict = {}
        self._poll_cache: dict = {}
        self._lock = threading.RLock()
        self._processing_lock = threading.RLock()
        self._retained_store: EventStore | None = None
        self.protocol_insight_ingress = protocol_insight_ingress
        self.message_stream = message_stream
        if message_stream is not None:
            message_stream.register_controller(self)
        self.protocol_insight_publisher_capacity = max(
            1, int(protocol_insight_publisher_capacity)
        )
        if retained_table_state is not None:
            self._retain_table(retained_table_state)

    @property
    def running(self) -> bool:
        process, processing_process = self.process, self.processing_process
        return bool(
            process and process.is_alive()
            and processing_process and processing_process.is_alive()
        )

    @property
    def table_available(self) -> bool:
        return self.running or self._retained_store is not None

    def _retain_table(self, state: dict):
        store = EventStore(self.config["storage"])
        store.restore_state(state)
        self._retained_store = store
        self.status_generation += 1

    def retained_table_state(self) -> dict | None:
        return self._retained_store.export_state() if self._retained_store is not None else None

    def table_snapshot(self, timeout: float = 60.0) -> pd.DataFrame:
        """Return a coherent copy of this session's current or retained message table."""
        if self.running:
            state = self.request("table_state", timeout=timeout)
        else:
            state = self.retained_table_state()
        frame = state.get("frame") if isinstance(state, dict) else None
        if not isinstance(frame, pd.DataFrame):
            raise RuntimeError(f"Session '{self.config['name']}' has no message table available")
        return frame.copy(deep=True)

    def _persistence_directory(self) -> Path:
        persistence = self.config.get("persistence", {})
        return resolve_project_path(self.project_root, persistence.get("directory", "app/data/communication_hub/logs")) / self.config["id"]

    def load_latest_persisted_table(self) -> dict:
        """Restore the newest final or periodic message snapshot without starting transport I/O."""
        if not self.config.get("persistence", {}).get("enabled"):
            return {"loaded": False, "path": ""}
        candidates = [
            path for path in (
                self._persistence_directory() / "messages_latest.pkl",
                self._persistence_directory() / "messages_final.pkl",
            ) if path.is_file()
        ]
        if not candidates:
            return {"loaded": False, "path": ""}
        path = max(candidates, key=lambda item: item.stat().st_mtime_ns)
        frame = pd.read_pickle(path)
        if not isinstance(frame, pd.DataFrame):
            raise TypeError(f"Persisted session snapshot is not a Pandas DataFrame: {path}")
        numeric_ids = pd.to_numeric(frame.get("id", pd.Series(dtype=float)), errors="coerce")
        largest_id = int(numeric_ids.max()) if len(numeric_ids) and pd.notna(numeric_ids.max()) else 0
        updates = pd.to_numeric(frame.get("update_count", pd.Series(dtype=float)), errors="coerce").fillna(1)
        version = max(0, int(updates.sum()))
        self._retain_table({"frame": frame, "next_id": largest_id + 1, "version": version})
        return {"loaded": True, "path": str(path), "rows": len(frame), "version": version}

    def persist_retained_table(self, final: bool = True) -> dict:
        if self._retained_store is None or not self.config.get("persistence", {}).get("enabled"):
            return {"saved": False}
        directory = self._persistence_directory(); directory.mkdir(parents=True, exist_ok=True)
        suffix = "final" if final else "latest"
        frame = self._retained_store.snapshot()
        counts = self._retained_store.name_summary_frame()
        paths = {
            directory / f"messages_{suffix}.pkl": frame,
            directory / f"message_counts_{suffix}.pkl": counts,
        }
        for path, value in paths.items():
            temporary = path.with_suffix(".tmp.pkl")
            value.to_pickle(temporary); os.replace(temporary, path)
        return {"saved": True, "rows": len(frame), "directory": str(directory)}

    def start(self, timeout: float = 10.0):
        with self._lock:
            if self.running:
                return self.status()
            if (
                (self.process is not None and self.process.is_alive())
                or (self.processing_process is not None and self.processing_process.is_alive())
            ):
                self.stop(timeout=min(timeout, 5.0))
            context = multiprocessing.get_context("spawn")
            self.status_generation += 1
            self._poll_pending.clear()
            self._poll_completed.clear()
            self._poll_cache.clear()
            self._shutdown_errors = []
            self._stopped_io_status = {}
            parent, child = context.Pipe()
            processing_parent, processing_child = context.Pipe()
            message_parent = message_child = None
            if self.message_stream is not None:
                message_parent, message_child = context.Pipe(duplex=False)
                self.message_stream.open_reader(self.config["id"], message_parent)
            retained_state = self.retained_table_state()
            processing = self.config["processing"]
            self.capture_queue = context.Queue(maxsize=int(processing["queue_capacity"]))
            self.diagnostic_queue = context.Queue(maxsize=32)
            self.processing_process = context.Process(
                target=data_processing_process_entry,
                args=(
                    processing_child, self.capture_queue, self.config, self.project_root,
                    retained_state, self.protocol_insight_ingress,
                    self.protocol_insight_publisher_capacity, self.diagnostic_queue,
                    message_child,
                    self.message_stream.recipients(self.config["id"]) if self.message_stream is not None else (),
                ),
                name=f"CommunicationData-{self.config['name']}", daemon=True,
            )
            self.processing_connection = processing_parent
            try:
                self.processing_process.start()
                processing_child.close()
                if message_child is not None:
                    message_child.close()
                self._request_connection(
                    self.processing_connection, self._processing_lock,
                    "ping", {}, timeout,
                )
                self.process = context.Process(
                    target=session_process_entry,
                    args=(
                        child, self.capture_queue, self.config, self.project_root,
                        self.diagnostic_queue,
                    ),
                    name=f"CommunicationSession-{self.config['name']}",
                    daemon=True,
                )
                self.connection = parent
                self.process.start()
                child.close()
                result = self.request("ping", timeout=timeout)
                if self.message_stream is not None:
                    # Include subscriptions added while backend startup was in progress.
                    self.request("message_subscriptions", {
                        "recipients": self.message_stream.recipients(self.config["id"]),
                    }, timeout=timeout)
                self._retained_store = None
                return result
            except BaseException:
                # A half-started session must not leave either backend alive.
                for endpoint in (child, processing_child, message_child):
                    try:
                        if endpoint is not None:
                            endpoint.close()
                    except (OSError, ValueError):
                        pass
                self._drain_backend_diagnostics()
                self.stop(timeout=min(timeout, 5.0))
                if self._backend_errors:
                    latest = self._backend_errors[-1]
                    raise RuntimeError(
                        f"{latest.get('backend', 'Session')} backend failed: "
                        f"{latest.get('error', 'unknown error')}"
                    )
                raise

    def _drain_backend_diagnostics(self):
        if self.diagnostic_queue is None:
            return
        while True:
            try:
                diagnostic = self.diagnostic_queue.get_nowait()
            except queue.Empty:
                break
            except (EOFError, OSError, ValueError):
                break
            if isinstance(diagnostic, dict):
                self._backend_errors.append(diagnostic)
                self._backend_errors = self._backend_errors[-32:]

    def _backend_failure_status(self, *, include_table_metrics: bool = True):
        self._drain_backend_diagnostics()
        io_alive = bool(self.process and self.process.is_alive())
        processing_alive = bool(
            self.processing_process and self.processing_process.is_alive()
        )
        configured = self.process is not None or self.processing_process is not None
        result = self._retained_store.metrics() if include_table_metrics and self._retained_store is not None else {}
        if not configured:
            result = {**self._stopped_io_status, **result}
            result.update({
                "state": "error" if self._shutdown_errors else "stopped",
                "status_message": (
                    "Session stopped with incomplete shutdown" if self._shutdown_errors else
                    "Recorded table retained in memory" if self._retained_store is not None else ""
                ),
                "session_id": self.config["id"],
            })
            if self._shutdown_errors:
                result["shutdown_errors"] = list(self._shutdown_errors)
                result["last_error"] = "\n".join(self._shutdown_errors)
            return result
        exits = []
        if not io_alive:
            exits.append(f"I/O backend exited (code {getattr(self.process, 'exitcode', None)})")
        if not processing_alive:
            exits.append(
                f"data-processing backend exited (code {getattr(self.processing_process, 'exitcode', None)})"
            )
        detail = "\n\n".join(
            str(item.get("traceback") or item.get("error") or "")
            for item in self._backend_errors[-2:]
        ).strip()
        result.update({
            "state": "error",
            "status_message": "; ".join(exits),
            "session_id": self.config["id"],
            "io_backend_alive": io_alive,
            "processing_backend_alive": processing_alive,
            "backend_errors": list(self._backend_errors),
            "last_error": detail or "; ".join(exits),
        })
        return result

    def request(self, command: str, payload: dict | None = None, timeout: float = 30.0):
        payload = payload or {}
        if not self.running or self.connection is None:
            if self._retained_store is not None:
                if command == "query":
                    return self._retained_store.query(
                        payload.get("query"), page=payload.get("page", 0), page_size=payload.get("page_size", 200),
                        sort_by=payload.get("sort_by", "timestamp"), descending=payload.get("descending", True),
                    )
                if command == "delete_preview":
                    result = self._retained_store.query(payload.get("query"), page=0, page_size=10)
                    return {"count": result["total"], "version": result["version"], "sample": result["rows"]}
                if command == "delete":
                    return self._retained_store.delete(payload.get("query"), payload.get("expected_version"))
                if command == "names":
                    return self._retained_store.distinct_names()
                if command == "name_summary":
                    return self._retained_store.name_summary()
                if command == "fields":
                    return self._retained_store.discover_fields(payload.get("name"))
            raise RuntimeError(f"Session '{self.config['name']}' is not running")
        if command in DATA_COMMANDS:
            return self._request_connection(
                self.processing_connection, self._processing_lock,
                command, payload, timeout,
            )
        return self._request_connection(
            self.connection, self._lock, command, payload, timeout,
        )

    def _request_connection(self, connection, lock, command, payload, timeout):
        if connection is None:
            raise RuntimeError(f"Session '{self.config['name']}' backend is not available")
        request_id = str(uuid.uuid4())
        with lock:
            connection.send({"id": request_id, "command": command, "payload": payload})
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if connection.poll(min(0.05, max(0.0, deadline - time.monotonic()))):
                    response = connection.recv()
                    if response.get("id") != request_id:
                        self._accept_poll_response(connection, response)
                        continue
                    if not response.get("ok"):
                        raise RuntimeError(response.get("error", "Worker command failed"))
                    return response.get("result")
            raise TimeoutError(f"Session command '{command}' timed out")

    def _accept_poll_response(self, connection, response):
        """Route a delayed poll reply consumed by another command on this pipe."""
        if self._poll_pending.get(connection) != response.get("id"):
            return
        self._poll_pending.pop(connection, None)
        self._poll_completed[connection] = response.get("result") if response.get("ok") else None

    def _poll_request(self, connection, lock, command, timeout):
        if connection is None:
            return None
        deadline = time.monotonic() + max(0.0, timeout)
        if not lock.acquire(timeout=max(0.0, deadline - time.monotonic())):
            return None
        try:
            if connection in self._poll_completed:
                return self._poll_completed.pop(connection)
            if time.monotonic() >= deadline:
                return None
            if connection not in self._poll_pending:
                request_id = str(uuid.uuid4())
                connection.send({"id": request_id, "command": command, "payload": {}})
                self._poll_pending[connection] = request_id
            # Leave timed-out requests pending. Sending another every tick
            # would build an unbounded command backlog behind a slow parser.
            while time.monotonic() < deadline:
                if connection.poll(min(0.05, max(0.0, deadline - time.monotonic()))):
                    self._accept_poll_response(connection, connection.recv())
                    if connection in self._poll_completed:
                        return self._poll_completed.pop(connection)
            return None
        except (EOFError, OSError, ValueError):
            self._poll_pending.pop(connection, None)
            return None
        finally:
            lock.release()

    def poll_status(self, timeout: float = 0.2):
        """Bounded UI refresh, independent of unrelated work and table queries.

        Each pipe has at most one outstanding poll. Lock acquisition and reply
        waiting share its budget; cached state is explicitly marked delayed.
        """
        generation = self.status_generation
        cache = self._poll_cache if self._poll_cache.get("generation") == generation else {}
        io_status = (
            self._poll_request(self.connection, self._lock, "status", timeout)
            if self.running else self._backend_failure_status(include_table_metrics=False)
        )
        if self.processing_process is not None and self.processing_process.is_alive():
            data_status = self._poll_request(
                self.processing_connection, self._processing_lock, "poll_data_status", timeout,
            )
        elif self._retained_store is not None:
            previous = cache.get("data", {})
            data_status = previous if previous.get("table_version") == self._retained_store.version else {
                **self._retained_store.metrics(), "table_version": self._retained_store.version,
            }
        else:
            data_status = None
        if generation != self.status_generation:
            return None
        io = io_status if io_status is not None else cache.get("io", {})
        data = data_status if data_status is not None else cache.get("data", {})
        self._poll_cache = {"generation": generation, "io": io, "data": data}
        return {
            **data, **io,
            "session_id": self.config["id"],
            "state": io.get("state", "unknown"),
            "status_message": io.get("status_message", "Awaiting connection status"),
            "connection_refresh_delayed": io_status is None,
            "statistics_refresh_delayed": data_status is None,
            "statistics_available": bool(data),
        }

    def status(self):
        if not self.running:
            return self._backend_failure_status()
        self._drain_backend_diagnostics()
        try:
            io_status = self.request("status", timeout=2.0)
            data_status = self._request_connection(
                self.processing_connection, self._processing_lock,
                "data_status", {}, 2.0,
            )
        except (BrokenPipeError, ConnectionError, EOFError, OSError):
            # is_alive() can remain true briefly after a Windows child closes
            # its pipe. Surface the backend exit instead of leaking IPC noise.
            deadline = time.monotonic() + 0.25
            while self.running and time.monotonic() < deadline:
                time.sleep(0.01)
            return self._backend_failure_status()
        io_status.update(data_status)
        if self._backend_errors:
            io_status["backend_errors"] = list(self._backend_errors)
        return io_status

    def send(self, data: bytes | str, *, encoding: str = "utf-8", target: str = ""):
        """Send exactly the supplied bytes; receive framing does not affect TX."""
        return self.request("send", {
            "data": data, "encoding": encoding, "target": target,
        })

    def query(self, query: dict | None = None, **options):
        payload = {"query": query or {}}
        payload.update(options)
        return self.request("query", payload)

    def stop(self, timeout: float = 15.0):
        # Serialize shutdown with sends and data requests, including concurrent
        # GUI/API stop calls. Both locks are reentrant for the IPC helpers.
        with self._lock, self._processing_lock:
            return self._stop_backends(timeout)

    def _stop_backends(self, timeout: float):
        process = self.process
        processing_process = self.processing_process
        if not process and not processing_process:
            persistence = self.config.get("persistence", {})
            if persistence.get("enabled") and persistence.get("save_on_stop", True):
                self.persist_retained_table(final=True)
            return self._backend_failure_status()
        self.status_generation += 1
        deadline = time.monotonic() + max(0.1, timeout)

        def remaining():
            return max(0.1, deadline - time.monotonic())

        def failed(stage, error):
            self._shutdown_errors.append(f"{stage}: {type(error).__name__}: {error}")

        required_sequence = 0
        if process and process.is_alive():
            try:
                # The reply is sent only after every capture producer has
                # stopped and the final marker has been queued reliably.
                stopped = self._request_connection(
                    self.connection, self._lock, "stop", {}, remaining(),
                )
                required_sequence = int(
                    stopped.get("capture_sequence", 0) if isinstance(stopped, dict) else 0
                )
                if not required_sequence:
                    raise RuntimeError("I/O backend did not acknowledge a final capture marker")
                self._stopped_io_status = stopped
            except Exception as error:
                failed("Receive shutdown", error)
            # Joining also waits for multiprocessing.Queue's feeder to flush.
            # Only then can get_nowait-based draining safely precede a snapshot.
            process.join(remaining())
            if process.is_alive():
                failed("Receive shutdown", TimeoutError("I/O backend required forced termination; capture may be incomplete"))
                process.terminate()
                process.join(3)
            elif process.exitcode not in (None, 0):
                failed("Receive shutdown", RuntimeError(f"I/O backend exited with code {process.exitcode}"))
        elif process is not None:
            failed("Receive shutdown", RuntimeError("I/O backend exited before its final capture marker was acknowledged"))
        if processing_process and processing_process.is_alive():
            try:
                self._retain_table(self._request_connection(
                    self.processing_connection, self._processing_lock,
                    "stop", {"capture_sequence": required_sequence, "retain_table": True}, remaining(),
                ))
                self._stopped_io_status["capture_queue_depth"] = 0
            except Exception as error:
                failed("Capture drain and table retention", error)
                # Salvage records from a failed/partial producer shutdown too.
                try:
                    self._retain_table(self._request_connection(
                        self.processing_connection, self._processing_lock,
                        "table_state", {}, remaining(),
                    ))
                    self._request_connection(
                        self.processing_connection, self._processing_lock,
                        "stop", {}, remaining(),
                    )
                except Exception as recovery_error:
                    failed("Table recovery", recovery_error)
            processing_process.join(remaining())
            if processing_process.is_alive():
                failed("Processing shutdown", TimeoutError("Data-processing backend required forced termination; capture or persistence may be incomplete"))
                processing_process.terminate(); processing_process.join(3)
            elif processing_process.exitcode not in (None, 0):
                failed("Processing shutdown", RuntimeError(f"Data-processing backend exited with code {processing_process.exitcode}"))
        elif processing_process is not None:
            failed("Processing shutdown", RuntimeError("Data-processing backend exited before its table could be retained"))
        if self.connection:
            self.connection.close()
        self.connection = None
        self.process = None
        if self.processing_connection:
            self.processing_connection.close()
        self.processing_connection = None
        self.processing_process = None
        if self.capture_queue is not None:
            try: self.capture_queue.close()
            except (AttributeError, OSError, ValueError): pass
        self.capture_queue = None
        if self.diagnostic_queue is not None:
            self._drain_backend_diagnostics()
            try: self.diagnostic_queue.close()
            except (AttributeError, OSError, ValueError): pass
        self.diagnostic_queue = None
        if self.message_stream is not None:
            self.message_stream.close_reader(self.config["id"], drain=True)
        return self._backend_failure_status()

    restart = lambda self: (self.stop(), self.start())[-1]
