"""Resizable sandbox results: lazy fields, routing probes, and value inspection."""
from __future__ import annotations

import itertools

from PyQt5 import QtCore, QtGui, QtWidgets

from app.binary_messages.json_codec import dumps
from .result_model import OPERATIONS, copy_value, detail_value, preview_value, result_roots, scalar_schema, value_type
from .ui_metrics import BOTTOM_PANEL_HEIGHT


ROLE = QtCore.Qt.UserRole
BATCH = 100


class FieldsTree(QtWidgets.QTreeWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderLabels(['Field', 'Type', 'Value'])
        self.setAccessibleName('Decoded fields')
        self.setAlternatingRowColors(True)
        self.setUniformRowHeights(True)
        self.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Interactive)
        self.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Interactive)
        self.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.setColumnWidth(0, 280); self.setColumnWidth(1, 130)
        self.roots, self.manifest = [], {}
        self.memory, self.selected_path = {}, ''
        self.itemExpanded.connect(self._expand)
        self.itemActivated.connect(self._activate)

    def entries(self):
        pending = [self.topLevelItem(index) for index in range(self.topLevelItemCount())]
        while pending:
            item = pending.pop()
            yield item
            pending.extend(item.child(index) for index in range(item.childCount()))

    def remember(self):
        self.memory = {item.entry.path: (item.isExpanded(), getattr(item, 'loaded', 0))
                       for item in self.entries() if hasattr(item, 'entry')}
        current = self.currentItem()
        self.selected_path = current.entry.path if current and hasattr(current, 'entry') else ''

    def set_roots(self, roots, manifest, compatible=False):
        if not compatible: self.memory, self.selected_path = {}, ''
        elif self.roots: self.remember()
        self.roots, self.manifest = roots, manifest
        self._render()

    def _item(self, entry, parent=None):
        schema = scalar_schema(entry.schema)
        item = QtWidgets.QTreeWidgetItem([entry.label, value_type(entry.value, schema, self.manifest),
                                         preview_value(entry.value, schema, self.manifest)])
        item.entry = entry
        item.loaded = 0
        item.iterator = iter(entry.children(self.manifest))
        item.complete = False
        item.setToolTip(0, entry.path)
        item.setToolTip(1, f'Declared type: {value_type(entry.value, schema, self.manifest)}\nRuntime value: {value_type(entry.value)}')
        item.setData(0, ROLE, entry.uid)
        (parent.addChild if parent else self.addTopLevelItem)(item)
        if entry.is_container:
            item.setChildIndicatorPolicy(item.ShowIndicator)
        if entry.path == self.selected_path: self.setCurrentItem(item)
        return item

    def _render(self):
        self.clear()
        for root in self.roots:
            item = self._item(root)
            self._load(item)
            item.setExpanded(self.memory.get(root.path, (True, 0))[0])

    def _load(self, item):
        if item.complete: return
        if item.childCount() and getattr(item.child(item.childCount() - 1), 'more', False):
            item.takeChild(item.childCount() - 1)
        limit = max(BATCH, self.memory.get(item.entry.path, (False, 0))[1] - item.loaded)
        # Saved expansion is bounded to the number of children previously inspected.
        for _ in range(limit):
            try: entry = next(item.iterator)
            except StopIteration:
                item.complete = True
                break
            child = self._item(entry, item)
            item.loaded += 1
            if self.memory.get(entry.path, (False, 0))[0]: child.setExpanded(True)
        if not item.complete:
            try:
                upcoming = next(item.iterator)
                item.iterator = itertools.chain((upcoming,), item.iterator)
            except StopIteration:
                item.complete = True
        if not item.complete:
            more = QtWidgets.QTreeWidgetItem(['Load next 100 items…', '', 'Enter or double-click'])
            more.more = True
            item.addChild(more)

    def _expand(self, item):
        if hasattr(item, 'entry') and not item.loaded: self._load(item)

    def _activate(self, item, column):
        if getattr(item, 'more', False):
            parent = item.parent()
            self._load(parent)
            self.setCurrentItem(parent)

    def expand_selected(self):
        item = self.currentItem()
        if item and hasattr(item, 'entry'): item.setExpanded(True)
        else:
            for index in range(self.topLevelItemCount()): self.topLevelItem(index).setExpanded(True)


class ResultsPanel(QtWidgets.QWidget):
    openRoutingRequested = QtCore.pyqtSignal(str)
    openDefinitionRequested = QtCore.pyqtSignal(str)
    viewStateChanged = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.result, self._shape = None, None
        layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.tabs = QtWidgets.QTabWidget()
        self.fields = FieldsTree()
        self.routing = QtWidgets.QTreeWidget(); self.routing.setHeaderLabels(['Check', 'Expected', 'Actual', 'Result'])
        self.routing.setAccessibleName('Routing checks'); self.routing.setAlternatingRowColors(True)
        for index in range(4): self.routing.header().setSectionResizeMode(index, QtWidgets.QHeaderView.Interactive if index < 3 else QtWidgets.QHeaderView.Stretch)
        self.routing.setColumnWidth(0, 240); self.routing.setColumnWidth(1, 230); self.routing.setColumnWidth(2, 260)
        self.tabs.addTab(self.fields, 'Fields'); self.tabs.addTab(self.routing, 'Routing checks')
        layout.addWidget(self.tabs, 1)
        self.empty = QtWidgets.QLabel('Run Decode or Decode auto to inspect fields.'); self.empty.setWordWrap(True); layout.addWidget(self.empty)
        self.notice = QtWidgets.QLabel(); self.notice.setWordWrap(True); self.notice.hide(); layout.addWidget(self.notice)
        self.details_action = QtWidgets.QAction('Show value details', self); self.details_action.setCheckable(True)
        self.copy_result_action = QtWidgets.QAction('Copy result as JSON', self); self.copy_result_action.setEnabled(False)
        self.details = QtWidgets.QWidget(); details_layout = QtWidgets.QVBoxLayout(self.details); details_layout.setContentsMargins(0, 0, 0, 0)
        detail_header = QtWidgets.QHBoxLayout()
        self.detail_path = QtWidgets.QLabel('Select a field'); self.detail_path.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.detail_path.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        detail_header.addWidget(self.detail_path, 1)
        self.format = QtWidgets.QComboBox(); self.format.setAccessibleName('Selected value format'); detail_header.addWidget(self.format)
        self.copy_button = QtWidgets.QToolButton(); self.copy_button.setText('Copy value'); detail_header.addWidget(self.copy_button)
        self.definition_button = QtWidgets.QToolButton(); self.definition_button.setText('Open definition'); detail_header.addWidget(self.definition_button)
        details_layout.addLayout(detail_header)
        self.detail_text = QtWidgets.QPlainTextEdit(); self.detail_text.setReadOnly(True); self.detail_text.setMaximumHeight(80)
        self.detail_text.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        details_layout.addWidget(self.detail_text); layout.addWidget(self.details); self.details.hide()
        self.fields.itemSelectionChanged.connect(self._selection)
        self.fields.setContextMenuPolicy(QtCore.Qt.CustomContextMenu); self.fields.customContextMenuRequested.connect(self._context_menu)
        self.details_action.toggled.connect(self.details.setVisible)
        self.details_action.toggled.connect(self._detail_format)
        self.format.currentTextChanged.connect(self._detail_format)
        self.copy_button.clicked.connect(lambda: self.copy_selected('value'))
        copy_action = QtWidgets.QAction('Copy value', self.fields)
        copy_action.setShortcut(QtGui.QKeySequence.Copy)
        copy_action.setShortcutContext(QtCore.Qt.WidgetWithChildrenShortcut)
        copy_action.triggered.connect(lambda: self.copy_selected('value'))
        self.fields.addAction(copy_action)
        self.copy_result_action.triggered.connect(self.copy_result)
        self.definition_button.clicked.connect(self._open_definition)
        self.routing.itemActivated.connect(lambda item, column: self.openRoutingRequested.emit(item.data(0, ROLE) or ''))
        for tree in (self.fields, self.routing): tree.header().sectionResized.connect(lambda: self.viewStateChanged.emit())
        self.details_action.toggled.connect(self.viewStateChanged)
        self.setFixedHeight(BOTTOM_PANEL_HEIGHT)
        self._selection()

    def set_result(self, result):
        previous = self.result
        self.result = result
        message = next((item for item in result.manifest.get('messages', []) if item['uid'] == result.message_uid), {})
        shape = (result.message_uid, repr(message.get('fields')), repr(result.manifest.get('structures', [])))
        compatible = self._shape == shape and previous is not None
        # Running/error placeholders must not overwrite compatible field view memory.
        if previous and previous.values is not None: self.fields.remember()
        self.fields.set_roots(result_roots(result), result.manifest, compatible=compatible)
        if result.values is not None: self._shape = shape
        self._render_routing()
        self.copy_result_action.setEnabled(result.values is not None)
        self.tabs.setCurrentIndex(1 if result.routing_state == 'Failed' else 0)
        self._summary()
        self._selection()

    def _summary(self):
        result = self.result
        if result is None: return
        parts = [OPERATIONS.get(result.operation, result.operation), result.message_name, result.direction]
        if result.byte_count is not None: parts.append(f'{result.byte_count} bytes')
        summary = 'Results · ' + ' · '.join(part for part in parts if part)
        outcome = f'Routing: {result.routing_state} · Payload: {result.payload_state}'
        self.setAccessibleDescription(summary + '. ' + outcome)
        for index in range(self.tabs.count()): self.tabs.setTabToolTip(index, summary + '\n' + outcome)
        notice = '\n'.join(part for part in ('Out of date · Inputs changed. Run the operation again.' if result.stale else '', result.error) if part)
        self.notice.setText(notice); self.notice.setVisible(bool(notice))
        self.notice.setStyleSheet('color: #9a6700;' if result.stale else 'color: #b42318;')
        self.empty.setText('Operation running…' if result.payload_state == 'Running' else
                           'No decoded fields are available. ' + ('Inspect Routing checks.' if result.routing_state == 'Failed' else 'See the status bar or message below.'))
        self.empty.setVisible(result.values is None)

    def mark_stale(self):
        if self.result is not None:
            self.result.stale = True
            self._summary(); self._selection()

    def _render_routing(self):
        self.routing.clear()
        result = self.result
        steps = result.routing.steps if result.routing is not None else ()
        self.tabs.setTabText(1, f'Routing checks · {len(steps)}' if steps else 'Routing checks')
        if not steps:
            self.routing.addTopLevelItem(QtWidgets.QTreeWidgetItem(['Routing not run' if result.routing_state == 'Not run' else 'No routing probes available', '', '', result.routing_state]))
        for step in steps:
            uid = step['selected_uid'] or step['group_uid']
            item = QtWidgets.QTreeWidgetItem([step['group'], '', '', step['outcome']])
            item.setData(0, ROLE, uid); self.routing.addTopLevelItem(item)
            success = bool(step['selected_uid'])
            color = QtGui.QColor('#287d3c' if success else '#b42318')
            item.setForeground(3, color)
            for index, identifier in enumerate(step['identifiers']):
                key = step['expected_key']
                expected = 'Key: ' + key[index].hex(' ').upper() if key is not None else 'See configured outgoing routes'
                actual = identifier['hex'] + ' · ' + repr(identifier['value'])
                if identifier['value'] is None: actual = identifier['hex'] + ' · Incomplete bytes'
                child = QtWidgets.QTreeWidgetItem([identifier['name'], expected, actual, 'Matched' if success else step['outcome']])
                child.setData(0, ROLE, step['group_uid'])
                child.setToolTip(0, f"{identifier['type']} · offset {identifier['offset']} · {identifier['length']} byte(s)")
                for column in (1, 2): child.setToolTip(column, child.text(column))
                if identifier.get('key_hex') is not None:
                    child.setToolTip(2, actual + '\nNormalized match key: ' + identifier['key_hex'])
                item.addChild(child)
            item.setExpanded(True)

    def _selected(self):
        item = self.fields.currentItem()
        return item.entry if item and hasattr(item, 'entry') else None

    def _selection(self):
        entry = self._selected()
        self.copy_button.setEnabled(entry is not None)
        self.definition_button.setEnabled(bool(entry and entry.uid and self.result and not self.result.stale))
        self.detail_path.setText(entry.path if entry else 'Select a field')
        self.detail_path.setToolTip(entry.path if entry else '')
        mode = self.format.currentText()
        with QtCore.QSignalBlocker(self.format):
            self.format.clear()
            choices = ['Hex', 'UTF-8'] if entry and isinstance(entry.value, bytes) else ['Decimal', 'Hex'] if entry and type(entry.value) is int else ['Quoted', 'Text'] if entry and isinstance(entry.value, str) else ['Default']
            self.format.addItems(choices)
            if mode in choices: self.format.setCurrentText(mode)
        self._detail_format()

    def _detail_format(self):
        entry = self._selected()
        # Container JSON can be large; compute full details only when requested.
        if entry and self.details_action.isChecked():
            text = detail_value(entry.value, self.format.currentText())
            if len(text) > 262144: text = text[:262144] + '\n… Display limited to 262,144 characters. Copy value for the full content.'
            self.detail_text.setPlainText(text)
        else: self.detail_text.clear()

    def copy_selected(self, what):
        entry = self._selected()
        if entry is None: return
        text = entry.path if what == 'path' else '\t'.join([entry.path, value_type(entry.value, scalar_schema(entry.schema), self.fields.manifest), copy_value(entry.value)]) if what == 'row' else copy_value(entry.value)
        QtWidgets.QApplication.clipboard().setText(text)

    def copy_result(self):
        if self.result and self.result.values is not None:
            value = self.result.values if self.result.initialized is None else {'Constructor values': self.result.initialized, 'Effective wire values': self.result.values}
            QtWidgets.QApplication.clipboard().setText(dumps(value))

    def _open_definition(self):
        entry = self._selected()
        if entry and entry.uid and self.result and not self.result.stale: self.openDefinitionRequested.emit(entry.uid)

    def _context_menu(self, position):
        item = self.fields.itemAt(position)
        if item is None or not hasattr(item, 'entry'): return
        self.fields.setCurrentItem(item)
        menu = QtWidgets.QMenu(self)
        for title, kind in [('Copy value', 'value'), ('Copy full path', 'path'), ('Copy row', 'row')]:
            action = menu.addAction(title); action.triggered.connect(lambda checked=False, kind=kind: self.copy_selected(kind))
        menu.addAction(self.copy_result_action)
        menu.addSeparator()
        action = menu.addAction('Expand selected'); action.triggered.connect(self.fields.expand_selected)
        action = menu.addAction('Collapse all'); action.triggered.connect(self.fields.collapseAll)
        menu.addAction(self.details_action)
        action = menu.addAction('Open definition'); action.setEnabled(self.definition_button.isEnabled()); action.triggered.connect(self._open_definition)
        menu.exec_(self.fields.viewport().mapToGlobal(position))

    def view_state(self):
        return {'field_widths': [self.fields.columnWidth(index) for index in range(2)],
                'routing_widths': [self.routing.columnWidth(index) for index in range(3)],
                'details': self.details_action.isChecked()}

    def restore_view_state(self, state):
        if not isinstance(state, dict): return
        for key, tree, count in [('field_widths', self.fields, 2), ('routing_widths', self.routing, 3)]:
            widths = state.get(key)
            if isinstance(widths, list) and len(widths) == count:
                for index, width in enumerate(widths):
                    if type(width) is int and 40 <= width <= 2000: tree.setColumnWidth(index, width)
        if type(state.get('details')) is bool: self.details_action.setChecked(state['details'])
