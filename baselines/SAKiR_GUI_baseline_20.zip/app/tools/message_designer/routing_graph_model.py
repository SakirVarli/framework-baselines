"""Qt-free, tolerant projection of routing definitions for the graph editor."""
from __future__ import annotations

import struct
from dataclasses import dataclass

from app.binary_messages.compiled_routing import Identifier
from .routing_model import resolve_definitions


@dataclass(frozen=True)
class RouteNode:
    uid: str
    name: str
    kind: str
    parent_uid: str
    direction: str
    summary: str
    condition: str
    details: str
    status: str
    reason: str
    draft: bool = False


@dataclass
class RouteGraph:
    root_uid: str
    nodes: dict[str, RouteNode]
    children: dict[str, list[str]]
    roots: list[str]


def _display_value(identifier, value, raw):
    decoded = identifier.decode(raw)
    if identifier.type == 'enum':
        name = next((name for name, number in identifier.enum_values if number == decoded), None)
        return f'{name} ({decoded})' if name else str(decoded)
    if identifier.type in {'uint', 'int'}:
        return f'0x{decoded:X}' if decoded >= 0 else str(decoded)
    if identifier.type == 'bytes':
        return '0x' + raw.hex().upper()
    return repr(decoded)


def build_route_graph(manifest, issues=(), draft_uids=()):
    """Project the hierarchy without requiring a compilable routing registry.

    Invalid ancestry is detached into diagnostic roots, retaining every object
    for inspection. Conditions use the decoder's encoding and normalization.
    """
    root = manifest['library']
    root_uid = root['uid']
    objects = [(root, 'Library')]
    objects.extend((owner, 'Group') for owner in manifest.get('groups', []))
    objects.extend((owner, 'Message') for owner in manifest.get('messages', []))
    owners = {owner['uid']: owner for owner, kind in objects if kind != 'Message'}
    by_uid = {owner['uid']: (owner, kind) for owner, kind in objects}
    parents = {uid: (owner.get('parent_group_uid') if kind == 'Group' else owner.get('group_uid')) or root_uid
               for uid, (owner, kind) in by_uid.items() if kind != 'Library'}
    definitions, definition_errors = {}, {}
    errors = (ValueError, TypeError, OverflowError, LookupError, struct.error)
    for uid, owner in owners.items():
        try:
            definitions[uid] = [Identifier(**item) for item in resolve_definitions(manifest, owner)]
        except errors as error:
            definitions[uid] = []
            definition_errors[uid] = str(error)

    issue_text = {}
    issue_errors = set()
    for issue in issues:
        if issue.uid in by_uid:
            issue_text.setdefault(issue.uid, []).append(issue.message)
            if issue.severity == 'error':
                issue_errors.add(issue.uid)

    # Resolve ancestry iteratively so malformed/deep graphs cannot recurse forever.
    ancestry = {root_uid: ''}
    for uid in by_uid:
        trail, seen, current = [], set(), uid
        while current not in ancestry:
            if current in seen:
                reason = 'Circular group ancestry'
                break
            seen.add(current)
            trail.append(current)
            parent = parents.get(current)
            if parent not in owners:
                reason = 'Missing parent group'
                break
            current = parent
        else:
            reason = ancestry[current]
        for entry in reversed(trail):
            ancestry[entry] = reason

    conditions, details, local_status = {}, {}, {}
    for uid, (owner, kind) in by_uid.items():
        parts, lines = [], []
        status, reason = 'included', 'Included in automatic decoding'
        if uid != root_uid:
            parent = parents[uid]
            values = owner.get('expected_values')
            if ancestry[uid]:
                status, reason = 'invalid', ancestry[uid]
            elif values is None:
                status, reason = 'excluded', 'Expected values are unassigned'
            elif not isinstance(values, dict):
                status, reason = 'invalid', 'Expected values must be an object'
            elif parent in definition_errors:
                status, reason = 'invalid', 'Parent identifiers are invalid: ' + definition_errors[parent]
            else:
                for identifier in definitions.get(parent, []):
                    value = values.get(identifier.uid)
                    if value is None:
                        parts.append(identifier.name + ' = ?')
                        status, reason = 'excluded', 'Expected values are incomplete'
                        continue
                    try:
                        raw = identifier.encode(value)
                        parts.append(identifier.name + ' = ' + _display_value(identifier, value, raw))
                        key = identifier.key_bytes(raw).hex(' ').upper()
                        line = (f'{identifier.name}: {value!r}\n'
                                f'  {identifier.type}, offset {identifier.offset}, {identifier.length} byte(s), '
                                f'{identifier.byteorder} endian\n'
                                f'  Expected bytes: {raw.hex(" ").upper()} · Match key: {key}')
                        if identifier.mask is not None or identifier.shift:
                            line += f'\n  Mask: {identifier.mask!r} · Shift: {identifier.shift}'
                        lines.append(line)
                    except errors as error:
                        parts.append(identifier.name + ' = Invalid')
                        status, reason = 'invalid', str(error)
            if values is None:
                condition = 'Unassigned'
            elif not parts and status == 'included':
                condition = 'Always'
            else:
                condition = ' AND '.join(parts) or reason
            if kind == 'Message':
                condition += ' · ' + owner.get('direction', 'ANY')
            conditions[uid] = condition
        else:
            conditions[uid] = ''
        if uid in definition_errors:
            status, reason = 'invalid', definition_errors[uid]
        if uid in issue_errors:
            status, reason = 'invalid', '\n'.join(issue_text[uid])
        local_status[uid] = (status, reason)
        details[uid] = '\n'.join(lines)

    effective = {}
    for uid in by_uid:
        trail, seen, current = [], set(), uid
        while current not in effective and current not in seen:
            seen.add(current)
            trail.append(current)
            if current == root_uid or ancestry[current]:
                break
            current = parents[current]
        for entry in reversed(trail):
            status, reason = local_status[entry]
            parent_state = effective.get(parents.get(entry))
            if status == 'included' and parent_state and parent_state[0] != 'included':
                status = parent_state[0]
                reason = 'Ancestor route: ' + parent_state[1].removeprefix('Ancestor route: ')
            effective[entry] = (status, reason)

    nodes, children = {}, {}
    roots = [root_uid]
    for uid, (owner, kind) in by_uid.items():
        parent = parents.get(uid, '')
        # Detach all unresolved ancestry; drawing false normal edges is misleading.
        if ancestry[uid]:
            parent = ''
        elif parent:
            children.setdefault(parent, []).append(uid)
        if uid != root_uid and not parent:
            roots.append(uid)
        names = [item.get('name', '?') for item in owner.get('identifiers', [])]
        summary = 'Reads ' + ', '.join(names) if names else 'No identifiers' if kind != 'Message' else 'Message definition'
        status, reason = effective[uid]
        full_details = '\n\n'.join(part for part in [conditions[uid], details[uid], reason,
                                                     '\n'.join(issue_text.get(uid, []))] if part)
        nodes[uid] = RouteNode(uid, owner.get('name') or owner.get('display_name') or 'Library', kind,
                               parent, owner.get('direction', 'ANY'), summary, conditions[uid],
                               full_details, status, reason, uid in draft_uids)
    for items in children.values():
        items.sort(key=lambda uid: (nodes[uid].kind == 'Message', nodes[uid].name.casefold(), uid))
    roots[1:] = sorted(roots[1:], key=lambda uid: (nodes[uid].name.casefold(), uid))
    return RouteGraph(root_uid, nodes, children, roots)
