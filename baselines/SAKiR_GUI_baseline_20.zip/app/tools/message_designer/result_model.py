"""Run snapshots and semantic value presentation, independent of Qt."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.binary_messages.json_codec import dumps, from_json_value


OPERATIONS = {'build': 'Encode', 'parse': 'Decode', 'auto_parse': 'Decode auto',
              'round_trip': 'Verify round trip', 'check_default': 'Check default message'}


@dataclass
class RunResult:
    operation: str
    message_uid: str = ''
    message_name: str = ''
    direction: str = 'ANY'
    scope_uid: str = ''
    input_identity: tuple = ()
    byte_count: int | None = None
    routing: Any = None
    routing_state: str = 'Not run'
    payload_state: str = 'Running'
    values: Any = None
    initialized: Any = None
    error: str = ''
    stale: bool = False
    manifest: dict = field(default_factory=dict, repr=False)
    definition_revision: int = 0


def wire_identity(text):
    try:
        return bytes.fromhex(text)
    except ValueError:
        return ('invalid hex', text)


def preview_value(value, schema=None, manifest=None, limit=120):
    kind = (schema or {}).get('kind')
    if value is None:
        return 'None'
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, int):
        text = f'{value} ({"-0x" + format(-value, "X") if value < 0 else "0x" + format(value, "X")})'
        if kind == 'enum':
            enum = next((item for item in (manifest or {}).get('enums', []) if item['uid'] == schema.get('enum_uid')), {})
            member = next((item['name'] for item in enum.get('values', []) if item['value'] == value), None)
            if member: text = f'{member} ({value})'
        return text
    if isinstance(value, bytes):
        return f'{len(value)} bytes · ' + (value[:32].hex(' ').upper() + (' …' if len(value) > 32 else '') if value else '(empty)')
    if isinstance(value, str):
        # Slice before escaping: previewing a large value must stay cheap.
        return repr(value[:limit]) + (' …' if len(value) > limit else '')
    if isinstance(value, dict):
        return f'{len(value)} fields'
    if isinstance(value, (list, tuple)):
        return f'{len(value)} items'
    return repr(value)[:limit]


def value_type(value, schema=None, manifest=None):
    if schema:
        kind = schema.get('kind', '')
        if kind in {'uint', 'int', 'float'}:
            return kind + str(schema.get('width', 1) * 8)
        if kind == 'enum':
            enum = next((item for item in (manifest or {}).get('enums', []) if item['uid'] == schema.get('enum_uid')), {})
            return enum.get('name', 'Enum') + ' enum'
        names = {'array': 'Array', 'struct': 'Structure', 'inline_struct': 'Structure', 'bytes': 'Bytes',
                 'string': 'Text', 'bool': 'Boolean', 'message': 'Message', 'varint': 'VarInt', 'zigzag': 'ZigZag'}
        if kind in names: return names[kind]
        if kind == 'bytes_integer': return ('int' if schema.get('signed') else 'uint') + str(schema.get('length', 1) * 8)
    return {dict: 'Structure', list: 'Array', bytes: 'Bytes', str: 'Text', bool: 'Boolean', type(None): 'None'}.get(type(value), type(value).__name__)


def scalar_schema(schema):
    """Unwrap only branches whose identity is unambiguous without evaluation."""
    while schema and schema.get('kind') in {'const', 'default', 'rebuild', 'conditional', 'aligned'}:
        schema = schema.get('item')
    # A runtime value's shape is insufficient to identify a switch case.
    return None if schema and schema.get('kind') == 'switch' else schema


@dataclass
class ValueEntry:
    label: str
    path: str
    value: Any
    schema: dict | None = None
    uid: str = ''

    def children(self, manifest):
        schema = scalar_schema(self.schema)
        if isinstance(self.value, dict):
            owner = schema or {}
            if owner.get('kind') == 'struct':
                owner = next((item for item in manifest.get('structures', []) if item['uid'] == owner.get('struct_uid')), {})
            definitions = {item.get('name'): item for item in owner.get('fields', [])}
            for key, value in self.value.items():
                child = definitions.get(key)
                yield ValueEntry(str(key), f'{self.path}.{key}', value, child, (child or {}).get('uid', ''))
        elif isinstance(self.value, (list, tuple)):
            child = schema.get('item') if schema and schema.get('kind') == 'array' else None
            for index, value in enumerate(self.value):
                yield ValueEntry(f'[{index}]', f'{self.path}[{index}]', value, child, (child or {}).get('uid', ''))

    @property
    def is_container(self):
        return isinstance(self.value, (dict, list, tuple)) and bool(self.value)


def result_roots(result):
    message = next((item for item in result.manifest.get('messages', []) if item['uid'] == result.message_uid), {})
    schema = {**message, 'kind': 'message'}
    roots = []
    if result.initialized is not None:
        roots.append(ValueEntry('Constructor values', 'Constructor values', result.initialized, schema, result.message_uid))
    if result.values is not None:
        name = 'Effective wire values' if result.initialized is not None else result.message_name or 'Fields'
        roots.append(ValueEntry(name, name, result.values, schema, result.message_uid))
    return roots


def semantic_values(response):
    return from_json_value(response.get('values', {}))


def copy_value(value):
    if isinstance(value, bytes): return value.hex(' ').upper()
    if isinstance(value, str): return value
    return dumps(value)


def detail_value(value, mode='Default'):
    if isinstance(value, bytes):
        if mode == 'UTF-8':
            try: return value.decode('utf-8')
            except UnicodeDecodeError as error: return f'Cannot decode as UTF-8: {error}\n\nHex:\n' + value.hex(' ').upper()
        return value.hex(' ').upper()
    if isinstance(value, int) and not isinstance(value, bool):
        return hex(value) if mode == 'Hex' else str(value)
    if isinstance(value, str): return value if mode == 'Text' else repr(value)
    return dumps(value)
