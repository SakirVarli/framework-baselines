"""Deterministic left-to-right routing layout, independent of Qt."""
from __future__ import annotations

NODE_WIDTH = 232
NODE_HEIGHT = 104
COLUMN_GAP = 210
ROW_GAP = 62


def visible_routes(graph, collapsed=(), query='', focus_uid=''):
    """Keep search matches and their ancestors; search reveals collapsed paths."""
    tokens = query.casefold().split()
    allowed = set(graph.nodes)
    if tokens:
        allowed = set()
        for uid, node in graph.nodes.items():
            text = f'{node.name} {node.kind} {node.direction} {node.condition}'.casefold()
            if all(token in text for token in tokens):
                current = uid
                while current and current not in allowed:
                    allowed.add(current)
                    current = graph.nodes[current].parent_uid
    if focus_uid in graph.nodes:
        scoped, pending = set(), [focus_uid]
        while pending:
            uid = pending.pop()
            if uid not in scoped:
                scoped.add(uid)
                pending.extend(graph.children.get(uid, []))
        allowed &= scoped
        roots = [focus_uid]
    else:
        roots = graph.roots
    visible, pending = set(), list(roots)
    while pending:
        uid = pending.pop()
        if uid not in allowed or uid in visible:
            continue
        visible.add(uid)
        if tokens or uid not in collapsed:
            pending.extend(graph.children.get(uid, []))
    return visible


def layout_routes(graph, visible):
    """Center parents over their visible children using an iterative postorder."""
    positions, row = {}, 0
    roots = [uid for uid in graph.nodes if uid in visible and graph.nodes[uid].parent_uid not in visible]
    roots.sort(key=lambda uid: (uid != graph.root_uid, graph.nodes[uid].name.casefold(), uid))
    for root in roots:
        pending = [(root, 0, False)]
        while pending:
            uid, depth, visited = pending.pop()
            children = [child for child in graph.children.get(uid, []) if child in visible]
            if not visited and children:
                pending.append((uid, depth, True))
                pending.extend((child, depth + 1, False) for child in reversed(children))
                continue
            if children:
                y = (positions[children[0]][1] + positions[children[-1]][1]) / 2
            else:
                y = row * (NODE_HEIGHT + ROW_GAP)
                row += 1
            positions[uid] = (depth * (NODE_WIDTH + COLUMN_GAP), y)
        row += 1
    return positions
