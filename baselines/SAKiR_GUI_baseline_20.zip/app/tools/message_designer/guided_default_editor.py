from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any

from PyQt5 import QtCore, QtGui, QtWidgets

from .object_defaults import array_item_owner, create_guided_value, guided_expression, guided_supported
from .field_logic import case_index


@dataclass
class _ArrayBinding:
    # A Python object keeps references intact; Qt copies dictionaries into QVariant maps.
    node: dict[str, Any]
    field: dict[str, Any]


class GuidedDefaultEditor(QtWidgets.QWidget):
    """Type-aware editor for a serialized field's Python initialization value."""

    changed = QtCore.pyqtSignal()

    def __init__(self, field: dict[str, Any], manifest: dict[str, Any], parent=None, *, deferred=False):
        super().__init__(parent)
        self._field = copy.deepcopy(field)
        self._manifest = manifest
        self._loading = False
        self._value = None
        self._active = False
        self._initialization_error = ""
        self._byte_views = {}

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["Path", "Type", "Value", "Source"])
        self.tree.setRootIsDecorated(True)
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        self.tree.setMinimumHeight(190)
        self.tree.currentItemChanged.connect(lambda *_: self._update_controls())
        layout.addWidget(self.tree)

        controls = QtWidgets.QHBoxLayout()
        self.add_item_button = QtWidgets.QPushButton("Add array item")
        self.remove_item_button = QtWidgets.QPushButton("Remove selected item")
        self.remove_stale_button = QtWidgets.QPushButton("Remove stale values")
        self.reset_template_button = QtWidgets.QPushButton('Reset array from item template')
        controls.addWidget(self.add_item_button)
        controls.addWidget(self.remove_item_button)
        controls.addWidget(self.remove_stale_button)
        controls.addWidget(self.reset_template_button)
        controls.addStretch()
        layout.addLayout(controls)
        self.add_item_button.clicked.connect(self._add_array_item)
        self.remove_item_button.clicked.connect(self._remove_array_item)
        self.remove_stale_button.clicked.connect(self._remove_stale_values)
        self.reset_template_button.clicked.connect(self._reset_array_template)

        preview_heading = QtWidgets.QLabel("Generated Python default")
        preview_heading.setStyleSheet("font-weight: 600;")
        layout.addWidget(preview_heading)
        self.preview = QtWidgets.QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.preview.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.FixedFont))
        self.preview.setMaximumHeight(86)
        layout.addWidget(self.preview)
        if not deferred:
            self.activate()

    def activate(self) -> None:
        if self._active:
            return
        self._active = True
        self._reconcile(self._field.get("object_default_value"))

    def _reconcile(self, existing) -> None:
        try:
            value = create_guided_value(self._field, self._manifest, existing, preserve_array_items=True)
        except (ValueError, TypeError, RecursionError) as error:
            self._initialization_error = str(error)
            self.tree.clear()
            self.preview.setPlainText(self._initialization_error)
            self.add_item_button.setEnabled(False)
            self.remove_item_button.setEnabled(False)
            self.remove_stale_button.setEnabled(False)
            return
        self._initialization_error = ""
        self._value = value
        self.remove_stale_button.setEnabled(True)
        self._rebuild()

    def value(self) -> dict[str, Any] | None:
        if self._initialization_error:
            # Do not silently apply an older value after a failed reconciliation.
            return None
        if self._value is None:
            return copy.deepcopy(self._field.get("object_default_value"))
        return _without_draft_items(self._value)

    def refresh_context(self, field: dict[str, Any], manifest: dict[str, Any]) -> None:
        reference_changed = any(field.get(key) != self._field.get(key) for key in ("kind", "enum_uid", "struct_uid"))
        existing = self._value if self._value is not None else field.get("object_default_value")
        if reference_changed:
            # An explicit empty tree resets the old type instead of seeding its stale default.
            existing = {}
        self._field = copy.deepcopy(field)
        self._manifest = manifest
        self._edit_source = None
        if self._active:
            self._reconcile(existing)

    def _rebuild(self) -> None:
        self._loading = True
        self.tree.clear()
        root = QtWidgets.QTreeWidgetItem([self._field.get("name", "field"), _type_label(self._field, self._manifest), "", ""])
        self.tree.addTopLevelItem(root)
        self._render(root, self._field, self._value, self._field.get("name", "field"))
        root.setExpanded(True)
        self.tree.expandAll()
        self._loading = False
        self._update_controls()
        self._update_preview()

    def _render(self, item, field, value, path) -> None:
        kind = field.get("kind")
        item.setData(0, QtCore.Qt.UserRole, {"field": field, "value": value})
        if kind in {"uint", "int", "bytes_integer", "varint", "zigzag", "computed"}:
            self._integer_value(item, value)
        elif kind == "float":
            self._line_value(item, value, "value", str(value.get("value", 0.0)))
        elif kind == "string":
            self._text_value(item, field, value)
        elif kind == "bytes":
            self._bytes_value(item, value, path)
        elif kind == "bool":
            combo = QtWidgets.QComboBox(); combo.addItem("False", False); combo.addItem("True", True)
            combo.setCurrentIndex(1 if value.get("value") else 0)
            combo.currentIndexChanged.connect(lambda _=0, n=value, w=combo: self._set(n, "value", bool(w.currentData()), w))
            self.tree.setItemWidget(item, 2, combo)
        elif kind == "enum":
            combo = QtWidgets.QComboBox()
            enum = _by_uid(self._manifest.get("enums", []), field.get("enum_uid")) or {}
            for member in enum.get("values", []):
                combo.addItem(f"{member.get('name')} ({member.get('value')})", member.get("uid"))
            index = combo.findData(value.get("value_uid"))
            if value.get("value_uid") and index < 0:
                combo.addItem(f"Missing value: {value.get('value_uid')}", value.get("value_uid")); index = combo.count() - 1
            combo.setCurrentIndex(max(0, index))
            combo.currentIndexChanged.connect(lambda _=0, n=value, w=combo: self._set(n, "value_uid", w.currentData(), w))
            self.tree.setItemWidget(item, 2, combo)
        elif kind == "bitfield":
            assignments = {entry.get("member_uid"): entry for entry in value.get("members", [])}
            for member in field.get("members", []):
                if member.get("kind") == "padding": continue
                entry = assignments.get(member.get("uid")); nested = entry.get("value", {}) if entry else {}
                child = QtWidgets.QTreeWidgetItem([f"{path}.{member.get('name')}", f"{member.get('kind')}[{member.get('bits')}]", "", "Explicit"])
                item.addChild(child)
                pseudo = {"kind": "bool" if member.get("kind") == "flag" else "int"}
                self._render(child, pseudo, nested, child.text(0))
        elif kind in {"struct", "inline_struct"}:
            fields = (_by_uid(self._manifest.get("structures", []), field.get("struct_uid")) or {}).get("fields", []) if kind == "struct" else field.get("fields", [])
            definitions = {nested.get("uid"): nested for nested in fields}
            for assignment in value.get("fields", []):
                nested = definitions.get(assignment.get("field_uid"))
                if not nested:
                    child = QtWidgets.QTreeWidgetItem([
                        f"{path}.<removed:{assignment.get('field_uid', '?')}>", "Missing field", "", "Stale",
                    ])
                    child.setForeground(0, QtGui.QBrush(QtGui.QColor("#b42318")))
                    item.addChild(child)
                    continue
                child_path = f"{path}.{nested.get('name')}"
                child = QtWidgets.QTreeWidgetItem([child_path, _type_label(nested, self._manifest), "", ""])
                item.addChild(child)
                source = QtWidgets.QComboBox(); source.addItem("Explicit value", "explicit"); source.addItem("Use nested default", "default")
                source.setCurrentIndex(max(0, source.findData(assignment.get("source", "explicit"))))
                source.currentIndexChanged.connect(lambda _=0, a=assignment, w=source: self._set(a, "source", w.currentData(), w))
                self.tree.setItemWidget(child, 3, source)
                self._render(child, nested, assignment.get("value", {}), child_path)
        elif kind == "array":
            item.setData(0, QtCore.Qt.UserRole + 1, _ArrayBinding(value, field))
            self._render_array_page(item, field, value, path)
        elif kind == "conditional":
            combo = QtWidgets.QComboBox(); combo.addItem("None", False); combo.addItem("Present", True)
            combo.setCurrentIndex(1 if value.get("present") else 0)
            combo.currentIndexChanged.connect(lambda _=0, n=value, w=combo: self._conditional_changed(n, w.currentData()))
            self.tree.setItemWidget(item, 2, combo)
            child = QtWidgets.QTreeWidgetItem([path, _type_label(field.get("item", {}), self._manifest), "", ""])
            item.addChild(child); self._render(child, field["item"], value.get("value", {}), path)
            child.setHidden(not value.get("present"))
        elif kind == "switch":
            combo = QtWidgets.QComboBox()
            for index, case in enumerate(field.get("cases", [])): combo.addItem(str(case.get("value", index)), index)
            selected = case_index(field, value)
            if selected is None:
                combo.addItem('⚠ Selected branch was removed', -1)
                combo.setCurrentIndex(combo.count() - 1)
            else:
                combo.setCurrentIndex(selected)
            if field.get('selector') == 'this._index' and item.data(0, QtCore.Qt.UserRole + 2) is not None:
                combo.setEnabled(False)
            combo.currentIndexChanged.connect(lambda _=0, n=value, f=field, w=combo: self._switch_changed(n, f, int(w.currentData() or 0)))
            self.tree.setItemWidget(item, 2, combo)
            cases = field.get("cases", [])
            if cases and selected is not None:
                child = QtWidgets.QTreeWidgetItem([path, _type_label(cases[selected]["item"], self._manifest), "", ""])
                item.addChild(child)
                self._render(child, cases[selected]["item"], value.get("value", {}), path)
        elif kind in {"const", "default", "aligned", "rebuild", "checksum"}:
            self._render(item, field.get("item", {}), value.get("value", {}), path)
        else:
            item.setText(2, "Guided editing unavailable")

    def _line_value(self, item, node, key, text, tooltip=""):
        edit = QtWidgets.QLineEdit(text); edit.setToolTip(tooltip)
        edit.textChanged.connect(lambda current, n=node, k=key, w=edit: self._set(n, k, current, w))
        self.tree.setItemWidget(item, 2, edit)

    def _integer_value(self, item, node):
        edit = QtWidgets.QLineEdit(str(node.get('value', 0)))
        edit.setToolTip('Decimal or hexadecimal integer (0x prefix). Right-click to switch Decimal/Hex views.')
        def display(hexadecimal):
            try:
                value = node.get('value', 0)
                number = int(value, 0) if isinstance(value, str) else int(value)
            except (ValueError, TypeError):
                return
            previous = edit.blockSignals(True)
            edit.setText(hex(number) if hexadecimal else str(number))
            edit.blockSignals(previous)
        def menu(position):
            popup = edit.createStandardContextMenu()
            popup.addSeparator()
            popup.addAction('Show decimal', lambda: display(False))
            popup.addAction('Show hexadecimal', lambda: display(True))
            popup.exec_(edit.mapToGlobal(position))
        edit.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        edit.customContextMenuRequested.connect(menu)
        edit.textChanged.connect(lambda text: self._set(node, 'value', text, edit))
        self.tree.setItemWidget(item, 2, edit)

    def _text_value(self, item, field, node):
        container = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(container); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(2)
        edit = QtWidgets.QLineEdit(str(node.get('value', '')))
        feedback = QtWidgets.QLabel(); feedback.setWordWrap(True)
        layout.addWidget(edit); layout.addWidget(feedback)
        encoding = field.get('encoding', 'utf8')
        def update(text):
            try:
                length = len(text.encode(encoding)) if text else 0
                count = len(text)
                feedback.setText(f'{count} character' + ('' if count == 1 else 's') + f' · {length} encoded bytes ({encoding})')
                feedback.setStyleSheet('color: #52627a;')
            except (LookupError, UnicodeError) as error:
                feedback.setText(str(error)); feedback.setStyleSheet('color: #b42318;')
        update(edit.text())
        edit.textChanged.connect(lambda text: (update(text), self._set(node, 'value', text, edit)))
        self.tree.setItemWidget(item, 2, container)

    def _bytes_value(self, item, node, path):
        container = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(container); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(2)
        row = QtWidgets.QHBoxLayout(); row.setContentsMargins(0, 0, 0, 0)
        view = QtWidgets.QComboBox(); view.addItems(['Hex', 'Text (UTF-8)'])
        edit = QtWidgets.QLineEdit(); edit.setMinimumWidth(90)
        row.addWidget(view); row.addWidget(edit, 1)
        feedback = QtWidgets.QLabel(); feedback.setWordWrap(True)
        layout.addLayout(row); layout.addWidget(feedback)
        def display(mode):
            try:
                raw = bytes.fromhex(str(node.get('hex', '')))
                text = raw.decode('utf8') if mode else str(node.get('hex', ''))
            except (ValueError, UnicodeError) as error:
                feedback.setText(str(error)); feedback.setStyleSheet('color: #b42318;')
                previous = view.blockSignals(True); view.setCurrentIndex(0); view.blockSignals(previous)
                self._byte_views[path] = 0
                text = str(node.get('hex', ''))
            else:
                feedback.setText(f'{len(raw)} bytes'); feedback.setStyleSheet('color: #52627a;')
                self._byte_views[path] = mode
            previous = edit.blockSignals(True); edit.setText(text); edit.blockSignals(previous)
        def change(text):
            try:
                raw = text.encode('utf8') if view.currentIndex() else bytes.fromhex(text)
                feedback.setText(f'{len(raw)} bytes'); feedback.setStyleSheet('color: #52627a;')
            except (ValueError, UnicodeError) as error:
                feedback.setText(str(error)); feedback.setStyleSheet('color: #b42318;')
            self._set(node, 'hex', text.encode('utf8').hex(' ') if view.currentIndex() else text, edit)
        view.setCurrentIndex(self._byte_views.get(path, 0))
        display(view.currentIndex())
        view.currentIndexChanged.connect(display); edit.textChanged.connect(change)
        self.tree.setItemWidget(item, 2, container)

    def _render_array_page(self, item, field, value, path, start=0):
        values = value.get('items', [])
        end = min(start + 100, len(values))
        for index in range(start, end):
            child_path = f'{path}[{index}]'
            child = QtWidgets.QTreeWidgetItem([child_path, _type_label(field.get('item', {}), self._manifest), '', ''])
            child.setData(0, QtCore.Qt.UserRole + 2, index)
            item.addChild(child)
            self._render(child, field['item'], values[index], child_path)
        if end < len(values):
            more = QtWidgets.QTreeWidgetItem(['', '', '', ''])
            item.addChild(more)
            button = QtWidgets.QPushButton(f'Load next {min(100, len(values) - end)} items ({len(values) - end} remaining)')
            def load():
                item.takeChild(item.indexOfChild(more))
                self._render_array_page(item, field, value, path, end)
                item.setExpanded(True)
            button.clicked.connect(load)
            self.tree.setItemWidget(more, 2, button)

    def _set(self, node, key, value, source=None):
        self._edit_source = source
        node[key] = value
        if not self._loading:
            self._update_preview(); self.changed.emit()

    def _conditional_changed(self, node, present):
        self._edit_source = None
        node["present"] = bool(present); self._rebuild(); self.changed.emit()

    def _switch_changed(self, node, field, index):
        self._edit_source = None
        cases = field.get("cases", [])
        previous = dict(node)
        if not 0 <= index < len(cases):
            return
        try:
            cache = copy.deepcopy(node.get('branch_values', {}))
            old_index = case_index(field, node)
            if old_index is not None:
                cache[cases[old_index].get('uid', str(old_index))] = copy.deepcopy(node.get('value'))
            identity = cases[index].get('uid', str(index))
            value = create_guided_value(cases[index]['item'], self._manifest, cache.get(identity))
            node.update(case_index=index, case_uid=cases[index].get('uid', ''), value=value, branch_values=cache)
            create_guided_value(self._field, self._manifest, self._value)
        except (ValueError, RecursionError) as error:
            node.update(previous)
            self._rebuild()
            self.preview.setPlainText(str(error))
            return
        self._rebuild(); self.changed.emit()

    def _selected_array(self):
        item = self.tree.currentItem()
        while item is not None:
            metadata = item.data(0, QtCore.Qt.UserRole + 1)
            if metadata: return item, metadata
            item = item.parent()
        return None, None

    def _update_controls(self):
        def contains(field, kinds, seen=frozenset()):
            if field.get('kind') in kinds:
                return True
            uid = field.get('struct_uid')
            if field.get('kind') == 'struct' and uid not in seen:
                definition = _by_uid(self._manifest.get('structures', []), uid) or {}
                if any(contains(child, kinds, seen | {uid}) for child in definition.get('fields', [])):
                    return True
            children = [*field.get('fields', []), *(case.get('item', {}) for case in field.get('cases', []))]
            if isinstance(field.get('item'), dict):
                children.append(field['item'])
            return any(contains(child, kinds, seen) for child in children)
        arrays = contains(self._field, {'array'})
        for button in (self.add_item_button, self.remove_item_button, self.reset_template_button):
            button.setVisible(arrays)
        self.remove_stale_button.setVisible(contains(self._field, {'struct', 'inline_struct', 'bitfield', 'enum', 'switch'}))
        item, metadata = self._selected_array()
        dynamic = bool(metadata and metadata.field.get("mode") != "fixed")
        self.add_item_button.setEnabled(dynamic)
        selected = self.tree.currentItem()
        self.remove_item_button.setEnabled(dynamic and selected is not None and selected.parent() is item)
        self.reset_template_button.setEnabled(bool(metadata and metadata.node.get('items')))

    def _reset_array_template(self):
        _, metadata = self._selected_array()
        if metadata is None:
            return
        try:
            values = [create_guided_value(metadata.field['item'], self._manifest, _index=index)
                      for index, _ in enumerate(metadata.node.get('items', []))]
        except (ValueError, TypeError, RecursionError) as error:
            self.preview.setPlainText(str(error)); return
        metadata.node['items'] = values
        metadata.node.pop('_extra_items', None)
        self._rebuild(); self.changed.emit()

    def _add_array_item(self):
        _, metadata = self._selected_array()
        if not metadata or metadata.field.get("mode") == "fixed": return
        try:
            value = create_guided_value(metadata.field["item"], self._manifest, _index=len(metadata.node.get('items', [])))
        except (ValueError, RecursionError) as error:
            self.preview.setPlainText(str(error))
            return
        items = metadata.node.setdefault("items", [])
        items.append(value)
        try:
            create_guided_value(self._field, self._manifest, self._value)
        except (ValueError, RecursionError) as error:
            items.pop()
            self.preview.setPlainText(str(error))
            return
        self._rebuild(); self.changed.emit()

    def _remove_array_item(self):
        array_item, metadata = self._selected_array(); selected = self.tree.currentItem()
        if not metadata or selected is None or selected.parent() is not array_item: return
        index = selected.data(0, QtCore.Qt.UserRole + 2)
        if isinstance(index, int): metadata.node["items"].pop(index); self._rebuild(); self.changed.emit()

    def _remove_stale_values(self):
        _purge_stale(self._field, self._value, self._manifest)
        self._rebuild(); self.changed.emit()

    def _update_preview(self):
        if self._initialization_error:
            self.preview.setPlainText(self._initialization_error); return
        if not guided_supported(self._field, self._manifest):
            self.preview.setPlainText("Unavailable until type references are complete."); return
        enums = {item.get("uid"): item for item in self._manifest.get("enums", [])}
        structures = {item.get("uid"): item for item in self._manifest.get("structures", [])}
        owner = _owner_for_field(self._manifest, self._field.get("uid")) or "Owner"
        try: expression = guided_expression(self._field, self._value, owner, enums, structures)
        except (KeyError, ValueError, TypeError, StopIteration) as error: expression = f"Incomplete guided value: {error}"
        self.preview.setPlainText(expression)


def _type_label(field, manifest):
    kind = field.get("kind", "unknown")
    if kind == "enum": return (_by_uid(manifest.get("enums", []), field.get("enum_uid")) or {}).get("name", "enum")
    if kind == "struct": return (_by_uid(manifest.get("structures", []), field.get("struct_uid")) or {}).get("name", "struct")
    if kind == "array": return f"array[{_type_label(field.get('item', {}), manifest)}]"
    return kind


def _by_uid(items, uid):
    return next((item for item in items if item.get("uid") == uid), None)


def _inline_name(owner, name):
    return owner + "".join(part.capitalize() for part in name.split("_")) + "Struct"


def _owner_for_field(manifest, target_uid):
    def visit(fields, owner):
        for field in fields:
            if field.get("uid") == target_uid: return owner
            if field.get("kind") == "inline_struct":
                found = visit(field.get("fields", []), _inline_name(owner, field.get("name", "field")))
                if found: return found
            nested = field.get("item")
            if isinstance(nested, dict):
                nested_owner = array_item_owner(owner, field) if field.get("kind") == "array" else owner
                found = visit([nested], nested_owner)
                if found: return found
            for index, case in enumerate(field.get("cases", [])):
                nested = case.get("item")
                if isinstance(nested, dict):
                    case_owner = owner + ''.join(part.capitalize() for part in field['name'].split('_')) + f"Case{case.get('class_index', index)}"
                    found = visit([nested], case_owner)
                    if found: return found
        return None
    for definition in [*manifest.get("structures", []), *manifest.get("messages", [])]:
        found = visit(definition.get("fields", []), definition.get("name", "Owner"))
        if found: return found
    return None


def _without_draft_items(value):
    if isinstance(value, dict):
        return {key: _without_draft_items(nested) for key, nested in value.items() if key != "_extra_items"}
    if isinstance(value, list):
        return [_without_draft_items(nested) for nested in value]
    return copy.deepcopy(value)


def _purge_stale(field, value, manifest):
    kind = field.get("kind")
    if kind in {"struct", "inline_struct"}:
        fields = (_by_uid(manifest.get("structures", []), field.get("struct_uid")) or {}).get("fields", []) if kind == "struct" else field.get("fields", [])
        definitions = {item.get("uid"): item for item in fields if item.get("kind") != "padding"}
        value["fields"] = [item for item in value.get("fields", []) if item.get("field_uid") in definitions]
        for assignment in value["fields"]:
            _purge_stale(definitions[assignment["field_uid"]], assignment.get("value", {}), manifest)
    elif kind == "array":
        for item in value.get("items", []): _purge_stale(field.get("item", {}), item, manifest)
    elif kind == "conditional":
        _purge_stale(field.get("item", {}), value.get("value", {}), manifest)
    elif kind == "switch":
        index = case_index(field, value); cases = field.get("cases", [])
        if isinstance(index, int) and 0 <= index < len(cases): _purge_stale(cases[index].get("item", {}), value.get("value", {}), manifest)
    elif kind in {"const", "default", "aligned", "rebuild", "checksum"}:
        _purge_stale(field.get("item", {}), value.get("value", {}), manifest)
