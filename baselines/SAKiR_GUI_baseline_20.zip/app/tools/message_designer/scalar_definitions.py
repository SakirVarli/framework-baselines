"""Physical scalar capacity and optional protocol constraints (no Qt)."""
import math
import struct


def scalar_errors(field, value):
    kind = field.get('kind')
    errors = []
    if kind == 'float':
        try:
            value = float(value)
            struct.pack('>' + {2: 'e', 4: 'f', 8: 'd'}[field.get('width', 4)], value)
        except (ValueError, TypeError, OverflowError, struct.error, KeyError):
            return ['cannot be represented by the selected floating-point storage']
        if field.get('finite_only') and not math.isfinite(value):
            errors.append('must be finite')
    elif kind in {'uint', 'int', 'bytes_integer', 'varint', 'zigzag'}:
        if type(value) is not int:
            return ['must be an integer']
        if kind == 'varint' and value < 0:
            errors.append('must be nonnegative for VarInt')
        width = field.get('length') if kind == 'bytes_integer' else field.get('width')
        if type(width) is int and width > 0 and kind not in {'varint', 'zigzag'}:
            bits = width * 8
            signed = kind == 'int' or kind == 'bytes_integer' and field.get('signed')
            minimum = -(1 << (bits - 1)) if signed else 0
            maximum = (1 << (bits - bool(signed))) - 1
            if not minimum <= value <= maximum:
                errors.append(f'does not fit the selected {bits}-bit storage')
        maximum_bytes = field.get('max_encoded_bytes')
        if kind in {'varint', 'zigzag'} and type(maximum_bytes) is int and maximum_bytes > 0:
            encoded = (value * 2 if value >= 0 else -value * 2 - 1) if kind == 'zigzag' else value
            if max(1, (encoded.bit_length() + 6) // 7) > maximum_bytes:
                errors.append(f'exceeds the {maximum_bytes}-byte encoding limit')
    else:
        return []
    minimum, maximum = field.get('minimum'), field.get('maximum')
    if type(minimum) in {int, float} and not value >= minimum:
        errors.append(f'is below the protocol minimum {minimum}')
    if type(maximum) in {int, float} and not value <= maximum:
        errors.append(f'is above the protocol maximum {maximum}')
    return errors
