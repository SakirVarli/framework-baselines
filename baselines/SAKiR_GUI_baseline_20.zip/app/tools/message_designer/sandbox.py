from __future__ import annotations

import importlib
import contextlib
import io
import json
import shutil
import sys
import tempfile
import inspect
import struct
import copy
from collections.abc import Mapping
from construct import Container, evaluate
from pathlib import Path
from typing import Any

from app.binary_messages.json_codec import from_json_value, to_json_value

from .generation import generate_library
from app.binary_messages.arrays import DefaultBudgetExceeded, DefaultInputRequired, _context_value, selected_branch


def _wire_snapshot(value):
    if isinstance(value, Mapping):
        return {key: _wire_snapshot(child) for key, child in value.items()
                if not (key == '_io' and hasattr(child, 'read') and hasattr(child, 'seek'))}
    if isinstance(value, (tuple, list)):
        return [_wire_snapshot(child) for child in value]
    return copy.deepcopy(value)


def _decode_snapshot(message_type, encoded):
    """Capture the parser result before user constructors and decoding hooks."""
    missing = object()
    descriptor = message_type.__dict__.get('from_wire', missing)
    original = message_type.from_wire
    captured, failures = [], []
    def capture(cls, value):
        try:
            captured.append(_wire_snapshot(value))
        except Exception as error:
            failures.append(str(error))
        return original(value)
    message_type.from_wire = classmethod(capture)
    try:
        decoded = message_type.decode(encoded)
    finally:
        if descriptor is missing:
            delattr(message_type, 'from_wire')
        else:
            message_type.from_wire = descriptor
    return decoded, captured[-1] if captured else None, '; '.join(failures)


def _payload_differences(expected, actual, specification, path='', context=None, raw_value=None):
    if specification.get('derived'):
        return []
    if specification.get('fallback_when_none'):
        return [] if expected is None else _payload_differences(expected, actual, specification.get('item', {}), path, context, raw_value)
    if expected == actual:
        return []
    if specification.get('float_width') and isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        code = {2: 'e', 4: 'f', 8: 'd'}[specification['float_width']]
        if struct.pack('>' + code, expected) == struct.pack('>' + code, actual):
            return []
    if 'branches' in specification:
        branch = selected_branch(specification, context) or {}
        return _payload_differences(expected, actual, branch, path, context, raw_value)
    if 'cases' in specification:
        for case in specification['cases']:
            if 'fields' not in case or isinstance(expected, dict) and set(expected) == set(case['fields']):
                return _payload_differences(expected, actual, case, path, context, raw_value)
    if isinstance(expected, dict) and isinstance(actual, dict):
        errors = []
        specs = specification.get('fields', {})
        for key in expected.keys() | actual.keys():
            child = specs.get(key, {})
            raw = raw_value.get(key) if isinstance(raw_value, dict) else None
            child_context = context
            if 'fields' in child:
                child_context = Container(raw or {})
                child_context._ = context
                child_context._root = context.get('_root', context) if context else child_context
            errors.extend(_payload_differences(expected.get(key), actual.get(key), child, f'{path}.{key}', child_context, raw))
        return errors
    if isinstance(expected, list) and isinstance(actual, list) and len(expected) == len(actual):
        errors = []
        for index, (left, right) in enumerate(zip(expected, actual)):
            item_spec = specification.get('item', {})
            item_spec = item_spec.get('indexed_cases', {}).get(index, item_spec)
            frame = Container(context or {}); frame._index = index
            raw = raw_value[index] if isinstance(raw_value, list) and index < len(raw_value) else None
            if 'fields' in item_spec:
                frame = Container(raw or {}); frame._ = context
            errors.extend(_payload_differences(left, right, item_spec, f'{path}[{index}]', frame, raw))
        return errors
    return [path or '<message>']


def check_default(message_type):
    """Exercise the real constructor; sample generation is deliberately excluded."""
    required = [name for name, parameter in inspect.signature(message_type).parameters.items()
                if parameter.default is inspect.Parameter.empty
                and parameter.kind not in (parameter.VAR_POSITIONAL, parameter.VAR_KEYWORD)]
    if required:
        return {'ok': True, 'default_status': 'Requires input', 'error': 'Required constructor fields: ' + ', '.join(required)}
    try:
        message = message_type()
        before = to_json_value(message.to_dict())
        encoded = message.encode()
        after = to_json_value(message.to_dict())
        if before != after:
            return {'ok': True, 'default_status': 'Unverified', 'error': 'Encoding hooks changed the initialized object.', 'values': before}
        decoded, parsed, snapshot_error = _decode_snapshot(message_type, encoded)
        rebuilt = decoded.encode()
        if rebuilt != encoded:
            return {'ok': True, 'default_status': 'Invalid', 'error': 'Default message did not re-encode to identical bytes.'}
        actual = to_json_value(decoded.to_dict())
        if snapshot_error or parsed is None:
            return {'ok': True, 'default_status': 'Unverified', 'error': 'Canonical parser values could not be captured: ' + snapshot_error}
        canonical = to_json_value(parsed)
        if not isinstance(canonical, dict) or any(key not in canonical for key in actual):
            return {'ok': True, 'default_status': 'Unverified', 'error': 'Decoded values cannot be mapped to the canonical wire fields.'}
        canonical = {key: canonical[key] for key in actual}
        if canonical != actual:
            return {'ok': True, 'default_status': 'Unverified', 'error': 'Decoding hooks changed canonical wire values.',
                    'initialized_values': before, 'values': canonical}
        raw = _context_value(decoded)
        differences = _payload_differences(before, actual,
                                           {'fields': getattr(message_type, '_DEFAULT_VALUE_SCHEMA', {})}, message_type.__name__, raw, raw)
        if differences:
            return {'ok': True, 'default_status': 'Invalid', 'error': 'Default payload changed during round trip: ' + ', '.join(differences[:10])}
        return {'ok': True, 'default_status': 'Verified', 'round_trip': True,
                'hex': encoded.hex(' '), 'values': actual,
                'initialized_values': before, 'normalized': before != actual}
    except (DefaultBudgetExceeded, MemoryError, RecursionError) as error:
        return {'ok': True, 'default_status': 'Unverified', 'error': str(error)}
    except (KeyError, AttributeError, NameError, DefaultInputRequired) as error:
        return {'ok': True, 'default_status': 'Requires input', 'error': str(error)}
    except Exception as error:
        return {'ok': True, 'default_status': 'Invalid', 'error': str(error)}


def execute(request: dict[str, Any]) -> dict[str, Any]:
    manifest = request["manifest"]
    package_name = manifest["library"]["package_name"]
    root = Path(tempfile.mkdtemp(prefix="sakir-message-preview-"))
    package_dir = root / package_name
    package_dir.mkdir()
    try:
        generated = generate_library(manifest, request.get("behaviors", ""))
        for name, content in generated.files.items():
            (package_dir / name).write_text(content, encoding="utf-8")
        sys.path.insert(0, str(root))
        package = importlib.import_module(package_name)
        message_type = getattr(package, request["message"])
        action = request["action"]
        if action == 'check_default':
            return check_default(message_type)
        if action == "build":
            values = from_json_value(request.get("values", {}))
            message = message_type.from_wire(values)
            encoded = message.encode()
            return {"ok": True, "hex": encoded.hex(" "), "values": to_json_value(message.to_dict())}
        raw = bytes.fromhex(request.get("hex", ""))
        message = message_type.decode(raw)
        result = {"ok": True, "hex": raw.hex(" "), "values": to_json_value(message.to_dict())}
        if action == "round_trip":
            rebuilt = message.encode()
            result["round_trip"] = rebuilt == raw
            result["rebuilt_hex"] = rebuilt.hex(" ")
        return result
    finally:
        if str(root) in sys.path:
            sys.path.remove(str(root))
        for name in list(sys.modules):
            if name == package_name or name.startswith(package_name + "."):
                sys.modules.pop(name, None)
        shutil.rmtree(root, ignore_errors=True)


def main() -> int:
    from .sandbox_limits import limit_preview_memory
    memory_limited = limit_preview_memory()
    output = io.StringIO()
    try:
        request = json.loads(sys.stdin.read())
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            result = execute(request)
    except BaseException as error:
        result = {"ok": False, "error": f"{type(error).__name__}: {error}"}
    if output.getvalue():
        result["log"] = output.getvalue()[-4000:]
    result['memory_limited'] = memory_limited
    sys.stdout.write(json.dumps(result, ensure_ascii=False))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
