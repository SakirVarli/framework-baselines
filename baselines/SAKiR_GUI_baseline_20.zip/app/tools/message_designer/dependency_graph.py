"""Separate build dependencies from parse order and authoritative payloads."""
from .field_logic import effective_expression
from .field_references import expression_paths


def build_cycles(fields, manifest):
    definitions = {field.get('name'): field for field in fields}
    graph = {name: set() for name in definitions}
    writers = {}
    for name, field in definitions.items():
        if field.get('mode') == 'count_field':
            if field.get('kind') == 'array' and field.get('rebuild_count'):
                writers[field.get('count_field')] = name
            if field.get('kind') in {'bytes', 'string'} and field.get('rebuild_length'):
                writers[field.get('length_field')] = name
    def expressions(field, key):
        try:
            return {path.split('.')[0] for path in expression_paths(effective_expression(field, key, manifest)) if not path.startswith('_')}
        except (ValueError, SyntaxError, TypeError):
            return set()
    for name, field in definitions.items():
        kind, mode = field.get('kind'), field.get('mode')
        if kind in {'computed', 'rebuild'}:
            graph[name].update(expressions(field, 'expression'))
            if field.get('expression_mode') == 'guided':
                graph[name].add(field.get('source_field'))
        if kind in {'conditional', 'switch'}:
            key = 'condition' if kind == 'conditional' else 'selector'
            graph[name].update(expressions(field, key))
            if field.get(key + '_mode') == 'field':
                graph[name].add(field.get(key + '_field'))
        if mode == 'count_field' and kind in {'array', 'bytes', 'string'}:
            reference = field.get('count_field' if kind == 'array' else 'length_field')
            if writers.get(reference) != name:
                graph[name].add(reference)
        if mode == 'count_expression' and kind in {'array', 'bytes', 'string'}:
            graph[name].update(expressions(field, 'count_expression' if kind == 'array' else 'length_expression'))
    for target, source in writers.items():
        if target in graph:
            graph[target].add(source)
    completed, active, found, seen = set(), [], [], set()
    def visit(name):
        if name in active:
            cycle = active[active.index(name):] + [name]
            identity = frozenset(cycle)
            if identity not in seen:
                found.append(cycle); seen.add(identity)
            return
        if name in completed or name not in graph:
            return
        active.append(name)
        for dependency in graph[name]:
            visit(dependency)
        active.pop(); completed.add(name)
    for name in graph:
        visit(name)
    return found
