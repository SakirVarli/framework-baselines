"""Shared dimensions for the Message Designer workspace."""

BOTTOM_PANEL_HEIGHT = 190
