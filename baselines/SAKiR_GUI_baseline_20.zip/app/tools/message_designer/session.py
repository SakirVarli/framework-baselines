from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any


SESSION_VERSION = 4


def default_session_path() -> Path:
    app_dir = Path(__file__).resolve().parents[2]
    return app_dir / "data" / "message_designer.json"


def save_session(
    path: Path,
    manifest: dict[str, Any],
    saved_snapshot: dict[str, Any],
    *,
    package_dir: Path | None,
    selected_uid: str,
    expanded_tree_keys: list[str] | None = None,
    property_drafts: dict | None = None,
    routing_drafts: dict | None = None,
    routing_selected_uid: str = "",
    routing_view_state: dict | None = None,
    results_view_state: dict | None = None,
) -> None:
    payload = {
        "session_version": SESSION_VERSION,
        "manifest": manifest,
        "saved_snapshot": saved_snapshot,
        "package_dir": str(package_dir) if package_dir else None,
        "selected_uid": selected_uid,
        "expanded_tree_keys": sorted(set(expanded_tree_keys or [])),
        "property_drafts": property_drafts or {},
        "routing_drafts": routing_drafts or {},
        "routing_selected_uid": routing_selected_uid,
        "routing_view_state": routing_view_state or {},
        "results_view_state": results_view_state or {},
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def load_session(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("session_version") not in {1, 2, 3, SESSION_VERSION}:
        return None
    if not isinstance(payload.get("manifest"), dict) or not isinstance(payload.get("saved_snapshot"), dict):
        return None
    version = payload['manifest'].get('schema_version', 1)
    legacy = type(version) is int and 1 <= version < 9
    payload["session_version"] = SESSION_VERSION
    payload.setdefault("expanded_tree_keys", [])
    if not isinstance(payload.get('routing_view_state'), dict):
        payload['routing_view_state'] = {}
    if not isinstance(payload.get('results_view_state'), dict):
        payload['results_view_state'] = {}
    for key in ("property_drafts", "routing_drafts"):
        if not isinstance(payload.get(key), dict):
            payload[key] = {}
    if legacy:
        from .model import MessageDesignerDocument, normalize_manifest
        document = MessageDesignerDocument(payload['manifest'])
        payload['manifest'] = document.data
        payload['saved_snapshot'] = normalize_manifest(payload['saved_snapshot'])
        for uid, draft in payload['property_drafts'].items():
            target = document.find(uid)
            if not target:
                continue
            if draft.get('kind') == 'Field':
                base, candidate = draft.get('base', {}), draft.get('value')
                if not isinstance(candidate, dict):
                    draft['migration_error'] = 'Legacy unfinished properties retained. Revert this draft before editing the migrated field.'
                    draft['error'] = draft['migration_error']
                    continue
                if any(candidate.get(key) != base.get(key) for key in ('width', 'endian', 'enum_uid')):
                    if base.get('kind') == 'enum' or candidate.get('kind') == 'enum':
                        draft['migration_error'] = 'Legacy enum storage draft retained. Revert this draft, then select or create an enum definition with the required storage.'
                        draft['error'] = draft['migration_error']
                        continue
                if target.get('kind') == 'enum':
                    for value in (base, candidate):
                        for key in ('width', 'endian', 'signed'): value.pop(key, None)
                        value['enum_uid'] = target['enum_uid']
                        if isinstance(value.get('object_default_value'), dict):
                            # Migration reconciles selections by the original member order.
                            old_enum = value['object_default_value'].get('enum_uid')
                            if old_enum != target['enum_uid']:
                                draft['migration_error'] = 'Legacy enum default draft retained after a definition split. Revert and reselect its member.'
            elif draft.get('kind') == 'Enum':
                for key in ('base', 'value'):
                    if isinstance(draft.get(key), dict):
                        draft[key]['storage'] = copy.deepcopy(target.get('storage'))
            if draft.get('migration_error'):
                draft['error'] = draft['migration_error']
    return copy.deepcopy(payload)


def clear_session(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
