"""Bytes/text boundary metadata and value checks shared by the designer."""
from __future__ import annotations

import codecs

from construct import ConstructError
from construct.core import encodingunit

from .array_definitions import PREFIX_FORMATS, known_initial_count


DATA_MODES = {
    'fixed': 'Fixed byte length',
    'count_field': 'Byte length from another field',
    'count_expression': 'Byte length from an expression',
    'prefixed': 'Byte-length prefix',
    'greedy': 'Until end of bounded input',
    'null_terminated': 'Null terminated',
    'pascal': 'Legacy 16-bit little-endian prefix',
}


def length_expression(field):
    if field.get('mode') == 'fixed':
        return str(field.get('length', 0))
    if field.get('mode') == 'count_field':
        expression = 'this.' + str(field.get('length_field', ''))
        # Construct enums parse to symbolic strings with numeric identities.
        return f'lambda ctx: int(({expression})(ctx))'
    return str(field.get('length_expression') or '0')


def known_length(field, manifest):
    if field.get('mode') == 'fixed':
        length = field.get('length')
        return length if type(length) is int and length >= 0 else None
    if field.get('mode') not in {'count_field', 'count_expression'} or (field.get('mode') == 'count_field' and field.get('rebuild_length')):
        return None
    expression = ('this.' + str(field.get('length_field', '')) if field.get('mode') == 'count_field'
                  else field.get('length_expression', '0'))
    return known_initial_count({**field, 'mode': 'count_expression', 'count_expression': expression,
                                'initial_policy': 'resolve', 'initial_count': None}, manifest)


def strict_data(field):
    return (field.get('data_policy') == 'strict' or field.get('mode') in {'prefixed', 'count_expression'}
            or field.get('min_bytes', 0) != 0 or field.get('max_bytes') is not None
            or field.get('rebuild_length', False))


def value_errors(field, value, expected=None):
    """Check known values without executing user expressions or allocating padding."""
    errors = []
    text = field.get('kind') == 'string'
    if text and not isinstance(value, str):
        return ['must be text']
    if not text and not isinstance(value, bytes):
        return ['must be bytes']
    try:
        encoding = field.get('encoding', 'utf8')
        data = (value.encode(encoding) if value else b'') if text else value
        unit = encodingunit(encoding) if text and field.get('mode') in {'fixed', 'null_terminated'} else b'\0'
    except (LookupError, UnicodeError, ValueError, TypeError, ConstructError) as error:
        return [f'cannot encode using {field.get("encoding", "utf8")}: {error}']
    mode = field.get('mode')
    length = field.get('length') if mode == 'fixed' else expected
    if type(length) is int:
        if text and mode == 'fixed':
            if len(data) > length:
                errors.append(f'encodes to {len(data)} bytes but the fixed capacity is {length}')
        elif len(data) != length:
            errors.append(f'contains {len(data)} encoded bytes but requires exactly {length}')
    if mode == 'null_terminated' and any(data[index:index + len(unit)] == unit
                                        for index in range(0, len(data), len(unit))):
        errors.append('contains an embedded null terminator')
    if text and mode == 'fixed' and data and data.endswith(unit) and strict_data(field):
        errors.append('ends with null padding that would be removed when decoding')
    size = length if mode == 'fixed' and type(length) is int else len(data)
    minimum, maximum = field.get('min_bytes', 0), field.get('max_bytes')
    if type(minimum) is int and size < minimum:
        errors.append(f'requires at least {minimum} payload bytes')
    if type(maximum) is int and size > maximum:
        errors.append(f'exceeds maximum {maximum} payload bytes')
    prefix = 'uint16' if mode == 'pascal' else field.get('prefix_format', 'uint16')
    if mode in {'prefixed', 'pascal'} and prefix in PREFIX_FORMATS and prefix != 'varint':
        if len(data) >= 1 << int(prefix[4:]):
            errors.append(f'encoded byte length exceeds {prefix} prefix capacity')
    return errors


def encoding_error(field):
    if field.get('kind') != 'string':
        return None
    try:
        encoding = field.get('encoding', 'utf8')
        codecs.lookup(encoding)
        if field.get('mode') in {'fixed', 'null_terminated'}:
            unit = encodingunit(encoding)
            length = field.get('length')
            if field.get('mode') == 'fixed' and type(length) is int and length % len(unit):
                return f'Fixed length must be a multiple of {len(unit)} bytes for {encoding}.'
    except (LookupError, ValueError, TypeError, ConstructError) as error:
        return str(error)
    return None
