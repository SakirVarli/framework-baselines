from PyQt5 import QtCore, QtGui, QtWidgets
from .commands import RenameCommand, ReparentCommand
from .icons import widget_icon


class DocumentOutline(QtWidgets.QTreeWidget):
    stateChanged = QtCore.pyqtSignal()
    filterTextChanged = QtCore.pyqtSignal(str)

    def __init__(self, document, undo_stack, parent=None):
        super().__init__(parent)
        self.document = document
        self.undo_stack = undo_stack
        self._items = {}
        self._searchable = {}
        self._filter_text = ""
        self._filter_expanded = None
        self.match_count = 0
        self.setHeaderHidden(True)
        self.setUniformRowHeights(True)
        self.setAccessibleName("Document outline tree")
        self.setSelectionMode(self.ExtendedSelection)
        self.setDragDropMode(self.DragDrop)
        self.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.itemSelectionChanged.connect(self._selection_changed)
        self.itemChanged.connect(self._item_renamed)
        self.customContextMenuRequested.connect(self._show_context_menu)
        self.expand_all_action = QtWidgets.QAction("Expand All", self)
        self.expand_all_action.triggered.connect(self.expandAll)
        self.collapse_all_action = QtWidgets.QAction("Collapse All", self)
        self.collapse_all_action.triggered.connect(self.collapseAll)
        self.reveal_selected_action = QtWidgets.QAction("Reveal Selection", self)
        self.reveal_selected_action.setToolTip("Clear the search and reveal selected controls in the outline")
        self.reveal_selected_action.triggered.connect(self.reveal_selection)
        self.document.on_change(self._document_changed)
        self.rebuild()

    def rebuild(self):
        expanded = {node_id: item.isExpanded() for node_id, item in self._items.items()}
        current = self.currentItem()
        current_id = current.data(0, QtCore.Qt.UserRole) if current else None
        scroll = self.verticalScrollBar().value()
        blocked = self.blockSignals(True)
        self.clear()
        self._items = {}
        self._searchable = {}
        root_item = QtWidgets.QTreeWidgetItem(["Window"])
        root_item.setData(0, QtCore.Qt.UserRole, self.document.root.node_id)
        root_item.setToolTip(0, "Application window design surface")
        root_item.setIcon(0, widget_icon("root"))
        root_item.setFlags(root_item.flags() & ~QtCore.Qt.ItemIsDragEnabled)
        self.addTopLevelItem(root_item)
        self._items[self.document.root.node_id] = root_item
        self._searchable[self.document.root.node_id] = self._search_text(self.document.root, "Window")
        for node in self.document.root.children:
            self._add_node(root_item, node)
        for node_id, item in self._items.items():
            item.setExpanded(expanded.get(node_id, True))
        self._sync_selection(current_id)
        self._apply_filter()
        self.verticalScrollBar().setValue(scroll)
        self.blockSignals(blocked)
        self.stateChanged.emit()

    def _add_node(self, parent_item, node):
        item = QtWidgets.QTreeWidgetItem([node.label])
        item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)
        item.setData(0, QtCore.Qt.UserRole, node.node_id)
        details = [node.node_type.replace("_", " ").title()]
        for key in ("name", "instance", "callback"):
            if node.properties.get(key):
                details.append(f"{key.title()}: {node.properties[key]}")
        item.setToolTip(0, "\n".join(details))
        item.setIcon(0, widget_icon(node.node_type))
        self._items[node.node_id] = item
        self._searchable[node.node_id] = self._search_text(node, node.label)
        if parent_item is None:
            self.addTopLevelItem(item)
        else:
            parent_item.addChild(item)
        for child in node.children:
            self._add_node(item, child)

    @property
    def filter_text(self):
        return self._filter_text

    @property
    def item_count(self):
        return len(self._items)

    def set_filter_text(self, text):
        if text == self._filter_text:
            return
        if text.strip() and not self._filter_text.strip():
            self._filter_expanded = {
                node_id: item.isExpanded() for node_id, item in self._items.items()}
        self._filter_text = text
        blocked = self.blockSignals(True)
        self._apply_filter()
        self.blockSignals(blocked)
        self.filterTextChanged.emit(text)
        self.stateChanged.emit()

    @staticmethod
    def _search_text(node, label):
        values = [label, node.node_type, node.node_type.replace("_", " ")]
        values.extend(str(node.properties.get(key) or "")
                      for key in ("name", "instance", "callback", "title"))
        return " ".join(values).casefold()

    def _matches(self, item, words):
        searchable = self._searchable[item.data(0, QtCore.Qt.UserRole)]
        return all(word in searchable for word in words)

    def _apply_filter(self):
        words = self._filter_text.casefold().split()
        self.match_count = 0

        def visit(item, ancestor_matches=False):
            matches = self._matches(item, words)
            self.match_count += int(matches)
            child_visible = False
            for index in range(item.childCount()):
                child_visible = visit(item.child(index), ancestor_matches or matches) or child_visible
            visible = matches or ancestor_matches or child_visible
            item.setHidden(not visible)
            if words and child_visible:
                item.setExpanded(True)
            return visible

        for index in range(self.topLevelItemCount()):
            visit(self.topLevelItem(index))
        if not words and self._filter_expanded is not None:
            for node_id, item in self._items.items():
                item.setExpanded(self._filter_expanded.get(node_id, True))
            self._filter_expanded = None

    def _sync_selection(self, current_id=None):
        selected = set(self.document.selected_ids)
        if current_id is None and selected:
            current_id = self.document.selected_ids[0]
        if current_id in self._items:
            self.setCurrentItem(self._items[current_id], 0, QtCore.QItemSelectionModel.NoUpdate)
        for node_id, item in self._items.items():
            item.setSelected(node_id in selected)

    def reveal_selection(self):
        if not self.document.selected_ids:
            return
        self.set_filter_text("")
        first = None
        for node_id in self.document.selected_ids:
            item = self._items.get(node_id)
            if item is None:
                continue
            first = first or item
            parent = item.parent()
            while parent is not None:
                parent.setExpanded(True)
                parent = parent.parent()
        if first is not None:
            self.scrollToItem(first, self.PositionAtCenter)
            self.setFocus()

    def select_first_match(self):
        words = self._filter_text.casefold().split()
        if not words:
            return
        for item in self._items.values():
            if self._matches(item, words):
                self.setCurrentItem(item)
                self.scrollToItem(item)
                self.setFocus()
                return

    def _set_branch_expanded(self, item, expanded):
        item.setExpanded(expanded)
        for index in range(item.childCount()):
            self._set_branch_expanded(item.child(index), expanded)

    def _show_context_menu(self, position):
        item = self.itemAt(position)
        if item is not None and not item.isSelected():
            self.setCurrentItem(item)
        menu = QtWidgets.QMenu(self)
        if item is not None:
            rename = menu.addAction("Rename", lambda: self.editItem(item, 0))
            rename.setEnabled(item is not self.topLevelItem(0))
            expand = menu.addAction("Expand Branch", lambda: self._set_branch_expanded(item, True))
            collapse = menu.addAction("Collapse Branch", lambda: self._set_branch_expanded(item, False))
            expand.setEnabled(bool(item.childCount()))
            collapse.setEnabled(bool(item.childCount()))
            menu.addSeparator()
        menu.addAction(self.expand_all_action)
        menu.addAction(self.collapse_all_action)
        menu.addAction(self.reveal_selected_action)
        menu.exec_(self.viewport().mapToGlobal(position))

    def _selection_changed(self):
        ids = [item.data(0, QtCore.Qt.UserRole) for item in self.selectedItems()]
        self.document.set_selection(ids)

    def _item_renamed(self, item):
        node = self.document.find(item.data(0, QtCore.Qt.UserRole))
        if not node or node.node_type == "root":
            return
        key = "instance" if node.node_type in {"output", "info"} else "name"
        new_value = item.text(0).strip()
        if new_value and new_value != str(node.properties.get(key, "")):
            self.undo_stack.push(RenameCommand(
                self.document, node.node_id, key, new_value))

    def _document_changed(self, reason, node):
        if reason != "selection":
            self.rebuild()
            return
        blocked = self.blockSignals(True)
        self._sync_selection()
        self.blockSignals(blocked)
        self.stateChanged.emit()

    def dropEvent(self, event):
        source = self.currentItem()
        target = self.itemAt(event.pos())
        if not source or not target or source is target:
            event.ignore()
            return
        node = self.document.find(source.data(0, QtCore.Qt.UserRole))
        target_node = self.document.find(target.data(0, QtCore.Qt.UserRole))
        if not node or not target_node:
            event.ignore()
            return
        parent = target_node if target_node.node_type in {"tab", "group"} else target_node.parent
        if not parent or not self.document.can_parent(parent.node_type, node.node_type):
            event.ignore()
            return
        if any(descendant is parent for descendant in node.walk()):
            event.ignore()
            return
        self.undo_stack.push(ReparentCommand(self.document, node.node_id, parent.node_id))
        event.acceptProposedAction()


class DocumentOutlinePanel(QtWidgets.QWidget):
    """Search and navigation controls around the editable outline tree."""

    def __init__(self, document, undo_stack, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(5)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText("Search name, type, or callback…")
        self.search.setAccessibleName("Search document outline")
        self.search.setToolTip("Filter by name, instance, widget type, or callback. Press Enter to select the first match.")
        self.search.setClearButtonEnabled(True)
        layout.addWidget(self.search)
        self.tree = DocumentOutline(document, undo_stack)
        toolbar = QtWidgets.QHBoxLayout()
        toolbar.setSpacing(3)
        for action, text in (
            (self.tree.expand_all_action, "Expand"),
            (self.tree.collapse_all_action, "Collapse"),
            (self.tree.reveal_selected_action, "Reveal"),
        ):
            action.setIconText(text)
            button = QtWidgets.QToolButton()
            button.setDefaultAction(action)
            button.setText(text)
            button.setToolTip(action.toolTip())
            toolbar.addWidget(button)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)
        layout.addWidget(self.tree, 1)
        self.summary = QtWidgets.QLabel()
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)
        self.search.textChanged.connect(self.tree.set_filter_text)
        self.tree.filterTextChanged.connect(self.search.setText)
        self.search.returnPressed.connect(self.tree.select_first_match)
        self.tree.stateChanged.connect(self._update_summary)
        find = QtWidgets.QShortcut(QtGui.QKeySequence.Find, self)
        find.setContext(QtCore.Qt.WidgetWithChildrenShortcut)
        find.activated.connect(self.focus_search)
        clear = QtWidgets.QShortcut(QtGui.QKeySequence("Escape"), self.search)
        clear.setContext(QtCore.Qt.WidgetShortcut)
        clear.activated.connect(self.search.clear)
        self._update_summary()

    def focus_search(self):
        self.search.setFocus()
        self.search.selectAll()

    def _update_summary(self):
        tree = self.tree
        selected = len(tree.document.selected_ids)
        items = f"{tree.item_count} item" + ("s" if tree.item_count != 1 else "")
        if tree.filter_text.strip():
            matches = f"{tree.match_count} match" + ("es" if tree.match_count != 1 else "")
            text = (f"{matches} · {items}"
                    if tree.match_count else "No matching items")
        else:
            text = items
        if selected:
            text += f" · {selected} selected"
        self.summary.setText(text)
        tree.reveal_selected_action.setEnabled(bool(selected))
