"""Shared, font-independent icons for configuration widget types."""

from functools import lru_cache

from PyQt5 import QtCore, QtGui


COLORS = {
    "root": ("#3569a8", "#e6effa"),
    "tab_widget": ("#7651b5", "#efe8fa"),
    "tab": ("#7651b5", "#efe8fa"),
    "group": ("#a66a19", "#fff1d8"),
    "button": ("#27815a", "#e0f3e9"),
    "output": ("#167b94", "#def3f8"),
    "info": ("#3569a8", "#e6effa"),
}


@lru_cache(maxsize=16)
def widget_icon(node_type):
    if node_type not in COLORS:
        return QtGui.QIcon()
    stroke, fill = COLORS[node_type]
    icon = QtGui.QIcon()
    for size in (16, 24, 32, 48):
        pixmap = QtGui.QPixmap(size, size)
        pixmap.fill(QtCore.Qt.transparent)
        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.scale(size / 24, size / 24)
        painter.setPen(QtGui.QPen(QtGui.QColor(stroke), 1.7, QtCore.Qt.SolidLine,
                                 QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
        painter.setBrush(QtGui.QColor(fill))

        def line(x1, y1, x2, y2):
            painter.drawLine(QtCore.QPointF(x1, y1), QtCore.QPointF(x2, y2))

        def box(x, y, width, height, radius=2):
            painter.drawRoundedRect(QtCore.QRectF(x, y, width, height), radius, radius)

        if node_type == "root":
            box(3, 4, 18, 16)
            line(3, 9, 21, 9)
            for x in (6, 9, 12):
                painter.drawPoint(QtCore.QPointF(x, 6.5))
        elif node_type == "tab_widget":
            box(3, 3, 8, 7, 1)
            box(11, 5, 8, 5, 1)
            box(3, 9, 18, 12, 1)
            line(7, 14, 17, 14)
            line(7, 17, 14, 17)
        elif node_type == "tab":
            painter.drawPolygon(QtGui.QPolygonF([
                QtCore.QPointF(5, 2), QtCore.QPointF(15, 2),
                QtCore.QPointF(20, 7), QtCore.QPointF(20, 22),
                QtCore.QPointF(5, 22),
            ]))
            line(15, 2, 15, 7)
            line(15, 7, 20, 7)
            line(9, 12, 16, 12)
            line(9, 16, 16, 16)
        elif node_type == "group":
            box(2, 5, 20, 16)
            painter.setPen(QtGui.QPen(QtGui.QColor(stroke), 3, QtCore.Qt.SolidLine,
                                     QtCore.Qt.RoundCap))
            line(6, 5, 12, 5)
            painter.setPen(QtGui.QPen(QtGui.QColor(stroke), 1.5))
            box(6, 11, 4, 6, 0.5)
            box(14, 11, 4, 6, 0.5)
        elif node_type == "button":
            box(2, 5, 19, 12, 3)
            line(6, 10, 13, 10)
            painter.setBrush(QtGui.QColor(stroke))
            painter.drawPolygon(QtGui.QPolygonF([
                QtCore.QPointF(14, 12), QtCore.QPointF(14, 22),
                QtCore.QPointF(17, 19), QtCore.QPointF(21, 18),
            ]))
        elif node_type == "output":
            box(2, 3, 20, 14)
            line(6, 7, 9, 10)
            line(9, 10, 6, 13)
            line(12, 13, 17, 13)
            line(12, 17, 12, 21)
            line(7, 21, 17, 21)
        elif node_type == "info":
            painter.drawEllipse(QtCore.QRectF(2, 2, 20, 20))
            line(12, 11, 12, 17)
            painter.setBrush(QtGui.QColor(stroke))
            painter.drawEllipse(QtCore.QRectF(11.2, 6.4, 1.6, 1.6))
        painter.end()
        icon.addPixmap(pixmap)
    return icon
