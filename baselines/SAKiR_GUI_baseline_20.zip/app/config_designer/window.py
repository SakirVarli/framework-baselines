"""Professional, non-modal Visual Studio-style configuration designer."""

import copy
import json
from pathlib import Path

from PyQt5 import QtCore, QtGui, QtWidgets

from app.stub_generator import regenerate_stubs, render_stubs
from app.utils import (
    CALLBACKS_PATH, CONFIG_PATH, PROJECT_ROOT, load_callbacks_as_file, load_json,
    sanitize_func_name,
)
from .callback_manager import (
    append_empty_callback, prepare_callback_source, remove_top_level_function,
    rename_top_level_function,
)
from .commands import (
    AddNodeCommand, BoundsCommand, CallbackSourceCommand, DeleteNodeCommand, GeometryCommand,
    PasteCommand, PropertyCommand, ReplaceDocumentCommand,
)
from .config_normalization import normalize_legacy_property_values
from .design_scene import DesignScene, DesignView
from .document import DesignerDocument
from .layout_migration import migrate_grid_layouts
from .nodes import DesignerNode
from .outline import DocumentOutlinePanel
from .persistence import AtomicConfigTransaction
from .property_inspector import PropertyInspector
from .preview_factory import create_preview_widget
from .schema import default_properties
from .canvas_layout import CanvasLayout
from app.tab_widgets import configure_tab_widget
from .toolbox import ToolboxList
from .validation import validate_document
from .validation_panel import ValidationPanel


class HoverMenuToolButton(QtWidgets.QToolButton):
    """Toolbar menu button that is also discoverable by hovering."""

    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.setText(text)
        self.setAttribute(QtCore.Qt.WA_AlwaysShowToolTips, True)
        self.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        self.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        # Give the native down-arrow a dedicated gutter instead of allowing it
        # to overlap the last label character.  Center it vertically and keep
        # it close to the button's right edge.
        self.setStyleSheet("""
            QToolButton {
                padding-left: 7px;
                padding-right: 20px;
            }
            QToolButton::menu-indicator {
                subcontrol-origin: padding;
                subcontrol-position: center right;
                right: 5px;
            }
        """)
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(250)
        self._hover_timer.timeout.connect(self._open_hover_menu)

    def enterEvent(self, event):
        if self.isEnabled() and self.menu() is not None:
            self._hover_timer.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover_timer.stop()
        super().leaveEvent(event)

    def _open_hover_menu(self):
        if self.isEnabled() and self.menu() is not None and not self.menu().isVisible():
            self.showMenu()


class PreviewDialog(QtWidgets.QDialog):
    """Static preview: intentionally creates no callback connections."""

    def __init__(self, document, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configuration Preview — callbacks disabled")
        self.resize(900, 620)
        layout = QtWidgets.QVBoxLayout(self)
        notice = QtWidgets.QLabel("DESIGN PREVIEW  •  Button callbacks are disabled")
        notice.setStyleSheet("background:#fff3cd;color:#7a5b00;padding:7px;font-weight:600;")
        layout.addWidget(notice)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self._build_container(document.root))
        layout.addWidget(scroll)

    def _build_container(self, node, parent=None):
        if node.node_type == "group":
            surface = QtWidgets.QGroupBox(node.label, parent)
        else:
            surface = QtWidgets.QWidget(parent)
        definition = node.properties.get("layout") or {}
        default_mode = "canvas" if node.node_type == "root" else "grid"
        if definition.get("mode", default_mode) == "canvas":
            design_size = list(definition.get("designSize") or [1200, 800])
            layout = CanvasLayout(
                design_size=design_size,
                resize_mode=definition.get("resizeMode", "anchors"))
            surface.setLayout(layout)
            surface.setMinimumSize(int(design_size[0]), int(design_size[1]))
            for child in node.children:
                layout.addWidgetDefinition(
                    self._build_widget(child, surface), child.properties)
        else:
            layout = QtWidgets.QGridLayout(surface)
            for child in node.children:
                pos = list(child.properties.get("pos") or [0, 0, 1, 1])
                pos += [1] * (4 - len(pos))
                layout.addWidget(
                    self._build_widget(child, surface),
                    pos[0], pos[1], pos[2], pos[3])
        return surface

    def _build_widget(self, node, parent):
        if node.node_type == "tab_widget":
            widget = configure_tab_widget(
                QtWidgets.QTabWidget(parent), node.properties)
            for page in node.children:
                widget.addTab(self._build_container(page, widget), page.label)
        elif node.node_type == "group":
            widget = self._build_container(node, parent)
        else:
            widget = create_preview_widget(node, parent=parent)
            if node.node_type == "button":
                widget.setEnabled(False)
        widget.setToolTip(str(node.properties.get("tooltip") or ""))
        return widget


class ConfigDesignerWindow(QtWidgets.QMainWindow):
    applied = QtCore.pyqtSignal(object)
    saved = QtCore.pyqtSignal(object)
    restoreRequested = QtCore.pyqtSignal(object)
    config_saved = QtCore.pyqtSignal(object, bool)  # legacy observers: True=Apply, False=Save

    def __init__(self, parent=None, config_path=CONFIG_PATH, callbacks_path=CALLBACKS_PATH, *, host=None):
        super().__init__(parent)
        # Keep application services available without making this an owned window.
        self._host = host if host is not None else parent
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, False)
        self.setWindowFlag(QtCore.Qt.Window, True)
        self.setWindowTitle("Configuration Designer")
        self.resize(1450, 850)
        self.config_path, self.callbacks_path = config_path, callbacks_path
        config = load_json(config_path)
        self.document = DesignerDocument.from_config(config)
        self._migration_error = None
        self._migration_result = None
        reference_size = self._migration_reference_size(self._host)
        try:
            normalized_values = normalize_legacy_property_values(self.document)
            migrated_grids = migrate_grid_layouts(self.document, reference_size)
            migrated_legacy_tabs = self.document.upgrade_legacy_layout()
            if normalized_values or migrated_grids or migrated_legacy_tabs:
                upgraded = self.document.to_config()
                self._migration_result = AtomicConfigTransaction(
                    self.config_path, self.callbacks_path).commit_config(upgraded)
                # Reopen the serialized v2 shape so the in-memory saved
                # snapshot exactly matches what was committed to disk.
                self.document = DesignerDocument.from_config(upgraded)
        except Exception as exc:
            self._migration_error = str(exc)
            self.document = DesignerDocument.from_config(config)
        self.undo_stack = QtWidgets.QUndoStack(self)
        self._callback_source_override = None
        self._callback_edit_baseline = None
        self._callback_binding_baseline = {}
        self._known_callback_bindings = {}
        self._callback_migrations = {}
        self._reset_callback_tracking()
        self._clipboard = []
        self._applied_unsaved = False
        self._closing_after_save = False
        self._build_ui()
        self._build_tabs()
        self._connect_document()
        self.run_validation(quiet=True)
        if self._migration_error:
            self.status_state.setText("Legacy upgrade could not be saved")
            self.status_state.setToolTip(self._migration_error)

    @staticmethod
    def _migration_reference_size(parent):
        """Use the currently visible app surface when available."""
        candidate = None
        if parent is not None and hasattr(parent, "centralWidget"):
            candidate = parent.centralWidget()
        if candidate is None:
            candidate = parent
        if candidate is not None:
            size = candidate.size()
            if size.width() >= 200 and size.height() >= 160:
                return [size.width(), size.height()]
        return [1200, 800]

    def _build_ui(self):
        self._build_actions()
        file_menu = self.menuBar().addMenu("&File")
        file_menu.addAction(self.import_config_action)
        file_menu.addAction(self.export_config_action)
        file_menu.addSeparator()
        file_menu.addAction(self.save_action)
        file_menu.addAction(self.save_close_action)
        file_menu.addAction(self.revert_action)
        toolbar = self.addToolBar("Designer")
        toolbar.setMovable(False)
        toolbar.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.undo_action = self.undo_stack.createUndoAction(self, "Undo")
        self.redo_action = self.undo_stack.createRedoAction(self, "Redo")
        self.undo_action.setShortcut(QtGui.QKeySequence.Undo)
        self.redo_action.setShortcut(QtGui.QKeySequence.Redo)
        for action in (
            self.save_action, self.save_close_action, self.apply_action, self.revert_action,
            self.undo_action, self.redo_action,
            self.preview_action, self.validate_action,
        ):
            toolbar.addAction(action)
            if action in (self.revert_action, self.redo_action):
                toolbar.addSeparator()
        toolbar.addSeparator()
        self.align_button = HoverMenuToolButton("Align", toolbar)
        self.align_menu = QtWidgets.QMenu(self.align_button)
        self.align_menu.setToolTipsVisible(True)
        self.align_menu.aboutToShow.connect(
            lambda: self._populate_align_menu(self.align_menu))
        self.align_button.setMenu(self.align_menu)
        toolbar.addWidget(self.align_button)
        self.distribute_button = HoverMenuToolButton("Distribute", toolbar)
        self.distribute_menu = QtWidgets.QMenu(self.distribute_button)
        self.distribute_menu.setToolTipsVisible(True)
        self.distribute_menu.aboutToShow.connect(
            lambda: self._populate_distribute_menu(self.distribute_menu))
        self.distribute_button.setMenu(self.distribute_menu)
        toolbar.addWidget(self.distribute_button)
        toolbar.addAction(self.bring_front_action)
        toolbar.addAction(self.send_back_action)
        toolbar.addSeparator()
        toolbar.addWidget(QtWidgets.QLabel(" Zoom "))
        self.zoom = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.zoom.setRange(50, 175)
        self.zoom.setValue(100)
        self.zoom.setFixedWidth(100)
        self.zoom.setFixedHeight(20)
        self.zoom.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 4px;
                border-radius: 2px;
                background: #cbd5df;
            }
            QSlider::sub-page:horizontal {
                border-radius: 2px;
                background: #4b86b4;
            }
            QSlider::handle:horizontal {
                width: 12px;
                height: 12px;
                margin: -4px 0;
                border: 1px solid #35698f;
                border-radius: 6px;
                background: #f8fafc;
            }
            QSlider::handle:horizontal:hover {
                background: #e5f1fa;
                border-color: #24597f;
            }
        """)
        self.zoom.valueChanged.connect(self._set_zoom)
        toolbar.addWidget(self.zoom)

        splitter = QtWidgets.QSplitter()
        self.setCentralWidget(splitter)
        left = QtWidgets.QTabWidget()
        self.toolbox = ToolboxList()
        left.addTab(self.toolbox, "Toolbox")
        self.outline_panel = DocumentOutlinePanel(self.document, self.undo_stack)
        self.outline = self.outline_panel.tree
        left.addTab(self.outline_panel, "Document Outline")
        left.setMinimumWidth(230)
        splitter.addWidget(left)

        center = QtWidgets.QWidget()
        center_layout = QtWidgets.QVBoxLayout(center)
        center_layout.setContentsMargins(0, 0, 0, 0)
        self.design_tabs = QtWidgets.QTabWidget()
        self.design_tabs.setMovable(False)
        self.design_tabs.currentChanged.connect(self._tab_changed)
        self.design_tabs.tabBarClicked.connect(
            self._design_surface_tab_clicked)
        center_layout.addWidget(self.design_tabs)
        splitter.addWidget(center)

        right = QtWidgets.QTabWidget()
        self.properties = PropertyInspector(
            self.document, self.undo_stack, self._callback_source)
        right.addTab(self.properties, "Properties")
        right.setMinimumWidth(310)
        splitter.addWidget(right)
        splitter.setSizes([240, 900, 330])

        bottom = QtWidgets.QDockWidget("Validation", self)
        bottom.setAllowedAreas(QtCore.Qt.BottomDockWidgetArea)
        self.validation_panel = ValidationPanel()
        bottom.setWidget(self.validation_panel)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, bottom)
        bottom.setMinimumHeight(145)
        self.validation_panel.issueActivated.connect(self._focus_issue)
        self.validation_panel.issueActionRequested.connect(self._validation_action)

        self.status_item = QtWidgets.QLabel("No selection")
        self.statusBar().addWidget(self.status_item, 1)
        self.status_state = QtWidgets.QLabel("Saved")
        self.statusBar().addPermanentWidget(self.status_state)

        self.properties.openCallbackRequested.connect(self._open_callback)
        self._apply_designer_tooltips()
        self.setStyleSheet("""
            QMainWindow { background: #eef2f6; }
            QToolBar { background: #f8fafc; border-bottom: 1px solid #ccd6e0; spacing: 3px; }
            QGroupBox { font-weight: 600; margin-top: 8px; }
            QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 3px; }
            QTreeWidget, QListWidget, QScrollArea, QTabWidget::pane { background: white; }
            QLabel[muted="true"] { color: #687787; }
        """)

    def _apply_designer_tooltips(self):
        tips = {
            self.import_config_action: (
                "Import config.json as an unsaved, validated and undoable designer change. "
                "Legacy grid layouts are converted to canvas layouts."),
            self.export_config_action: (
                "Validate and export the current working configuration without changing the project files."),
            self.save_action: "Validate and atomically save config.json and callbacks.py.",
            self.save_close_action: "Save safely, reload the running application, and close the designer.",
            self.apply_action: "Apply the working layout temporarily without writing either source file.",
            self.revert_action: "Restore the last configuration saved on disk.",
            self.preview_action: "Preview the application layout without executing button callbacks.",
            self.validate_action: "Check hierarchy, geometry, callbacks, files, colors and layout constraints.",
            self.add_tab_action: "Add a new tab to the configuration.",
            self.bring_front_action: "Place selected canvas controls in front of their siblings.",
            self.send_back_action: "Place selected canvas controls behind their siblings.",
            self.cut_action: "Cut the selected controls to the designer clipboard.",
            self.copy_action: "Copy the selected controls to the designer clipboard.",
            self.paste_action: "Paste controls into the selected container.",
        }
        for action, text in tips.items():
            action.setToolTip(text)
            action.setStatusTip(text)
        self.zoom.setToolTip(
            "Zoom the design surface without changing geometry. You can also use Ctrl + mouse wheel.")
        self.design_tabs.setToolTip(
            "Application design surface. Use Ctrl + wheel to zoom and Shift + wheel "
            "to scroll horizontally. Ctrl + drag selects multiple components within "
            "the parent where the drag begins.")
        self.toolbox.setToolTip("Drag controls from here onto the active tab or group.")
        self.outline.setToolTip(
            "Configuration hierarchy. Search by name, type, or callback; use Expand, Collapse, "
            "or Reveal to navigate. Press F2 or right-click an item to rename it.")
        self.properties.setToolTip("Edit typed properties for the selected control or container.")
        self.validation_panel.setToolTip("Double-click a validation message to focus the affected control.")
        self._update_arrange_actions()

    def _build_actions(self):
        self.import_config_action = QtWidgets.QAction("Import config.json…", self)
        self.import_config_action.setShortcut(QtGui.QKeySequence.Open)
        self.export_config_action = QtWidgets.QAction("Export config.json…", self)
        self.save_action = QtWidgets.QAction("Save", self)
        self.save_action.setShortcut(QtGui.QKeySequence.Save)
        self.save_close_action = QtWidgets.QAction("Save and Close", self)
        self.save_close_action.setShortcut("Ctrl+Shift+S")
        self.apply_action = QtWidgets.QAction("Apply", self)
        self.apply_action.setShortcut("Ctrl+Enter")
        self.revert_action = QtWidgets.QAction("Revert", self)
        self.preview_action = QtWidgets.QAction("Preview", self)
        self.preview_action.setShortcut("F5")
        self.validate_action = QtWidgets.QAction("Validate", self)
        self.validate_action.setShortcut("F7")
        self.delete_action = QtWidgets.QAction("Delete", self)
        self.delete_action.setShortcut(QtGui.QKeySequence.Delete)
        self.cut_action = QtWidgets.QAction("Cut", self)
        self.cut_action.setShortcut(QtGui.QKeySequence.Cut)
        self.copy_action = QtWidgets.QAction("Copy", self)
        self.copy_action.setShortcut(QtGui.QKeySequence.Copy)
        self.paste_action = QtWidgets.QAction("Paste", self)
        self.paste_action.setShortcut(QtGui.QKeySequence.Paste)
        self.duplicate_action = QtWidgets.QAction("Duplicate", self)
        self.duplicate_action.setShortcut("Ctrl+D")
        self.add_tab_action = QtWidgets.QAction("Add Page", self)
        self.add_tab_action.setVisible(False)
        self.add_tab_action.setShortcut("Ctrl+T")
        self.convert_canvas_action = QtWidgets.QAction("Convert to Canvas", self)
        self.convert_canvas_action.setVisible(False)
        self.convert_canvas_action.setToolTip(
            "Convert the current tab or group to exact X, Y, width and height while preserving grid positions.")
        self.convert_grid_action = QtWidgets.QAction("Convert to Grid", self)
        self.convert_grid_action.setVisible(False)
        self.convert_grid_action.setToolTip(
            "Return the current container to row/column placement. Canvas bounds remain preserved.")
        self.bring_front_action = QtWidgets.QAction("Bring to Front", self)
        self.send_back_action = QtWidgets.QAction("Send to Back", self)
        self.import_config_action.triggered.connect(self.import_config)
        self.export_config_action.triggered.connect(self.export_config)
        self.save_action.triggered.connect(self.save_config)
        self.save_close_action.triggered.connect(lambda: self.save_config(close_after=True))
        self.apply_action.triggered.connect(self.apply_changes)
        self.revert_action.triggered.connect(self.revert_changes)
        self.preview_action.triggered.connect(self.show_preview)
        self.validate_action.triggered.connect(self.run_validation)
        self.delete_action.triggered.connect(self.delete_selected)
        self.cut_action.triggered.connect(self.cut_selected)
        self.copy_action.triggered.connect(self.copy_selected)
        self.paste_action.triggered.connect(self.paste)
        self.duplicate_action.triggered.connect(self.duplicate_selected)
        self.add_tab_action.triggered.connect(self.add_tab)
        self.convert_canvas_action.triggered.connect(self.convert_current_to_canvas)
        self.convert_grid_action.triggered.connect(self.convert_current_to_grid)
        self.bring_front_action.triggered.connect(lambda: self.change_z_order(front=True))
        self.send_back_action.triggered.connect(lambda: self.change_z_order(front=False))
        for action in (self.delete_action, self.cut_action, self.copy_action,
                       self.paste_action, self.duplicate_action,
                       self.bring_front_action, self.send_back_action):
            self.addAction(action)

    def _build_tabs(self):
        self._rebuilding_tabs = True
        self.design_tabs.blockSignals(True)
        while self.design_tabs.count():
            widget = self.design_tabs.widget(0)
            if isinstance(widget, DesignView):
                widget.scene().dispose()
            self.design_tabs.removeTab(0)
            widget.deleteLater()
        scene = DesignScene(
            self.document, self.undo_stack, self.document.root.node_id)
        scene.rebuild()
        scene.statusChanged.connect(self.status_item.setText)
        scene.contextActionRequested.connect(self._designer_context_action)
        view = DesignView(scene)
        view.zoomChanged.connect(self._zoom_from_view)
        self.design_tabs.addTab(view, "Window")
        self.design_tabs.blockSignals(False)
        self._rebuilding_tabs = False
        self.design_tabs.setCurrentIndex(0)
        self._update_layout_actions()

    def _connect_document(self):
        self.document.on_change(self._document_changed)
        self.undo_stack.cleanChanged.connect(self._clean_changed)

    def _document_changed(self, reason, node):
        callback_changed = self._track_callback_changes(reason)
        if reason == "selection" and node:
            if self._activate_owning_pages(node):
                self.current_scene().rebuild()
        if reason in {"revert", "replace"}:
            self._build_tabs()
        if reason not in {"selection", "saved", "applied"}:
            self.status_state.setText("Modified" + (" • Applied, not saved" if self._applied_unsaved else ""))
        self._update_layout_actions()
        if callback_changed and hasattr(self, "validation_panel"):
            self.run_validation(quiet=True)

    def _effective_callback_bindings(self):
        return {
            node.node_id: str(
                node.properties.get("callback") or
                sanitize_func_name(node.properties.get("name", "")))
            for node in self.document.root.walk()
            if node.node_type == "button"
        }

    def _reset_callback_tracking(self):
        current = self._effective_callback_bindings()
        self._callback_binding_baseline = dict(current)
        self._known_callback_bindings = dict(current)
        self._callback_migrations = {}

    def _track_callback_changes(self, reason):
        if reason in {"saved", "applied", "selection"}:
            return False
        if reason in {"revert", "replace"}:
            self._reset_callback_tracking()
            return True
        previous = self._known_callback_bindings
        current = self._effective_callback_bindings()
        changed = current != previous
        for node_id, new_callback in current.items():
            if node_id not in previous:
                self._callback_binding_baseline.setdefault(
                    node_id, new_callback)
                continue
            old_callback = previous[node_id]
            if new_callback == old_callback:
                continue
            baseline = self._callback_binding_baseline.get(
                node_id, old_callback)
            if new_callback == baseline:
                self._callback_migrations.pop(node_id, None)
            else:
                self._callback_migrations.setdefault(
                    node_id, old_callback)
        removed = set(previous) - set(current)
        for node_id in removed:
            self._callback_binding_baseline.pop(node_id, None)
            self._callback_migrations.pop(node_id, None)
        self._known_callback_bindings = dict(current)
        return changed

    def _clean_changed(self, clean):
        if clean and not self.document.is_dirty:
            self.status_state.setText("Saved")

    def current_scene(self):
        view = self.design_tabs.currentWidget()
        return view.scene() if isinstance(view, DesignView) else None

    def _tab_changed(self, index):
        view = self.design_tabs.widget(index)
        if isinstance(view, DesignView):
            self._zoom_from_view(round(view.transform().m11() * 100))
        self._update_layout_actions()

    def _design_surface_tab_clicked(self, index):
        view = self.design_tabs.widget(index)
        if isinstance(view, DesignView) and view.scene().container:
            self.document.set_selection([
                view.scene().container.node_id])

    def _focus_owning_tab(self, node_id):
        """Reveal all owning pages while keeping the Window canvas active."""
        node = self.document.find(node_id)
        if not node:
            return
        self._activate_owning_pages(node)
        self.design_tabs.setCurrentIndex(0)
        self.current_scene().set_container(self.document.root.node_id)
        self._update_layout_actions()

    @staticmethod
    def _activate_owning_pages(node):
        changed = False
        cursor = node
        while cursor:
            if (cursor.node_type == "tab" and cursor.parent and
                    cursor.parent.node_type == "tab_widget"):
                if cursor.parent.metadata.get("active_page_id") != cursor.node_id:
                    cursor.parent.metadata["active_page_id"] = cursor.node_id
                    changed = True
            cursor = cursor.parent
        return changed

    def _update_layout_actions(self):
        node = self._active_layout_container()
        if node:
            default = "canvas" if node.node_type == "root" else "grid"
            mode = node.get_property("layout.mode", default)
            canvas = mode == "canvas"
            self.convert_canvas_action.setEnabled(mode != "canvas")
            self.convert_grid_action.setEnabled(mode == "canvas")
            self.bring_front_action.setEnabled(canvas)
            self.send_back_action.setEnabled(canvas)
        if hasattr(self, "align_button"):
            self._update_arrange_actions()

    def _arrange_nodes(self):
        nodes = [self.document.find(node_id) for node_id in self.document.selected_ids]
        return [node for node in nodes
                if node and node.node_type not in {"root", "tab"} and node.parent]

    def _compatible_arrange_nodes(self):
        nodes = self._arrange_nodes()
        if not nodes or len({node.parent.node_id for node in nodes}) != 1:
            return []
        return nodes

    def _update_arrange_actions(self):
        nodes = self._compatible_arrange_nodes()
        align_enabled = bool(nodes)
        distribute_enabled = len(nodes) >= 3
        self.align_button.setEnabled(align_enabled)
        self.distribute_button.setEnabled(distribute_enabled)
        self.align_button.setToolTip(
            "Align the selected component to its parent, or align multiple sibling components "
            "to the first-selected component or their parent."
            if align_enabled else
            "Select one movable component, or multiple components in the same parent, to align.")
        self.distribute_button.setToolTip(
            "Space three or more sibling components with equal gaps, horizontally or vertically; "
            "the outer components stay fixed."
            if distribute_enabled else
            "Select at least three components in the same parent to distribute.")

    @staticmethod
    def _add_menu_action(menu, label, callback, tooltip):
        action = menu.addAction(label)
        action.setToolTip(tooltip)
        action.setStatusTip(tooltip)
        action.triggered.connect(callback)
        return action

    def _populate_align_menu(self, menu):
        menu.clear()
        nodes = self._compatible_arrange_nodes()
        if not nodes:
            action = menu.addAction("Select compatible components to align")
            action.setEnabled(False)
            return
        directions = (
            ("Left edges", "left"),
            ("Horizontal centers", "hcenter"),
            ("Right edges", "right"),
            ("Top edges", "top"),
            ("Vertical centers", "vcenter"),
            ("Bottom edges", "bottom"),
        )
        if len(nodes) > 1:
            reference = menu.addMenu("Align to First Selected")
            reference.setToolTipsVisible(True)
            for label, direction in directions:
                self._add_menu_action(
                    reference, label,
                    lambda checked=False, value=direction: self.align_items(value, "selection"),
                    "Keep the first-selected component fixed and align the other selected siblings to it.")
        parent = menu.addMenu("Align to Parent")
        parent.setToolTipsVisible(True)
        for label, direction in directions:
            self._add_menu_action(
                parent, label,
                lambda checked=False, value=direction: self.align_items(value, "parent"),
                "Align each selected component inside the corresponding edge or center of its parent.")

    def _populate_distribute_menu(self, menu):
        menu.clear()
        nodes = self._compatible_arrange_nodes()
        enabled = len(nodes) >= 3
        rows = self._add_menu_action(
            menu, "Rows (Vertically)",
            lambda: self.distribute_items("vertical"),
            "Keep the topmost and bottommost components fixed and make the vertical gaps equal.")
        columns = self._add_menu_action(
            menu, "Columns (Horizontally)",
            lambda: self.distribute_items("horizontal"),
            "Keep the leftmost and rightmost components fixed and make the horizontal gaps equal.")
        rows.setEnabled(enabled)
        columns.setEnabled(enabled)

    def _active_layout_container(self):
        """Use a selected page/group for layout commands, otherwise the window."""
        selected = [
            self.document.find(node_id)
            for node_id in self.document.selected_ids
        ]
        selected = [node for node in selected if node]
        if len(selected) == 1 and selected[0].node_type in {"root", "tab", "group"}:
            return selected[0]
        scene = self.current_scene()
        return scene.container if scene else None

    @staticmethod
    def _container_grid(container):
        explicit = container.properties.get("grid") if container else None
        if isinstance(explicit, list) and len(explicit) == 2:
            return explicit
        rows = columns = 1
        for child in container.children if container else []:
            pos = list(child.properties.get("pos") or [0, 0, 1, 1])
            pos += [1] * (4 - len(pos))
            rows = max(rows, pos[0] + pos[2])
            columns = max(columns, pos[1] + pos[3])
        return [rows, columns]

    def _set_zoom(self, value):
        view = self.design_tabs.currentWidget()
        if isinstance(view, DesignView):
            view.set_zoom_percent(value)

    def _zoom_from_view(self, value):
        self.zoom.blockSignals(True)
        self.zoom.setValue(value)
        self.zoom.blockSignals(False)

    def _callback_source(self):
        if self._callback_source_override is not None:
            return self._callback_source_override
        try:
            with open(self.callbacks_path, "r", encoding="utf-8") as stream:
                return stream.read()
        except FileNotFoundError:
            from app.starter_project import default_callbacks_source
            return default_callbacks_source()

    @property
    def _callbacks_dirty(self):
        return (self._callback_source_override is not None and
                self._callback_source_override != self._callback_edit_baseline)

    def _set_callback_source(self, source):
        if self._callback_edit_baseline is None:
            self._callback_edit_baseline = self._callback_source()
        # Returning to the baseline releases the in-memory override so a later
        # save cannot overwrite an external callbacks.py edit with stale text.
        self._callback_source_override = (
            None if source == self._callback_edit_baseline else source)
        self.status_state.setText("Modified")
        self.run_validation(quiet=True)
        self.properties.rebuild()

    def _validation_action(self, issue):
        if isinstance(issue, tuple):
            issue, action = issue
        else:
            action = issue.action
        if not action or not issue.action_target:
            return
        if action == "generate-callback":
            try:
                old_source = self._callback_source()
                new_source = append_empty_callback(
                    old_source, issue.action_target)
            except (OSError, SyntaxError, ValueError) as error:
                QtWidgets.QMessageBox.critical(
                    self, "Callback could not be generated", str(error))
                return
            if new_source != old_source:
                self.undo_stack.push(CallbackSourceCommand(
                    self._set_callback_source, old_source, new_source,
                    f"Generate callback {issue.action_target}"))
            return
        if action == "keep-previous-callback":
            node = self.document.find(issue.node_id)
            if node and node.node_type == "button" and issue.previous_target:
                self.undo_stack.push(PropertyCommand(
                    self.document, [node.node_id], "callback",
                    issue.previous_target, "Keep previous callback"))
            return
        if action == "rename-previous-callback":
            answer = QtWidgets.QMessageBox.question(
                self, "Rename callback function?",
                f"Rename '{issue.previous_target}' to '{issue.action_target}' while "
                "preserving its function body?\n\nThe change is undoable and is not "
                "written until Save.",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if answer != QtWidgets.QMessageBox.Yes:
                return
            try:
                old_source = self._callback_source()
                new_source = rename_top_level_function(
                    old_source, issue.previous_target, issue.action_target)
            except (OSError, SyntaxError, ValueError) as error:
                QtWidgets.QMessageBox.critical(
                    self, "Callback could not be renamed", str(error))
                return
            self.undo_stack.push(CallbackSourceCommand(
                self._set_callback_source, old_source, new_source,
                f"Rename callback {issue.previous_target}"))
            return
        if action != "delete-callback":
            return
        callback = issue.action_target
        answer = QtWidgets.QMessageBox.question(
            self, "Delete empty callback?",
            f"Delete the empty callback '{callback}'?\n\n"
            "The change is not written until Save, and you can restore it with Undo.",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if answer != QtWidgets.QMessageBox.Yes:
            return
        try:
            old_source = self._callback_source()
            new_source = remove_top_level_function(old_source, callback)
        except (OSError, SyntaxError, ValueError) as error:
            QtWidgets.QMessageBox.critical(
                self, "Callback could not be deleted", str(error))
            return
        if new_source == old_source:
            self.run_validation(quiet=True)
            return
        self.undo_stack.push(CallbackSourceCommand(
            self._set_callback_source, old_source, new_source,
            f"Delete callback {callback}"))

    def _issues(self):
        try:
            source = self._callback_source()
        except OSError:
            source = ""
        return validate_document(
            self.document, source, PROJECT_ROOT, self._callback_migrations)

    def run_validation(self, quiet=False):
        issues = self._issues()
        self._last_validation_issues = issues
        self.validation_panel.set_issues(issues)
        errors = sum(issue.blocking for issue in issues)
        warnings = len(issues) - errors
        self.statusBar().showMessage(f"Validation: {errors} error(s), {warnings} warning(s)", 5000)
        if not quiet and not issues:
            QtWidgets.QMessageBox.information(self, "Validation", "No validation issues found.")
        return issues

    def _allow_operation(self, operation):
        issues = self.run_validation(quiet=True)
        errors = [issue for issue in issues if issue.blocking]
        warnings = [issue for issue in issues if not issue.blocking]
        if errors:
            QtWidgets.QMessageBox.critical(
                self, f"Cannot {operation}",
                f"Resolve {len(errors)} blocking validation error(s) before {operation.lower()}.")
            return False
        if warnings:
            result = QtWidgets.QMessageBox.question(
                self, f"{operation} with warnings",
                f"There are {len(warnings)} warning(s). Continue?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            return result == QtWidgets.QMessageBox.Yes
        return True

    def import_config(self):
        """Load a config into the working document as one undoable edit."""
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Import config.json", PROJECT_ROOT, "JSON (*.json)")
        if not path:
            return False

        try:
            with open(path, "r", encoding="utf-8") as stream:
                config = json.load(stream)
            imported = DesignerDocument.from_config(config)
            normalized_values = normalize_legacy_property_values(imported)
            reference_size = self._migration_reference_size(self._host)
            migrated_grids = migrate_grid_layouts(imported, reference_size)
            migrated_legacy_tabs = imported.upgrade_legacy_layout()
            # Reparse the serialized representation so the command receives
            # exactly the schema-v2 shape users will later save or export.
            imported = DesignerDocument.from_config(imported.to_config())
        except Exception as error:
            QtWidgets.QMessageBox.critical(
                self, "Import failed",
                f"The selected config could not be imported or converted.\n\n{error}")
            return False

        if imported.to_config() == self.document.to_config():
            self.run_validation(quiet=True)
            QtWidgets.QMessageBox.information(
                self, "Config unchanged",
                "The imported configuration matches the current designer document.")
            return True

        self.undo_stack.push(ReplaceDocumentCommand(self.document, imported))
        issues = self._last_validation_issues
        errors = sum(issue.blocking for issue in issues)
        warnings = len(issues) - errors
        conversion_note = (
            "Legacy values and layouts were normalized for schema v2.\n"
            if normalized_values or migrated_grids or migrated_legacy_tabs else "")
        QtWidgets.QMessageBox.information(
            self, "Config imported",
            "The configuration was imported as an unsaved, undoable designer change.\n"
            f"{conversion_note}Validation: {errors} error(s), {warnings} warning(s).\n\n"
            "Review any issues, then use Save to update the project.")
        return True

    def export_config(self):
        """Validate and export the current working configuration."""
        if not self._allow_operation("Export"):
            return False
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Export config.json",
            str(Path(PROJECT_ROOT) / "config.json"), "JSON (*.json)")
        if not path:
            return False
        target = Path(path)
        if target.suffix.lower() != ".json":
            target = target.with_suffix(".json")
        if target.resolve() == Path(self.config_path).resolve():
            QtWidgets.QMessageBox.warning(
                self, "Use Save for the project config",
                "Export cannot replace the active project config.json. Use Save so "
                "configuration, callbacks and developer stubs stay consistent.")
            return False
        try:
            result = AtomicConfigTransaction(
                target, self.callbacks_path).commit_config(self.document.to_config())
        except Exception as error:
            QtWidgets.QMessageBox.critical(
                self, "Export failed", f"The configuration could not be exported.\n\n{error}")
            return False
        backup_note = (
            f"\n\nPrevious export backed up to:\n{result.config_backup}"
            if result.config_backup else "")
        QtWidgets.QMessageBox.information(
            self, "Config exported",
            f"Validated configuration exported to:\n{target}{backup_note}")
        return True

    def apply_changes(self):
        self._ensure_enhanced_layout()
        if not self._allow_operation("Apply"):
            return False
        config = self.document.to_config()
        self.document.mark_applied()
        self._applied_unsaved = config != self.document.saved_snapshot
        self.applied.emit(copy.deepcopy(config))
        self.config_saved.emit(copy.deepcopy(config), True)
        self.status_state.setText("Applied, not saved" if self._applied_unsaved else "Saved")
        return True

    def save_config(self, close_after=False):
        self._ensure_enhanced_layout()
        if not self._allow_operation("Save"):
            return False
        config = self.document.to_config()
        try:
            callbacks, analysis = prepare_callback_source(config, self._callback_source())
            # Render and compile-check generated developer stubs before either
            # user-owned file is committed.
            render_stubs(config)
            self._last_save_result = AtomicConfigTransaction(
                self.config_path, self.callbacks_path).commit(config, callbacks)
        except Exception as error:
            QtWidgets.QMessageBox.critical(
                self, "Save failed",
                f"No partial save was kept. The previous files were restored.\n\n{error}")
            return False
        stub_warning = ""
        try:
            regenerate_stubs(config)
        except Exception as error:
            stub_warning = f" Developer stubs could not be refreshed: {error}"
            QtWidgets.QMessageBox.warning(
                self, "Saved with stub warning",
                "Configuration and callbacks were saved safely, but the generated "
                f"developer API could not be refreshed.\n\n{error}")
        self.document.mark_saved()
        self._callback_source_override = None
        self._callback_edit_baseline = None
        self._reset_callback_tracking()
        self.properties.rebuild()
        self.run_validation(quiet=True)
        self.undo_stack.setClean()
        self._applied_unsaved = False
        self.saved.emit(copy.deepcopy(config))
        self.config_saved.emit(copy.deepcopy(config), False)
        self.status_state.setText("Saved")
        self.statusBar().showMessage(
            f"Saved atomically. Generated {len(analysis.missing)} callback stub(s).{stub_warning}", 6000)
        backup_parts = [
            path for path in (
                self._last_save_result.config_backup,
                self._last_save_result.callbacks_backup,
            ) if path
        ]
        self.status_state.setToolTip(
            "Backups:\n" + "\n".join(backup_parts) if backup_parts else "New files; no prior backups required.")
        if close_after:
            self._closing_after_save = True
            self.close()
        return True

    def _ensure_enhanced_layout(self):
        """Prevent Apply/Save from emitting legacy or grid-based layouts."""
        reference = self.document.root.get_property(
            "layout.designSize", [1200, 800])
        changed = migrate_grid_layouts(self.document, reference)
        changed = self.document.upgrade_legacy_layout() or changed
        if changed:
            self.undo_stack.clear()
            self.document.notify("migration", self.document.root)

    def revert_changes(self):
        if self.document.is_dirty or self._callbacks_dirty or self._applied_unsaved:
            answer = QtWidgets.QMessageBox.question(
                self, "Revert changes", "Discard all edits since the last save?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if answer != QtWidgets.QMessageBox.Yes:
                return
        self.document.restore_saved()
        self._callback_source_override = None
        self._callback_edit_baseline = None
        self._reset_callback_tracking()
        self.undo_stack.clear()
        if self._applied_unsaved:
            self.restoreRequested.emit(copy.deepcopy(self.document.saved_snapshot))
        self._applied_unsaved = False
        self.status_state.setText("Saved")
        self.run_validation(quiet=True)

    def show_preview(self):
        if any(issue.blocking for issue in self.run_validation(quiet=True)):
            QtWidgets.QMessageBox.critical(self, "Preview unavailable", "Resolve blocking errors first.")
            return
        preview = PreviewDialog(self.document, self)
        preview.exec_()

    def delete_selected(self):
        ids = [node_id for node_id in self.document.selected_ids
               if (self.document.find(node_id) and self.document.find(node_id).node_type != "root")]
        if not ids:
            return
        self.undo_stack.beginMacro("Delete selection")
        try:
            for node_id in ids:
                if self.document.find(node_id):
                    self.undo_stack.push(DeleteNodeCommand(self.document, node_id))
        finally:
            self.undo_stack.endMacro()

    def copy_selected(self):
        self._clipboard = [
            self.document.find(node_id).clone()
            for node_id in self.document.selected_ids if self.document.find(node_id)
        ]

    def cut_selected(self):
        nodes = [
            self.document.find(node_id) for node_id in self.document.selected_ids
        ]
        cut_nodes = [node for node in nodes if node and node.node_type != "root"]
        if not cut_nodes:
            return
        parent_ids = {node.parent.node_id for node in cut_nodes if node.parent}
        self.copy_selected()
        self.delete_selected()
        if len(parent_ids) == 1:
            parent_id = next(iter(parent_ids))
            if self.document.find(parent_id):
                self.document.set_selection([parent_id])

    def paste(self):
        scene = self.current_scene()
        if not scene or not self._clipboard:
            return
        added = []
        self.undo_stack.beginMacro("Paste items")
        try:
            for original in self._clipboard:
                node = original.clone()
                if node.node_type == "tab":
                    selected = [
                        self.document.find(node_id)
                        for node_id in self.document.selected_ids
                    ]
                    target = next(
                        (candidate for candidate in selected
                         if candidate and candidate.node_type == "tab_widget"), None)
                    if target is None:
                        page = next(
                            (candidate for candidate in selected
                             if candidate and candidate.node_type == "tab" and
                             candidate.parent and
                             candidate.parent.node_type == "tab_widget"), None)
                        target = page.parent if page else None
                    if target is None:
                        target = next(
                            (candidate for candidate in self.document.root.walk()
                             if candidate.node_type == "tab_widget"), None)
                    parent_id = target.node_id if target else ""
                else:
                    parent = self._paste_parent()
                    parent_id = parent.node_id if parent else ""
                    mode = DesignScene._node_layout_mode(parent)
                    if mode == "canvas":
                        bounds = list(node.properties.get("bounds") or [0, 0, 180, 44])
                        bounds[0] += scene.snap_spacing
                        bounds[1] += scene.snap_spacing
                        node.properties["bounds"] = bounds
                    else:
                        pos = list(node.properties.get("pos") or [0, 0, 1, 1])
                        pos += [1] * (4 - len(pos))
                        pos[0] += 1
                        pos[1] += 1
                        node.properties["pos"] = pos
                parent = self.document.find(parent_id)
                if parent and self.document.can_parent(parent.node_type, node.node_type):
                    self.undo_stack.push(PasteCommand(self.document, parent_id, node, text="Paste item"))
                    added.append(node.node_id)
        finally:
            self.undo_stack.endMacro()
        self.document.set_selection(added)

    def _paste_parent(self):
        selected = [
            self.document.find(node_id) for node_id in self.document.selected_ids
        ]
        selected = [node for node in selected if node]
        if len(selected) == 1:
            node = selected[0]
            if node.node_type in {"root", "tab", "group"}:
                return node
            if node.node_type == "tab_widget":
                return DesignScene.active_page(node)
            if node.parent and node.parent.node_type != "tab_widget":
                return node.parent
        return self.document.root

    def duplicate_selected(self):
        self.copy_selected()
        self.paste()

    def add_tab(self):
        selected = [
            self.document.find(node_id) for node_id in self.document.selected_ids
        ]
        target = next(
            (node for node in selected if node and node.node_type == "tab_widget"),
            None)
        if target is None:
            target = next(
                (node for node in self.document.root.walk()
                 if node.node_type == "tab_widget"), None)
        if target is None:
            QtWidgets.QMessageBox.information(
                self, "Add Page", "Add or select a Tab Widget first.")
            return
        scene = self.current_scene()
        if scene:
            scene.add_tab_page(target.node_id)
            if target.children:
                self._focus_owning_tab(target.children[-1].node_id)

    def _designer_context_action(self, action, node_id):
        node = self.document.find(node_id)
        if node and node_id not in self.document.selected_ids:
            self.document.set_selection([node_id])
        if action == "cut":
            self.cut_selected()
        elif action == "copy":
            self.copy_selected()
        elif action == "paste":
            self.paste()
        elif action == "duplicate":
            self.duplicate_selected()
        elif action == "delete":
            self.delete_selected()
        elif action == "add_page" and node and node.node_type == "tab_widget":
            self.current_scene().add_tab_page(node.node_id)
        elif action in {"move_left", "move_right"} and node and node.node_type == "tab":
            index = node.parent.children.index(node)
            delta = -1 if action == "move_left" else 1
            self.current_scene().reorder_tab_page(node.node_id, index + delta)
        elif action == "bring_front":
            self.change_z_order(front=True)
        elif action == "send_back":
            self.change_z_order(front=False)

        elif action.startswith("align_selection_"):
            self.align_items(action.removeprefix("align_selection_"), "selection")
        elif action.startswith("align_parent_"):
            self.align_items(action.removeprefix("align_parent_"), "parent")
        elif action == "distribute_vertical":
            self.distribute_items("vertical")
        elif action == "distribute_horizontal":
            self.distribute_items("horizontal")

    @staticmethod
    def _node_rect(node, canvas):
        values = list(node.properties.get("bounds" if canvas else "pos") or [0, 0, 1, 1])
        values += [1] * (4 - len(values))
        if canvas:
            return values[0], values[1], values[2], values[3], values
        return values[1], values[0], values[3], values[2], values

    def _parent_extent(self, parent, canvas):
        if canvas:
            size = parent.get_property("layout.designSize")
            if not (isinstance(size, list) and len(size) == 2):
                bounds = parent.properties.get("bounds", [0, 0, 1200, 800])
                size = bounds[2:4]
            return max(1, int(size[0])), max(1, int(size[1]))
        rows, columns = self._container_grid(parent)
        return columns, rows

    def _push_rect(self, node, canvas, rect, text):
        x, y, width, height, original = rect
        updated = list(original)
        if canvas:
            updated[:4] = [round(x), round(y), width, height]
            command = BoundsCommand
        else:
            updated[:4] = [round(y), round(x), height, width]
            command = GeometryCommand
        if updated != original:
            self.undo_stack.push(command(
                self.document, node.node_id, updated, text))

    def align_items(self, direction, relative_to="selection"):
        nodes = self._compatible_arrange_nodes()
        if not nodes or (relative_to == "selection" and len(nodes) < 2):
            return
        canvas = DesignScene._node_layout_mode(nodes[0].parent) == "canvas"
        reference_rect = self._node_rect(nodes[0], canvas)
        parent_width, parent_height = self._parent_extent(nodes[0].parent, canvas)
        self.undo_stack.beginMacro(
            f"Align {direction} to {relative_to}")
        try:
            for node in nodes:
                x, y, width, height, original = self._node_rect(node, canvas)
                if relative_to == "parent":
                    ref_x, ref_y, ref_width, ref_height = 0, 0, parent_width, parent_height
                else:
                    ref_x, ref_y, ref_width, ref_height = reference_rect[:4]
                if direction == "left":
                    x = ref_x
                elif direction == "hcenter":
                    x = ref_x + (ref_width - width) / 2
                elif direction == "right":
                    x = ref_x + ref_width - width
                elif direction == "top":
                    y = ref_y
                elif direction == "vcenter":
                    y = ref_y + (ref_height - height) / 2
                elif direction == "bottom":
                    y = ref_y + ref_height - height
                else:
                    return
                self._push_rect(node, canvas, (x, y, width, height, original), "Align item")
        finally:
            self.undo_stack.endMacro()

    def distribute_items(self, orientation):
        nodes = self._compatible_arrange_nodes()
        if len(nodes) < 3 or orientation not in {"vertical", "horizontal"}:
            return
        canvas = DesignScene._node_layout_mode(nodes[0].parent) == "canvas"
        rects = [(node, self._node_rect(node, canvas)) for node in nodes]
        axis = 1 if orientation == "vertical" else 0
        size_axis = 3 if orientation == "vertical" else 2
        rects.sort(key=lambda pair: pair[1][axis])
        start = rects[0][1][axis]
        end = rects[-1][1][axis] + rects[-1][1][size_axis]
        total_size = sum(rect[size_axis] for _, rect in rects)
        gap = (end - start - total_size) / (len(rects) - 1)
        cursor = start
        self.undo_stack.beginMacro(
            "Distribute rows" if orientation == "vertical" else "Distribute columns")
        try:
            for index, (node, rect) in enumerate(rects):
                x, y, width, height, original = rect
                if index not in {0, len(rects) - 1}:
                    if orientation == "vertical":
                        y = cursor
                    else:
                        x = cursor
                    self._push_rect(
                        node, canvas, (x, y, width, height, original), "Distribute item")
                cursor += rect[size_axis] + gap
        finally:
            self.undo_stack.endMacro()

    # Compatibility entry points retained for integrations that used the old actions.
    def align_left(self):
        self.align_items("left", "selection")

    def distribute_rows(self):
        self.distribute_items("vertical")

    def distribute_columns(self):
        self.distribute_items("horizontal")

    def change_z_order(self, front=True):
        nodes = [self.document.find(node_id) for node_id in self.document.selected_ids]
        nodes = [node for node in nodes if node and node.parent]
        if not nodes:
            return
        if len({node.parent.node_id for node in nodes}) != 1:
            return
        siblings = nodes[0].parent.children
        values = [int(sibling.properties.get("zIndex", 0) or 0) for sibling in siblings]
        target = (max(values) + 1) if front else (min(values) - 1)
        self.undo_stack.beginMacro("Change z-order")
        try:
            for offset, node in enumerate(nodes):
                value = target + offset if front else target - offset
                self.undo_stack.push(PropertyCommand(
                    self.document, [node.node_id], "zIndex", value, "Change z-order"))
        finally:
            self.undo_stack.endMacro()

    def convert_current_to_canvas(self):
        scene = self.current_scene()
        container = self._active_layout_container()
        default = "canvas" if container and container.node_type == "root" else "grid"
        if not container or container.get_property("layout.mode", default) == "canvas":
            return
        rows, columns = self._container_grid(container)
        if container.node_type in {"root", "tab"}:
            design_size = [1200, 800]
        else:
            bounds = container.properties.get("bounds")
            design_size = (
                list(bounds[2:4])
                if isinstance(bounds, list) and len(bounds) == 4
                else [800, 600])
        cell_width = design_size[0] / max(1, columns)
        cell_height = design_size[1] / max(1, rows)
        with self.document.batch_notifications("property", container):
            self.undo_stack.beginMacro("Convert container to canvas")
            try:
                self.undo_stack.push(PropertyCommand(
                    self.document, [container.node_id], "layout.designSize", design_size))
                self.undo_stack.push(PropertyCommand(
                    self.document, [container.node_id], "layout.resizeMode", "anchors"))
                self.undo_stack.push(PropertyCommand(
                    self.document, [container.node_id], "layout.snap", 8))
                for child in container.children:
                    pos = list(child.properties.get("pos") or [0, 0, 1, 1])
                    pos += [1] * (4 - len(pos))
                    bounds = [
                        round(pos[1] * cell_width),
                        round(pos[0] * cell_height),
                        round(pos[3] * cell_width),
                        round(pos[2] * cell_height),
                    ]
                    self.undo_stack.push(BoundsCommand(
                        self.document, child.node_id, bounds, "Convert item bounds"))
                self.undo_stack.push(PropertyCommand(
                    self.document, [container.node_id], "layout.mode", "canvas"))
            finally:
                self.undo_stack.endMacro()
        self.statusBar().showMessage(
            "Converted to canvas. Original grid and widget positions were preserved.", 6000)

    def convert_current_to_grid(self):
        scene = self.current_scene()
        container = self._active_layout_container()
        default = "canvas" if container and container.node_type == "root" else "grid"
        if not container or container.get_property("layout.mode", default) != "canvas":
            return
        bounds = container.properties.get("bounds") if container.node_type == "group" else None
        design_size = (
            list(bounds[2:4])
            if isinstance(bounds, list) and len(bounds) == 4
            else container.get_property("layout.designSize", [1200, 800]))
        existing_grid = container.properties.get("grid")
        if isinstance(existing_grid, list) and len(existing_grid) == 2:
            rows, columns = existing_grid
        else:
            rows = max(1, round(design_size[1] / scene.cell_size))
            columns = max(1, round(design_size[0] / scene.cell_size))
        cell_width = design_size[0] / max(1, columns)
        cell_height = design_size[1] / max(1, rows)
        with self.document.batch_notifications("property", container):
            self.undo_stack.beginMacro("Convert container to grid")
            try:
                self.undo_stack.push(PropertyCommand(
                    self.document, [container.node_id], "grid", [rows, columns]))
                for child in container.children:
                    existing_pos = child.properties.get("pos")
                    if (isinstance(existing_pos, list) and len(existing_pos) in (2, 4) and
                            all(isinstance(value, int) for value in existing_pos)):
                        continue
                    bounds = list(child.properties.get("bounds") or [0, 0, scene.cell_size, scene.cell_size])
                    pos = [
                        max(0, round(bounds[1] / cell_height)),
                        max(0, round(bounds[0] / cell_width)),
                        max(1, round(bounds[3] / cell_height)),
                        max(1, round(bounds[2] / cell_width)),
                    ]
                    self.undo_stack.push(GeometryCommand(
                        self.document, child.node_id, pos, "Convert item position"))
                self.undo_stack.push(PropertyCommand(
                    self.document, [container.node_id], "layout.mode", "grid"))
            finally:
                self.undo_stack.endMacro()
        self.statusBar().showMessage(
            "Converted to grid. Canvas bounds remain stored for future restoration.", 6000)

    def _focus_issue(self, node_id):
        try:
            node = self.document.find(node_id)
            if node:
                self._focus_owning_tab(
                    node.parent.node_id
                    if node.parent and node.parent.node_type != "root"
                    else node.node_id)
                self.document.set_selection([node_id])
        except Exception as error:
            QtWidgets.QMessageBox.warning(
                self, "Validation issue could not be focused",
                "The related control could not be opened safely. The validation "
                f"issue remains available.\n\n{error}")

    def _open_callback(self, callback):
        if not callback:
            return
        opener = getattr(self._host, "_open_callback_in_vscode", None)
        if opener:
            opener(callback)
        else:
            QtWidgets.QMessageBox.information(
                self, "Callback", f"Open {self.callbacks_path} and navigate to {callback}().")

    def closeEvent(self, event):
        if self._closing_after_save:
            self._closing_after_save = False
            event.accept()
            return
        if self.document.is_dirty or self._callbacks_dirty:
            box = QtWidgets.QMessageBox(self)
            box.setWindowTitle("Unsaved designer changes")
            box.setText("The designer contains changes that have not been saved.")
            box.setInformativeText(
                "Save them, discard them, or cancel closing."
                + ("\nThe running UI will be restored if you discard the applied preview."
                   if self._applied_unsaved else ""))
            save = box.addButton("Save", QtWidgets.QMessageBox.AcceptRole)
            discard = box.addButton("Discard", QtWidgets.QMessageBox.DestructiveRole)
            cancel = box.addButton(QtWidgets.QMessageBox.Cancel)
            box.exec_()
            if box.clickedButton() is save:
                if not self.save_config():
                    event.ignore()
                    return
            elif box.clickedButton() is discard:
                if self._applied_unsaved:
                    self.restoreRequested.emit(copy.deepcopy(self.document.saved_snapshot))
                self.document.restore_saved()
                self._callback_source_override = None
                self._callback_edit_baseline = None
                self._applied_unsaved = False
            else:
                event.ignore()
                return
        event.accept()
