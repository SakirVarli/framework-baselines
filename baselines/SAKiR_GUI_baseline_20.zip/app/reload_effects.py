"""Scoped framework effects and explicit resource lifetimes during reload.

Arbitrary Python/network side effects are not transactional. Framework output,
subscriptions, and allocations made in this scope are staged until publication.
"""
from contextlib import contextmanager
from contextvars import ContextVar

from PyQt5 import QtCore, QtWidgets, sip


_effects = ContextVar("reload_effects", default=None)
_execution = ContextVar("callback_generation", default=None)


class StaleGenerationError(RuntimeError):
    pass


def current_effects():
    return _effects.get()


def track_resource(value):
    effects = current_effects()
    if effects is not None:
        effects.track(value)
    elif (token := execution_token()) is not None:
        check_execution(token)
        token[0]._track_resource(value)


def execution_token():
    return _execution.get()


def check_execution(token=None):
    token = token if token is not None else _execution.get()
    if token is not None:
        registry, generation = token
        if registry.generation != generation or registry.state != "READY":
            raise StaleGenerationError("Callback belongs to a retired runtime generation")


@contextmanager
def execution_scope(registry, generation):
    token = _execution.set((registry, generation))
    try:
        check_execution()
        yield
    finally:
        _execution.reset(token)


def qt_alive(value):
    return isinstance(value, QtCore.QObject) and not sip.isdeleted(value)


def borrowed(value):
    try:
        return bool(getattr(type(value), "__reload_borrowed__", False) or
                    (isinstance(value, QtCore.QObject) and
                     getattr(value, "__reload_borrowed__", False)))
    except RuntimeError:  # A deleted QObject can still have a Python wrapper.
        return False


def resource_widget(value):
    """Only use the explicit adapter; never evaluate an arbitrary .widget property."""
    if isinstance(value, QtWidgets.QWidget):
        return value if qt_alive(value) else None
    getter = getattr(type(value), "__reload_widget__", None)
    return getter(value) if getter is not None else None


def resource_disposer(value):
    if borrowed(value):
        return None
    method = getattr(type(value), "__reload_dispose__", None)
    if method is not None:
        return lambda item: method(item)
    if isinstance(value, QtCore.QObject):
        return dispose_qobject
    return None


def dispose_qobject(value):
    if not qt_alive(value):
        return
    if isinstance(value, QtWidgets.QWidget):
        value.hide()
        value.setParent(None)
    if isinstance(value, QtCore.QTimer):
        value.stop()
    value.deleteLater()


def retained_identities(values):
    identities = set()
    pending = list(values)
    while pending:
        value = pending.pop()
        if id(value) in identities:
            continue
        identities.add(id(value))
        if type(value) is dict:
            pending.extend(value.keys())
            pending.extend(value.values())
        elif type(value) in (list, tuple, set, frozenset):
            pending.extend(value)
        widget = resource_widget(value)
        if widget is not None:
            identities.add(id(widget))
    return identities


class ReloadEffects:
    def __init__(self):
        self.output = []
        self.resources = []
        self.subscriptions = []
        self.actions = []
        self.token = None
        self.closed = False

    @contextmanager
    def scope(self):
        token = _effects.set(self)
        previous_execution = _execution.set(None)
        try:
            yield self
        finally:
            _execution.reset(previous_execution)
            _effects.reset(token)

    def display(self, area, content, mode):
        if self.closed:
            raise StaleGenerationError("Reload attempt is no longer active")
        self.output.append((area, content, mode))

    def track(self, resource):
        if self.closed:
            raise StaleGenerationError("Reload attempt is no longer active")
        self.resources.append(resource)

    def prepare(self):
        for subscription in self.subscriptions:
            subscription._activate()

    def commit(self):
        # Called on the GUI thread, without event-loop reentry.
        self.closed = True
        warnings = []
        for area, content, mode in self.output:
            if qt_alive(area):
                try:
                    area._safe_display(content, mode)
                except Exception as error:
                    warnings.append(f"Output handover failed: {error}")
        self.output.clear()
        for widget, name, args, kwargs in self.actions:
            if qt_alive(widget):
                try:
                    widget._safe_action(name, args, kwargs)
                except Exception as error:
                    warnings.append(f"InfoWidget handover failed: {error}")
        self.actions.clear()
        return warnings

    def rollback(self):
        self.closed = True
        self.output.clear()
        self.actions.clear()

