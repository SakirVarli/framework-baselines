"""Process-local registry used by the callback-facing Globals API.

The registry protects its own mapping operations. It deliberately does not
claim to make mutable values, user resources, or Qt objects thread-safe.
"""

from __future__ import annotations

from contextlib import contextmanager
import copy
from threading import RLock, local
from typing import Any, Callable, Dict, Iterable, Iterator, Mapping
from app.reload_effects import check_execution, resource_disposer


class AppGlobalDefinitionError(RuntimeError):
    """Raised when a global declaration or name violates the public contract."""


RESERVED_GLOBAL_NAMES = frozenset(
    {
        "clear", "get", "items", "keys",
        "mutate", "pop", "setdefault", "snapshot",
        "update", "values", "init_globals", "definitions", "state",
        "generation", "error",
    }
)


def validate_global_name(name: str) -> str:
    """Validate a user-visible registry name and return it unchanged."""
    if not isinstance(name, str) or not name:
        raise AppGlobalDefinitionError("Global names must be non-empty strings.")
    if name.startswith("_"):
        raise AppGlobalDefinitionError(
            f"Global name {name!r} is reserved; names beginning with '_' are internal."
        )
    if name in RESERVED_GLOBAL_NAMES:
        raise AppGlobalDefinitionError(
            f"Global name {name!r} conflicts with the Globals mapping API. "
            "Choose a different name."
        )
    return name


_MISSING = object()


def _plain_state(value, seen=None):
    """Only copy built-in data; never invoke resource/user copy hooks."""
    if type(value) in (str, bytes, int, float, bool, complex, type(None)):
        return True
    if type(value) not in (list, dict, set, tuple, frozenset):
        return False
    seen = set() if seen is None else seen
    if id(value) in seen:
        return True
    seen.add(id(value))
    items = list(value.items()) if type(value) is dict else value
    return all(_plain_state(item, seen) for item in items)


def stage_values(values, specs=None):
    memo = {}
    def can_copy(name, value):
        spec = (specs or {}).get(name)
        return _plain_state(value) and (spec is None or
                (spec.kind == "plain" and spec.dispose is None))
    staged = {name: copy.deepcopy(value, memo) if can_copy(name, value) else value
              for name, value in values.items()}
    originals = {}
    def visit(value):
        if type(value) not in (list, dict, set, tuple, frozenset) or id(value) in originals:
            return
        originals[id(value)] = value
        items = list(value.items()) if type(value) is dict else value
        for item in items:
            visit(item)
    for name, value in values.items():
        if can_copy(name, value):
            visit(value)
    # Hold each clone strongly: IDs alone can be reused after a declaration is
    # removed/recreated and would then incorrectly alias an unrelated allocation.
    clones = {id(memo[key]): (memo[key], value)
              for key, value in originals.items() if key in memo}
    return staged, clones


def publish_plain_state(values, clones):
    """Reconcile staged built-in data while retaining preserved object identities."""
    resolved = {}
    def restore(value):
        if type(value) not in (list, dict, set, tuple, frozenset):
            return value
        entry = clones.get(id(value))
        original = entry[1] if entry is not None else value
        if id(value) in resolved:
            return resolved[id(value)]
        resolved[id(value)] = original
        if type(value) is list:
            original[:] = [restore(item) for item in value]
        elif type(value) is dict:
            incoming = [(restore(key), restore(item)) for key, item in value.items()]
            original.clear()
            original.update(incoming)
        elif type(value) is set:
            incoming = [restore(item) for item in value]
            original.clear()
            original.update(incoming)
        elif type(value) in (tuple, frozenset):
            incoming = [restore(item) for item in value]
            if entry is None:
                resolved[id(value)] = (value if all(item is old for item, old in zip(incoming, value))
                                       else type(value)(incoming))
                return resolved[id(value)]
        return original
    return {name: restore(value) for name, value in values.items()}


class GlobalRegistry:
    """Constructable, process-local registry with atomic mapping operations."""

    _INTERNAL_ATTRIBUTES = frozenset(
        {
            "_values", "_specs", "_owners", "_lock", "_local",
            "_state", "_generation", "_error", "_retired",
        }
    )

    def __init__(self) -> None:
        object.__setattr__(self, "_values", {})
        object.__setattr__(self, "_specs", {})
        object.__setattr__(self, "_owners", {})
        object.__setattr__(self, "_lock", RLock())
        object.__setattr__(self, "_local", local())
        object.__setattr__(self, "_state", "EMPTY")
        object.__setattr__(self, "_generation", 0)
        object.__setattr__(self, "_error", None)
        object.__setattr__(self, "_retired", [])

    def _remember_replaced(self, name, value):
        if getattr(self._local, "staging_values", None) is not None:
            return
        spec = self._specs.get(name)
        if resource_disposer(value) is not None or getattr(spec, "dispose", None) is not None:
            self._retired.append((name, value, spec))

    def _retired_snapshot(self):
        with self._lock:
            return list(self._retired)

    def _track_resource(self, value):
        with self._lock:
            self._retired.append(("callback resource", value, None))

    def _active_values(self) -> Dict[str, Any]:
        return getattr(self._local, "staging_values", self._values)

    @contextmanager
    def _staging_scope(self, values: Dict[str, Any], allocations=None):
        previous = getattr(self._local, "staging_values", _MISSING)
        previous_allocations = getattr(self._local, "allocations", None)
        self._local.staging_values = values
        self._local.allocations = allocations if allocations is not None else previous_allocations
        try:
            yield values
        finally:
            self._local.allocations = previous_allocations
            if previous is _MISSING:
                try:
                    del self._local.staging_values
                except AttributeError:
                    pass
            else:
                self._local.staging_values = previous

    def __getattr__(self, name: str) -> Any:
        with self._lock:
            values = self._active_values()
            if name in values:
                return values[name]
        raise AttributeError(f"Global {name!r} not found")

    def __setattr__(self, name: str, value: Any) -> None:
        if name in self._INTERNAL_ATTRIBUTES:
            object.__setattr__(self, name, value)
            return
        validate_global_name(name)
        check_execution()
        with self._lock:
            values = self._active_values()
            if name in values and values[name] is not value:
                self._remember_replaced(name, values[name])
            self._active_values()[name] = value
            allocations = getattr(self._local, "allocations", None)
            if allocations is not None:
                allocations.append((name, value))

    def __delattr__(self, name: str) -> None:
        if name in self._INTERNAL_ATTRIBUTES or name.startswith("_"):
            raise AppGlobalDefinitionError(f"Internal registry attribute {name!r} cannot be deleted.")
        self.__delitem__(name)

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            return self._active_values()[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.__setattr__(key, value)

    def __delitem__(self, key: str) -> None:
        validate_global_name(key)
        check_execution()
        with self._lock:
            values = self._active_values()
            if key not in values:
                raise KeyError(key)
            self._remember_replaced(key, values[key])
            del values[key]
            if values is self._values:
                self._owners.pop(key, None)

    def __contains__(self, key: object) -> bool:
        with self._lock:
            return key in self._active_values()

    def __len__(self) -> int:
        with self._lock:
            return len(self._active_values())

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def keys(self) -> list[str]:
        with self._lock:
            return list(self._active_values())

    def values(self) -> list[Any]:
        with self._lock:
            return list(self._active_values().values())

    def items(self) -> list[tuple[str, Any]]:
        with self._lock:
            return list(self._active_values().items())

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._active_values().get(key, default)

    def pop(self, key: str, default: Any = _MISSING) -> Any:
        validate_global_name(key)
        check_execution()
        with self._lock:
            values = self._active_values()
            if key in values:
                self._remember_replaced(key, values[key])
            if values is self._values:
                self._owners.pop(key, None)
            if default is _MISSING:
                return values.pop(key)
            return values.pop(key, default)

    def setdefault(self, key: str, default: Any = None) -> Any:
        validate_global_name(key)
        with self._lock:
            if key not in self._active_values():
                self.__setattr__(key, default)
            return self._active_values()[key]

    def update(self, new_data: Mapping[str, Any] | Iterable[tuple[str, Any]]) -> None:
        incoming = dict(new_data)
        for key in incoming:
            validate_global_name(key)
        with self._lock:
            for key, value in incoming.items():
                self.__setattr__(key, value)

    def clear(self) -> None:
        """Remove values while retaining declaration/runtime metadata."""
        check_execution()
        with self._lock:
            values = self._active_values()
            for name, value in values.items():
                self._remember_replaced(name, value)
            values.clear()
            if values is self._values:
                self._owners.clear()

    def snapshot(self) -> Dict[str, Any]:
        """Return a locked shallow copy of all current values."""
        with self._lock:
            return dict(self._active_values())

    def _spec_snapshot(self) -> Dict[str, Any]:
        """Return a locked shallow copy of current declaration specs."""
        with self._lock:
            return dict(self._specs)

    def mutate(self, key: str, operation: Callable[[Any], Any]) -> Any:
        """Atomically replace ``key`` with ``operation(current_value)``."""
        check_execution()
        validate_global_name(key)
        if not callable(operation):
            raise TypeError("operation must be callable")
        with self._lock:
            values = self._active_values()
            if key not in values:
                raise KeyError(key)
            value = operation(values[key])
            self.__setattr__(key, value)
            return value

    @property
    def state(self) -> str:
        with self._lock:
            return self._state

    @property
    def generation(self) -> int:
        with self._lock:
            return self._generation

    @property
    def error(self) -> Any:
        with self._lock:
            return self._error

    def _set_runtime_state(
        self, state: str, *, generation: int | None = None, error: Any = None
    ) -> None:
        with self._lock:
            self._state = str(state)
            if generation is not None:
                self._generation = int(generation)
            self._error = error

    def _commit_generation(
        self,
        *,
        specs: Mapping[str, Any],
        values: Mapping[str, Any],
        generation: int,
        owner: str = "callbacks",
    ) -> None:
        """Atomically replace the committed values/specifications for a generation."""
        for key in values:
            validate_global_name(key)
        with self._lock:
            self._values = dict(values)
            self._specs = dict(specs)
            self._owners = {
                key: owner for key in specs if key in self._values
            }
            self._generation = generation
            self._state = "INITIALIZING_RESOURCES"
            self._error = None
            self._retired = []

    def _owned_snapshot(self, owner: str = "callbacks") -> Dict[str, Any]:
        """Return values currently owned by one lifecycle owner."""
        with self._lock:
            return {
                key: self._values[key]
                for key, current_owner in self._owners.items()
                if current_owner == owner and key in self._values
            }

    def _restore_generation(
        self,
        *,
        values: Mapping[str, Any],
        specs: Mapping[str, Any],
        generation: int,
        state: str,
        error: Any = None,
        retired=(),
    ) -> None:
        """Restore a coordinator snapshot after a pre-commit failure."""
        with self._lock:
            self._values = dict(values)
            self._specs = dict(specs)
            self._owners = {
                key: "callbacks" for key in specs if key in self._values
            }
            self._generation = int(generation)
            self._state = str(state)
            self._error = error
            self._retired = list(retired)

    def __dir__(self) -> list[str]:
        return sorted(set(super().__dir__()) | set(self.keys()))

    def __repr__(self) -> str:
        with self._lock:
            keys = list(self._values)
            state = self._state
            generation = self._generation
        return f"<GlobalRegistry state={state} generation={generation} keys={keys}>"


AppGlobals = GlobalRegistry()


__all__ = [
    "AppGlobalDefinitionError", "AppGlobals", "GlobalRegistry",
    "RESERVED_GLOBAL_NAMES", "validate_global_name",
]
