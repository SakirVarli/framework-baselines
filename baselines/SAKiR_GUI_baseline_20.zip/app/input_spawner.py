import os, json, threading, ast
from PyQt5 import QtWidgets, QtGui, QtCore
from app.utils import HISTORY_PATH, load_json, save_json, PROJECT_ROOT

# Value parsing (safe-ish)

def _smart_parse(text: str):
    if text is None:
        return None
    s = text.strip()
    if s == '':
        return ''
    # Try int
    try:
        return int(s)
    except: pass
    # Try hex
    try:
        if s.startswith("0x"):
            return int(s, 16)
        else:
            pass
    except:
        pass
    # Try float
    try:
        return float(s)
    except: pass
    # Try literal (list, dict, tuple, bool, None, bytes via b"..")
    try:
        return eval(s)
    except: pass
    # Fallback string
    return s

class _InlineForm(QtWidgets.QWidget):
    def __init__(self, parent_button: QtWidgets.QPushButton, inputs_def: dict, helper, on_thread: bool):
        super().__init__(None)
        self.setWindowFlags(
            QtCore.Qt.Tool |
            QtCore.Qt.FramelessWindowHint |
            QtCore.Qt.WindowStaysOnTopHint
        )
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.parent_button = parent_button
        self._parent_window = self.parent_button.window()
        runtime = getattr(self._parent_window, "global_runtime", None)
        self._runtime_generation = runtime.registry.generation if runtime is not None else None
        self._parent_window.installEventFilter(self)
        self.inputs_def = inputs_def
        self.helper = helper
        self.on_thread = on_thread
        self.setObjectName('InlineForm')

        # --- Create bordered container (no title, tight margins) ---
        frame = QtWidgets.QGroupBox()
        frame.setTitle("")  # empty title = just border

        frame_layout = QtWidgets.QVBoxLayout(frame)
        frame_layout.setContentsMargins(6, 6, 6, 6)
        frame_layout.setSpacing(6)

        title_label = QtWidgets.QLabel("Input required...")
        title_label.setStyleSheet("font-weight: bold; color: #333; margin-bottom: 4px;")
        frame_layout.addWidget(title_label)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)

        scroll_content = QtWidgets.QWidget()
        scroll_content.setAutoFillBackground(True)

        pal = scroll_content.palette()
        pal.setColor(QtGui.QPalette.Window, QtGui.QColor("#fdfdfd"))
        scroll_content.setPalette(pal)
        inputs_layout = QtWidgets.QGridLayout(scroll_content)
        inputs_layout.setSpacing(6)

        scroll.setWidget(scroll_content)
        frame_layout.addWidget(scroll)

        frame.setStyleSheet("""
            QGroupBox {
                border: 1px solid #666;
                border-radius: 5px;
                margin-top: 0px;
                background-color: #fdfdfd;
            }
        """)

        # Outer layout — also tight
        self.layout = QtWidgets.QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)
        self.layout.addWidget(frame)

        self.fields = {}

        # load history
        hist = load_json(HISTORY_PATH)
        btn_key = parent_button.text()
        last = (hist.get('buttons') or {}).get(btn_key) or {}

        row = 1
        for key, meta in inputs_def.items():
            t = meta.get('type', str)
            use_hist = meta.get('use_historical', True)
            default = meta.get('default')
            placeholder = meta.get('placeholder', '')

            if use_hist and key in last:
                default = last[key]

                if t == 'file selector':
                    default = self.resolve_path_from_history(default)

            w = None
            if t in ('str', 'int', 'float'):
                w = QtWidgets.QLineEdit()
                if default is not None:
                    w.setText(str(default))
                w.setPlaceholderText(placeholder)
            elif t == 'dropdown':
                w = QtWidgets.QComboBox()
                for opt in meta.get('options', []):
                    w.addItem(str(opt))
                if default is not None:
                    idx = w.findText(str(default))
                    if idx >= 0:
                        w.setCurrentIndex(idx)
            elif t == 'radiobuttons':
                grp = QtWidgets.QWidget()
                hl = QtWidgets.QHBoxLayout(grp)
                hl.setContentsMargins(0,0,0,0)
                bg = QtWidgets.QButtonGroup(grp)
                for opt in meta.get('options', []):
                    rb = QtWidgets.QRadioButton(str(opt))
                    bg.addButton(rb)
                    hl.addWidget(rb)
                    if default == opt:
                        rb.setChecked(True)
                w = (grp, bg)
            elif t == 'checkbox':
                w = QtWidgets.QCheckBox()
                if bool(default):
                    w.setChecked(True)
            elif t == 'file selector':
                # meta: default, allowed file extensions (list) or 'only folder', allow_multiple (bool)
                container = QtWidgets.QWidget()
                hl = QtWidgets.QHBoxLayout(container)
                hl.setContentsMargins(0,0,0,0)

                le = QtWidgets.QLineEdit()
                if default:
                    le.setText(str(default))

                btn = QtWidgets.QPushButton("🔍")
                btn.setFixedWidth(20)

                def pick(le, meta, container):
                    # Keep accepting the historical misspelling so existing
                    # callback definitions continue to work.
                    exts = meta.get(
                        'allowed file extensions',
                        meta.get('allowed file extentions'),
                    )
                    allow_multiple = meta.get('allow_multiple', False)

                    # -------------------------------------------------
                    # Determine start directory from current line edit
                    # -------------------------------------------------
                    start_dir = le.text().strip()

                    # If value is stringified list -> extract first element
                    try:
                        parsed = ast.literal_eval(start_dir)
                        if isinstance(parsed, list) and parsed:
                            start_dir = parsed[0]
                    except Exception:
                        pass

                    # Normalize path
                    if start_dir:
                        start_dir = os.path.expanduser(start_dir)
                        start_dir = os.path.abspath(start_dir)

                        if os.path.isfile(start_dir):
                            start_dir = os.path.dirname(start_dir)
                        elif not os.path.isdir(start_dir):
                            start_dir = os.path.dirname(start_dir)

                    if not start_dir or not os.path.isdir(start_dir):
                        start_dir = ""

                    # =================================================
                    # ---------------- Folder Selection ---------------
                    # =================================================
                    if exts == 'only folder':

                        dlg = QtWidgets.QFileDialog(container, 'Select folder')
                        dlg.setOption(QtWidgets.QFileDialog.ShowDirsOnly, True)
                        dlg.setFileMode(QtWidgets.QFileDialog.Directory)
                        dlg.setDirectory(start_dir)

                        if allow_multiple:
                            dlg.setOption(QtWidgets.QFileDialog.DontUseNativeDialog, True)
                            dlg.setOption(QtWidgets.QFileDialog.ShowDirsOnly, True)
                            dlg.setFileMode(QtWidgets.QFileDialog.Directory)
                            dlg.setFilter(QtCore.QDir.AllDirs | QtCore.QDir.NoDotAndDotDot)
                            dlg.setDirectory(start_dir)

                            view = dlg.findChild(QtWidgets.QListView, 'listView')
                            if view:
                                view.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

                            tree = dlg.findChild(QtWidgets.QTreeView)
                            if tree:
                                tree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

                        if dlg.exec_():
                            paths = dlg.selectedFiles()
                            if not paths:
                                return

                            if allow_multiple and not len(paths) == 1:
                                le.setText(str(paths))
                            else:
                                le.setText(paths[0])

                    # =================================================
                    # ---------------- File Selection -----------------
                    # =================================================
                    else:

                        filt = 'All Files (*.*)'
                        if isinstance(exts, list) and exts:
                            patt = ' '.join('*' + e for e in exts)
                            filt = f"Allowed ({patt});;All Files (*.*)"

                        if allow_multiple:
                            paths, _ = QtWidgets.QFileDialog.getOpenFileNames(
                                container,
                                'Select files',
                                start_dir,
                                filter=filt
                            )
                            if not paths:
                                return

                            if not len(paths) == 1:
                                le.setText(str(paths))
                            else:
                                le.setText(paths[0])

                        else:
                            path, _ = QtWidgets.QFileDialog.getOpenFileName(
                                container,
                                'Select file',
                                start_dir,
                                filter=filt
                            )
                            if path:
                                le.setText(path)

                btn.clicked.connect(
                    lambda _, le=le, meta=meta, container=container: pick(le, meta, container)
                )

                hl.addWidget(le)
                hl.addWidget(btn)
                w = (container, le)

            else:
                le = QtWidgets.QLineEdit()
                if default is not None:
                    le.setText(str(default))
                le.setPlaceholderText(placeholder)
                w = le

            self.fields[key] = w
            lab = QtWidgets.QLabel(str(key))
            inputs_layout.addWidget(lab, row, 0)
            if isinstance(w, tuple):
                inputs_layout.addWidget(w[0], row, 1)
            else:
                inputs_layout.addWidget(w, row, 1)
            row += 1

        inputs_layout.setRowStretch(inputs_layout.rowCount(), 1)
        scroll.setMaximumHeight(scroll_content.sizeHint().height())
        scroll.setMinimumWidth(scroll_content.sizeHint().width() + 20)

        # Done/Cancel
        btns = QtWidgets.QWidget()
        hb = QtWidgets.QHBoxLayout(btns)
        hb.setContentsMargins(0,0,0,0)
        done = QtWidgets.QPushButton('Done')
        self._apply_button_colors(done, "#aaff7f")
        cancel = QtWidgets.QPushButton('Cancel')
        self._apply_button_colors(cancel, "#ffaa7f")
        hb.addWidget(done); hb.addWidget(cancel)
        frame_layout.addWidget(btns)

        done.clicked.connect(self._done)
        cancel.clicked.connect(self._cleanup)

        # --- Position popup directly under the button (with screen bounds protection) ---
        btn_rect = self.parent_button.rect()
        btn_pos = self.parent_button.mapToGlobal(btn_rect.bottomLeft())

        self.adjustSize()

        screen = QtWidgets.QApplication.primaryScreen().availableGeometry()

        x = btn_pos.x()
        y = btn_pos.y() + int(self.height()*0.01)

        # Prevent right overflow
        if x + self.width() > screen.right():
            x = screen.right() - self.width() - 10

        # Prevent bottom overflow
        if y + self.height() > screen.bottom():
            y = btn_pos.y() - self.height() - self.parent_button.height()

        # Prevent left overflow
        if x < screen.left():
            x = screen.left() + 10

        # Prevent top overflow
        if y < screen.top():
            y = screen.top() + 10

        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()

    def _done(self):
        runtime = getattr(self._parent_window, "global_runtime", None)
        if runtime is not None and (runtime.registry.generation != self._runtime_generation
                                    or runtime.registry.state != "READY"):
            self._cleanup()
            return
        values = {}
        history = {}
        for key, w in self.fields.items():
            val = None
            if isinstance(w, QtWidgets.QLineEdit):
                val = _smart_parse(w.text())
                hist_val = val
            elif isinstance(w, QtWidgets.QCheckBox):
                val = w.isChecked()
                hist_val = val
            elif isinstance(w, QtWidgets.QComboBox):
                val = _smart_parse(w.currentText())
                hist_val = val
            elif isinstance(w, tuple):
                # radio or file selectors
                widget0 = w[0]

                # Radiobuttons
                if hasattr(w[1], 'buttons'):
                    for rb in w[1].buttons():
                        if rb.isChecked():
                            val = _smart_parse(rb.text())
                            hist_val = val
                            break
                else:
                    val = _smart_parse(w[1].text())
                    hist_val = self._normalize_path_for_history(val)
            else:
                val = None
                hist_val = val
            values[key] = val
            history[key] = hist_val
            
        # Save to history
        hist = load_json(HISTORY_PATH)
        btn_key = self.parent_button.text()
        hist.setdefault('buttons', {}).setdefault(btn_key, {})
        hist['buttons'][btn_key].update(history)
        save_json(HISTORY_PATH, hist)

        # Call helper
        if self.on_thread:
            runtime = getattr(self._parent_window, "global_runtime", None)
            if runtime is not None:
                runtime.start_callback(self.helper, inp=values)
            else:
                t = threading.Thread(target=self.helper, kwargs={'inp': values}, daemon=True)
                t.start()
        else:
            self.helper(inp=values)
        self._cleanup()

    def _cleanup(self):
        self.hide()

        # ✅ Remove global event filter safely
        app = QtWidgets.QApplication.instance()
        if app:
            app.removeEventFilter(self)

        if hasattr(self.parent_button, "_active_input_popup"):
            self.parent_button._active_input_popup = None

        self.deleteLater()

    def _apply_button_colors(self, widget, bg=None, fg=None):
        """
        Apply widget-aware colors without breaking native styles.

        QPushButton:
            - Always uses a Windows-like minimal stylesheet
            - Auto-detects text color (white or black) for contrast
        Other widgets:
            - Uses QPalette for background/foreground (keeps native look)
        """

        pal = widget.palette()

        # ------------------ BUTTONS ------------------
        if isinstance(widget, QtWidgets.QPushButton):
            base_color = QtGui.QColor(bg) if bg else QtGui.QColor("#FFFFFF")

            # Auto text color
            if not fg:
                brightness = (0.299 * base_color.red() + 0.587 * base_color.green() + 0.114 * base_color.blue())
                fg = "#000000" if brightness > 160 else "#FFFFFF"

            lighter = base_color.lighter(150).name()   # top shade
            darker = base_color.darker(110).name()     # bottom shade
            border = base_color.darker(140).name()

            widget.setStyleSheet(f"""
                QPushButton {{
                    background-color: qlineargradient(
                        x1:0, y1:0, x2:0, y2:1,
                        stop:0 {lighter}, stop:1 {darker}
                    );
                    color: {fg};
                    border: 1px solid {border};
                    border-radius: 4px;
                    padding: 4px 8px;
                }}
                QPushButton:hover {{
                    background-color: qlineargradient(
                        x1:0, y1:0, x2:0, y2:1,
                        stop:0 {base_color.lighter(130).name()},
                        stop:1 {base_color.lighter(110).name()}
                    );
                }}
                QPushButton:pressed {{
                    background-color: qlineargradient(
                        x1:0, y1:0, x2:0, y2:1,
                        stop:0 {base_color.darker(115).name()},
                        stop:1 {base_color.darker(130).name()}
                    );
                }}
                QPushButton:disabled {{
                    background-color: #CCCCCC;
                    color: #777777;
                    border: 1px solid #AAAAAA;
                }}
            """)
            return
    
    def _normalize_path_for_history(self, value):
        """
        Convert path(s) to relative if inside PROJECT_ROOT.
        Keep absolute if outside.
        Supports string or list of strings.
        """
        if not value:
            return value

        def convert_single(p):
            try:
                abs_p = os.path.abspath(p)
                root = os.path.abspath(PROJECT_ROOT)

                # Check if inside project root
                if os.path.commonpath([abs_p, root]) == root:
                    return os.path.relpath(abs_p, root)
                else:
                    return abs_p
            except Exception:
                return p  # fallback safe

        if isinstance(value, list):
            return [convert_single(p) for p in value]

        if isinstance(value, str):
            return convert_single(value)

        return value

    def resolve_path_from_history(self, p):
        if not p:
            return p

        if isinstance(p, list):
            return [self.resolve_path_from_history(x) for x in p]

        if not os.path.isabs(p):
            return os.path.abspath(os.path.join(PROJECT_ROOT, p))

        return p

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self._cleanup()
        else:
            super().keyPressEvent(event)
    
    def focusOutEvent(self, event):
        # Close if focus goes outside this form
        if not self.isActiveWindow():
            self._cleanup()
        super().focusOutEvent(event)
    
    def eventFilter(self, obj, event):
        # def get_event_name(event):
        #     etype = int(event.type())
        #     for attr in dir(QtCore.QEvent):
        #         if attr[0].isupper():
        #             try:
        #                 if getattr(QtCore.QEvent, attr) == etype:
        #                     return attr
        #             except Exception:
        #                 pass
        #     return f"Unknown({etype})"

        # print("EVENT:", int(event.type()), get_event_name(event))
        if not self.isVisible():
            return super().eventFilter(obj, event)

        # ✅ 1. Close on OUTSIDE mouse click
        if event.type() == QtCore.QEvent.MouseButtonPress:
            if isinstance(event, QtGui.QMouseEvent):
                if not self.geometry().contains(event.globalPos()):
                    self._cleanup()
                    return True

        # ✅ 4. Close if parent moves/resizes (layout safety)
        if obj == self._parent_window and event.type() in (QtCore.QEvent.Move, QtCore.QEvent.Resize):
            self._cleanup()
            return False

        return super().eventFilter(obj, event)

def spawn_input(parent_button: QtWidgets.QPushButton, helper, input_widgets: dict, helper_on_thread: bool=True):
    """Create floating input popup and call helper with collected dict."""

    # ✅ Destroy old popup if it already exists for this button
    old = getattr(parent_button, "_active_input_popup", None)
    if old:
        old.close()
        old.deleteLater()

    # ✅ Create and STORE new popup (THIS prevents garbage collection)
    popup = _InlineForm(parent_button, input_widgets, helper, helper_on_thread)
    parent_button._active_input_popup = popup
