# Binary messages

`app.binary_messages` combines normal Python dataclasses with declarative
Construct schemas. Construct owns the binary layout; message classes own typed
state, validation, custom methods, properties, and runtime-only attributes.

## Define a message

```python
from dataclasses import dataclass
from typing import ClassVar

from construct import Bytes, Int8ub, Int16ul, Rebuild, Struct, len_, this

from app.binary_messages import BinaryMessage, runtime_field


@dataclass(slots=True)
class DataMessage(BinaryMessage):
    version: int
    payload: bytes
    source: str | None = runtime_field(default=None)

    WIRE_SCHEMA: ClassVar = Struct(
        "version" / Int8ub,
        "payload_length" / Rebuild(Int16ul, len_(this.payload)),
        "payload" / Bytes(this.payload_length),
    )

    def validate(self) -> None:
        if self.version != 1:
            raise ValueError("Unsupported version")
```

```python
message = DataMessage(version=1, payload=b"hello")
encoded = message.to_bytes()
decoded = DataMessage.from_bytes(encoded)
```

Nested dataclasses, enums, lists, tuples, sets, optional values, and renamed
wire fields are converted automatically. Override `from_wire()` or `to_wire()`
when a protocol needs a transformation that annotations cannot express.

## Reusable enum schemas

Message Designer enum definitions generate Construct schemas directly:

```python
from construct import Enum, Int16sl, Struct

StatusWire = Enum(Int16sl, OK=0, ERROR=-1)
schema = Struct("status" / StatusWire)

schema.build({"status": StatusWire.ERROR})  # b'\xff\xff'
schema.build({"status": "ERROR"})         # same bytes
```

Select signed or unsigned 8/16/24/32/64-bit storage and byte order on the enum
definition. Fields inherit that format. Known decoded values are Construct labels;
use `int(value)` for numeric comparisons. Unknown in-range numbers can be rebuilt.
Message wire mappings and JSON exports normalize Construct enum values to numbers.
Aliases decode to the first listed member.

Legacy designer libraries migrate in memory and regenerate when saved. If an enum
was used with multiple storage formats, migration creates separate definitions to
preserve those bytes. Generated Python `IntEnum` classes are replaced: review
`.value`, `.name`, class calls, iteration, type checks, and comparisons with integers
in custom code. The runtime continues supporting hand-written Python enum classes.

## Runtime-only and renamed fields

Use `runtime_field()` for application state that must never be encoded. Use
`wire_field(name="wireName")` when the Python attribute and Construct field have
different names.

## Streams and files

`read_from()` and `write_to()` operate at the current position of an open
binary stream. `read_file()` and `write_file()` provide path-based helpers.
`decode()` rejects trailing data by default; pass `allow_trailing=True` only
when the caller intentionally owns framing.

## Decode output and hooks

`MessageClass.decode()` (and its `from_bytes()` alias), registry `decode()`, and
library/group `decode_auto()` accept keyword-only `return_mode` and `after_decode`:

```python
message = Packet.decode(data)  # Existing object behavior.
fields = Packet.decode(data, return_mode="dict")
fields = library.decode_auto(data, direction="RX", return_mode="dict", after_decode="dict")
```

`return_mode` is `"object"` (default) or `"dict"`. The hook selector `after_decode`
is `"object"`, `"dict"`, `"none"`, or `None` (default). `None` follows the requested
return mode; hook implementations are never inspected to select a path.

| Return mode | Hook selector | Result |
|---|---|---|
| object | omitted / object | Construct and validate the object, then call its `after_decode()` |
| object | none | Construct and validate the object, skipping its after-decode hook |
| object | dict | Invalid; raises `ValueError` |
| dict | omitted / dict | Parse the wire schema directly, normalize values, call `after_decode_dict()` |
| dict | none | Parse the wire schema directly and normalize values without a hook |
| dict | object | Normal object decoding and hook, then export `to_dict()` |

Dictionary mode adds `Name`, using `MESSAGE_NAME` or the class name. This key is
reserved: a wire/export field named `Name` raises `MessageDecodeError`. Nested
Construct containers become fresh dictionaries/lists, Construct enums become
numbers, and bytes remain bytes. Only Construct's internal `_io` entry is removed;
other underscore-prefixed schema fields remain. Wire-only counts, computed fields,
and checksums may appear even when the object's `to_dict()` omits them.

The direct dictionary path does not construct framework message/dataclass objects,
run `from_wire()`, initialize model fields, call object `validate()`, or call the
object `after_decode()`. Wire-schema checks, expressions, and custom Construct
adapters still run. Advanced/custom schema adapters can return their own types.
Binary decode errors and the usual trailing-byte rejection remain enforced.

Override the dictionary hook in a behavior mixin or message class:

```python
class PacketBehavior:
    @classmethod
    def after_decode_dict(cls, data):
        data["temperature_c"] = data["raw_temperature"] / 100
```

This hook runs after normalization and adding `Name`. Mutate the dictionary in
place, return `None`, and preserve `Name`. Its default implementation does nothing.
Only the selected hook runs. Hook errors raise `MessageDecodeError`; there is no
automatic fallback to another hook or decoding path.

Choosing `after_decode="object"` with dictionary output deliberately pays the
normal construction, initialization, and validation costs, including custom
object behavior. Its `to_dict()` export excludes runtime-only attributes by
default. File/stream readers, JSON readers, encoding, sending, and `codec()`
retain their existing object APIs. JSON dictionaries containing bytes can use
the `app.binary_messages.json_codec` helpers.

## Message registries

`MessageRegistry` indexes `BinaryMessage` subclasses by their composite
`(MESSAGE_ID, DIRECTION)` identity and logical `MESSAGE_NAME`. TX and RX classes may
share an ID; an `ANY` class remains compatible with ID-only protocols. ID-only
lookup works when one class owns the ID and raises `AmbiguousMessageIdError`
when both directions exist. Pass `direction="TX"` or `direction="RX"` to explicit or
automatic decoding in that case. It provides explicit dispatch and,
when configured with `FixedIdExtractor`, automatic extraction from a shared
fixed header using offset, width, byte order, mask, and shift settings. Unknown
identities and missing extractor configuration raise dedicated exceptions.

A message declared `ANY` supports both sending and receiving. A `TX` filter
matches `TX` or `ANY` messages; an `RX` filter matches `RX` or `ANY` messages.
Communication Hub's `Direction.TX` / `Direction.RX` enum members are accepted
directly as `direction`; converting them with `.value` is optional. Direction
enums are normalized by their value, and invalid values remain errors.
Passing `direction="ANY"` or omitting direction applies no direction filter.
If multiple messages match, decoding stops with an ambiguity exception instead
of choosing a message. The Hex Sandbox presents routing ambiguity as a warning.

## JSON

`to_json()`, `from_json()`, `write_json()`, and `read_json()` use an explicit
tag for bytes and non-finite floats. Ordinary strings such as `"dead"` remain
strings instead of being guessed to be hexadecimal bytes. Runtime-only fields
are excluded.

See `examples/binary_messages_demo.py` for signed and unsigned integers, bits,
an enum, a dynamic array of nested dataclasses, raw bytes, validation, and a
custom property in one message.

Run it from the repository root with:

```powershell
python -m examples.binary_messages_demo
```
