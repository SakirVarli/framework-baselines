from __future__ import annotations

from dataclasses import is_dataclass
from functools import cache
from io import BytesIO
from pathlib import Path
from typing import Any, BinaryIO, ClassVar, Literal, Mapping, Self, overload

from construct import Adapter, Construct

from .conversion import dataclass_from_mapping, dataclass_to_mapping
from .decoding import AfterDecodeMode, ReturnMode, decode_hook_mode, decoded_dictionary
from .errors import (
    MessageDecodeError,
    MessageDefinitionError,
    MessageEncodeError,
    MessageJsonError,
    MessageSendError,
)
from .json_codec import dump_file, dumps, load_file, loads
from .identity import Direction
from .sending import MessageSendSession


class _MessageAdapter(Adapter):
    def __init__(self, subcon: Construct, message_type: type[BinaryMessage]):
        super().__init__(subcon)
        self.message_type = message_type

    def _decode(self, obj, context, path):
        message = self.message_type.from_wire(obj)
        message.validate()
        message.after_decode()
        return message

    def _encode(self, obj, context, path):
        if not isinstance(obj, self.message_type):
            raise TypeError(
                f"Expected {self.message_type.__name__}, got {type(obj).__name__}"
            )
        obj.before_encode()
        obj.validate()
        if type(obj).to_wire is BinaryMessage.to_wire:
            # Keep labels required by Const/context expressions during encoding.
            # Public mappings and JSON still export numeric values.
            return dataclass_to_mapping(obj, preserve_construct_enums=True)
        return obj.to_wire()


class BinaryMessage:
    """Dataclass base for a typed object backed by a Construct schema."""

    WIRE_SCHEMA: ClassVar[Construct]
    MESSAGE_ID: ClassVar[int | None] = None
    MESSAGE_NAME: ClassVar[str | None] = None
    DIRECTION: ClassVar[Direction] = Direction.ANY
    TX_RX: ClassVar[Direction] = Direction.ANY  # Legacy generated-library alias.

    @classmethod
    @cache
    def codec(cls) -> Construct:
        cls._check_definition()
        return _MessageAdapter(cls.WIRE_SCHEMA, cls)

    @classmethod
    @overload
    def decode(
        cls, data: bytes | bytearray | memoryview, *, return_mode: Literal["object"] = "object",
        after_decode: AfterDecodeMode | None = None, allow_trailing: bool = False, **context: Any,
    ) -> Self: ...

    @classmethod
    @overload
    def decode(
        cls, data: bytes | bytearray | memoryview, *, return_mode: Literal["dict"],
        after_decode: AfterDecodeMode | None = None, allow_trailing: bool = False, **context: Any,
    ) -> dict[str, Any]: ...

    @classmethod
    @overload
    def decode(
        cls, data: bytes | bytearray | memoryview, *, return_mode: ReturnMode,
        after_decode: AfterDecodeMode | None = None, allow_trailing: bool = False, **context: Any,
    ) -> Self | dict[str, Any]: ...

    @classmethod
    def decode(
        cls,
        data: bytes | bytearray | memoryview,
        *,
        return_mode: ReturnMode = "object",
        after_decode: AfterDecodeMode | None = None,
        allow_trailing: bool = False,
        **context: Any,
    ) -> Self | dict[str, Any]:
        """Decode an object or wire dictionary, selecting hooks explicitly.

        An omitted after_decode follows return_mode. Dictionary mode skips model
        construction and model validation unless after_decode='object' is chosen.
        """
        hook = decode_hook_mode(return_mode, after_decode)
        stream = BytesIO(data)
        if return_mode == "object" and hook == "object":
            # Preserve the existing stream-reader/codec path and overrides.
            message = cls.read_from(stream, **context)
        else:
            cls._check_definition()
            start = _stream_position(stream)
            try:
                if hook == "object":
                    message = cls.read_from(stream, **context).to_dict()
                else:
                    message = cls.WIRE_SCHEMA.parse_stream(stream, **context)
                    if return_mode == "object":
                        message = cls.from_wire(message)
                        message.validate()
                if return_mode == "dict":
                    name = cls.MESSAGE_NAME or cls.__name__
                    message = decoded_dictionary(message, name)
                    if hook == "dict":
                        returned = cls.after_decode_dict(message)
                        if returned is not None:
                            raise TypeError("after_decode_dict must mutate the dictionary in place and return None")
                        if message.get("Name") != name:
                            raise ValueError("after_decode_dict must preserve reserved 'Name' metadata")
            except MessageDecodeError:
                raise
            except Exception as error:
                raise MessageDecodeError(
                    f"Could not decode {cls.__name__} at byte {start}: {error}"
                ) from error
        if not allow_trailing:
            trailing = stream.read(1)
            if trailing:
                raise MessageDecodeError(
                    f"{cls.__name__}: trailing data begins at byte {stream.tell() - 1}"
                )
        return message

    from_bytes = decode

    @classmethod
    def read_from(cls, stream: BinaryIO, **context: Any) -> Self:
        cls._check_definition()
        start = _stream_position(stream)
        try:
            return cls.codec().parse_stream(stream, **context)
        except MessageDecodeError:
            raise
        except Exception as error:
            raise MessageDecodeError(
                f"Could not decode {cls.__name__} at byte {start}: {error}"
            ) from error

    @classmethod
    def read_file(cls, path: str | Path, **context: Any) -> Self:
        with Path(path).open("rb") as stream:
            message = cls.read_from(stream, **context)
            if stream.read(1):
                raise MessageDecodeError(
                    f"{cls.__name__}: trailing data in {Path(path)!s}"
                )
            return message

    def encode(self, **context: Any) -> bytes:
        stream = BytesIO()
        self.write_to(stream, **context)
        return stream.getvalue()

    to_bytes = encode

    def send(
        self,
        session: MessageSendSession,
        *,
        target: str = "",
        encode_context: Mapping[str, Any] | None = None,
    ) -> Any:
        """Encode this message and synchronously send it through a running session."""
        if session is None or not isinstance(session, MessageSendSession):
            raise MessageSendError(
                "A compatible Communication Hub session must be supplied"
            )
        try:
            running = session.running
        except Exception as error:
            raise MessageSendError(
                "Could not determine whether the Communication Hub session is running"
            ) from error
        if not isinstance(running, bool):
            raise MessageSendError(
                "The Communication Hub session 'running' property must be a boolean"
            )
        if not running:
            raise MessageSendError(
                "The Communication Hub session is not running; start it explicitly before sending"
            )

        data = self.encode(**({} if encode_context is None else encode_context))
        try:
            return session.send(data, target=target)
        except Exception as error:
            raise MessageSendError(
                f"Could not send {type(self).__name__} through the Communication Hub session: {error}"
            ) from error

    def write_to(self, stream: BinaryIO, **context: Any) -> None:
        type(self)._check_definition()
        start = _stream_position(stream)
        try:
            type(self).codec().build_stream(self, stream, **context)
        except MessageEncodeError:
            raise
        except Exception as error:
            raise MessageEncodeError(
                f"Could not encode {type(self).__name__} at byte {start}: {error}"
            ) from error

    def write_file(self, path: str | Path, **context: Any) -> None:
        with Path(path).open("wb") as stream:
            self.write_to(stream, **context)

    @classmethod
    def from_wire(cls, wire_value: Mapping[str, Any]) -> Self:
        cls._check_definition()
        return dataclass_from_mapping(cls, wire_value)

    def to_wire(self) -> dict[str, Any]:
        type(self)._check_definition()
        return dataclass_to_mapping(self)

    def to_dict(self, *, include_runtime: bool = False) -> dict[str, Any]:
        type(self)._check_definition()
        return dataclass_to_mapping(self, include_runtime=include_runtime)

    def to_json(self, *, indent: int | None = 2) -> str:
        return dumps(self.to_wire(), indent=indent)

    @classmethod
    def from_json(cls, text: str) -> Self:
        value = loads(text)
        if not isinstance(value, Mapping):
            raise MessageJsonError(
                f"Expected a JSON object for {cls.__name__}, got {type(value).__name__}"
            )
        message = cls.from_wire(value)
        message.validate()
        return message

    def write_json(self, path: str | Path, *, indent: int | None = 2) -> None:
        dump_file(self.to_wire(), path, indent=indent)

    @classmethod
    def read_json(cls, path: str | Path) -> Self:
        value = load_file(path)
        if not isinstance(value, Mapping):
            raise MessageJsonError(
                f"Expected a JSON object for {cls.__name__}, got {type(value).__name__}"
            )
        message = cls.from_wire(value)
        message.validate()
        return message

    def validate(self) -> None:
        """Override to enforce semantic rules beyond the Construct schema."""

    def after_decode(self) -> None:
        """Override to initialize runtime-only state after binary decoding."""

    @classmethod
    def after_decode_dict(cls, data: dict[str, Any]) -> None:
        """Override to mutate dictionary output after schema decoding; preserve Name."""

    def before_encode(self) -> None:
        """Override to refresh derived state immediately before binary encoding."""

    @classmethod
    def _check_definition(cls) -> None:
        if not is_dataclass(cls):
            raise MessageDefinitionError(
                f"{cls.__name__} must be decorated with @dataclass"
            )
        schema = getattr(cls, "WIRE_SCHEMA", None)
        if not isinstance(schema, Construct):
            raise MessageDefinitionError(
                f"{cls.__name__}.WIRE_SCHEMA must be a Construct instance"
            )


def _stream_position(stream: BinaryIO) -> int | str:
    try:
        return stream.tell()
    except (AttributeError, OSError):
        return "unknown"
