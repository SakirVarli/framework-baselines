"""Strict bytes and text codecs with explicit byte boundaries and limits."""
from __future__ import annotations

from io import BytesIO

from construct import Construct, EnumIntegerString, PaddedString, RangeError, SizeofError, StringError, evaluate
from construct.core import encodingunit, stream_read, stream_write


def encoded_data(value, encoding=None):
    if encoding is not None:
        if not isinstance(value, str):
            raise ValueError('expected text')
        # Match Construct StringEncoded's empty-value behavior, including UTF-16.
        return value.encode(encoding) if value else b''
    if not isinstance(value, bytes):
        raise ValueError('expected bytes')
    return value


def data_length(value, encoding=None):
    return len(encoded_data(value, encoding))


def source_byte_length(context, path):
    """Resolve text encoding from the actual source schema at this occurrence."""
    while path.startswith('_.'):
        context = context._; path = path[2:]
    parts = path.split('.')
    schemas = context.get('_subcons', {})
    schema = None
    for index, key in enumerate(parts):
        schema = schemas.get(key) if schemas else None
        value = context[key]
        if index < len(parts) - 1:
            while schema is not None and not hasattr(schema, '_subcons') and hasattr(schema, 'subcon'):
                schema = schema.subcon
            schemas = getattr(schema, '_subcons', {})
            context = value
            schemas = schemas or context.get('_subcons', {}) if isinstance(context, dict) else schemas
    encoding = None
    if isinstance(value, str):
        encoding = context.get('_designer_encodings', {}).get(parts[-1])
        while schema is not None:
            if getattr(schema, 'encoding', None) is not None:
                encoding = schema.encoding
                break
            schema = getattr(schema, 'subcon', None)
        if encoding is None:
            raise ValueError(f'{path}: encoded text size needs a source encoding; use an explicit advanced expression')
    return data_length(value, encoding)


class DataCodec(Construct):
    """Lengths and limits are payload bytes, excluding prefixes/terminators.

    Fixed padded strings include padding in their payload boundary. Counted
    strings require an exact encoded size. Null terminators are encoding units.
    """

    def __init__(self, *, mode, length=None, prefix=None, encoding=None, minimum=0, maximum=None):
        super().__init__()
        if mode not in {'fixed', 'count_field', 'count_expression', 'prefixed', 'pascal', 'greedy', 'null_terminated'}:
            raise ValueError(f'unsupported data mode: {mode}')
        if type(minimum) is not int or minimum < 0 or maximum is not None and (type(maximum) is not int or maximum < minimum):
            raise ValueError('invalid payload byte limits')
        self.mode, self.length, self.prefix, self.encoding = mode, length, prefix, encoding
        self.minimum, self.maximum = minimum, maximum
        self.unit = encodingunit(encoding) if encoding is not None and mode in {'fixed', 'null_terminated'} else b'\0'

    def _size(self, size, path):
        if isinstance(size, EnumIntegerString):
            size = int(size)
        if type(size) is not int or size < 0:
            raise RangeError(f'payload byte length must be a nonnegative integer, found {size!r}', path=path)
        if size < self.minimum or self.maximum is not None and size > self.maximum:
            raise RangeError(f'payload size {size} is outside byte limits {self.minimum}..{self.maximum}', path=path)
        return size

    def _parse(self, stream, context, path):
        mode = self.mode
        if mode in {'fixed', 'count_field', 'count_expression', 'prefixed', 'pascal'}:
            length = (self.prefix._parsereport(stream, context, path) if mode in {'prefixed', 'pascal'}
                      else evaluate(self.length, context))
            length = self._size(length, path)
            # Large unsigned/VarInt prefixes must not overflow the stream's read
            # API, even when an intentionally unbounded schema has no maximum.
            if length <= 65536:
                data = stream_read(stream, length, path)
            else:
                payload = bytearray()
                while len(payload) < length:
                    payload.extend(stream_read(stream, min(65536, length - len(payload)), path))
                data = bytes(payload)
        elif mode == 'null_terminated':
            payload = bytearray()
            while True:
                chunk = stream_read(stream, len(self.unit), path)
                if chunk == self.unit:
                    break
                if self.maximum is not None and len(payload) + len(chunk) > self.maximum:
                    raise RangeError(f'payload exceeds maximum {self.maximum} bytes', path=path)
                payload.extend(chunk)
            data = bytes(payload)
            self._size(len(data), path)
        else:
            data = stream.read() if self.maximum is None else stream.read(self.maximum + 1)
            self._size(len(data), path)
        if self.encoding is None:
            return data
        try:
            if mode == 'fixed':
                return PaddedString(len(data), self.encoding)._parsereport(BytesIO(data), context, path)
            return data.decode(self.encoding)
        except (UnicodeError, LookupError) as error:
            raise StringError(f'cannot decode using {self.encoding}: {error}', path=path) from error

    def _build(self, obj, stream, context, path):
        try:
            data = encoded_data(obj, self.encoding)
        except (ValueError, TypeError, LookupError, UnicodeError) as error:
            raise StringError(str(error), path=path) from error
        mode = self.mode
        if mode in {'fixed', 'count_field', 'count_expression'}:
            length = self._size(evaluate(self.length, context), path)
            if mode == 'fixed' and self.encoding is not None:
                if len(data) > length:
                    raise RangeError(f'text encodes to {len(data)} bytes, fixed capacity is {length}', path=path)
                if data and data.endswith(self.unit):
                    raise StringError('text ends with null padding that would be removed on decode', path=path)
                if length % len(self.unit):
                    raise RangeError('fixed text boundary splits an encoding unit', path=path)
                data += bytes(length - len(data))
            elif len(data) != length:
                raise RangeError(f'expected {length} payload bytes, found {len(data)}', path=path)
        self._size(len(data), path)
        if mode == 'null_terminated':
            if any(data[index:index + len(self.unit)] == self.unit for index in range(0, len(data), len(self.unit))):
                raise StringError('payload contains an embedded null terminator', path=path)
        if mode in {'prefixed', 'pascal'}:
            self.prefix._build(len(data), stream, context, path)
        stream_write(stream, data, len(data), path)
        if mode == 'null_terminated':
            stream_write(stream, self.unit, len(self.unit), path)
        return obj

    def _sizeof(self, context, path):
        if self.mode in {'fixed', 'count_field', 'count_expression'}:
            return self._size(evaluate(self.length, context), path)
        raise SizeofError('variable payload size', path=path)
