"""Decode options and normalization of Construct values without model creation."""
from __future__ import annotations

from collections.abc import Mapping
from enum import Enum
from typing import Any, Literal

from construct import Container, EnumInteger, EnumIntegerString


ReturnMode = Literal["object", "dict"]
AfterDecodeMode = Literal["object", "dict", "none"]


def decode_hook_mode(return_mode: ReturnMode, after_decode: AfterDecodeMode | None) -> AfterDecodeMode:
    if return_mode not in ("object", "dict"):
        raise ValueError("return_mode must be 'object' or 'dict'")
    if after_decode is None:
        return return_mode
    if after_decode not in ("object", "dict", "none"):
        raise ValueError("after_decode must be 'object', 'dict', 'none', or None")
    if return_mode == "object" and after_decode == "dict":
        raise ValueError("after_decode='dict' requires return_mode='dict'")
    return after_decode


def decoded_dictionary(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError("Dictionary decoding requires a mapping from the wire schema")
    if "Name" in value:
        raise ValueError("Decoded field 'Name' conflicts with reserved message-name metadata")
    result = _plain_value(value)
    result["Name"] = name
    return result


def _plain_value(value: Any) -> Any:
    if isinstance(value, (EnumInteger, EnumIntegerString)):
        return int(value)
    if isinstance(value, Enum):
        return _plain_value(value.value)
    if isinstance(value, Mapping):
        # Struct inserts _io. Other underscore-prefixed fields belong to the
        # schema and must survive. Plain dictionaries may legitimately use _io.
        container = isinstance(value, Container)
        return {key: _plain_value(item) for key, item in value.items()
                if not (container and key == "_io")}
    if isinstance(value, list):
        return [_plain_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_plain_value(item) for item in value)
    return value
