from __future__ import annotations

from enum import Enum


class Direction(str, Enum):
    """Direction metadata used as the second half of a message registry key."""

    TX = "TX"
    RX = "RX"
    ANY = "ANY"

    @classmethod
    def normalize(cls, value: "Direction | str | Enum | None") -> "Direction | None":
        if value is None:
            return None
        if isinstance(value, cls):
            return value
        # Communication Hub has its own str/Enum Direction. Normalize enum
        # values without importing Hub (or relying on Enum.__str__).
        if isinstance(value, Enum):
            value = value.value
        try:
            return cls(str(value).upper())
        except ValueError as error:
            raise ValueError("direction must be 'TX', 'RX', or 'ANY'") from error

    @classmethod
    def normalize_filter(cls, value: "Direction | str | Enum | None") -> "Direction | None":
        """ANY accepts either direction when selecting a message."""
        direction = cls.normalize(value)
        return None if direction == cls.ANY else direction


# Compatibility for libraries generated before the Direction rename.
TxRx = Direction
