"""Structured, live benchmark status with an optional bounded event log."""
import json
import time

from PyQt5 import QtCore, QtWidgets


class ElidedValue(QtWidgets.QLabel):
    """Keep identifiers in their table cell and expose the full value on hover."""
    def setText(self, text):
        self.full_text = str(text)
        self.setToolTip(self.full_text)
        self.refresh_text()

    def refresh_text(self):
        super().setText(self.fontMetrics().elidedText(
            getattr(self, 'full_text', '—'), QtCore.Qt.ElideRight, max(0, self.contentsRect().width()-10)))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.refresh_text()


class BenchmarkStatus(QtWidgets.QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('benchmarkStatus')
        self.setAccessibleName('Benchmark status')
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)
        self.fields = {}
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel('Benchmark status')
        title.setObjectName('timelineCardTitle')
        header.addWidget(title)
        header.addStretch()
        state = self.make_field('state', 'Run state')
        state.setObjectName('benchmarkBadge')
        state.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        state.setWordWrap(False)
        header.addWidget(state)
        layout.addLayout(header)
        results = QtWidgets.QFrame()
        results.setObjectName('benchmarkResults')
        result_grid = QtWidgets.QGridLayout(results)
        result_grid.setContentsMargins(0, 8, 0, 8)
        result_grid.setSpacing(2)
        for column, key in enumerate(('passed', 'failed', 'unsupported')):
            count = self.make_field(key, key.capitalize())
            count.setObjectName('benchmarkCount')
            count.setProperty('result', key)
            count.setAlignment(QtCore.Qt.AlignCenter)
            caption = QtWidgets.QLabel(key.capitalize())
            caption.setObjectName('muted')
            caption.setAlignment(QtCore.Qt.AlignCenter)
            result_grid.addWidget(count, 0, column)
            result_grid.addWidget(caption, 1, column)
            result_grid.setColumnStretch(column, 1)
        layout.addWidget(results)
        self.table = QtWidgets.QGridLayout()
        self.table.setSpacing(0)
        self.table.setColumnMinimumWidth(0, 76)
        self.table.setColumnMinimumWidth(2, 82)
        self.table.setColumnStretch(1, 1)
        self.table.setColumnStretch(3, 1)
        for row, cells in enumerate([
            [('case', 'Case')], [('mode', 'Mode'), ('repetition', 'Repetition')],
            [('stage', 'Stage'), ('turn', 'Turn')], [('model', 'Model')],
            [('elapsed', 'Elapsed'), ('requests', 'Requests')],
            [('heartbeat', 'Heartbeat'), ('memory', 'Memory')],
        ]):
            for column, (key, title) in enumerate(cells):
                caption = QtWidgets.QLabel(title)
                caption.setObjectName('benchmarkKey')
                caption.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
                field = self.make_field(key, title)
                field.setObjectName('benchmarkValue')
                self.table.addWidget(caption, row, column*2)
                self.table.addWidget(field, row, column*2+1, 1, 3 if len(cells) == 1 else 1)
        layout.addLayout(self.table)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setObjectName('benchmarkProgress')
        self.progress.setAccessibleName('Completed benchmark cases')
        self.progress.setFormat('%v / %m cases completed')
        self.progress.setFixedHeight(20)
        layout.addWidget(self.progress)
        self.message = QtWidgets.QLabel()
        self.message.setObjectName('benchmarkMessage')
        self.message.setTextFormat(QtCore.Qt.PlainText)
        self.message.setWordWrap(True)
        self.message.setMinimumWidth(0)
        self.message.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.message.setAccessibleName('Benchmark message')
        layout.addWidget(self.message)
        self.details = QtWidgets.QToolButton()
        self.details.setObjectName('benchmarkDetails')
        self.details.setText('Technical event log')
        self.details.setCheckable(True)
        self.details.setArrowType(QtCore.Qt.RightArrow)
        self.details.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        layout.addWidget(self.details)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setFixedHeight(110)
        self.log.document().setMaximumBlockCount(200)
        self.log.setAccessibleName('Benchmark technical event log')
        layout.addWidget(self.log)
        self.details.toggled.connect(self.toggle_details)
        self.reset()
        self.hide()

    def make_field(self, key, title):
        label = ElidedValue() if key in {'case', 'model'} else QtWidgets.QLabel()
        label.setText('—')
        label.setTextFormat(QtCore.Qt.PlainText)
        label.setWordWrap(key not in {'case', 'model'})
        label.setMinimumWidth(0)
        label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
        label.setAccessibleName('Benchmark '+title.lower())
        label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.fields[key] = label
        return label

    def set_state(self, state):
        badge = self.fields['state']
        badge.setText(str(state).replace('_', ' ').capitalize())
        tone = ('success' if state == 'completed' else 'error' if state in {'failed', 'interrupted'}
                else 'warning' if state in {'stopping', 'cancelled', 'limited'} else 'active')
        badge.setProperty('tone', tone)
        badge.style().unpolish(badge)
        badge.style().polish(badge)

    def clear_activity(self):
        for key in ('case', 'mode', 'repetition', 'turn', 'stage', 'model'):
            self.fields[key].setText('—')

    def toggle_details(self, expanded):
        self.details.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.log.setVisible(expanded)

    def reset(self, scheduled=0, request_limit=0):
        self.started = None
        self.ended = None
        self.last_heartbeat = None
        self.terminal = False
        self.stopping = False
        self.counts = {'passed': 0, 'failed': 0, 'unsupported': 0}
        self.request_count = 0
        self.request_limit = request_limit
        self.memory = 'Unavailable'
        self.log.clear()
        self.message.clear()
        self.message.hide()
        self.details.setChecked(False)
        self.toggle_details(False)
        self.set_state('ready')
        self.clear_activity()
        self.progress.setRange(0, max(1, scheduled))
        self.progress.setValue(0)
        self.update_results()
        self.update_clock()

    def begin(self, scheduled, request_limit):
        self.reset(scheduled, request_limit)
        self.started = time.monotonic()
        self.set_state('starting')
        self.fields['stage'].setText('Starting worker')
        self.show()

    def add_message(self, message):
        self.message.setText(str(message))
        self.message.setVisible(bool(message))
        self.log.appendPlainText(str(message))
        self.show()

    def update_results(self):
        for key, value in self.counts.items():
            self.fields[key].setText(str(value))

    def update_clock(self):
        now = self.ended if self.ended is not None else time.monotonic()
        elapsed = max(0, int(now-self.started)) if self.started is not None else 0
        minutes, seconds = divmod(elapsed, 60)
        self.fields['elapsed'].setText(f'{minutes:02d}:{seconds:02d}')
        self.fields['requests'].setText(f'{self.request_count:,} / {self.request_limit:,}')
        heartbeat = ('Waiting' if self.last_heartbeat is None else
                     f'{max(0, int(now-self.last_heartbeat))} seconds ago')
        self.fields['heartbeat'].setText(heartbeat)
        self.fields['memory'].setText(self.memory)

    def request_stop(self, message):
        self.stopping = True
        self.set_state('stopping')
        self.add_message(message)

    def finish(self, status, error=None):
        if self.ended is None:
            self.ended = time.monotonic()
        self.update_clock()
        self.terminal = True
        self.set_state(status)
        self.clear_activity()
        self.fields['case'].setText('No active case')
        if error:
            if isinstance(error, dict):
                error = ': '.join(str(error[key]) for key in ('code', 'message') if error.get(key))
            self.add_message(error)

    def apply_event(self, value):
        """Accept already-sanitized worker events; heartbeat only refreshes metrics."""
        kind = value.get('kind')
        self.log.appendPlainText(json.dumps(value, ensure_ascii=False))
        if self.terminal:
            return
        self.show()
        if 'requests' in value:
            self.request_count = value['requests']
        if 'scheduled' in value:
            self.progress.setMaximum(max(1, value['scheduled']))
        if 'executed' in value:
            self.progress.setValue(value['executed'])
        if kind == 'heartbeat':
            self.last_heartbeat = time.monotonic()
            rss = (value.get('resources') or {}).get('rss_bytes')
            self.memory = f'{rss / (1024*1024):.1f} MiB' if isinstance(rss, (int, float)) else 'Unavailable'
        elif kind == 'preflight':
            if not self.stopping:
                self.set_state('preflight')
            self.fields['stage'].setText('Checking model support')
        elif kind == 'case_started':
            if not self.stopping:
                self.set_state('running')
            self.clear_activity()
            self.fields['case'].setText(value['case'])
            self.fields['mode'].setText({'single': 'Single model', 'multi': 'Multi-model'}.get(value.get('mode'), '—'))
            self.fields['repetition'].setText(str(value.get('repetition', 0)+1))
            if value.get('candidate'):
                self.fields['case'].setText(f"{value['case']} · {value['candidate']} ({value.get('partition', '—')})")
        elif kind == 'stage':
            stage = ' · '.join(str(value[key]).replace('_', ' ').capitalize()
                               for key in ('role', 'status') if value.get(key))
            self.fields['stage'].setText(stage or '—')
            self.fields['turn'].setText(str(value.get('turn', '—')))
            self.fields['model'].setText(str(value.get('model') or '—'))
        elif kind == 'case_completed':
            result = 'unsupported' if value.get('status') == 'unsupported' else 'passed' if value.get('passed') else 'failed'
            self.counts[result] += 1
            self.update_results()
            self.fields['stage'].setText(result.capitalize())
            self.add_message(f"{value.get('id', 'Case')}: {result}.")
        elif kind == 'outcome':
            outcome = value.get('outcome')
            if isinstance(outcome, dict):
                outcome = outcome.get('status') or outcome.get('code')
            if outcome:
                self.add_message(f"Turn outcome: {outcome}")
        elif kind == 'fatal':
            self.finish('failed', value.get('message'))
        elif kind == 'finished':
            self.finish(value.get('status', 'interrupted'), value.get('error'))
        self.update_clock()
