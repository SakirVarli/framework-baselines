import sys, re, traceback, json, subprocess
import multiprocessing
from PyQt5 import QtWidgets, QtGui, QtCore
import warnings, os, shutil
from pathlib import Path
from app.branding import FULL_NAME, SHORT_NAME, environment_name
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

SUPERVISED_ENV_VAR = environment_name("DESIGNER_SUPERVISED")
APP_RESTART_EXIT_CODE_VAR = environment_name("DESIGNER_RESTART_EXIT_CODE")
APP_RESTART_MARKER = environment_name("DESIGNER_RESTART_REQUESTED")
APP_UPGRADE_EXIT_CODE_VAR = environment_name("DESIGNER_UPGRADE_EXIT_CODE")
APP_UPGRADE_MARKER = environment_name("DESIGNER_UPGRADE_REQUESTED") + ":"
APP_RESTART_EXIT_CODE = int(os.environ.get(APP_RESTART_EXIT_CODE_VAR, "42"))
APP_UPGRADE_EXIT_CODE = int(os.environ.get(APP_UPGRADE_EXIT_CODE_VAR, "43"))


def configure_hidden_multiprocessing():
    """Use the environment's console interpreter for reliable Windows IPC.

    The Designer supervisor already starts the application with
    CREATE_NO_WINDOW. Replacing the multiprocessing executable with
    pythonw.exe is therefore unnecessary, and on Python 3.14 it can make
    spawned workers close their control pipes shortly after startup.
    """
    if os.name != "nt" or is_frozen():
        return
    executable = Path(sys.executable)
    python = executable.with_name("python.exe")
    multiprocessing.set_executable(str(python if python.is_file() else executable))


def gui_python_executable():
    """Return a console-free interpreter for GUI restarts when available."""
    executable = Path(sys.executable)
    if os.name == "nt" and not is_frozen():
        pythonw = executable.with_name("pythonw.exe")
        if pythonw.is_file():
            return str(pythonw)
    return str(executable)


from app.startup import apply_app_icon, run_loader, set_windows_app_id
from app.lifecycle import LifecycleManager
from app.ui_builder import ConfigDrivenWindow
from app.config_designer.api import ConfigDesignerWindow
from app.builder import BuildAppDialog
from app.upgrade_dialogs import AppVersionDialog, BaselineExportWizard, UpgradeWizard
from app.upgrade_manager import PACKAGE_FILENAME, STATE_DIRNAME, hide_windows_path
from app.tool_api import Tools
from app.help_system import HelpWindow
from app.project_recovery import ensure_project_files
from app.utils import (
    PROJECT_ROOT, CALLBACKS_PATH, HELP_PATH,
    load_callbacks_as_file, create_func_pattern, set_widow_feature, is_frozen
)

class MainApp(ConfigDrivenWindow):
    def __init__(self, *, degraded_startup=False):
        super().__init__(degraded_startup=degraded_startup)
        if self.phase == "development":
            for hidden_path in (
                Path(PROJECT_ROOT) / "app",
                Path(PROJECT_ROOT) / STATE_DIRNAME,
                Path(PROJECT_ROOT) / PACKAGE_FILENAME,
            ):
                hide_windows_path(hidden_path)
        self._make_menubar()
        QtCore.QTimer.singleShot(0, self._show_upgrade_result)

    # ---------------- Menus ----------------
    def _make_menubar(self):
        mb = self.menuBar()

        file_menu = mb.addMenu('&File')
        act_open_designer = file_menu.addAction('Config Designer…')
        file_menu.addSeparator()

        if self.phase == "baseline" and not is_frozen():
            act_export_baseline = file_menu.addAction('Export Baseline…')
        act_upgrade = file_menu.addAction('Upgrade…')
        file_menu.addSeparator()

        act_soft_restart = file_menu.addAction('Soft Restart')
        act_restart = file_menu.addAction('Restart')
        file_menu.addSeparator()

        act_exit = file_menu.addAction('Exit')

        settings_menu = mb.addMenu('&Settings')
        act_set_admin = settings_menu.addAction('Set Admin Password…')
        act_set_title = settings_menu.addAction('Set Window Title…')
        act_set_icon = settings_menu.addAction('Set Window Icon…')
        
        if not is_frozen():
            build_menu = mb.addMenu('&Build') 
            act_build = build_menu.addAction('Build Application')

        version_menu = mb.addMenu('&Version')

        if not is_frozen():
            act_set_version = version_menu.addAction('Set App Version…')
        act_version = version_menu.addAction(f'Version: {self.version}.{self.build}')
        act_version.setEnabled(False)  # makes it informational only
        act_baseline = version_menu.addAction(f'Baseline: {self.baseline_number}')
        act_baseline.setEnabled(False)
        version_menu.addSeparator()
        act_app_release_notes = version_menu.addAction('App Version Release Notes…')
        act_baseline_release_notes = version_menu.addAction('Baseline Release Notes…')

        # -------- Tools Menu --------
        tools_menu = mb.addMenu('&Tools')
        act_open_ide = tools_menu.addAction('IDE')
        act_open_ftp_server = tools_menu.addAction('FTP Server')
        act_open_ftp_client  = tools_menu.addAction('FTP Client')
        act_open_serial = tools_menu.addAction('Serial')
        act_open_telnet  = tools_menu.addAction('Telnet')
        act_open_communication = tools_menu.addAction('Communication Hub')

        help_menu = mb.addMenu('&Help')
        act_help_contents = help_menu.addAction('Help Contents')
        act_help_contents.setShortcut(QtGui.QKeySequence('F1'))
        

        # Wire
        act_open_designer.triggered.connect(self._open_designer) #Sorting
        if self.phase == "baseline" and not is_frozen():
            act_export_baseline.triggered.connect(self._export_baseline)
        act_upgrade.triggered.connect(self._upgrade)
        act_soft_restart.triggered.connect(self._soft_restart)
        act_restart.triggered.connect(self._restart)
        act_exit.triggered.connect(self.close)

        act_set_admin.triggered.connect(self._set_admin_password)
        act_set_title.triggered.connect(self._set_title)
        act_set_icon.triggered.connect(self._set_icon)
        
        if not is_frozen():
            act_set_version.triggered.connect(self._set_version)
            act_build.triggered.connect(self._build_app)

        version_menu.aboutToShow.connect(
            lambda: (
                act_version.setText(f'Version: {self.version}.{self.build}'),
                act_baseline.setText(f'Baseline: {self.baseline_number}')
            )
        )

        act_open_ide.triggered.connect(self._open_python_ide)
        act_open_ftp_server.triggered.connect(self._open_ftp_server)
        act_open_ftp_client.triggered.connect(self._open_ftp_client)
        act_open_serial.triggered.connect(self._open_serial)
        act_open_telnet.triggered.connect(self._open_telnet)
        act_open_communication.triggered.connect(self._open_communication_hub)
        act_help_contents.triggered.connect(self._open_help)
        act_app_release_notes.triggered.connect(self._show_app_version_release_notes)
        act_baseline_release_notes.triggered.connect(self._show_baseline_release_notes)

    # -------- Admin gate for sensitive actions --------
    def _admin_ok(self) -> bool:
        # No password set → always allowed
        if not self.admin_pasword:
            return True

        txt, ok = QtWidgets.QInputDialog.getText(
            self,
            "Admin Password",
            "Enter admin password:",
            QtWidgets.QLineEdit.Password
        )

        if not ok:
            return False  # user cancelled

        if txt != self.admin_pasword:
            QtWidgets.QMessageBox.warning(
                self,
                "Access Denied",
                "Incorrect admin password."
            )
            return False

        return True
    
    # -------- Menu handlers --------
    def _open_designer(self):
        if not self._admin_ok():
            return
        try:
            designer = getattr(self, "_config_designer", None)
            if designer is None:
                designer = ConfigDesignerWindow(self)
                self._config_designer = designer
                designer.applied.connect(self._reload_layout)
                designer.saved.connect(self._reload_layout)
                designer.restoreRequested.connect(self._reload_layout)
            designer.show()
            designer.raise_()
            designer.activateWindow()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Designer Error", f"Failed to launch Configuration Designer:\n{e}")

    def _export_baseline(self):
        if not self._admin_ok():
            return
        wizard = BaselineExportWizard(self, self.baseline_number, self.version, self.build)
        if wizard.exec_() != QtWidgets.QDialog.Accepted or not wizard.export_result:
            return
        released_baseline = wizard.baseline.value()
        self.baseline_number = released_baseline + 1
        set_widow_feature("baseline_number", self.baseline_number)
        outputs = "\n".join(wizard.export_result.values())
        QtWidgets.QMessageBox.information(
            self, "Baseline Exported",
            f"Baseline {released_baseline} was exported and verified successfully:\n\n{outputs}"
        )

    def _upgrade(self):
        if not self._admin_ok():
            return
        wizard = UpgradeWizard(self, self.baseline_number)
        if wizard.exec_() != QtWidgets.QDialog.Accepted or not wizard.plan_path:
            return
        self._upgrade_plan_path = str(wizard.plan_path)
        QtCore.QTimer.singleShot(0, self._request_upgrade_shutdown)

    def _request_upgrade_shutdown(self):
        if os.environ.get(SUPERVISED_ENV_VAR) != "1":
            restart = [sys.executable, "-m", "app.main"]
            command = [
                sys.executable, "-m", "app.upgrade_helper", self._upgrade_plan_path,
                "--wait-pid", str(os.getpid()), "--restart-json", json.dumps(restart),
            ]
            creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            subprocess.Popen(
                command, cwd=PROJECT_ROOT, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=creationflags,
            )
        self.close()

    def _show_upgrade_result(self):
        result_path = Path(PROJECT_ROOT) / STATE_DIRNAME / "last-result.json"
        if not result_path.is_file():
            return
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
            result_path.unlink()
        except Exception:
            return
        if result.get("success"):
            release = result.get("release", {})
            notes = release.get("notes") or "No detailed release notes were supplied."
            baseline_label = f"Baseline {release.get('baseline_number')}"
            release_title = str(release.get("title") or "").strip()
            release_heading = baseline_label
            if release_title and release_title.casefold() != baseline_label.casefold():
                release_heading = f"{release_title}\n{baseline_label}"
            restart_note = ""
            if result.get("restart_error"):
                restart_note = f"\n\nAutomatic restart failed: {result['restart_error']}"
            QtWidgets.QMessageBox.information(
                self, "Upgrade Successful — Release Notes",
                f"{release_heading}\n\n"
                f"Changed files: {len(result.get('changed', []))}\n"
                f"Preserved files: {len(result.get('preserved', []))}\n\nRelease notes:\n{notes}"
                f"{restart_note}"
            )
        else:
            QtWidgets.QMessageBox.critical(
                self, "Upgrade Failed and Was Rolled Back",
                f"The upgrade could not be completed. Existing files were restored.\n\n"
                f"{result.get('error', 'Unknown upgrade error')}\n\nBackup: {result.get('backup', '')}"
            )

    def _show_baseline_release_notes(self):
        history_path = Path(PROJECT_ROOT) / STATE_DIRNAME / "history.json"
        try:
            history = json.loads(history_path.read_text(encoding="utf-8"))
            release = history[-1]["release"]
        except Exception:
            QtWidgets.QMessageBox.information(
                self, "Baseline Release Notes",
                "No installed baseline release notes are available."
            )
            return
        baseline_label = f"Baseline {release.get('baseline_number')}"
        release_title = str(release.get("title") or "").strip()
        release_heading = baseline_label
        if release_title and release_title.casefold() != baseline_label.casefold():
            release_heading = f"{release_title}\n{baseline_label}"
        QtWidgets.QMessageBox.information(
            self, "Baseline Release Notes",
            f"{release_heading}\n\n"
            f"{release.get('summary', '')}\n\n{release.get('notes', '') or 'No detailed release notes were supplied.'}"
        )

    def _show_app_version_release_notes(self):
        notes = self.app_version_release_notes.strip()
        QtWidgets.QMessageBox.information(
            self, "App Version Release Notes",
            f"Application version {self.version}\n\n"
            f"{notes or 'No release notes were supplied for this application version.'}"
        )

    def _soft_restart(self):
        """Trigger a soft restart request"""
        try:
            self._reload_runtime()
            self._show_done_confirm(
                "Runtime succesfully reloaded."
            )
        except Exception:
            tb = traceback.format_exc()
            self._show_error_traceback(
                f"'Runtime Relaod' crashed:\n\n{tb}"
            )

    def _restart(self):
        """Trigger a restart request — confirmation handled in closeEvent."""
        self._restarting = True
        self.close()  # closeEvent will handle confirmation and restart

    def _set_admin_password(self):
        if not self._admin_ok():
            return
        txt, ok = QtWidgets.QInputDialog.getText(self, 'Set Admin Password', 'New admin password (leave empty to clear):', QtWidgets.QLineEdit.Password)
        if ok:
            self.admin_pasword = (txt or None)
            set_widow_feature("admin_password", self.admin_pasword)

    def _set_title(self):
        if not self._admin_ok():
            return
        txt, ok = QtWidgets.QInputDialog.getText(self, 'Set Window Title', 'Title:', text=self.title)
        if ok:
            self.title = txt
            self.setWindowTitle(self.title)
            set_widow_feature("title", self.title)

    def _set_icon(self):
        if not self._admin_ok():
            return

        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Pick icon",
            PROJECT_ROOT,
            "Icon Files (*.ico)"
        )
        if not path:
            return

        src = Path(path)

        # Only accept .ico files
        if src.suffix.lower() != ".ico":
            QtWidgets.QMessageBox.warning(self, "Invalid Icon", "Please select a .ico file.")
            return

        # Target location inside project
        target_dir = Path(PROJECT_ROOT) / "app" / "favicon"
        target_dir.mkdir(parents=True, exist_ok=True)

        target_icon_path = target_dir / "app.ico"

        try:
            shutil.copy2(src, target_icon_path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Copy Failed", str(e))
            return

        # Apply icon from internal project path
        self.icon = str(target_icon_path)
        self.setWindowIcon(QtGui.QIcon(self.icon))

        # Save relative path in config (portable)
        rel_path = os.path.relpath(target_icon_path, PROJECT_ROOT).replace("\\", "/")
        set_widow_feature("icon", rel_path)

    def _set_version(self):
        if not self._admin_ok():
            return
        dialog = AppVersionDialog(
            self, self.version, self.app_version_release_notes
        )
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return
        self.version = dialog.version.text().strip()
        self.app_version_release_notes = dialog.notes.toPlainText().strip()
        set_widow_feature("version", self.version)
        set_widow_feature("app_version_release_notes", self.app_version_release_notes)
        QtWidgets.QMessageBox.information(
            self, "Version Updated",
            f"Application version {self.version} and its release notes were saved."
        )

    def _build_app(self):
        if not self._admin_ok():
            return
        try:
            dlg = BuildAppDialog(self)
            dlg.exec_()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "IDE Error", f"Failed to launch Build Dialog:\n{e}")
    
    def _open_singleton(self, attr_name: str, cls, *args, **kwargs):
        """
        Opens a singleton window:
        - If the window exists and is visible → bring to front
        - If minimized → restore
        - If closed → create a new one
        """
        # If exists & visible → bring forward
        win = getattr(self, attr_name, None)
        if win:
            try:
                if hasattr(win, "reattach_ui") and not getattr(win, "_ui_attached", True):
                    win.reattach_ui()
                win.show()
                win.raise_()
                win.activateWindow()
                win.showNormal()
                return win
            except RuntimeError:
                setattr(self, attr_name, None)

        # Otherwise create new instance
        win = cls(*args, **kwargs)
        win.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)

        # Remove stored reference when destroyed
        def _clear():
            setattr(self, attr_name, None)

        win.destroyed.connect(_clear)

        setattr(self, attr_name, win)
        win.show()
        apply_app_icon(win)
        return win

    def _open_python_ide(self):
        if not self._admin_ok():
            return
        from app.tools.ide import MiniIDE
        ide = self._open_singleton("_ide_window", MiniIDE)

        # Only connect the signal once (avoid duplicates)
        if not hasattr(ide, "_reload_connected"):
            ide.file_saved.connect(self._on_ide_file_saved)
            ide._reload_connected = True
    
    def _on_ide_file_saved(self):
        """Called whenever a file is saved from the IDE."""
        try:
            self._reload_runtime()
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Reload Error", f"Failed to reload after IDE save:\n{e}")
    
    def _open_callback_in_embedded_ide(self, func_name: str):
        """
        Open callbacks.py in the MiniIDE and jump to the function signature.
        The function definition line will appear centered in the editor.
        """

        # Ensure IDE window exists
        if not hasattr(self, "_ide_window") or not self._ide_window or not self._ide_window.isVisible():
            self._open_python_ide()

        ide = self._ide_window
        ide.open_file(CALLBACKS_PATH)

        # Get active tab + editor
        tab = ide.current_tab()
        if not tab:
            QtWidgets.QMessageBox.warning(self, "IDE Error", "IDE has no active tab.")
            return

        editor = tab.editor  # pyqode CodeEdit()

        # === Find function ===
        try:
            content = load_callbacks_as_file()
            pattern = create_func_pattern(func_name)

            lines = content.splitlines(keepends=True)

            target_line = -1
            for i, line in enumerate(lines):
                if re.match(pattern, line):
                    target_line = i
                    break

            if target_line < 0:
                QtWidgets.QMessageBox.information(
                    self,
                    "Callback Not Found",
                    f"'{func_name}' was not found.\nSave configuration then try again."
                )
                return

            # === Jump cursor to target line ===
            cursor = editor.textCursor()
            block = editor.document().findBlockByLineNumber(target_line)
            cursor.setPosition(block.position())
            editor.setTextCursor(cursor)

            # === Center editor on the cursor ===
            # pyqode's editor.centerCursor() doesn't run correctly unless delayed
            def _center_now():
                editor.centerCursor()
                # Also ensure the line is visible
                editor.ensureCursorVisible()

            QtCore.QTimer.singleShot(80, _center_now)

            # Bring IDE forward
            ide.raise_()
            ide.activateWindow()

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "IDE Error", f"Failed to open callback:\n{e}")

    def _open_ftp_server(self):
        if not self._admin_ok():
            return
        from app.tools.ftp_server import FTPServerWidget
        return Tools.registry.register(
            "ftp_server", self._open_singleton("_ftp_server", FTPServerWidget)
        )
    
    def _open_ftp_client(self):
        if not self._admin_ok():
            return
        from app.tools.ftp_client import FTPClientWidget
        return Tools.registry.register(
            "ftp_client", self._open_singleton("_ftp_client", FTPClientWidget)
        )
    
    def _open_serial(self):
        if not self._admin_ok():
            return
        from app.tools.serial_widget import SerialWidget
        return Tools.registry.register(
            "serial", self._open_singleton("_serial_widget", SerialWidget)
        )

    def _open_telnet(self):
        if not self._admin_ok():
            return
        from app.tools.telnet_widget import TelnetWidget
        return Tools.registry.register(
            "telnet", self._open_singleton("_telnet_widget", TelnetWidget)
        )

    def _open_communication_hub(self):
        if not self._admin_ok():
            return
        from app.tools.communication_hub.widget import CommunicationHubWidget
        return Tools.registry.register(
            "communication", self._open_singleton("_communication_hub", CommunicationHubWidget)
        )

    def _open_help(self):
        return self._open_singleton(
            "_help_window",
            HelpWindow,
            HELP_PATH,
            phase=self.phase,
            admin_check=self._admin_ok,
            parent=self,
        )

    def _acquire_communication_hub(self):
        """Create or return the Hub runtime owner without displaying its UI."""
        hub = getattr(self, "_communication_hub", None)
        if hub is not None:
            try:
                return Tools.registry.register("communication", hub)
            except RuntimeError:
                self._communication_hub = None
        from app.tools.communication_hub.widget import CommunicationHubWidget
        hub = CommunicationHubWidget()
        hub.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        hub.destroyed.connect(lambda: setattr(self, "_communication_hub", None))
        self._communication_hub = hub
        # The same retained object owns API-started workers. Opening the tool
        # later calls reattach_ui() and renders their current state.
        hub.detach_ui()
        apply_app_icon(hub)
        return Tools.registry.register("communication", hub)

    def closeEvent(self, event: QtGui.QCloseEvent):
        """Unified confirmation handler for both Close and Restart."""
        try:
            ide_open = hasattr(self, "_ide_window") and self._ide_window and self._ide_window.isVisible()
            restarting = getattr(self, "_restarting", False)
            upgrading = bool(getattr(self, "_upgrade_plan_path", ""))

            # --- Determine message ---
            if ide_open:
                msg = (
                    "The integrated IDE is currently open.\n"
                    f"{'Restarting' if restarting else 'Closing'} the application will also close the IDE "
                    "without savin the last changes on the open files.\n\n"
                    f"Do you want to {'restart' if restarting else 'exit'} the application?"
                )
            else:
                msg = (
                    f"Are you sure you want to {'restart' if restarting else 'close'} the application?"
                )

            if not upgrading:
                reply = QtWidgets.QMessageBox.question(
                    self,
                    f"Confirm {'Restart' if restarting else 'Exit'}",
                    msg,
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No
                )

                if reply == QtWidgets.QMessageBox.No:
                    event.ignore()
                    return

            help_window = getattr(self, "_help_window", None)
            if help_window is not None:
                try:
                    help_window._commit_editor_topic()
                    if not help_window.confirm_pending_changes():
                        event.ignore()
                        return
                except RuntimeError:
                    self._help_window = None
            
            # --- Close IDE if open ---
            if ide_open:
                try:
                    self._ide_window._force_close = True
                    self._ide_window.save_session()
                    self._ide_window.close()
                except Exception as e:
                    print(f"⚠️ Failed to close IDE cleanly: {e}")
            
            # --- Gracefull shutdown for all other tools ---
            Tools.begin_shutdown()
            tool_attrs = [
                "_ftp_server",
                "_ftp_client",
                "_serial_widget",
                "_telnet_widget",
                "_communication_hub",
            ]

            for attr in tool_attrs:
                win = getattr(self, attr, None)
                if win and hasattr(win, "close"):
                    try:
                        if hasattr(win, "prepare_application_shutdown"):
                            win.prepare_application_shutdown()
                        win.close()
                    except Exception as e:
                        print(f"⚠️ Failed to close {attr}: {e}")

            if upgrading:
                if os.environ.get(SUPERVISED_ENV_VAR) == "1":
                    print(f"{APP_UPGRADE_MARKER}{self._upgrade_plan_path}", flush=True)
                LifecycleManager.run_lifecycle("close", event)
                event.accept()
                QtWidgets.QApplication.exit(APP_UPGRADE_EXIT_CODE)
                return

            # --- Restart if requested ---
            if restarting:
                if os.environ.get(SUPERVISED_ENV_VAR) == "1":
                    print(APP_RESTART_MARKER, flush=True)
                    LifecycleManager.run_lifecycle("close", event)
                    event.accept()
                    QtWidgets.QApplication.exit(APP_RESTART_EXIT_CODE)
                    return
                elif is_frozen():
                    QtCore.QProcess.startDetached(sys.executable, sys.argv)
                else:
                    QtCore.QProcess.startDetached(
                        gui_python_executable(), ["-m", "app.main"])

            LifecycleManager.run_lifecycle("close", event)
        except Exception as e:
            print(f"⚠️ CloseEvent error: {e}")

        super().closeEvent(event)


def recover_missing_project_files(parent=None):
    """Offer to restore required project files before MainApp reads them."""
    def ask_generate(missing):
        paths = "\n".join(f"  • {path}" for path in missing)
        box = QtWidgets.QMessageBox(parent)
        box.setIcon(QtWidgets.QMessageBox.Warning)
        box.setWindowTitle(f"{SHORT_NAME} Project Recovery")
        box.setText("Required project files are missing.")
        box.setInformativeText(
            f"{FULL_NAME} found:\n\n{paths}\n\n"
            "Generate Defaults creates only the missing files and continues. "
            "Continue Anyway writes nothing and starts with limited or empty "
            "UI/callback behavior; this question will appear again next launch."
        )
        generate = box.addButton("Generate Defaults", QtWidgets.QMessageBox.AcceptRole)
        box.addButton("Continue Anyway", QtWidgets.QMessageBox.DestructiveRole)
        box.setDefaultButton(generate)
        box.exec_()
        return box.clickedButton() is generate

    def warn_degraded(missing):
        paths = "\n".join(f"  • {path}" for path in missing)
        QtWidgets.QMessageBox.warning(
            parent,
            f"{SHORT_NAME} Limited Startup",
            "The application cannot work properly while these files are missing:\n\n"
            f"{paths}\n\nNo files were generated. You will be asked again next launch.",
        )

    return ensure_project_files(PROJECT_ROOT, ask_generate, warn_degraded)

def main():
    multiprocessing.freeze_support()
    configure_hidden_multiprocessing()
    set_windows_app_id()
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
    apply_app_icon()
    recovery_state = recover_missing_project_files()

    parent_pipe, child_pipe = multiprocessing.Pipe()
    loader_proc = multiprocessing.Process(
        target=run_loader,
        args=(child_pipe,),
        daemon=False  # ✅ SAFE
    )
    loader_proc.start()

    def on_app_ready():
        # ✅ Tell loader to fade out
        parent_pipe.send("CLOSE")
        # ✅ Show ONLY after everything is ready
        win.show()
        apply_app_icon(win)

    try:
        win = MainApp(degraded_startup=recovery_state == "degraded")
        configured_icon = QtGui.QIcon(win.icon)
        if not configured_icon.isNull():
            app.setWindowIcon(configured_icon)
            win.setWindowIcon(configured_icon)
        apply_app_icon(win)
        win.ready.connect(on_app_ready)
        sys.exit(app.exec_())
    except:
        parent_pipe.send("CRASHED")
        raise


if __name__ == '__main__':
    main()
