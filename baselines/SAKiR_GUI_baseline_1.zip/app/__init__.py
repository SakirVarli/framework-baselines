# app/__init__.py
"""
=========================================================
 File: app.__init__.py
 Project: Config-Driven PyQt Framework
=========================================================
 © 2025 sakirvarli. All rights reserved.

 This file is part of the Config-Driven Application Framework,
 developed by sakirvarli. Redistribution and modification
 are permitted for personal usage, provided this
 notice remains intact.

 Author:        sakirvarli
 Contact:       sakirvarli
 Created:       2025-11-09
 Auto-Generated: Yes
 Python:        3.12+

 Description:
      This package provides the core runtime modules for building,
      editing, and executing dynamic PyQt interfaces from JSON configs.
 
 This package provides all application-level modules such as:
     • config_designer: interactive visual configuration designer
     • ide: integrated Python IDE
     • global_store: thread-safe runtime globals (AppGlobals)
     • utils: shared utility functions
=========================================================
"""

__version__ = "1.0.0"
__author__ = "sakirvarli"
