# app/lifecycle_manager.py
import asyncio
import inspect
from threading import RLock
from typing import Callable, Optional, List, Tuple

class LifecycleManager:
    """
    Central lifecycle orchestration engine for application startup and shutdown.

    LifecycleManager is a standalone, thread-safe system responsible for
    registering, ordering, and executing lifecycle callbacks such as
    application startup and shutdown hooks.

    This class intentionally **does NOT store any global state**.
    It is purely an execution engine and can be embedded into other
    systems (such as AppGlobals or framework controllers).

    --------------------------------------------------------------------
    🧠 Core Responsibilities
    --------------------------------------------------------------------
    • Register lifecycle callbacks with priority ordering
    • Support synchronous and asynchronous callbacks
    • Execute lifecycle phases deterministically
    • Remain reload-safe and thread-safe

    --------------------------------------------------------------------
    🔁 Supported Lifecycle Phases
    --------------------------------------------------------------------
    • "startup"
    • "close"

    Each phase has a dedicated registration API and execution method.

    --------------------------------------------------------------------
    ⚠️ Execution Order (CRITICAL)
    --------------------------------------------------------------------
    The lifecycle phases are executed in the following order relative
    to global initialization:

        1️⃣ QApplication is created
        2️⃣ Globals global declarations are materialized into AppGlobals, import time globals avaliable here
        3️⃣ 🔹 STARTUP lifecycle runs  ← (on_startup callbacks)
        4️⃣ Full UI layout is built
        5️⃣ Globals.init_globals() executes
        6️⃣ Async globals / async init complete
        7️⃣ Application is marked "ready"
        8️⃣ 🔹 CLOSE lifecycle runs on shutdown

    ⚠️ As a result:
    --------------------------------------------------------------------
    • Startup callbacks MUST NOT assume globals created in init_globals()
      already exist.
    • Startup callbacks SHOULD be used for wiring, validation, and setup,
      not final UI manipulation.
    • Final UI work belongs in init_globals().

    --------------------------------------------------------------------
    🔢 Priority-Based Ordering
    --------------------------------------------------------------------
    • Each callback may define a priority (integer)
    • Higher priority callbacks execute FIRST
    • Callbacks with the same priority execute in registration order

    Example:
        priority=100 → runs first
        priority=0   → runs later

    --------------------------------------------------------------------
    🔄 Sync & Async Support
    --------------------------------------------------------------------
    • Callbacks may be synchronous or asynchronous
    • Async callbacks are awaited automatically
    • Execution order is preserved across async boundaries
    • Async callbacks never block the UI thread

    --------------------------------------------------------------------
    🔒 Thread Safety & Reload Safety
    --------------------------------------------------------------------
    • All registrations and executions are protected by an internal RLock
    • Lifecycle callbacks survive:
        - config reloads
        - module reloads
        - AppGlobals updates
    • Duplicate callback registrations are automatically prevented

    --------------------------------------------------------------------
    🛠️ Intended Usage
    --------------------------------------------------------------------
    • Framework-level orchestration
    • Application startup & shutdown sequencing
    • Plugin systems and extensibility hooks
    • Controlled initialization pipelines

    Most application code should register hooks using:
        • on_startup(...)
        • on_close(...)

    and allow the framework to execute them automatically.

    --------------------------------------------------------------------
    🧩 Design Philosophy
    --------------------------------------------------------------------
    LifecycleManager exists to enforce **temporal correctness**:
    code runs not only in the right order, but at the right *time*.
    --------------------------------------------------------------------
    """

    def __init__(self):
        self._lock = RLock()
        self._startup_callbacks: List[Tuple[int, Callable]] = []
        self._close_callbacks: List[Tuple[int, Callable]] = []

    # -------------------------------------------------
    # Internal helpers (same semantics)
    # -------------------------------------------------
    def _register_callback(
        self,
        target: List[Tuple[int, Callable]],
        func: Callable,
        priority: int,
        label: str,
    ):
        with self._lock:
            if not any(f == func for _, f in target):
                target.append((priority, func))
                target.sort(key=lambda x: -x[0])

    def _remove_callback(
        self,
        target: List[Tuple[int, Callable]],
        func: Callable,
        label: str,
    ):
        with self._lock:
            target[:] = [(p, f) for (p, f) in target if f != func]

    async def _run_callbacks_async(
        self,
        callbacks: List[Tuple[int, Callable]],
        label: str,
        *args,
    ):
        for priority, cb in callbacks:
            try:
                if cb.__code__.co_argcount == 0:
                    result = cb()
                else:
                    result = cb(*args)

                if inspect.isawaitable(result):
                    await result

            except Exception as e:
                raise RuntimeError(
                    f"[Lifecycle] ❌ Error in {label} callback {cb.__name__}: {e}"
                )

    def _ensure_async_run(self, coro):
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(coro)
        except RuntimeError:
            asyncio.run(coro)

    # -------------------------------------------------
    # Public lifecycle API (IDENTICAL NAMES)
    # -------------------------------------------------
    def on_startup(self, func: Optional[Callable] = None, *, priority: int = 0):
        """
        Register a function to be executed during the **startup lifecycle phase**.

        ⚠️ IMPORTANT ORDER GUARANTEE
        --------------------------------------------------------------------
        Startup hooks are executed **AFTER**:
            • QApplication has been created
            • Class-level global declarations are materialized, import time globals avaliable here

        Startup hooks are executed **BEFORE**:
            • The full UI layout is built
            • Globals.init_globals()
            • Any async globals are awaited
            • The application is marked as "ready"

        This makes startup hooks ideal for *early wiring*, validation,
        and pre-initialization logic — but NOT for relying on values
        created inside init_globals().

        --------------------------------------------------------------------
        ✅ Typical Use Cases
        --------------------------------------------------------------------
        • Register signals and observers
        • Validate configuration or environment
        • Prepare background workers (do not start UI work yet)
        • Set up logging, routing, or instrumentation
        • Perform dependency checks
        • Initialize non-UI state

        --------------------------------------------------------------------
        ❌ NOT Intended For
        --------------------------------------------------------------------
        • Accessing globals created inside init_globals()
        • Touching widgets created in init_globals()
        • UI mutations that depend on finalized globals

        --------------------------------------------------------------------
        ✅ Usage (Decorator)
        --------------------------------------------------------------------
            @LifecycleManager.on_startup(priority=100)
            def setup(window):
                print("Startup phase reached")

        --------------------------------------------------------------------
        ✅ Usage (Direct Call)
        --------------------------------------------------------------------
            def setup(window):
                ...

            LifecycleManager.on_startup(setup, priority=50)

        --------------------------------------------------------------------
        🔢 Priority
        --------------------------------------------------------------------
        • Higher priority values execute FIRST
        • Default priority is 0
        • Useful for ordering dependent startup steps

        --------------------------------------------------------------------
        🔄 Sync & Async Support
        --------------------------------------------------------------------
        • Functions may be sync or async
        • Awaitables are awaited automatically
        • Execution order is preserved across async boundaries

        --------------------------------------------------------------------
        🧠 Arguments
        --------------------------------------------------------------------
        • If the function accepts arguments, the main window instance
        is passed automatically.

        --------------------------------------------------------------------
        ⚠️ Rules & Notes
        --------------------------------------------------------------------
        • Do NOT block the UI thread
        • Avoid long-running synchronous work
        """
        if func is None:
            def decorator(f: Callable):
                self._register_callback(
                    self._startup_callbacks, f, priority, "startup"
                )
                return f
            return decorator

        self._register_callback(
            self._startup_callbacks, func, priority, "startup"
        )
        return func

    def on_close(self, func: Optional[Callable] = None, *, priority: int = 0):
        """
        Register a function to be executed during application shutdown.

        Close hooks are executed automatically when the application
        or main window is closing.

        --------------------------------------------------------------------
        ✅ Typical Use Cases
        --------------------------------------------------------------------
        • Save application or user state
        • Stop background threads or workers
        • Close network or database connections
        • Flush logs or caches
        • Perform graceful shutdown logic

        --------------------------------------------------------------------
        ✅ Usage (Decorator)
        --------------------------------------------------------------------
            @LifecycleManager.on_close(priority=50)
            def cleanup(event=None):
                print("Shutting down...")
                Globals.client.close()

        --------------------------------------------------------------------
        ✅ Usage (Direct Call)
        --------------------------------------------------------------------
            def cleanup(event=None):
                ...

            LifecycleManager.on_close(cleanup, priority=10)

        --------------------------------------------------------------------
        🔢 Priority
        --------------------------------------------------------------------
        • Higher priority values execute FIRST
        • Default priority is 0
        • Useful when shutdown order matters

        --------------------------------------------------------------------
        🔄 Sync & Async Support
        --------------------------------------------------------------------
        • The registered function may be:
            - synchronous
            - asynchronous (async def)
        • Awaitables are awaited automatically

        --------------------------------------------------------------------
        🧠 Arguments
        --------------------------------------------------------------------
        • If the function accepts an argument, it will receive:
            - the close event (if available)
            - or None otherwise

        --------------------------------------------------------------------
        ⚠️ Rules & Notes
        --------------------------------------------------------------------
        • Keep shutdown logic fast and robust
        • Avoid blocking operations
        • Prefer async cleanup for I/O-bound work
        """
        if func is None:
            def decorator(f: Callable):
                self._register_callback(
                    self._close_callbacks, f, priority, "close"
                )
                return f
            return decorator

        self._register_callback(
            self._close_callbacks, func, priority, "close"
        )
        return func

    def remove_on_startup(self, func: Callable):
        """
        Remove a previously registered startup callback.
        """
        self._remove_callback(
            self._startup_callbacks, func, "startup"
        )

    def remove_on_close(self, func: Callable):
        """
        Remove a previously registered close callback.
        """
        self._remove_callback(
            self._close_callbacks, func, "close"
        )

    def run_startup_callbacks(self, *args):
        with self._lock:
            callbacks = list(self._startup_callbacks)
        self._ensure_async_run(
            self._run_callbacks_async(callbacks, "startup", *args)
        )

    def run_close_callbacks(self, event=None):
        with self._lock:
            callbacks = list(self._close_callbacks)
        self._ensure_async_run(
            self._run_callbacks_async(callbacks, "close", event)
        )

    def run_lifecycle(self, stage: str, *args):
        """
        Manually trigger a lifecycle stage.

        This method executes all registered lifecycle callbacks
        for the specified stage, in priority order.

        --------------------------------------------------------------------
        ⚠️ Execution Semantics
        --------------------------------------------------------------------
        • "startup" runs BEFORE Globals.init_globals()
        • "close" runs during application shutdown
        • Async callbacks are awaited safely
        • Execution order is deterministic

        --------------------------------------------------------------------
        ✅ Supported Stages
        --------------------------------------------------------------------
        • "startup"
        • "close"

        --------------------------------------------------------------------
        ⚠️ Intended Usage
        --------------------------------------------------------------------
        • Framework-level orchestration
        • Advanced lifecycle control
        • Testing or replay scenarios

        Most applications should rely on automatic lifecycle execution.

        --------------------------------------------------------------------
        ❌ Invalid Stages
        --------------------------------------------------------------------
        • Any value other than "startup" or "close" raises ValueError
        """
        stage = stage.lower().strip()
        if stage == "startup":
            self.run_startup_callbacks(*args)
        elif stage == "close":
            self.run_close_callbacks(*args)
        else:
            raise ValueError("Invalid stage. Must be 'startup' or 'close'.")

    # -------------------------------------------------
    # Optional: debug / introspection
    # -------------------------------------------------
    def __repr__(self):
        return (
            f"<LifecycleManager "
            f"startup={len(self._startup_callbacks)} "
            f"close={len(self._close_callbacks)}>"
        )

LifecycleManager = LifecycleManager()