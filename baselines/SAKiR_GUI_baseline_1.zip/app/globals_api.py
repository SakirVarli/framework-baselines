# app/globals_api.py
from __future__ import annotations

import asyncio
import inspect
import traceback
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

from PyQt5 import QtCore, QtWidgets  # used only for safety checks
from app.global_store import AppGlobals

class AppGlobalDefinitionError(RuntimeError):
    """
    Raised when an illegal global is defined at import time.

    This indicates a violation of the Globals API contract,
    such as creating Qt objects or heavy resources eagerly.
    """
    pass

# -----------------------------
# Wrappers for lazy globals
# -----------------------------
@dataclass(frozen=True)
class Lazy:
    factory: Callable[[], Any]
    label: str = ""

@dataclass(frozen=True)
class AsyncLazy:
    factory: Callable[[], Any]  # must return awaitable or be async func
    label: str = ""

class AsyncGlobalsWorker(QtCore.QThread):
    finished_ok = QtCore.pyqtSignal(dict)
    crashed = QtCore.pyqtSignal(str)

    def __init__(self, pending_async: dict):
        super().__init__()
        self._pending_async = pending_async

    def run(self):
        try:
            async def _runner():
                results = {}
                for name, decl in self._pending_async.items():
                    res = decl.factory()
                    val = await res if inspect.isawaitable(res) else res

                    if isinstance(val, QtCore.QObject):
                        raise RuntimeError(
                            f"Async global '{name}' returned a Qt object. "
                            f"Use lazy(...) instead."
                        )

                    results[name] = val
                return results

            results = asyncio.run(_runner())
            self.finished_ok.emit(results)

        except Exception:
            self.crashed.emit(traceback.format_exc())

def lazy(factory: Callable[[], Any], label: str = "") -> Lazy:
    """
    Declare a lazily-created global value.

    A lazy global is **not created at import time**.
    Instead, it is created automatically by the framework
    when the UI is fully ready and globals are materialized.

    --------------------------------------------------------------------
    🔧 Why Use lazy(...)
    --------------------------------------------------------------------
    • To safely create Qt widgets
    • To defer heavy initialization
    • To avoid import-time side effects
    • To keep class-level declarations clean

    --------------------------------------------------------------------
    ✅ Correct Usage
    --------------------------------------------------------------------
    class Globals(GlobalsBase):
        plot = lazy(lambda: Plot(
            title="My Plot",
            rows=1, cols=1,
            mode="widget"
        ))

    The factory:
    • is called exactly once per initialization cycle
    • runs in the Qt main thread
    • may return any object

    --------------------------------------------------------------------
    ❌ Incorrect Usage
    --------------------------------------------------------------------
    class Globals(GlobalsBase):
        plot = Plot(...)   # ⚠️ unsafe, will warn

    --------------------------------------------------------------------
    🧠 Notes
    --------------------------------------------------------------------
    • The factory must be a callable with no arguments
    • If you need async behavior, use `async_global(...)` instead
    """
    return Lazy(factory=factory, label=label)


def async_global(factory: Callable[[], Any], label: str = "") -> AsyncLazy:
    """
    Declare an asynchronously-created global value.

    Async globals are created by awaiting an async factory
    **without blocking the UI thread**.

    --------------------------------------------------------------------
    🔧 Why Use async_global(...)
    --------------------------------------------------------------------
    • Network clients
    • Database connections
    • File or API initialization
    • Any I/O-bound startup logic

    --------------------------------------------------------------------
    ✅ Correct Usage
    --------------------------------------------------------------------
    async def create_client():
        await asyncio.sleep(1)
        return Client()

    class Globals(GlobalsBase):
        client = async_global(create_client)

    After initialization:
        Globals.client   # ready to use

    --------------------------------------------------------------------
    ⚠️ Important Threading Rules
    --------------------------------------------------------------------
    • The async factory runs outside the Qt UI thread
    • Do NOT touch Qt widgets inside the async factory
    • For UI updates, post back to the main thread using:
        - signals
        - QMetaObject.invokeMethod

    --------------------------------------------------------------------
    🧠 Notes
    --------------------------------------------------------------------
    • The factory may be:
        - an async function
        - a function returning an awaitable
    • The result is stored in AppGlobals once ready
    """
    return AsyncLazy(factory=factory, label=label)


# -----------------------------
# Unsafe detection + warnings
# -----------------------------
def _is_qt_object(x: Any) -> bool:
    try:
        return isinstance(x, QtCore.QObject)
    except Exception:
        return False


def _looks_like_widgetish(x: Any) -> bool:
    # common patterns: QWidget/QObject, Plot instances that carry QWidget, timers, etc.
    if _is_qt_object(x):
        return True
    # Heuristic for your Plot wrapper: has .widget that is QWidget/QObject
    w = getattr(x, "widget", None)
    if w is not None and _is_qt_object(w):
        return True
    return False

# -----------------------------
# Metaclass that collects declarations
# -----------------------------
class _GlobalsMeta(type):
    def __new__(mcls, name, bases, ns: Dict[str, Any]):
        defs: Dict[str, Any] = {}

        # inherit definitions from bases
        for b in bases:
            defs.update(getattr(b, "_definitions", {}))

        # collect new definitions from this class
        for k, v in list(ns.items()):
            if k.startswith("_"):
                continue
            # keep methods / descriptors
            if (
                inspect.isfunction(v)
                or inspect.ismethod(v)
                or isinstance(v, (classmethod, staticmethod, property))
            ):
                continue

            # warn on unsafe eager objects (Plot/QWidget/etc)
            if _looks_like_widgetish(v):
                raise AppGlobalDefinitionError(
                    f"[Globals] Illegal global '{k}' of type '{type(v).__name__}' at class level.\n\n"
                    f"Qt objects and heavy resources MUST NOT be created at import time (at class level globals).\n\n"
                    f"Fix one of the following:\n"
                    f"  - Use lazy(lambda: ...)\n"
                    f"  - Use async_global(async_factory)\n"
                    f"  - Use init_globals\n\n"
                    f"Example:\n"
                    f"  {k} = lazy(lambda: Widget(...))"
                )

            # coroutine objects are also unsafe at class-level
            if inspect.iscoroutine(v):
                raise AppGlobalDefinitionError(
                    f"[Globals] Illegal coroutine object '{k}' defined at class level.\n\n"
                    f"Coroutine objects must not be created at import time (at class level globals).\n\n"
                    f"Fix:\n"
                    f"  {k} = async_global(async_factory)"
                )

            defs[k] = v
            ns.pop(k)

        cls = super().__new__(mcls, name, bases, ns)
        cls._definitions = defs
        return cls

    # attribute access delegates to AppGlobals (single store)
    def __getattr__(self, name: str) -> Any:
        return getattr(AppGlobals, name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(AppGlobals, name, value)

    def __delattr__(self, name: str) -> None:
        delattr(AppGlobals, name)

    # dict-like passthrough
    def __getitem__(self, key): return AppGlobals[key]
    def __setitem__(self, key, value): AppGlobals[key] = value
    def __contains__(self, key): return key in AppGlobals
    

# -----------------------------
# Base user class
# -----------------------------
class GlobalsBase(metaclass=_GlobalsMeta):
    """
    Base class for defining application-wide globals in a safe, declarative way.

    Users should subclass this class in `callbacks.py` to declare global
    variables, shared widgets, clients, caches, or state that must be
    accessible across callbacks, threads, and UI components.

    --------------------------------------------------------------------
    🧠 Core Concept
    --------------------------------------------------------------------
    - This class does NOT store data itself.
    - All attributes defined here are ultimately stored in **AppGlobals**,
    which is the single, thread-safe global store of the application.
    - This class provides a clean, IDE-friendly interface on top of AppGlobals.

    --------------------------------------------------------------------
    ✅ What You Can Do
    --------------------------------------------------------------------
    • Declare simple globals at class level, these are avaliable before startup lifecycle:
        class Globals(GlobalsBase):
            counter = 0
            app_name = "My App"

    • Declare lazy (deferred) globals using `lazy(...)`, these are avaliable after startup lifecycle:
        class Globals(GlobalsBase):
            plot = lazy(lambda: Plot(...))

    • Declare async globals using `async_global(...)`, these are avaliable after startup lifecycle:
        class Globals(GlobalsBase):
            client = async_global(create_client_async)

    • Perform UI-safe initialization in `init_globals()`, these are avaliable after startup lifecycle:
        class Globals(GlobalsBase):
            def init_globals(self):
                display("main", self.plot.widget)

    --------------------------------------------------------------------
    ⚠️ Important Rules
    --------------------------------------------------------------------
    • Do NOT create Qt widgets directly at class level.
    This will trigger a warning.
    Use `lazy(lambda: ...)` instead.

    • Do NOT override `__init__`.
    Use `init_globals()` for initialization logic.

    • Do NOT call `init_globals()` yourself.
    It is called automatically by the framework after the UI is ready.

    --------------------------------------------------------------------
    🧩 Accessing Globals
    --------------------------------------------------------------------
    Anywhere in your code:
        Globals.plot
        Globals.client
        Globals["counter"]

    All of these refer to the same underlying AppGlobals store.

    --------------------------------------------------------------------
    This class exists to give you:
    ✔ a clean API
    ✔ IDE autocomplete
    ✔ safe Qt timing
    ✔ zero boilerplate
    """

    # attribute access delegates to AppGlobals (single store)
    def __getattr__(self, name: str) -> Any:
        return getattr(AppGlobals, name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(AppGlobals, name, value)

    def __delattr__(self, name: str) -> None:
        delattr(AppGlobals, name)

    # dict-like passthrough
    def __getitem__(self, key): return AppGlobals[key]
    def __setitem__(self, key, value): AppGlobals[key] = value
    def __contains__(self, key): return key in AppGlobals
    def keys(self): return AppGlobals.keys()
    def items(self): return AppGlobals.items()

    # user hook
    def init_globals(self):
        """
        User-defined initialization hook for globals.

        This method is called automatically by the framework **after**:
        - the QApplication is running
        - startup lifecycle executed
        - the entire UI layout is built
        - Output and Info registries are ready

        --------------------------------------------------------------------
        ✅ What This Method Is For
        --------------------------------------------------------------------
        • Creating or finalizing global objects
        • Displaying widgets using `display(...)`
        • Wiring signals
        • Performing one-time setup logic
        • Assigning additional globals dynamically:
            self.some_value = 123

        --------------------------------------------------------------------
        ✅ Thread & UI Safety
        --------------------------------------------------------------------
        • This method runs in the **Qt main thread**
        • It is safe to create widgets and update UI here
        • It may be declared as `async def` if needed

        --------------------------------------------------------------------
        ⚠️ What NOT To Do
        --------------------------------------------------------------------
        • Do NOT block the UI (no `time.sleep`)
        • Do NOT spawn threads here for UI work
        • Do NOT assume this runs only once (it runs on reload too)

        --------------------------------------------------------------------
        Async Example:
            async def init_globals(self):
                data = await fetch_async_data()
                self.data = data

        Sync Example:
            def init_globals(self):
                display("main", self.plot.widget)
        """
        pass

    @classmethod
    def materialize_into_appglobals(
        cls,
        instance: "GlobalsBase",
        *,
        allow_override: bool = False
    ) -> Dict[str, Any]:
        """
        Internal framework hook that materializes class-level global
        declarations into the AppGlobals store.
        --------------------------------------------------------------------
        This method is called automatically by the UI builder
        and should not be invoked manually by user code.
        """
        created_sync = []
        pending_async: Dict[str, AsyncLazy] = {}

        for name, decl in getattr(cls, "_definitions", {}).items():
            if (not allow_override) and hasattr(AppGlobals, name):
                continue

            if isinstance(decl, Lazy):
                val = decl.factory()
                setattr(AppGlobals, name, val)
                created_sync.append(name)

            elif isinstance(decl, AsyncLazy):
                pending_async[name] = decl  # await later

            else:
                # simple values are fine
                setattr(AppGlobals, name, decl)
                created_sync.append(name)

        return {"created_sync": created_sync, "pending_async": pending_async}


# convenience exports
__all__ = ["GlobalsBase", "lazy", "async_global"]
