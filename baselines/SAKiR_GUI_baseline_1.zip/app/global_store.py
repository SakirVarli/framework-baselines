# app/global_store.py
import asyncio
import inspect
from threading import RLock
from typing import Callable, Optional, List, Tuple

class AppGlobals:
    """
    Thread-safe dynamic global store shared between callbacks and modules.

    This class acts as a central registry for widgets, state variables,
    and runtime objects that need to be shared across different parts
    of the application — while remaining thread-safe, reload-friendly,
    and lifecycle-aware.

    ------------------------------------------------------------
    📦  Basic Usage
    ------------------------------------------------------------
        from app.global_store import AppGlobals

        # Store and retrieve any object
        AppGlobals.status_label = QLabel("Running")
        AppGlobals["theme"] = "dark"
        print(AppGlobals.theme, AppGlobals["theme"])  # both valid

        # Iterate over stored globals
        for name, value in AppGlobals.items():
            print(name, type(value))

    ------------------------------------------------------------
    🔒  Thread-Safe Design
    ------------------------------------------------------------
    All attribute and dict-like operations are protected by an internal
    RLock. This ensures that GUI updates, background threads, and async
    tasks can safely read/write global data concurrently.

    ------------------------------------------------------------
    ⚙️  Persistence and Auto-Merge
    ------------------------------------------------------------
    - Clearing the store via `clear()` only removes dynamic globals,
    not lifecycle hooks.
    - Updating via `update()` or merging another AppGlobals instance
    automatically merges lifecycle callbacks without duplication.
    - Lifecycle hooks remain active even if AppGlobals is reloaded.

    ------------------------------------------------------------
    🧠  Summary of Features
    ------------------------------------------------------------
    • Thread-safe global key-value store (with RLock)
    • Dual access style (dot-notation or dict-like)
    • Auto-preserved lifecycle events (startup & close)
    • Priority-based execution order for lifecycle hooks
    • Support for both sync and async functions
    • Safe merging & persistence across reloads
    • Ideal for sharing widgets, threads, signals, logs, configs

    ------------------------------------------------------------
    🛠️  Common Patterns
    ------------------------------------------------------------
        AppGlobals.log_widget.append("Task started")
        AppGlobals.worker_thread.start()
        AppGlobals.current_user = "admin"
        AppGlobals.chart_widget.plot(data)

    ------------------------------------------------------------
    📚  Methods Overview
    ------------------------------------------------------------
    - keys()                 → list of stored keys
    - items()                → iterator of (key, value)
    - clear()                → remove all stored globals (keeps hooks)
    - update(dict|AppGlobals)→ merge data and lifecycle hooks

    ------------------------------------------------------------
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init_internal_state()
        return cls._instance

    # ---------- Internal Init ----------
    def _init_internal_state(self):
        # use low-level access to avoid recursion during bootstrapping
        self._data = object.__getattribute__(self, "_data") if "_data" in self.__dict__ else {}
        self._lock = object.__getattribute__(self, "_lock") if "_lock" in self.__dict__ else RLock()

    # ---------- Attribute Access ----------
    def __getattr__(self, name):
        with self._lock:
            if name in self._data:
                return self._data[name]
            raise AttributeError(f"Global '{name}' not found")

    def __setattr__(self, name, value):
        if name in (
            "_data", "_lock", "_instance",
        ):
            object.__setattr__(self, name, value)
        else:
            with self._lock:
                self._data[name] = value

    def __delattr__(self, name):
        with self._lock:
            if name in self._data:
                del self._data[name]
            else:
                raise AttributeError(f"No such global: {name}")

    # ---------- Dict-like Access ----------
    def __getitem__(self, key):
        with self._lock:
            return self._data[key]

    def __setitem__(self, key, value):
        with self._lock:
            self._data[key] = value

    def __contains__(self, key):
        with self._lock:
            return key in self._data

    def keys(self):
        with self._lock:
            return list(self._data.keys())

    def items(self):
        with self._lock:
            return dict(self._data).items()

    def clear(self):
        """Clear data but preserve lifecycle callbacks."""
        with self._lock:
            self._data.clear()

    def update(self, new_data: dict):
        """
        Thread-safe update of globals.

        If another AppGlobals-like object is passed, lifecycle
        hooks from that object are merged automatically.
        """
        with self._lock:
            # If merging another AppGlobals instance
            if isinstance(new_data, self.__class__):
                self._data.update(new_data._data)
            else:
                self._data.update(new_data)

    def _merge_callbacks(self, base: List[Tuple[int, Callable]], incoming: List[Tuple[int, Callable]]):
        """Avoid duplicate callbacks while merging."""
        existing_funcs = {f for _, f in base}
        for p, f in incoming:
            if f not in existing_funcs:
                base.append((p, f))
        base.sort(key=lambda x: -x[0])

    def __repr__(self):
        return f"<AppGlobals keys={list(self._data.keys())}>"

# Singleton instance
AppGlobals = AppGlobals()
