"""The common complete-message parsing transformation, without storage work."""
from __future__ import annotations

import time

from .parser_runtime import Direction, ParseResult
from .store import EventInput


def parse_capture(envelope, config, parser, tx_header_decoder):
    direction = Direction(str(envelope.get("direction", "RX")))
    message = bytes(envelope.get("message", b""))
    header = bytes(envelope.get("header", b""))
    fields = dict(envelope.get("header_fields", {}))
    metadata_error = ""
    ethernet = config["protocol"] == "raw_ethernet"
    if ethernet:
        from .ethernet import decode_ethernet
        header, ethernet_fields, metadata_error = decode_ethernet(message)
        fields["ethernet"] = ethernet_fields
        capture = fields.setdefault("capture", {})
        capture.setdefault("origin", "send" if direction == Direction.TX else "capture")
        capture.setdefault("direction", "outgoing" if direction == Direction.TX else "unknown")
        capture.setdefault("adapter_id", config["transport"]["adapter_id"])
        capture.setdefault("captured_length", len(message))
        capture.setdefault("original_length", len(message))
        capture["truncated"] = capture["captured_length"] < capture["original_length"]
        if capture["truncated"]:
            metadata_error = "; ".join(filter(None, (metadata_error, "Ethernet packet was truncated during capture")))
        if metadata_error:
            capture["decode_error"] = metadata_error
    if direction == Direction.TX and envelope.get("kind") != "framing_error" and tx_header_decoder.mode == "header_length":
        header = message[:tx_header_decoder.header_size]
        fields = {}
        try:
            fields = tx_header_decoder.decode_header_fields(header)
        except Exception as error:
            metadata_error = f"TX header decoding failed: {type(error).__name__}: {error}"[:1000]
    if envelope.get("kind") == "framing_error":
        parsed = ParseResult("FramingError", message, False, "error", error=str(envelope.get("error", "Framing error")))
    else:
        parsed = parser.parse(message, direction)
    event = EventInput(
        timestamp_ns=int(envelope.get("timestamp_ns", time.time_ns())),
        completed_timestamp_ns=int(envelope.get("completed_timestamp_ns", envelope.get("timestamp_ns", time.time_ns()))),
        capture_sequence=int(envelope.get("capture_sequence", 0)), direction=direction,
        protocol=config["protocol"], protocol_label=config.get("protocol_label", ""),
        message=message, header=header, header_fields=fields, session_id=config["id"],
        connection_id=str(envelope.get("connection_id", "")),
        peer=(fields["ethernet"].get("destination_mac" if direction == Direction.TX else "source_mac", "")
              if ethernet else str(envelope.get("peer", ""))),
        raw_frame=message if ethernet and config["transport"]["retain_raw_frames"] else None)
    return event, parsed, metadata_error
