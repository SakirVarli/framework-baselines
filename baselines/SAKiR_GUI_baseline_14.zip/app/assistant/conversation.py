"""Selectable rich text with rounded message and code surfaces."""
from PyQt5 import QtCore, QtGui, QtWidgets


class Conversation(QtWidgets.QTextBrowser):
    # QTextDocument supports table padding but not CSS border-radius. Retain
    # its text layout and selection, and paint the marked table surfaces here.
    SURFACES = {"#f2f4f7": 12, "#f3f5f8": 10}

    def __init__(self, parent=None):
        super().__init__(parent)
        self._surfaces = []

    def setHtml(self, text):
        self._surfaces = []
        super().setHtml(text)
        self._collect_surfaces(self.document().rootFrame())
        self.viewport().update()

    def _collect_surfaces(self, frame):
        for child in frame.childFrames():
            fmt = child.frameFormat()
            brush = fmt.background()
            color = brush.color().name()
            if brush.style() != QtCore.Qt.NoBrush and color in self.SURFACES:
                self._surfaces.append((child, QtGui.QColor(color), self.SURFACES[color]))
                fmt.setBackground(QtGui.QBrush(QtCore.Qt.NoBrush))
                if isinstance(child, QtGui.QTextTable):
                    child.setFormat(fmt.toTableFormat())
                else:
                    child.setFrameFormat(fmt)
            self._collect_surfaces(child)

    def surface_rect(self, frame):
        rect = self.document().documentLayout().frameBoundingRect(frame)
        if isinstance(frame, QtGui.QTextTable):
            # Qt reports the table origin at the first cell's content origin.
            cell = frame.cellAt(0, 0).format().toTableCellFormat()
            rect.translate(-cell.leftPadding(), -cell.topPadding())
        return rect

    def paintEvent(self, event):
        painter = QtGui.QPainter(self.viewport())
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtCore.Qt.NoPen)
        offset = QtCore.QPointF(-self.horizontalScrollBar().value(), -self.verticalScrollBar().value())
        for frame, color, radius in self._surfaces:
            rect = self.surface_rect(frame).translated(offset)
            if rect.intersects(QtCore.QRectF(event.rect())):
                painter.setBrush(color)
                painter.drawRoundedRect(rect, radius, radius)
        painter.end()
        super().paintEvent(event)
