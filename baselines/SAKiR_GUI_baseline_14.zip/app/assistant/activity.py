"""A GUI-thread version of the Designer console's working indicator."""
import random

from PyQt5 import QtCore, QtGui, QtWidgets

from app.activity import ACTIVITY_ANIMATION, WORKING_PHRASES


class WorkingIndicator(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAccessibleName("Assistant working")
        self._running = False
        self._frame = 0
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        prefix = QtWidgets.QLabel("[working]")
        prefix.setStyleSheet("color: #996513; font-size: 9pt;")
        layout.addWidget(prefix)
        self.phrase = QtWidgets.QLabel()
        self.phrase.setTextFormat(QtCore.Qt.PlainText)
        self.phrase.setStyleSheet("color: #697180; font-size: 9pt;")
        layout.addWidget(self.phrase)
        self.animation = QtWidgets.QLabel()
        self.animation.setAccessibleName("Working animation")
        self.animation.setTextFormat(QtCore.Qt.PlainText)
        self.animation.setFont(QtGui.QFont("Consolas", 10))
        self.animation.setStyleSheet("color: #996513; font-family: Consolas; font-size: 10pt;")
        metrics = self.animation.fontMetrics()
        self.animation.setFixedWidth(max(metrics.horizontalAdvance(frame) for frame, _ in ACTIVITY_ANIMATION) + 2)
        self.animation.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(self.animation)
        self.timer = QtCore.QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.advance)
        self.hide()

    def set_running(self, running):
        if running == self._running:
            return
        self._running = running
        if running:
            self.phrase.setText(random.choice(WORKING_PHRASES))
            self._frame = 0
            self._paint_frame()
        else:
            self.timer.stop()
        self.setVisible(running)

    def _paint_frame(self):
        frame, delay = ACTIVITY_ANIMATION[self._frame]
        self.animation.setText(frame)
        self.timer.setInterval(round(delay * 1000))
        if self._running and self.isVisible():
            self.timer.start()

    def advance(self):
        if not self._running or not self.isVisible():
            return
        self._frame = (self._frame + 1) % len(ACTIVITY_ANIMATION)
        self._paint_frame()

    def showEvent(self, event):
        super().showEvent(event)
        if self._running:
            self._paint_frame()

    def hideEvent(self, event):
        self.timer.stop()
        super().hideEvent(event)
