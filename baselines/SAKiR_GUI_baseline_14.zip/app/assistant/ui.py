"""Native PyQt assistant, connection settings, capability browser and review."""
import copy
from dataclasses import asdict
import html
import json
import re
from pathlib import Path
import threading

from PyQt5 import QtCore, QtGui, QtWidgets

from . import changes
from .appearance import ComboBox, apply_theme, icon
from .activity import WorkingIndicator
from .conversation import Conversation
from .policy import AssistantError, digest, redact
from .provider import ChatProvider
from .storage import Settings


def show_error(parent, exc):
    QtWidgets.QMessageBox.warning(parent, "Assistant", str(exc))


class SettingsDialog(QtWidgets.QDialog):
    probe_finished = QtCore.pyqtSignal(object)

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.setWindowTitle("Assistant Settings")
        apply_theme(self)
        self.resize(690, 650)
        self.widgets = {}
        self.profile = copy.deepcopy(controller.settings.capability_profile)
        self.cancel = threading.Event()
        self.provider = None
        outer = QtWidgets.QVBoxLayout(self)
        notice = QtWidgets.QLabel("Configuration: app/data/assistant/assistant.json\nAssistant files stay inside this framework folder.")
        notice.setWordWrap(True)
        outer.addWidget(notice)
        tabs = QtWidgets.QTabWidget()
        outer.addWidget(tabs)
        connection, limits, privacy = [QtWidgets.QWidget() for _ in range(3)]
        tabs.addTab(connection, "Connection")
        tabs.addTab(limits, "Limits && Compatibility")
        tabs.addTab(privacy, "History && Permissions")
        conn = QtWidgets.QFormLayout(connection)
        self.text(conn, "base_url", "Server base URL", "http://server:8000/v1")
        self.text(conn, "model", "Model ID", "Exact ID returned by your server")
        self.combo(conn, "auth_mode", "Authentication", [("No authentication", "none"), ("Session key", "session"),
                   ("Environment variable", "environment"), ("Windows Credential Manager", "windows")])
        self.key = QtWidgets.QLineEdit(controller.credentials.session)
        self.key.setEchoMode(QtWidgets.QLineEdit.Password)
        self.key.setPlaceholderText("Enter a key; never written to assistant.json")
        conn.addRow("API key", self.key)
        self.text(conn, "key_env", "Key environment variable")
        self.text(conn, "credential_ref", "Windows credential reference", "Auto-generated when a key is saved")
        self.text(conn, "ca_bundle", "Custom CA certificate", "Optional path to a trusted CA PEM file")
        self.check(conn, "streaming", "Stream responses")
        probe_row = QtWidgets.QWidget()
        buttons = QtWidgets.QHBoxLayout(probe_row)
        self.list_button = QtWidgets.QPushButton("List models")
        self.probe_button = QtWidgets.QPushButton("Test tools && streaming")
        buttons.addWidget(self.list_button)
        buttons.addWidget(self.probe_button)
        conn.addRow(probe_row)
        self.models = ComboBox()
        self.models.setPlaceholderText("Models returned by the server")
        self.models.activated.connect(lambda i: self.widgets["model"].setText(self.models.itemText(i)))
        conn.addRow("Discovered models", self.models)
        self.probe_status = QtWidgets.QPlainTextEdit()
        self.probe_status.setReadOnly(True)
        self.probe_status.setMaximumHeight(140)
        self.probe_status.setPlainText(json.dumps(self.profile, indent=2) if self.profile else "Connection not tested yet. Model IDs can also be entered manually.")
        conn.addRow("Compatibility", self.probe_status)
        form = QtWidgets.QFormLayout(limits)
        self.combo(form, "token_parameter", "Output limit parameter", [("max_tokens", "max_tokens"), ("max_completion_tokens", "max_completion_tokens")])
        for key, label, low, high in (("timeout", "Request timeout (seconds)", 5, 600), ("max_tokens", "Maximum output tokens", 256, 65536),
                                    ("context_chars", "Context budget (characters)", 8000, 2000000), ("max_rounds", "Maximum model rounds", 1, 40),
                                    ("max_tool_calls", "Maximum tool calls", 1, 100), ("task_timeout", "Task deadline (seconds)", 30, 3600),
                                    ("file_timeout", "File-reader timeout (seconds)", 1, 120), ("preview_rows", "Preview rows", 1, 200),
                                    ("result_chars", "Tool-result character limit", 1000, 64000)):
            spin = QtWidgets.QSpinBox()
            spin.setRange(low, high)
            spin.setValue(getattr(controller.settings, key))
            self.widgets[key] = spin
            form.addRow(label, spin)
        hint = QtWidgets.QLabel("Context is measured conservatively in characters. Server token limits still apply.\nDisable streaming if your server supports tools only in complete responses.")
        hint.setWordWrap(True)
        form.addRow(hint)
        form = QtWidgets.QFormLayout(privacy)
        self.check(form, "save_history", "Save visible conversation history locally")
        spin = QtWidgets.QSpinBox()
        spin.setRange(1, 100)
        spin.setValue(controller.settings.history_sessions)
        self.widgets["history_sessions"] = spin
        form.addRow("Retained sessions", spin)
        private = QtWidgets.QLabel(str(controller.store.private))
        private.setWordWrap(True)
        private.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        form.addRow("Assistant data folder", private)
        clear = QtWidgets.QPushButton("Delete conversation history")
        clear.clicked.connect(self.clear_history)
        form.addRow(clear)
        policy = QtWidgets.QLabel("Framework Python: read only\nCallbacks and externals: previewed project edits\nConfiguration JSON: validated edits\nGenerated stubs: maintained by the framework\nNo shell or arbitrary code execution tool\nApply & Reload executes reviewed project Python.\nAssistant data is excluded from baseline exports.\nOnly attached external files can be inspected outside the project.")
        policy.setWordWrap(True)
        form.addRow("Permissions", policy)
        self.buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.save)
        self.buttons.rejected.connect(self.reject)
        outer.addWidget(self.buttons)
        self.list_button.clicked.connect(lambda: self.test("models"))
        self.probe_button.clicked.connect(lambda: self.test("probe"))
        self.probe_finished.connect(self.test_finished)
        self.finished.connect(self.stop_probe)
        self.widgets["auth_mode"].currentIndexChanged.connect(self.update_auth)
        self.update_auth()

    def update_auth(self, *_):
        mode = self.widgets["auth_mode"].currentData()
        self.key.setEnabled(mode in {"session", "windows"})
        self.widgets["key_env"].setEnabled(mode == "environment")
        self.widgets["credential_ref"].setEnabled(mode == "windows")

    def text(self, form, key, label, placeholder=""):
        widget = QtWidgets.QLineEdit(getattr(self.controller.settings, key))
        widget.setPlaceholderText(placeholder)
        self.widgets[key] = widget
        form.addRow(label, widget)

    def combo(self, form, key, label, items):
        widget = ComboBox()
        for title, value in items:
            widget.addItem(title, value)
        widget.setCurrentIndex(max(0, widget.findData(getattr(self.controller.settings, key))))
        self.widgets[key] = widget
        form.addRow(label, widget)

    def check(self, form, key, label):
        widget = QtWidgets.QCheckBox(label)
        widget.setChecked(getattr(self.controller.settings, key))
        self.widgets[key] = widget
        form.addRow(widget)

    def collect(self):
        data = asdict(self.controller.settings)
        for key, widget in self.widgets.items():
            data[key] = widget.currentData() if isinstance(widget, QtWidgets.QComboBox) else widget.isChecked() if isinstance(widget, QtWidgets.QCheckBox) else widget.value() if isinstance(widget, QtWidgets.QSpinBox) else widget.text().strip()
        data["capability_profile"] = self.profile
        return Settings(**data)

    def key_for(self, settings, save=False):
        if settings.auth_mode == "session":
            self.controller.credentials.session = self.key.text()
        elif settings.auth_mode == "windows" and self.key.text():
            if not save:
                return self.key.text()
            settings.credential_ref = settings.credential_ref or "SAKiR-Assistant-" + digest(settings.base_url.encode())[:24]
            self.controller.credentials._windows(settings.credential_ref, self.key.text())
        return self.controller.credentials.key(settings)

    def save(self):
        try:
            settings = self.collect()
            settings.validate(connection=bool(settings.base_url or settings.model))
            if settings.auth_mode in {"session", "windows"}:
                self.key_for(settings, save=True)
            profile = settings.capability_profile
            if profile and (profile.get("model"), profile.get("base_url"), profile.get("streaming")) != (settings.model, settings.base_url, settings.streaming):
                settings.capability_profile = None
            self.controller.store.save_settings(settings)
            self.controller.settings = settings
            self.controller.settings_error = ""
            self.controller.activity.emit("settings", settings.model)
            self.accept()
        except Exception as exc:
            show_error(self, exc)

    def test(self, kind):
        try:
            settings = self.collect()
            if kind == "models" and not settings.model:
                settings.model = "discovery"
            settings.validate()
            key = self.key_for(settings)
        except Exception as exc:
            show_error(self, exc)
            return
        self.cancel = threading.Event()
        self.list_button.setEnabled(False)
        self.probe_button.setEnabled(False)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(False)
        self.probe_status.setPlainText("Checking the configured server…")
        def worker():
            try:
                self.provider = ChatProvider(settings, key)
                data = self.provider.models() if kind == "models" else self.provider.probe(self.cancel)
                result = {"kind": kind, "data": data}
            except Exception as exc:
                result = {"error": str(exc).replace(key, "<redacted>"), "code": getattr(exc, "code", "CONNECTION_ERROR"),
                          "profile": {"base_url": settings.base_url, "model": settings.model,
                                      "streaming": settings.streaming, "tool_round_trip": False}}
            finally:
                if self.provider:
                    try:
                        self.provider.dispose()
                    except Exception:
                        pass
                self.provider = None
            try:
                self.probe_finished.emit(result)
            except RuntimeError:
                pass
        threading.Thread(target=worker, daemon=True, name="assistant-connection-test").start()

    def test_finished(self, result):
        self.list_button.setEnabled(True)
        self.probe_button.setEnabled(True)
        self.buttons.button(QtWidgets.QDialogButtonBox.Save).setEnabled(True)
        self.probe_status.setPlainText(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("kind") == "models":
            self.models.clear()
            self.models.addItems(result["data"])
        elif result.get("kind") == "probe":
            self.profile = result["data"]
        elif result.get("code") == "TOOLS_UNSUPPORTED":
            self.profile = result["profile"]

    def stop_probe(self, *_):
        self.cancel.set()
        if self.provider:
            threading.Thread(target=self.provider.close, daemon=True).start()

    def clear_history(self):
        self.controller.store.clear_history()
        self.controller.new_session()
        self.probe_status.setPlainText("Conversation history deleted. Recovery journals retained.")


class Composer(QtWidgets.QPlainTextEdit):
    send_requested = QtCore.pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter) and not event.modifiers() & QtCore.Qt.ShiftModifier:
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


class ReviewDialog(QtWidgets.QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.proposal = controller.proposal
        self.setWindowTitle("Review Assistant Changes")
        self.resize(1050, 750)
        outer = QtWidgets.QVBoxLayout(self)
        report, diff = controller.review()
        tabs = QtWidgets.QTabWidget()
        outer.addWidget(tabs)
        summary = QtWidgets.QPlainTextEdit()
        summary.setReadOnly(True)
        summary.setPlainText(self.proposal.summary + "\n\nAffected files:\n" + "\n".join(e.path for e in self.proposal.edits)
                             + "\n\nThe diff includes any existing unsaved designer work.\nApply & Reload saves these files and reloads project Python.")
        tabs.addTab(summary, "Summary")
        code = QtWidgets.QPlainTextEdit()
        code.setReadOnly(True)
        code.setFont(QtGui.QFont("Consolas", 10))
        code.setPlainText(diff)
        tabs.addTab(code, "Code && Configuration Diff")
        validation = QtWidgets.QPlainTextEdit()
        validation.setReadOnly(True)
        validation.setPlainText("Checks:\n" + "\n".join(report["checks"]) + "\n\n" + ("No blocking errors." if report["ok"] else "Apply blocked.")
                                + "\n" + "\n".join(i["severity"].upper() + ": " + i["message"] for i in report["issues"]))
        tabs.addTab(validation, "Validation")
        row = QtWidgets.QHBoxLayout()
        preview = QtWidgets.QPushButton("Layout Preview")
        preview.clicked.connect(self.preview)
        row.addWidget(preview)
        row.addStretch()
        for label, reload in (("Save Only", False), ("Apply && Reload", True)):
            button = QtWidgets.QPushButton(label)
            button.setEnabled(report["ok"] and not controller.busy)
            button.clicked.connect(lambda _, reload=reload: self.apply(reload))
            row.addWidget(button)
        close = QtWidgets.QPushButton("Close")
        close.clicked.connect(self.reject)
        row.addWidget(close)
        outer.addLayout(row)

    def preview(self):
        from app.config_designer.document import DesignerDocument
        from app.config_designer.window import PreviewDialog
        config = self.controller.snapshot()["config"]
        for edit in self.proposal.edits:
            if edit.path == "app/data/config.json":
                config = json.loads(edit.content)
        PreviewDialog(DesignerDocument.from_config(config), self).exec_()

    def apply(self, reload):
        try:
            if self.controller.proposal is not self.proposal:
                raise AssistantError("STALE_PROPOSAL", "A new proposal replaced this review.")
            self.controller.apply(self.proposal.fingerprint, reload)
            self.accept()
        except Exception as exc:
            show_error(self, exc)


class AssistantWindow(QtWidgets.QMainWindow):
    def __init__(self, controller):
        # A QWidget parent creates a native owner on Windows, which excludes
        # the window from normal task switching. The controller owns lifetime.
        super().__init__(None, QtCore.Qt.Window)
        self.setWindowTitle("SAKiR Assistant")
        self.setObjectName("sakirAssistantWindow")
        self.setWindowIcon(controller.window.windowIcon())
        self.setAttribute(QtCore.Qt.WA_QuitOnClose, False)
        self.controller = controller
        self.resize(1180, 820)
        self.setMinimumSize(680, 500)
        apply_theme(self)
        self.visible_messages = copy.deepcopy(controller.history)
        self.streaming_text = ""
        self.data_preview = None
        self._sidebar_preference = True
        self._sessions = {}
        content = QtWidgets.QWidget()
        content.setObjectName("assistantSurface")
        self.setCentralWidget(content)
        shell = QtWidgets.QHBoxLayout(content)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)

        self.sidebar = QtWidgets.QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(248)
        side = QtWidgets.QVBoxLayout(self.sidebar)
        side.setContentsMargins(16, 24, 16, 16)
        side.setSpacing(10)
        side.addWidget(self.label("SAKiR  /  Assistant", "brand"))
        side.addSpacing(18)
        self.new_button = self.button("New chat", self.new, "newChat", "new")
        self.new_button.setToolTip("New chat (Ctrl+N)")
        side.addWidget(self.new_button)
        side.addWidget(self.button("Saved drafts", self.drafts, "navigation", "document"))
        side.addWidget(self.button("Capabilities", self.capabilities, "navigation", "folder"))
        side.addSpacing(18)
        side.addWidget(self.label("CONVERSATIONS", "eyebrow"))
        self.session_search = QtWidgets.QLineEdit()
        self.session_search.setObjectName("sessionSearch")
        self.session_search.setPlaceholderText("Search chats…")
        self.session_search.setAccessibleName("Search conversations")
        self.session_search.textChanged.connect(self.filter_sessions)
        side.addWidget(self.session_search)
        self.session_list = QtWidgets.QListWidget()
        self.session_list.setObjectName("sessions")
        self.session_list.setAccessibleName("Saved conversations")
        self.session_list.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.session_list.itemClicked.connect(self.load_session)
        side.addWidget(self.session_list, 1)
        self.session_notice = self.label("Your chats will appear here.", "muted")
        side.addWidget(self.session_notice)
        side.addWidget(self.button("Restore previous changes", self.restore, "navigation", "history"))
        side.addWidget(self.button("Settings", self.settings, "navigation", "settings"))
        project = self.label(controller.policy.root.name, "muted")
        project.setToolTip(str(controller.policy.root))
        side.addWidget(project)
        shell.addWidget(self.sidebar)

        chat = QtWidgets.QWidget()
        chat.setObjectName("chatPage")
        outer = QtWidgets.QVBoxLayout(chat)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        shell.addWidget(chat, 1)
        header = QtWidgets.QFrame()
        header.setObjectName("header")
        head = QtWidgets.QHBoxLayout(header)
        head.setContentsMargins(20, 14, 24, 14)
        toggle = self.button("", self.toggle_sidebar, "", "panel")
        toggle.setAccessibleName("Toggle conversation sidebar")
        toggle.setToolTip("Toggle sidebar (Ctrl+B)")
        head.addWidget(toggle)
        self.chat_title = self.label("New chat", "brand")
        self.chat_title.setMinimumWidth(0)
        self.chat_title.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        head.addWidget(self.chat_title, 1)
        self.model = self.label(controller.settings.model or "Set up a model", "model")
        self.model.setMaximumWidth(240)
        self.model.setToolTip(controller.settings.model or "Choose a model in Settings")
        head.addWidget(self.model)
        head.addWidget(self.button("", self.settings, "", "settings"))
        head.itemAt(head.count() - 1).widget().setToolTip("Connection settings")
        head.itemAt(head.count() - 1).widget().setAccessibleName("Connection settings")
        outer.addWidget(header)

        # Keep long responses and the composer within a comfortable reading width.
        reading_row = QtWidgets.QHBoxLayout()
        reading_row.setContentsMargins(24, 0, 24, 0)
        reading_row.addStretch(1)
        reading = QtWidgets.QWidget()
        reading.setMaximumWidth(880)
        reading.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        body = QtWidgets.QVBoxLayout(reading)
        body.setContentsMargins(0, 0, 0, 16)
        body.setSpacing(12)
        reading_row.addWidget(reading, 10)
        reading_row.addStretch(1)
        outer.addLayout(reading_row, 1)
        self.pages = QtWidgets.QStackedWidget()
        self.pages.addWidget(self.build_welcome())
        self.conversation = Conversation()
        self.conversation.setObjectName("conversation")
        self.conversation.setAccessibleName("Assistant conversation")
        self.conversation.setOpenExternalLinks(False)
        self.conversation.setOpenLinks(False)
        self.conversation.anchorClicked.connect(self.open_source)
        self.conversation.document().setDocumentMargin(16)
        self.conversation.document().setDefaultStyleSheet(
            "body { color: #252a34; font-family: 'Segoe UI'; font-size: 11pt; }"
            "p { margin-top: 8px; margin-bottom: 12px; line-height: 150%; }"
            "pre { color: #33455e; white-space: pre-wrap; font-family: Consolas; margin: 0; }"
            "code { font-family: Consolas; color: #33455e; }"
            "a { color: #2563ad; text-decoration: none; }"
            "th, td { padding: 8px; } h1, h2, h3 { color: #202630; }"
        )
        self.pages.addWidget(self.conversation)
        body.addWidget(self.pages, 1)
        self.status = self.label(("Settings need repair: " + controller.settings_error) if controller.settings_error else "Ready", "status")
        self.status.setWordWrap(True)
        status_row = QtWidgets.QHBoxLayout()
        status_row.setSpacing(14)
        self.working_indicator = WorkingIndicator()
        status_row.addWidget(self.working_indicator)
        status_row.addWidget(self.status, 1)
        body.addLayout(status_row)
        self.review_bar = QtWidgets.QFrame()
        self.review_bar.setObjectName("reviewBar")
        review_row = QtWidgets.QHBoxLayout(self.review_bar)
        self.review_label = self.label("Ready for your review", "muted")
        self.review_label.setMinimumWidth(0)
        self.review_label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        review_row.addWidget(self.review_label, 1)
        self.review_button = self.button("Review changes", self.review, "primary")
        self.action_button = self.button("Review action", self.review_action)
        self.data_button = self.button("Data preview", self.preview_data)
        for button in (self.review_button, self.action_button, self.data_button):
            review_row.addWidget(button)
        body.addWidget(self.review_bar)

        composer = QtWidgets.QFrame()
        composer.setObjectName("composer")
        composer_layout = QtWidgets.QVBoxLayout(composer)
        composer_layout.setContentsMargins(14, 12, 14, 10)
        composer_layout.setSpacing(8)
        self.attachments = QtWidgets.QListWidget()
        self.attachments.setObjectName("attachments")
        self.attachments.setMaximumHeight(70)
        self.attachments.setAccessibleName("Attached files")
        self.attachments.setToolTip("Double-click to remove an attachment.")
        self.attachments.itemDoubleClicked.connect(self.remove_attachment)
        composer_layout.addWidget(self.attachments)
        self.sync_attachments(sorted(map(str, controller.policy.attachments)))
        self.input = Composer()
        self.input.setObjectName("request")
        self.input.setAccessibleName("Assistant request")
        self.input.setPlaceholderText("Ask anything about your project, or describe a change…")
        self.input.setMinimumHeight(58)
        self.input.setMaximumHeight(150)
        self.input.send_requested.connect(self.send)
        self.input.textChanged.connect(self.resize_composer)
        self.resize_composer()
        composer_layout.addWidget(self.input)
        footer = QtWidgets.QHBoxLayout()
        attach = self.button("", self.attach, "", "attach")
        attach.setToolTip("Attach files")
        attach.setAccessibleName("Attach files")
        footer.addWidget(attach)
        self.intent = ComboBox()
        self.intent.addItems(["Explain / Inspect", "Create Changes"])
        self.intent.setAccessibleName("Assistant mode")
        self.intent.setToolTip("Create Changes stages edits for your review before applying.")
        footer.addWidget(self.intent)
        footer.addStretch(1)
        self.stop_button = self.button("Stop", controller.stop, "stop")
        footer.addWidget(self.stop_button)
        self.send_button = self.button("Send", self.send, "primary", "send")
        self.send_button.setIcon(icon("send", "#ffffff"))
        footer.addWidget(self.send_button)
        composer_layout.addLayout(footer)
        body.addWidget(composer)
        info = QtWidgets.QHBoxLayout()
        self.context_label = self.label(controller.selection or "Current project", "context")
        self.context_label.setMinimumWidth(0)
        self.context_label.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
        self.context_label.setMaximumWidth(440)
        info.addWidget(self.context_label, 1)
        hint = self.label("Enter to send · Shift+Enter for a new line", "muted")
        info.addWidget(hint)
        body.addLayout(info)
        controller.activity.connect(self.on_event)
        controller.busy_changed.connect(self.busy)
        controller.proposal_changed.connect(self.update_review)
        controller.action_changed.connect(self.update_review)
        controller.attachments_changed.connect(self.sync_attachments)
        self.refresh_sessions()
        self.busy(controller.busy)
        for sequence, callback in (("Ctrl+N", self.new), ("Ctrl+B", self.toggle_sidebar),
                                   ("Ctrl+L", self.input.setFocus)):
            shortcut = QtWidgets.QShortcut(QtGui.QKeySequence(sequence), self)
            shortcut.activated.connect(callback)
        self.paint_timer = QtCore.QTimer(self)
        self.paint_timer.setInterval(80)
        self.paint_timer.timeout.connect(self.render)
        self.paint_timer.start()
        self._rendered = None
        self.render()

    @staticmethod
    def label(text, name):
        label = QtWidgets.QLabel(text)
        label.setObjectName(name)
        label.setTextFormat(QtCore.Qt.PlainText)
        return label

    @staticmethod
    def button(text, callback, name="", symbol=None):
        button = QtWidgets.QPushButton(text)
        button.setObjectName(name)
        button.setCursor(QtCore.Qt.PointingHandCursor)
        if symbol:
            button.setIcon(icon(symbol))
            button.setIconSize(QtCore.QSize(18, 18))
        button.clicked.connect(callback)
        return button

    def build_welcome(self):
        welcome = QtWidgets.QWidget()
        welcome.setObjectName("welcome")
        self.welcome = welcome
        layout = QtWidgets.QVBoxLayout(welcome)
        layout.setContentsMargins(12, 20, 12, 20)
        layout.setSpacing(14)
        layout.addStretch(2)
        layout.addWidget(self.label("YOUR PROJECT, WITH A LITTLE HELP", "eyebrow"))
        self.hero = self.label("What shall we build?", "hero")
        self.hero.setWordWrap(True)
        layout.addWidget(self.hero)
        subtitle = self.label("Explore your framework, work with data,\nor turn an idea into a reviewed change.", "subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        layout.addSpacing(20)
        suggestions = QtWidgets.QGridLayout()
        suggestions.setSpacing(10)
        self.suggestion_grid = suggestions
        self.suggestion_buttons = []
        prompts = (
            ("Explore the project", "Explain the structure of this project and its main capabilities.", 0),
            ("Build a feature", "Help me plan a new feature for this project. Ask what I would like to build.", 1),
            ("Inspect my data", "Help me inspect a data file. Ask which file I would like to attach.", 0),
            ("Understand callbacks", "Explain how callbacks work in this project, with source references.", 0),
        )
        for i, (title, prompt, mode) in enumerate(prompts):
            button = self.button(title + "  ↗", lambda checked=False, p=prompt, m=mode: self.use_prompt(p, m), "suggestion")
            button.setToolTip(prompt)
            button.setMinimumHeight(54)
            self.suggestion_buttons.append(button)
            suggestions.addWidget(button, i // 2, i % 2)
        layout.addLayout(suggestions)
        layout.addStretch(3)
        # The start screen remains usable in a short or narrow native window.
        scroll = QtWidgets.QScrollArea()
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        scroll.setWidget(welcome)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        welcome.installEventFilter(self)
        return scroll

    def eventFilter(self, watched, event):
        if watched is getattr(self, "welcome", None) and event.type() == QtCore.QEvent.Resize:
            narrow = event.size().width() < 480
            columns = 1 if narrow else 2
            for i, button in enumerate(self.suggestion_buttons):
                self.suggestion_grid.removeWidget(button)
                self.suggestion_grid.addWidget(button, i // columns, i % columns)
            self.hero.setStyleSheet("font-size: " + ("22pt;" if narrow else "28pt;"))
        return super().eventFilter(watched, event)

    def use_prompt(self, prompt, mode):
        self.intent.setCurrentIndex(mode)
        self.input.setPlainText(prompt)
        self.input.setFocus()

    def resize_composer(self):
        line_height = self.input.fontMetrics().lineSpacing()
        lines = max(self.input.blockCount(), int(self.input.document().size().height()))
        self.input.setFixedHeight(min(150, max(58, lines * line_height + 16)))

    def toggle_sidebar(self):
        self._sidebar_preference = not self.sidebar.isVisible()
        self.sidebar.setVisible(self._sidebar_preference)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "sidebar"):
            self.sidebar.setVisible(self._sidebar_preference and self.width() >= 900)
        if hasattr(self, "_rendered"):
            self._rendered = None
            self.render()

    def refresh_sessions(self):
        self._sessions = dict(self.controller.store.sessions())
        # Include the active conversation even when local history is disabled.
        if self.visible_messages:
            self._sessions[self.controller.session_id] = copy.deepcopy(self.visible_messages)
        self.session_list.clear()
        keys = list(self._sessions)
        if self.controller.session_id in keys:
            keys.remove(self.controller.session_id)
        keys.insert(0, self.controller.session_id)
        for key in keys:
            messages = self._sessions.get(key, [])
            title = next((m["content"] for m in messages if m["role"] == "user"), "New chat")
            title = " ".join(title.split())
            item = QtWidgets.QListWidgetItem(self.session_list)
            item.setText(self.session_list.fontMetrics().elidedText(title, QtCore.Qt.ElideRight, 186))
            item.setToolTip(title)
            item.setData(QtCore.Qt.UserRole, key)
            item.setData(QtCore.Qt.UserRole + 1, title)
            if key == self.controller.session_id:
                self.session_list.setCurrentItem(item)
        self.session_notice.setVisible(not self._sessions)
        self.filter_sessions(self.session_search.text())

    def filter_sessions(self, text):
        for i in range(self.session_list.count()):
            item = self.session_list.item(i)
            item.setHidden(text.casefold() not in item.data(QtCore.Qt.UserRole + 1).casefold())

    def load_session(self, item):
        key = item.data(QtCore.Qt.UserRole)
        if key == self.controller.session_id:
            return
        try:
            self.controller.new_session(copy.deepcopy(self._sessions[key]), key)
        except Exception as exc:
            self.refresh_sessions()
            show_error(self, exc)

    def update_review(self, *_):
        proposal, action = self.controller.proposal, self.controller.action
        self.review_button.setVisible(proposal is not None)
        self.review_button.setEnabled(proposal is not None and not self.controller.busy)
        self.action_button.setVisible(action is not None)
        self.action_button.setEnabled(action is not None and not self.controller.busy)
        self.data_button.setVisible(self.data_preview is not None)
        self.review_bar.setVisible(proposal is not None or action is not None or self.data_preview is not None)
        self.review_label.setText("Ready for your review" if proposal or action else "File inspected")

    def showEvent(self, event):
        super().showEvent(event)
        self.paint_timer.start()
        self.render()

    def hideEvent(self, event):
        self.paint_timer.stop()
        super().hideEvent(event)

    def render(self):
        fingerprint = repr(self.visible_messages) + self.streaming_text
        if fingerprint == self._rendered:
            return
        self._rendered = fingerprint
        self.pages.setCurrentIndex(1 if self.visible_messages or self.streaming_text else 0)
        title = next((m["content"] for m in self.visible_messages if m["role"] == "user"), "New chat")
        title = " ".join(title.split())
        self.chat_title.setText(self.chat_title.fontMetrics().elidedText(title, QtCore.Qt.ElideRight, max(120, self.width() - 650)))
        self.chat_title.setToolTip(title)
        bar = self.conversation.verticalScrollBar()
        previous = bar.value()
        follow = bar.maximum() - previous <= 36
        parts = []
        for message in self.visible_messages + ([{"role": "assistant", "content": self.streaming_text}] if self.streaming_text else []):
            text = html.escape(message["content"])
            try:
                import markdown2
                # Let the renderer escape raw HTML once, including code blocks.
                text = markdown2.markdown(message["content"], safe_mode="escape", extras=["fenced-code-blocks", "tables"])
                text = re.sub(r"<img\b[^>]*>", "", text, flags=re.I)
            except ImportError:
                text = "<pre>" + text + "</pre>"
            text = re.sub(r"<pre\b[^>]*>.*?</pre>",
                          lambda match: '<table width="100%" cellspacing="0" cellpadding="12" bgcolor="#f3f5f8">'
                          '<tr><td style="padding:12px;">' + match.group() + '</td></tr></table>', text, flags=re.S | re.I)
            role = message["role"]
            name = {"user": "You", "assistant": "SAKiR", "error": "Something went wrong"}.get(role, role.title())
            background = ' bgcolor="#f2f4f7"' if role == "user" else ""
            color = "#b43c32" if role == "error" else "#697180"
            parts.append('<table width="100%" cellspacing="0" cellpadding="14"' + background + '><tr><td style="padding:14px;">'
                         + '<p style="color:' + color + '; font-size:9pt;"><b>' + html.escape(name) + "</b></p>" + text
                         + "</td></tr></table><p style='font-size:6pt;'>&nbsp;</p>")
        self.conversation.setHtml("<html><body>" + "".join(parts) + "</body></html>")
        bar.setValue(bar.maximum() if follow else min(previous, bar.maximum()))

    def open_source(self, url):
        if url.scheme() == "sakir-help":
            try:
                if url.host() or url.query() or url.fragment() or not re.fullmatch(r"[\w.-]{1,100}", url.path()):
                    raise AssistantError("SECTION_NOT_FOUND", "Invalid handbook section link.")
                handbook = self.controller.index.handbook
                handbook.refresh()
                handbook.read(url.path())
                window = self.controller.window._open_help()
                if window is not None:
                    window.navigate_to(url.path())
            except Exception as exc:
                show_error(self, exc)
            return
        if url.scheme() != "sakir-source":
            return
        try:
            start = int(url.fragment().lstrip("L") or "1")
            revision = QtCore.QUrlQuery(url).queryItemValue("revision")
            if revision:
                task = self.controller.task_index
                if not re.fullmatch(r"[0-9a-f]{64}", revision) or task is None or task.cache.get(url.path(), {}).get("content_revision") != revision:
                    raise AssistantError("STALE_REFERENCE", "This source revision is no longer available in this session. Ask Assistant to inspect the current source again.")
                data = task.read(url.path(), start, 120)
            else:
                data = self.controller.index.read(url.path(), start, 120)
            dialog = QtWidgets.QDialog(self)
            dialog.setWindowTitle(data["path"] + ":" + str(start) + (" — " + data["state"] + " snapshot" if revision else ""))
            dialog.resize(950, 650)
            layout = QtWidgets.QVBoxLayout(dialog)
            source = QtWidgets.QPlainTextEdit()
            source.setReadOnly(True)
            source.setFont(QtGui.QFont("Consolas", 10))
            source.setPlainText(data["text"])
            layout.addWidget(source)
            dialog.exec_()
        except Exception as exc:
            show_error(self, exc)

    def on_event(self, kind, value):
        if kind == "user":
            self.visible_messages.append({"role": "user", "content": value})
            self.streaming_text = ""
            self.refresh_sessions()
        elif kind == "text_delta":
            self.streaming_text += value
        elif kind == "finished":
            response = value.get("text", "") if isinstance(value, dict) else ""
            if response or self.streaming_text:
                self.visible_messages.append({"role": "assistant", "content": response or self.streaming_text})
            self.streaming_text = ""
        elif kind in {"status", "error"}:
            self.status.setText(value)
            if kind == "error":
                if self.streaming_text:
                    self.visible_messages.append({"role": "assistant", "content": self.streaming_text})
                    self.streaming_text = ""
                self.visible_messages.append({"role": "error", "content": value})
        elif kind == "tool_result" and value["tool"] == "inspect_file" and value["result"].get("ok"):
            self.data_preview = value["result"]["data"]
            self.update_review()
        elif kind == "session":
            self.visible_messages = copy.deepcopy(value)
            self.streaming_text = ""
            self.data_preview = None
            self.input.clear()
            self.update_review()
            self.refresh_sessions()
            self.conversation.verticalScrollBar().setValue(0)
        elif kind == "selection":
            self.context_label.setText(value or "Current project")
            self.context_label.setToolTip(value or "Current project")
        elif kind == "coverage":
            self.context_label.setToolTip((self.controller.selection or "Current project") +
                f"\nKnowledge: {value['files']} files, {value['symbols']} symbols, {value['help_topics']} handbook topics" +
                "\nUnsaved overlays: " + (", ".join(value["unsaved_paths"]) or "none") +
                f"\nDiagnostics: {len(value['diagnostics'])}. Open Capabilities for details and refresh.")
        elif kind == "settings":
            self.model.setText(value or "Configure a local model")
            self.status.setText("Ready")
            self.model.setToolTip(value or "Choose a model in Settings")
            self.refresh_sessions()
        if kind == "status" and not self.controller.busy:
            self.refresh_sessions()
        self.render()

    def busy(self, value):
        self.working_indicator.set_running(value)
        if value:
            self.status.setText("Starting…")
        self.send_button.setEnabled(not value)
        self.stop_button.setEnabled(value)
        self.stop_button.setVisible(value)
        self.send_button.setVisible(not value)
        self.new_button.setEnabled(not value)
        self.session_list.setEnabled(not value)
        self.intent.setEnabled(not value)
        self.update_review()

    def send(self):
        if self.controller.busy:
            return
        text = self.input.toPlainText().strip()
        if not text:
            return
        try:
            self.controller.submit(text, self.intent.currentIndex() == 1)
            self.input.clear()
        except Exception as exc:
            show_error(self, exc)

    def settings(self):
        if self.controller.busy:
            show_error(self, "Stop the active task before changing the connection.")
            return
        SettingsDialog(self.controller, self).exec_()
        self.model.setText(self.controller.settings.model or "Configure a local model")
        self.refresh_sessions()

    def new(self):
        try:
            self.controller.new_session()
            self.input.setFocus()
        except Exception as exc:
            show_error(self, exc)

    def history(self):
        try:
            sessions = self.controller.store.sessions()
            labels = [str(i+1) + ". " + (messages[0].get("content", "Empty")[:70] if messages else "Empty") for i, (_, messages) in enumerate(sessions)]
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Conversation History", "Session", labels, 0, False)
            if ok:
                key, messages = sessions[labels.index(choice)]
                self.controller.new_session(messages, key)
        except Exception as exc:
            show_error(self, exc)

    def drafts(self):
        try:
            drafts = self.controller.drafts()
            labels = [str(i+1) + ". " + p.summary[:90] for i, p in enumerate(drafts)]
            if not labels:
                show_error(self, "No saved proposal drafts yet.")
                return
            choice, ok = QtWidgets.QInputDialog.getItem(self, "Saved Proposal Drafts", "Draft (revalidated against the current project)", labels, 0, False)
            if ok:
                self.controller.load_draft(drafts[labels.index(choice)])
                self.review()
        except Exception as exc:
            show_error(self, exc)

    def attach(self):
        files, _ = QtWidgets.QFileDialog.getOpenFileNames(self, "Attach Data or Source", str(self.controller.policy.root / "externals"))
        for filename in files:
            try:
                path = self.controller.policy.attach(filename)
                if not self.attachments.findItems(path, QtCore.Qt.MatchExactly):
                    self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))
            except Exception as exc:
                show_error(self, exc)

    def remove_attachment(self, item):
        self.controller.policy.attachments.discard(Path(item.text()).resolve())
        self.controller.attachments_changed.emit(sorted(map(str, self.controller.policy.attachments)))

    def sync_attachments(self, paths):
        self.attachments.clear()
        self.attachments.addItems(paths)
        self.attachments.setVisible(bool(paths))

    def capabilities(self):
        from .knowledge_ui import KnowledgeDialog
        KnowledgeDialog(self.controller, self).exec_()

    def review(self):
        try:
            ReviewDialog(self.controller, self).exec_()
        except Exception as exc:
            show_error(self, exc)

    def restore(self):
        try:
            self.controller.restore()
            self.review()
        except Exception as exc:
            show_error(self, exc)

    def review_action(self):
        action = copy.deepcopy(self.controller.action)
        if not action:
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Review Session Action")
        dialog.resize(600, 420)
        layout = QtWidgets.QVBoxLayout(dialog)
        text = QtWidgets.QPlainTextEdit()
        text.setReadOnly(True)
        text.setPlainText(json.dumps({k: v for k, v in action.items() if k not in {"runtime_revision", "generation"}}, ensure_ascii=False, indent=2)
                          + "\n\nThis action affects the existing connection/device. File restore cannot undo a transmission.")
        layout.addWidget(text)
        run_button = QtWidgets.QPushButton("Run Action")
        def run_action():
            try:
                self.controller.run_action(digest(action))
                dialog.accept()
            except Exception as exc:
                show_error(dialog, exc)
        run_button.clicked.connect(run_action)
        layout.addWidget(run_button)
        dialog.exec_()

    def preview_data(self):
        if self.data_preview is None:
            show_error(self, "Ask the assistant to inspect a file first.")
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("Inspected Data Preview")
        dialog.resize(850, 600)
        layout = QtWidgets.QVBoxLayout(dialog)
        if "rows" in self.data_preview and "columns" in self.data_preview:
            columns, rows = self.data_preview["columns"], self.data_preview["rows"]
            table = QtWidgets.QTableWidget(len(rows), len(columns))
            table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            table.setHorizontalHeaderLabels(columns)
            for i, row in enumerate(rows):
                for j, value in enumerate(row[:len(columns)]):
                    table.setItem(i, j, QtWidgets.QTableWidgetItem(str(value)))
            layout.addWidget(table)
        else:
            text = QtWidgets.QPlainTextEdit()
            text.setReadOnly(True)
            text.setPlainText(json.dumps(self.data_preview, ensure_ascii=False, indent=2))
            layout.addWidget(text)
        dialog.exec_()
