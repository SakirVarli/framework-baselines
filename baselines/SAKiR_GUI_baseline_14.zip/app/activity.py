"""Working phrases and animation shared by the console and native assistant."""

WORKING_PHRASES = [
    "Pip cooking",
    "Tiny magic",
    "Env snack",
    "Almost there",
    "Doing stuff",
    "Module hunt",
    "Bit shuffle",
    "Tool time",
    "Pkg party",
    "Loading luck",
    "Dependency tea",
    "Python yoga",
    "Wheel spin",
    "Cache dive",
    "Small wizardry",
]

ACTIVITY_ANIMATION = [
    (".   .", 0.14),
    (" ~ ~ ", 0.14),
    (" s s ", 0.14),
    ("  §  ", 0.14),
    ("  S  ", 0.30),
    ("  §  ", 0.14),
    (" s s ", 0.14),
    (" ~ ~ ", 0.14),
]
